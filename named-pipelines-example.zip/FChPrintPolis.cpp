//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FChPrintPolis.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sAlphaListBox"
#pragma link "sCheckListBox"
#pragma link "sSpeedButton"
#pragma link "sButton"
#pragma resource "*.dfm"
TForm4 *Form4;
//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm4::sCheckListBox1ClickCheck(TObject *Sender)
{
  sButton1->Enabled = true;
}
//---------------------------------------------------------------------------

