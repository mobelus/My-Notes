//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "UShowHTML.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SHDocVw_OCX"
#pragma resource "*.dfm"

TFShowHTML *FShowHTML;
//---------------------------------------------------------------------------
__fastcall TFShowHTML::TFShowHTML(TComponent* Owner)
        : TForm(Owner)
{
}
//----------------------------------------------------------------------------
__fastcall TFShowHTML::TFShowHTML(TComponent* Owner, AnsiString html_file)
        :TForm(Owner)
{
 WB->Navigate(WideString(html_file));
}
//------------------------------------------------------------------------------
__fastcall TFShowHTML::TFShowHTML(TComponent* Owner, TStringList* html_code)
        :TForm(Owner)
{
  TMemoryStream *ms=new TMemoryStream();
  html_code->SaveToStream(ms);
  ms->Seek(0,0);
  WB->Navigate(L"about:blank");
  IPersistStreamInit *ps;
  WB->Document->QueryInterface(IID_IPersistStreamInit,(void **)&ps);
  TStreamAdapter *sa=new TStreamAdapter(ms,soReference);
  ps->Load(*sa);
  delete ms;

}
//------------------------------------------------------------------------------
__fastcall TFShowHTML::TFShowHTML(TComponent* Owner, mops_api_018* m_api, AnsiString file_name_in_store)
        :TForm(Owner)
 {
   int res;
   TMemoryStream *ms=new TMemoryStream();
   int  id_file=m_api->Internal_Get_Additional_File_Id_By_Name(file_name_in_store);
   TADOQuery *qw=m_api->dbGetCursor(res,"select Body from _Mops_File_Store_ where id=" + IntToStr(id_file));
  ((TBlobField*) qw->FieldByName("body"))->SaveToStream(ms);
   m_api->dbCloseCursor(res,qw);
  ms->Seek(0,0);
  WB->Navigate(L"about:blank");
  IPersistStreamInit *ps;
  WB->Document->QueryInterface(IID_IPersistStreamInit,(void **)&ps);
  TStreamAdapter *sa=new TStreamAdapter(ms,soReference);
  ps->Load(*sa);
  delete ms;
 }


 //---------------------------------------------------------------------------
void __fastcall TFShowHTML::WBDocumentComplete(TObject *Sender,
      LPDISPATCH pDisp, Variant *URL)

{
  WB->OleObject.OlePropertyGet("Document").OlePropertyGet("Body").OlePropertySet("background",img.c_str());
  this->Caption=WB->OleObject.OlePropertyGet("Document").OlePropertyGet("Title");
}
//---------------------------------------------------------------------------
void __fastcall TFShowHTML::Button1Click(TObject *Sender)
{
   WB->ExecWB(OLECMDID_PRINTPREVIEW,OLECMDEXECOPT_DODEFAULT);
}
//---------------------------------------------------------------------------
void __fastcall TFShowHTML::Button2Click(TObject *Sender)
{
   WB->ExecWB(OLECMDID_PRINT,OLECMDEXECOPT_DODEFAULT);
}
//---------------------------------------------------------------------------
void __fastcall TFShowHTML::Button3Click(TObject *Sender)
{
 WB->ExecWB(OLECMDID_FIND,OLECMDEXECOPT_DODEFAULT);
}
//---------------------------------------------------------------------------

