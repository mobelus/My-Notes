//---------------------------------------------------------------------------

#ifndef KProfessionH
#define KProfessionH

#include "Ikoeff.h"
#include "IFrame.H"
//---------------------------------------------------------------------------
class CBaseKoeffProfession: public IBaseKoeff{
  IProfession *m_Iframe;
  double m_Koeff;
  AnsiString m_DesK;
  int m_pridProf;
protected :
  TCT m_TypeTariff;
  TCT m_prTypeTariff;
  AnsiString m_SQLf;
public:
  CBaseKoeffProfession(IProfession *f, TCT tt);
  AnsiString NKoeff_I()     { return "Kprof";};
  AnsiString DescKoeff_I()  { return "���������������� ����.";};
protected :
  virtual double getKoeff_I(){return m_Koeff;};
  virtual double calcKoeff_I(){return CalcKoeff();};
  virtual AnsiString getDescDBKoeff_I(){return m_DesK;};
protected :
  double  CalcKoeff();
  virtual bool GetDBQuery(int);
};


class CUKoeffProfession :public CBaseKoeffProfession{
public :
    CUKoeffProfession(IProfession *f, TCT tt)
      :CBaseKoeffProfession(f, tt){};
protected :
  virtual bool GetDBQuery(int);
};

class CPartnerKoeffProfession :public  CUKoeffProfession{
public :
    CPartnerKoeffProfession(IProfession *f, TCT tt)
      :CUKoeffProfession(f, tt){};
protected :
  virtual bool GetDBQuery(int);
};

class CIVCKoeffProfession :public CPartnerKoeffProfession{
public :
    CIVCKoeffProfession(IProfession *f, TCT tt)
      :CPartnerKoeffProfession(f, tt){};
protected :
  virtual bool GetDBQuery(int);
};

#endif

