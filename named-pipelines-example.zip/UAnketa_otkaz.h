//---------------------------------------------------------------------------

#ifndef UAnketa_otkazH
#define UAnketa_otkazH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sComboBox.hpp"
#include "sListView.hpp"
#include "sBitBtn.hpp"
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFAnketa_otkaz : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TPanel *Panel2;
        TComboBox *ComboBox1;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *Edit1;
        TLabel *Label3;
        TEdit *Edit2;
        TGroupBox *GroupBox1;
        TLabel *Label4;
        TEdit *Edit3;
        TLabel *Label5;
        TEdit *Edit4;
        TLabel *Label6;
        TsDateEdit *sDateEdit1;
        TLabel *Label7;
        TsDateEdit *sDateEdit2;
        TLabel *Label8;
        TsDateEdit *sDateEdit3;
        TLabel *Label9;
        TEdit *Edit5;
        TLabel *Label10;
        TEdit *Edit6;
        TEdit *Edit7;
        TLabel *Label11;
        TLabel *Label12;
        TEdit *Edit8;
        TLabel *Label13;
        TEdit *Edit9;
        TLabel *Label14;
        TsDateEdit *sDateEdit4;
        TLabel *Label15;
        TsDateEdit *sDateEdit5;
        TLabel *Label16;
        TsDateEdit *sDateEdit6;
        TLabel *Label17;
        TsComboBox *sComboBox1;
        TEdit *Edit10;
        TLabel *Label18;
        TLabel *Label19;
        TsComboBox *sComboBox2;
        TEdit *Edit11;
        TLabel *Label20;
        TsComboBox *sComboBox3;
        TEdit *Edit12;
        TLabel *Label21;
        TsComboBox *sComboBox4;
        TLabel *Label22;
        TEdit *Edit13;
        TLabel *Label23;
        TsComboBox *sComboBox5;
        TLabel *Label24;
        TsComboBox *sComboBox6;
        TLabel *Label25;
        TsComboBox *sComboBox7;
        TLabel *Label26;
        TsComboBox *sComboBox8;
        TEdit *Edit14;
        TLabel *Label27;
        TEdit *Edit15;
        TLabel *Label28;
        TEdit *Edit16;
        TsBitBtn *sBitBtn1;
        TsBitBtn *sBitBtn2;
        TsBitBtn *sBitBtn3;
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall Edit2Change(TObject *Sender);
        void __fastcall Edit3Change(TObject *Sender);
        void __fastcall Edit4Change(TObject *Sender);
        void __fastcall sDateEdit1Change(TObject *Sender);
        void __fastcall sDateEdit2Change(TObject *Sender);
        void __fastcall sDateEdit3Change(TObject *Sender);
        void __fastcall Edit5Change(TObject *Sender);
        void __fastcall Edit6Change(TObject *Sender);
        void __fastcall Edit7Change(TObject *Sender);
        void __fastcall Edit8Change(TObject *Sender);
        void __fastcall Edit9Change(TObject *Sender);
        void __fastcall sDateEdit4Change(TObject *Sender);
        void __fastcall sDateEdit5Change(TObject *Sender);
        void __fastcall sDateEdit6Change(TObject *Sender);
        void __fastcall sComboBox1Change(TObject *Sender);
        void __fastcall Edit10Change(TObject *Sender);
        void __fastcall sComboBox2Change(TObject *Sender);
        void __fastcall Edit11Change(TObject *Sender);
        void __fastcall sComboBox3Change(TObject *Sender);
        void __fastcall Edit12Change(TObject *Sender);
        void __fastcall sComboBox4Change(TObject *Sender);
        void __fastcall Edit13Change(TObject *Sender);
        void __fastcall sComboBox5Change(TObject *Sender);
        void __fastcall sComboBox6Change(TObject *Sender);
        void __fastcall sComboBox7Change(TObject *Sender);
        void __fastcall sComboBox8Change(TObject *Sender);
        void __fastcall Edit14Change(TObject *Sender);
        void __fastcall Edit15Change(TObject *Sender);
        void __fastcall Edit16Change(TObject *Sender);
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sBitBtn3Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFAnketa_otkaz(TComponent* Owner);
       void __fastcall PrepareFields(TList *list_anketa );
       void * m_api;
       int id_terr;
};



typedef struct Zastrach_Data
{
    AnsiString fio;
    AnsiString f_zastrach;
    AnsiString i_zastrach;
    AnsiString o_zastrach;
    AnsiString address;
    AnsiString tel;
    AnsiString pasport_ser;
    AnsiString pasport_num;
    TDateTime pasport_data_vidachi;
    TDateTime pasport_deystv_do;
    TDateTime pasport_date_rogd;
    AnsiString pasport_gragdanstvo;
    AnsiString mesto_raboti;
    AnsiString strani_viezda;
    AnsiString turist_firma;
    AnsiString num_dogovor;
    TDateTime date_dogovor;
    TDateTime start_data_poezdki;
    TDateTime end_data_poezdki;
    bool chron_zabolevan_yes;
    AnsiString chron_zabolevan;
    bool beremennost_yes;
    AnsiString beremennost;
    bool rodstv_v_stacionare_yes;
    AnsiString rodstv_v_stacionare;
    bool otkaz_v_vise_yes;
    AnsiString otkaz_v_stranu;
    bool otmetki_v_deystv_pasporte_yes;
    bool otmetki_v_starom_pasporte_yes;
    bool zakl_dogovor_yes;
    bool obrasch_za_vozmecheniem_yes;
    AnsiString obrasch_za_vozmecheniem;
    AnsiString stoimost_poezdki;
    AnsiString reshenie_strachovshika;
    AnsiString CheckData();
} Zastrach_Data;

//---------------------------------------------------------------------------
extern PACKAGE TFAnketa_otkaz *FAnketa_otkaz;
//---------------------------------------------------------------------------
#endif
