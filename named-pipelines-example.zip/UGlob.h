
#ifndef UGlobH
#define UGlobH

#include "Tmops_api.h"

extern mops_api_020* gAPI;
extern int gRes;
extern TADOQuery *gQTTTbl;
extern AnsiString sidTT;

void InitTT(){
  gQTTTbl = gAPI->dbGetCursor(gRes, "select * from VZR174Pr_type_calc");
  sidTT = gAPI->vrGetVariableCurProduct(gRes, "id_type_tarif");
}

void gfID(AnsiString tbl, AnsiString sWhere, AnsiString sID, int &idK){
  AnsiString sSQL;
  AnsiString sidTTl = sidTT;
  int count = gAPI->dbGetIntFromQuery(gRes, "select count(*) from VZR174Pr_type_calc");
  int id;

  if(gAPI == NULL)
    return;

  for(int i = 0;i < count;i++){
    AnsiString sq;

    sq = "select " + sID + " from " + tbl + " where " + sWhere + " and id_type_calc = " + sidTTl;
    if( tbl!="" && (id = gAPI->dbGetIntFromQuery(gRes, sq))   > 0){
      idK = id;
      return;
    }
    else{
      gQTTTbl->Filtered = false;
      gQTTTbl->Filter = "id_type_calc =" + sidTTl;
      gQTTTbl->Filtered = true;
      int idTT = gQTTTbl->FieldByName("id_type_calc_parent")->AsInteger;
      sidTTl = IntToStr(idTT);
      gQTTTbl->Filtered = false;
   }
  }
}

double gfK(AnsiString tbl, AnsiString sWhere, AnsiString sID, AnsiString sK){
  AnsiString sSQL;
  AnsiString sidTTl = sidTT;
  int count = gAPI->dbGetIntFromQuery(gRes, "select count(*) from VZR174Pr_type_calc");

  if(gAPI == NULL)
    return -1;
  for(int i = 0;i < count;i++){
    AnsiString sql = "select " + sID + " from " + tbl + " where " + sWhere + " and id_type_calc = " + sidTTl;
    if(gAPI->dbGetIntFromQuery(gRes, sql) > 0){
      sql = "select " + sK + " from " + tbl + " where " + sWhere + " and id_type_calc = " + sidTTl;
      return gAPI->dbGetFloatFromQuery(gRes, sql);
    }
    else{
      gQTTTbl->Filtered = false;
      gQTTTbl->Filter = "id_type_calc =" + sidTTl;
      gQTTTbl->Filtered = true;
      int idTT = gQTTTbl->FieldByName("id_type_calc_parent")->AsInteger;
      sidTTl = IntToStr(idTT);
      gQTTTbl->Filtered = false;
   }
  }
  return -1;
}

double gfK1(AnsiString from, AnsiString tbl1, AnsiString sWhere, AnsiString sID, AnsiString sK){
  AnsiString sSQL;
  AnsiString sidTTl = sidTT;
  int count = gAPI->dbGetIntFromQuery(gRes, "select count(*) from VZR174Pr_type_calc");

  if(gAPI == NULL)
    return -1;
  for(int i = 0;i < count;i++){
    AnsiString sql = "select " + sID + " from " + from + " where " + sWhere + " and " + tbl1 + ".id_type_calc = " + sidTTl;
    if(gAPI->dbGetIntFromQuery(gRes, sql) > 0){
      sql = "select " + sK + " from " + from + " where " + sWhere + " and " + tbl1 + ".id_type_calc = " + sidTTl;
      return gAPI->dbGetFloatFromQuery(gRes, sql);
    }
    else{
      gQTTTbl->Filtered = false;
      gQTTTbl->Filter = "id_type_calc =" + sidTTl;
      gQTTTbl->Filtered = true;
      int idTT = gQTTTbl->FieldByName("id_type_calc_parent")->AsInteger;
      sidTTl = IntToStr(idTT);
      gQTTTbl->Filtered = false;
   }
  }
  return -1;
}

TADOQuery * gfQuery(AnsiString tbl, AnsiString sParam, AnsiString sWhere = "")
{
   AnsiString sSQL;
  AnsiString sidTTl = sidTT;
   int count = gAPI->dbGetIntFromQuery(gRes, "select count(*) from VZR174Pr_type_calc");
   TADOQuery *Qw;

   if(gAPI == NULL) return NULL;
   AnsiString s = (sWhere != "")?AnsiString(" and " + sWhere):AnsiString("");
   for(int i = 0;i < count;i++){
      Qw = gAPI->dbGetCursor(gRes, "select " + sParam + " from " + tbl + " where id_type_calc = " + sidTTl + s);
      if(Qw != NULL && (Qw->RecordCount > 0)) return Qw;
      else{
      gQTTTbl->Filtered = false;
      gQTTTbl->Filter = "id_type_calc =" + sidTTl;
      gQTTTbl->Filtered = true;
      int idTT = gQTTTbl->FieldByName("id_type_calc_parent")->AsInteger;
      sidTTl = IntToStr(idTT);
      gQTTTbl->Filtered = false;
      }
   }
   return NULL;
}

TADOQuery * gfQuery2(AnsiString tbl, AnsiString sParam, AnsiString sWhere = ""){
  AnsiString sSQL;
  AnsiString sidTTl = sidTT;
  int count = gAPI->dbGetIntFromQuery(gRes, "select count(*) from VZR174Pr_type_calc");
  TADOQuery *Qw;

  if(gAPI == NULL)
    return NULL;
  AnsiString s = (sWhere != "")?AnsiString(" and " + sWhere):AnsiString("");
  for(int i = 0;i < count;i++){

    Qw = gAPI->dbGetCursor(gRes, "select " + sParam + " from " + tbl + " where id_type_calc = " + sidTTl + s);
    if(Qw != NULL && (Qw->RecordCount > 0)){
      return Qw;
    }
    else{
      gQTTTbl->Filtered = false;
      gQTTTbl->Filter = "id_type_calc =" + sidTTl;
      gQTTTbl->Filtered = true;
      int idTT = gQTTTbl->FieldByName("id_type_calc_parent")->AsInteger;
      sidTTl = IntToStr(idTT);
      gQTTTbl->Filtered = false;
   }
  }
  return NULL;
}

TADOQuery * gfQuery1(AnsiString sParam, AnsiString from, AnsiString sWhere, AnsiString tbl){
  AnsiString sSQL;
  AnsiString sidTTl = sidTT;
  int count = gAPI->dbGetIntFromQuery(gRes, "select count(*) from VZR174Pr_type_calc");
  TADOQuery *Qw;

  if(gAPI == NULL)
    return NULL;
  AnsiString s = (sWhere != "")?AnsiString(" and " + sWhere):AnsiString("");
  for(int i = 0;i < count;i++){

    Qw = gAPI->dbGetCursor(gRes, "select " + sParam + " from " + from + " where " + tbl + ".id_type_calc = " + sidTTl + s);
    if(Qw != NULL && (Qw->RecordCount > 0)){
      return Qw;
    }
    else{
      gQTTTbl->Filtered = false;
      gQTTTbl->Filter = "id_type_calc =" + sidTTl;
      gQTTTbl->Filtered = true;
      int idTT = gQTTTbl->FieldByName("id_type_calc_parent")->AsInteger;
      sidTTl = IntToStr(idTT);
      gQTTTbl->Filtered = false;
   }
  }
  return NULL;
}
#define ADD       1
#define ADDAND    2
#define ADDWHERE  3

AnsiString gfQwTTf(AnsiString query, int tyVar){
  AnsiString sRet;

  if(tyVar == 1)
    sRet = query + " id_type_calc = " + sidTT;
  else if(tyVar == 2)
    sRet = query + " and id_type_calc = " + sidTT;
  else if(tyVar == 3)
    sRet = query + " where id_type_calc = " + sidTT;

  return sRet;
}

class IKoeffTerritory{
  public:
    virtual bool getCountry_I(char **buff) = 0;
};


class KoeffVZRTerritory{
  IKoeffTerritory *m_Iframe;
  public:
    KoeffVZRTerritory(IKoeffTerritory *f): m_Iframe(f){};
    const char *getNKoeff_I(){ return "Kt";};
    const char *getDescKoeff_I(){ return "����������� ������������ �� ���������������� ��������";};
    double Koeff(){return getKoeff_I();};
  protected :
    virtual double getKoeff_I();
};

class KoeffVZRTerritoryU: public KoeffVZRTerritory
{
  protected :
    virtual double getKoeff_I(){return 0.0;};
};


double KoeffVZRTerritory::getKoeff_I(){
  double Krez = 0.0;
  AnsiString
    sCountry,
    sql = "";
  char *buff;

  const char* qkTerr = "SELECT VZR174Pr_terr_main_K.K FROM (vzr174pr_terr_str RIGHT JOIN VZR174Pr_terr_main_K ON vzr174pr_terr_str.id_terr = VZR174Pr_terr_main_K.id_terr) LEFT JOIN VZR174Pr_Country ON vzr174pr_terr_str.id_str = VZR174Pr_Country.ID WHERE (VZR174Pr_Country.ID = %i) AND VZR174Pr_terr_main_K.id_type_calc=1;";

  m_Iframe->getCountry_I(&buff);
  sCountry = buff;
  delete [] buff;
  TStringList *lst = new TStringList();
  lst->Delimiter = ',';
  lst->DelimitedText = StringReplace(sCountry.Trim()," ","_",TReplaceFlags()<<rfReplaceAll);
  for(int i = 0; i < lst->Count; i++){
  sCountry = StringReplace((*lst)[i],"_"," ",TReplaceFlags()<<rfReplaceAll);
  int id_country = gAPI->dbGetIntFromQuery(gRes, "select ID from VZR174Pr_Country where CountryLatName = '" + sCountry + "' or CountryName = '" + sCountry + "'");
  double var = gAPI->dbGetFloatFromQuery(gRes, sql.sprintf(qkTerr, id_country));
  if(Krez < var)
    Krez = var;
  }
  delete lst;

  return Krez;
};

class IBaseModule{
  virtual void Calculate_I() = 0;
  virtual int CheckValues_I() = 0;
  virtual int Description_I() = 0;
};


#endif //UGlobH

