//---------------------------------------------------------------------------

#ifndef USprYurPredstH
#define USprYurPredstH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sListView.hpp"
#include <ComCtrls.hpp>
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "Tmops_api.h"
#include "sCustomComboEdit.hpp"
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sComboBox.hpp"
//---------------------------------------------------------------------------
class TFSprPredsYur : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel2;
        TsPanel *sPanel1;
        TsPanel *sPanel3;
        TsBitBtn *sBitBtn1;
        TsPanel *sPanel4;
        TsBitBtn *sBitBtn2;
        TsListView *LV;
        TsLabel *sLabel1;
        TsEdit *PredstName;
        TsLabel *sLabel2;
        TsEdit *DovNum;
        TsLabel *sLabel3;
        TsDateEdit *DovData;
        TsLabel *sLabel4;
        TsEdit *DogNum;
        TsLabel *sLabel5;
        TsDateEdit *sDateEdit1;
        TsBitBtn *sBitBtn3;
        TsBitBtn *sBitBtn4;
        TsBitBtn *sBitBtn5;
        TsLabel *sLabel6;
        TsEdit *PredstDolgn;
        TsLabel *sLabel7;
        TsEdit *sEdit1;
        TsLabel *sLabel8;
        TsEdit *sEdit2;
        TsComboBox *sComboBox1;
        TsLabel *sLabel9;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
        void __fastcall sBitBtn3Click(TObject *Sender);
        void __fastcall sBitBtn4Click(TObject *Sender);
        void __fastcall sBitBtn5Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
        __fastcall TFSprPredsYur(TComponent* Owner);
        mops_api_007* m_api;
        void __fastcall PrepareFields();
        int insert_update; //-1  - ������, 0 - update, 1- insert
};
//---------------------------------------------------------------------------
extern PACKAGE TFSprPredsYur *FSprPredsYur;
//---------------------------------------------------------------------------
#endif
