//---------------------------------------------------------------------------

#ifndef UStraniH
#define UStraniH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sAlphaListBox.hpp"
#include "sCheckListBox.hpp"
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "Tmops_api.h"
//---------------------------------------------------------------------------
class TFStrani : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsPanel *sPanel2;
        TsCheckListBox *sCheckListBox1;
        TsBitBtn *sBitBtn1;
        TsBitBtn *sBitBtn2;
        TCheckBox *CheckBox1;
  TsBitBtn *sBitBtn3;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sCheckListBox1DrawItem(TWinControl *Control,
          int Index, TRect &Rect, TOwnerDrawState State);
        void __fastcall CheckBox1Click(TObject *Sender);
  void __fastcall sBitBtn3Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFStrani(TComponent* Owner);
        mops_api_007* m_api;
        void __fastcall Init(AnsiString Strani, bool flag = false);
        AnsiString stran;
        bool specprogram;
        long m_id_terr;
        AnsiString m_terr_str;
        AnsiString m_terr;

        AnsiString m_OutStranReport;
};
//---------------------------------------------------------------------------
extern PACKAGE TFStrani *FStrani;
//---------------------------------------------------------------------------
#endif
