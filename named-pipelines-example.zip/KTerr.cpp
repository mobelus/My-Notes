
#pragma hdrstop
#include "KTERR.H"
#include "BaseVZRMod.h"
#include "Constants.h"

//���������� �� ������ ����������� ����. ��� ��
/*const char* qTerr = "SELECT MIN(VZR174Pr_terr_main_K.K)"
    " FROM (vzr174pr_terr_str RIGHT JOIN VZR174Pr_terr_main_K ON vzr174pr_terr_str.id_terr = VZR174Pr_terr_main_K.id_terr)"
    " LEFT JOIN VZR174Pr_Country ON (vzr174pr_terr_str.id_str<>298 and vzr174pr_terr_str.id_str = VZR174Pr_Country.ID)"
    " WHERE (VZR174Pr_Country.ID = %i) AND VZR174Pr_terr_main_K.id_type_calc= %d";
*/

const char* qkDes = "SELECT group FROM VZR174Pr_terr_main_K as TerrMain,"
   " VZR174Pr_terr_group_main_risk as TerrGMain"
   " where id_terr = %i and TerrMain.id_type_calc = %d and TerrGMain.id_type_calc = TerrMain.id_type_calc and TerrMain.id_group = TerrGMain.id_terr_group and K = %f"
   " order by id_group";

CBaseKoeffTerritory::CBaseKoeffTerritory(ITerritory *f,  TCT tt)
    :m_Iframe(f), m_TypeTariff(tt){
      m_idWorldwide =         gAPI->dbGetIntFromQuery(gRes, "select id_terr from VZR174Pr_terr where terr_name = 'Worldwide'");
      m_idSchengen =          gAPI->dbGetIntFromQuery(gRes, "select id_terr from VZR174Pr_terr where terr_name = 'Schengen'");
      m_idForeignCountries =  gAPI->dbGetIntFromQuery(gRes, "select id_terr from VZR174Pr_terr where terr_name = 'Foreign countries'");
      m_idSNG =               gAPI->dbGetIntFromQuery(gRes, "select id_terr from VZR174Pr_terr where terr_name = 'CIS'");
}

double CBaseKoeffTerritory::CalcKoeff(){
  double Krez = 0.0;
  AnsiString
    sStrani = "", str_typeterr="",
    err     = "";
  char *Strani;
  int idTerr;

  try{
    if(!m_Iframe->getCountry_I(idTerr, &Strani))
      return 0;
//    if(m_prTypeTariff == m_TypeTariff && (m_pridTerr == idTerr) && (m_prStrani == Strani))
//      return m_Koeff;
    m_pridTerr = idTerr;
    m_prStrani = Strani;
    m_prTypeTariff = m_TypeTariff;
  }catch(Exception &e){
    err = e.Message;
  }
  sStrani = Strani;
  if(sStrani.IsEmpty() ) {
        if(idTerr == m_idWorldwide) {
            Krez = 2;
            str_typeterr = "7";
        } else if( idTerr == 668 ) {  //���� ���, ����� ���
            Krez = 2;
            str_typeterr = "5";
        }
  } else {
        TStringList *lst = new TStringList();
        lst->Delimiter = ',';
        lst->DelimitedText = StringReplace(sStrani.Trim()," ","_",TReplaceFlags()<<rfReplaceAll);

        for(int i = 0; i < lst->Count; i++) {

            AnsiString sCountry = StringReplace((*lst)[i],"_"," ",TReplaceFlags()<<rfReplaceAll);
            int idC = gAPI->dbGetIntFromQuery(gRes, "select ID from VZR174Pr_Country where VZR174Pr_Country.nostrah=0 and CountryLatName = '" + sCountry + "' or CountryName = '" + sCountry + "'");

            TADOQuery* q = gAPI->dbGetCursor(gRes,  "SELECT medkoef.K as k,c.id_terr_main_k as terrtype from VZR174Pr_terr_main_K medkoef, VZR174Pr_Country c "
            " where c.id_terr_main_k=medkoef.id and c.ID="+IntToStr(idC));

            double var = q->FieldByName("k")->AsFloat;
            AnsiString ciuntry_typeterr = q->FieldByName("terrtype")->AsString;

            if(Krez < var) {
                  Krez = var;
                  str_typeterr = ciuntry_typeterr;
            }
            gAPI->dbCloseCursor(gRes, q);
        }

        delete lst;
    }


  m_Koeff = Krez;
  m_DesK = FloatToStr(m_Koeff) + " (���������� " + str_typeterr + ")";

  return Krez;
}

//��� ���
double CBaseKoeffTerritory::GetDBQuery(int idCountry){
  return 1;
}


AnsiString CBaseKoeffTerritory::DesKoeff(double K, int id_terr) {
  return "";//FloatToStr(K) + " (���������� " + gAPI->dbGetStringFromQuery(gRes, "select id_terr_main_k from vzr174pr_country where id="+IntToStr(id_terr)) +")";
}

//��� ��
double CUKoeffTerritory::GetDBQuery(int idCountry){
//  double f = 0.0f;

 //   double f = gAPI->dbGetFloatFromQuery(gRes, m_SQLf.sprintf(qTerr, idCountry, (int)m_TypeTariff));
    return 1;
}

AnsiString CUKoeffTerritory::DesKoeff(double K){
  return FloatToStr(K) + " (" + gAPI->dbGetStringFromQuery(gRes, m_SQLf.sprintf(qkDes, (int)eROZNICA_UR, K)) + ")";
}
#pragma package(smart_init)
