//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UPartner.h"
#include "BaseVZRMod.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sLabel"
#pragma link "sGroupBox"
#pragma link "sBitBtn"
#pragma link "sComboBox"
#pragma resource "*.dfm"
TFPartner *FPartner;
//---------------------------------------------------------------------------
__fastcall TFPartner::TFPartner(TComponent* Owner,mops_api_018 *api)
        : TForm(Owner), m_api(api)
{
  int res;
  TCT tt = (TCT)StrToIntDef(m_api->vrGetVariableCurProduct(res, "id_type_tarif"),1);

  OldFormWP=this->WindowProc;
  this->WindowProc=NewFormWP;
  if(tt == eROZNICA_FIZ || (tt == eROZNICA_UR))
    sRadioGroup1->ItemIndex=0;
  else if(tt == ePARTNER_UR)
    sRadioGroup1->ItemIndex=1;
  m_api->Fill_ComboBox_Int(res, sCBSpec, "select * from vzr174Pr_Regions", "id", "region_name");
  sCBSpec->ItemIndex = 0;
}
//---------------------------------------------------------------------------
void __fastcall TFPartner::NewFormWP(TMessage &Msg)
{
   if(Msg.Msg==WM_CLOSE)   return ; //��������� ������� ���� ������ ����� ������ "��"
   OldFormWP(Msg);
}
//---------------------------------------------------------------------------
void __fastcall TFPartner::sBitBtn1Click(TObject *Sender)
{
  m_api->vrSetVariableCurProduct(res, "id_type_tarif",  IntToStr((int)(sRadioGroup1->ItemIndex)?ePARTNER_UR:eROZNICA_FIZ));
  m_api->vrSetVariableCurProduct(res, "vzr174Pr_id_reg_spec_tarif",  IntToStr((int)sCBSpec->Items->Objects[sCBSpec->ItemIndex]));
}
//---------------------------------------------------------------------------

