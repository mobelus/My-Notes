//---------------------------------------------------------------------------

#ifndef UBorderoMonH
#define UBorderoMonH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Tmops_api.h"
#include "sBitBtn.hpp"
#include "sPanel.hpp"
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "Excel.h"
#include "sComboBox.hpp"
#include "sLabel.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "DateUtils.hpp"
#include "sGroupBox.hpp"
//---------------------------------------------------------------------------
class TFBorderoMon : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsPanel *sPanel2;
        TsBitBtn *sBitBtn1;
        TsLabel *sLabel1;
        TsComboBox *Month;
        TsLabel *sLabel2;
        TsDateEdit *sDateEdit1;
        TsLabel *sLabel3;
        TsDateEdit *sDateEdit2;
        TsLabel *sLabel4;
        TsComboBox *Doverit;
        TsLabel *sLabel5;
        TsComboBox *Poveren;
        TsRadioGroup *sRadioGroup1;
        TsBitBtn *sBitBtn2;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall MonthChange(TObject *Sender);
        void __fastcall sRadioGroup1Click(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
private:	// User declarations
  bool m_frep;
  AnsiString m_qfr;

  AnsiString __fastcall CreateQuery2FastReport();
public:		// User declarations
        __fastcall TFBorderoMon(TComponent* Owner);
        __fastcall TFBorderoMon(TComponent* Owner, bool frep);
      void  PrepareFields(bool preview);
      mops_api_007* m_api;
      bool PreView;
      AnsiString  __fastcall GetQuery2FastReport();
};
//---------------------------------------------------------------------------
extern PACKAGE TFBorderoMon *FBorderoMon;
//---------------------------------------------------------------------------
#endif
