//---------------------------------------------------------------------------
#ifndef FrameCalc_cH
#define FrameCalc_cH
//---------------------------------------------------------------------------
#include "BSO.h"
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sFrameAdapter.hpp"
#include "Tmops_api.h"
#include <Mask.hpp>
#include "sMaskEdit.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include "sComboBox.hpp"
#include "sLabel.hpp"
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sGroupBox.hpp"
#include "sEdit.hpp"
#include "sCurrEdit.hpp"
#include "sListView.hpp"
#include <ComCtrls.hpp>
#include "sBitBtn.hpp"
#include <msxmldom.hpp>
#include <XMLDoc.hpp>
#include <xmldom.hpp>
#include <XMLIntf.hpp>
#include "Constants.h"
#include "frxClass.hpp"
#include "frxDesgn.hpp"
//#include "ToolEdit.hpp"
//#include "RzEdit.hpp"
#include "cxCalendar.hpp"
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxDropDownEdit.hpp"
#include "cxEdit.hpp"
#include "cxMaskEdit.hpp"
#include "cxTextEdit.hpp"
#include <DB.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include "sPageControl.hpp"
#include <Buttons.hpp>
#include "sCheckBox.hpp"
#include "sAlphaListBox.hpp"
#include "UShowHTML.h"
#include "sCheckListBox.hpp"
#include "sSpeedButton.hpp"
#include "sMemo.hpp"
#include "sRichEdit.hpp"
#include <ADODB.hpp>
#include "sMonthCalendar.hpp"
#include "BaseVZRMod.h"
#include "sButton.hpp"
#include "cxGraphics.hpp"
#include "FramePrint_.h"

#define Ksb 0.9
#define Krgs 0.9

extern g_vip_master;

//---------------------------------------------------------------------------
class TFrameCalc : public TFrame, ITerritory, ISport, IProfession, IFree, ICountIns, IAge, IStudProg
{
__published:	// IDE-managed Components
  TsFrameAdapter *sFrameAdapter1;
  TsPanel *sPanel1;
  TDataSource *DataSource1;
  TGroupBox *GroupBox1;
  TButton *Button1;
  TButton *Button2;
  TDBGrid *DBGrid1;
  TsPanel *sPanel2;
  TGroupBox *gbCancelTrip;
  TsComboBox *CBCancelTripType;
  TGroupBox *gbCancelTripFranchise;
  TsCalcEdit *eCancelTripKoeff;
  TsComboBox *eCancelTripFranchise;
  TsCalcEdit *eCancelTripSumm;
  TsCalcEdit *ceCancelTripKoefAnder;
  TGroupBox *gbAccident;
  TsLabel *sLabel16;
  TsLabel *sLabel17;
  TsComboBox *CBAccidentSumm;
  TsComboBox *CBAccidentType;
  TGroupBox *gbAccidentFranchise;
  TsCalcEdit *eAccidentKoeff;
  TsComboBox *eAccidentFranchise;
  TsCalcEdit *ceAccidentKoefAnder;
  TGroupBox *gbPremium;
  TGroupBox *gbCivilLiability;
  TsLabel *sLabel15;
  TsComboBox *CBCivilLiabilitySumm;
  TGroupBox *gbCivilLiabilityFranchise;
  TsLabel *sLabel24;
  TsLabel *sLabel25;
  TsCalcEdit *eCivilLiabilityKoeff;
  TsCalcEdit *eCivilLiabilityFranchise;
  TsCalcEdit *ceCivilLiabilityKoefAnder;
  TsComboBox *sCCivil;
  TsCheckBox *sChBCivil;
  TsCheckBox *sChBCTripOplata;
  TsEdit *sECancelTrip;
  TsRadioGroup *sRGInsType;
  TGroupBox *GroupBox2;
  TsDateEdit *sDEStartTravel;
  TsComboBox *cbRegions;
  TsDateEdit *sDEZayav;
  TsSpeedButton *sSBLoadIns;
  TsEdit *eAllPremiumRUR;
  TsEdit *eTotalPremium;
  TsLabel *sLabel1;
  TsLabel *sLabel2;
  TsLabel *sLabel4;
  TcxDateEdit *cxDEBirthDay;
  TsBitBtn *sBBtnIns;
  TsBitBtn *sBBtnInsured;
  TsBitBtn *sBBtnBirthday;
  TsRichEdit *sRichEdit1;
  TsPanel *sPanel3;
  TCheckBox *cbMultiTrip;
  TsGroupBox *sGroupBox1;
  TsLabel *lbS;
  TsLabel *lbPO;
  TsComboBox *CBTerm;
  TsCalcEdit *eDays;
  TcxDateEdit *deStartDate;
  TcxDateEdit *deEndDate;
  TsBitBtn *sBitBtn1;
  TsBitBtn *sBitBtn2;
  TGroupBox *gbLossBag;
  TsComboBox *CBLossBagTransportType;
  TsComboBox *CBLossBagTimeFranchise;
  TEdit *eLossBagTimeFranchiseKoef;
  TGroupBox *gbLossBagFranchise;
  TsCalcEdit *eLossBagFranchiseKoeff;
  TsComboBox *eLossBagFranchise;
  TsCheckBox *sChB_Opis;
  TsBitBtn *sBBtnN1;
  TsEdit *eLossBagPrem;
  TsEdit *eCivilLiabilityPrem;
  TsEdit *eAccidentPrem;
  TsCheckBox *sChBDogDeistvya;
  TsPanel *sPanel4;
  TsSpeedButton *sSBListStran;
  TsLabel *sLbNoteCountry;
  TsCheckBox *sChBNoteCountry;
  TsComboBox *CBTerritory;
  TsEdit *EStrana;
  TsListBox *sLBTerrFastFind;
  TsCheckListBox *sCListBoxStraniSel;
  TGroupBox *gbMainRisk;
  TsComboBox *CBSumm;
  TComboBox *CBProgram;
  TsCalcEdit *ceMainKoefAnder;
  TGroupBox *gbMainFranchise;
  TsCalcEdit *eKoefKoef;
    TsComboBox *TeMainFranchise;
  TsEdit *eMedPrem;
  TsPanel *sPanel5;
  TsComboBox *CBCurrency;
  TsCalcEdit *eRate;
  TSpeedButton *SpeedButton1;
  TGroupBox *gbKoeff;
  TsComboBox *CBKoefSport;
  TEdit *eKoefSport;
  TsComboBox *CBKoefProf;
  TEdit *eKoefProf;
  TsRichEdit *sRESportMess;
  TsCalcEdit *eKoefFree;
    TsCheckBox *cbMedRisk;
    TCheckBox *cbLossBag;
    TCheckBox *cbCancelTrip;
    TCheckBox *cbCivilLiability;
    TCheckBox *cbAccident;
    TsLabel *sLabel6;
    TsCheckBox *sChB_fPers;
    TCheckBox *cbZabolevanie;
    TCheckBox *cbBeremennost;
    TsComboBox *LossBagSrok;
    TsBitBtn *sBBtnN4;
    TsBitBtn *sBitBtnMH;
    TsBitBtn *sBBtnN3;
    TsBitBtn *sBBtnN2;
    TGroupBox *gbSkidka;
    TComboBox *ComboBox_sotrudnik;
    TsBitBtn *sBBtnDisc;
    TLabel *Label4;
        TXMLDocument *XMLDoc;
    TCheckBox *CBSpecTarif;
    TCheckBox *cbMedRF;
    TsComboBox *CBLossBagSumm;
    TsCalcEdit *nbag;
    TsCheckBox *sCB_Student;
    TComboBox *sCELossBagSumm;
    TLabel *Label1;
    TCheckBox *alko;

  void __fastcall cbMultiTripClick(TObject *Sender);
  void __fastcall EStranaChange(TObject *Sender);
  void __fastcall eDaysChange(TObject *Sender);
  void __fastcall CBTermChange(TObject *Sender);
  void __fastcall deDatesChange(TObject *Sender);
  void __fastcall CBProgramChange(TObject *Sender);
  void __fastcall CBSummChange(TObject *Sender);
  void __fastcall CBKoefChange(TObject *Sender);
  void __fastcall eKoefFreeChange(TObject *Sender);
  void __fastcall cbLossBagClick(TObject *Sender);
  void __fastcall CBLossBagTimeFranchiseChange(TObject *Sender);
  void __fastcall CBLossBagTransportTypeChange(TObject *Sender);
  void __fastcall CBLossBagSummChange(TObject *Sender);
  void __fastcall cbCancelTripClick(TObject *Sender);
  void __fastcall eCancelTripSummChange(TObject *Sender);
  void __fastcall CBCancelTripTypeChange(TObject *Sender);
  void __fastcall cbCivilLiabilityClick(TObject *Sender);
  void __fastcall CBCivilLiabilitySummChange(TObject *Sender);
  void __fastcall cbAccidentClick(TObject *Sender);
  void __fastcall CBAccidentSummChange(TObject *Sender);
  void __fastcall CBAccidentTypeChange(TObject *Sender);
  void __fastcall CBCurrencyChange(TObject *Sender);
  void __fastcall eRateChange(TObject *Sender);
  void __fastcall ceMainKoefAnderChange(TObject *Sender);
  void __fastcall ceLossBagKoefAnderChange(TObject *Sender);
  void __fastcall ceCivilLiabilityKoefAnderChange(TObject *Sender);
  void __fastcall ceAccidentKoefAnderChange(TObject *Sender);
  void __fastcall eKoefKoefChange(TObject *Sender);
  void __fastcall eLossBagFranchiseKoeffChange(TObject *Sender);
  void __fastcall eCancelTripKoeffChange(TObject *Sender);
  void __fastcall eAccidentKoeffChange(TObject *Sender);
  void __fastcall cbRegionsChange(TObject *Sender);
  void __fastcall CBSpecTarifClick(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Button2Click(TObject *Sender);
  void __fastcall pcInsurerChange(TObject *Sender);
  void __fastcall eSurnameChange(TObject *Sender);
  void __fastcall eNameChange(TObject *Sender);
  void __fastcall eLastNameChange(TObject *Sender);
  void __fastcall eTelChange(TObject *Sender);
  void __fastcall eAddressChange(TObject *Sender);
  void __fastcall deBirthdayPropertiesChange(TObject *Sender);
  void __fastcall ComboBox_sotrudnikChange(TObject *Sender);
  void __fastcall SpeedButton1Click(TObject *Sender);
  void __fastcall eCivilLiabilityFranchiseChange(TObject *Sender);
  void __fastcall deStartDateKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall deEndDateKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall sCalcEdit1Change(TObject *Sender);
  void __fastcall deStatementDatePropertiesChange(TObject *Sender);
  void __fastcall sDEZayavChange(TObject *Sender);
  void __fastcall sDEStartTravelChange(TObject *Sender);
  void __fastcall sChBCivilClick(TObject *Sender);
  void __fastcall sCCivilChange(TObject *Sender);
  void __fastcall sChBCTripOplataClick(TObject *Sender);
  void __fastcall sRGInsTypeChanging(TObject *Sender, int NewIndex,
          bool &AllowChange);
  void __fastcall sECancelTripChange(TObject *Sender);
  void __fastcall EStranaKeyPress(TObject *Sender, char &Key);
  void __fastcall sLBTerrFastFindExit(TObject *Sender);
  void __fastcall sRGInsTypeClick(TObject *Sender);
  void __fastcall sBitBtn1Click(TObject *Sender);
  void __fastcall CBTerritoryChange(TObject *Sender);
  void __fastcall sSBListStranClick(TObject *Sender);
  void __fastcall EStranaKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall sCListBoxStraniSelKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall sCListBoxStraniSelExit(TObject *Sender);
  void __fastcall sLBTerrFastFindClick(TObject *Sender);
  void __fastcall sBitBtn2Click(TObject *Sender);
  void __fastcall sSBLoadInsClick(TObject *Sender);
  void __fastcall cxDEBirthDayPropertiesCloseUp(TObject *Sender);
  void __fastcall cxDEBirthDayExit(TObject *Sender);
  void __fastcall sLBTerrFastFindKeyPress(TObject *Sender, char &Key);
  void __fastcall EStranaKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall DBGrid1Exit(TObject *Sender);
  void __fastcall DBGrid1CellClick(TColumn *Column);
  void __fastcall DBGrid1DrawColumnCell(TObject *Sender, const TRect &Rect,
          int DataCol, TColumn *Column, TGridDrawState State);
  void __fastcall DBGrid1KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall DBGrid1ColExit(TObject *Sender);
  void __fastcall DBGrid1Enter(TObject *Sender);
  void __fastcall DBGrid1KeyPress(TObject *Sender, char &Key);
  void __fastcall cxDEBirthDayKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall cxDEBirthDayMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
  void __fastcall sCELossBagSummChange(TObject *Sender);
  void __fastcall sBBtnInsClick(TObject *Sender);
  void __fastcall sBBtnInsuredClick(TObject *Sender);
  void __fastcall OnClickRisks(TObject *Sender);
  void __fastcall sBBtnBirthdayClick(TObject *Sender);
  void __fastcall sBBtnDiscClick(TObject *Sender);
  void __fastcall sBBtnNRiskClick(TObject *Sender);
  void __fastcall sBitBtnMHClick(TObject *Sender);
  void __fastcall cbMedRiskClick(TObject *Sender);
  void __fastcall sChBDogDeistvyaClick(TObject *Sender);
    void __fastcall cbZabolevanieClick(TObject *Sender);
        void __fastcall DataSource1DataChange(TObject *Sender,
          TField *Field);
    void __fastcall nbagExit(TObject *Sender);
    void __fastcall nbagKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall nbagMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
private:
  int TermID;
  bool Check;
  double MainPremium,
         LossBagPremium,
         CancelTripPremium,
         CivilLiabilityPremium,
         AccidentPremium,
         TotalPremium,
         PremiumRUR,
         Rate,
         InsTotalPremium,
         InsPremiumRUR,
         TotalLossBagPremium,
         TotalCancelTripPremium,
         TotalCivilLiabilityPremium,
         TotalAccidentPremium;
  int flag_territory; // ���� �����, ��������  � ��������� ���������� (0 - ������� ������, 1 - ���, 2 - ������������ ��������� � �.�. , 4 - ������, 8 - ������ ��� ����������� ������
  bool region_spectarif; // ����, ������������, ����� �� ����������� ���������� ��� ���������� �������
  AnsiString CalcStringTotal;//������ �������
  TcxDateEdit *m_pDBEdit;
  TRect m_Sel_Rect;
  int m_idx;
  int m_InsCount;
  int load_type;
  bool m_flag_process_cb;
  bool m_valid_data;
  bool m_flag_data;
  int net_oshibok; //1 ���� ��� ������ ����������
  bool m_flag_spec_Belarus;
  bool frame_load; //true ����� ������� ����������� �.�. ������� ������������ ������� � ��� ������� �������� ������ �����������
  bool m_calc;
  bool m_fInitForm;
  AnsiString  m_des_calc_ctrl;
  TDateTime m_dtStart;
  TDateTime m_dtEnd;
  bool m_fInetConnect;
  bool m_fPressCurr;

  long m_id_copy; //��������� ������ ����� ��� ���
  int m_Res;
  double TotalMainPrem;//����� ������. �� ��������.
  //����������� ������������ �� ����������� ��������
  bool m_fAgeCountry;//���� ������� � ���, �������, ��������
  bool m_fTripDop;//����������� ������ �� �������� � ��������.
  bool fEnterTerr;
  bool fEnterTerr1;
  AnsiString sEnterTerr;
  bool fSpec;
  int mNewIndex;
  double m_dop_discount; //������ ��� �����������.
  AnsiString m_TerrName;

  AnsiString sKoeffFrAgeDes;
  AnsiString sKoeffFrCDaysDes;

  double m_KoefTerr;

  double __fastcall GetK_age(int age);
  void    __fastcall InitComboBoxes();
  void    __fastcall InitKoeffs();
  void    __fastcall InitControls();
  void    __fastcall Calculate(bool fgCalEn = false);
  void    __fastcall LoadComboBox(TsComboBox* aCB, AnsiString aTableName, AnsiString aFieldBrief, AnsiString aFieldValue, AnsiString aPredicate = "",  AnsiString aOrderBy = "");
  void __fastcall TFrameCalc::LoadComboBox(TComboBox* aCB, AnsiString aTableName, AnsiString aFieldBrief,
                                         AnsiString aFieldValue, AnsiString aPredicate, AnsiString aOrderBy);

  int     __fastcall GetDaysNumber(int aTermID);
  double  __fastcall GetMainRiskPremium(int aProgramID, int aSummID, int aTermID);
  double  __fastcall GetLossBagPremium(int aTransportTypeID, int aSummID);
  double  __fastcall GetCancelTripPremium(int aSumm, int aTypeID, float &Trif);
  double  __fastcall GetCivilLiabilityPremium(int aID);
  double  __fastcall GetAccidentPremium(int aSummID, int aTypeID);
  int     __fastcall GetComboBoxObject(TsComboBox* aCB);
  AnsiString GetCalcDescription();   //���������� ������ � ��������� �������
  double  __fastcall GetKurs(AnsiString, TDateTime);
  long    __fastcall GetTerm(AnsiString, AnsiString);
  long    __fastcall GetTermSpecAge();
  double  __fastcall Round_(double);
  void    __fastcall UpdateCurrensLimit(TObject *Sender = NULL);
  AnsiString __fastcall SwitchRusLat(AnsiString in, bool flag = true);
  void    __fastcall CBKoefCh(TObject *, AnsiString, AnsiString , AnsiString, AnsiString, AnsiString,AnsiString);
  AnsiString __fastcall GetRegion(){
      int res = 0;
      AnsiString sRet = m_api->vrGetVariableCurProduct(res, "region_mmo");
    //AnsiString sRet = m_api->dbGetStringFromQuery(res,"select SKK from _mops_polzovateli_ where id="+ m_api->vrGetVariableCurProduct(res,"_mops_global_tekushi_polzovatel_id_")).SubString(2,2);
    //return sRet;};
      return sRet.SubString(2,2);
  };
  bool __fastcall       CheckMaxSummTerr();
  bool __fastcall       CheckMinSummTerr();
  int __fastcall       CheckAgeTerr();
  int                   CalcYears(const TDateTime& dt1, const TDateTime& dt2);
  int __fastcall        GetDDayTerr();
//  AnsiString __fastcall MakeReportString(AnsiString &,AnsiString &, AnsiString &, AnsiString &);
  AnsiString __fastcall MakeReportString();
  void __fastcall       CurrencyEnabled();
  bool __fastcall       CheckEnterDtStart();
  void __fastcall       FindFilter(AnsiString sf);
  AnsiString __fastcall GetStrCountry(int id);
  AnsiString            DlgFileName(AnsiString);
  int __fastcall        StrLPos(AnsiString S, int start, char Ch);
  int __fastcall        StrRPos(AnsiString S, int start, char Ch);
  AnsiString __fastcall StrMidStr(AnsiString S, int start, int end);
  void __fastcall       ShowMessSport(int index);
  bool __fastcall       MedicRiskChecked(){return (CBProgram->ItemIndex != -1) && (CBSumm->ItemIndex != -1);};
  double __fastcall     CancelTripPercCountry();
  //�������� ����� �����������
  void __fastcall CALC_STOP(bool &flag, AnsiString des){
      if(m_des_calc_ctrl.IsEmpty()){
        m_des_calc_ctrl = des;
        flag = false;
      }
  };
  void __fastcall CALC_START(bool &flag, AnsiString des){
      if((m_des_calc_ctrl == des) || des.IsEmpty()){
        flag = true;
        m_des_calc_ctrl = "";
      }
  };
  bool
    mfCalcEndDate,
    m_fEscKay,
    m_fEnabledChangFilter,
    m_fSBListStran,
    m_fsCListBoxStraniSelKeyUpEnter;

  int           mDDay; //���������� ���� �������� � ������.
  int           m_idWorldwide;
  int           m_idSchengen;
  int           m_idForeignCountries;
  int           m_idSNG;
  int           m_chSSPos;
  int           m_chCount;
  int           m_nCol;
  int           m_idUSA;
  AnsiString    m_sEnterStraniRez;
  TReplaceFlags rf;
  TDataSet *    m_dCountryTbl;
  TDataSet *    m_dCountryTerrTbl;
  TDataSet *    m_dCountryTerrTbl1;
  int           m_idRoznicaT;
  int           m_idPartnerT;

public:

		int nAddDay;
        mops_api_019* m_api;
        TFramePrint* print_frame;
        TADOQuery* m_lQuery;
        TMemo *MemoDescription;
        TStringList *rules;
        TStringList *ShengenCountry; //� LoadFrame ������������ ������ ����� �������
      int     __fastcall CheckForm();
        __fastcall TFrameCalc(TComponent* Owner);
        __fastcall ~TFrameCalc();
        void __fastcall PrepareFields();
        void __fastcall SaveFrame(int calc_id);
        void __fastcall LoadFrame(int calc_id);
        bool __fastcall CanSave();
        double GetPremFullRur() {return PremiumRUR;};
        void __fastcall CalculateForPrint();
        void __fastcall CheckCalculateCalEn();
        double __fastcall GetKursCalEn(AnsiString, TDateTime);
        bool __fastcall CheckCountryForPasport();
        bool __fastcall CheckDisableFr();   //true ���� ���� �������� ��������. ���� ������� ����.������� "���� ���" ��� ���� � estrana ������ �������.
        bool __fastcall CheckCountryShengentEnabledAddDay();
        bool __fastcall CheckCountryForTerr(int id_terr);
        bool __fastcall CheckCountryInclude(int id_country);   //� ������ ���� id ������.
        bool __fastcall TestInetConnect();

        void __fastcall WMMouseActivate(TWMMouseActivate param);
        void __fastcall WMSetCursor(TWMSetCursor param);
        void __fastcall DBGKey(WORD &Key);
        int __fastcall CheckAgeIns();
//        void __fastcall WrapCalcKAge(){
//          Calculate();
//        };
        void __fastcall CancelTripVisible(bool);
        void __fastcall InitializeTT();
        void __fastcall ShowWarning(bool);
        void __fastcall Displayf15DayShengen();
  IVZR174Module* m_IModule;
private:
  bool m_fInDBGridMousePos;
  bool m_fOutDBGridMouse;
  bool m_fDBGridMouseAct;
  bool m_flgChild5; //����������� ������� �� 5 ���. ��������.
  bool m_flgShowMessCurr; //����������� ������� �� 5 ���. ��������.
protected:
  bool getCountry_I(int &,char **);
  bool getSport_I(int &);
  bool getProfession_I(int &);
  bool getFree_I(double &);
  bool getCountIns_I(int &);
  bool getAge_I(bool &, int &);
  void getStudProg_I(bool &, bool &);

BEGIN_MESSAGE_MAP
  VCL_MESSAGE_HANDLER(WM_SETCURSOR, TWMSetCursor, WMSetCursor);
  VCL_MESSAGE_HANDLER(WM_MOUSEACTIVATE, TWMMouseActivate, WMMouseActivate);
END_MESSAGE_MAP(TFrame);

};

AnsiString TFrameCalc::DlgFileName(AnsiString ff)
{
  AnsiString sfn;
  TOpenDialog *od=new TOpenDialog(NULL);

  od->Filter = ff;
  if(!od->Execute())
  {
    delete od;
    return "";
  }
  sfn = od->FileName;
  delete od;

  return sfn;
}
//---------------------------------------------------------------------------
extern PACKAGE TFrameCalc *FrameCalc;
//---------------------------------------------------------------------------

#endif
