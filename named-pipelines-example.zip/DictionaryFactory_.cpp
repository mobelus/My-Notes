//---------------------------------------------------------------------------
#pragma hdrstop

#include "DictionaryFactory_.h"
//---------------------------------------------------------------------------

#pragma package(smart_init)

//---------------------------------------------------------------------------
void __fastcall TDictionary::Load()
{
        int lRes;

        TADOQuery* qw = l_api->dbGetCursor(lRes, fSelectQuery, false);
        m_api->dbExecuteQuery(lRes, "delete from " + fTableName);

        InsertInTable(qw);
}
//---------------------------------------------------------------------------
TDictionary* __fastcall GetDictionary(AnsiString aBrief, mops_api_008* aMainAPI)
{
        int lRes;
        TDictionaryFactory* lFactory;

        if (aMainAPI->dbGetCurrentProduct(lRes) == "���_174")
        {
                 lFactory = new TVZR174DictFactory();
        }
        else
        {
                return NULL;
        }

        return (TDictionary*)lFactory->GetDictionary_(aBrief, aMainAPI);
}
//---------------------------------------------------------------------------
TDictionary* __fastcall TVZR174DictFactory::GetDictionary_(AnsiString aBrief, mops_api_008* aMainAPI)
{
        if (aBrief=="4.1.4")
        {
                return (TDictionary*) new TVZR174_Dict_4_1_4(aMainAPI);
        }
        else if (aBrief=="4.1.3")
        {
                return (TDictionary*) new TVZR174_Dict_4_1_3(aMainAPI);
        }
        else
        {
                return NULL;
        }
}
//---------------------------------------------------------------------------
__fastcall TVZR174_Dict_4_1_4::TVZR174_Dict_4_1_4(mops_api_008* aMainAPI)
{
        int lRes;
        m_api = aMainAPI;
        l_api = m_api->glDic_Get_SKK_API(lRes);

        fSelectQuery = "select * from RGSSCC_META.REF_SUBJECT_rf";
        fTableName = "vzr174Pr_R_REF_SUBJECT_RF";
}

//---------------------------------------------------------------------------
void __fastcall TVZR174_Dict_4_1_4::InsertInTable(TADOQuery* aQuery)
{
        int lRes;
        for(aQuery->First(); !aQuery->Eof; aQuery->Next())
        {

                m_api->dbExecuteQuery(lRes, "insert into " + fTableName + " (id,subject_federation_code, subject_federation_name) values (" +
                                                         aQuery->FieldByName("id")->AsString + ","
                                                        "'" + m_api->Internal_Prepare_SQL_Text(lRes,aQuery->FieldByName("subject_federation_code")->AsString) + "',"
                                                        "'" + m_api->Internal_Prepare_SQL_Text(lRes,aQuery->FieldByName("subject_federation_name")->AsString) + "'"
                                                        ")");
        }
}

__fastcall TVZR174_Dict_4_1_3::TVZR174_Dict_4_1_3(mops_api_008* aMainAPI)
{
        int lRes;
        m_api = aMainAPI;
        l_api = m_api->glDic_Get_SKK_API(lRes);

        fSelectQuery = "select * from RGSSCC_META.REF_FEDERAL_DISTRICT";
        fTableName = "vzr174Pr_R_REF_FEDERAL_DISTRICT";
}


void __fastcall TVZR174_Dict_4_1_3::InsertInTable(TADOQuery* aQuery)
{
        int lRes;
        for(aQuery->First(); !aQuery->Eof; aQuery->Next())
        {

                m_api->dbExecuteQuery(lRes, "insert into " + fTableName + " (id,federal_district_code, federal_district_name) values (" +
                                                         aQuery->FieldByName("id")->AsString + ","
                                                        "'" + m_api->Internal_Prepare_SQL_Text(lRes,aQuery->FieldByName("federal_district_code")->AsString) + "',"
                                                        "'" + m_api->Internal_Prepare_SQL_Text(lRes,aQuery->FieldByName("federal_district_name")->AsString) + "'"
                                                        ")");
        }
}





