//---------------------------------------------------------------------------

#ifndef PolisForm1xMulti_H
#define PolisForm1xMulti_H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include <QRCtrls.hpp>
#include <QuickRpt.hpp>
#include "Tmops_api.h"
#include "Constants.h"
#include "FDopList3x1.h"
#include "FDopList3x2.h"

#include "Graphics.hpp"
#include "dxGDIPlusClasses.hpp"
//---------------------------------------------------------------------------
class TPolisForm1xMulti : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *qrPolis;
        TQRBand *TitleBand1;
        TQRImage *qrimgHead;
        TQRImage *qrimgTable;
        TQRLabel *qrlbHolder;
        TQRLabel *qrlbBirthday;
        TQRLabel *qrlbTel;
        TQRLabel *qrlbAddress;
        TQRLabel *qrlbStartDate_dd;
        TQRLabel *qrlbEndDate_dd;
        TQRLabel *qrlbDays;
        TQRLabel *qrlbPersonBirthday1;
        TQRLabel *qrlbPerson1;
        TQRLabel *qrlbTerritory;
        TQRLabel *qrlbCode;
        TQRLabel *qrlbMainSumm;
        TQRLabel *qrlbMainFranchise;
        TQRLabel *qrlbMainPremium;
        TQRLabel *qrlbLossBagSumm;
        TQRLabel *qrlbLossBagFranchise;
        TQRLabel *qrlbLossBagPremium;
        TQRLabel *qrlbCancelTripPremium;
        TQRLabel *qrlbCivilLiabilityPremium;
        TQRLabel *qrlbAccidentPremium;
        TQRLabel *qrlbAccidentFranchise;
        TQRLabel *qrlbCivilLiabilityFranchise;
        TQRLabel *qrlbCancelTripFranchise;
        TQRLabel *qrlbCancelTripSumm;
        TQRLabel *qrlbCivilLiabilitySumm;
        TQRLabel *qrlbAccidentSumm;
        TQRLabel *cbSport;
        TQRLabel *cbAge;
        TQRLabel *cbProf;
        TQRLabel *cbOther;
        TQRLabel *qrlbTotalPremium;
        TQRLabel *qrlbPlace;
        TQRLabel *qrlbIssueDate;
        TQRLabel *qrlbDovNum;
        TQRLabel *qrlbDovDateDD;
        TQRLabel *qrlbDovDateMMMM;
        TQRLabel *qrlbDovDateYYYY;
        TQRLabel *qrlbDogNum;
        TQRLabel *qrlbDogDateDD;
        TQRLabel *qrlbDogDateMMMM;
        TQRLabel *qrlbDogDateYYYY;
        TQRLabel *qrlbPhysicalDate;
        TQRLabel *qrlbPredstDate;
        TQRLabel *qrlbPredstFIO;
        TQRLabel *qrlbPhysicalFIO;
        TQRLabel *qrlLossBagCode;
        TQRLabel *QRLabel2;
        TQRLabel *qrlCancelTripCode;
        TQRLabel *QRLabel4;
        TQRLabel *qrlCivilLiabilityCode;
        TQRLabel *QRLabel6;
        TQRLabel *qrlAccidentCode;
        TQRLabel *QRLabel8;
        TQRLabel *qrlMainRules;
        TQRLabel *qrlLossBagRules;
        TQRLabel *qrlCancelTripRules;
        TQRLabel *qrlCivilLiabilityRules;
        TQRLabel *qrlAccidentRules;
        TQRLabel *qrlbPerson2;
        TQRLabel *qrlbPerson3;
        TQRLabel *qrlbPerson4;
        TQRLabel *qrlbPersonBirthday2;
        TQRLabel *qrlbPersonBirthday3;
        TQRLabel *qrlbPersonBirthday4;
        TQRLabel *QRLabel1;
        TQRLabel *lbSpecsial;
        TQRImage *mqrimgGVA;
        TQRImage *QRIFPers;
        TQRImage *QRIPechat;
        TQRImage *QRITextPechat;
        TQRLabel *QRLTextPechat;
        TQRImage *QRIBottonTab;
        TQRLabel *LPeriodStart_dd;
        TQRLabel *LPeriodStart_mm;
        TQRLabel *LPeriodStart_yy;
        TQRLabel *LPeriodEnd_dd;
        TQRLabel *LPeriodEnd_mm;
        TQRLabel *LPeriodEnd_yy;
        TQRImage *QRUFPers;
        TQRLabel *qrlbStartDate_mm;
        TQRLabel *qrlbStartDate_yy;
        TQRLabel *qrlbEndDate_mm;
        TQRLabel *qrlbEndDate_yy;
        TQRImage *mqrimgAcc;

private:
  TQRImage *mqrimg;
  TQRImage *mPersType;
  bool m_fPechat;
  inline void mov_note(){

    int d = QRITextPechat->Height;

    QRITextPechat->Enabled = m_fPechat;
    QRLTextPechat->Enabled = m_fPechat;
    QRIBottonTab->Top += d;
    qrlbDovNum->Top += d;
    qrlbDovDateDD->Top += d;
    qrlbDovDateMMMM->Top += d;
    qrlbDovDateYYYY->Top += d;

    qrlbDogNum->Top += d;
    qrlbDogDateDD->Top += d;
    qrlbDogDateMMMM->Top += d;
    qrlbDogDateYYYY->Top += d;

    qrlbPhysicalFIO->Top += d;
    qrlbPhysicalDate->Top += d;
    qrlbPredstFIO->Top += d;
    qrlbPredstDate->Top += d;

   

  }
public:
  mops_api_007* m_api;

  __fastcall TPolisForm1xMulti(TComponent* Owner);
  __fastcall TPolisForm1xMulti(TComponent* Owner, bool fPechat, bool fAcc);

  void __fastcall  PrintPolis(long calc_id,bool preview, bool blank, int idIns);
  void __fastcall  print_report(bool preview, bool blank);
};
//---------------------------------------------------------------------------
extern PACKAGE TPolisForm1xMulti *PolisForm1xMulti;
//---------------------------------------------------------------------------
#endif
