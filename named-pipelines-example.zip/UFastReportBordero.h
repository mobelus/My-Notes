//---------------------------------------------------------------------------

#ifndef UFastReportBorderoH
#define UFastReportBorderoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "frxClass.hpp"
#include "frxCross.hpp"
#include "frxDesgn.hpp"
#include "frxDBSet.hpp"
#include "frxChBox.hpp"
#include "frxDCtrl.hpp"
#include "frxDMPExport.hpp"
#include "frxGradient.hpp"
//---------------------------------------------------------------------------
class TFFastReportBordero : public TForm
{
__published:	// IDE-managed Components
        TfrxReport *frxReport1;
        TfrxCrossObject *frxCrossObject1;
        TfrxDBDataset *frxDBDataset1;
        TfrxDotMatrixExport *frxDotMatrixExport1;
        TfrxCheckBoxObject *frxCheckBoxObject1;
        TfrxGradientObject *frxGradientObject1;
        TfrxDialogControls *frxDialogControls1;
private:	// User declarations
public:		// User declarations
        __fastcall TFFastReportBordero(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFFastReportBordero *FFastReportBordero;
//---------------------------------------------------------------------------
#endif
