//---------------------------------------------------------------------------

#ifndef UPartnerH
#define UPartnerH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sLabel.hpp"
#include "sGroupBox.hpp"
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "TMops_api.h"
#include "sComboBox.hpp"
//---------------------------------------------------------------------------
class TFPartner : public TForm
{
__published:	// IDE-managed Components
        TsLabel *sLabel1;
        TsRadioGroup *sRadioGroup1;
        TsBitBtn *sBitBtn1;
  TsComboBox *sCBSpec;
        void __fastcall sBitBtn1Click(TObject *Sender);
private:	// User declarations
        int res;
        TWndMethod OldFormWP;
        void __fastcall NewFormWP(TMessage &Msg);
        mops_api_018 *m_api;
      void TWndMethod(TMessage &Message);
public:		// User declarations
        __fastcall TFPartner(TComponent* Owner,mops_api_018 *m_api);


};
//---------------------------------------------------------------------------
extern PACKAGE TFPartner *FPartner;
//---------------------------------------------------------------------------
#endif
