//---------------------------------------------------------------------------

#ifndef FChPrintPolisH
#define FChPrintPolisH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sAlphaListBox.hpp"
#include "sCheckListBox.hpp"
#include "sSpeedButton.hpp"
#include <Buttons.hpp>
#include "sButton.hpp"
//---------------------------------------------------------------------------
class TForm4 : public TForm
{
__published:	// IDE-managed Components
  TsCheckListBox *sCheckListBox1;
  TsButton *sButton1;
  void __fastcall sCheckListBox1ClickCheck(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TForm4(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm4 *Form4;
//---------------------------------------------------------------------------
#endif

