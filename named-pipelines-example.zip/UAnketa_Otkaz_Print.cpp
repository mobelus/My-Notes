//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UAnketa_Otkaz_Print.h"
#include "Word.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sAlphaListBox"
#pragma link "sCheckListBox"
#pragma link "sLabel"
#pragma link "sCheckBox"
#pragma link "sBitBtn"
#pragma link "sCustomComboEdit"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma link "CGAUGES"
#pragma link "sGauge"
#pragma link "sGroupBox"
#pragma link "frxClass"
#pragma link "frxDBSet"
#pragma resource "*.dfm"
TFAnketa_Otkaz_Print *FAnketa_Otkaz_Print;
//---------------------------------------------------------------------------
__fastcall TFAnketa_Otkaz_Print::TFAnketa_Otkaz_Print(TComponent* Owner)
        : TForm(Owner)
{
  m_freport = E_WORD;
}

__fastcall TFAnketa_Otkaz_Print::TFAnketa_Otkaz_Print(TComponent* Owner, TEREPORT rep)
        : TForm(Owner)
{
  m_freport = rep;
}
//---------------------------------------------------------------------------
void  __fastcall TFAnketa_Otkaz_Print::PrepareFields(long id_calc,bool PreViewFlag)
{

sRadioGroup1->ItemIndex=PreViewFlag;

this->id_calc=id_calc;
int res;
TADOQuery *qw=m_api->dbGetCursor(res,"select id_zastr, fio from vzr_zastr where calc_id="+IntToStr(id_calc));
sCheckListBox1->Clear();
for(int i=0; i<qw->RecordCount;i++)
{
  sCheckListBox1->Items->AddObject( qw->FieldByName("fio")->AsString,(TObject*)qw->FieldByName("id_zastr")->AsInteger);
  sCheckListBox1->Checked[sCheckListBox1->Count-1]=true;
  qw->Next();
}

TDateTime data_zayavl=m_api->dbGetDateTimeFromQuery(res,"select data_zayavl from vzr_calc where calc_id=" + IntToStr(id_calc));
sDateEdit1->Date=data_zayavl;
sDateEdit2->Date=data_zayavl;

}
//---------------------------------------------------------------------------
void __fastcall TFAnketa_Otkaz_Print::sBitBtn1Click(TObject *Sender)
{
//--����������� �������
int res;
TADOQuery *qw;
mops_api_007 *m_api2 = (mops_api_007*)m_api;

if(m_freport == E_FAST_REPORT)
{
  int j = 0;
  long id_file = m_api2->Internal_Get_Additional_File_Id_By_Name("ank_otkaz_fr");
  AnsiString file_name = m_api2->dbGetFileNameInStore(res, id_file);
  m_api->dbSaveFileFromStore(res, id_file, m_api->Excel_tmp_path);
  m_qfr = "SELECT vzr_zastr.*, vzr_calc.strach_fio, vzr_calc.predst_name, vzr_calc.data_zayavl FROM vzr_zastr INNER JOIN vzr_calc ON  vzr_calc.calc_id = vzr_zastr.calc_id WHERE ";
  for(int i=0; i<sCheckListBox1->Items->Count;i++)
  {
    if(sCheckListBox1->Checked[i])
    {
      j++;
      if(j != 1)
        m_qfr += " OR ";
      m_qfr += "vzr_zastr.id_zastr = " + IntToStr((int)sCheckListBox1->Items->Objects[i]);
    }
  }
  m_qfr += ";";

  Close();
  return;
}
long id_file=m_api2->Internal_Get_Additional_File_Id_By_Name("ank_okaz");
AnsiString file_name=m_api2->dbGetFileNameInStore(res,id_file);
m_api->dbSaveFileFromStore(res,id_file,m_api->Excel_tmp_path);

Wrd *w=new Wrd();
sGauge1->Progress=0;
sGauge1->MinValue=0;

int j=0;
for(int i=0; i<sCheckListBox1->Items->Count;i++)
if(sCheckListBox1->Checked[i]) j++;
sGauge1->MaxValue=j;
sGauge1->Visible=true;
sRadioGroup1->Visible=false;
Application->ProcessMessages();
for(int i=0; i<sCheckListBox1->Items->Count;i++)
{
       if(sCheckListBox1->Checked[i])
       {
        qw=m_api->dbGetCursor(res,"select * from vzr_zastr where id_zastr="+ IntToStr((int)sCheckListBox1->Items->Objects[i]));
        w->AddDocument((m_api->Excel_tmp_path+"\\"+file_name).c_str()); //��������� ������
        w->SetActiveDocument(1);
        w->SetTextToBookMark(qw->FieldByName("fio")->AsString.c_str(),"fio");
        w->SetTextToBookMark((qw->FieldByName("address")->AsString+ " " +qw->FieldByName("tel")->AsString).c_str(),"addr_tel");
        w->SetTextToBookMark(("����� " + qw->FieldByName("pasport_ser")->AsString+ " ����� " +qw->FieldByName("pasport_num")->AsString).c_str(),"pasport_data");
        w->SetTextToBookMark(qw->FieldByName("pasport_data_vidachi")->AsString.c_str(),"data_vidachi");
        w->SetTextToBookMark(qw->FieldByName("pasport_deystv_do")->AsString.c_str(),"deystv_do");
        w->SetTextToBookMark(qw->FieldByName("dr")->AsString.c_str(),"data_rogd");
        w->SetTextToBookMark(qw->FieldByName("pasport_gragdanstvo")->AsString.c_str(),"gragdanstvo");
        w->SetTextToBookMark(qw->FieldByName("mesto_raboti")->AsString.c_str(),"mesto_raboti");
        w->SetTextToBookMark(qw->FieldByName("strani_viezda")->AsString.c_str(),"strani_viezda");
        w->SetTextToBookMark((qw->FieldByName("turist_firma")->AsString + " � " + qw->FieldByName("num_dogovor")->AsString + " �� " + qw->FieldByName("date_dogovor")->AsString).c_str(),"tur_firma_num_dog");
        w->SetTextToBookMark(qw->FieldByName("start_data_poezdki")->AsString.c_str(),"start_data_p");
        w->SetTextToBookMark(qw->FieldByName("end_data_poezdki")->AsString.c_str(),"end_data_p");
        AnsiString tmp="";
        if(qw->FieldByName("chron_zabolevan_yes")->AsBoolean) tmp="��, " + qw->FieldByName("chron_zabolevan")->AsString;
        else tmp="���";
        w->SetTextToBookMark(tmp.c_str(),"chron_zabol");
        if(qw->FieldByName("beremennost_yes")->AsBoolean) tmp="��, " + qw->FieldByName("beremennost")->AsString;
        else tmp="���";
        w->SetTextToBookMark(tmp.c_str(),"berem");

        if(qw->FieldByName("rodstv_v_stacionare_yes")->AsBoolean) tmp="��, " + qw->FieldByName("rodstv_v_stacionare")->AsString;
        else tmp="���";
        w->SetTextToBookMark(tmp.c_str(),"stacionar");
        w->SetTextToBookMark(qw->FieldByName("otkaz_v_vise_yes")->AsBoolean?"��":"���","otkaz");
        w->SetTextToBookMark(qw->FieldByName("otkaz_v_stranu")->AsString.c_str(),"otkaz_v_stranu");
        w->SetTextToBookMark(qw->FieldByName("otmetki_v_deystv_pasporte_yes")->AsBoolean?"��":"���","otmetki_o_viz_v_deystv");
        w->SetTextToBookMark(qw->FieldByName("otmetki_v_starom_pasporte_yes")->AsBoolean?"��":"���","otmetki_o_viz_v_starom");
        w->SetTextToBookMark(qw->FieldByName("zakl_dogovor_yes")->AsBoolean?"��":"���","analog_risk");
        w->SetTextToBookMark(qw->FieldByName("obrasch_za_vozmecheniem_yes")->AsBoolean?("��, "+qw->FieldByName("obrasch_za_vozmecheniem")->AsString).c_str():"���","obrach_za_vozm");
        w->SetTextToBookMark(qw->FieldByName("stoimost_poezdki")->AsString.c_str(),"stoimost_poezdki");
        tmp=sDateEdit1->Date.FormatString("dd")+tmp.StringOfChar(' ',2);
        w->SetTextToBookMark(tmp.c_str() ,"chislo_data_str");
        tmp=sDateEdit1->Date.FormatString("mmmm");
        tmp=tmp+tmp.StringOfChar(' ',27-tmp.Length()*2);
        w->SetTextToBookMark(tmp.c_str(),"mes_data_str");
        w->SetTextToBookMark(sDateEdit1->Date.FormatString("yy").c_str(),"god_data_str");
        w->SetTextToBookMark(m_api->dbGetStringFromQuery(res,"select strach_fio from vzr_calc where calc_id="+ IntToStr(id_calc)).c_str(),"fio_strach");
        w->SetTextToBookMark(qw->FieldByName("reshenie_strachovshika")->AsString.c_str(),"reshenie_strachovshika");
        tmp=sDateEdit2->Date.FormatString("dd")+tmp.StringOfChar(' ',2);
        w->SetTextToBookMark(tmp.c_str(),"chislo_resh");
        tmp=sDateEdit2->Date.FormatString("mmmm");
        tmp=tmp+tmp.StringOfChar(' ',27-tmp.Length()*2);
        w->SetTextToBookMark(tmp.c_str(),"mes_resh");
        w->SetTextToBookMark(sDateEdit2->Date.FormatString("yy").c_str(),"god_resh");
        w->SetTextToBookMark(m_api->dbGetStringFromQuery(res,"select predst_name from vzr_calc where calc_id="+ IntToStr(id_calc)).c_str(),"fio_strachovshika");
        if(sRadioGroup1->ItemIndex==0) w->Print();
        sGauge1->Progress++;
     }
}

sGauge1->Visible=false;
sRadioGroup1->Visible=true;
Application->ProcessMessages();
if(sRadioGroup1->ItemIndex==0) {w->Close();}
else w->Show();
w->Free();
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_Otkaz_Print::sBitBtn2Click(TObject *Sender)
{
Close();
}
//---------------------------------------------------------------------------

AnsiString __fastcall TFAnketa_Otkaz_Print::GetQuery2FastReport()
{
  if(!m_qfr.IsEmpty())
      return m_qfr;

  return AnsiString("");
}
