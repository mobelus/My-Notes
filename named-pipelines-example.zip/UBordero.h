//---------------------------------------------------------------------------

#ifndef UBorderoH
#define UBorderoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sBitBtn.hpp"
#include "sPanel.hpp"
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "Tmops_api.h"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sComboBox.hpp"
#include "sGroupBox.hpp"
//---------------------------------------------------------------------------
class TFBordero : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsPanel *sPanel2;
        TsBitBtn *sBitBtn1;
        TsDateEdit *sDateEdit1;
        TsLabel *sLabel4;
        TsEdit *sEdit1;
        TsLabel *sLabel5;
        TsBitBtn *sBitBtn2;
        TLabel *Label2;
        TEdit *eTel;
        TsComboBox *cbUser;
        TLabel *Label1;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
private:	// User declarations
  bool m_frep;
  AnsiString m_qfr;

  AnsiString __fastcall CreateQuery2FastReport();
public:		// User declarations
        __fastcall TFBordero(TComponent* Owner);
        __fastcall TFBordero(TComponent* Owner, bool frep);
         mops_api_007* m_api;
         void PrepareFields();
         bool PreView;
         AnsiString  __fastcall GetQuery2FastReport();
};
//---------------------------------------------------------------------------
extern PACKAGE TFBordero *FBordero;
//---------------------------------------------------------------------------
#endif
