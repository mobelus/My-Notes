//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PolisForm1xMulti.h"
#include "windows.h"
#include "wingdi.h"
#include "jpeg.hpp"
#include <DateUtils.hpp>
#include <SysUtils.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxGDIPlusClasses"
#pragma resource "*.dfm"

TPolisForm1xMulti *PolisForm1xMulti;

AnsiString MonthToStr(AnsiString m)
{
       if((m == "������") || (m == "�������") || (m == "������") || (m == "���") ||
       (m == "����") || (m == "����") || (m == "��������") ||
       (m == "�������") || (m == "������") || (m == "�������")){
               int l = m.Length();
               m = m.Insert("�", l);
               m.SetLength(l);
      }
       else if ((m == "����") || (m == "������"))
               m += "�";

       return m;
}
//---------------------------------------------------------------------------
__fastcall TPolisForm1xMulti::TPolisForm1xMulti(TComponent* Owner)
        : TForm(Owner)
{
    mqrimg = NULL;
    QRIPechat->Enabled = false;


}

__fastcall TPolisForm1xMulti::TPolisForm1xMulti(TComponent* Owner, bool fPechat, bool fAcc)
        : TForm(Owner), m_fPechat(fPechat)
{
    if(fAcc){
      mqrimg = mqrimgAcc;
      mqrimgAcc->Enabled = true;
    }
    else{
      mqrimg = mqrimgGVA;
      mqrimgGVA->Enabled = true;
    }



    if(m_fPechat)
      mov_note();

}
//---------------------------------------------------------------------------
void __fastcall  TPolisForm1xMulti::PrintPolis(long calc_id, bool preview, bool blank, int idIns)
{

    mqrimgAcc->Top=QRIBottonTab->Top + QRIBottonTab->Height-4;
    mqrimgGVA->Top=QRIBottonTab->Top + QRIBottonTab->Height-4;

        AnsiString
          Premia =      "",
          FIO_Insurer=  "";
        lbSpecsial->Caption = "";
        qrimgHead->Enabled   = !blank;
        if(mqrimg){
          //mqrimg->Enabled = !blank;
          //mqrimg->Top = 687;
          //mqrimg->Left = 3;
        }

        AnsiString Currency="";
        int res;
        TADOQuery *qw = m_api->dbGetCursor(res, "select c.* "
                                                "  from vzr174Pr_calc c"
                                           " where calc_id=" + IntToStr(calc_id));

        if(qw->RecordCount<=0)
        {
                return;
        }

        Currency=qw->FieldByName("CurrencyName")->AsString;

        if (qw->FieldByName("strach_fiz_yur")->AsString=="���������� ����")
        {
                qrlbHolder       ->Caption = qw->FieldByName("strach_fio")->AsString;
                qrlbBirthday     ->Caption = qw->FieldByName("strach_dr")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("strach_dr")->AsString;
                qrlbAddress      ->Caption = qw->FieldByName("strach_address")->AsString;
                qrlbTel          ->Caption = qw->FieldByName("strach_tel")->AsString;
                qrlbPhysicalFIO  ->Caption = qw->FieldByName("strach_fio")->AsString;
                qrlbPhysicalDate ->Caption = FormatDateTime("dd.mm.yyyy",qw->FieldByName("data_zayavl")->AsDateTime);
                mPersType = QRIFPers;
        }
        else
        {
                qrlbHolder        ->Caption = qw->FieldByName("strach_yur_naimen")->AsString;
                qrlbAddress       ->Caption = qw->FieldByName("strach_yur_address")->AsString;
                qrlbTel           ->Caption = qw->FieldByName("strach_yur_tel")->AsString;
                qrlbPhysicalFIO   ->Caption = qw->FieldByName("strach_yur_contact")->AsString;
                qrlbPhysicalDate  ->Caption =  FormatDateTime("dd.mm.yyyy",qw->FieldByName("data_zayavl")->AsDateTime);
                mPersType = QRUFPers;
        }




        int nAddDay = m_api->dbGetIntFromQuery(res,"select nAddDay from vzr174Pr_calc where calc_id = " + IntToStr(calc_id));
        TDateTime tdPolis;
        if(qw->FieldByName("str_polis_start_data")->AsDateTime!=(TDateTime)NULL)
        {       tdPolis = qw->FieldByName("str_polis_start_data")->AsDateTime;
                qrlbStartDate_dd ->Caption = tdPolis.FormatString("dd");
                qrlbStartDate_mm ->Caption = MonthToStr(tdPolis.FormatString("mm"));
                qrlbStartDate_yy ->Caption = tdPolis.FormatString("yy");
        }
        if(qw->FieldByName("str_polis_end_data")->AsDateTime!=(TDateTime)NULL)
        {
                tdPolis = qw->FieldByName("str_polis_end_data")->AsDateTime;
                tdPolis = Dateutils::IncDay(tdPolis, nAddDay);
                qrlbEndDate_dd ->Caption = tdPolis.FormatString("dd");
                qrlbEndDate_mm ->Caption = MonthToStr(tdPolis.FormatString("mm"));
                qrlbEndDate_yy ->Caption = tdPolis.FormatString("yy");
        }
        if(qw->FieldByName("str_polis_start_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                LPeriodStart_dd ->Caption = qw->FieldByName("str_polis_start_dog_data")->AsDateTime.FormatString("dd");
                LPeriodStart_mm ->Caption = MonthToStr(qw->FieldByName("str_polis_start_dog_data")->AsDateTime.FormatString("mm"));
                LPeriodStart_yy ->Caption = qw->FieldByName("str_polis_start_dog_data")->AsDateTime.FormatString("yy");
        }
        if(qw->FieldByName("str_polis_end_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                LPeriodEnd_dd ->Caption = qw->FieldByName("str_polis_end_dog_data")->AsDateTime.FormatString("dd");
                LPeriodEnd_mm ->Caption = MonthToStr(qw->FieldByName("str_polis_end_dog_data")->AsDateTime.FormatString("mm"));
                LPeriodEnd_yy ->Caption = qw->FieldByName("str_polis_end_dog_data")->AsDateTime.FormatString("yy");
        }

        qrlbDays           ->Caption = qw->FieldByName("MainDays")->AsString;
//        qrlbPerson         ->Caption = qw->FieldByName("InsuredPersonFIO")->AsString;
//        qrlbPersonBirthday ->Caption = qw->FieldByName("InsuredPersonBirthday")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("InsuredPersonBirthday")->AsString;
        qrlbCode           ->Caption = qw->FieldByName("program")->AsString;
        AnsiString  sterr;
        sterr = qw->FieldByName("MainTerritory")->AsString;
        if(!qw->FieldByName("MainTerritory")->AsString.IsEmpty() && !qw->FieldByName("CountryReport")->AsString.IsEmpty())
          sterr += ",";
        sterr += qw->FieldByName("CountryReport")->AsString;
        qrlbTerritory      ->Caption = sterr;
        qrlbMainSumm    ->Caption =  qw->FieldByName("MainSumm")->AsString + " " +Currency ;
        if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
          qrlbMainPremium ->Caption = qw->FieldByName("MainPremium")->AsString + " " + Currency;
        qrlMainRules->Caption=qw->FieldByName("MainRules")->AsString;

        if (qw->FieldByName("MainFranchiseValue")->AsFloat>0)
                qrlbMainFranchise->Caption = FloatToStr(qw->FieldByName("MainFranchiseValue")->AsFloat) + " " + Currency;

        int lFlags = qw->FieldByName("RisksFlags")->AsInteger;

        if ((lFlags & VZRCALC_RISKSFLAG_LOSSBAG)>0)
        {
                this->qrlLossBagCode->Caption=qw->FieldByName("LossBagTransportTypeName")->AsString.SubString(1,1);
                qrlbLossBagSumm ->Caption=qw->FieldByName("LossBagSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbLossBagPremium ->Caption = qw->FieldByName("LossBagPremium")->AsString + " " + Currency;
                qrlLossBagRules->Caption=qw->FieldByName("LossBagRules")->AsString;
//��������� ��������.
//                qrlbLossBagFranchise->Caption=Trim(qw->FieldByName("LossBagTimeFranchiseName")->AsString);
                if (  qw->FieldByName("LossBagFranchiseValue")->AsFloat>0)
                        qrlbLossBagFranchise->Caption =qrlbLossBagFranchise->Caption+ "; "+ FloatToStr(m_api->Round(qw->FieldByName("LossBagFranchiseValue")->AsFloat *qw->FieldByName("LossBagSummValue")->AsFloat/100)) + " " + Currency;
//          if(qw->FieldByName("LossBagflagOpis")->AsBoolean)
//            lbSpecsial->Caption = "inventory of property (����� ���������).";
        }
        if ((lFlags & VZRCALC_RISKSFLAG_CANCELTRIP)>0)
        {
                qrlCancelTripRules->Caption=qw->FieldByName("CancelTripRules")->AsString;
                this->qrlCancelTripCode->Caption=qw->FieldByName("CancelTripTypeName")->AsString.SubString(1,1);
                qrlbCancelTripSumm    ->Caption = qw->FieldByName("CancelTripSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbCancelTripPremium ->Caption = qw->FieldByName("CancelTripPremium")->AsString + " " + Currency;
                if (qw->FieldByName("CancelTripFranchiseValue")->AsFloat>0)
                        qrlbCancelTripFranchise->Caption = FloatToStr(m_api->Round(qw->FieldByName("CancelTripFranchiseValue")->AsFloat *qw->FieldByName("CancelTripSummValue")->AsFloat /100)) + " " + Currency;
//          if(!lbSpecsial->Caption.IsEmpty())
//            lbSpecsial->Caption = lbSpecsial->Caption + ";";
//          lbSpecsial->Caption = lbSpecsial->Caption + " ����������� " + qw->FieldByName("CancelTripCivilText")->AsString;
        }
       if ((lFlags & VZRCALC_RISKSFLAG_CIVILLIABILITY)>0)
        {

                qrlCivilLiabilityRules->Caption=qw->FieldByName("CivilLiabilityRules")->AsString;
                this->qrlCivilLiabilityCode->Caption="F";//qw->FieldByName("")->AsString.SubString(1,1);
                qrlbCivilLiabilitySumm ->Caption =qw->FieldByName("CivilLiabilitySummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbCivilLiabilityPremium ->Caption = qw->FieldByName("CivilLiabilityPremium")->AsString + " " + Currency;
                if (qw->FieldByName("CivilLiabilityFranchiseValue")->AsFloat>0)
                        qrlbCivilLiabilityFranchise->Caption =FloatToStr(m_api->Round(qw->FieldByName("CivilLiabilitySummValue")->AsFloat*qw->FieldByName("CivilLiabilityFranchiseValue")->AsFloat/100)) + " "+ Currency;
        }
        if ((lFlags & VZRCALC_RISKSFLAG_ACCIDENT)>0)
        {
                qrlAccidentRules->Caption=qw->FieldByName("AccidentRules")->AsString;
                this->qrlAccidentCode->Caption=qw->FieldByName("AccidentTypeName")->AsString.SubString(1,10);
                qrlbAccidentSumm    ->Caption =qw->FieldByName("AccidentSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbAccidentPremium ->Caption = qw->FieldByName("AccidentPremium")->AsString + " " + Currency;
                if (qw->FieldByName("AccidentFranchiseValue")->AsFloat>0)
                        qrlbAccidentFranchise->Caption =FloatToStr(m_api->Round(qw->FieldByName("AccidentSummValue")->AsFloat* qw->FieldByName("AccidentFranchiseValue")->AsFloat/100))+ " " + Currency ;
        }



        if(qw->FieldByName("MainKoefFreeValue")->AsFloat!=1)
        cbOther->Caption = "v";

       if (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==2 ||
           (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==1))
                cbSport->Caption = "v";


//        if (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==1)
//                cbActive->Caption = "v";

        if (qw->FieldByName("MainKoefProfName")->AsString!="���")
                cbProf->Caption = "v";

        qrlbPlace     ->Caption = qw->FieldByName("mesto_vidachi")->AsString;
        qrlbIssueDate ->Caption = qw->FieldByName("data_zayavl")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("data_zayavl")->AsString;

        if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
          qrlbTotalPremium->Caption = Format("%s %s = %s ������", ARRAYOFCONST((qw->FieldByName("AllPremium")->AsString,
                                                                               qw->FieldByName("CurrencyName")->AsString,
                                                                               qw->FieldByName("AllPremiumRUR")->AsString)));

        qrlbDovNum ->Caption = qw->FieldByName("predst_dov_num")->AsString;
        if(qw->FieldByName("predst_dov_data")->AsDateTime!=(TDateTime)NULL)
        {
                qrlbDovDateDD   ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("dd");
                qrlbDovDateMMMM ->Caption = MonthToStr(qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("mm"));
                qrlbDovDateYYYY ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("yyyy");
        }

        qrlbDogNum->Caption=qw->FieldByName("predst_dog_num")->AsString;
        if(qw->FieldByName("predst_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                qrlbDogDateDD->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("dd");
                qrlbDogDateMMMM->Caption=MonthToStr(qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("mm"));
                qrlbDogDateYYYY->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("yyyy");
        }

       qrlbPredstFIO->Caption=qw->FieldByName("predst_name")->AsString;
       qrlbPredstDate->Caption=qw->FieldByName("data_zayavl")->AsString;

       // qrlbPersonFIO  ->Caption = qw->FieldByName("InsuredPersonFIO")->AsString;
       // qrlbPersonDate ->Caption = qw->FieldByName("data_zayavl")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("data_zayavl")->AsString;

 //�������������� ������.
  AnsiString stmp;
  long c_people = 0;

  if(m_api->dbGetLongFromQuery(res, stmp.sprintf("select count(*) from VZR174Pr_Insured where id_calc = %i and k_age <> 1", calc_id)))
    cbAge->Caption = "v";
  c_people = m_api->dbGetLongFromQuery(res, stmp.sprintf("select count(*) from VZR174Pr_Insured where id_calc = %i", calc_id));

 TADOQuery *qI = m_api->dbGetCursor(res, stmp.sprintf("select * from VZR174Pr_Insured where id_calc = %i", calc_id));
 if(res != 0)
 {
    MessageBox(NULL, "��� ������ �� ��������������", "������", MB_OK);
    return;
 }

//��� ������������ ����.
 if(qw->FieldByName("strach_fiz_yur")->AsString!="���������� ����" && (qw->FieldByName("fPrintOneIns")->AsBoolean == true)){
    qI->Locate("num",idIns,TLocateOptions()<<loCaseInsensitive);
    qI->UpdateCursorPos();
    if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
      qrlbTotalPremium->Caption = Format("%s %s = %s ������", ARRAYOFCONST((qI->FieldByName("premium")->AsString,
                                                                         qw->FieldByName("CurrencyName")->AsString,
                                                                         qI->FieldByName("premium_rur")->AsString)));
     qrlbPerson1->Caption         = qI->FieldByName("InsuredPersonFIO")->AsString;
     qrlbPersonBirthday1->Caption = qI->FieldByName("InsuredPersonBirthday")->AsDateTime == TDateTime()?AnsiString(""):qI->FieldByName("InsuredPersonBirthday")->AsString;
     AnsiString mess = "��� ��������������� : " + qI->FieldByName("InsuredPersonFIO")->AsString + ".\r\n������� � ������� �����: \r\n ����� " + qI->FieldByName("polis_ser")->AsString + " \r\n ����� "+qI->FieldByName("polis_num")->AsString;
     if(blank){
      if(MessageBox(NULL,mess.c_str(), "���������� ��� ������ �� ������.", MB_OKCANCEL) == mrOk){
        qI->Edit();
        qI->FieldByName("fPrinted")->AsBoolean = true;
        qI->Post();
      }
      else{
        m_api->dbCloseCursor(res, qI);
        return;
      }
     }
     print_report(preview, blank);
     m_api->dbCloseCursor(res, qI);
   return;
 }

 stmp = "";
 if(c_people <= 4)
 {
   int num = 1;
   TQRLabel *plb1 = NULL;
   TQRLabel *plb2 = NULL;

   qI->First();
   while(!qI->Eof)
   {
    stmp.sprintf("qrlbPerson%i", num);
    plb1 = (TQRLabel *)this->TitleBand1->FindChildControl(stmp);
    stmp.sprintf("qrlbPersonBirthday%i", num);
    plb2 = (TQRLabel *)this->TitleBand1->FindChildControl(stmp);
    plb1->Caption = qI->FieldByName("InsuredPersonFIO")->AsString;
    plb2->Caption = qI->FieldByName("InsuredPersonBirthday")->AsString=="31.12.1899"?AnsiString(""):qI->FieldByName("InsuredPersonBirthday")->AsString;
    qI->Next();
    num++;
   }
   print_report(preview, blank);
 }
 else if(c_people > 4)
 {
   //�����
   TQRLabel *plb1 = NULL;
   TQRLabel *plb2 = NULL;

    stmp.sprintf("qrlbPerson%i", 1);
    plb1 = (TQRLabel *)this->TitleBand1->FindChildControl(stmp);
    stmp.sprintf("qrlbPersonBirthday%i", 1);
    plb2 = (TQRLabel *)this->TitleBand1->FindChildControl(stmp);
    stmp.sprintf("%i �������, �������� ������������ ������", c_people);
    plb1->Caption = stmp;
    plb2->Caption = "-----------";
   for(int num = 2;num <= 4; num++)
   {
    stmp.sprintf("qrlbPerson%i", num);
    plb1 = (TQRLabel *)this->TitleBand1->FindChildControl(stmp);
    stmp.sprintf("qrlbPersonBirthday%i", num);
    plb2 = (TQRLabel *)this->TitleBand1->FindChildControl(stmp);
    plb1->Caption = "-----------";
    plb2->Caption = "-----------";
   }
   print_report(preview, blank);
   //���.��������
   int full_num = c_people / max_rec_1;
   if(full_num == 0)
   {
     if(c_people > max_rec_2)
     {
      //�����. �����.
      TFormDopList3x1 *ppr = new TFormDopList3x1(this, m_fPechat);
      qI->First();
      for(int page = 0; page <= full_num; page++)
      {
        ppr->QRLabel1->Caption = IntToStr(page + 2);
        ppr->QRLabel2->Caption = IntToStr(full_num);
        ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
        ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
        ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
        ppr->print(preview, blank);
      }
      delete ppr;
     }
      //����. �����.
      TFormDopList3x2 *ppr = new TFormDopList3x2(this, m_fPechat);
      ppr->QRLabel155->Caption = IntToStr(c_people);
      if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
      {
        ppr->QRLabel156->Caption = qw->FieldByName("AllPremium")->AsString;
        ppr->QRLabel157->Caption = qw->FieldByName("AllPremiumRUR")->AsString;
      }
      ppr->QRLabel1->Caption = IntToStr(full_num + 2);
      ppr->QRLabel2->Caption = IntToStr(full_num + 2);
      ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
      ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
      ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
      ppr->print(preview, blank);
      delete ppr;
   }
   else
   {
      //�����. �����.
      TFormDopList3x1 *ppr = new TFormDopList3x1(this, m_fPechat);
      qI->First();
      for(int page = 0; page < full_num; page++)
      {
        ppr->QRLabel1->Caption = IntToStr(page + 2);
        ppr->QRLabel2->Caption = IntToStr(full_num + 2);
        ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
        ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
        ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
        ppr->print(preview, blank);
      }
      delete ppr;
      long rem = c_people - (full_num * max_rec_1);
      if(rem > max_rec_2)
      {
        TFormDopList3x1 *ppr = new TFormDopList3x1(this, m_fPechat);
        ppr->QRLabel1->Caption = IntToStr(full_num + 2 - 1);
        ppr->QRLabel2->Caption = IntToStr(full_num + 2);
        ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
        ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
        ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
        ppr->print(preview, blank);
        delete ppr;
      }
      //����. �����.
      TFormDopList3x2 *ppr2 = new TFormDopList3x2(this, m_fPechat);
      ppr2->QRLabel155->Caption = IntToStr(c_people);
      if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
      {
        ppr2->QRLabel156->Caption = qw->FieldByName("AllPremium")->AsString;
        ppr2->QRLabel157->Caption = qw->FieldByName("AllPremiumRUR")->AsString;
      }
      ppr2->QRLabel1->Caption = IntToStr(full_num + 2);
      ppr2->QRLabel2->Caption = IntToStr(full_num + 2);
      ppr2->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
      ppr2->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
      ppr2->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
      ppr2->print(preview, blank);
      delete ppr2;
   }
 }
  m_api->dbCloseCursor(res, qI);
}
//---------------------------------------------------------------------------


void __fastcall TPolisForm1xMulti::print_report(bool preview, bool blank)
{
  qrimgHead->Enabled=!blank;

 //����������� ���.��. ����.
{
    TJPEGImage *jpg=new TJPEGImage();
    jpg->Assign(QRIBottonTab->Picture);
    Graphics::TBitmap *btmp=new Graphics::TBitmap();
    btmp->Assign(jpg);
    btmp->PixelFormat=pf32bit;

    Graphics::TBitmap *btmp2=new Graphics::TBitmap();
    TJPEGImage *jpg2=new TJPEGImage();
    jpg2->Assign(mPersType->Picture);
    SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
    btmp2->Assign(jpg2);
    btmp2->PixelFormat=pf32bit;
//  ::BitBlt(btmp->Canvas->Handle, 5, 5, 330, 62, btmp2->Canvas->Handle, 0, 0, SRCAND);
    ::StretchBlt(btmp->Canvas->Handle, 60, 20, btmp->Width/2 - 100, btmp->Height/2 + 40, btmp2->Canvas->Handle, 0, 0, btmp2->Width, btmp2->Height, SRCAND);
    jpg->Assign(btmp);
    QRIBottonTab->Picture->Assign(jpg);
    delete jpg;
    delete jpg2;
    delete btmp;
    delete btmp2;
}

  //����������� ������. 1-�����
  QRIPechat->Enabled = false;
  if(m_fPechat){
    TJPEGImage *jpg=new TJPEGImage();
    jpg->Assign(QRIBottonTab->Picture);
    Graphics::TBitmap *btmp=new Graphics::TBitmap();
    btmp->Assign(jpg);
    btmp->PixelFormat=pf32bit;

    Graphics::TBitmap *btmp2=new Graphics::TBitmap();
    TJPEGImage *jpg2=new TJPEGImage();
    jpg2->Assign(QRIPechat->Picture);
    SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
    btmp2->Assign(jpg2);
    btmp2->PixelFormat=pf32bit;

//   ::BitBlt(btmp->Canvas->Handle, 100, 0, btmp->Width, btmp->Height,btmp2->Canvas->Handle, 0, 0, SRCAND);
    ::StretchBlt(btmp->Canvas->Handle,

        btmp->Width - 741,
        btmp->Height - btmp2->Height - 160,
        btmp2->Width + 287,
        btmp2->Height + 160,

        btmp2->Canvas->Handle, 0, 0, btmp2->Width, 2*btmp2->Height/3 + 10, SRCAND);

    jpg->Assign(btmp);
    QRIBottonTab->Picture->Assign(jpg);

    delete jpg;
    delete jpg2;
    delete btmp;
    delete btmp2;

  //����������� ������. 2-�����
    jpg = new TJPEGImage();
    btmp = new Graphics::TBitmap();
    jpg->Assign(mqrimg->Picture);
    btmp->Assign(jpg);
    if(blank){
      btmp->Canvas->Brush->Color = (TColor)RGB(255,255,255);
      TRect rc(0, 0, btmp->Width, btmp->Height);
      btmp->Canvas->FillRect(rc);
    }

      btmp->PixelFormat=pf32bit;
       btmp2=new Graphics::TBitmap();
      jpg2=new TJPEGImage();
      jpg2->Assign(QRIPechat->Picture);
      SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
      btmp2->Assign(jpg2);
      btmp2->PixelFormat=pf32bit;

  //   ::BitBlt(btmp->Canvas->Handle, 100, 0, btmp->Width, btmp->Height,btmp2->Canvas->Handle, 0, 0, SRCAND);
      ::StretchBlt(btmp->Canvas->Handle,

          btmp->Width - btmp2->Width - 382,
          0,
          btmp2->Width + 215,
          btmp2->Height/3 + 80,

          btmp2->Canvas->Handle, 0, 2*btmp2->Height/3, btmp2->Width, btmp2->Height/3, SRCAND);

      jpg->Assign(btmp);
      mqrimg->Picture->Assign(jpg);

      delete jpg;
      delete jpg2;
      delete btmp;
      delete btmp2;
  }
  else
    if(mqrimg)
      mqrimg->Enabled=!blank;




        if(!blank)
        {
         //�������� ����� "�������"
         TJPEGImage *jpg=new TJPEGImage();
         jpg->Assign(qrimgTable->Picture);
         Graphics::TBitmap *btmp2=new Graphics::TBitmap();
         Graphics::TBitmap *btmp=new Graphics::TBitmap();
         btmp->Assign(jpg);
         btmp2->Assign(jpg);
         btmp->PixelFormat=pf32bit;
         btmp2->PixelFormat=pf32bit;
         SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
         HFONT font = CreateFont(-1000,          // ������ ������
                   250,                          // ������ ����������
                   230,                         // ���� ��������
                   0,                           // ���� �����������
                   FW_BOLD,                     // ������ ������
                   TRUE,                        // ������
                   FALSE,                       // �������������
                   FALSE,                       // ��������������
                   DEFAULT_CHARSET ,
                   OUT_TT_PRECIS,               // �������� ������
                   CLIP_DEFAULT_PRECIS,         // �������� ���������
                   ANTIALIASED_QUALITY,         // �������� ������
                   FF_DONTCARE|DEFAULT_PITCH,   // ��������� � ���
                   "Times New Roman");          // ��� ������
         btmp2->Canvas->Font->Handle=font;
         btmp2->Canvas->Font->Color=(TColor)RGB(255,0,0);
         btmp2->Canvas->TextOut(-20,200,"�������");

         TBlendFunction Blend;
         Blend.BlendOp=AC_SRC_OVER;
         Blend.BlendFlags = 0;
         Blend.SourceConstantAlpha = 90;       // ������������ 50% (0 - 255)
         Blend.AlphaFormat =0;//AC_SRC_ALPHA;   // ���� = 0 (������ ��������)
         ::AlphaBlend(btmp->Canvas->Handle, 0, 0, btmp->Width, btmp->Height,btmp2->Canvas->Handle, 0, 0, btmp->Width, btmp->Height, Blend);
         jpg->Assign(btmp);
         qrimgTable->Picture->Assign(jpg);
        delete jpg;
        delete btmp;
        delete btmp2;
        }


        if(mqrimg && !blank)
        {
         //�������� ����� "�������"
         TJPEGImage *jpg=new TJPEGImage();
         jpg->Assign(mqrimg->Picture);
         Graphics::TBitmap *btmp2=new Graphics::TBitmap();
         Graphics::TBitmap *btmp=new Graphics::TBitmap();
         btmp->Assign(jpg);
         btmp2->Assign(jpg);
         btmp->PixelFormat=pf32bit;
         btmp2->PixelFormat=pf32bit;
         SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
         HFONT font = CreateFont(-150,          // ������ ������
                   130,                         // ������ ����������
                   230,                         // ���� ��������
                   0,                           // ���� �����������
                   FW_BOLD,                     // ������ ������
                   TRUE,                        // ������
                   FALSE,                       // �������������
                   FALSE,                       // ��������������
                   DEFAULT_CHARSET ,
                   OUT_TT_PRECIS,               // �������� ������
                   CLIP_DEFAULT_PRECIS,         // �������� ���������
                   ANTIALIASED_QUALITY,         // �������� ������
                   FF_DONTCARE|DEFAULT_PITCH,   // ��������� � ���
                   "Times New Roman");          // ��� ������
         btmp2->Canvas->Font->Handle=font;
         btmp2->Canvas->Font->Color=(TColor)RGB(255,0,0);
         btmp2->Canvas->TextOut(50,750,"�������");

         TBlendFunction Blend;
         Blend.BlendOp=AC_SRC_OVER;
                Blend.BlendFlags = 0;
                Blend.SourceConstantAlpha = 90; // ������������ 50% (0 - 255)
                Blend.AlphaFormat =0;//AC_SRC_ALPHA; // ���� = 0 (������ ��������)
                ::AlphaBlend(btmp->Canvas->Handle, 0, 0, btmp->Width, btmp->Height,
         btmp2->Canvas->Handle, 0, 0, btmp->Width, btmp->Height, Blend);
         jpg->Assign(btmp);
         mqrimg->Picture->Assign(jpg);
        delete jpg;
        delete btmp;
        delete btmp2;
        }

  if (preview)
    qrPolis->Preview();
  else
    qrPolis->Print();
}


