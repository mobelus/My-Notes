//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Rab_Mesta_Form_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sSkinProvider"
#pragma link "DBGridEh"
#pragma link "sEdit"
#pragma link "sLabel"
#pragma link "sPanel"
#pragma link "sSpeedButton"
#pragma link "sSplitter"
#pragma resource "*.dfm"
TRab_Mesta_Form *Rab_Mesta_Form;
//---------------------------------------------------------------------------
__fastcall TRab_Mesta_Form::TRab_Mesta_Form(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRab_Mesta_Form::sSpeedButton5Click(TObject *Sender)
{
   ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TRab_Mesta_Form::sSpeedButton6Click(TObject *Sender)
{
   ModalResult = mrCancel;
}
//---------------------------------------------------------------------------
void TRab_Mesta_Form::InitForm(mops_api_007* _m_api, AnsiString rm_name, AnsiString rm_pref)
{
   m_api = _m_api;

   int res;
   AnsiString st;

   main_q = m_api->dbGetCursor(res, "select * from _mops_rabochee_mesto_ where deleted=0 and [id]>0");
   DataSource1->DataSet = main_q;

   id = -1;
   id = m_api->dbGetIntFromQuery(res, (AnsiString)"select [id] from _mops_rabochee_mesto_ where deleted=0 and [id]>0 and prefix='" + rm_pref + "'");
   if(id <= 0){
      if(Application->MessageBox(("������� ����� '"+rm_name+"("+rm_pref+")' �� �������, ��������?").c_str(), "�������������", MB_YESNO) == IDYES){
         id = m_api->dbGenerateId(res, "_mops_rabochee_mesto_");
         st = st.sprintf("insert into _mops_rabochee_mesto_ ([id],name,prefix,deleted)values(%i,'%s','%s',0)", id, rm_name, rm_pref);
         m_api->dbExecuteQuery(res,st);
         m_api->dbRefreshCursor(res,main_q,0);
      }
   }
   m_api->dbFindRecord(res, main_q, "id", st.sprintf("%i", id));
}
//---------------------------------------------------------------------------
void __fastcall TRab_Mesta_Form::sSpeedButton4Click(TObject *Sender)
{
   int res;
   m_api->dbRefreshCursor(res, main_q, "id");
}
//---------------------------------------------------------------------------
void __fastcall TRab_Mesta_Form::FormDestroy(TObject *Sender)
{
   int res;
   m_api->dbCloseCursor(res, main_q);
}
//---------------------------------------------------------------------------
void __fastcall TRab_Mesta_Form::DataSource1DataChange(TObject *Sender, TField *Field)
{
   id = main_q->FieldByName("id")->AsInteger;
}
//---------------------------------------------------------------------------

