//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FIns_dlg.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sEdit"
#pragma resource "*.dfm"
TFIns *FIns;
//---------------------------------------------------------------------------
__fastcall TFIns::TFIns(TComponent* Owner, const int t, mops_api_023* m)
  : TForm(Owner), terr_id(t), m_api(m)
{
}
//---------------------------------------------------------------------------
void __fastcall TFIns::Edit_FChange(TObject *Sender)
{
   if(terr_id != 4){
      int res;

      TEdit* edit = dynamic_cast<TEdit*>(Sender);
      int ss = edit->SelStart;
//      edit->Text = m_api->Translit_Text(res, edit->Text);
      edit->Text = edit->Text;
      edit->SelStart = ss + 1;
   }
}
//---------------------------------------------------------------------------

