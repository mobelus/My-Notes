//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UStrani.h"
#include "Constants.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sAlphaListBox"
#pragma link "sCheckListBox"
#pragma link "sBitBtn"
#pragma resource "*.dfm"
//const char* qkTerr = "SELECT VZR174Pr_terr_main_K.K FROM (vzr174pr_terr_str RIGHT JOIN VZR174Pr_terr_main_K ON vzr174pr_terr_str.id_terr = VZR174Pr_terr_main_K.id_terr) LEFT JOIN VZR174Pr_Country ON vzr174pr_terr_str.id_str = VZR174Pr_Country.ID WHERE (VZR174Pr_Country.ID = %i) AND VZR174Pr_terr_main_K.id_type_calc=1;";
TFStrani *FStrani;
//---------------------------------------------------------------------------
__fastcall TFStrani::TFStrani(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------
void __fastcall TFStrani::Init(AnsiString Strani, bool flag)
{
        int res;
        AnsiString sQuery = "select * from vzr174Pr_country, "+m_terr_str+" where VZR174Pr_Country.nostrah=0 and vzr174Pr_country.id="+m_terr_str+".id_str and "+m_terr_str+".id_terr=" + IntToStr(m_id_terr);

        if(flag)
        {
          if(Strani!="")
          {
            TStringList *str_strani=new TStringList;
            TSysCharSet Tws,Tcs;
            Tcs<<';';
            ExtractStrings(Tcs,Tws,Strani.c_str(),str_strani);
            sQuery += " and (";
            for(int i=0; i<str_strani->Count;i++)
            {
              if(i != 0)
                sQuery += " or ";
              sQuery += "CountryName='" + str_strani->Strings[i] + "' or CountryLatName='" + str_strani->Strings[i] + "'";
            }
            sQuery += ")";
          }
        }
        TADOQuery *qw = m_api->dbGetCursor(res, sQuery);
        sCheckListBox1->Clear();
        //bool engl_name=m_api->dbGetBoolFromQuery(res,"select engl_name from "+m_terr+" where id_terr="+ IntToStr(m_id_terr));
        qw->First();
        while(!qw->Eof)
        {
//         if(!engl_name) sCheckListBox1->Items->AddObject(qw->FieldByName("CountryName")->AsString,(TObject*) qw->FieldByName("id")->AsInteger);
//         if(engl_name) sCheckListBox1->Items->AddObject(qw->FieldByName("CountryLatName")->AsString,(TObject*) qw->FieldByName("id")->AsInteger);
          sCheckListBox1->Items->AddObject(qw->FieldByName("CountryName")->AsString,(TObject*) qw->FieldByName("id")->AsInteger);
          qw->Next();
        }
        if(flag)
          Strani = m_OutStranReport;
        if(Strani!="")
        {
          TStringList *str_strani=new TStringList;
          TSysCharSet Tws,Tcs;
          Tcs<<';';
          ExtractStrings(Tcs,Tws,Strani.c_str(),str_strani);
          for(int i=0; i<str_strani->Count;i++)
          {
            int j=sCheckListBox1->Items->IndexOf(Trim(str_strani->Strings[i]));
            if(j!=-1)sCheckListBox1->Checked[j]=true;
          }
        }
}

void __fastcall TFStrani::sBitBtn1Click(TObject *Sender)
{
 stran="";
 specprogram=false;
 int count=0;
 int id=0;
 AnsiString sql;

 for(int i=0; i < sCheckListBox1->Count;i++)
    if(sCheckListBox1->Checked[i])
     count++;

 for(int i=0 , j=0; i < sCheckListBox1->Count;i++)
    if(sCheckListBox1->Checked[i]){
     specprogram = (count == 0);
     id=(int)sCheckListBox1->Items->Objects[i];
     stran = stran + sCheckListBox1->Items->Strings[i];
     if(j != count - 1)
      stran += ";";
     j++;
    }

  if(specprogram)
  {
   int res;
   int f_specpr=m_api->dbGetIntFromQuery(res,"select flags from vzr174pr_country where VZR174Pr_Country.nostrah=0 and id="+ IntToStr(id));
   specprogram=(f_specpr & COUNTRY_FLAGS_PITER_SPECPROGRAM)==COUNTRY_FLAGS_PITER_SPECPROGRAM;
  }
  ModalResult=mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TFStrani::sCheckListBox1DrawItem(TWinControl *Control,
      int Index, TRect &Rect, TOwnerDrawState State)
{
        sCheckListBox1->Canvas->FillRect(Rect);
        if (State.Contains(odSelected))sCheckListBox1->Canvas->Brush->Color= (TColor)RGB(200,200,255);
        else
          {
                   if(sCheckListBox1->Checked[Index])  sCheckListBox1->Canvas->Brush->Color =(TColor)RGB(255,200,200);
                   else
                   {
                   div_t t=div(Index,2);
                   if(t.rem==0)sCheckListBox1->Canvas->Brush->Color = (TColor)RGB(200,255,200);
                   if(t.rem==1)sCheckListBox1->Canvas->Brush->Color = clWhite;
                   }
          }
        sCheckListBox1->Canvas->FillRect(Rect);
        sCheckListBox1->Canvas->TextOut(Rect.Left, Rect.Top,sCheckListBox1->Items->Strings[Index]);
}
//---------------------------------------------------------------------------

void __fastcall TFStrani::CheckBox1Click(TObject *Sender)
{
        for(int i=0; i<sCheckListBox1->Count;i++)
                sCheckListBox1->Checked[i]=CheckBox1->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TFStrani::sBitBtn3Click(TObject *Sender)
{
  TFStrani *fs=new TFStrani(this);
  stran="";
  specprogram=false;
  int count=0;

  fs->m_api=(mops_api_007*)m_api;
  fs->m_OutStranReport = m_OutStranReport;
  fs->m_id_terr=m_id_terr;
  fs->m_terr_str=m_terr_str;
  fs->m_terr=m_terr;
  fs->sBitBtn3->Visible = false;
  for(int i=0; i<sCheckListBox1->Count;i++)
  {
    if(sCheckListBox1->Checked[i])
    {
      stran=stran+ sCheckListBox1->Items->Strings[i] + ";";
      count++;
    }
  }
  fs->Caption = "�������� ����� ��� ������.";
  fs->Init(stran, true);
  if(fs->ShowModal() == mrOk)
    m_OutStranReport = fs->stran;
  fs->Free();
}
//---------------------------------------------------------------------------


