//---------------------------------------------------------------------------

#ifndef Rab_Mesta_Form_cH
#define Rab_Mesta_Form_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sSkinProvider.hpp"
#include "DBGridEh.hpp"
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sPanel.hpp"
#include "sSpeedButton.hpp"
#include "sSplitter.hpp"
#include <Buttons.hpp>
#include <DB.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include "Tmops_api.h"
//---------------------------------------------------------------------------
class TRab_Mesta_Form : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel5;
        TsPanel *sPanel6;
        TsSpeedButton *sSpeedButton5;
        TsSpeedButton *sSpeedButton6;
        TsSpeedButton *sSpeedButton4;
        TDBGridEh *DBGridEh1;
        TsSkinProvider *sSkinProvider1;
        TDataSource *DataSource1;
        void __fastcall sSpeedButton5Click(TObject *Sender);
        void __fastcall sSpeedButton6Click(TObject *Sender);
        void __fastcall sSpeedButton4Click(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall DataSource1DataChange(TObject *Sender,
          TField *Field);
private:	// User declarations
        TADOQuery *main_q;
        mops_api_007* m_api;
public:		// User declarations
        int id;
        __fastcall TRab_Mesta_Form(TComponent* Owner);
        void InitForm(mops_api_007* _m_api,AnsiString rm_name,AnsiString rm_pref);
};
//---------------------------------------------------------------------------
extern PACKAGE TRab_Mesta_Form *Rab_Mesta_Form;
//---------------------------------------------------------------------------
#endif
