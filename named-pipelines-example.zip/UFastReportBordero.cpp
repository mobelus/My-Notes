//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UFastReportBordero.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "frxClass"
#pragma link "frxCross"
#pragma link "frxDesgn"
#pragma link "frxDBSet"
#pragma link "frxChBox"
#pragma link "frxDCtrl"
#pragma link "frxDMPExport"
#pragma link "frxGradient"
#pragma resource "*.dfm"
TFFastReportBordero *FFastReportBordero;
//---------------------------------------------------------------------------
__fastcall TFFastReportBordero::TFFastReportBordero(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------
