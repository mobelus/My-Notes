//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PolisForm3x.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

AnsiString MonthToStr(AnsiString m)
{
       if((m == "������") || (m == "�������") || (m == "������") || (m == "���") ||
       (m == "����") || (m == "����") || (m == "��������") ||
       (m == "�������") || (m == "������") || (m == "�������")){
               int l = m.Length();
               m = m.Insert("�", l);
               m.SetLength(l);
      }
       else if ((m == "����") || (m == "������"))
               m += "�";

       return m;
}
TFPolis3x *FPolis3x;
//---------------------------------------------------------------------------
__fastcall TFPolis3x::TFPolis3x(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
__fastcall TFPolis3x::TFPolis3x(TComponent* Owner, bool fPechat)
  : TForm(Owner), m_fPechat(fPechat)
{
}
//---------------------------------------------------------------------------

void __fastcall TFPolis3x::PrintPolis(long calc_id,bool preview, bool blank)
{
  int res = 0;
  long c_people = 0;
  AnsiString stmp = "";
  AnsiString Currency="";

  QRLabel43->Caption = "-----------";
  QRLabel44->Caption = "-----------";
  QRLabel56->Caption = "-----------";
  QRLabel57->Caption = "-----------";
  QRLabel45->Caption = "-----------";
  QRLabel46->Caption = "-----------";
  QRLabel58->Caption = "-----------";
  QRLabel59->Caption = "-----------";
  c_people = m_api->dbGetLongFromQuery(res, stmp.sprintf("select count(*) from VZR174Pr_Insured where id_calc = %i", calc_id));
  TADOQuery *qw = m_api->dbGetCursor(res, stmp.sprintf("select * from vzr174pr_calc where calc_id = %i", calc_id));
  if(res != 0 && qw->RecordCount > 0)
  {
    MessageBox(NULL, "��� ������ �� ������", "������", MB_OK);
    return;
  }
  Currency = qw->FieldByName("CurrencyName")->AsString;
        if (qw->FieldByName("strach_fiz_yur")->AsString=="���������� ����")
        {
                QRLabel1       ->Caption = qw->FieldByName("strach_fio")->AsString;
                QRLabel2       ->Caption = qw->FieldByName("strach_dr")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("strach_dr")->AsString;
                QRLabel3       ->Caption = qw->FieldByName("strach_address")->AsString;
                QRLabel4       ->Caption = qw->FieldByName("strach_tel")->AsString;
        }
        else
        {
                QRLabel1       ->Caption = qw->FieldByName("strach_yur_naimen")->AsString;
                QRLabel3       ->Caption = qw->FieldByName("strach_yur_address")->AsString;
                QRLabel4       ->Caption = qw->FieldByName("strach_yur_tel")->AsString;
               // qrlbJuridicalFIO  ->Caption = qw->FieldByName("strach_yur_contact")->AsString;
               // qrlbJuridicalDate ->Caption = qw->FieldByName("data_zayavl")->AsString;
        }


        if(qw->FieldByName("str_polis_start_data")->AsDateTime!=(TDateTime)NULL)
        {
                QRLStrStart_dd->Caption = qw->FieldByName("str_polis_start_data")->AsDateTime.FormatString("dd");
                QRLStrStart_mm ->Caption = MonthToStr(qw->FieldByName("str_polis_start_data")->AsDateTime.FormatString("mm"));
                QRLStrStart_yy ->Caption = qw->FieldByName("str_polis_start_data")->AsDateTime.FormatString("yy");
        }
        if(qw->FieldByName("str_polis_end_data")->AsDateTime!=(TDateTime)NULL)
        {
                QRLStrEnd_dd->Caption = qw->FieldByName("str_polis_end_data")->AsDateTime.FormatString("dd");
                QRLStrEnd_mm ->Caption = MonthToStr(qw->FieldByName("str_polis_end_data")->AsDateTime.FormatString("mm"));
                QRLStrEnd_yy ->Caption = qw->FieldByName("str_polis_end_data")->AsDateTime.FormatString("yy");
        }

        if(qw->FieldByName("str_polis_start_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                QRLSrokStart_dd ->Caption = qw->FieldByName("str_polis_start_dog_data")->AsDateTime.FormatString("dd");
                QRLSrokStart_mm ->Caption = MonthToStr(qw->FieldByName("str_polis_start_dog_data")->AsDateTime.FormatString("mm"));
                QRLSrokStart_yy ->Caption = qw->FieldByName("str_polis_start_dog_data")->AsDateTime.FormatString("yy");
        }
        if(qw->FieldByName("str_polis_end_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                QRLSrokEnd_dd ->Caption = qw->FieldByName("str_polis_end_dog_data")->AsDateTime.FormatString("dd");
                QRLSrokEnd_mm ->Caption = MonthToStr(qw->FieldByName("str_polis_end_dog_data")->AsDateTime.FormatString("mm"));
                QRLSrokEnd_yy ->Caption = qw->FieldByName("str_polis_end_dog_data")->AsDateTime.FormatString("yy");
        }

        QRLabel7  ->Caption = qw->FieldByName("MainDays")->AsString;
        AnsiString  sterr;
        sterr = qw->FieldByName("MainTerritory")->AsString;
        if(!qw->FieldByName("MainTerritory")->AsString.IsEmpty() && !qw->FieldByName("CountryReport")->AsString.IsEmpty())
          sterr += ",";
        sterr += qw->FieldByName("CountryReport")->AsString;
        QRLabel16->Caption = sterr;

/*        if(!qw->FieldByName("CountryReport")->AsString.IsEmpty())
          if(qw->FieldByName("CountryReport")->AsString != "Worldwide")
            QRLabel16->Caption = QRLabel16->Caption + ":";
        QRLabel16->Caption = QRLabel16->Caption + qw->FieldByName("CountryReport")->AsString;
*/


        QRLabel18 ->Caption = qw->FieldByName("Program")->AsString;
        QRLabel23 ->Caption = qw->FieldByName("MainSumm")->AsString + " " +Currency ;
        if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
          QRLabel33 ->Caption = qw->FieldByName("MainPremium")->AsString + " " + Currency;
        QRLabel47->Caption=qw->FieldByName("MainRules")->AsString;

        if (qw->FieldByName("MainFranchiseValue")->AsFloat>0)
                QRLabel28->Caption = FloatToStr(qw->FieldByName("MainFranchiseValue")->AsFloat) + " " + Currency;


        int lFlags = qw->FieldByName("RisksFlags")->AsInteger;

        if ((lFlags & VZRCALC_RISKSFLAG_LOSSBAG)>0)
        {
                this->QRLabel19->Caption=qw->FieldByName("LossBagTransportTypeName")->AsString.SubString(1,1);
                QRLabel24 ->Caption=qw->FieldByName("LossBagSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  QRLabel34 ->Caption = qw->FieldByName("LossBagPremium")->AsString + " " + Currency;
                QRLabel48->Caption=qw->FieldByName("LossBagRules")->AsString;
                QRLabel29->Caption=Trim(qw->FieldByName("LossBagTimeFranchiseName")->AsString);
                if (  qw->FieldByName("LossBagFranchiseValue")->AsFloat>0)
                        QRLabel29->Caption =QRLabel29->Caption+ "; "+ FloatToStr(m_api->Round(qw->FieldByName("LossBagFranchiseValue")->AsFloat *qw->FieldByName("LossBagSummValue")->AsFloat/100)) + " " + Currency;

        }
        if ((lFlags & VZRCALC_RISKSFLAG_CANCELTRIP)>0)
        {
                QRLabel49->Caption=qw->FieldByName("CancelTripRules")->AsString;
                this->QRLabel20->Caption=qw->FieldByName("CancelTripTypeName")->AsString.SubString(1,1);
                QRLabel25    ->Caption = qw->FieldByName("CancelTripSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  QRLabel35 ->Caption = qw->FieldByName("CancelTripPremium")->AsString + " " + Currency;
                if (qw->FieldByName("CancelTripFranchiseValue")->AsFloat>0)
                        QRLabel30->Caption = FloatToStr(m_api->Round(qw->FieldByName("CancelTripFranchiseValue")->AsFloat *qw->FieldByName("CancelTripSummValue")->AsFloat /100)) + " " + Currency;
        }
       if ((lFlags & VZRCALC_RISKSFLAG_CIVILLIABILITY)>0)
        {

                QRLabel50->Caption=qw->FieldByName("CivilLiabilityRules")->AsString;
                this->QRLabel21->Caption="F";//qw->FieldByName("")->AsString.SubString(1,1);
                QRLabel26 ->Caption =qw->FieldByName("CivilLiabilitySummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  QRLabel36 ->Caption = qw->FieldByName("CivilLiabilityPremium")->AsString + " " + Currency;
                if (qw->FieldByName("CivilLiabilityFranchiseValue")->AsFloat>0)
                        QRLabel31->Caption =FloatToStr(m_api->Round(qw->FieldByName("CivilLiabilitySummValue")->AsFloat*qw->FieldByName("CivilLiabilityFranchiseValue")->AsFloat/100)) + " "+ Currency;
        }
        if ((lFlags & VZRCALC_RISKSFLAG_ACCIDENT)>0)
        {
                QRLabel51->Caption=qw->FieldByName("AccidentRules")->AsString;
                this->QRLabel22->Caption=qw->FieldByName("AccidentTypeName")->AsString.SubString(1,1);
                QRLabel27    ->Caption =qw->FieldByName("AccidentSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  QRLabel37 ->Caption = qw->FieldByName("AccidentPremium")->AsString + " " + Currency;
                if (qw->FieldByName("AccidentFranchiseValue")->AsFloat>0)
                        QRLabel32->Caption =FloatToStr(m_api->Round(qw->FieldByName("AccidentSummValue")->AsFloat* qw->FieldByName("AccidentFranchiseValue")->AsFloat/100))+ " " + Currency ;
        }

        if(qw->FieldByName("MainKoefFreeValue")->AsFloat!=1)
          QRLabel55->Caption = "v";
        if (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==2 ||
            (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==1))
          QRLabel53->Caption = "v";
//        if (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==1)
//          QRLabel52->Caption = "v";
        if (qw->FieldByName("MainKoefProfName")->AsString!="���")
          QRLabel54->Caption = "v";
        if (m_api->dbGetLongFromQuery(res, stmp.sprintf("select count(*) from VZR174Pr_Insured where id_calc = %i and k_age <> 1", calc_id)))
          QRLabel38->Caption = "v";
        if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
          QRLabel40->Caption = Format("%s %s = %s ������", ARRAYOFCONST((qw->FieldByName("AllPremium")->AsString,
                                                                               qw->FieldByName("CurrencyName")->AsString,
                                                                               qw->FieldByName("AllPremiumRUR")->AsString)));
        QRLabel41->Caption = qw->FieldByName("mesto_vidachi")->AsString;
        QRLabel42->Caption = qw->FieldByName("data_zayavl")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("data_zayavl")->AsString;
        QRLabel43 ->Caption = qw->FieldByName("predst_dov_num")->AsString;
        if(qw->FieldByName("predst_dov_data")->AsDateTime!=(TDateTime)NULL)
        {
                QRLabel44   ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("dd");
                QRLabel56 ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("mm");
                QRLabel57 ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("yyyy");
        }
        QRLabel45->Caption=qw->FieldByName("predst_dog_num")->AsString;
        if(qw->FieldByName("predst_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                QRLabel46->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("dd");
                QRLabel58->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("mm");
                QRLabel59->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("yyyy");
        }
        QRLabel39->Caption = "";
//       if(qw->FieldByName("LossBagflagOpis")->AsBoolean)
//            QRLabel39->Caption = "inventory of property (����� ���������).";
        if(qw->FieldByName("MainSpec")->AsBoolean &&
           qw->FieldByName("Region")->AsString != "�����-��������� � ������������� �������")
        {
//          if(!QRLabel39->Caption.IsEmpty())
//            QRLabel39->Caption = QRLabel39->Caption + ";";
//          QRLabel39->Caption = QRLabel39->Caption + "���������";
;
        }
        if(qw->FieldByName("flag_Pers")->AsBoolean)
        {
//          if(!QRLabel39->Caption.IsEmpty())
//           QRLabel39->Caption = QRLabel39->Caption + ";";
//          QRLabel39->Caption = QRLabel39->Caption + "����� 12.7 ������ �����������.";
;
        }
        if ((lFlags & VZRCALC_RISKSFLAG_CANCELTRIP)>0){
//          if(!QRLabel39->Caption.IsEmpty())
//            QRLabel39->Caption = QRLabel39->Caption + ";";
//          QRLabel39->Caption = QRLabel39->Caption + " ����������� " + qw->FieldByName("CancelTripCivilText")->AsString;
;
        }

        if(QRLabel39->Caption.IsEmpty())
          QRLabel39->Caption = "----------";

 //�������������� ������.
  if(m_api->dbGetLongFromQuery(res, stmp.sprintf("select count(*) from VZR174Pr_Insured where id_calc = %i and k_age <> 1", calc_id)))
    QRLabel38->Caption = "v";

 TADOQuery *qI = m_api->dbGetCursor(res, stmp.sprintf("select * from VZR174Pr_Insured where id_calc = %i", calc_id));
 if(res != 0)
 {
    MessageBox(NULL, "��� ������ �� ��������������", "������", MB_OK);
    return;
 }
 stmp = "";
 if(c_people <= 4)
 {
   int num = 8;
   TQRLabel *plb1 = NULL;
   TQRLabel *plb2 = NULL;

   qI->First();
   while(!qI->Eof)
   {
    stmp.sprintf("QRLabel%i", num);
    plb1 = (TQRLabel *)this->QRBand1->FindChildControl(stmp);
    stmp.sprintf("QRLabel%i", num + 4);
    plb2 = (TQRLabel *)this->QRBand1->FindChildControl(stmp);
    plb1->Caption = qI->FieldByName("InsuredPersonFIO")->AsString;
    plb2->Caption = qI->FieldByName("InsuredPersonBirthday")->AsString;
    qI->Next();
    num++;
   }
   print_report(preview, blank);
 }
 else if(c_people > 4)
 {
   //�����
   int n = 8;
   TQRLabel *plb1 = NULL;
   TQRLabel *plb2 = NULL;

    stmp.sprintf("QRLabel%i", n);
    plb1 = (TQRLabel *)this->QRBand1->FindChildControl(stmp);
    stmp.sprintf("QRLabel%i", n + 4);
    plb2 = (TQRLabel *)this->QRBand1->FindChildControl(stmp);
    stmp.sprintf("%i people, according to the attached list(�������, �������� ������������ ������)", c_people);
    plb1->Caption = stmp;
    plb2->Caption = "-----------";
   for(int num = 1;num < 4; num++)
   {
    stmp.sprintf("QRLabel%i", n + num);
    plb1 = (TQRLabel *)this->QRBand1->FindChildControl(stmp);
    stmp.sprintf("QRLabel%i", n + num + 4);
    plb2 = (TQRLabel *)this->QRBand1->FindChildControl(stmp);
    plb1->Caption = "-----------";
    plb2->Caption = "-----------";
   }
   print_report(preview, blank);
   //���.��������
   int full_num = c_people / max_rec_1;
   if(full_num == 0)
   {
     if(c_people > max_rec_2)
     {
      //�����. �����.
      TFormDopList3x1 *ppr = new TFormDopList3x1(this, m_fPechat);
      qI->First();
      for(int page = 0; page <= full_num; page++)
      {
        ppr->QRLabel1->Caption = IntToStr(page + 2);
        ppr->QRLabel2->Caption = IntToStr(full_num);
        ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
        ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
        ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
        m_api->QR_Form_Prepare(m_Res, ppr, "������ 3-�� ������ �� ������ (������������� ��������)");
        ppr->print(preview, blank);
      }
      delete ppr;
     }
      //����. �����.
      TFormDopList3x2 *ppr = new TFormDopList3x2(this, m_fPechat);
      ppr->QRLabel155->Caption = IntToStr(c_people);
      if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
      {
        ppr->QRLabel156->Caption = qw->FieldByName("AllPremium")->AsString;
        ppr->QRLabel157->Caption = qw->FieldByName("AllPremiumRUR")->AsString;
      }
      ppr->QRLabel1->Caption = IntToStr(full_num + 2);
      ppr->QRLabel2->Caption = IntToStr(full_num + 2);
      ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
      ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
      ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
      m_api->QR_Form_Prepare(m_Res, ppr, "������ 3-�� ������ �� ������ (���������)");
      ppr->print(preview, blank);
      delete ppr;
   }
   else
   {
      //�����. �����.
      TFormDopList3x1 *ppr = new TFormDopList3x1(this, m_fPechat);
      qI->First();
      for(int page = 0; page < full_num; page++)
      {
        ppr->QRLabel1->Caption = IntToStr(page + 2);
        ppr->QRLabel2->Caption = IntToStr(full_num + 2);
        ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
        ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
        ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
        m_api->QR_Form_Prepare(m_Res, ppr, "������ 3-�� ������ �� ������ (������������� ��������)");
        ppr->print(preview, blank);
      }
      delete ppr;
      long rem = c_people - (full_num * max_rec_1);
      if(rem > max_rec_2)
      {
        TFormDopList3x1 *ppr = new TFormDopList3x1(this, m_fPechat);
        ppr->QRLabel1->Caption = IntToStr(full_num + 2 - 1);
        ppr->QRLabel2->Caption = IntToStr(full_num + 2);
        ppr->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
        ppr->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
        ppr->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
        m_api->QR_Form_Prepare(m_Res, ppr, "������ 3-�� ������ �� ������ (������������� ��������)");
        ppr->print(preview, blank);
        delete ppr;
      }
      //����. �����.
      TFormDopList3x2 *ppr2 = new TFormDopList3x2(this, m_fPechat);
      ppr2->QRLabel155->Caption = IntToStr(c_people);
      if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
      {
        ppr2->QRLabel156->Caption = qw->FieldByName("AllPremium")->AsString;
        ppr2->QRLabel157->Caption = qw->FieldByName("AllPremiumRUR")->AsString;
      }
      ppr2->QRLabel1->Caption = IntToStr(full_num + 2);
      ppr2->QRLabel2->Caption = IntToStr(full_num + 2);
      ppr2->QRLabel3->Caption = qw->FieldByName("strach_polis_ser")->AsString;
      ppr2->QRLabel4->Caption = qw->FieldByName("strach_polis_num")->AsString;
      ppr2->rep_date(qI, qw->FieldByName("disabled_prem_in_polis")->AsBoolean);
      m_api->QR_Form_Prepare(m_Res, ppr, "������ 3-�� ������ �� ������ (���������)");
      ppr2->print(preview, blank);
      delete ppr2;
   }
 }
  m_api->dbCloseCursor(res, qI);
  m_api->dbCloseCursor(res, qw);
}

 void __fastcall TFPolis3x::print_report(bool preview, bool blank)
{

  //������������
  QRLabel17->Caption = QRLabel1->Caption;
  QRLabel125->Caption = QRLabel1->Caption;
  QRLabel61->Caption = QRLabel2->Caption;
  QRLabel127->Caption = QRLabel2->Caption;
  QRLabel60->Caption = QRLabel3->Caption;
  QRLabel126->Caption = QRLabel3->Caption;
  QRLabel62->Caption = QRLabel4->Caption;
  QRLabel128->Caption = QRLabel4->Caption;

QRLabel67->Caption =  QRLStrStart_dd->Caption;
QRLabel133->Caption = QRLStrStart_dd->Caption;
QRLabel6->Caption =   QRLStrStart_mm->Caption;
QRLabel186->Caption = QRLStrStart_mm->Caption;
QRLabel5->Caption =   QRLStrStart_yy->Caption;
QRLabel187->Caption = QRLStrStart_yy->Caption;

QRLabel68->Caption = QRLStrEnd_dd->Caption;
QRLabel134->Caption = QRLStrEnd_dd->Caption;
QRLabel52->Caption = QRLStrEnd_mm->Caption;
QRLabel188->Caption = QRLStrEnd_mm->Caption;
QRLabel100->Caption = QRLStrEnd_yy->Caption;
QRLabel189->Caption = QRLStrEnd_yy->Caption;

QRLabel190->Caption =   QRLSrokStart_dd->Caption;
QRLabel166->Caption =   QRLSrokStart_dd->Caption;
QRLabel191->Caption =   QRLSrokStart_mm->Caption;
QRLabel175->Caption =   QRLSrokStart_mm->Caption;
QRLabel192->Caption =   QRLSrokStart_yy->Caption;
QRLabel176->Caption =   QRLSrokStart_yy->Caption;

QRLabel193->Caption =   QRLSrokEnd_dd->Caption;
QRLabel177->Caption =   QRLSrokEnd_dd->Caption;
QRLabel194->Caption =   QRLSrokEnd_mm->Caption;
QRLabel178->Caption =   QRLSrokEnd_mm->Caption;
QRLabel195->Caption =   QRLSrokEnd_yy->Caption;
QRLabel179->Caption =   QRLSrokEnd_yy->Caption;

QRLabel69->Caption = QRLabel7->Caption;
QRLabel135->Caption = QRLabel7->Caption;
QRLabel63->Caption = QRLabel8->Caption;
QRLabel129->Caption = QRLabel8->Caption;
QRLabel64->Caption = QRLabel9->Caption;
QRLabel130->Caption = QRLabel9->Caption;
QRLabel65->Caption = QRLabel10->Caption;
QRLabel131->Caption = QRLabel10->Caption;
QRLabel66->Caption = QRLabel11->Caption;
QRLabel132->Caption = QRLabel11->Caption;
QRLabel70->Caption = QRLabel12->Caption;
QRLabel71->Caption = QRLabel13->Caption;
QRLabel72->Caption = QRLabel14->Caption;
QRLabel73->Caption = QRLabel15->Caption;
QRLabel136->Caption = QRLabel12->Caption;
QRLabel137->Caption = QRLabel13->Caption;
QRLabel138->Caption = QRLabel14->Caption;
QRLabel139->Caption = QRLabel15->Caption;

QRLabel75->Caption = QRLabel18->Caption;
QRLabel76->Caption = QRLabel19->Caption;
QRLabel77->Caption = QRLabel20->Caption;
QRLabel78->Caption = QRLabel21->Caption;
QRLabel79->Caption = QRLabel22->Caption;

QRLabel141->Caption = QRLabel18->Caption;
QRLabel142->Caption = QRLabel19->Caption;
QRLabel143->Caption = QRLabel20->Caption;
QRLabel144->Caption = QRLabel21->Caption;
QRLabel145->Caption = QRLabel22->Caption;

QRLabel80->Caption = QRLabel23->Caption;
QRLabel81->Caption = QRLabel24->Caption;
QRLabel82->Caption = QRLabel25->Caption;
QRLabel83->Caption = QRLabel26->Caption;
QRLabel84->Caption = QRLabel27->Caption;

QRLabel146->Caption = QRLabel23->Caption;
QRLabel147->Caption = QRLabel24->Caption;
QRLabel148->Caption = QRLabel25->Caption;
QRLabel149->Caption = QRLabel26->Caption;
QRLabel150->Caption = QRLabel27->Caption;

QRLabel85->Caption = QRLabel28->Caption;
QRLabel86->Caption = QRLabel29->Caption;
QRLabel87->Caption = QRLabel30->Caption;
QRLabel88->Caption = QRLabel31->Caption;
QRLabel89->Caption = QRLabel32->Caption;

QRLabel151->Caption = QRLabel28->Caption;
QRLabel152->Caption = QRLabel29->Caption;
QRLabel153->Caption = QRLabel30->Caption;
QRLabel154->Caption = QRLabel31->Caption;
QRLabel155->Caption = QRLabel32->Caption;

QRLabel90->Caption = QRLabel33->Caption;
QRLabel91->Caption = QRLabel34->Caption;
QRLabel92->Caption = QRLabel35->Caption;
QRLabel93->Caption = QRLabel36->Caption;
QRLabel94->Caption = QRLabel37->Caption;

QRLabel156->Caption = QRLabel33->Caption;
QRLabel157->Caption = QRLabel34->Caption;
QRLabel158->Caption = QRLabel35->Caption;
QRLabel159->Caption = QRLabel36->Caption;
QRLabel160->Caption = QRLabel37->Caption;

QRLabel95->Caption = QRLabel47->Caption;
QRLabel96->Caption = QRLabel48->Caption;
QRLabel97->Caption = QRLabel49->Caption;
QRLabel98->Caption = QRLabel50->Caption;
QRLabel99->Caption = QRLabel51->Caption;

QRLabel161->Caption = QRLabel47->Caption;
QRLabel162->Caption = QRLabel48->Caption;
QRLabel163->Caption = QRLabel49->Caption;
QRLabel164->Caption = QRLabel50->Caption;
QRLabel165->Caption = QRLabel51->Caption;

QRLabel101->Caption = QRLabel53->Caption;
QRLabel102->Caption = QRLabel38->Caption;
QRLabel103->Caption = QRLabel54->Caption;
QRLabel104->Caption = QRLabel55->Caption;

QRLabel167->Caption = QRLabel53->Caption;
QRLabel168->Caption = QRLabel38->Caption;
QRLabel169->Caption = QRLabel54->Caption;
QRLabel170->Caption = QRLabel55->Caption;

QRLabel105->Caption = QRLabel39->Caption;
QRLabel171->Caption = QRLabel39->Caption;

QRLabel106->Caption = QRLabel40->Caption;
QRLabel172->Caption = QRLabel40->Caption;

QRLabel107->Caption = QRLabel41->Caption;
QRLabel173->Caption = QRLabel41->Caption;

QRLabel108->Caption = QRLabel42->Caption;
QRLabel174->Caption = QRLabel42->Caption;

QRLabel109->Caption = QRLabel43->Caption;
QRLabel110->Caption = QRLabel44->Caption;
QRLabel111->Caption = QRLabel56->Caption;
QRLabel112->Caption = QRLabel57->Caption;
QRLabel113->Caption = QRLabel45->Caption;
QRLabel114->Caption = QRLabel46->Caption;
QRLabel115->Caption = QRLabel58->Caption;
QRLabel116->Caption = QRLabel59->Caption;

QRLabel117->Caption = QRLabel43->Caption;
QRLabel118->Caption = QRLabel44->Caption;
QRLabel119->Caption = QRLabel56->Caption;
QRLabel120->Caption = QRLabel57->Caption;
QRLabel121->Caption = QRLabel45->Caption;
QRLabel122->Caption = QRLabel46->Caption;
QRLabel123->Caption = QRLabel58->Caption;
QRLabel124->Caption = QRLabel59->Caption;

QRLabel74->Caption = QRLabel16->Caption;
QRLabel140->Caption = QRLabel16->Caption;

        if(!blank)
        {
         //�������� ����� "�������"
         TJPEGImage *jpg=new TJPEGImage();
         jpg->Assign( QRImage1->Picture);
         Graphics::TBitmap *btmp2=new Graphics::TBitmap();
         Graphics::TBitmap *btmp=new Graphics::TBitmap();
         btmp->Assign(jpg);
         btmp2->Assign(jpg);
         btmp->PixelFormat=pf32bit;
         btmp2->PixelFormat=pf32bit;
         SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
         HFONT font = CreateFont(100,          // ������ ������
                   80,          // ������ ����������
                   250,            //���� ��������
                   0,            //���� �����������
                   FW_BOLD,     //������ ������
                   TRUE,        // ������
                   FALSE,        // �������������
                   FALSE,               // ��������������
                   DEFAULT_CHARSET ,
                   OUT_TT_PRECIS,       // �������� ������
                   CLIP_DEFAULT_PRECIS,   //�������� ���������
                   ANTIALIASED_QUALITY, // �������� ������
                   FF_DONTCARE|DEFAULT_PITCH, // ��������� � ���
                   "Times New Roman");          // ��� ������
         btmp2->Canvas->Font->Handle=font;
         btmp2->Canvas->Font->Color=RGB(255,0,0);
         btmp2->Canvas->TextOut(100,btmp->Height-350,"�������");
         btmp2->Canvas->TextOut(100,btmp->Height-350-btmp->Height/3,"�������");
         btmp2->Canvas->TextOut(100,btmp->Height-350-2*btmp->Height/3,"�������");

         TBlendFunction Blend;
         Blend.BlendOp=AC_SRC_OVER;
                Blend.BlendFlags = 0;
                Blend.SourceConstantAlpha = 128; // ������������ 50% (0 - 255)
                Blend.AlphaFormat =0;//AC_SRC_ALPHA; // ���� = 0 (������ ��������)
                ::AlphaBlend(btmp->Canvas->Handle, 0, 0, btmp->Width, btmp->Height,
		btmp2->Canvas->Handle, 0, 0, btmp->Width, btmp->Height, Blend);
         jpg->Assign(btmp);
         QRImage1->Picture->Assign(jpg);
        delete jpg;
        delete btmp;
        delete btmp2;
        }

  if(m_fPechat){
    QRIBack->Top = QRImage1->Top;
    QRIBack->Width = QRImage1->Width;
    QRIBack->Left = QRImage1->Left;
    QRIBack->Height = QRImage1->Height;
    QRIBack->Enabled=!blank;
    QRImage1->Enabled = false;
    QRIPechat_1->Enabled = true;
    QRIPechat_2->Enabled = true;
    QRIPechat_3->Enabled = true;
    }
  else
    QRImage1->Enabled=!blank;

  if (preview)
    QuickRep1->Preview();
  else
    QuickRep1->Print();
}
