//---------------------------------------------------------------------------


#pragma hdrstop

#include "KAge.h"
#include "BaseVZRMod.h"

//---------------------------------------------------------------------------
CBaseKoeffAge::CBaseKoeffAge(IAge *f, TCT tt)
  :m_Iframe(f), m_TypeTariff(tt){}

double CBaseKoeffAge::CalcKoeff(){
  int age = 0;
  bool fCAge = false;
  AnsiString  err;

  try{
  if(!m_Iframe->getAge_I(fCAge, age))
    return 0;
  if(m_prTypeTariff == m_TypeTariff && (m_prfCAge == fCAge) && (m_prage == age))
    return m_Koeff;
  m_prTypeTariff = m_TypeTariff;
  m_prfCAge = fCAge;
  m_prage = age;
  }catch(Exception &e){
    err = e.Message;
  }
  m_Koeff = GetDBQuery(fCAge, age);

  return m_Koeff;
}

double CBaseKoeffAge::GetDBQuery(bool fCAge,int age){
  int idK = 0;
  AnsiString tbl;
  AnsiString swhere;

  //������ ���� �� ������� � ������ ������ - ��� ������� �� �������!

  m_SQLf.sprintf("%i >= start_age AND %i <= end_age", age, age);
  gVZR->gfID("VZR174Pr_Age", m_SQLf, "id", idK);
  swhere = "ID=" + IntToStr(idK);
  if(fCAge && (m_TypeTariff == eROZNICA_FIZ)){
    tbl = "VZR174Pr_Age_Country";
    m_DesK = gAPI->dbGetStringFromQuery(gRes, "select '��' + Str(start_age) + ' �� ' + Str(end_age) + ' ���.' from VZR174Pr_Age where id = " + IntToStr(idK));
  }
  else{
    tbl = "VZR174Pr_Koeffs";
    m_DesK = gAPI->dbGetStringFromQuery(gRes, "select Brief from VZR174Pr_Koeffs where GroupID=2 and ID = " + IntToStr(idK));
  }

  double Koeff = gVZR->gfK(tbl, "ID = " + IntToStr(idK) + " and GroupID=2 and multitrip="+IntToStr(gVZR->multitrip),"ID", "Koeff");
  m_DesK = FloatToStr(Koeff) + " (" + m_DesK + ")";
  return Koeff;
}
#pragma package(smart_init)

