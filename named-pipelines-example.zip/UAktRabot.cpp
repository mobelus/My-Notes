//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UAktRabot.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sComboBox"
#pragma link "sLabel"
#pragma link "sCustomComboEdit"
#pragma link "sGroupBox"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma link "sBitBtn"
#pragma link "sCurrEdit"
#pragma link "sSkinProvider"
#pragma link "sSkinManager"
#pragma resource "*.dfm"
TFAktRabot *FAktRabot;


//---------------------------------------------------------------------------
__fastcall TFAktRabot::TFAktRabot(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TFAktRabot::PrepareFields()
{
 int res;
 nas_punkt="";
 TADOQuery *qw=m_api->dbGetCursor(res,"select * from vzr174Pr_str_comp");
 for(int i=0; i<qw->RecordCount;i++)
 {
 sComboBox1->Items->AddObject(qw->FieldByName("str_comp_name")->AsString,(TObject*) qw->FieldByName("id_str_comp")->AsInteger);
 qw->Next();
 }
 if(sComboBox1->Items->Count == 1)
  sComboBox1->ItemIndex = 0;
 if(m_api->vrGetVariableCurProduct(res,"vzr174Pr_str_company") != "")
  sComboBox1->ItemIndex = sComboBox1->Items->IndexOf(m_api->vrGetVariableCurProduct(res,"vzr174Pr_str_company"));

if(sComboBox1->ItemIndex>-1) sComboBox1Change(NULL);

 qw=m_api->dbGetCursor(res,"select * from vzr174Pr_predst_str");
 for(int i=0; i<qw->RecordCount;i++)
 {
   sComboBox2->Items->AddObject(qw->FieldByName("pred_str_name")->AsString,(TObject*)qw->FieldByName("id_predst_str")->AsInteger);
   qw->Next();
 }

 if(sComboBox2->Items->Count == 1)
  sComboBox2->ItemIndex = 0;
 if(m_api->vrGetVariableCurProduct(res,"vzr174Pr_str_predst") != "")
  sComboBox2->ItemIndex=sComboBox2->Items->IndexOf(m_api->vrGetVariableCurProduct(res,"vzr174Pr_str_predst"));

 qw=m_api->dbGetCursor(res,"select * from vzr174Pr_yur");
sComboBox3->Clear();
 for(int i=0; i<qw->RecordCount;i++)
 {
 sComboBox3->Items->AddObject(qw->FieldByName("yur_name")->AsString,(TObject*) qw->FieldByName("id_yur")->AsInteger);
 qw->Next();
 }
 if(sComboBox3->Items->Count == 1)
  sComboBox3->ItemIndex = 0;
 if(m_api->vrGetVariableCurProduct(res,"vzr174Pr_yur") != "")
  sComboBox3->ItemIndex=sComboBox3->Items->IndexOf(m_api->vrGetVariableCurProduct(res,"vzr174Pr_yur"));

 qw=m_api->dbGetCursor(res,"select * from vzr174Pr_predst_yur");
 sComboBox4->Clear();
 for(int i=0; i<qw->RecordCount;i++)
 {
  sComboBox4->Items->AddObject(qw->FieldByName("pred_yur_name")->AsString,(TObject*) qw->FieldByName("id_predst_yur")->AsInteger);
  qw->Next();
 }
 if(sComboBox4->Items->Count == 1)
  sComboBox4->ItemIndex = 0;
 if(m_api->vrGetVariableCurProduct(res,"vzr174Pr_yur_predst") != "")
  sComboBox4->ItemIndex=sComboBox4->Items->IndexOf(m_api->vrGetVariableCurProduct(res,"vzr174Pr_yur_predst"));

 sDateEdit3->Date=Now();
 sDateEdit1->Date=Now();
 sDateEdit2->Date=Now();
 SQL="";
}


void __fastcall TFAktRabot::sBitBtn2Click(TObject *Sender)
{
 Close();
}
//---------------------------------------------------------------------------

void __fastcall TFAktRabot::sBitBtn1Click(TObject *Sender)
{
int res;
if(m_api->dbGetIntFromQuery(res,"select count (*) from vzr174Pr_calc vc,_mops_calcs_  mc where mc.id=vc.calc_id and vc.predst_name='"+ sComboBox2->Text + "' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true))==0)
{
 Application->MessageBoxA("��� ��������� �� ��������� ������","���",MB_OK | MB_ICONWARNING);
 return;

}

//��������� SQL
SQL="SELECT '"+ sCalcEdit1->Text +"' AS num_akt, "
"'"+sDateEdit3->Text+"' AS date_ak, "
"'" + sComboBox1->Text + "' as str_comp_name,"
"'" + nas_punkt + "' as str_comp_nas_punkt, "
" pr_st.pred_str_name, "
" pr_st.doverennost_num, "
" pr_st.doverennost_data, "
" '"+sComboBox3->Text+"' AS yur_name, "
" pr_yur.pred_yur_name, "
" pr_yur.pred_yur_r_name, "
" pr_yur.dolgnost_yur, "
" pr_yur.dolgnost_r_yur, "
" pr_yur.doverennost_num_yur, "
" pr_yur.doverennost_data_yur, "
" pr_yur.dogovor_num_yur, "
" pr_yur.dogovor_data_yur, "
" iif(pr_yur.sex_yur='�','������������','�����������') AS deystv_yur, "
" '" + sDateEdit1->Text+"' as start_period, "
" '"+sDateEdit2->Text+"' as end_period,"
" (select count (*) from vzr174Pr_calc vc,_mops_calcs_  mc where mc.id=vc.calc_id and vc.predst_name='"+ sComboBox2->Text + "' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true)+  " ) as count_dogovor, "
" (select count (*) from vzr174Pr_calc vc,_mops_calcs_  mc, vzr174Pr_Insured ins where mc.id=vc.calc_id and vc.calc_id = ins.id_calc and vc.predst_name='"+ sComboBox2->Text + "' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true)+  " ) as count_insured, "
" (select  CStr(fix(sum (AllPremiumRUR))) + ' ���. ' + CStr(fix(round(100*(sum(AllPremiumRUR) -fix(sum (AllPremiumRUR))),0))) + ' ���.'      from vzr174Pr_calc vc,_mops_calcs_  mc where mc.id=vc.calc_id and vc.predst_name='"+ sComboBox2->Text+"' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true)+  "   ) as obsh_prem, "
" (select  CStr(fix(sum (yur_voznagrajd/100*AllPremiumRUR))) + ' ���. ' + CStr(fix(round(100*(sum(yur_voznagrajd/100*AllPremiumRUR) -fix(sum (yur_voznagrajd/100*AllPremiumRUR))),0))) + ' ���.' "
" from vzr174Pr_calc vc,_mops_calcs_  mc where mc.id=vc.calc_id and vc.predst_name='"+sComboBox2->Text+"' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false  and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true)+  "  ) as voznagr, "
" (select ROund(sum (yur_voznagrajd/100*AllPremiumRUR),2)  from vzr174Pr_calc vc,_mops_calcs_  mc where mc.id=vc.calc_id and vc.predst_name='"+sComboBox2->Text+"' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false  and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true)+  " ) as voznagr_f, "
" CStr(fix(voznagr_f/1.18*0.18) ) + ' ���. ' + CStr( fix(round(100* voznagr_f/1.18*0.18 - 100*fix(voznagr_f/1.18*0.18),0)) ) + ' ���.'  as nds18 "

//" (select  CStr(fix(sum (yur_voznagrajd/100*AllPremiumRUR/1.18*0.18))) + ' ���. ' + CStr(fix(round(100*(sum(yur_voznagrajd/100*AllPremiumRUR/1.18*0.18) -fix(sum (yur_voznagrajd/100*AllPremiumRUR/1.18*0.18))),0))) + ' ���.'   from vzr174Pr_calc vc,_mops_calcs_  mc where mc.id=vc.calc_id and vc.predst_name='"+sComboBox2->Text+"' and  vc.predst_yur_name='"+sComboBox4->Text+"' and mc.deleted=false and vc.data_zayavl>="+m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text,true)+"  and vc.data_zayavl<=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit2->Text,true)+  "   ) as nds18 "

" FROM "
" vzr174Pr_predst_str AS pr_st, "
" vzr174Pr_predst_yur AS pr_yur "
" WHERE "
" pr_st.pred_str_name='"+sComboBox2->Text+"'  and "
" pr_yur.pred_yur_name='"+sComboBox4->Text+"'" ;

this->ModalResult=mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TFAktRabot::sComboBox1Change(TObject *Sender)
{
//�������� ��������������� �������� ����������� ������
int res;
nas_punkt=m_api->dbGetStringFromQuery(res,"select str_comp_nas_punkt from vzr174Pr_str_comp where id_str_comp=" + IntToStr((int)sComboBox1->Items->Objects[sComboBox1->ItemIndex]));
}
//---------------------------------------------------------------------------

