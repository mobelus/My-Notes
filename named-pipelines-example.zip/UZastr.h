//---------------------------------------------------------------------------

#ifndef UZastrH
#define UZastrH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "sCustomComboEdit.hpp"
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sComboBox.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "Tmops_api.h"
#include "sGroupBox.hpp"
#include <memory>

//---------------------------------------------------------------------------
 typedef struct  Koeff
                {
                  Koeff(TWinControl *parent,int left=0,int top=0)
                        {
                              l=new TsLabel(parent);
                              cb=new TsComboBox(parent);
                              l->Parent=parent;
                              cb->Parent=parent;
                              l->Top=top+3;
                              l->Left=left;

                              cb->Left=left+60;
                              cb->Width+=40;
                              cb->Top=top;
                              cb->OnClick=cbOnChange;
                              cb->Style=csDropDownList;
                              cb->ShowHint=true;
                              l->Show();
                              cb->Show();
                              koeff_value=0;
                              id=-1;
                              name="";

                       };

                    ~Koeff()
                       {
                                cb->Free();
                                l->Free();
                       };

                 AnsiString name;
                 TsLabel *l;
                 TsComboBox *cb;
                 double koeff_value;
                 long id;
                 int MestoProd;
               void __fastcall cbOnChange(TObject *Sender);
                } Koeff;

class TFZastr : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsPanel *sPanel2;
        TsBitBtn *sBitBtn1;
        TsBitBtn *sBitBtn2;
  TsEdit *F_Zastrach;
        TsLabel *sLabel1;
        TsDateEdit *DateRogd;
        TsLabel *sLabel2;
        TsLabel *sLabel3;
        TsEdit *AddressZ;
        TsEdit *StrPremZ;
        TsLabel *sLabel4;
        TsGroupBox *sGroupBox1;
        TLabel *Label1;
        TEdit *Edit1;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Edit2;
  TEdit *I_Zastrach;
  TEdit *O_Zastrach;
  TLabel *Label4;
  TLabel *Label5;
  TButton *Button1;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall DateRogdChange(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall F_ZastrachKeyPress(TObject *Sender, char &Key);
        void __fastcall AddressZKeyPress(TObject *Sender, char &Key);
        void __fastcall DateRogdExit(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
private:	// User declarations

public:		// User declarations
        __fastcall TFZastr(TComponent* Owner);
        mops_api_007* m_api;
        void __fastcall PrepareFields(bool new_z);
        double str_summ;
        double str_prem;
        void __fastcall CalcPremiya();
        TDateTime data_zayav;
        TList *lst_koeff;//���� �������������
        std::auto_ptr<TStringList> m_pzstrah_addr;
        int m_id_MestoProd;
};
//---------------------------------------------------------------------------
extern PACKAGE TFZastr *FZastr;
//---------------------------------------------------------------------------
#endif
