#ifndef ExcelH
#define ExcelH
//���������, ������������ ��� ��������� �����:
#define xlInsideHorizontal 12
#define xlInsideVertical 11
#define xlDiagonalDown 5
#define xlDiagonalUp 6
#define xlEdgeBottom 9
#define xlEdgeLeft 7
#define xlEdgeRight 10
#define xlEdgeTop 8
//��������� ����� �����
#define xlContinuous 1
#define xlDash -4115
#define xlDashDot 4
#define xlDashDotDot 5
#define xlDot -4118
#define xlDouble -4119
#define xlSlantDashDot 13
#define xlLineStyleNone -4142
//������� �����
#define xlHairline 1
#define xlMedium -4138
#define xlThick 4
#define xlThin 2

typedef enum eFILESUPPORT {
  FILEEMPTY = -1,
  FILEXCEL,     //Excel
  FILEODS       //OpenOffice
}eFILESUPPORTEXT;

class Excel
{
private:
      Variant App,Sh,OD;
      eFILESUPPORTEXT m_typef;
      AnsiString m_file;

            void __fastcall AppInitExel();
            void __fastcall AppInitOds();
      AnsiString __fastcall ConvertToURL(AnsiString);
public:
            void __fastcall ExcelInit(AnsiString File);
            void __fastcall toExcelCell(int c1,int c2, String data);
            void __fastcall toExcelCell(int c1,int c2, Variant data);
            void __fastcall Merge(char * Range);
            void __fastcall HorAlign(int  sRow,int sCol,int val);
            void __fastcall VertAlign(int  sRow,int sCol,int val);
            void __fastcall SetFont(int sRow,int sCol,TFont *Fnt);
            void __fastcall SetColor(int sRow, int sCol,int Color);
            void __fastcall SetColor(char * Range ,int Color);
            void __fastcall SetFrame(int sRow,int sCol, int gde, int line_style, int weight,int color);
            void __fastcall SetFrame(char* Range, int gde, int line_style, int weight,int color);
            void __fastcall SetFrameCellss(int sRow,int sCol,  int line_style, int weight,int color);
            void __fastcall SetOrientation(int sRow, int sCol,int Angle);
            void __fastcall SetOrientation(char * Range,int Angle);
            void __fastcall AutoFit(int sRow,int sCol);
      AnsiString __fastcall GetRange(int start_row,int start_col,int end_row,int end_col);
            void __fastcall Visible(bool visible);
            void __fastcall Free();
            void __fastcall Close();
            void __fastcall SaveAs(AnsiString FileName);
      AnsiString __fastcall GetActiverange();
           TRect __fastcall GetActiverange2();
            void __fastcall SetCheckBoxVisible();
            void __fastcall InsertRow(int sRow);
            void __fastcall Print(int count_copy);
            void __fastcall Quit();
      AnsiString __fastcall GetValue(int sRow, int sCol);
};
#endif
