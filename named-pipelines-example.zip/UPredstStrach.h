//---------------------------------------------------------------------------


#ifndef UPredstStrachH
#define UPredstStrachH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sGroupBox.hpp"
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sComboBox.hpp"
#include "Tmops_api.h"
//---------------------------------------------------------------------------
class TFPredstStrach : public TFrame
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsGroupBox *sGroupBox1;
        TsLabel *sLabel1;
        TsLabel *sLabel2;
        TsEdit *StrachCompNumLic;
        TsLabel *sLabel3;
        TsDateEdit *sDateEdit1;
        TsComboBox *StrachCompName;
        TsGroupBox *sGroupBox2;
        TsLabel *sLabel4;
        TsComboBox *Predst;
        TsLabel *sLabel5;
        TsEdit *PredstNumDov;
        TsLabel *sLabel6;
        TsDateEdit *PredstDataDov;
        TsGroupBox *sGroupBox3;
        TsLabel *sLabel12;
        TsComboBox *CBYur;
        TsGroupBox *sGroupBox4;
        TsLabel *sLabel13;
        TsLabel *sLabel14;
        TsLabel *sLabel15;
        TsLabel *sLabel16;
        TsLabel *sLabel17;
        TsLabel *sLabel18;
        TsLabel *sLabel19;
        TsLabel *sLabel20;
        TsComboBox *sComboBox1;
        TsEdit *sEdit4;
        TsDateEdit *sDateEdit2;
        TsEdit *sEdit5;
        TsDateEdit *sDateEdit3;
        TsEdit *sEdit6;
        TsEdit *sEdit7;
        TsEdit *sEdit8;
  TsLabel *sLabel21;
  TsEdit *EVoz;
        TCheckBox *CBNoPrintPrem;
    TsLabel *sLabel7;
    TsLabel *sLabel8;
    TsDateEdit *predst_dog_data;
    TsLabel *sLabel9;
    TsLabel *sLabel10;
    TsEdit *predst_dog_num;
        void __fastcall StrachCompNameChange(TObject *Sender);
        void __fastcall PredstChange(TObject *Sender);
        void __fastcall sComboBox1Change(TObject *Sender);
  void __fastcall CBYurChange(TObject *Sender);
private:	// User declarations

public:		// User declarations
        __fastcall TFPredstStrach(TComponent* Owner);
        mops_api_007* m_api;
       void __fastcall  LoadFrame(long id_calc);
       void __fastcall  SaveFrame(long id_calc);
       void __fastcall PrepareFields();
       bool __fastcall CheckData(); //���������� true, ���� ��� ���������
       bool m_fLoadXML;

};
//---------------------------------------------------------------------------
extern PACKAGE TFPredstStrach *FPredstStrach;
//---------------------------------------------------------------------------
#endif

