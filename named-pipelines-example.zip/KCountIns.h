//---------------------------------------------------------------------------

#ifndef KCountInsH
#define KCountInsH
//---------------------------------------------------------------------------
#include "Ikoeff.h"
#include "IFrame.H"

class CBaseKoeffCountIns:public IBaseKoeff{
  ICountIns *m_Iframe;
  double m_Koeff;
  AnsiString m_DesK;
  int m_prcountIns;
protected :
  TCT m_TypeTariff;
  TCT m_prTypeTariff;
  AnsiString m_SQLf;
public:
  CBaseKoeffCountIns(ICountIns *f, TCT tt);
  AnsiString NKoeff_I()     { return "Kcins";};
  AnsiString DescKoeff_I()  { return "����� ��������������.";};
protected :
  virtual double getKoeff_I(){return m_Koeff;};
  virtual double calcKoeff_I(){return CalcKoeff();};
  virtual AnsiString getDescDBKoeff_I(){return m_DesK;};
protected :
  double  CalcKoeff();
  virtual double GetDBQuery(int);
};

class CUKoeffCountIns: public CBaseKoeffCountIns{
public:
  CUKoeffCountIns(ICountIns *f, TCT tt)
    :CBaseKoeffCountIns(f,tt){};
protected:
  virtual double GetDBQuery(int c);
};

class CPartnerKoeffCountIns: public CUKoeffCountIns{
public:
  CPartnerKoeffCountIns(ICountIns *f, TCT tt)
    :CUKoeffCountIns(f,tt){}
protected:
  virtual double GetDBQuery(int c){return 1;};
};

class CIVCKoeffCountIns: public CPartnerKoeffCountIns{
public:
  CIVCKoeffCountIns(ICountIns *f, TCT tt)
    :CPartnerKoeffCountIns(f,tt){}
};
#endif

