//---------------------------------------------------------------------------


#pragma hdrstop

#include "KSport.h"
#include "BaseVZRMod.h"
//---------------------------------------------------------------------------

const char* qkSport = "SELECT %s  FROM VZR174Pr_sport_main_K as tblK,"
   " VZR174Pr_sport_group_main_risk as tblDes "
   " where  tblK.id_type_calc = %d and tblDes.id_type_calc = tblK.id_type_calc and tblK.id_group = tblDes.id_sport_group and id = %d";

CBaseKoeffSport::CBaseKoeffSport(ISport *f, TCT tt)
  : m_Iframe(f), m_TypeTariff(tt){}

double  CBaseKoeffSport::CalcKoeff(){
  int idSport;
  AnsiString err;

  try{
    if(!m_Iframe->getSport_I(idSport))
      return 0;
    if(m_prTypeTariff == m_TypeTariff && (m_pridSport == idSport))
      return m_Koeff;
    m_pridSport = idSport;
    m_prTypeTariff = m_TypeTariff;
  }catch(Exception &e){
    err = e.Message;
  }
  GetDBQuery(idSport);
  return m_Koeff;
}

bool CBaseKoeffSport::GetDBQuery(int id){
  if(gAPI->dbGetIntFromQuery(gRes, m_SQLf.sprintf(qkSport, "count(*)", (int)m_TypeTariff, id)) > 0){
    TADOQuery *pq = gAPI->dbGetCursor(gRes, m_SQLf.sprintf(qkSport, "K, group", (int)m_TypeTariff, id));
    m_Koeff = pq->FieldByName("K")->AsFloat;
    m_DesK = FloatToStr(m_Koeff) + " (" + pq->FieldByName("group")->AsString + ")";
    gAPI->dbCloseCursor(gRes, pq);
    return true;
  }
  return false;
}

bool CUKoeffSport::GetDBQuery(int id){
  if(!CBaseKoeffSport::GetDBQuery(id)){
    m_TypeTariff = eROZNICA_FIZ;
    return CBaseKoeffSport::GetDBQuery(id);
  }
  else
    return true;
}

bool CPartnerKoeffSport::GetDBQuery(int id){
  if(!CBaseKoeffSport::GetDBQuery(id)){
    m_TypeTariff = eROZNICA_UR;
    return CUKoeffSport::GetDBQuery(id);
  }
  else
    return true;
}

bool CIVCKoeffSport::GetDBQuery(int id){
  if(!CBaseKoeffSport::GetDBQuery(id)){
    m_TypeTariff = ePARTNER_UR;
    return CPartnerKoeffSport::GetDBQuery(id);
  }
  else
    return true;
}
#pragma package(smart_init)

