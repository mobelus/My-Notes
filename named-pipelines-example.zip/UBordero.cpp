//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "UBordero.h"
#include "Word.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sBitBtn"
#pragma link "sPanel"
#pragma link "sCustomComboEdit"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma link "sEdit"
#pragma link "sLabel"
#pragma link "sComboBox"
#pragma link "sGroupBox"
#pragma resource "*.dfm"
TFBordero *FBordero;
//---------------------------------------------------------------------------
__fastcall TFBordero::TFBordero(TComponent* Owner)
        : TForm(Owner), m_frep(false)
{
}
//---------------------------------------------------------------------------
__fastcall TFBordero::TFBordero(TComponent* Owner, bool frep)
        : TForm(Owner), m_frep(frep)
{
}
//---------------------------------------------------------------------------
void TFBordero::PrepareFields() {
        int res;
        sDateEdit1->Date = Now();
        //������������
        TADOQuery *  qw=m_api->dbGetCursor(res,"select * from _mops_polzovateli_ where deleted=0 order by name" );
        cbUser->Clear();
        for(int i=0; i<qw->RecordCount;i++,qw->Next())
         cbUser->AddItem(qw->FieldByName("name")->AsString,(TObject*)qw->FieldByName("id")->AsInteger);
        if(cbUser->Items->Count == 1)
          cbUser->ItemIndex = 0;
}
//---------------------------------------------------------------------------
void __fastcall TFBordero::sBitBtn1Click(TObject *Sender)
{
        if(sEdit1->Text=="")
        {
                Application->MessageBox("�� ������ ����� �������","����������� ���",MB_OK | MB_ICONERROR);
                return;
        }

        if(sDateEdit1->Text=="")
        {
                Application->MessageBox("�� ������� ���� �������","����������� ���",MB_OK | MB_ICONERROR);
                return;
        }


        if(cbUser->Text=="")
        {
         Application->MessageBox("�� ������� ������������","����������� ���",MB_OK |MB_ICONERROR);
         return;
        }

        if(eTel->Text=="")
        {
         Application->MessageBox("�� ������� ������� ������������","����������� ���",MB_OK |MB_ICONERROR);
         return;
        }




 if(m_frep)
 {
    //Fast Report
    m_qfr = CreateQuery2FastReport();
    Close();
    return;
 }


}
//---------------------------------------------------------------------------
void __fastcall TFBordero::sBitBtn2Click(TObject *Sender)
{
Close();
}
//---------------------------------------------------------------------------
AnsiString __fastcall TFBordero::GetQuery2FastReport()
{
        if(!m_qfr.IsEmpty())
                return m_qfr;
        else
                return AnsiString("");
}
//---------------------------------------------------------------------------
AnsiString __fastcall TFBordero::CreateQuery2FastReport()
{
        int res = 0;
      AnsiString iduser = IntToStr((int)cbUser->Items->Objects[cbUser->ItemIndex]);
       AnsiString SQL= " SELECT count( *) as cnt1 FROM vzr174Pr_calc AS vc, _mops_calcs_ AS mc WHERE mc.id=vc.calc_id AND mc.deleted=0 AND mc.id_polzovatelya=" +iduser+ " AND vc.data_zayavl=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text);
        AnsiString itogo=m_api->dbGetStringFromQuery(res,SQL);
        SQL= " SELECT sum(vc.AllPremium) as cnt1 FROM vzr174Pr_calc AS vc, _mops_calcs_ AS mc WHERE mc.id=vc.calc_id AND mc.deleted=0 AND mc.id_polzovatelya=" +iduser+ " AND vc.data_zayavl=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text) + " and vc.CurrencyName='USD'";
        AnsiString bord_summa_usd=m_api->dbGetStringFromQuery(res,SQL);
        SQL= " SELECT sum(vc.AllPremium) as cnt1 FROM vzr174Pr_calc AS vc, _mops_calcs_ AS mc WHERE mc.id=vc.calc_id AND mc.deleted=0 AND mc.id_polzovatelya=" +iduser+ " AND vc.data_zayavl=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text) + " and vc.CurrencyName='EUR'";
        AnsiString bord_summa_eur=m_api->dbGetStringFromQuery(res,SQL);
        SQL= " SELECT sum(vc.AllPremiumRUR) as cnt1 FROM vzr174Pr_calc AS vc, _mops_calcs_ AS mc WHERE mc.id=vc.calc_id AND mc.deleted=0 AND mc.id_polzovatelya=" +iduser+ " AND vc.data_zayavl=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text);
        AnsiString bord_summa_rur=m_api->dbGetStringFromQuery(res,SQL);
        SQL= " select skk from _mops_polzovateli_ where deleted=0 and id=" + iduser;
        AnsiString skk=m_api->dbGetStringFromQuery(res,SQL);

        
        AnsiString orgform = m_api->dbGetStringFromQuery(res, "select rgs_value from gl_dict_rgs_lnz_opf where type_id=1 and start_date<=DATE() and end_date>=DATE()");
        AnsiString license = m_api->dbGetStringFromQuery(res, "select rgs_value from gl_dict_rgs_lnz_opf where type_id=2 and start_date<=DATE() and end_date>=DATE()");


        SQL=" SELECT '"+license+"' as license, '"+orgform+"' as orgform,'"+sEdit1->Text+"' as bord_num, '"+ sDateEdit1->Text +"' as bord_data,"
        "'' as bord_mesto,'"+eTel->Text+"' as bord_tel, '"+cbUser->Text+" ' as bord_fio,"
        " '"+bord_summa_usd+"' as bord_summa_USD,'"+ bord_summa_eur+"'as bord_summa_eur, "
        "'"+bord_summa_rur+"' as bord_summa_rur,'" +itogo+"' as bord_itogo,'" +skk+"' as bord_skk, * "
          //and fPrintOneIns = iif(fPrintOneIns, fPrinted, false) - �� ������� �������. 22.01.2013. - ��� ������������ ������� �� ��������� ���� �������� ����������� ��� ���.
        " FROM vzr174Pr_calc AS vc, _mops_calcs_ AS mc , vzr174Pr_Insured WHERE mc.id=vc.calc_id AND vc.calc_id = vzr174Pr_Insured.id_calc AND mc.deleted=0 AND mc.id_polzovatelya=" +IntToStr((int)cbUser->Items->Objects[cbUser->ItemIndex])+ " AND vc.data_zayavl=" + m_api->Internal_Convert_Date_To_SQL(res,sDateEdit1->Text) + "  order by vzr174Pr_Insured.id_calc, vzr174Pr_Insured.num";

        return SQL;
}
//---------------------------------------------------------------------------
