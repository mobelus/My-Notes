//---------------------------------------------------------------------------

#ifndef KAgeH
#define KAgeH
//---------------------------------------------------------------------------
#include "Ikoeff.h"
#include "IFrame.H"

class CBaseKoeffAge:public IBaseKoeff{
  IAge *m_Iframe;
  double m_Koeff;
  AnsiString m_DesK;
  int m_prage;
  bool m_prfCAge;
protected :
  TCT m_TypeTariff;
  TCT m_prTypeTariff;
  AnsiString m_SQLf;
public:
  CBaseKoeffAge(IAge *f, TCT tt);
  AnsiString NKoeff_I()     { return "Kage";};
  AnsiString DescKoeff_I()  { return "���������� �����������.";};
protected :
  virtual double getKoeff_I(){return m_Koeff;};
  virtual double calcKoeff_I(){return CalcKoeff();};
  virtual AnsiString getDescDBKoeff_I(){return m_DesK;};
protected :
  double CalcKoeff();
  double GetDBQuery(bool, int);
};

class CUKoeffAge:public CBaseKoeffAge{
public:
  CUKoeffAge(IAge *f, TCT tt)
    :CBaseKoeffAge(f,tt){};
protected:
  double GetDBQuery(bool fCAge,int age){return CBaseKoeffAge::GetDBQuery(fCAge,age);};
};

class CPartnerKoeffAge:public CUKoeffAge{
public:
  CPartnerKoeffAge(IAge *f, TCT tt)
    :CUKoeffAge(f,tt){};
protected:
  double GetDBQuery(bool fCAge,int age){return CBaseKoeffAge::GetDBQuery(fCAge,age);};
};

class CIVCKoeffAge:public CPartnerKoeffAge{
public:
  CIVCKoeffAge(IAge *f, TCT tt)
    :CPartnerKoeffAge(f,tt){};
protected:
  double GetDBQuery(bool fCAge,int age){return CBaseKoeffAge::GetDBQuery(fCAge,age);};
};

#endif

