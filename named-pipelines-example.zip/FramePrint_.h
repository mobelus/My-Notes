//---------------------------------------------------------------------------


#ifndef FramePrint_H
#define FramePrint_H
//---------------------------------------------------------------------------
#include "BSO.h"
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sFrameAdapter.hpp"
#include "Tmops_api.h"
#include <Mask.hpp>
#include "sMaskEdit.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include "sComboBox.hpp"
#include "sLabel.hpp"
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sGroupBox.hpp"
#include "sEdit.hpp"
#include "sCurrEdit.hpp"
#include "sListView.hpp"
#include <ComCtrls.hpp>
#include "sBitBtn.hpp"
#include "sPageControl.hpp"
#include <Buttons.hpp>
#include "cxCalendar.hpp"
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxDropDownEdit.hpp"
#include "cxEdit.hpp"
#include "cxMaskEdit.hpp"
#include "cxTextEdit.hpp"
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <DB.hpp>
#include "sCheckBox.hpp"

class TDBUsersGrid: public TDBGrid{
public:
   _fastcall TDBUsersGrid(HWND ParentWin) : TDBGrid(ParentWin){};

    AnsiString _fastcall GetInplaceEditText(){ return InplaceEditor->Text;};
    void _fastcall SetInplaceEditText(AnsiString t){ InplaceEditor->Text = t;};
    TCustomEdit *_fastcall GetInplaceCtrl(){ return InplaceEditor;};
};

//---------------------------------------------------------------------------
class TFramePrint : public TFrame
{
__published:	// IDE-managed Components
        TGroupBox *GBStrachPolis;
        TLabel *Label1;
        TLabel *Label2;
        TsLabel *sLabel18;
        TsLabel *sLabel19;
        TEdit *ePolisSer;
        TEdit *ePolisNum;
        TLabel *Label3;
        TLabel *Label4;
        TsEdit *ePlace;
        TcxDateEdit *deStartDate;
        TcxDateEdit *deEndDate;
        TcxDateEdit *deStatementDate;
  TsGroupBox *GBStrach;
  TsPageControl *pcInsurer;
  TsTabSheet *tsPhysical;
  TGroupBox *GroupBox1;
  TDBGrid *DBGrid1;
  TButton *Button3;
  TButton *Button1;
  TsPanel *sPJuridical;
  TsLabel *sLabel40;
  TsEdit *eOrganization;
  TsLabel *sLabel41;
  TsEdit *eContactPerson;
  TsLabel *sLabel42;
  TsEdit *eTelJur;
  TLabel *Label7;
  TsEdit *eAddressJur;
  TsTabSheet *tsJuridical;
  TsPanel *sPPhysical;
  TsLabel *sLabel36;
  TsLabel *sLabel37;
  TsLabel *sLabel38;
  TsLabel *sLabel39;
  TLabel *Label12;
  TLabel *Label13;
  TsEdit *eSurname;
        TsEdit *eAddress1;
  TsEdit *eTel;
  TEdit *eName;
  TEdit *eLastName;
  TcxDateEdit *deBirthday;
  TsCheckBox *sCBPrintOneIns;
  TsBitBtn *sBBtnTerrStrah;
  TButton *Button2;
        TButton *Button4;
    TGroupBox *KanalGB;
    TTreeView *KanalPrTV;
    TPanel *PremPolPanel;
    TLabel *Label5;
    TLabel *Label6;
    TcxDateEdit *premium_charge_date;
    TsComboBox *CBPayment;
    TsComboBox *CBPaymentDoc;
    TsEdit *EPPSer;
    TEdit *eppnum;
    TsComboBox *regcode;
        TsLabel *sLabel1;
        TComboBox *CBPublic;
        TsLabel *sLabel2;
        TsEdit *EDTWork;
        TsBitBtn *sBitBtn1;
        TsLabel *sLabel3;
        TComboBox *CBCitizen;
        TsLabel *sLabel4;
        TsLabel *sLabel5;
        TsLabel *sLabel6;
        TsLabel *sLabel7;
        TsLabel *sLabel8;
        TsLabel *sLabel9;
        TsLabel *sLabel10;
        TsEdit *eDocSer;
        TComboBox *CBTypeDoc;
        TsEdit *eDocNum;
        TcxDateEdit *deDocDate;
        TsEdit *EDocVidan;
        TsEdit *eDocPodraz;
        TsEdit *eDocAddr;
        TsBitBtn *sBitBtn2;
        void __fastcall ePolisSerChange(TObject *Sender);
        void __fastcall deStatementDatePropertiesChange(TObject *Sender);
        void __fastcall deStartDatePropertiesChange(TObject *Sender);
  void __fastcall pcInsurerChange(TObject *Sender);
  void __fastcall eSurnameChange(TObject *Sender);
  void __fastcall eOrganizationChange(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Button3Click(TObject *Sender);
  void __fastcall deBirthdayKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall deBirthdayPropertiesChange(TObject *Sender);
  void __fastcall sCBPrintOneInsClick(TObject *Sender);
  void __fastcall DBGrid1KeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall DBGrid1Enter(TObject *Sender);
  void __fastcall DBGrid1Exit(TObject *Sender);
  void __fastcall DBGrid1CellClick(TColumn *Column);
  void __fastcall DBGrid1KeyPress(TObject *Sender, char &Key);
  void __fastcall sBBtnTerrStrahClick(TObject *Sender);
  void __fastcall Button2Click(TObject *Sender);
        void __fastcall ePolisNumChange(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall DBGrid1ColExit(TObject *Sender);
        void __fastcall DBGrid1DrawColumnCell(TObject *Sender,
          const TRect &Rect, int DataCol, TColumn *Column,
          TGridDrawState State);
        void __fastcall BuildKanalPrTree(TTreeNode* node,int p_id);
    void __fastcall CBPaymentChange(TObject *Sender);
    void __fastcall CBPaymentDocChange(TObject *Sender);
    void __fastcall KanalPrTVChange(TObject *Sender, TTreeNode *Node);
    void __fastcall EPPSerChange(TObject *Sender);
    void __fastcall eppnumChange(TObject *Sender);
    void __fastcall premium_charge_datePropertiesChange(TObject *Sender);
        void __fastcall CBPublicChange(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
        void __fastcall CBCitizenChange(TObject *Sender);
        void __fastcall CBTypeDocChange(TObject *Sender);
        void __fastcall eDocSerChange(TObject *Sender);
        void __fastcall eDocNumChange(TObject *Sender);
        void __fastcall deDocDateKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall deDocDatePropertiesChange(TObject *Sender);
        void __fastcall EDocVidanChange(TObject *Sender);
        void __fastcall eDocPodrazChange(TObject *Sender);
        void __fastcall eDocAddrChange(TObject *Sender);
private:
  long      m_id_calc;
  TFrame *  m_pCalc;
  long      m_numliIns;
  bool mf_cgBSO;
  bool mf_load;
  bool mf_iscopy;
  bool mf_Contry;
  int m_Res;
  int terr_id;
  TRect mr_CurrentCell;
  TColumn *m_CurrCol;
  int m_nCurrCol;
  int m_idSNG;
  bool m_fSetEditFocus;
  bool m_fEditIns;

void __fastcall FirstCharUpperCase(TCustomEdit * ed);
AnsiString __fastcall FirstCharUpperCase(AnsiString ed);
bool __fastcall CheckDataIns();
bool __fastcall CheckDataInsDub();
AnsiString m_EnterString;
TDBUsersGrid *m_Grid;

public:
        __fastcall TFramePrint(TComponent* Owner);
        __fastcall ~TFramePrint(){
            try{
              if((DBGrid1->DataSource != NULL) && (DBGrid1->DataSource->DataSet != NULL))
                DBGrid1->DataSource->DataSet = NULL;
            }catch(...){
            };
        };
        bool Check;
        mops_api_027* m_api;
        int count_days;
        bool myltitrip;// ������� ������������ �������
        bool __fastcall CheckData();

        void __fastcall PrepareFields();
        void __fastcall SaveFrame(int calc_id);
        void __fastcall LoadFrame(int calc_id);

        void __fastcall SetCalcFrame(TFrame *);
        bool __fastcall ChBSO();
        void __fastcall SetTerrId(const int val);

};
//---------------------------------------------------------------------------
extern PACKAGE TFramePrint *FramePrint;
//---------------------------------------------------------------------------
#endif
