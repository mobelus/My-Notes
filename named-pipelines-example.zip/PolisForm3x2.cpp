//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PolisForm3x2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormPolis3x2 *FormPolis3x2;
//---------------------------------------------------------------------------
__fastcall TFormPolis3x2::TFormPolis3x2(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

