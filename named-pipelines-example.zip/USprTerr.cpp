//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "USprTerr.h"
#include "UGlob.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sListView"
#pragma link "sBitBtn"
#pragma link "sCustomComboEdit"
#pragma link "sEdit"
#pragma link "sLabel"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma link "sButton"

#pragma link "sBitBtn"
#pragma link "sEdit"
#pragma link "sLabel"
#pragma link "sListView"
#pragma link "sPanel"
#pragma link "sButton"
#pragma link "sFrameAdapter"
#pragma link "sSkinProvider"
#pragma link "sAlphaListBox"
#pragma link "sCheckListBox"
#pragma resource "*.dfm"

#define FLAG_USER 0x10000000

TFSprTerr *FSprTerr;
//---------------------------------------------------------------------------
__fastcall TFSprTerr::TFSprTerr(TComponent* Owner)
        : TForm(Owner), fstatus(true)
{
 m_Res = 0;
}
//---------------------------------------------------------------------------
void __fastcall TFSprTerr::sBitBtn1Click(TObject *Sender)
{
if(!sPanel1->Visible)
{
        TerrName->Text="";
        TerrNameRus->Text="";

        for(int i=0; i<strani->Count;i++) strani->Checked[i]=false;
        CheckBox1->Checked=false;


        insert_update=1;
        sPanel3->Enabled=false;
        LV->Align=alNone;
        int width=sPanel1->Width;
        sPanel1->Width=0;
        sPanel1->Visible=true;
        for(int i=0; i<=width;i+=4)
        {
         sPanel1->Width=i;
         Application->ProcessMessages();
        Sleep(10);
      }
}

}
//---------------------------------------------------------------------------
void __fastcall TFSprTerr::sBitBtn2Click(TObject *Sender)
{
int res;
if(sPanel1->Visible)
{
  if(TerrName->Text==""){
   Application->MessageBox("�� ������� ���������� �������� ���������� �������","����������� ���",MB_OK | MB_ICONERROR);
   return;
  }
  if(TerrNameRus->Text==""){
   Application->MessageBox("�� ������� ���������� �������� ������� �������","����������� ���",MB_OK | MB_ICONERROR);
   return;
  }
  AnsiString sStrani;
  int SelCount = 0;
  bool fSelNULL = 0;
  TList *lst = new TList();
  for(int i=0; i<strani->Count;i++)
    if(strani->Checked[i]){
      int idtmp = 0;
      gfID("VZR174Pr_terr_Summ_limit", "id_country = " + IntToStr((int)strani->Items->Objects[i]), "id", idtmp);
      if(idtmp <= 0){
        idtmp = 0;
        fSelNULL = true;
      }
      else {
        idtmp = (int)strani->Items->Objects[i];
        SelCount ++;
      }
      lst->Add((void *)idtmp);
  }
  SelCount = SelCount + ((fSelNULL)?1:0);
  for(int i=0; i<lst->Count;i++){
    sStrani = sStrani + "id_country = " + IntToStr((int)(*lst)[i]);
    if(i < lst->Count - 1)
      sStrani = sStrani + " or ";
  }
  bool fmaxSumm = false;
  int id_currency = 1;//USD
  //����� ������
  int rval = 0;
  gfID("VZR174Pr_terr_Summ_limit", "(" + sStrani + ") and id_valuta = " + IntToStr(id_currency), "count(*)", rval);
  bool fUSD = (rval == SelCount)?false:true;
  //���������� ������� � USD
  gfID("VZR174Pr_terr_Summ_limit", "(" + sStrani + ") and id_valuta = " + IntToStr(id_currency), "Max(id_summ)", rval);
  int maxUSDID = rval;
  //�������� ������� ����������� �������� ��� ������ �������� ������.
  gfID("VZR174Pr_terr_Summ_limit", "(" + sStrani + ") and id_valuta = " + IntToStr(id_currency) + " and id_summ <= " + IntToStr(maxUSDID), "count(*)", rval);
  fmaxSumm = (rval == SelCount)?false:true;
  if(fUSD)
    Application->MessageBox("����������� �� �������� � USD. �� ��������� ���������� �� ������.","����������� ���",MB_OK | MB_ICONERROR);
  if(fmaxSumm)
    Application->MessageBox("����������� �� �������� � USD. ��� ����� ���������� ��������� �����.","����������� ���",MB_OK | MB_ICONERROR);
  fUSD |= fmaxSumm;
  id_currency = 2;//EUR
  //����� ������
  gfID("VZR174Pr_terr_Summ_limit", "(" + sStrani + ") and id_valuta = " + IntToStr(id_currency), "count(*)", rval);
  bool fEUR = (rval == SelCount)?false:true;
  //���������� ������� � EUR
  gfID("VZR174Pr_terr_Summ_limit", "(" + sStrani + ") and id_valuta = " + IntToStr(id_currency), "Max(id_summ)", rval);
  int maxEURID = rval;
  //�������� ������� ����������� �������� ��� ������ �������� ������.
  gfID("VZR174Pr_terr_Summ_limit", "(" + sStrani + ") and id_valuta = " + IntToStr(id_currency) + " and id_summ <= " + IntToStr(maxEURID), "count(*)", rval);
  fmaxSumm = (rval == SelCount)?false:true;
  if(fEUR)
    Application->MessageBox("����������� �� �������� � EUR. �� ��������� ���������� �� ������.","����������� ���",MB_OK | MB_ICONERROR);
  if(fmaxSumm)
    Application->MessageBox("����������� �� �������� � EUR. ��� ����� ���������� ��������� �����.","����������� ���",MB_OK | MB_ICONERROR);
  fEUR |= fmaxSumm;
  delete lst;
  if(fUSD && fEUR)
    return;
  AnsiString sql="";
  //�������� ��������

long id_terr;
          if(insert_update==0) // ���������� �������
          {
/*
          id_terr=(int)LV->Selected->Data;
          sql="update vzr174Pr_terr set "
          " terr_name='" + TerrName->Text + "', "
          " engl_name=" + IntToStr((int)CheckBox1->Checked) + ", "
          " select_country=" + IntToStr((int)CBSelectCountry->Checked) + ", "
          " disable_fr_main_risk=" + IntToStr((int)CBDisableFR->Checked) + " "
          " where id_terr=" + IntToStr(id_terr);
*/
            id_terr=(long)(LV->Selected->Data);
            if((id_terr & FLAG_USER) == FLAG_USER)
            {
              id_terr&=~FLAG_USER;
              sql="update vzr174Pr_terr_user set "
              " terr_name='" + TerrName->Text + "', "
              " terr_name_rus='" + TerrNameRus->Text + "', "
              " engl_name=" + IntToStr((int)CheckBox1->Checked) + ", "
              " select_country=" + IntToStr((int)CBSelectCountry->Checked) + ", "
              " disable_fr_main_risk=" + IntToStr((int)CBDisableFR->Checked) + ", "
              " id_type_calc=" + StrToInt(gAPI->vrGetVariableCurProduct(gRes, "id_type_tarif")) +
              " where id_terr=" + IntToStr(id_terr);
            }
          }

          if(insert_update==1) //���������� �����
          {
             id_terr=m_api->dbGenerateUniqueId(res,"vzr174Pr_terr_user","id_terr");
               sql="insert into vzr174Pr_terr_user (id_terr,terr_name,engl_name,select_country,disable_fr_main_risk,terr_name_rus,id_type_calc) values ("
               + IntToStr(id_terr) + ","
               + "'" + TerrName->Text + "',"
               + IntToStr((int) CheckBox1->Checked) +","
               + IntToStr((int) CBSelectCountry->Checked) +","
               + IntToStr((int) CBDisableFR->Checked) +","
               + "'" + TerrNameRus->Text + "'" + ","
               + StrToInt(gAPI->vrGetVariableCurProduct(gRes, "id_type_tarif")) +
               ")";
          }
      insert_update=-1;
      m_api->dbExecuteQuery(res,sql);
      //������ ��� ������������� ������ � ����������
      m_api->dbExecuteQuery(res,"delete from vzr174Pr_terr_str_user where id_terr=" + IntToStr(id_terr));
      for(int i=0; i<strani->Count;i++){
       if(strani->Checked[i])
        m_api->dbExecuteQuery(res,"insert into vzr174Pr_terr_str_user (id_terr_str,id_terr,id_str,id_type_calc) values (" + IntToStr(m_api->dbGenerateUniqueId(res,"vzr174Pr_terr_str_user","id_terr_str"))+ "," +IntToStr(id_terr)+ ","+IntToStr((int)strani->Items->Objects[i])+"," + StrToInt(gAPI->vrGetVariableCurProduct(gRes, "id_type_tarif")) + ")");
      }
      sPanel3->Enabled=true;
      sPanel1->Visible=false;
      LV->Align=alClient;
      PrepareFields();
}
}
//---------------------------------------------------------------------------
void __fastcall TFSprTerr::sBitBtn3Click(TObject *Sender)
{
  if(LV->Selected==NULL) return;
  if(!sPanel1->Visible)
  {
    int res = 0;
    TADOQuery *qw = NULL;
    long terr_id;
    AnsiString stbl_terr_str;
    AnsiString stbl_terr;

    if(((long)LV->Selected->Data & FLAG_USER) == FLAG_USER)
    {
      stbl_terr_str = "vzr174Pr_terr_str_user";
      stbl_terr = "vzr174Pr_terr_user";
      terr_id = (long)LV->Selected->Data & ~FLAG_USER;
    }
    else
    {
      stbl_terr_str = "vzr174Pr_terr_str";
      stbl_terr = "vzr174Pr_terr";
      terr_id = (long)LV->Selected->Data;
    }

    qw = m_api->dbGetCursor(res,"select * from  " + stbl_terr_str + " where id_terr="+ IntToStr(terr_id));
    for(int i=0; i<strani->Count;i++)
      strani->Checked[i]=false;
    for(int i=0; i<qw->RecordCount;i++)
    {
      strani->Checked[strani->Items->IndexOfObject((TObject*)qw->FieldByName("id_str")->AsInteger)]=true;
      qw->Next();
    }
    TADOQuery *plQ = m_api->dbGetCursor(res, "select * from "+ stbl_terr +" where id_terr=" + IntToStr(terr_id));
    TerrName->Text = plQ->FieldByName("terr_name")->AsString;
    TerrNameRus->Text = plQ->FieldByName("terr_name_rus")->AsString;
    CheckBox1->Checked = plQ->FieldByName("engl_name")->AsBoolean;
    CBSelectCountry->Checked = plQ->FieldByName("select_country")->AsBoolean;
    CBDisableFR->Checked = plQ->FieldByName("disable_fr_main_risk")->AsBoolean;
    m_api->dbCloseCursor(res, plQ);
    insert_update=0;
    sPanel3->Enabled=false;
    LV->Align=alNone;
    sPanel1->Visible=true;
    ShowStatusFields((FLAG_USER & (long)LV->Selected->Data) == FLAG_USER);
  }
}
//---------------------------------------------------------------------------
void __fastcall TFSprTerr::PrepareFields()
 {
 int res;
 Button1->Visible=m_api->vrGetVariableCurProduct(res,"_mops_global_run_parameter_is_admin_")=="1";

  insert_update=-1;

  LV->Items->Clear();
  TADOQuery *qw=m_api->dbGetCursor(res,"select * from vzr174Pr_terr ");
    for(int i=0; i<qw->RecordCount; i++)
    {
      TListItem *li=LV->Items->Add();

      li->Caption=qw->FieldByName("terr_name")->AsString;
      li->Data=(TObject*) qw->FieldByName("id_terr")->AsInteger;
     qw->Next();
    }
   m_api->dbCloseCursor(res, qw);

  qw  = m_api->dbGetCursor(res,"select * from vzr174Pr_terr_user");
    for(int i=0; i<qw->RecordCount; i++)
    {
      TListItem *li=LV->Items->Add();

      li->Caption = qw->FieldByName("terr_name")->AsString;
      li->Data  = (TObject*)(long)(FLAG_USER | qw->FieldByName("id_terr")->AsInteger);
     qw->Next();
    }
   m_api->dbCloseCursor(res, qw);
  //������
  strani->Clear();
  qw=m_api->dbGetCursor(res,"select * from vzr174Pr_country order by countryname");
  for(int i=0; i<qw->RecordCount;i++){
  strani->Items->AddObject(qw->FieldByName("countryname")->AsString+ " (" + qw->FieldByName("countrylatname")->AsString+")",(TObject*)qw->FieldByName("id")->AsInteger);
  qw->Next();
  }
  m_api->dbCloseCursor(res, qw);
  //����������.
  terr->Clear();
  qw=m_api->dbGetCursor(res,"select * from vzr174pr_terr where id_terr = 2 or id_terr = 4");
  for(int i=0; i<qw->RecordCount;i++){
    terr->Items->AddObject(qw->FieldByName("terr_name_rus")->AsString+ " (" + qw->FieldByName("terr_name")->AsString+")",(TObject*)qw->FieldByName("id_terr")->AsInteger);
    qw->Next();
  }
  m_api->dbCloseCursor(res, qw);
}
//------------------------------------------------------------------------------
void __fastcall TFSprTerr::sBitBtn4Click(TObject *Sender)
{
  if(LV->Selected==NULL) return;
  long terr_id;
  AnsiString
    stbl_terr_str,
    stbl_terr;

  if(((long)LV->Selected->Data & FLAG_USER) == FLAG_USER)
  {
    stbl_terr_str = "vzr174Pr_terr_str_user";
    stbl_terr = "vzr174Pr_terr_user";
    terr_id = (long)LV->Selected->Data & ~FLAG_USER;
  }
  else
  {
    stbl_terr_str = "vzr174Pr_terr_str";
    stbl_terr = "vzr174Pr_terr";
    terr_id = (long)LV->Selected->Data;
  }

  if(Application->MessageBox("�� ������������� ������ ������� ���������� ��������?","����������� ���",MB_YESNO | MB_ICONQUESTION)==IDYES)
  {
  int res;

  m_api->dbExecuteQuery(res,"delete from "+stbl_terr+" where id_terr=" + IntToStr(terr_id));
  m_api->dbExecuteQuery(res,"delete from "+stbl_terr_str+" where id_terr="+IntToStr(terr_id));

  PrepareFields();
  }
}
//---------------------------------------------------------------------------
void __fastcall TFSprTerr::sBitBtn5Click(TObject *Sender)
{

if(sPanel1->Visible)
{
      /*  int width=sPanel1->Width;
        sPanel1->Visible=true;
        for(int i=width; i>=0;i-=4)
        {
           sPanel1->Width=i;
           Sleep(10);
          Application->ProcessMessages();
       }

        sPanel1->Width=width;
*/
       sPanel3->Enabled=true;
       sPanel1->Visible=false;
       LV->Align=alClient;
       ShowStatusFields(true);
}
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if(Key==27)Close();
}
//---------------------------------------------------------------------------


void __fastcall TFSprTerr::straniDrawItem(TWinControl *Control, int Index,
      TRect &Rect, TOwnerDrawState State)
{
  strani->Canvas->FillRect(Rect);
  if (State.Contains(odSelected))strani->Canvas->Brush->Color=(TColor)RGB(200,200,255);
  else
    {
     if(strani->Checked[Index])  strani->Canvas->Brush->Color =(TColor)RGB(255,200,200);
     else
     {
     div_t t=div(Index,2);
     if(t.rem==0)strani->Canvas->Brush->Color = (TColor)RGB(200,255,200);
     if(t.rem==1)strani->Canvas->Brush->Color = clWhite;
     }
    }
  strani->Canvas->FillRect(Rect);
  strani->Canvas->TextOut(Rect.Left, Rect.Top,strani->Items->Strings[Index]);
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::BBUnloadClick(TObject *Sender)
{
   //�������� ������������ � XML
   //���������� ����� ����� ������ ���� �����������, ��������� ������ ���������� � ������, ����������� � ���
   int res;
  AnsiString terr = "vzr174Pr_terr_user";
  AnsiString terr_str = "vzr174Pr_terr_str_user";

   TSaveDialog *sd=new TSaveDialog(this);
   sd->Filter="��������� XML (*.xml)|*.xml";
   if(sd->Execute())
   {
          _di_IXMLDocument XMLDoc = NewXMLDocument();
          InitXMLDoc(XMLDoc);
         _di_IXMLNode Root = XMLDoc->DocumentElement,node1,node2,node3,node4;

         node1=Root->AddChild("territory");
         TADOQuery *qw=m_api->dbGetCursor(res,"select * from " + terr);
         node1->Attributes["Count"] =IntToStr(qw->RecordCount);
         for(int i=0; i<qw->RecordCount;i++)
         {
          node2=node1->AddChild("territory_"+IntToStr(i));
          m_api->XML_Save_Query_Row(res, node2,qw);
          //�������� ����������� � ���������� ������
          TADOQuery *qw_str=m_api->dbGetCursor(res,"select * from "+terr_str+" where id_terr="+ qw->FieldByName("id_terr")->AsString);
          node3=node2->AddChild("strani");
          node3->Attributes["Count"]=IntToStr(qw_str->RecordCount);
          for(int j=0; j<qw_str->RecordCount;j++)
          {
           node4=node3->AddChild("strani_"+IntToStr(j));
           m_api->XML_Save_Query_Row(res, node4,qw_str);
           qw_str->Next();
          }

          qw->Next();
        m_api->dbCloseCursor(res,qw_str);
         }

    m_api->dbCloseCursor(res,qw);      
   XMLDoc->SaveToFile(ChangeFileExt(sd->FileName,".xml"));

   }

   delete sd;

}
//---------------------------------------------------------------------------
void TFSprTerr::InitXMLDoc(_di_IXMLDocument XMLDoc)
{
   XMLDoc->Active = true;
   XMLDoc->Options.Clear();
   XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;

   XMLDoc->Version       = "1.0";
   XMLDoc->Encoding      = "WINDOWS-1251";
   XMLDoc->StandAlone    = "no";
   XMLDoc->NodeIndentStr = "         ";

   _di_IXMLNode Root = XMLDoc->CreateNode("ROOT");
   XMLDoc->DocumentElement = Root;
   Root->Attributes["XML_Gen_Date"]     = AnsiString(Now().DateTimeString());
   Root->Attributes["Internal_version"] = AnsiString("0.0.0.1");
   Root->Attributes["Module"]           = AnsiString("VZR");
   Root->Attributes["Spr"]=AnsiString("Territory");
}


//------------------------------------------------------------------------------
void __fastcall TFSprTerr::BBLoadClick(TObject *Sender)
{
  int res;

  AnsiString terr = "vzr174Pr_terr_user";
  AnsiString terr_str = "vzr174Pr_terr_str_user";

  if(m_api->dbGetIntFromQuery(res,"select count(*) from " + terr)>0)
  {
     int rezult=Application->MessageBox("� ��� ��� ������� ���������� � �����������. ������� ��������� ���������� ��� ��������?\r\n(�� - �������, ��� - �� �������, �������� � ������������, ������ - �������� ��������)",
                                        "�������� ������������ ����������",
                                        MB_YESNOCANCEL | MB_ICONQUESTION | MB_DEFBUTTON3);
     if(rezult==2) return;
     if(rezult==6)
     {
      m_api->dbExecuteQuery(res,"delete from " + terr);
      m_api->dbExecuteQuery(res,"delete from " + terr_str);
     }
  }

  // �������� ����������� ���������� �� XML
  TOpenDialog *od=new TOpenDialog(this);
  od->Filter="��������� XML (*.xml)|*.xml";
  if(od->Execute())
  {
     _di_IXMLDocument XMLDoc = NewXMLDocument();
      InitXMLDoc(XMLDoc);
      XMLDoc->LoadFromFile(od->FileName);
      _di_IXMLNode node1, node2, node3,node4;
      _di_IXMLNode Root = XMLDoc->DocumentElement;
      if(Root->Attributes["Module"]==AnsiString("VZR") &&  Root->Attributes["Spr"]==AnsiString("Territory"))
      {
                node1=Root->ChildNodes->FindNode("territory");
                long id_territory=0;
                long id_str_terr=0;
                int count_terr=StrToInt(node1->Attributes["Count"]);
                //�������  � �������� ����������
               for(int i=0; i<count_terr; i++)
               {
                id_territory =  m_api->dbGenerateUniqueId(res,terr,"id_terr");
                m_api->dbExecuteQuery(res,"insert into "+terr+" (id_terr) values("+IntToStr(id_territory)+")");
                TADOQuery *qw_terr=m_api->dbGetCursor(res,"select * from "+terr+" where id_terr="+ IntToStr(id_territory),false);
                node2=node1->ChildNodes->Nodes[i];
                m_api->XML_Load_Query_Row(res,node2,qw_terr,"EXCLUDE#id_terr#");

                      // �������� �����, ������������� � ����������
                      node3=node2->ChildNodes->FindNode("strani");
                      for(int j=0; j<StrToInt(node3->Attributes["Count"]);j++)
                      {
                          id_str_terr=m_api->dbGenerateUniqueId(res,terr_str,"id_terr_str");

                        m_api->dbExecuteQuery(res,"insert into "+terr_str+" (id_terr_str,id_terr) values("+IntToStr(id_str_terr)+","+IntToStr(id_territory)+")");
                        TADOQuery * qw_str=m_api->dbGetCursor(res,"select id_str from "+terr_str+" where id_terr_str="+ IntToStr(id_str_terr),false);
                        m_api->XML_Load_Query_Row(res,node3->ChildNodes->Nodes[j],qw_str,"EXCLUDE#id_str_terr#id_terr#");
                        m_api->dbCloseCursor(res,qw_str);
                      }

                m_api->dbCloseCursor(res,qw_terr);
               }
      PrepareFields();
      }
      else
      {
       Application->MessageBox("��������� ���� xml!!!","�������� ����������",MB_OK | MB_ICONERROR);
      }
  }
  delete od;
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::Button1Click(TObject *Sender)
{
TStringList *sl1=new TStringList();
TStringList *sl2=new TStringList();

int res;
m_api->Internal_Generate_Insert_Data_Table_Script(res,"vzr174Pr_terr",sl1);
m_api->Internal_Generate_Insert_Data_Table_Script(res,"vzr174Pr_terr_str",sl2);
sl1->SaveToFile("C:\\vzr174Pr_terr.txt");
sl2->SaveToFile("C:\\vzr174Pr_terr_str.txt");
delete sl1;
delete sl2;
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::ShowStatusFields(bool flag)
{
    //sBitBtn3->Enabled = flag;
    fstatus = flag;
    sBitBtn4->Enabled = flag;
    sBitBtn2->Enabled = flag;
}

void __fastcall TFSprTerr::LVSelectItem(TObject *Sender, TListItem *Item,
      bool Selected)
{
  if(Selected)
  {
    if(sPanel1->Visible)
    {
    TerrName->Text=LV->Selected->Caption;
    int res;
    long terr_id;
    AnsiString
      stbl_terr_str,
      stbl_terr;
  if(((long)LV->Selected->Data & FLAG_USER) == FLAG_USER)
  {
    stbl_terr_str = "vzr174Pr_terr_str_user";
    stbl_terr = "vzr174Pr_terr_user";
    terr_id = (long)LV->Selected->Data & ~FLAG_USER;
  }
  else
  {
    stbl_terr_str = "vzr174Pr_terr_str";
    stbl_terr = "vzr174Pr_terr";
    terr_id = (long)LV->Selected->Data;
  }
        TADOQuery *qw=m_api->dbGetCursor(res,"select * from "+stbl_terr_str+" where id_terr="+ IntToStr(terr_id));
        for(int i=0; i<strani->Count;i++) strani->Checked[i]=false;
        for(int i=0; i<qw->RecordCount;i++)
        {
         strani->Checked[strani->Items->IndexOfObject((TObject*)qw->FieldByName("id_str")->AsInteger)]=true;
         qw->Next();
        }
        CheckBox1->Checked=m_api->dbGetBoolFromQuery(res,"select engl_name from "+stbl_terr+" where id_terr=" + IntToStr(terr_id));
        CBSelectCountry->Checked=m_api->dbGetBoolFromQuery(res,"select select_country from "+stbl_terr+" where id_terr=" + IntToStr(terr_id));
        CBDisableFR->Checked=m_api->dbGetBoolFromQuery(res,"select disable_fr_main_risk from "+stbl_terr+" where id_terr=" + IntToStr(terr_id));
    }
    ShowStatusFields((FLAG_USER & (long)Item->Data) == FLAG_USER);
  }
}
//---------------------------------------------------------------------------
AnsiString __fastcall TFSprTerr::SwitchRusLat(AnsiString in, bool flag)
{
  TStringList *lst = new TStringList();
  AnsiString out;
  TReplaceFlags rf;
        rf<<rfReplaceAll;

  lst->Delimiter = ',';
  lst->DelimitedText = in;
  TADOQuery *pQ = m_api->dbGetCursor(m_Res, "select CountryName, CountryLatName from vzr174Pr_country");
  for(int i = 0; i < lst->Count; i++)
  {
    if(pQ->Locate((flag)?"CountryName":"CountryLatName", (*lst)[i], TLocateOptions () << loCaseInsensitive))
    {
      AnsiString sss = pQ->FieldByName((flag)?"CountryLatName":"CountryName")->AsString;
      lst->Strings[i] = sss;
    }
    else
    {
      AnsiString smes = "������������ \"" + (*lst)[i] + "\" � ����������� �����������. ������ ������������ ����� \",\".";
      Application->MessageBox(smes.c_str(),"",0);
      lst->DelimitedText = "";
      break;
    }
  }
  m_api->dbCloseCursor(m_Res, pQ);
  out = lst->DelimitedText;
  out = StringReplace(out,"\"","",rf);
  lst->Clear();
  delete lst;

  return out;
}
void __fastcall TFSprTerr::sBRus_LatClick(TObject *Sender)
{
  TerrName->Text = SwitchRusLat(TerrNameRus->Text, true);
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::terrDrawItem(TWinControl *Control, int Index,
      TRect &Rect, TOwnerDrawState State)
{
  terr->Canvas->FillRect(Rect);
  if (State.Contains(odSelected))terr->Canvas->Brush->Color=(TColor)RGB(200,200,255);
  else
    {
     if(terr->Checked[Index])  terr->Canvas->Brush->Color =(TColor)RGB(255,200,200);
     else
     {
     div_t t=div(Index,2);
     if(t.rem==0)terr->Canvas->Brush->Color = (TColor)RGB(200,255,200);
     if(t.rem==1)terr->Canvas->Brush->Color = clWhite;
     }
    }
  terr->Canvas->FillRect(Rect);
  terr->Canvas->TextOut(Rect.Left, Rect.Top,terr->Items->Strings[Index]);
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::terrClickCheck(TObject *Sender)
{
 // MakeTerrName();
}
//---------------------------------------------------------------------------

void __fastcall TFSprTerr::straniClickCheck(TObject *Sender)
{
//  MakeTerrName();
}
//---------------------------------------------------------------------------
void __fastcall TFSprTerr::MakeTerrName(){
  if(!fstatus) return;

  AnsiString
    TerrNameRusl = "",
    TerrNamel = "";
  int
    idtmp = 0,
    res = 0,
    chCount = 0;
  TADOQuery *pQ;
  bool ecomma = false;

  for(int i = 0; i < terr->Count; i++)
    if(terr->Checked[i])
      chCount ++;
  for(int i = 0, j = 0 ; i < terr->Count; i++)
    if(terr->Checked[i]){
      idtmp = (int)terr->Items->Objects[i];
      pQ = m_api->dbGetCursor(m_Res, "select terr_name, terr_name_rus from vzr174pr_terr where id_terr = " + IntToStr(idtmp));
      TerrNameRusl += pQ->FieldByName("terr_name_rus")->AsString;
      TerrNamel += pQ->FieldByName("terr_name")->AsString;
      m_api->dbCloseCursor(res, pQ);
      j++;
      if(j != chCount){
        TerrNameRusl += ",";
        TerrNamel += ",";
      }
    }
  if(chCount > 0)
    ecomma = true;
  chCount = 0;
  for(int i = 0; i < strani->Count; i++)
    if(strani->Checked[i])
      chCount ++;
  if(ecomma && (chCount > 0)){
        TerrNameRusl += ",";
        TerrNamel += ",";
  }
  for(int i=0, j = 0 ; i < strani->Count ;i++)
    if(strani->Checked[i]){
      idtmp = (int)strani->Items->Objects[i];
      pQ = m_api->dbGetCursor(m_Res, "select CountryName, CountryLatName from vzr174Pr_country where id = " + IntToStr(idtmp));
      TerrNameRusl += pQ->FieldByName("CountryName")->AsString;
      TerrNamel += pQ->FieldByName("CountryLatName")->AsString;
      m_api->dbCloseCursor(res, pQ);
      j++;
      if(j != chCount){
        TerrNameRusl += ",";
        TerrNamel += ",";
      }
    }
  TerrNameRus->Text = TerrNameRusl;
  TerrName->Text = TerrNamel;
}
