//---------------------------------------------------------------------------
#ifndef Project_H
#define Project_H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include "sCustomComboEdit.hpp"
#include "sGroupBox.hpp"
#include "sLabel.hpp"
#include "sComboBox.hpp"
#include "sCurrEdit.hpp"
#include "Tmops_api.h"
//---------------------------------------------------------------------------
class TProject
{
private:
        AnsiString TableName;
        AnsiString ProductIDList;
        AnsiString TerrIDList;

        TWinControl* Parent;
        TsGroupBox* gbProjects;
        TsCalcEdit* ceKoef;

         double min_koef;
         double max_koef;
        mops_api_008* m_api;
        mops_api_008* l_api;

        void __fastcall LoadCBProjects();

        void __fastcall ceKoefChange(TObject* Sender);


public:
        TsComboBox* CBProjects;

        __fastcall TProject(TWinControl* aParent, mops_api_008* aAPI, AnsiString aTableName, AnsiString aProductIDList, AnsiString aTerrIDList);

        void __fastcall LoadFromSKK();
        bool __fastcall CalcKoefsExists();

        void __fastcall CBProjectsChange(TObject* Sender);

        void __fastcall SetBounds(TRect* aRect, AnsiString aAlign = "");

        void __fastcall SetProductIDList(AnsiString aProductIDList);
        void __fastcall SetKoefVisible(bool aValue);

        double __fastcall GetKoef();
        int __fastcall GetProjectID();
        void __fastcall SetKoef(double value);
        long __fastcall GetID();
        bool __fastcall ValidateKoef(AnsiString &error_description);

        void __fastcall (__closure(*UserFunc))();

};
//---------------------------------------------------------------------------
#endif
