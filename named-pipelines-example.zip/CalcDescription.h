//---------------------------------------------------------------------------
#ifndef CalcDescriptionH
#define CalcDescriptionH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "FrameCalc_c.h"
//---------------------------------------------------------------------------
class TFCalcDescription : public TFrame
{
__published:	// IDE-managed Components
        TMemo *Memo;
private:	// User declarations
         TWndMethod OldWP;
   void __fastcall NewWP(TMessage &Msg);

public:		// User declarations
        __fastcall TFCalcDescription(TComponent* Owner);
        TFrameCalc *fc;







};
//---------------------------------------------------------------------------
extern PACKAGE TFCalcDescription *FCalcDescription;
//---------------------------------------------------------------------------
#endif
