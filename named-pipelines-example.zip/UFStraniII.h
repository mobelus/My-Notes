//---------------------------------------------------------------------------

#ifndef UFStraniIIH
#define UFStraniIIH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPageControl.hpp"
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
#include "TMops_api.h"
#include "sTabControl.hpp"
#include "sAlphaListBox.hpp"
#include "sButton.hpp"
#include "sCheckListBox.hpp"

class TFSraniII : public TForm
{
__published:	// IDE-managed Components
  TsPageControl *sPgC;
  TsTabSheet *sTabSheet1;
  TsTabSheet *sTabSheet2;
  TsTabSheet *sTabSheet3;
  TsTabSheet *sTabSheet4;
  TsButton *sButton1;
  TsButton *sButton2;
  TsCheckListBox *sChLBShengen;
  TsCheckListBox *sChLBSIG;
  TsCheckListBox *sChLBOther;
  TsCheckListBox *sChLBUser;
private:	// User declarations
public:		// User declarations
  __fastcall TFSraniII(TComponent* Owner);
  __fastcall TFSraniII(TComponent* Owner, mops_api_023 *api);
  void __fastcall Init();
};
//---------------------------------------------------------------------------
extern PACKAGE TFSraniII *FSraniII;
//---------------------------------------------------------------------------
#endif

