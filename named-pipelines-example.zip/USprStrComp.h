//---------------------------------------------------------------------------

#ifndef USprStrCompH
#define USprStrCompH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sListView.hpp"
#include <ComCtrls.hpp>
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "Tmops_api.h"
#include "sCustomComboEdit.hpp"
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TFSprStrComp : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel2;
        TsPanel *sPanel1;
        TsPanel *sPanel3;
        TsBitBtn *sBitBtn1;
        TsPanel *sPanel4;
        TsBitBtn *sBitBtn2;
        TsListView *LV;
        TsLabel *sLabel1;
        TsLabel *sLabel2;
        TsEdit *LicNum;
        TsLabel *sLabel3;
        TsDateEdit *LicData;
        TsBitBtn *sBitBtn3;
        TsBitBtn *sBitBtn4;
        TsBitBtn *sBitBtn5;
        TLabel *Label1;
        TEdit *ENasPunkt;
  TComboBox *cbFilial;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
        void __fastcall sBitBtn3Click(TObject *Sender);
        void __fastcall sBitBtn4Click(TObject *Sender);
        void __fastcall sBitBtn5Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
        __fastcall TFSprStrComp(TComponent* Owner);
        mops_api_007* m_api;
        void __fastcall PrepareFields();
        int insert_update; //-1  - ������, 0 - update, 1- insert
};
//---------------------------------------------------------------------------
extern PACKAGE TFSprStrComp *FSprStrComp;
//---------------------------------------------------------------------------
#endif
