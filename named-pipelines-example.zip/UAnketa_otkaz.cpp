//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UAnketa_otkaz.h"
#include "UStrani.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sCustomComboEdit"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma link "sComboBox"
#pragma link "sBitBtn"
#pragma resource "*.dfm"
TFAnketa_otkaz *FAnketa_otkaz;
//---------------------------------------------------------------------------
__fastcall TFAnketa_otkaz::TFAnketa_otkaz(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------
void __fastcall TFAnketa_otkaz::PrepareFields(TList *list_anketa )
{
     ComboBox1->Clear();
      for(int i=0; i<list_anketa->Count;i++)
      {
      Zastrach_Data *zd=new Zastrach_Data( (*(Zastrach_Data *)list_anketa->Items[i]) );
      ComboBox1->Items->AddObject(zd->fio,(TObject*)zd);
      }
   ComboBox1->ItemIndex=0;
   ComboBox1Change(NULL);
}
//------------------------------------------------------------------------------
void __fastcall TFAnketa_otkaz::ComboBox1Change(TObject *Sender)
{
Zastrach_Data *zd=(Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex];
Edit1->Text=zd->address;
Edit2->Text=zd->tel;
Edit3->Text=zd->pasport_ser;
Edit4->Text=zd->pasport_num;
sDateEdit1->Date=zd->pasport_data_vidachi;
sDateEdit2->Date=zd->pasport_deystv_do;
sDateEdit3->Date=zd->pasport_date_rogd;
Edit5->Text=zd->pasport_gragdanstvo;
Edit6->Text=zd->mesto_raboti;
Edit7->Text=zd->strani_viezda;
Edit8->Text=zd->turist_firma;
Edit9->Text=zd->num_dogovor;
sDateEdit4->Date=zd->date_dogovor;
sDateEdit5->Date=zd->start_data_poezdki;
sDateEdit6->Date=zd->end_data_poezdki;
sComboBox1->ItemIndex=(int)zd->chron_zabolevan_yes;
Edit10->Visible=zd->chron_zabolevan_yes;
Label18->Visible=zd->chron_zabolevan_yes;
Edit10->Text=zd->chron_zabolevan;
sComboBox2->ItemIndex=(int)zd->beremennost_yes;
Edit11->Visible=zd->beremennost_yes;
Edit11->Text=zd->beremennost;
sComboBox3->ItemIndex=(int)zd->rodstv_v_stacionare_yes;
Edit12->Visible=zd->rodstv_v_stacionare_yes;
Edit12->Text=zd->rodstv_v_stacionare;
sComboBox4->ItemIndex=(int)zd->otkaz_v_vise_yes;
Edit13->Visible=zd->otkaz_v_vise_yes;
Label22->Visible=zd->otkaz_v_vise_yes;
Edit13->Text=zd->otkaz_v_stranu;
sComboBox5->ItemIndex=(int)zd->otmetki_v_deystv_pasporte_yes;
sComboBox6->ItemIndex=(int)zd->otmetki_v_starom_pasporte_yes;
sComboBox7->ItemIndex=(int)zd->zakl_dogovor_yes;
sComboBox8->Visible=zd->zakl_dogovor_yes;
Label26->Visible=zd->zakl_dogovor_yes;
sComboBox8->ItemIndex=(int)zd->obrasch_za_vozmecheniem_yes;
Edit14->Visible=zd->obrasch_za_vozmecheniem_yes;
Edit14->Text=zd->obrasch_za_vozmecheniem;
Edit15->Text=zd->stoimost_poezdki;
Edit16->Text=zd->reshenie_strachovshika;
}
//------------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit2Change(TObject *Sender)
{
((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->tel=Edit2->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit3Change(TObject *Sender)
{
((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->pasport_ser=Edit3->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit4Change(TObject *Sender)
{
((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->pasport_num=Edit4->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sDateEdit1Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->pasport_data_vidachi=sDateEdit1->Date;
}
//---------------------------------------------------------------------------


void __fastcall TFAnketa_otkaz::sDateEdit2Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->pasport_deystv_do=sDateEdit2->Date;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sDateEdit3Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->pasport_date_rogd=sDateEdit3->Date;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit5Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->pasport_gragdanstvo =Edit5->Text;        
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit6Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->mesto_raboti=Edit6->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit7Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->strani_viezda=Edit7->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit8Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->turist_firma=Edit8->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit9Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->num_dogovor=Edit9->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sDateEdit4Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->date_dogovor=sDateEdit4->Date;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sDateEdit5Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->start_data_poezdki=sDateEdit5->Date;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sDateEdit6Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->end_data_poezdki=sDateEdit6->Date;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox1Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->chron_zabolevan_yes=(bool)sComboBox1->ItemIndex;
 if(sComboBox1->ItemIndex==0)
 {
  Label18->Visible=false;
  Edit10->Visible=false;
  Edit10->Text="";
  Edit10Change(NULL);
 }

 if(sComboBox1->ItemIndex==1)
 {
  Label18->Visible=true;
  Edit10->Visible=true;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit10Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->chron_zabolevan=Edit10->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox2Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->beremennost_yes=(bool)sComboBox2->ItemIndex;
 if(sComboBox2->ItemIndex==0)
 {
  Edit11->Visible=false;
  Edit11->Text="";
  Edit11Change(NULL);
 }
 if(sComboBox2->ItemIndex==1)
 {
  Edit11->Visible=true;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit11Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->beremennost=Edit11->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox3Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->rodstv_v_stacionare_yes=(bool)sComboBox3->ItemIndex;
 if(sComboBox3->ItemIndex==0)
 {
 Edit12->Visible=false;
 Edit12->Text="";
 Edit12Change(NULL);
 }
 if(sComboBox3->ItemIndex==1)
 {
  Edit12->Visible=true;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit12Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->rodstv_v_stacionare=Edit12->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox4Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->otkaz_v_vise_yes=(bool) sComboBox4->ItemIndex;
 if(sComboBox4->ItemIndex==0)
 {
 Label22->Visible=false;
 Edit13->Visible=false;
 Edit13->Text="";
 Edit13Change(NULL);
 }

 if(sComboBox4->ItemIndex==1)
 {
  Label22->Visible=true;
  Edit13->Visible=true;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit13Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->otkaz_v_stranu=Edit13->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox5Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->otmetki_v_deystv_pasporte_yes=(bool)sComboBox5->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox6Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->otmetki_v_starom_pasporte_yes=(bool)sComboBox6->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox7Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->zakl_dogovor_yes=(bool)sComboBox7->ItemIndex;
 if(sComboBox7->ItemIndex==0)
 {
  Label26->Visible=false;
  sComboBox8->Visible=false;
  sComboBox8->ItemIndex=0;
  sComboBox8Change(NULL);
 }

 if(sComboBox7->ItemIndex==1)
 {
    Label26->Visible=true;
    sComboBox8->Visible=true;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sComboBox8Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->obrasch_za_vozmecheniem_yes=(bool)sComboBox8->ItemIndex;
 if(sComboBox8->ItemIndex==0)
 {
  Edit14->Visible=false;
  Edit14->Text="";
  Edit14Change(NULL);

 }

 if(sComboBox8->ItemIndex==1)
 {
  Edit14->Visible=true;
 }
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit14Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->obrasch_za_vozmecheniem=Edit14->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit15Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->stoimost_poezdki=Edit15->Text;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::Edit16Change(TObject *Sender)
{
 ((Zastrach_Data *)ComboBox1->Items->Objects[ComboBox1->ItemIndex])->reshenie_strachovshika=Edit16->Text;
}
//---------------------------------------------------------------------------
AnsiString Zastrach_Data::CheckData()
{

if(this->fio=="") return "�� �������� ���";
if(this->address=="") return "�� ������ �����!";
if(this->tel=="") return "�� ������ ����� ��������!";
if(this->pasport_ser=="") return "�� ������� ����� �������� ";
if(this->pasport_num=="")return "�� ������� ����� ��������";
if(this->pasport_data_vidachi==(TDateTime)NULL) return "�� ������� ���� ������ ��������";
if(this->pasport_deystv_do==(TDateTime)NULL) return "�� ������� ���� ��������� ����� �������� ��������";
if(this->pasport_date_rogd==(TDateTime)NULL) return "�� ������� ���� ��������";
if(this->pasport_gragdanstvo=="") return "�� ������� �����������";
if(this->mesto_raboti=="") return "�� ������� ����� ������";
if(this->strani_viezda=="") return "�� ������� ������(�) ������";
if(this->turist_firma=="") return "�� ������� ������������� �����";
if(this->num_dogovor=="") return "�� ������ ����� ��������";
if(this->date_dogovor==(TDateTime)NULL) return "�� ������ ���� ��������";
if(this->start_data_poezdki==(TDateTime)NULL) return "�� ������� ���� ������ �������";
if(this->end_data_poezdki==(TDateTime)NULL) return "�� ������� ���� ��������� �������";
if(this->chron_zabolevan_yes==true && this->chron_zabolevan=="") return "�� �������, ����� ����������� ����������� �������";
if(this->beremennost_yes==true && this->beremennost=="") return "�� ������� ���������� ��� ������������";
if(this->rodstv_v_stacionare_yes==true && this->rodstv_v_stacionare=="") return "�� ������� ������������, ����������� � ����������";
if(this->otkaz_v_vise_yes==true && this->otkaz_v_stranu=="") return "�� ������� ������, � ������� ��� ����� � ��������� ����";
if(this->zakl_dogovor_yes==true && this->obrasch_za_vozmecheniem_yes==true && this->obrasch_za_vozmecheniem=="") return "�� ������� ���������� �� �����";
if(this->stoimost_poezdki=="") return "�� ������� ��������� �������";
if(this->reshenie_strachovshika=="") return "�� ������� ������� �����������";
return "";
};


void __fastcall TFAnketa_otkaz::sBitBtn1Click(TObject *Sender)
{
AnsiString err="";
for(int i=0; i<ComboBox1->Items->Count;i++)
{
 err=((Zastrach_Data *)ComboBox1->Items->Objects[i])->CheckData();
   if(err!="")
     {
     MessageDlg( " � ��������������� "  + ((Zastrach_Data *)ComboBox1->Items->Objects[i])->fio + " " + err,mtInformation, TMsgDlgButtons() << mbOK, 0);
     return;
     }
}
if(err=="")
this->ModalResult=mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TFAnketa_otkaz::sBitBtn3Click(TObject *Sender)
{
//---������� ������
TFStrani *fs=new TFStrani(this);
fs->m_api=(mops_api_007*)m_api;
fs->id_terr=id_terr;
fs->Init(Edit7->Text);

if(fs->ShowModal()==mrOk) Edit7->Text=fs->stran;

fs->Free();
}
//---------------------------------------------------------------------------

