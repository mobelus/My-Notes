//---------------------------------------------------------------------------


#pragma hdrstop

#include "KFree.h"

//---------------------------------------------------------------------------
CBaseKoeffFree::CBaseKoeffFree(IFree *f)
  :m_Iframe(f), m_DesK("") {}

double CBaseKoeffFree::CalcKoeff(){
  AnsiString  err;

  try{
  if(!m_Iframe->getFree_I(m_Koeff))
    return 0;
  }catch(Exception &e){
    err = e.Message;
  }
  m_DesK = FloatToStr(m_Koeff);
  return m_Koeff;
}
#pragma package(smart_init)

