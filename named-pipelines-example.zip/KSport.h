//---------------------------------------------------------------------------

#ifndef KSportH
#define KSportH

#include "Ikoeff.h"
#include "IFrame.H"

class CBaseKoeffSport:public IBaseKoeff{
  ISport *m_Iframe;
  double m_Koeff;
  AnsiString m_DesK;
  int m_pridSport;
  TCT m_prTypeTariff;
protected :
  TCT m_TypeTariff;
  AnsiString m_SQLf;
public:
  CBaseKoeffSport(ISport *f, TCT tt);
  AnsiString NKoeff_I()     { return "Ksp";};
  AnsiString DescKoeff_I()  { return "���������� �����:";};
protected :
  virtual double     getKoeff_I(){return m_Koeff;};
  virtual double     calcKoeff_I(){return CalcKoeff();};
  virtual AnsiString getDescDBKoeff_I(){return m_DesK;};
protected :
  double  CalcKoeff();
  virtual bool GetDBQuery(int);
};

class CUKoeffSport:public CBaseKoeffSport{
public :
  CUKoeffSport(ISport *f, TCT tt)
      :CBaseKoeffSport(f, tt){};
protected :
  virtual bool GetDBQuery(int);
};

class CPartnerKoeffSport:public CUKoeffSport{
public :
  CPartnerKoeffSport(ISport *f, TCT tt)
      :CUKoeffSport(f, tt){};
protected :
  virtual bool GetDBQuery(int);
};

class CIVCKoeffSport:public CPartnerKoeffSport{
public :
  CIVCKoeffSport(ISport *f, TCT tt)
      :CPartnerKoeffSport(f, tt){};
protected :
  virtual bool GetDBQuery(int);
};

//---------------------------------------------------------------------------
#endif

