//---------------------------------------------------------------------------


#pragma hdrstop

#include "KCountIns.h"
#include "BaseVZRMod.h"

//---------------------------------------------------------------------------
const char* qkCIns = "SELECT %s  from VZR174Pr_Koeff_Count_Ins where rengs <= %d and %d <=renge and id_type_calc = %d";

CBaseKoeffCountIns::CBaseKoeffCountIns(ICountIns *f, TCT tt)
  :m_Iframe(f), m_TypeTariff(tt){}

double CBaseKoeffCountIns::CalcKoeff(){
  AnsiString err;
  int countIns = 0;

  try{
  if(!m_Iframe->getCountIns_I(countIns))
    return 0;
  if(m_prTypeTariff == m_TypeTariff && (m_prcountIns == countIns))
    return m_Koeff;
  m_prTypeTariff = m_TypeTariff;
  m_prcountIns = countIns;
  }catch(Exception &e){
    err = e.Message;
  }
  m_Koeff = GetDBQuery(countIns);
  m_DesK = FloatToStr(m_Koeff) + " (�������������� " + IntToStr(countIns) + " �������)";
  return m_Koeff;
}

double CBaseKoeffCountIns::GetDBQuery(int c){
//     lKoefCountIns = gfK("VZR174Pr_Koeff_Count_Ins"," (rengs <= " + IntToStr(countIns) + " and " + IntToStr(countIns) + " <=renge)","id","K");
 double Koeff;
  if(gAPI->dbGetIntFromQuery(gRes, m_SQLf.sprintf(qkCIns, "count(*)",  c, c,(int)m_TypeTariff)) > 0){
    TADOQuery *pq = gAPI->dbGetCursor(gRes, m_SQLf.sprintf(qkCIns, "K, title", c, c,(int)m_TypeTariff));
    Koeff = pq->FieldByName("K")->AsFloat;
    m_DesK = FloatToStr(m_Koeff) + " (" + pq->FieldByName("title")->AsString + ")";
    gAPI->dbCloseCursor(gRes, pq);
    return Koeff;
  }
  return -1;
}

double CUKoeffCountIns::GetDBQuery(int c){
  double Koeff = CBaseKoeffCountIns::GetDBQuery(c);
  if(Koeff<0){
    m_TypeTariff = eROZNICA_FIZ;
    return CBaseKoeffCountIns::GetDBQuery(c);
  }else return Koeff;
}


#pragma package(smart_init)

