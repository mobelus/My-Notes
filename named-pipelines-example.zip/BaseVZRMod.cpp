//---------------------------------------------------------------------------

#pragma hdrstop

#include "BaseVZRMod.h"

CBaseVZRMod::CBaseVZRMod()
    : m_TT(eTCTNULL), m_KIt(m_K.begin())
{
  m_QTT = gAPI->dbGetCursor(gRes, "select * from VZR174Pr_type_calc");
}

//---------------------------------------------------------------------------
CBaseVZRMod::~CBaseVZRMod(){
  FreeKoeffI();
}

double CBaseVZRMod::Calculat(){
  double dw = 1;

  for(m_KIt = m_K.begin(); m_KIt != m_K.end(); m_KIt++)
    dw *= (*m_KIt)->calcKoeff_I();

  return dw;
};

int CBaseVZRMod::CheckForm(int param){
  return 0;
};

AnsiString CBaseVZRMod::FormatDescriptionCalc(const char * fmt){
  return "";
};

void CBaseVZRMod::TarifVar(TCT t){
  if(m_TT == t) return;
  m_K.clear();
  m_K.push_back((LPKoeff)new CBaseKoeffFree(m_IFree));//[0]
  switch(t){
    case eROZNICA_FIZ:
          m_K.push_back(new CBaseKoeffTerritory(m_ITerr, eROZNICA_FIZ));//[1]
          m_K.push_back(new CBaseKoeffSport(m_ISport, eROZNICA_FIZ));//[2]
          m_K.push_back(new CBaseKoeffProfession(m_IProf, eROZNICA_FIZ));//[3]
          m_K.push_back(new CBaseKoeffCountIns(m_ICountIns, eROZNICA_FIZ));//[4]
          m_K.push_back(new CBaseKoeffAge(m_IAge, eROZNICA_FIZ));//[5]
          m_K.push_back(new CBaseKoeffStudKoeff(m_IStudProg, eROZNICA_FIZ));//[6]
      break;
    case eROZNICA_UR:
          m_K.push_back(new CUKoeffTerritory(m_ITerr, eROZNICA_UR));
          m_K.push_back(new CUKoeffSport(m_ISport, eROZNICA_UR));
          m_K.push_back(new CUKoeffProfession(m_IProf, eROZNICA_UR));
          m_K.push_back(new CUKoeffCountIns(m_ICountIns, eROZNICA_UR));
          m_K.push_back(new CUKoeffAge(m_IAge, eROZNICA_UR));
          m_K.push_back(new CUKoeffStudKoeff(m_IStudProg, eROZNICA_UR));
      break;
    case ePARTNER_UR:
          m_K.push_back(new CPartnerKoeffTerritory(m_ITerr, ePARTNER_UR));
          m_K.push_back(new CPartnerKoeffSport(m_ISport, ePARTNER_UR));
          m_K.push_back(new CPartnerKoeffProfession(m_IProf, ePARTNER_UR));
          m_K.push_back(new CPartnerKoeffCountIns(m_ICountIns, ePARTNER_UR));
          m_K.push_back(new CPartnerKoeffAge(m_IAge, ePARTNER_UR));
          m_K.push_back(new CPartnerKoeffStudKoeff(m_IStudProg, ePARTNER_UR));
      break;
    case eIVC:
          m_K.push_back(new CIVCKoeffTerritory(m_ITerr, eIVC));
          m_K.push_back(new CIVCKoeffSport(m_ISport, eIVC));
          m_K.push_back(new CIVCKoeffProfession(m_IProf, eIVC));
          m_K.push_back(new CIVCKoeffCountIns(m_ICountIns, eIVC));
          m_K.push_back(new CIVCKoeffAge(m_IAge, eIVC));
          m_K.push_back(new CIVCKoeffStudKoeff(m_IStudProg, eIVC));
      break;
  };
  m_TT = t;
}

void CBaseVZRMod::FreeKoeffI(){
  for(m_KIt = m_K.begin(); m_KIt != m_K.end(); m_KIt++)
    delete (*m_KIt);
  m_K.clear();
  m_TT = eTCTNULL;
}

//---------------------------------------------------------------------------
void CBaseVZRMod::gfID(AnsiString tbl, AnsiString sWhere, AnsiString sID, int &idK){
  AnsiString sSQL;
  AnsiString sIDTT = IntToStr((int)m_TT);

  if(gAPI == NULL)
    return;
  for(int i = 0;i < m_QTT->RecordCount;i++){
    sSQL = "select " + sID + " from " + tbl + " where " + sWhere + " and id_type_calc = " + sIDTT;
    idK = gAPI->dbGetIntFromQuery(gRes, sSQL);
    if(!tbl.IsEmpty() && (idK > 0))
      return;
    else
      sIDTT = GetTTParent(sIDTT);
  }
}

double CBaseVZRMod::gfK(AnsiString tbl, AnsiString sWhere, AnsiString sID, AnsiString sK){
  AnsiString sSQL;
  AnsiString sIDTT = IntToStr((int)m_TT);

  if(gAPI == NULL)
    return -1;
  for(int i = 0;i < m_QTT->RecordCount;i++) {
//    sSQL = "select " + sID + " from " + tbl + " where " + sWhere + " and id_type_calc = " + sIDTT;
//    if(gAPI->dbGetIntFromQuery(gRes, sSQL) > 0) {
      sSQL = "select " + sK + " from " + tbl + " where " + sWhere + " and id_type_calc = " + sIDTT;
      double prem = gAPI->dbGetFloatFromQuery(gRes, sSQL);
      if(prem>0)
        return prem;
//    }
    else
      sIDTT = GetTTParent(sIDTT);
  }

  return -1;
}

double CBaseVZRMod::gfK1(AnsiString from, AnsiString tbl1, AnsiString sWhere, AnsiString sID, AnsiString sK){
  AnsiString sSQL;
  AnsiString sIDTT = IntToStr((int)m_TT);

  if(gAPI == NULL)
    return -1;
  for(int i = 0;i < m_QTT->RecordCount;i++){
    sSQL = "select " + sID + " from " + from + " where " + sWhere + " and " + tbl1 + ".id_type_calc = " + sIDTT;
    if(gAPI->dbGetIntFromQuery(gRes, sSQL) > 0){
      sSQL = "select " + sK + " from " + from + " where " + sWhere + " and " + tbl1 + ".id_type_calc = " + sIDTT;
      return gAPI->dbGetFloatFromQuery(gRes, sSQL);
    }
    else
      sIDTT = GetTTParent(sIDTT);
  }

  return -1;
}

TADOQuery * CBaseVZRMod::gfQuery(AnsiString tbl, AnsiString sParam, AnsiString sWhere){
  AnsiString sSQL;
  AnsiString sIDTT = IntToStr((int)m_TT);
  TADOQuery *Qw;

  if(gAPI == NULL)
    return NULL;
  AnsiString s = (sWhere != "")?AnsiString(" and " + sWhere):AnsiString("");
  for(int i = 0;i < m_QTT->RecordCount;i++){
      Qw = gAPI->dbGetCursor(gRes, "select " + sParam + " from " + tbl + " where id_type_calc = " + sIDTT + s);
      if(Qw != NULL && (Qw->RecordCount > 0))
        return Qw;
      else
        sIDTT = GetTTParent(sIDTT);
  }
  return NULL;
}

TADOQuery * CBaseVZRMod::gfQuery2(AnsiString tbl, AnsiString sParam, AnsiString sWhere){
  AnsiString sSQL;
  AnsiString sIDTT = IntToStr((int)m_TT);
  TADOQuery *Qw;

  if(gAPI == NULL)
    return NULL;
  AnsiString s = (sWhere != "")?AnsiString(" and " + sWhere):AnsiString("");
  for(int i = 0;i < m_QTT->RecordCount;i++){
    Qw = gAPI->dbGetCursor(gRes, "select " + sParam + " from " + tbl + " where id_type_calc = " + sIDTT + s);
    if(Qw != NULL && (Qw->RecordCount > 0)){
      return Qw;
    }
    else
      sIDTT = GetTTParent(sIDTT);
  }
  return NULL;
}

TADOQuery * CBaseVZRMod::gfQuery1(AnsiString sParam, AnsiString from, AnsiString sWhere, AnsiString tbl){
  AnsiString sSQL;
  AnsiString sIDTT = IntToStr((int)m_TT);
  TADOQuery *Qw;

  if(gAPI == NULL)
    return NULL;
  AnsiString s = (sWhere != "")?AnsiString(" and " + sWhere):AnsiString("");
  for(int i = 0;i < m_QTT->RecordCount;i++){
    Qw = gAPI->dbGetCursor(gRes, "select " + sParam + " from " + from + " where " + tbl + ".id_type_calc = " + sIDTT + s);
    if(Qw != NULL && (Qw->RecordCount > 0)){
      return Qw;
    }
    else
      sIDTT = GetTTParent(sIDTT);
  }
  return NULL;
}

AnsiString CBaseVZRMod::gfQwTTf(AnsiString query, int tyVar){

  if(tyVar == 2)
    return query + " and id_type_calc = "   + IntToStr((int)m_TT);
  else if(tyVar == 3)
    return query + " where id_type_calc = " + IntToStr((int)m_TT);

  return query + " id_type_calc = "       + IntToStr((int)m_TT);
}

#pragma package(smart_init)
