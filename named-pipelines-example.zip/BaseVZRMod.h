//---------------------------------------------------------------------------

#ifndef BaseVZRModH
#define BaseVZRModH

#include "IVZR174Module.H"
#include "KTerr.H"
#include "KSport.H"
#include "KProfession.h"
#include "KFree.h"
#include "KCountIns.h"
#include "KAge.h"
#include "KStudProg.h"
#include <typeinfo>
#include <vector>
#include "Tmops_api.h"


#define ADD       1
#define ADDAND    2
#define ADDWHERE  3

//---------------------------------------------------------------------------
class CBaseVZRMod: public IVZR174Module {
  TCT           m_TT;
  //������������.
  vector<LPKoeff> m_K;
  vector<LPKoeff>::iterator m_KIt;
  //���������� ������������� � ������.
  ITerritory *  m_ITerr;
  ISport *      m_ISport;
  IProfession * m_IProf;
  IFree *       m_IFree;
  ICountIns *   m_ICountIns;
  IAge *        m_IAge;
  IStudProg *   m_IStudProg;

public:
  CBaseVZRMod();
  ~CBaseVZRMod();
template <class F>
  void InitIFrames(F IFrame){
    m_ISport =    (ISport*)IFrame;
    m_ITerr =     (ITerritory*)IFrame;
    m_IProf =     (IProfession*)IFrame;
    m_IFree =     (IFree*)IFrame;
    m_ICountIns = (ICountIns*)IFrame;
    m_IAge =      (IAge*)IFrame;
    m_IStudProg = (IStudProg*)IFrame;
    TarifVar(eROZNICA_FIZ);
  }
  double Calculat();
  int  CheckForm(int param);
  AnsiString FormatDescriptionCalc(const char *);
  void TarifVar(TCT t);
  TCT  GetTT(){return m_TT;};
  void FreeKoeffI();
protected:
  double  Calculat_I()      {return Calculat(); };
  void    TarifVar_I(TCT t) {TarifVar(t);       };
  void    Free_I()          {FreeKoeffI();      };
  LPKoeff KFree_I()         {return m_K[0];    };
  LPKoeff KTerr_I()         {return m_K[1];    };
  LPKoeff KSport_I()        {return m_K[2];    };
  LPKoeff KProf_I()         {return m_K[3];    };
  LPKoeff KCountIns_I()     {return m_K[4];    };
  LPKoeff KAge_I()          {return m_K[5];    };
  LPKoeff KStudProg_I()     {return m_K[6];    };
//�����������
private:
  TADOQuery * m_QTT;
public :
  int multitrip;
  void    gfID(AnsiString tbl, AnsiString sWhere, AnsiString sID, int &idK);
  double  gfK (AnsiString tbl, AnsiString sWhere, AnsiString sID, AnsiString sK);
  double  gfK1(AnsiString from, AnsiString tbl1, AnsiString sWhere, AnsiString sID, AnsiString sK);
  TADOQuery* gfQuery (AnsiString tbl, AnsiString sParam, AnsiString sWhere = "");
  TADOQuery* gfQuery1(AnsiString sParam, AnsiString from, AnsiString sWhere, AnsiString tbl);
  TADOQuery* gfQuery2(AnsiString tbl, AnsiString sParam, AnsiString sWhere = "");
  AnsiString  gfQwTTf (AnsiString query, int tyVar);
protected:
  AnsiString GetTTParent(AnsiString sIDTT){
      m_QTT->Filtered = false;
      m_QTT->Filter = "id_type_calc =" + sIDTT;
      m_QTT->Filtered = true;
      sIDTT = IntToStr(m_QTT->FieldByName("id_type_calc_parent")->AsInteger);
      m_QTT->Filtered = false;

    return sIDTT;
  };
};

extern CBaseVZRMod* gVZR;

extern mops_api_028* gAPI;
extern int gRes;
#endif

