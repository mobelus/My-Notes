#ifndef KTERRH
#define KTERRH

#include "ikoeff.h"
#include "IFrame.H"

class CBaseKoeffTerritory: public IBaseKoeff{
  ITerritory *m_Iframe;
  double m_Koeff;
  AnsiString m_DesK;
//��������� �������� ����������.
  TCT m_prTypeTariff;
  int m_pridTerr;
  AnsiString m_prStrani;
protected :
  TCT m_TypeTariff;
  int
    m_idForeignCountries,
    m_idSNG,
    m_idSchengen,
    m_idWorldwide;
  AnsiString m_SQLf;
public:
  CBaseKoeffTerritory(ITerritory *f, TCT tt);
  AnsiString NKoeff_I()     { return "Kt";};
  AnsiString DescKoeff_I()  { return "���������� �����������:";};
protected :
  virtual double getKoeff_I(){return m_Koeff;};
  virtual double calcKoeff_I(){return CalcKoeff();};
  virtual AnsiString getDescDBKoeff_I(){return m_DesK;};
protected :
  double  CalcKoeff();
  virtual double GetDBQuery(int);
  virtual AnsiString DesKoeff(double, int);
  virtual int GetIDWW(){return 296;};
};

class CUKoeffTerritory: public CBaseKoeffTerritory{
public:
  CUKoeffTerritory(ITerritory *f, TCT tt)
    :CBaseKoeffTerritory(f,tt){};
protected :
  virtual double GetDBQuery(int);
  virtual AnsiString DesKoeff(double);
  int GetIDWW(){return m_idWorldwide;};
};

class CPartnerKoeffTerritory: public CUKoeffTerritory{
public:
  CPartnerKoeffTerritory(ITerritory *f, TCT tt)
    :CUKoeffTerritory(f,tt){};
protected :
  virtual double GetDBQuery(int idC){return CUKoeffTerritory::GetDBQuery(idC);};
  virtual AnsiString DesKoeff(double k){return CUKoeffTerritory::DesKoeff(k);};
};

class CIVCKoeffTerritory: public CPartnerKoeffTerritory{
public:
  CIVCKoeffTerritory(ITerritory *f, TCT tt)
    :CPartnerKoeffTerritory(f,tt){};
protected :
  virtual double GetDBQuery(int idC){return CPartnerKoeffTerritory::GetDBQuery(idC);};
  virtual AnsiString DesKoeff(double k){return CPartnerKoeffTerritory::DesKoeff(k);};
};

#endif
