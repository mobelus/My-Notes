//---------------------------------------------------------------------------

#ifndef UAktRabotH
#define UAktRabotH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sComboBox.hpp"
#include "sLabel.hpp"
#include "sCustomComboEdit.hpp"
#include "sGroupBox.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "Tmops_api.h"
#include "sCurrEdit.hpp"
#include <ComCtrls.hpp>
#include "sSkinProvider.hpp"
#include "sSkinManager.hpp"
//---------------------------------------------------------------------------

class TFAktRabot : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsPanel *sPanel2;
        TsLabel *sLabel1;
        TsComboBox *sComboBox1;
        TsLabel *sLabel2;
        TsComboBox *sComboBox2;
        TsGroupBox *sGroupBox1;
        TsLabel *sLabel3;
        TsDateEdit *sDateEdit1;
        TsLabel *sLabel4;
        TsDateEdit *sDateEdit2;
        TsBitBtn *sBitBtn1;
        TsLabel *sLabel5;
        TsCalcEdit *sCalcEdit1;
        TsLabel *sLabel6;
        TsDateEdit *sDateEdit3;
        TsLabel *sLabel7;
        TsComboBox *sComboBox3;
        TsLabel *sLabel8;
        TsComboBox *sComboBox4;
        TsBitBtn *sBitBtn2;
        void __fastcall sBitBtn2Click(TObject *Sender);
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sComboBox1Change(TObject *Sender);
private:	// User declarations
bool PreView;
bool m_freport;
AnsiString m_qfr;
AnsiString nas_punkt;

  AnsiString __fastcall CreateQuery2FastReport();
public:		// User declarations
        __fastcall TFAktRabot(TComponent* Owner);
        mops_api_007* m_api;
        void PrepareFields();
        AnsiString SQL;


};
//---------------------------------------------------------------------------
extern PACKAGE TFAktRabot *FAktRabot;
//---------------------------------------------------------------------------
#endif
