#ifndef IFrameH
#define IFrameH

class IAge{
  public:
    virtual bool getAge_I(bool &, int &) = 0;
};

class ICountIns{
  public:
    virtual bool getCountIns_I(int &) = 0;
};

class IFree{
  public:
    virtual bool getFree_I(double &) = 0;
};

class IProfession{
  public:
    virtual bool getProfession_I(int &) = 0;
};

class ITerritory{
  public:
    virtual bool getCountry_I(int &, char **) = 0;
};

class ISport{
  public:
    virtual bool getSport_I(int &) = 0;
};

class IStudProg{
  public:
    virtual void getStudProg_I(bool &, bool &) = 0;
};
#endif //IFrameH
