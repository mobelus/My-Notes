//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "USprStrComp.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sListView"
#pragma link "sBitBtn"
#pragma link "sCustomComboEdit"
#pragma link "sEdit"
#pragma link "sLabel"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma resource "*.dfm"
TFSprStrComp *FSprStrComp;
//---------------------------------------------------------------------------
__fastcall TFSprStrComp::TFSprStrComp(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFSprStrComp::sBitBtn1Click(TObject *Sender) {
if(!sPanel1->Visible) {
        cbFilial->ItemIndex = -1;
        LicNum->Text="";
        LicData->Text="";


        insert_update=1;
        sPanel3->Enabled=false;
        LV->Align=alNone;
        int width=sPanel1->Width;
        sPanel1->Width=0;
        sPanel1->Visible=true;
        for(int i=0; i<=width;i+=4)
        {
        sPanel1->Width=i;
         Application->ProcessMessages();
        Sleep(10);
      }
}

}
//---------------------------------------------------------------------------
void __fastcall TFSprStrComp::sBitBtn2Click(TObject *Sender) {
int res;
if(sPanel1->Visible) {
          if(cbFilial->ItemIndex == -1 ) {
           Application->MessageBox("�������� ������","����������� ���", MB_OK | MB_ICONERROR);
           return;
          }

          if(ENasPunkt->Text=="")
          {
           Application->MessageBox("�� ������ ���������� ����� ������������ �����","����������� ���",MB_OK | MB_ICONERROR);
           return;
          }



          if(LicNum->Text=="")
          {
           Application->MessageBox("�� ������ ����� ��������","����������� ���",MB_OK | MB_ICONERROR);
           return;
          }

          TDateTime dt;
           if(LicData->Text=="  .  .    " || !TryStrToDate(LicData->Text,dt))
          {
           Application->MessageBox("�� ������� ���� �������� ��� ���� ����� �������� ������","����������� ���",MB_OK | MB_ICONERROR);
           return;
          }




          AnsiString sql="";
          //�������� ��������
          if(insert_update==0) // ���������� �������
          {
          sql="update vzr174Pr_str_comp set "
          " str_comp_name='" + cbFilial->Text + "',"
          "str_comp_nas_punkt='" + ENasPunkt->Text + "',"
          " lic_number='" + LicNum->Text + "',"
          " lic_data=" + m_api->Internal_Convert_Date_To_SQL(res,LicData->Text) +
          " where id_str_comp=" + IntToStr((int)LV->Selected->Data);

          }

          if(insert_update==1) //���������� �����
          {
           sql="insert into vzr174Pr_str_comp (id_str_comp,str_comp_name,str_comp_nas_punkt,lic_number,lic_data) values ("
           + IntToStr(m_api->dbGenerateId(res,"vzr174Pr_str_comp")) + ","
           + "'"+ cbFilial->Text + "',"
           + "'" + ENasPunkt->Text + "',"
           + "'" + LicNum->Text + "',"
           + m_api->Internal_Convert_Date_To_SQL(res,LicData->Text) +
           ")";

          }
      insert_update=-1;
      m_api->dbExecuteQuery(res,sql);







        int width=sPanel1->Width;
        sPanel1->Visible=true;
        for(int i=width; i>=0;i-=4)
        {
           sPanel1->Width=i;
           Sleep(10);
          Application->ProcessMessages();
       }
      sPanel3->Enabled=true;
        sPanel1->Visible=false;
        sPanel1->Width=width;
       LV->Align=alClient;
       PrepareFields();

}


}
//---------------------------------------------------------------------------
void __fastcall TFSprStrComp::sBitBtn3Click(TObject *Sender) {
if(LV->Selected==NULL) return;

if(!sPanel1->Visible) {
  cbFilial->ItemIndex = cbFilial->Items->IndexOf( LV->Selected->Caption );

  ENasPunkt->Text=LV->Selected->SubItems->Strings[0];
  LicNum->Text=LV->Selected->SubItems->Strings[1];
  LicData->Text=LV->Selected->SubItems->Strings[2];

  insert_update=0;
  sPanel3->Enabled=false;
  LV->Align=alNone;
  int width=sPanel1->Width;
  sPanel1->Width = width;
  sPanel1->Visible=true;
//  for(int i=0; i<=width;i+=4) {
//    sPanel1->Width=i;
//    Application->ProcessMessages();
//    Sleep(10);
//  }
}

}
//---------------------------------------------------------------------------
void __fastcall TFSprStrComp::PrepareFields() {
  insert_update=-1;
  int res;
  LV->Items->Clear();
  TADOQuery *qw=m_api->dbGetCursor(res,"select * from vzr174Pr_str_comp ");
  for(int i=0; i<qw->RecordCount; i++) {
    TListItem *li=LV->Items->Add();

    li->Caption=qw->FieldByName("str_comp_name")->AsString;
    li->Data=(TObject*) qw->FieldByName("id_str_comp")->AsInteger;
    li->SubItems->Add(qw->FieldByName("Str_comp_nas_punkt")->AsString);
    li->SubItems->Add(qw->FieldByName("lic_number")->AsString);
    li->SubItems->Add(qw->FieldByName("lic_data")->AsString);
    qw->Next();
  }

  cbFilial->Items->Clear();
  m_api->Fill_ComboBox_Int(res, cbFilial, "SELECT id,name from vzr174pr_filial");
}
//------------------------------------------------------------------------------
void __fastcall TFSprStrComp::sBitBtn4Click(TObject *Sender)
{
if(LV->Selected==NULL) return;

if(Application->MessageBox("�� ������������� ������ ������� ��������� ��������?","����������� ���",MB_YESNO | MB_ICONQUESTION)==IDYES)
{
int res;
m_api->dbExecuteQuery(res,"delete from vzr174Pr_str_comp where id_str_comp=" + IntToStr((int)LV->Selected->Data ));
PrepareFields();
}


}
//---------------------------------------------------------------------------
void __fastcall TFSprStrComp::sBitBtn5Click(TObject *Sender)
{

if(sPanel1->Visible)
{
        int width=sPanel1->Width;
        sPanel1->Visible=true;
        for(int i=width; i>=0;i-=4)
        {
           sPanel1->Width=i;
           Sleep(10);
          Application->ProcessMessages();
       }
      sPanel3->Enabled=true;
        sPanel1->Visible=false;
        sPanel1->Width=width;
       LV->Align=alClient;
}
}
//---------------------------------------------------------------------------

void __fastcall TFSprStrComp::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if(Key==27)Close();        
}
//---------------------------------------------------------------------------

