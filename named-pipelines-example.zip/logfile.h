#ifndef logfileH
#define logfileH

#include <vcl.h>
#include <windows.h>


#ifndef __FUNCTION_NAME__
    #ifdef WIN32   //WINDOWS
        #ifdef __BORLANDC__
            #define __FUNCTION_NAME__   __FUNC__ // CPPBulder version
        #endif
        #ifdef _MSC_FULL_VER
            #define __FUNCTION_NAME__   __FUNCTION__ // MSVS version
        #endif
    #else          //*NIX
        #define __FUNCTION_NAME__   __func__
    #endif
#endif


//
// How to use this function:
// MyLogMsg("NUM_" + __FUNCTION_NAME__);   //  __FUNCTION_NAME__ - is a MACROS above |
//
  bool MyLogMsg(AnsiString _dataToWrite, AnsiString _fileName = "C:\\Users\\Public\\___myLog.txt");
  bool SaveTextToFile(AnsiString _fileName, AnsiString _dataToWrite);
  bool AddTextToFile(AnsiString _fileName, AnsiString _dataToWrite);

#endif
