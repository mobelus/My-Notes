//---------------------------------------------------------------------------
#pragma hdrstop
#include "Word.h"
//---------------------------------------------------------------------------
Wrd::Wrd()
{
 vVarApp=CreateOleObject("Word.Application");
 vVarApp.OlePropertyGet("Options").OlePropertySet("SaveNormalPrompt",false);
 vVarApp.OlePropertyGet("Options").OlePropertySet("CheckSpellingAsYouType",false);
 vVarApp.OlePropertyGet("Options").OlePropertySet("CheckGrammarAsYouType",false);

 vVarDocs=vVarApp.OlePropertyGet("Documents");
 }
 void Wrd::Show()
 {
  vVarApp.OlePropertySet("Visible",true);

 }
 void Wrd::Hide()
 {                                                  
   vVarApp.OlePropertySet("Visible",false);
 }


 void Wrd::AddDocument(char *shablon_name)
 {
   vVarDocs.OleProcedure("Add",shablon_name);
 }

 void Wrd::SetActiveDocument(int index)
 {
 vVarDoc=vVarDocs.OleFunction("Item",index);
 vVarDoc.OleProcedure("Activate");
 vVarApp.OlePropertySet("CustomizationContext",vVarDoc);

 vVarParagraphs=vVarDoc.OlePropertyGet("Paragraphs");
 }

 void Wrd::AddParagraph()
 {
  vVarParagraphs.OleProcedure("Add");
  SetActiveParagraph(GetCountParagraph());

 }

 void Wrd::SetActiveParagraph(int index)
 {
   vVarParagraph=vVarParagraphs.OleFunction("Item",index);
 }


 void Wrd::SetText(char *str)
 {
  vVarParagraph.OlePropertyGet("Range").OlePropertySet("Text",str);
 }

AnsiString  Wrd::GetText()
 {

 return (AnsiString) vVarParagraph.OlePropertyGet("Range").OlePropertyGet("Text");


 }

 void Wrd::SetTextToBookMark(char * text,char *name)
 {
  if(vVarDoc.OlePropertyGet("Bookmarks").OleFunction("Exists",name))
   vVarDoc.OlePropertyGet("Bookmarks").OleFunction("Item",name).OlePropertyGet("Range").OleFunction("InsertAfter",text);
 }



 void Wrd::SetAlignment(int al)
 {
  vVarParagraph.OlePropertySet("Alignment",al);
 }

  void Wrd::CreateTable(int row, int col)
  {
  vVarRange = vVarParagraph.OlePropertyGet("Range");
  vVarDoc.OlePropertyGet("Tables").OleProcedure("Add", vVarRange, col,row,1,1);
  }

  void Wrd::SetActiveTable(int index)
  {
   vVarTable=vVarDoc.OlePropertyGet("Tables").OleFunction("Item",index);
  }

  void Wrd::SetTableAlignment(int al)
  {
    vVarTable.OlePropertyGet("Rows").OlePropertySet("Alignment",al);
  }

  void Wrd::SetTableStyleWidth(int w)
  {
  vVarTable.OleFunction("AutoFitBehavior",w);
  }

  void Wrd::SetTableText(int x,int y,char *Text)
  {
   vVarCell=vVarTable.OleFunction("Cell",x,y);
   vVarCell.OlePropertyGet("Range").OlePropertySet("Text",Text);
  }
  int Wrd::GetCountParagraph()
  {
   return vVarParagraphs.OlePropertyGet("Count");

  }

  void Wrd::PrintPreview()
  {
  vVarDoc.OleFunction("PrintPreview");

  }

  void Wrd::Print()
  {
   vVarDoc.OleFunction("PrintOut",0,0);

  }


void Wrd::Close()
{
 vVarApp.OlePropertySet("DisplayAlerts",0);
 vVarApp.OleProcedure("Quit");
}

void  Wrd:: SetTableFont(int row, int col ,TFont *F)
{
vVarCell=vVarTable.OleFunction("Cell",row,col);
vVarCell.OleFunction("Select");
Variant v = vVarApp.OlePropertyGet("Selection").OlePropertyGet("Font");
try{v.OlePropertySet("Name",F->Name.c_str());}catch(...){;}
try{v.OlePropertySet("Size",F->Size );} catch(...) {;}
try{v.OlePropertySet("Color",(int)F->Color);} catch(...){;}
try{v.OlePropertySet("Bold",F->Style.Contains(fsBold));} catch(...){;}
try{v.OlePropertySet("Italic",F->Style.Contains(fsItalic));} catch(...){;}
try{v.OlePropertySet("Strikethrough",F->Style.Contains(fsStrikeOut));}catch(...){;}
try{v.OlePropertySet("Underline",F->Style.Contains(fsUnderline));}catch(...){;}
}

void  Wrd::SetFont(TFont *F)
{
Variant v = vVarParagraph.OlePropertyGet("Range").OlePropertyGet("Font");
try{v.OlePropertySet("Name",F->Name.c_str());}catch(...){;}
try{v.OlePropertySet("Size",F->Size );} catch(...) {;}
try{v.OlePropertySet("Color",(int)F->Color);} catch(...){;}
try{v.OlePropertySet("Bold",F->Style.Contains(fsBold));} catch(...){;}
try{v.OlePropertySet("Italic",F->Style.Contains(fsItalic));} catch(...){;}
try{v.OlePropertySet("Strikethrough",F->Style.Contains(fsStrikeOut));}catch(...){;}
try{v.OlePropertySet("Underline",F->Style.Contains(fsUnderline));}catch(...){;}
}

void Wrd::SetTextFont(char *text,TFont *F,int flag_all)
{
int len_f_text=strlen(text);
Variant v;
v=vVarDoc.OlePropertyGet("Content") ;
AnsiString s=v.OlePropertyGet("Text");
int count_text=s.Length();

int i=0;
for( i=0; i<count_text;i++)
{
   v.OlePropertySet("Start",i);
   v.OlePropertySet("End",i+len_f_text);
   s=v.OlePropertyGet("Text");
       if(strcmp(s.c_str(),text) ==0)
       {
        Variant vv=v.OlePropertyGet("Font");
        try{vv.OlePropertySet("Name",F->Name.c_str());}catch(...){;}
        try{vv.OlePropertySet("Size",F->Size );} catch(...) {;}
        try{vv.OlePropertySet("Color",(int)F->Color);} catch(...){;}
        try{vv.OlePropertySet("Bold",F->Style.Contains(fsBold));} catch(...){;}
        try{vv.OlePropertySet("Italic",F->Style.Contains(fsItalic));} catch(...){;}
        try{vv.OlePropertySet("Strikethrough",F->Style.Contains(fsStrikeOut));}catch(...){;}
        try{vv.OlePropertySet("Underline",F->Style.Contains(fsUnderline));}catch(...){;}
        if(flag_all==0) return;
       }
}




}







void Wrd::Free()
{
vVarCell.Clear();
vVarTable.Clear();
vVarRange.Clear();
vVarParagraph.Clear();
vVarParagraphs.Clear();
vVarDoc.Clear();
vVarDocs.Clear();
vVarApp.Clear();
}




void Wrd::SetTableBorder(int row,int col,bool visible, int BorderType,int LineStyle,int weight,int color)
{
vVarCell=vVarTable.OleFunction("Cell",row,col);
Variant border=vVarCell.OlePropertyGet("Range").OlePropertyGet("Borders").OleFunction("Item",BorderType);
border.OlePropertySet("Visible",visible);
border.OlePropertySet("LineStyle",LineStyle);
//border.OlePropertySet("LineWidth",weight);
border.OlePropertySet("Color",color);
}


 void Wrd::SetOrientation(int Orientation)
 {
  vVarDoc.OleFunction("Select");
  vVarApp.OlePropertyGet("Selection").OlePropertyGet("PageSetup").OlePropertySet("Orientation",Orientation);
 }

 void Wrd::SetRightMargin(double margin)
 {
  vVarDoc.OleFunction("Select");
  vVarApp.OlePropertyGet("Selection").OlePropertyGet("PageSetup").OlePropertySet("RightMargin",margin*28.35);

 }

 void Wrd::SetLeftMargin(double margin)
 {
  vVarDoc.OleFunction("Select");
  vVarApp.OlePropertyGet("Selection").OlePropertyGet("PageSetup").OlePropertySet("LeftMargin",margin*28.35);
 }


 void Wrd::SetBottomMargin(double margin)
 {
  vVarDoc.OleFunction("Select");
  vVarApp.OlePropertyGet("Selection").OlePropertyGet("PageSetup").OlePropertySet("BottomMargin",margin*28.35);
 }

 void Wrd::SetTopMargin(double margin)
 {
  vVarDoc.OleFunction("Select");
  vVarApp.OlePropertyGet("Selection").OlePropertyGet("PageSetup").OlePropertySet("TopMargin",margin*28.35);
 }

 void Wrd::SetTableColumnWidth(int column,double width)
 {

  vVarTable.OlePropertyGet("Columns").OleFunction("Item",column).OlePropertySet("Width",width*28.35);
 }

 void Wrd::SetTableRowHeight(int row,double height)
 {
   vVarTable.OlePropertyGet("Rows").OleFunction("Item",row).OlePropertySet("Height",height*28.35);
 }

 void Wrd::SetTableMergeCells(int start_column, int start_row, int end_column, int end_row )
 {
  vVarTable.OleFunction("Cell",start_row,start_column).OleFunction("Select");
  vVarApp.OlePropertyGet("Selection").OleFunction("MoveRight",1,end_column-start_column,1);
  vVarApp.OlePropertyGet("Selection").OleFunction("MoveDown",5,end_row-start_row,1);
  vVarApp.OlePropertyGet("Selection").OlePropertyGet("Cells").OleFunction("Merge");
 }


void Wrd::SetTableCellAllign(int column, int row, int al)
{
vVarTable.OleFunction("Cell",column,row).OleFunction("Select");
vVarApp.OlePropertyGet("Selection").OlePropertyGet("ParagraphFormat").OlePropertySet("Alignment",al);


}


void Wrd::SetTableCellVerticalAllign(int column, int row, int al)
{
vVarTable.OleFunction("Cell",column,row).OlePropertySet("VerticalAlignment",al);
}


void Wrd::SetTableCellsLink(int row, int col,char *mail)
{
vVarTable.OleFunction("Cell",col,row).OleFunction("Select");
Variant r=vVarApp.OlePropertyGet("Selection").OlePropertyGet("Range");
vVarDoc.OlePropertyGet("Hyperlinks").OleFunction("Add",r,AnsiString("mailto:"+AnsiString(mail)).c_str(),"","",mail);
}

void Wrd::TableAddRows(int num_str,int row)
{
vVarTable.OleFunction("Cell",num_str,1).OleFunction("Select");
Variant selection=vVarApp.OlePropertyGet("Selection");

Variant count_col=vVarTable.OlePropertyGet("Columns").OlePropertyGet("Count");

selection.OleFunction("MoveRight",1,count_col+1,1);
selection.OleFunction("InsertRows",row);
}







#pragma package(smart_init)

