//---------------------------------------------------------------------------

#ifndef KFreeH
#define KFreeH

#include "Ikoeff.h"
#include "IFrame.H"

class CBaseKoeffFree:public IBaseKoeff{
  IFree *m_Iframe;
  double m_Koeff;
  AnsiString m_DesK;
public:
  CBaseKoeffFree(IFree *f);
  AnsiString NKoeff_I()     { return "Kx";};
  AnsiString DescKoeff_I()  { return "������ ��������������.";};
protected :
  virtual double getKoeff_I(){return m_Koeff;};
  virtual double calcKoeff_I(){return CalcKoeff();};
  virtual AnsiString getDescDBKoeff_I(){return m_DesK;};
protected :
  double  CalcKoeff();
};
//---------------------------------------------------------------------------
#endif

