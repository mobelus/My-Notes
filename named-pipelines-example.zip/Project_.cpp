//---------------------------------------------------------------------------
#pragma hdrstop
#include "Project_.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
__fastcall TProject::TProject(TWinControl* aParent, mops_api_008* aAPI, AnsiString aTableName, AnsiString aProductIDList, AnsiString aTerrIDList)
{
        Parent = aParent;

        if (Parent)
        {
                gbProjects = new TsGroupBox(Parent);
                gbProjects->Parent = Parent;
                gbProjects->Caption = "�������";
                gbProjects->Height  = 45;
                gbProjects->Width   = 500;
                gbProjects->Align   = alNone;

                CBProjects = new TsComboBox(gbProjects);
                CBProjects->Parent = gbProjects;
                CBProjects->Width = 400;
                CBProjects->Top   = 20;
                CBProjects->Left  = 6;
                CBProjects->Anchors = TAnchors() << akLeft << akTop << akRight;
                CBProjects->Style = csDropDownList;
                CBProjects->OnChange = CBProjectsChange;

                ceKoef = new TsCalcEdit(gbProjects);
                ceKoef->Parent = gbProjects;
                ceKoef->Width = 60;
                ceKoef->Top   = 20;
                ceKoef->Left  = CBProjects->Left + CBProjects->Width + 10;
                ceKoef->Anchors = TAnchors() << akTop << akRight;
                ceKoef->Enabled = false;
                ceKoef->OnChange = ceKoefChange;
        }

        m_api = aAPI;

        TableName = aTableName;
        ProductIDList = aProductIDList;
        TerrIDList = aTerrIDList;
        min_koef=0;
        max_koef=0;

}
//---------------------------------------------------------------------------
void __fastcall TProject::LoadFromSKK()
{
        int res;

        l_api = m_api->glDic_Get_SKK_API(res);

        AnsiString lSQL = "select pp.ID,pp.PRODUCT_PRODUCT_ID_FK, pp.DICTPROJECT_PROJECT_ID_FK, p.PROJECT_NAME, pp.LINK_4_1_4_FK, pp.START_DATE, pp.END_DATE_, pp.KA_MIN, pp.KA_MAX "
                            "from RGSSCC_META.ref_dictprojectproduct pp "
                           "inner join RGSSCC_META.ref_dictproject p on p.ID=pp.DICTPROJECT_PROJECT_ID_FK "
                           "where (pp.START_DATE < SYSDATE) "
                             "and ((SYSDATE < pp.END_DATE_) or (pp.END_DATE_ is null)) "
                             "and pp.PRODUCT_PRODUCT_ID_FK in (" + ProductIDList + ") "
                             "and (p.DATE_FROM < SYSDATE) "
                             "and (p.DATE_TO > SYSDATE) "
                             "and (SYSDATE > pp.DATE_FROM) "
                             "and (SYSDATE < pp.DATE_TO) "
                           "order by pp.ID ";

        TADOQuery* qw = l_api->dbGetCursor(res, lSQL, false);

        if (res!=0)
                return;

        m_api->dbExecuteQuery(res, "delete from " + TableName);

        for(qw->First(); !qw->Eof; qw->Next())
        {
                AnsiString lSQL = "insert into " + TableName + " (ID, ProductID, ProjectID, TerrID, ProjectName, K_MIN, K_MAX, StartDate, EndDate) values("
                + (qw->FieldByName("ID")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("ID")->AsString) + ","
                + (qw->FieldByName("PRODUCT_PRODUCT_ID_FK")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("PRODUCT_PRODUCT_ID_FK")->AsString) + ","
                + (qw->FieldByName("DICTPROJECT_PROJECT_ID_FK")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("DICTPROJECT_PROJECT_ID_FK")->AsString) + ","
                + (qw->FieldByName("LINK_4_1_4_FK")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("LINK_4_1_4_FK")->AsString) + ",'"
                + (qw->FieldByName("PROJECT_NAME")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("PROJECT_NAME")->AsString) + "',"
                + (qw->FieldByName("KA_MIN")->AsString.IsEmpty()?AnsiString("NULL"):StringReplace(qw->FieldByName("KA_MIN")->AsString,",",".",TReplaceFlags()<<rfReplaceAll)) + ","
                + (qw->FieldByName("KA_MAX")->AsString.IsEmpty()?AnsiString("NULL"):StringReplace(qw->FieldByName("KA_MAX")->AsString,",",".",TReplaceFlags()<<rfReplaceAll)) + ","
                + m_api->Internal_Convert_Date_To_SQL(res, qw->FieldByName("START_DATE")->AsString, false) + ","
                + m_api->Internal_Convert_Date_To_SQL(res, qw->FieldByName("END_DATE_")->AsString, false) + ")"  ;

                m_api->dbExecuteQuery(res, lSQL);
        }
}
//---------------------------------------------------------------------------
bool __fastcall TProject::CalcKoefsExists()
{
        int res;

        AnsiString lSQL =  "select * "
                             "from " + TableName + " "
                            "where ProductID in (" + ProductIDList + ") "
                              "and (K_MIN<>1 or K_MAX<>1) "
                              "and StartDate<Date() "
                              "and (EndDate>Date() or EndDate is null) "
                              "and TerrID in (" + TerrIDList + ")";

        TADOQuery* qw = m_api->dbGetCursor(res, lSQL);

        int count = qw->RecordCount;

        m_api->dbCloseCursor(res, qw);

        if (count > 0)
                return true;
        else
                return false;

}
//---------------------------------------------------------------------------
void __fastcall TProject::SetBounds(TRect* aRect, AnsiString aAlign)
{
        try
        {
        if (aRect)
        {
                if (aRect->Top > 0)
                        gbProjects->Top  = aRect->Top;
                if (aRect->Left > 0)
                        gbProjects->Left = aRect->Left;
                if (aRect->Right - aRect->Left > 0)
                        gbProjects->Width = aRect->Right - aRect->Left;
                if (aRect->Bottom - aRect->Top > 0)
                        gbProjects->Height = aRect->Bottom - aRect->Top;
        }
        }
        catch(Exception& e)
        {
                ShowMessage(e.Message);
        }

        if (!aAlign.IsEmpty())
        {
                if (aAlign=="alNone")
                        gbProjects->Align = alNone;
                else if (aAlign=="alTop")
                        gbProjects->Align = alTop;
                else if (aAlign=="alBottom")
                        gbProjects->Align = alBottom;
                else if (aAlign=="alLeft")
                        gbProjects->Align = alLeft;
                else if (aAlign=="alRight")
                        gbProjects->Align = alRight;
        }
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetProductIDList(AnsiString aProductIDList)
{
        ProductIDList = aProductIDList;
        LoadCBProjects();
}
//---------------------------------------------------------------------------
void __fastcall TProject::LoadCBProjects()
{
        int res;

        CBProjects->Clear();
        min_koef=0;
        max_koef=0;
        ceKoef->Value = 0;
        ceKoef->Enabled = false;

        TADOQuery* qw = m_api->dbGetCursor(res, "select ID, ProjectName "
                                                  "from " + TableName + " "
                                                 "where ProductID in (" + ProductIDList + ") "
                                                   "and StartDate<Date() "
                                                   "and (EndDate>Date() or EndDate is null)"
                                                   "and TerrID  in (" + TerrIDList+ ")");

        for (qw->First(); !qw->Eof; qw->Next())
                CBProjects->Items->AddObject(qw->FieldByName("ProjectName")->AsString, (TObject*)qw->FieldByName("ID")->AsInteger);


        m_api->dbCloseCursor(res, qw);
}
//---------------------------------------------------------------------------
double __fastcall TProject::GetKoef()
{
        if (CBProjects->ItemIndex < 0)
                return 0;

        return ceKoef->Value;
}
//---------------------------------------------------------------------------
void __fastcall TProject::CBProjectsChange(TObject* Sender)
{
        if (CBProjects->ItemIndex < 0)
                return;

        int res = 0;

        double min = m_api->dbGetFloatFromQuery(res, "select K_MIN from " + TableName + " where ID=" + IntToStr((int)CBProjects->Items->Objects[CBProjects->ItemIndex]));
        double max = m_api->dbGetFloatFromQuery(res, "select K_MAX from " + TableName + " where ID=" + IntToStr((int)CBProjects->Items->Objects[CBProjects->ItemIndex]));

        min_koef=min;
        max_koef=max;

        if (min == max)
        {
                ceKoef->Value = min;
                ceKoef->Enabled = false;
        }
        else
        {
                ceKoef->Enabled = true;
        }



        UserFunc();
}
//---------------------------------------------------------------------------
void __fastcall TProject::ceKoefChange(TObject* Sender)
{
        UserFunc();
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetKoefVisible(bool aValue)
{
        ceKoef->Visible = aValue;
}
//---------------------------------------------------------------------------
int __fastcall TProject::GetProjectID()
{
        if (CBProjects->ItemIndex < 0)
                return 0;

        int res = 0;
        int prj_id = m_api->dbGetIntFromQuery(res, "select ProjectID from " + TableName + " where ID=" + IntToStr((int)CBProjects->Items->Objects[CBProjects->ItemIndex]));        return prj_id;
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetKoef(double value)
{
         if(value<min_koef ||  value>max_koef)
                return ;

         ceKoef->Value=value;
         ceKoefChange(ceKoef);
}
//----------------------------------------------------------------------------
long __fastcall TProject::GetID()
{
 return
        (CBProjects->ItemIndex>-1
        ? (int)CBProjects->Items->Objects[CBProjects->ItemIndex]
        : -1);
}
//-----------------------------------------------------------------------------
bool __fastcall TProject::ValidateKoef(AnsiString &error_description)
{
  if(CBProjects->ItemIndex<0)
                return false;

  double koef=ceKoef->Value;

  if(koef<min_koef || koef>max_koef)
         {
                error_description="����������� �� ������� " + CBProjects->Text
                                   + " ������ ���������� � ��������� �� "
                                   + FormatFloat("##0.00",min_koef) + " �� "
                                   + FormatFloat("##0.00",max_koef);
                return false;
        }

 else
        {
                error_description="";
                return true;
       }
}

