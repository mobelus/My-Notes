#include "logfile.h"


bool SaveTextToFile(AnsiString _FileName, AnsiString _dataToWrite)
{
	HANDLE hFile;
	BOOL bErrorFlag = FALSE;
            // name to write  // open for writing  //not share  // default security
	hFile = CreateFile(_FileName.c_str(), GENERIC_WRITE,     0, NULL,
            // create new file only    // normal file         // no attr. template
                        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        //DisplayError(TEXT("CreateFile"));
        //printf(TEXT("Terminal failure: Unable to open file \"%s\" for write.\n"), _FileName);
        return false;
    }

    //_tprintf(TEXT("Writing %d bytes to %s.\n"), dwBytesToWrite, argv[1]);

	DWORD dwBytesToWrite = (DWORD)(_dataToWrite.Length());
	DWORD dwBytesWritten = 0;
                 // open file handle // start of data to write  // number of bytes to write // number of bytes that were written
	bErrorFlag = WriteFile(      hFile, _dataToWrite.c_str(),   dwBytesToWrite,             &dwBytesWritten,  NULL); // no overlapped structure

    if (FALSE == bErrorFlag)
    {
        //DisplayError(TEXT("WriteFile"));
        //printf("Terminal failure: Unable to write to file.\n");
		return false;
    }
    else
    {
        if (dwBytesWritten != dwBytesToWrite)
        {
            // This is an error because a synchronous write that results in
            // success (WriteFile returns TRUE) should write all data as
            // requested. This would not necessarily be the case for
            // asynchronous writes.
            //printf("Error: dwBytesWritten != dwBytesToWrite\n");
			return false;
		}
        else
        {
            //_tprintf(TEXT("Wrote %d bytes to %s successfully.\n"), dwBytesWritten, _FileName);
        }
    }

    CloseHandle(hFile);
	return true;
}


bool AddTextToFile(AnsiString _FileName, AnsiString _dataToWrite)
{
	HANDLE hFile;
	BOOL bErrorFlag = FALSE;
	// name to write  // open for writing  //not share  // default security
	hFile = CreateFile(_FileName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL,
		// create new file only    // normal file         // no attr. template
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		hFile = CreateFile(_FileName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL,
			// create new file only    // normal file         // no attr. template
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			NULL);

		//DisplayError(TEXT("CreateFile"));
		//printf(TEXT("Terminal failure: Unable to open file \"%s\" for write.\n"), _FileName);
	}

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return false;
	}

	//_tprintf(TEXT("Writing %d bytes to %s.\n"), dwBytesToWrite, argv[1]);
    _dataToWrite += "\n";
	DWORD dwBytesToWrite = (DWORD)(_dataToWrite.Length());
	//DWORD dwBytesWritten = 0;
	DWORD dwBytesWritten = SetFilePointer(hFile, 0, NULL, FILE_END); //set pointer position to end file
	// open file handle // start of data to write  // number of bytes to write // number of bytes that were written
	bErrorFlag = WriteFile(hFile, _dataToWrite.c_str(), dwBytesToWrite, &dwBytesWritten, NULL); // no overlapped structure

	if (FALSE == bErrorFlag)
	{
		//DisplayError(TEXT("WriteFile"));
		//printf("Terminal failure: Unable to write to file.\n");
		return false;
	}
	else
	{
		if (dwBytesWritten != dwBytesToWrite)
		{
			// This is an error because a synchronous write that results in
			// success (WriteFile returns TRUE) should write all data as
			// requested. This would not necessarily be the case for
			// asynchronous writes.
			//printf("Error: dwBytesWritten != dwBytesToWrite\n");
			return false;
		}
		else
		{
			//_tprintf(TEXT("Wrote %d bytes to %s successfully.\n"), dwBytesWritten, _FileName);
		}
	}

	CloseHandle(hFile);
	return true;
}


  //bool MyLogMsg(AnsiString _FileName, AnsiString _dataToWrite)
bool MyLogMsg(AnsiString _dataToWrite, AnsiString _FileName)
{
  return AddTextToFile(_FileName, _dataToWrite);
}

