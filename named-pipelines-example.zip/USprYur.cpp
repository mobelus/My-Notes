//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "USprYur.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sListView"
#pragma link "sBitBtn"
#pragma link "sCustomComboEdit"
#pragma link "sEdit"
#pragma link "sLabel"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma resource "*.dfm"
TFSprYur *FSprYur;
//---------------------------------------------------------------------------
__fastcall TFSprYur::TFSprYur(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFSprYur::sBitBtn1Click(TObject *Sender)
{
if(!sPanel1->Visible)
{
        TerrName->Text="";
        EVoz->Text="";
        insert_update=1;
        sPanel3->Enabled=false;
        LV->Align=alNone;
        int width=sPanel1->Width;
        sPanel1->Width=0;
        sPanel1->Visible=true;
        for(int i=0; i<=width;i+=4)
        {
        sPanel1->Width=i;
         Application->ProcessMessages();
        Sleep(10);
      }
}

}
//---------------------------------------------------------------------------
void __fastcall TFSprYur::sBitBtn2Click(TObject *Sender)
{
int res;
if(sPanel1->Visible)
{
          if(TerrName->Text=="")
          {
           Application->MessageBox("�� ������� ������������ ������������ ����","����������� ���",MB_OK | MB_ICONERROR);
           return;
          }
          if(EVoz->Text=="")
          {
           Application->MessageBox("�� ������� ��������������","����������� ���",MB_OK | MB_ICONERROR);
           return;
          }


          AnsiString sql="";
          //�������� ��������
          if(insert_update==0) // ���������� �������
          {
          sql="update vzr174Pr_yur set "
          " yur_name='" + TerrName->Text + "', "
          " yur_voz=" + EVoz->Text +
          " where id_yur=" + IntToStr((int)LV->Selected->Data);

          }

          if(insert_update==1) //���������� �����
          {
           sql="insert into vzr174Pr_yur (id_yur,yur_name,yur_voz) values ("
           + IntToStr(m_api->dbGenerateId(res,"vzr174Pr_yur")) + ","
           + "'"+TerrName->Text + "'," + EVoz->Text +
           ")";

          }
      insert_update=-1;
      m_api->dbExecuteQuery(res,sql);

        int width=sPanel1->Width;
        sPanel1->Visible=true;
        for(int i=width; i>=0;i-=4)
        {
           sPanel1->Width=i;
           Sleep(10);
          Application->ProcessMessages();
       }
      sPanel3->Enabled=true;
        sPanel1->Visible=false;
        sPanel1->Width=width;
       LV->Align=alClient;
       PrepareFields();

}


}
//---------------------------------------------------------------------------
void __fastcall TFSprYur::sBitBtn3Click(TObject *Sender)
{
if(LV->Selected==NULL) return;


if(!sPanel1->Visible)
{
        TerrName->Text=LV->Selected->Caption;
        EVoz->Text=LV->Selected->SubItems->Strings[0];
        insert_update=0;
        sPanel3->Enabled=false;
        LV->Align=alNone;
        int width=sPanel1->Width;
        sPanel1->Width=0;
        sPanel1->Visible=true;
        for(int i=0; i<=width;i+=4)
        {
        sPanel1->Width=i;
         Application->ProcessMessages();
        Sleep(10);
      }
}

}
//---------------------------------------------------------------------------
void __fastcall TFSprYur::PrepareFields()

 {
  insert_update=-1;
 int res;
 LV->Items->Clear();
TADOQuery *qw=m_api->dbGetCursor(res,"select * from vzr174Pr_yur ");
    for(int i=0; i<qw->RecordCount; i++)
    {
      TListItem *li=LV->Items->Add();

      li->Caption=qw->FieldByName("yur_name")->AsString;
      li->SubItems->Add(IntToStr(qw->FieldByName("yur_voz")->AsInteger));
      li->Data=(TObject*) qw->FieldByName("id_yur")->AsInteger;
     qw->Next();
    }
}
//------------------------------------------------------------------------------
void __fastcall TFSprYur::sBitBtn4Click(TObject *Sender)
{
if(LV->Selected==NULL) return;

if(Application->MessageBox("�� ������������� ������ ������� ����������� ����?","����������� ���",MB_YESNO | MB_ICONQUESTION)==IDYES)
{
int res;
m_api->dbExecuteQuery(res,"delete from vzr174Pr_yur where id_yur=" + IntToStr((int)LV->Selected->Data ));
PrepareFields();
}


}
//---------------------------------------------------------------------------
void __fastcall TFSprYur::sBitBtn5Click(TObject *Sender)
{

if(sPanel1->Visible)
{
        int width=sPanel1->Width;
        sPanel1->Visible=true;
        for(int i=width; i>=0;i-=4)
        {
           sPanel1->Width=i;
           Sleep(10);
          Application->ProcessMessages();
       }
      sPanel3->Enabled=true;
        sPanel1->Visible=false;
        sPanel1->Width=width;
       LV->Align=alClient;
}
}
//---------------------------------------------------------------------------

void __fastcall TFSprYur::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if(Key==27)Close();        
}
//---------------------------------------------------------------------------

