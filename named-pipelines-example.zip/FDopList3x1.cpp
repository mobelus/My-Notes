//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FDopList3x1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormDopList3x1 *FormDopList3x1;
//---------------------------------------------------------------------------
__fastcall TFormDopList3x1::TFormDopList3x1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
__fastcall TFormDopList3x1::TFormDopList3x1(TComponent* Owner, bool fPechat)
  : TForm(Owner), m_fPechat(fPechat)
{
}

void __fastcall TFormDopList3x1::rep_date(TADOQuery *date, bool fprem)
{
 TQRLabel *plb1 = NULL;
 TQRLabel *plb2 = NULL;
 TQRLabel *plb3 = NULL;
 TQRLabel *plb4 = NULL;
 TQRLabel *plb5 = NULL;
 AnsiString stmp = "";
 int i = 5,
    count_max = 1;

 while(!date->Eof && count_max <= max_rec_1)
 {
  plb1 = (TQRLabel *)this->QRBand1->FindChildControl(stmp.sprintf("QRLabel%i", i));
  plb2 = (TQRLabel *)this->QRBand1->FindChildControl(stmp.sprintf("QRLabel%i", i + 1));
  plb3 = (TQRLabel *)this->QRBand1->FindChildControl(stmp.sprintf("QRLabel%i", i + 2));
  plb4 = (TQRLabel *)this->QRBand1->FindChildControl(stmp.sprintf("QRLabel%i", i + 3));
  plb5 = (TQRLabel *)this->QRBand1->FindChildControl(stmp.sprintf("QRLabel%i", i + 4));
  plb1->Caption = IntToStr(date->RecNo);
  plb2->Caption = date->FieldByName("InsuredPersonFIO")->AsString;
  plb3->Caption = date->FieldByName("InsuredPersonBirthday")->AsString;
  plb4->Caption = FloatToStr(date->FieldByName("k_age")->AsFloat);
  if(!fprem)
    plb5->Caption = date->FieldByName("premium")->AsString;

  date->Next();
  i += 5;
  count_max ++;
 }
}

void __fastcall TFormDopList3x1::print(bool preview, bool blank)
{
  QRLabel165->Caption = Date().DateString();
  QRLabel166->Caption = Date().DateString();

  if(m_fPechat){
    Graphics::TBitmap *btmp=new Graphics::TBitmap();
    btmp->Assign(QRImage1->Picture);
    btmp->PixelFormat=pf32bit;

    Graphics::TBitmap *btmp2=new Graphics::TBitmap();
    TJPEGImage *jpg=new TJPEGImage();
    SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
    jpg->Assign(QRIPechat->Picture);
    btmp2->Assign(jpg);
    btmp2->PixelFormat=pf32bit;

//   ::BitBlt(btmp->Canvas->Handle, 100, 0, btmp->Width, btmp->Height,btmp2->Canvas->Handle, 0, 0, SRCAND);
    ::StretchBlt(btmp->Canvas->Handle,

        btmp->Width - btmp2->Width/2 - 50,
        btmp->Height - btmp2->Height/2 - 20,
        btmp2->Width/2 + 20,
        btmp2->Height/2 + 20,

        btmp2->Canvas->Handle, 0, 0, btmp2->Width, btmp2->Height, SRCAND);

    QRImage1->Picture->Assign(btmp);

    delete jpg;
    delete btmp;
    delete btmp2;
  }

        if(!blank)
        {
         //�������� ����� "�������"
         TJPEGImage *jpg=new TJPEGImage();
         try{
          jpg->Assign(QRImage1->Picture->Bitmap);
          }
          catch(Exception &ex)
          {
            MessageBox(NULL, ex.Message.c_str(), "������", mbOK);
          }
         Graphics::TBitmap *btmp2=new Graphics::TBitmap();
         Graphics::TBitmap *btmp=new Graphics::TBitmap();
         btmp->Assign(jpg);
         btmp2->Assign(jpg);
         btmp->PixelFormat=pf32bit;
         btmp2->PixelFormat=pf32bit;
         SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
         HFONT font = CreateFont(80,          // ������ ������
                   60,          // ������ ����������
                   250,            //���� ��������
                   0,            //���� �����������
                   FW_BOLD,     //������ ������
                   TRUE,        // ������
                   FALSE,        // �������������
                   FALSE,               // ��������������
                   DEFAULT_CHARSET ,
                   OUT_TT_PRECIS,       // �������� ������
                   CLIP_DEFAULT_PRECIS,   //�������� ���������
                   ANTIALIASED_QUALITY, // �������� ������
                   FF_DONTCARE|DEFAULT_PITCH, // ��������� � ���
                   "Times New Roman");          // ��� ������
         btmp2->Canvas->Font->Handle=font;
         btmp2->Canvas->Font->Color=(TColor)RGB(255,0,0);
         btmp2->Canvas->TextOut(100,btmp->Height-350,"�������");
         btmp2->Canvas->TextOut(100,btmp->Height-350-btmp->Height/3,"�������");
         btmp2->Canvas->TextOut(100,btmp->Height-350-2*btmp->Height/3,"�������");

         TBlendFunction Blend;
         Blend.BlendOp=AC_SRC_OVER;
                Blend.BlendFlags = 0;
                Blend.SourceConstantAlpha = 128; // ������������ 50% (0 - 255)
                Blend.AlphaFormat =0;//AC_SRC_ALPHA; // ���� = 0 (������ ��������)
                ::AlphaBlend(btmp->Canvas->Handle, 0, 0, btmp->Width, btmp->Height,
		btmp2->Canvas->Handle, 0, 0, btmp->Width, btmp->Height, Blend);
         jpg->Assign(btmp);
         QRImage1->Picture->Assign(jpg);
        delete jpg;
        delete btmp;
        delete btmp2;
        }

  if (preview)
  {
    QuickRep1->Preview();
  }
  else
  {
    QuickRep1->Print();
  }
}
