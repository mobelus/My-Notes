#ifndef IKOEFFH
#define IKOEFFH

#include <vcl>

typedef enum enum_type_calc_tarif{
  eTCTNULL = 0,
  eROZNICA_FIZ,
  eROZNICA_UR,
  ePARTNER_UR,
  eIVC
}TCT, * LPTCT;


class IBaseKoeff{
public :
  virtual double      getKoeff_I() = 0;
  virtual double      calcKoeff_I() = 0;
  virtual AnsiString  NKoeff_I() = 0;
  virtual AnsiString  DescKoeff_I() = 0;
  virtual AnsiString  getDescDBKoeff_I()= 0;
  virtual ~IBaseKoeff(){};
};
typedef IBaseKoeff* LPKoeff;
#endif //IKOEFFH
