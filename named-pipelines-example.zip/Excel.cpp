#include <vcl.h>
#include "Excel.h"
#include "math.h"
void __fastcall Excel::ExcelInit(AnsiString File)
{
   //Excel �� ������� - ��������� ���
  AnsiString ext = ExtractFileExt(File);
  m_file = File;
  if(ext == ".xls"){
    m_typef = FILEXCEL;
    AppInitExel();
  }
  else if(ext == ".ods"){
    m_typef = FILEODS;
    AppInitOds();
  }
}
//-----------------------------------------------------------------------------
 void __fastcall Excel::toExcelCell(int Row,int Column, AnsiString data)
{
  try {
    Variant  cur = Sh.OlePropertyGet("Cells", Row,Column);
    cur.OlePropertySet("Value", data.c_str());
  } catch(...) { ; }
}
//------------------------------------------------------------------------
void __fastcall Excel::toExcelCell(int Row,int Column, Variant data)
{
  try {
    Variant  cur = Sh.OlePropertyGet("Cells", Row,Column);
    cur.OlePropertySet("Value", data);
  } catch(...) { ; }
}
//---------------------------------------------------------------------------
void __fastcall Excel::Merge(char* Range)
{
try{
Variant merge=Sh.OlePropertyGet("Range",Range);
merge.OleProcedure("Merge");
}
catch(...){;}
}
//------------------------------------------------------------------------------
void __fastcall Excel::HorAlign(int  sRow,int sCol,int val)
{
try{
App.OlePropertyGet("Cells",sRow,sCol).OlePropertySet("HorizontalAlignment",val);
}
catch(...) {;}
}
//------------------------------------------------------------------------------
void __fastcall Excel::VertAlign(int  sRow,int sCol,int val)
{
try{
App.OlePropertyGet("Cells",sRow,sCol).OlePropertySet("VerticalAlignment",val);
}
catch(...) {;}


}
//------------------------------------------------------------------------------
void __fastcall Excel:: SetFont(int sRow,int sCol,TFont *F)
{
Variant cel=App.OlePropertyGet("Cells",sRow,sCol);
try{cel.OlePropertyGet("Font").OlePropertySet("Name",F->Name.c_str());}catch(...){;} //��� ������
try{cel.OlePropertyGet("Font").OlePropertySet("Size",F->Size );} catch(...) {;}//������ ������
try{cel.OlePropertyGet("Font").OlePropertySet("Color",F->Color);} catch(...){;} // ���� ������
try{cel.OlePropertyGet("Font").OlePropertySet("Bold",F->Style.Contains(fsBold));} catch(...){;}//;������
try{cel.OlePropertyGet("Font").OlePropertySet("Italic",F->Style.Contains(fsItalic));} catch(...){;}//������
try{cel.OlePropertyGet("Font").OlePropertySet("Strikethrough",F->Style.Contains(fsStrikeOut));}catch(...){;}//�����������
try{cel.OlePropertyGet("Font").OlePropertySet("Underline",F->Style.Contains(fsUnderline));}catch(...){;}//������������
/*
//������� ������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Superscript",true);
//������ ������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Subscript",true);
//��� �����
vVarCell.OlePropertyGet("Font").
OlePropertySet("OutlineFont",true);
//C �����
vVarCell.OlePropertyGet("Font").
OlePropertySet("Shadow",true);
//������������ ��������� ������ �� ��������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",2);
//������������ ������� ������ �� ��������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",-4119);
//������������ ��������� ������ �� ������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",4);
//������������ ������� ������ �� ��������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",5);
����� �������� ��������:
xlUnderlineStyleDouble = -4119,
xlUnderlineStyleDoubleAccounting = 5,
xlUnderlineStyleNone = -4142,
xlUnderlineStyleSingle = 2,
xlUnderlineStyleSingleAccounting = 4
*/
}
//------------------------------------------------------------------------------
void __fastcall Excel::SetColor(int sRow, int sCol,int Color)
{
Variant cel=App.OlePropertyGet("Cells",sRow,sCol);
try{cel.OlePropertyGet("Interior").OlePropertySet("Color",Color);} catch(...){;}
}
//------------------------------------------------------------------------------
void __fastcall Excel::SetColor(char * Range ,int Color)
{
Variant cel=App.OlePropertyGet("Range",Range);
try{cel.OlePropertyGet("Interior").OlePropertySet("Color",Color);} catch(...){;}
}




//------------------------------------------------------------------------------
void __fastcall Excel:: SetFrame(int sRow,int sCol, int gde, int line_style, int weight,int color)
{
Variant cel=App.OlePropertyGet("Cells",sRow,sCol);
try{
cel.OlePropertyGet("Borders",gde).OlePropertySet("LineStyle",line_style);
cel.OlePropertyGet("Borders",gde).OlePropertySet("Weight",weight);
cel.OlePropertyGet("Borders",gde).OlePropertySet("Color",color);
}
catch(...){;}
}
//-----------------------------------------------------------------------------------------------
void __fastcall Excel::SetFrameCellss(int sRow,int sCol, int line_style, int weight,int color)
{
SetFrame(sRow,sCol,xlEdgeRight,line_style,weight,color);
SetFrame(sRow,sCol,xlEdgeLeft,line_style,weight,color);
SetFrame(sRow,sCol,xlEdgeTop,line_style,weight,color);
SetFrame(sRow,sCol,xlEdgeBottom,line_style,weight,color);
}


void __fastcall Excel:: SetFrame(char* Range, int gde, int line_style, int weight,int color)
{
Variant cel=App.OlePropertyGet("Range",Range);
try{
cel.OlePropertyGet("Borders",gde).OlePropertySet("LineStyle",line_style);
cel.OlePropertyGet("Borders",gde).OlePropertySet("Weight",weight);
cel.OlePropertyGet("Borders",gde).OlePropertySet("Color",color);
}
catch(...){;}
}
//------------------------------------------------------------------------------
AnsiString __fastcall Excel::GetRange(int start_row,int start_col,int end_row, int end_col)
{
AnsiString return_str="";
AnsiString startr="";
AnsiString endr="";


div_t start_c=div(start_col,27);
while(start_c.quot>0)
{
if(start_c.rem!=0)startr=startr + char(65+start_c.rem);
else startr=startr + char(65);
start_c=div(start_c.quot,27);
}
if(start_c.rem!=0)startr=startr + char(64+start_c.rem);
for(int i=startr.Length();i>0;i--) return_str=return_str+startr[i];
return_str=return_str+IntToStr(start_row) + ":";

div_t end_c=div(end_col,27);
while(end_c.quot>0)
{
if(end_c.rem!=0)endr=endr + char(65+end_c.rem);
else endr=endr + char(65);
end_c=div(end_c.quot,27);
}
if(end_c.rem!=0)endr=endr + char(64+end_c.rem);


for(int i=endr.Length();i>0;i--) return_str=return_str+endr[i];
return_str=return_str+IntToStr(end_row);

return return_str;
}
//-----------------------------------------------------------------------------
void __fastcall Excel::SetOrientation(int sRow, int sCol,int Angle)
{
Variant cel=App.OlePropertyGet("Cells",sRow,sCol);
try{cel.OlePropertySet("Orientation",Angle);} catch(...){;}
}

//------------------------------------------------------------------------------
void __fastcall Excel::SetOrientation(char * Range,int Angle)
{
Variant cel=App.OlePropertyGet("Range",Range);
try{cel.OlePropertySet("Orientation",Angle);} catch(...){;}
}
//------------------------------------------------------------------------------
void __fastcall Excel::AutoFit(int sRow, int sCol)
{
Variant cel=App.OlePropertyGet("Cells",sRow,sCol);
try{cel.OlePropertyGet("EntireColumn").OleProcedure("AutoFit");} catch(...){;}
}

//------------------------------------------------------------------------------
void __fastcall Excel::Visible ( bool visible)
{
  if(!App.IsEmpty())App.OlePropertySet("Visible",visible);
}
//------------------------------------------------------------------------------

void __fastcall Excel::Close()
{
try{
App.OlePropertyGet("WorkBooks",1).OleProcedure("Close");}
       catch(...){
          ShowMessage("�� �������� ���� ������� Excel.");
      }

}

//------------------------------------------------------------------------------
void __fastcall Excel:: Free()
 {
   Sh.Clear();
    App.Clear();
 }

//------------------------------------------------------------------------------

void __fastcall Excel::SaveAs(AnsiString FileName)
{
try{
      App.OlePropertyGet("WorkBooks",1).OleProcedure("SaveAs",FileName.c_str());
      }catch(...){
         ShowMessage("�� ������� ���������! ��������� ���� :)");
      }
}

//--------------------------------------------------------------------------------
AnsiString  __fastcall Excel::GetActiverange()
{
AnsiString Range;
try{
Range=Sh.OlePropertyGet("UsedRange").OlePropertyGet("Address");
}
catch(...){ShowMessage("�� ������� ������� ������������ �������");}
return  StringReplace(Range,"$","",TReplaceFlags()<<rfReplaceAll);
}
//------------------------------------------------------------------------------
TRect __fastcall Excel::GetActiverange2()
{
TRect r;
AnsiString Range;
try{
Range=Sh.OlePropertyGet("UsedRange").OlePropertyGet("Address");
Range=StringReplace(Range,"$","",TReplaceFlags()<<rfReplaceAll);

int stroki=0;
int  stolbci=0;
int count_str=0;
int count_stolb=0;
AnsiString part1,part2;
part1=Range.SubString(1,Range.Pos(":")-1);
part2=Range.SubString(Range.Pos(":")+1,Range.Length());


for(int i=1; i<=part1.Length();i++)
{
  int temp=(int) part1[i];
   if(temp>=65 & temp<=90) //������
    {
    if(i==1)stolbci=temp-64;
    if(i==2) stolbci=stolbci*27+temp-65;
     count_stolb++;
    }
   if(temp>=49 && temp <58 ) //�����
    {
     stroki=stroki*pow(10,count_str)+(temp-48);
     count_str++;
    }
}
r.left=stroki;
r.top=stolbci;
stroki=0;
stolbci=0;
count_str=0;
count_stolb=0;
for(int i=1; i<=part2.Length();i++)
{
  int temp=(int) part2[i];
   if(temp>=65 & temp<=90) //������
    {
    if(i==1)stolbci=temp-64;
    if(i==2) stolbci=stolbci*27+temp-65;
     count_stolb++;
    }
   if(temp>=49 && temp <58 ) //�����
    {
     stroki=stroki*pow(10,count_str)+(temp-48);
     count_str++;
    }
}
r.right=stroki;
r.bottom=stolbci;
}
catch(...){ShowMessage("�� ������� ������� ������������ �������");}
return r;
}


void __fastcall Excel::SetCheckBoxVisible()
{

int count=Sh.OlePropertyGet("CheckBoxes").OlePropertyGet("Count");
for(int i=1; i<=count;i++)
{
//Variant chk_box=Sh.OlePropertyGet("Shapes").OleFunction("Item",i).OlePropertyGet("OLEFormat").OlePropertyGet("Object");
//ShowMessage(chk_box.OlePropertyGet("name"));

Sh.OlePropertyGet("CheckBoxes",i).OlePropertySet("Value",1);
}
}

void __fastcall Excel::InsertRow(int sRow)
{
AnsiString rows=IntToStr(sRow)+":"+IntToStr(sRow);
 Variant row=Sh.OlePropertyGet("Rows",rows.c_str());
try{row.OleProcedure("Insert",3) ;} catch(...){;}
}

void __fastcall Excel::Print(int count_copy)
{
try {Sh.OleProcedure("PrintOut",1,1,count_copy);} catch(...){;}

}

void __fastcall Excel::Quit()
{
  if(m_typef == FILEXCEL){
   Sh.Clear();
   if(App.OlePropertyGet("Visible") == 0){
      App.OlePropertySet("DisplayAlerts", false);
      App.OlePropertyGet("WorkBooks",1).OleProcedure("Close");
      App.OleProcedure("Quit");
      App.OlePropertySet("DisplayAlerts", true);
   }
   App.Clear();
  }
  else if(m_typef == FILEODS){
   OD.OleFunction("close", true);
   OD = Unassigned();
   App.OleFunction("terminate"); //�� ������� QuickStarter
   App = Unassigned();
  }
}

AnsiString __fastcall Excel::GetValue(int sRow, int sCol)
{
  Variant result,Cell;
  try{
   if(m_typef == FILEXCEL){
      Cell = Sh.OlePropertyGet("Cells",sRow,sCol);  // index start row 1 col 1
      result = (AnsiString) Cell.OlePropertyGet("Value");
    }
    else if(m_typef == FILEODS){
      Cell = Sh.OleFunction("getCellByPosition", sCol - 1 , sRow - 1);  //index start row 0 col 0
      AnsiString type = Cell.OleFunction("getType");
//      Variant eType = App.OleFunction("createInstance", "com.sun.star.table.CellContentType");
      if(type == "1")
        result = (AnsiString) Cell.OleFunction("getValue");
      else if(type == "2")
        result = (AnsiString) Cell.OleFunction("getString");
      else if(type == "3")
        result = (AnsiString) Cell.OleFunction("getFormula");
      else result = "";
    }
    return result;
  }
  catch(Exception &e){
    Application->MessageBox(e.Message.c_str(), ("������: GetValue (" + e.ClassName() + ")").c_str(), MB_OK + MB_ICONERROR);
  }
  catch(...) {
  }

 return "";
}

void __fastcall Excel::AppInitExel(){
   try{
      App = Variant::CreateObject("Excel.Application");
   }
   catch(...){
      Application->MessageBox("���������� ������� Microsoft Excel!"
      "�������� Excel �� ���������� �� ����������.", "������", MB_OK + MB_ICONERROR);
   }

   try{
      if(m_file != "") App.OlePropertyGet("WorkBooks").OleProcedure("Open", m_file.c_str());
      else           App.OlePropertyGet("WorkBooks").OleProcedure("add");
      Sh = App.OlePropertyGet("WorkSheets", 1);
   }
   catch(...){
      Application->MessageBox("������ �������� ����� Microsoft Excel!", "������", MB_OK + MB_ICONERROR);
   }
}

void __fastcall Excel::AppInitOds(){
  Variant
    ServiceManager,
    Sheets,
    props,
    VariantArray;

  int Bounds[2] = {0,0};

  try{
   ServiceManager = Variant::CreateObject("com.sun.star.ServiceManager");
  }
  catch(...){
    Application->MessageBox("���������� ������� OpenOffice!"
    "�������� OpenOffice �� ���������� �� ����������.", "������", MB_OK + MB_ICONERROR);
  }

  try{
    if (VarType(ServiceManager) == varDispatch)
      App = ServiceManager.OleFunction("createInstance", "com.sun.star.frame.Desktop");

      props = ServiceManager.OleFunction("Bridge_GetStruct","com.sun.star.beans.PropertyValue");
      props.OlePropertySet("name", "Hidden");
      props.OlePropertySet("value", true);
      VariantArray = VarArrayCreate(Bounds, 1, varVariant);
      VariantArray.PutElement(props,0);
      AnsiString sUrl = ConvertToURL(m_file);
      OD = App.OleFunction("LoadComponentFromURL", sUrl.c_str(), "_blank", 0, VariantArray);
      if (VarType(OD) == varDispatch){
        Sheets = OD.OleFunction("getSheets");
        Sh = Sheets.OleFunction("getByIndex", 0);
      }
  }
  catch(...){
      Application->MessageBox("������ �������� OpenOffice!", "������", MB_OK + MB_ICONERROR);
  }
}

AnsiString __fastcall Excel::ConvertToURL(AnsiString sFileName){
AnsiString
  sTmpFile,
  ConvertToURL;

  if(sFileName.SubString(0, 7) == "file://"){
    return sFileName;
  }
  ConvertToURL = "file:///";
  sTmpFile = sFileName;
  //replace any "\" by "/"
  sTmpFile = StringReplace(sTmpFile,"\\","/", TReplaceFlags() << rfReplaceAll);
  // replace any % by %25
  sTmpFile = StringReplace(sTmpFile,"%","%25", TReplaceFlags() << rfReplaceAll);
  //replace any " " by "%20"
  sTmpFile = StringReplace(sTmpFile," ","%20", TReplaceFlags() << rfReplaceAll);
  ConvertToURL = ConvertToURL + sTmpFile;

  return ConvertToURL;
}



