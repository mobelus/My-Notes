//---------------------------------------------------------------------------


#pragma hdrstop

#include "KStudProg.h"
#include "BaseVZRMod.h"
#include "Constants.h"

const char* qkKoeff = "select Koeff from VZR174Pr_Koeffs where GroupID = 9 and id_type_calc = %d";
//---------------------------------------------------------------------------
CBaseKoeffStudKoeff::CBaseKoeffStudKoeff(IStudProg *f, TCT tt)
  : m_Iframe(f), m_TypeTariff(tt){}

double CBaseKoeffStudKoeff::CalcKoeff(){
  bool flag = false;
  bool fNotShengen = false;
  AnsiString err;

  try{
     m_Iframe->getStudProg_I(flag, fNotShengen);
    if(m_prTypeTariff == m_TypeTariff && (m_Flag == flag))
      return m_Koeff;
    m_Flag = flag;
    m_prTypeTariff = m_TypeTariff;
  }catch(Exception &e){
    err = e.Message;
  }
//  m_Koeff = (flag && !fNotShengen)?GetDBQuery():1;
  m_Koeff = (flag)?GetDBQuery():1;
  m_DesK = FloatToStr(m_Koeff);

  return m_Koeff ;
}


double CBaseKoeffStudKoeff::GetDBQuery(){
  return gAPI->dbGetFloatFromQuery(gRes, m_SQLf.sprintf(qkKoeff, eROZNICA_FIZ));
}

double CUKoeffStudKoeff::GetDBQuery(){
  return gAPI->dbGetFloatFromQuery(gRes, m_SQLf.sprintf(qkKoeff, eROZNICA_UR));
}

#pragma package(smart_init)

