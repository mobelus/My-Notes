//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "CalcDescription.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFCalcDescription *FCalcDescription;
//---------------------------------------------------------------------------
__fastcall TFCalcDescription::TFCalcDescription(TComponent* Owner)
        : TFrame(Owner)
{


}
//---------------------------------------------------------------------------


