//---------------------------------------------------------------------------


#pragma hdrstop

#include "KProfession.h"
#include "BaseVZRMod.h"

//---------------------------------------------------------------------------
const char* qkProf = "SELECT %s  FROM VZR174Pr_prof_main_K as tblK,"
   " VZR174Pr_prof_group_main_risk as tblDes "
   " where  tblK.id_type_calc = %d and tblDes.id_type_calc = tblK.id_type_calc and tblK.id_group = tblDes.id_prof_group and id = %d";

CBaseKoeffProfession::CBaseKoeffProfession(IProfession *f, TCT tt)
  :m_Iframe(f), m_TypeTariff(tt){
}

double CBaseKoeffProfession::CalcKoeff(){
  int idProf;
  AnsiString  err;

  try{
  if(!m_Iframe->getProfession_I(idProf))
    return 0;
  if(m_prTypeTariff == m_TypeTariff && (m_pridProf == idProf))
    return m_Koeff;
  m_prTypeTariff = m_TypeTariff;
  m_pridProf = idProf;
  }catch(Exception &e){
    err = e.Message;
  }
  GetDBQuery(idProf);
  return m_Koeff;
}

bool CBaseKoeffProfession::GetDBQuery(int id){
  if(gAPI->dbGetIntFromQuery(gRes, m_SQLf.sprintf(qkProf, "count(*)", (int)m_TypeTariff, id)) > 0){
    TADOQuery *pq = gAPI->dbGetCursor(gRes, m_SQLf.sprintf(qkProf, "K, group", (int)m_TypeTariff, id));
    m_Koeff = pq->FieldByName("K")->AsFloat;
    m_DesK = FloatToStr(m_Koeff) + " (" + pq->FieldByName("group")->AsString + ")";
    gAPI->dbCloseCursor(gRes, pq);
    return true;
  }
  return false;
}

bool CUKoeffProfession::GetDBQuery(int id){
  if(!CBaseKoeffProfession::GetDBQuery(id)){
    m_TypeTariff = eROZNICA_FIZ;
    return CBaseKoeffProfession::GetDBQuery(id);
  }
  else
    return true;
}

bool CPartnerKoeffProfession::GetDBQuery(int id){
  if(!CBaseKoeffProfession::GetDBQuery(id)){
    m_TypeTariff = eROZNICA_UR;
    return CUKoeffProfession::GetDBQuery(id);
  }
  else
    return true;
}

bool CIVCKoeffProfession::GetDBQuery(int id){
  if(!CBaseKoeffProfession::GetDBQuery(id)){
    m_TypeTariff = ePARTNER_UR;
    return CPartnerKoeffProfession::GetDBQuery(id);
  }
  else
    return true;
}
#pragma package(smart_init)

