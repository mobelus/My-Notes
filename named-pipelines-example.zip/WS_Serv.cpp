//---------------------------------------------------------------------------


#pragma hdrstop

#include "WS_Serv.h"

void Main_Func(mops_api_027* m_api)
{
bool debuging = true; //!m_api->is_debug;
int is_error = Main_Public(m_api);
  if(is_error == 0)
    {
    SetPublicVirtu(m_api);
    if(debuging) Application->MessageBox( "�������� ��������� �� ������ ����� ����������� �������", "��������", MB_OK | MB_ICONINFORMATION);
    //AnsiString temp = product_message + ". �������� � ����� ��������� �������."; MB_OK | MB_ICONINFORMATOIN
    //ShowMessage(temp.c_str());
    }
  else if(is_error > 0)
    {
    Application->NormalizeTopMosts();
    switch(is_error)
       {
       case 1:
       case 2:  if(debuging) Application->MessageBox( "������ �������� libcurl!", "������", MB_OK | MB_ICONERROR); break;
       case 3:  if(debuging) Application->MessageBox( "������ ����������� �� ������� VIRTU!", "������", MB_OK | MB_ICONERROR); break;
       case 4:  if(debuging) Application->MessageBox( "������ ���������� ��������� �� ������� VIRTU!", "������", MB_OK | MB_ICONERROR); break;
       default:  if(debuging) Application->MessageBox( "������, ���������� � ������������!", "������", MB_OK | MB_ICONERROR);
       }
    }
  else
    {
     if(debuging) Application->MessageBox( "��� ��������� ��������� ��� �������� �� ������ �����", "��������", MB_OK | MB_ICONINFORMATION);
    }
}
//-----------------------------------------------------------------


int Main_Public(mops_api_027* m_api)
{
	AnsiString xml_ansi = GenerateXML(m_api);
	if (xml_ansi.IsEmpty()) return -1;
	char *xml_char = xml_ansi.c_str();

	//char *xml_char = new char [xml_ansi.Length()];

	//strcpy(xml_char, xml_ansi.c_str());

	HINSTANCE cl = 0;
	if ((cl = LoadLibrary("libcurl.dll")) == 0)
	{
		Application->NormalizeTopMosts();
		//Application->MessageBox( "������ �������� libcurl!" , "������", MB_OK | MB_ICONERROR);
		Application->RestoreTopMosts();
		return 2;
	}
	else
	{
		CURLcode(__stdcall *curl_global_init)(long);
		curl_global_init = (CURLcode(__stdcall *)(long))GetProcAddress(cl, "curl_global_init");
		curl_global_init(CURL_GLOBAL_DEFAULT);
	}

	if (!cl)
	{
		Application->NormalizeTopMosts();
		//Application->MessageBox( "������ �������� libcurl!", "������", MB_OK | MB_ICONERROR);
		Application->RestoreTopMosts();
		return 1;
	}

	// ���������� ���������� �� �������
	CURL*(__stdcall *curl_easy_init)();
	CURLcode(__stdcall *curl_easy_setopt) (CURL *curl, CURLoption option, ...);
	CURLcode(__stdcall *curl_easy_perform) (CURL *curl);
	CURLcode(__stdcall *curl_easy_getinfo) (CURL *curl, CURLINFO info, ...);
	CURLFORMcode(__stdcall *curl_formadd)(struct curl_httppost ** firstitem, struct curl_httppost ** lastitem, ...);
	void(__stdcall *curl_easy_cleanup) (CURL *curl);
	struct curl_slist *(__stdcall *curl_slist_append) (struct curl_slist *list, const char *string);
	void(__stdcall *curl_slist_free_all) (struct curl_slist * list);
	char* (__stdcall *curl_easy_escape)(CURL * curl, const char * string, int length);

	// ����������� ���������� ������� ��������������� ������ ������� DLL
	curl_easy_init = (CURL*(__stdcall*)())GetProcAddress(cl, "curl_easy_init");
	curl_easy_setopt = (CURLcode(__stdcall *)(CURL *curl, CURLoption option, ...)) GetProcAddress(cl, "curl_easy_setopt");
	curl_easy_perform = (CURLcode(__stdcall *)(CURL *curl))GetProcAddress(cl, "curl_easy_perform");
	curl_easy_cleanup = (void(__stdcall *)(CURL *curl))GetProcAddress(cl, "curl_easy_cleanup");
	curl_easy_getinfo = (CURLcode(__stdcall *) (CURL *curl, CURLINFO info, ...))GetProcAddress(cl, "curl_easy_getinfo");
	curl_slist_append = (curl_slist*(__stdcall *) (struct curl_slist *list, const char *string))GetProcAddress(cl, "curl_slist_append");
	curl_slist_free_all = (void(__stdcall *) (struct curl_slist *list))GetProcAddress(cl, "curl_slist_free_all");
	curl_formadd = (CURLFORMcode(__stdcall *)(struct curl_httppost **firstitem, struct curl_httppost **lastitem, ...))GetProcAddress(cl, "curl_formadd");
	curl_easy_escape = (char *(__stdcall*)(CURL * curl, const char *string, int length))GetProcAddress(cl, "curl_easy_escape");

	CURL *curl;  //��������� ������
	AnsiString table;  //��������� ���������� ��� ������� html-���� ��������� �����
	AnsiString xml_text;

	AnsiString host, port, host_port;
	GetProxy(host, port, host_port);

	curl = curl_easy_init();  // ������������� ������

	AnsiString ws_host = GetParam(m_api, pr_name, 1);
	AnsiString ws_login = GetParam(m_api, "������", 4);
	AnsiString ID_prod = GetParam(m_api, pr_name, 5);
	AnsiString ws_post_login = "https://" + ws_host + GetParam(m_api, pr_name, 2);
	AnsiString ws_post_pub = "https://" + ws_host + GetParam(m_api, "������", 3) + ID_prod;

	if (curl)
	{
		// ��������� ����������
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, Writer);  // ������ ������� ������ ������
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &table);  // ���������� ������ � ����������
		curl_easy_setopt(curl, CURLOPT_URL, ws_post_login.c_str());  //������ URL
		curl_easy_setopt(curl, CURLOPT_HEADER, 1); // ���������� ��������� (1- ����������; 0 � �� ����������)
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 30);
		curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "cookies.txt");
		curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "cookies.txt");
		curl_easy_setopt(curl, CURLOPT_COOKIESESSION, 1);
		curl_easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);  // �� ��������� SSL ����������
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);  // �� ��������� Host SSL �����������
		curl_easy_setopt(curl, CURLOPT_NOPROXY, ws_host.c_str());
		curl_easy_setopt(curl, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
		curl_easy_setopt(curl, CURLOPT_PROXY, host_port);
		//curl_easy_setopt(curl,CURLOPT_PROXYUSERPWD,"RGSMAIN\\IIKuznetsov:Pass");
		curl_easy_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
		curl_easy_setopt(curl, CURLOPT_POST, 1);

		struct curl_slist *list = NULL;
		list = curl_slist_append(list, "Content-Type: application/json");
		list = curl_slist_append(list, (AnsiString("Host:") + ws_host).c_str());

		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, list);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, ws_login.c_str());
		curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, ws_login.Length());

		//����������� �������
		curl_easy_perform(curl);

		//(*response) = table;

		//Memo1->Lines->Append(table);

		//struct curl_slist *list_cook = NULL;  ���� ����� ����
		//curl_easy_getinfo(curl, CURLINFO_COOKIELIST, &list_cook);
		//(*response) = list_cook->data;
		curl_slist_free_all(list);
		curl_easy_cleanup(curl);
	}
	else
	{
		return 2;
	}

	if (WS_Auth(table))
	{
		bool debuging = true;
		curl = curl_easy_init();
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, Writer);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &table);
		curl_easy_setopt(curl, CURLOPT_HEADER, 1);
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 30);
		curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "cookies.txt");
		curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "cookies.txt");
		//curl_easy_setopt(curl, CURLOPT_COOKIE, list_cook );
		curl_easy_setopt(curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		if (debuging)
			curl_easy_setopt(curl, CURLOPT_DEBUGFUNCTION, my_trace);

		//struct data {char trace_ascii; /* 1 or 0 */};
		//struct data config;


		//curl_easy_setopt(curl, CURLOPT_DEBUGDATA, &config);
		curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);

		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

		curl_easy_setopt(curl, CURLOPT_NOPROXY, ws_host.c_str());
		curl_easy_setopt(curl, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
		curl_easy_setopt(curl, CURLOPT_PROXY, host_port);
		//curl_easy_setopt(curl,CURLOPT_PROXYUSERPWD,"RGSMAIN\\IIKuznetsov:Pass");
		curl_easy_setopt(curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);

		struct curl_httppost *formpost = NULL;
		struct curl_httppost *lastptr = NULL;

		curl_formadd(&formpost, &lastptr,
			CURLFORM_COPYNAME, "filename",
			CURLFORM_BUFFER, "filename",
			CURLFORM_BUFFERPTR, xml_char,
			CURLFORM_BUFFERLENGTH, strlen(xml_char),
			CURLFORM_END);

		curl_easy_setopt(curl, CURLOPT_URL, ws_post_pub.c_str());
		curl_easy_setopt(curl, CURLOPT_HTTPPOST, formpost);

		if (debuging)
		{
			TStringList *temp = new TStringList;
			temp->SaveToFile("INFO.log");
			temp->SaveToFile("HEADER_OUT.log");
			temp->SaveToFile("DATA_OUT.log");
			temp->SaveToFile("SSL_DATA_OUT.log");
			temp->SaveToFile("HEADER_IN.log");
			temp->SaveToFile("DATA_IN.log");
			delete temp;
		}

		curl_easy_perform(curl);
		if (WS_Pub(table)) return 0;
		else return 4;
	}
	return 3;
}



int my_trace(CURL *handle, curl_infotype type,
             char *data, size_t size,
             void *userp)
{
  (void)handle; /* prevent compiler warning */
  TStringList *temp = new TStringList;


  switch (type) {
  case CURLINFO_TEXT:
    temp->LoadFromFile("INFO.log");
    temp->Append(AnsiString(data));
    temp->SaveToFile("INFO.log");
     return 0;

  case CURLINFO_HEADER_OUT:
    temp->LoadFromFile("HEADER_OUT.log");
    temp->Append(AnsiString(data));
    temp->SaveToFile("HEADER_OUT.log");
    break;
  case CURLINFO_DATA_OUT:
    temp->LoadFromFile("DATA_OUT.log");
    temp->Append(AnsiString(data));
    temp->SaveToFile("DATA_OUT.log");
    break;
  case CURLINFO_SSL_DATA_OUT:
    temp->LoadFromFile("SSL_DATA_OUT.log");
    temp->Append(AnsiString(data));
    temp->SaveToFile("SSL_DATA_OUT.log");
    break;
  case CURLINFO_HEADER_IN:
    temp->LoadFromFile("HEADER_IN.log");
    temp->Append(AnsiString(data));
    temp->SaveToFile("HEADER_IN.log");
    break;
  case CURLINFO_DATA_IN:
    temp->LoadFromFile("DATA_IN.log");
    temp->Append(AnsiString(data));
    temp->SaveToFile("DATA_IN.log");
    break;
  /*case CURLINFO_SSL_DATA_IN:
    text = "<= Recv SSL data";
    break;  */
  }
}


//-----------------------------------------------------------------
bool SaveTextToFile(AnsiString _FileName, AnsiString _dataToWrite)
{
	HANDLE hFile;
	BOOL bErrorFlag = FALSE;
	hFile = CreateFile(_FileName.c_str(), GENERIC_WRITE,     0, NULL,
                        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hFile == INVALID_HANDLE_VALUE) { return false; }

	DWORD dwBytesToWrite = (DWORD)(_dataToWrite.Length());
	DWORD dwBytesWritten = 0;
	bErrorFlag = WriteFile(      hFile, _dataToWrite.c_str(),   dwBytesToWrite,             &dwBytesWritten,  NULL); // no overlapped structure

    if (FALSE == bErrorFlag)
    { return false; }
    else
    {
        if (dwBytesWritten != dwBytesToWrite)
        { return false; }
        else
        { /*_tprintf(TEXT("Wrote %d bytes to %s successfully.\n"), dwBytesWritten, _FileName); */ }
    }

    CloseHandle(hFile);
	return true;
}


//-----------------------------------------------------------------
bool WS_Auth(AnsiString &text)
{
if(!text.IsEmpty())
   {
   if ( (text.Pos(".INSURANCE=") > 0) && (text.Pos("{\"d\":true}") > 0)) return true;
   }
return false;
}

//-----------------------------------------------------------------
bool WS_Pub(AnsiString &text)
{
  if(!text.IsEmpty())
  {
    SaveTextToFile("C:\\Users\\Public\\VZR174Pr_RESPONSE.xml", text);
    if(text.Pos("{ \"success\": true }") > 0)
      return true;
  }
  return false;
}

//-----------------------------------------------------------------
AnsiString GenerateXML(mops_api_027* m_api)
{
_di_IXMLNode root, policys, policy, node1, node2, node3;
_di_IXMLDocument XMLDoc = NewXMLDocument();
XMLDoc->Active = true;
XMLDoc->Options = XMLDoc->Options<<doNodeAutoCreate
                                   <<doNodeAutoIndent // ����������
                                   <<doAttrNull
                                   <<doAutoPrefix
                                   <<doNamespaceDecl;

XMLDoc->ParseOptions = XMLDoc->ParseOptions<<poResolveExternals
                                             <<poValidateOnParse
                                             <<poPreserveWhiteSpace
                                             <<poAsyncLoad;
  // ��������������, ������ - ���������, ���� ������ - ������ - poPreserveWhiteSpace
XMLDoc->NodeIndentStr = "\t"; // poPreserveWhiteSpace
XMLDoc->Encoding = "WINDOWS-1251";
XMLDoc->StandAlone = "no";

root = XMLDoc->Node->AddChild("export");
SetAttribute(root, "partner", "-");
AnsiString temp_field;
DateTimeToString(temp_field, "yyyy.mm.dd hh:nn:ss", Now());
SetAttribute(root, "export_date", temp_field);
SetAttribute(root, "export_id", "1");
//SetAttribute(root, "export_version", "03");
policys = root->AddChild("policys");
bool dogovor = GeneratePolisXML(policys, m_api);
XMLDoc->SaveToFile("�����������������174.xml");
if(dogovor) return XMLDoc->XML->Text;
else return "";
//XMLDoc->SaveToStream(stream);
}
//-----------------------------------------------------------------

bool GeneratePolisXML(_di_IXMLNode &root, mops_api_027* m_api)
{
AnsiString temp;
int res;
bool is_dogovor = false;
_di_IXMLNode policy, persons, person, person_value, insure, contacts, riskobject, autovehicles, paymentdatas, paymentdata, risk, attribute;
TADOQuery *q, *q_calc, *q_zastrah;

AnsiString date_text = m_api->Internal_Convert_Date_To_SQL(res, CDSendWS);
AnsiString sql_txt =
"select calc_id from "+product+"_calc where iif(isnull(virtu),0,virtu)=0 "
"and calc_id in (select id from _mops_calcs_ where NoErrors=true) "
"and data_zayavl >= "+date_text.c_str();
//int firster = 0;
q=m_api->dbGetCursor(res,sql_txt.c_str());
while(!q->Eof)
   {
      //firster = 1;
      is_dogovor = true;
      q_calc = m_api->dbGetCursor(res,AnsiString("select * from ")+product+"_calc where calc_id="+q->FieldByName("calc_id")->AsString);
      policy = root->AddChild("policy");

      AnsiString skk_sql = "SELECT SKK FROM _mops_polzovateli_ as w left join _mops_calcs_ as q on w.id = q.id_polzovatelya where q.id = " + q->FieldByName("calc_id")->AsString;
      skk_sql = m_api->dbGetStringFromQuery(res, skk_sql);
      AnsiString ser = q_calc->FieldByName("strach_polis_ser")->AsString;
      //if(ser.Pos("-") <= 0) ser = "-" + ser;
      AddChildValue(policy,"branch_code", "");
      AddChildValue(policy,"contract_series", ser);
      AddChildValue(policy,"contract_number", q_calc->FieldByName("strach_polis_num")->AsString);
      AddChildValue(policy,"policy_series", ser);
      AddChildValue(policy,"policy_number", q_calc->FieldByName("strach_polis_num")->AsString);
      AddChildValue(policy,"product_class_id", AnsiString("1"));
      AddChildValue(policy,"status_police", AnsiString("����������"));

      DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("str_polis_start_data")->AsDateTime);
      AddChildValue(policy,"start_date", temp);
      AddChildValue(policy,"policy_start_date", temp);


      /*if(q_calc->FieldByName("MainMultiTrip")->AsInteger > 0)
         {
         TDateTime st = (q_calc->FieldByName("str_polis_start_data")->AsDateTime);
         TDateTime et = (q_calc->FieldByName("str_polis_end_data")->AsDateTime);
         if(((int)(et - st)) <= 90)
            {
             et = et + q_calc->FieldByName("MainDays")->AsInteger;
             TDateTime elim = st + 90;
             elim = elim - 1;
             if(et > elim) et = elim;
            }
         DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", et);
         }
      else
         {
         DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("str_polis_end_data")->AsDateTime);
         }  */
      DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("str_polis_end_data")->AsDateTime);
      AddChildValue(policy,"end_date", temp);
      AddChildValue(policy,"policy_end_date", temp);

      AddChildValue(policy,"days", IntToStr(q_calc->FieldByName("MainDays")->AsInteger));

      AddChildValue(policy,"currency_type", q_calc->FieldByName("CurrencyName")->AsString);
      AddChildValue(policy,"is_currency_equivalent", "1");

      //DateTimeToString(temp,"yyyy-mm-dd", q_calc->FieldByName("data_zayavl")->AsDateTime);
      //AddChildValue(policy,"policy_date", temp);

      DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("data_zayavl")->AsDateTime);
      AddChildValue(policy,"policy_date", temp);

      DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("premium_charge_date")->AsDateTime);
      AddChildValue(policy,"premium_charge_date", temp);

      persons = policy->AddChild("persons");
      person = persons->AddChild("person");

      AnsiString ur_or_fiz = q_calc->FieldByName("strach_fiz_yur")->AsString;

      //if(ur_or_fiz == "���������� ����") ur_or_fiz = "0";     ������ ���.
      //else ur_or_fiz = "1";

      AddChildValue(person,"is_juridical", AnsiString("0"));
      AddChildValue(person,"is_insured", AnsiString("1"));
      AddChildValue(person,"is_insurant", AnsiString("1"));
      AddChildValue(person,"is_beneficiary", AnsiString("0"));

      AddChildValue(person,"first_name", q_calc->FieldByName("strach_i")->AsString);
      AddChildValue(person,"last_name", q_calc->FieldByName("strach_f")->AsString);
      AddChildValue(person,"second_name", q_calc->FieldByName("strach_o")->AsString);

      DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("strach_dr")->AsDateTime);
      AddChildValue(policy,"physical_bitrh_date", temp);

      AddChildValue(person,"exact_address", q_calc->FieldByName("strach_address")->AsString);

      contacts = persons->AddChild("contacts");
      contacts = contacts->AddChild("contact");
      SetAttribute(contacts, "contact_type_id", AnsiString("3"));
      SetAttribute(contacts, "contract_data", q_calc->FieldByName("strach_tel")->AsString);

      //AddChildValue(person,"contact_type_id", AnsiString("3"));
      //AddChildValue(person,"contact contract_data", q_calc->FieldByName("strach_tel")->AsString);

      autovehicles = policy->AddChild("autovehicles");
      autovehicles = autovehicles->AddChild("autovehicle");
      autovehicles = autovehicles->AddChild("riskobjects");

      q_zastrah = m_api->dbGetCursor(res,AnsiString("select * from ")+product+"_Insured where id_calc="+q->FieldByName("calc_id")->AsString);
      while(!q_zastrah->Eof)
         {
         int val = q_calc->FieldByName("RisksFlags")->AsInteger;
         AnsiString object_type_id;
         AnsiString object_code;
         int type = 0;
         while(val > 0)
            {
            if(val >= 16)
             {
              val = val - 16;
              AnsiString roots = q_calc->FieldByName("Program")->AsString;
              if(roots == AnsiString("1 - ������")) {object_type_id = "_ROOT00000000000017400001", object_code = "1 - ������";}
              else if(roots == AnsiString("2 - ��������")) {object_type_id = "_ROOT00000000000017400002"; object_code = "2 - ��������";}
              else if(roots == AnsiString("3 - �������")) {object_type_id = "_ROOT00000000000017400003"; object_code = "3 - �������";}
              else if(roots == AnsiString("4 - �������")) {object_type_id = "_ROOT00000000000017400004"; object_code = "4 - �������";}
              type = 1;
              //goto: next;
             }
            else if(val >= 8)
             {
              val = val - 8;
              AnsiString roots = q_calc->FieldByName("AccidentTypeName")->AsString;
              roots = roots.SubString(1,2);
              if(roots == AnsiString("N1")) {object_type_id = "_ROOT00000000000017400022"; object_code = "N1";}
              else if(roots == AnsiString("N2")) {object_type_id = "_ROOT00000000000017400023"; object_code = "N2";}
              else if(roots == AnsiString("N3")) {object_type_id = "_ROOT00000000000017400024"; object_code = "N3";}
              type = 2;
              //goto: next;
             }
            else if(val >= 4)
             {
              val = val - 4;
              object_type_id = "_ROOT00000000000017400021"; object_code = "G1";
              type = 3;
              //goto: next;
             }
            else if(val >= 2)
             {
              val = val - 2;
              type = 4;
              //goto: next;
             }
            else if(val >= 1)
             {
              val = val - 1;
              AnsiString roots = q_calc->FieldByName("LossBagTransportTypeName")->AsString;
              roots = roots.SubString(1,2);
              if(roots == AnsiString("B1")) {object_type_id = "_ROOT00000000000017400014"; object_code = "B1";}
              else if(roots == AnsiString("B2")) {object_type_id = "_ROOT00000000000017400025"; object_code = "B2";}
              else if(roots == AnsiString("B3")) {object_type_id = "_ROOT00000000000017400026"; object_code = "B3";}
              type = 5;
              //goto: next;
             }
            //next:
            double valute = q_calc->FieldByName("ExchangeRate")->AsFloat;
            risk = autovehicles->AddChild("riskobject");
            SetAttribute(risk,"risk_object_type_id", object_type_id);
            SetAttribute(risk,"program_code", object_code);

            if(type == 1)
               {
               SetAttribute(risk,"liability", ConvertFloatToStrPoint(m_api,q_calc->FieldByName("MainSumm")->AsFloat));
               SetAttribute(risk,"liability_rur", ConvertFloatToStrPoint(m_api, (q_calc->FieldByName("MainSumm")->AsFloat * valute)));
               SetAttribute(risk,"premium", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("med_premium")->AsString)));
               SetAttribute(risk,"premium_rur", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("med_premium_rur")->AsString)));
               SetAttribute(risk,"franchise_sum", AnsiString("0"));
               SetAttribute(risk,"is_conditional_franchise", AnsiString("0"));
               }
            if(type == 2)
               {
               SetAttribute(risk,"liability", ConvertFloatToStrPoint(m_api, q_calc->FieldByName("AccidentSummValue")->AsFloat));
               SetAttribute(risk,"liability_rur", ConvertFloatToStrPoint(m_api, (q_calc->FieldByName("AccidentSummValue")->AsFloat * valute)));
               SetAttribute(risk,"premium", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("Accident_premium")->AsString)));
               SetAttribute(risk,"premium_rur", ConvertFloatToStrPoint(m_api, (StrToFloat(q_zastrah->FieldByName("Accident_premium")->AsString) * valute)));
               SetAttribute(risk,"franchise_sum", AnsiString("0"));
               SetAttribute(risk,"is_conditional_franchise", AnsiString("0"));
               }
            if(type == 3)
               {
               SetAttribute(risk,"liability", ConvertFloatToStrPoint(m_api, q_calc->FieldByName("CivilLiabilitySummValue")->AsFloat));
               SetAttribute(risk,"liability_rur", ConvertFloatToStrPoint(m_api, q_calc->FieldByName("CivilLiabilitySummValue")->AsFloat * valute));
               SetAttribute(risk,"premium", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("CivilLiability_premium")->AsString)));
               SetAttribute(risk,"premium_rur", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("CivilLiability_premium")->AsString) * valute));
               SetAttribute(risk,"franchise_sum", AnsiString("0"));
               SetAttribute(risk,"is_conditional_franchise", AnsiString("0"));
               }
            if(type == 4)
               {
                //fhfhfhgfg
               }
            if(type == 5)
               {
               SetAttribute(risk,"liability", ConvertFloatToStrPoint(m_api, q_calc->FieldByName("LossBagSummValue")->AsFloat));
               SetAttribute(risk,"liability_rur", ConvertFloatToStrPoint(m_api, (q_calc->FieldByName("LossBagSummValue")->AsFloat * valute)));
               SetAttribute(risk,"premium", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("LossBag_premium")->AsString)));
               SetAttribute(risk,"premium_rur", ConvertFloatToStrPoint(m_api, StrToFloat(q_zastrah->FieldByName("LossBag_premium")->AsString) * valute));
               SetAttribute(risk,"franchise_sum", AnsiString("0"));
               SetAttribute(risk,"is_conditional_franchise", AnsiString("0"));// ConvertFloatToStrPoint(m_api, q_calc->FieldByName("LossBagFranchiseKoefValue")->AsFloat));
               }
            risk = risk->AddChild("riskobjectrisk_attribute");

            SetAttributeAttrib(risk,AnsiString("first_last_name"),AnsiString(q_zastrah->FieldByName("InsuredPersonFIO")->AsString));
            DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_zastrah->FieldByName("InsuredPersonBirthday")->AsDateTime);
            SetAttributeAttrib(risk,AnsiString("birth_date"), temp);
            SetAttributeAttrib(risk,AnsiString("is_special_conditions_age"), AnsiString("���"));

            double prems = q_calc->FieldByName("AllPremiumRUR")->AsFloat;
            AnsiString dop_usl_bool = "���";
            AnsiString dop_usl = "";

            /*if(prems > 15000)
               {
               AnsiString graz = q_calc->FieldByName("strach_pasport_gr")->AsString;
               if(graz == "��")
                  {
                  dop_usl_bool = "��";
                  dop_usl = q_calc->FieldByName("strach_pasport_type")->AsString + " ������������: ";
                  dop_usl = dop_usl + q_calc->FieldByName("strach_pasport_ser")->AsString + " ";
                  dop_usl = dop_usl + q_calc->FieldByName("strach_pasport_num")->AsString + " ";
                  if(!q_calc->FieldByName("strach_pasport_kem_vidan")->IsNull)
                     {
                     dop_usl = dop_usl + q_calc->FieldByName("strach_pasport_kem_vidan")->AsString + ", ";
                     }
                  if(!q_calc->FieldByName("strach_pasport_data")->IsNull)
                     {
                     DateTimeToString(temp,"dd.mm.yyyy", q_calc->FieldByName("strach_pasport_data")->AsDateTime);
                     dop_usl = dop_usl + temp + ", ";
                     }
                  if(!q_calc->FieldByName("strach_pasport_kod_podr")->IsNull)
                     {
                  dop_usl = dop_usl + q_calc->FieldByName("strach_pasport_kod_podr")->AsString + ", ";
                     }
                  if(!q_calc->FieldByName("strach_pasport_addr")->IsNull)
                     {
                     dop_usl = dop_usl + q_calc->FieldByName("strach_pasport_addr")->AsString;
                     }
                  }
               }   */

            SetAttributeAttrib(risk,AnsiString("is_payment_bank_card"), AnsiString("���"));
            SetAttributeAttrib(risk,AnsiString("payment_bank_name"), AnsiString(""));

            SetAttributeAttrib(risk,AnsiString("is_alcohilic"), (q_calc->FieldByName("alko_med")->AsInteger > 0 ? AnsiString("��") : AnsiString("���")) );

            //---------------------------------------------------------
            //������ ����� ����� ������� � ��, ��� ���������, � �� �������� ������ � ����� � �������� �����.
            AnsiString str_OsobUslov = "";
            if (q_calc->FieldByName("MainMultiTrip")->AsInteger > 0 ? true : false)
               {
                if (q_calc->FieldByName("MainDays")->AsInteger < 90)
                   str_OsobUslov = str_OsobUslov + "������������ �������.";
                else if (q_calc->FieldByName("MainMultiTrip")->AsInteger == 1)
                   str_OsobUslov = str_OsobUslov + "������������ �������, ������ ������� �� ����� 90 ����.";
               }
            if (q_calc->FieldByName("alko_med")->AsInteger > 0 ? true : false)
               {
                if ((q_calc->FieldByName("RisksFlags")->AsInteger > 8) && (q_calc->FieldByName("MainSumm")->AsFloat > 0) && (q_calc->FieldByName("CivilLiabilitySummValue")->AsFloat > 0))
                   str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 13.1. 1)  �); �. 23.2. 5); �. 34.1. 16)  �� ����������� �� ����������� �������������� � ���.";
                else if( (q_calc->FieldByName("MainSumm")->AsFloat > 0) && (q_calc->FieldByName("RisksFlags")->AsInteger > 8))
                   str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 13.1. 1)  �); �. 23.2. 5) �� ����������� �� ����������� �������������� � ���.";
                else if( (q_calc->FieldByName("MainSumm")->AsFloat > 0) && (q_calc->FieldByName("CivilLiabilitySummValue")->AsFloat > 0))
                   str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 13.1. 1)  �); �. 34.1. 16)  �� ����������� �� ����������� �������������� � ���.";
                else if( (q_calc->FieldByName("RisksFlags")->AsInteger > 8) && (q_calc->FieldByName("CivilLiabilitySummValue")->AsFloat > 0) )
                   str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 23.2. 5); �. 34.1. 16)  �� ����������� �� ����������� �������������� � ���.";
                else if(q_calc->FieldByName("MainSumm")->AsFloat > 0)
                  str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 13.1. 1)  �) �� ����������� �� ����������� �������������� � ���.";
                else if(q_calc->FieldByName("RisksFlags")->AsInteger > 8)
                  str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 23.2. 5) �� ����������� �� ����������� �������������� � ���.";
                else if(q_calc->FieldByName("CivilLiabilitySummValue")->AsFloat > 0)
                  str_OsobUslov = str_OsobUslov + " � ��������� ������� �������� �. 34.1. 16) �� ����������� �� ����������� �������������� � ���.";
                //else if(q_calc->FieldByName("RisksFlags")->AsInteger > 8)
                //str_OsobUslov = str_OsobUslov + " ������� ������ �.";
               }
            /*if (((q_calc->FieldByName("RisksFlags")->AsInteger) & 8) >= 8)
               {
                str_OsobUslov = str_OsobUslov + " ������� �������� ��������� ������ �.";
               }   */

            //---------------------------------------------------------
            //str_OsobUslov = str_OsobUslov + (skk_sql.SubString(2,2) == "77" ? AnsiString("������ 150") : AnsiString(" ������ 0" + skk_sql.SubString(2,2)));
            str_OsobUslov = IntToStr(q_calc->FieldByName("regcode")->AsInteger) + ";" + str_OsobUslov;
            //if(dop_usl.Length() > 0)
            //   str_OsobUslov = str_OsobUslov + " " +dop_usl;

            if(str_OsobUslov.Length() > 0) dop_usl_bool = "��";
            
            SetAttributeAttrib(risk,AnsiString("is_additional_terms"), dop_usl_bool);
            SetAttributeAttrib(risk,AnsiString("additional_terms_description"), str_OsobUslov);

            SetAttributeAttrib(risk,AnsiString("is_multiple_trip"), (q_calc->FieldByName("MainMultiTrip")->AsInteger > 0 ? AnsiString("��") : AnsiString("���")));
            bool temps = q_calc->FieldByName("fStudProg")->AsBoolean;
            SetAttributeAttrib(risk,AnsiString("is_education"),(temps ? AnsiString("��") : AnsiString("���")));
            if(temps)
                SetAttributeAttrib(risk,AnsiString("education_coefficient"), AnsiString("1.2"));
            SetAttributeAttrib(risk,AnsiString("virtu_product_name"), AnsiString("174 TP1"));
            SetAttributeAttrib(risk,AnsiString("is_special_conditions_active"), (q_calc->FieldByName("MainKoefSportName")->AsString == "���" ? AnsiString("���") : AnsiString("��")));
            //SetAttributeAttrib(risk,AnsiString("is_special_conditions_is_special_conditions_profession"), AnsiString("���"));
            SetAttributeAttrib(risk,AnsiString("is_special_conditions_profession"), (q_calc->FieldByName("MainKoefProfName")->AsString == "���" ? AnsiString("���") : AnsiString("��")));
            temp = q_calc->FieldByName("MainKoefProfName")->AsString;
            if(temp != "���")
               {
               if(temp == "1-�� ���������") SetAttributeAttrib(risk,AnsiString("special_conditions_profession_category"), AnsiString("��������� 1"));
               else if(temp == "2-�� ���������") SetAttributeAttrib(risk,AnsiString("special_conditions_profession_category"), AnsiString("��������� 2"));
               else if(temp == "3-�� ���������") SetAttributeAttrib(risk,AnsiString("special_conditions_profession_category"), AnsiString("��������� 3"));
               else if(temp == "4-�� ���������") SetAttributeAttrib(risk,AnsiString("special_conditions_profession_category"), AnsiString("��������� 4"));
               else if(temp == "5-�� ���������") SetAttributeAttrib(risk,AnsiString("special_conditions_profession_category"), AnsiString("��������� 5"));
               }
            temp = q_calc->FieldByName("MainKoefSportName")->AsString;
            SetAttributeAttrib(risk,("is_special_conditions_sport"), (temp == "���" ? AnsiString("���") : AnsiString("��")));
            if(temp != "���")
               {
               if(temp == "�������� ���������� ������") SetAttributeAttrib(risk,AnsiString("special_conditions_sport_risks"), AnsiString("������ 2"));
               else if(temp == "������� ������������ �������") SetAttributeAttrib(risk,AnsiString("special_conditions_sport_risks"), AnsiString("������ 3"));
               else if(temp == "������� ���������������� �������") SetAttributeAttrib(risk,AnsiString("special_conditions_sport_risks"), AnsiString("������ 4"));
               }

            SetAttributeAttrib(risk,AnsiString("trip_days_count"), IntToStr(q_calc->FieldByName("MainDays")->AsInteger));

            int id_terr = q_calc->FieldByName("idMainTerritory")->AsInteger;
            //AnsiString ter = m_api->dbGetStringFromQuery(res, "select terr_name from vzr174pr_terr where id_terr=" + IntToStr(id_terr));

            SetAttributeAttrib(risk,AnsiString("policy_type"), AnsiString("�� ��"));

            SetAttributeAttrib(risk,AnsiString("host_country"), AnsiString(q_calc->FieldByName("CountryReport")->AsString));

            int temps_i = q_calc->FieldByName("cbZabolevanie")->AsInteger;
            SetAttributeAttrib(risk,AnsiString("is_chronical"), (temps_i ? AnsiString("��"): AnsiString("���")));
            if(temps_i > 0)
               SetAttributeAttrib(risk,AnsiString("chronical_coefficient"), AnsiString("5"));

            temps_i = q_calc->FieldByName("cbBeremennost")->AsInteger;
            SetAttributeAttrib(risk,AnsiString("is_pregnancy"), (temps_i ? AnsiString("��"): AnsiString("���")));
            if(temps_i > 0)
                SetAttributeAttrib(risk,AnsiString("pregnancy_coefficient"), AnsiString("5"));

            SetAttributeAttrib(risk,AnsiString("gc_cross_selling"), AnsiString("���"));
            SetAttributeAttrib(risk,AnsiString("is_terrorism"), AnsiString("���"));

            if(type == 5)
               {
               AnsiString loss = q_calc->FieldByName("LossBagTransportTypeName")->AsString;
               if(loss.Length() > 0)
                  {
                   int bag = q_zastrah->FieldByName("nbag")->AsInteger;
                   SetAttributeAttrib(risk,AnsiString("baggage_places_count"), IntToStr(bag));
                   int nums_id;
                   if(! q_calc->FieldByName("LossBagTimeFranchiseTime")->IsNull)
                      {
                      AnsiString times= q_calc->FieldByName("LossBagTimeFranchiseTime")->AsString.c_str();
                      if(times.Length() > 0)
                        SetAttributeAttrib(risk,AnsiString("baggage_franchise_in_hours"), times);
                      }
                  }
               }
            }
          q_zastrah->Next();
         }
      m_api->dbCloseCursor(res,q_zastrah);

      paymentdatas = policy->AddChild("paymentdatas");
      paymentdata = paymentdatas->AddChild("paymentdata");
      DateTimeToString(temp,"yyyy.mm.dd hh:nn:ss", q_calc->FieldByName("premium_charge_date")->AsDateTime);
      SetAttribute(paymentdata, "payment_date", temp);
      SetAttribute(paymentdata, "payment_sum", ConvertFloatToStrPoint(m_api, q_calc->FieldByName("AllPremium")->AsFloat));
      SetAttribute(paymentdata, "payment_sum_rur", ConvertFloatToStrPoint(m_api, q_calc->FieldByName("AllPremiumRUR")->AsFloat));
      SetAttribute(paymentdata, "payment_type_id", IntToStr(q_calc->FieldByName("CBPayment")->AsInteger));
      SetAttribute(paymentdata, "payment_document_type_id", IntToStr(q_calc->FieldByName("CBPaymentDoc")->AsInteger));
      SetAttribute(paymentdata, "payment_document_number", AnsiString(q_calc->FieldByName("EPPSer")->AsString + q_calc->FieldByName("eppnum")->AsString));
      SetAttribute(paymentdata, "currency", q_calc->FieldByName("CurrencyName")->AsString);
      m_api->dbCloseCursor(res,q_calc);
      q->Next();
      }
   m_api->dbCloseCursor(res,q);
   return is_dogovor;
}
//-----------------------------------------------------------------

void SetPublicVirtu(mops_api_027* m_api)
{
int res;
AnsiString date_text = m_api->Internal_Convert_Date_To_SQL(res, CDSendWS);

AnsiString sql_txt =
"update " + product + "_calc set virtu = true where iif(isnull(virtu),0,virtu)=0 and calc_id in "
"(select id from _mops_calcs_ where NoErrors=true) "
" and data_zayavl >= "+date_text.c_str();
m_api->dbExecuteQuery(res, sql_txt.c_str());

}
//-----------------------------------------------------------------

void SetAttributeAttrib(_di_IXMLNode &root, AnsiString &name, AnsiString &param)
{
  _di_IXMLNode attib;
  attib = root->AddChild("attribute");
  attib->SetAttribute("name",name);
  attib->SetAttribute("value",param);
}


void SetAttribute(_di_IXMLNode &root, AnsiString &name, AnsiString &param)
{
  root->SetAttribute(name,param);
}
//-----------------------------------------------------------------
_di_IXMLNode AddChildValue(_di_IXMLNode &root, AnsiString &name, AnsiString &value)
{
_di_IXMLNode node1 = root->AddChild(name);
if( !(value.IsEmpty()) && (value != "")) node1->SetText(value);
return node1;
}
//-----------------------------------------------------------------

static size_t Writer(char *data, size_t size, size_t nmemb, AnsiString *buffer)
{
  size_t result = 0;
  if(buffer != NULL)
    {
     buffer->Insert(data,buffer->Length()+1);
     //��������� ���������� buffer
     result = size * nmemb;
     // ��������� �������� ���������� ���������� ���� ������
    }
  return result;
}
//-----------------------------------------------------------------


void GetProxy(AnsiString &host, AnsiString &port, AnsiString &host_port)
{
wchar_t buffer[1024];
INTERNET_PROXY_INFO * info = reinterpret_cast<INTERNET_PROXY_INFO *>(buffer);
DWORD dwSize = sizeof(buffer);
InternetQueryOption(NULL, INTERNET_OPTION_PROXY, info, &dwSize);

host_port = info->lpszProxy;
host = "";
port = "80";
AnsiString address = info->lpszProxyBypass;
int pos = host_port.Pos(":");
if(pos > 0)
   {
   host = host_port.SubString(0, pos - 1);
   port = host_port.SubString(pos+1, host_port.Length() - pos);
   }
}

//---------------------------------------------------------------------------

AnsiString GetParam(mops_api_027* m_api, AnsiString &product_name, int param)
{
int res = 0;
AnsiString ret = "";
AnsiString prod_name_all = "���";
int count = 0;
if(product_name != "") count += 1;

while (count >= 0)
   {
   AnsiString temp_sql = AnsiString("select * from gl_dict_virtu_ws where product_name = '") + prod_name_all + "' and type_param =" + param;
   TADOQuery *q = m_api->dbGetCursor(res, temp_sql);
   if(q->RecordCount > 0)
      {
      ret = q->FieldByName("value_param")->AsString;
      }
   m_api->dbCloseCursor(res, q);
   if(count == 1) { prod_name_all = product_name; count -= 1; continue;}
   else count -= 1;
   }
return ret;
}


AnsiString ConvertFloatToStrPoint(mops_api_027* m_api, double value)
{
  return StringReplace(FloatToStr( m_api->Round(value)),",",".",TReplaceFlags()<<rfReplaceAll<<rfIgnoreCase);
}

#pragma package(smart_init)






