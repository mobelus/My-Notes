//---------------------------------------------------------------------------

#ifndef PolisForm3x2H
#define PolisForm3x2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <QRCtrls.hpp>
#include <QuickRpt.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TFormPolis3x2 : public TForm
{
__published:	// IDE-managed Components
  TQuickRep *QuickRep1;
  TQRBand *QRBand1;
  TQRImage *QRImage1;
  TQRLabel *QRLabel1;
  TQRLabel *QRLabel2;
  TQRLabel *QRLabel3;
  TQRLabel *QRLabel4;
  TQRLabel *QRLabel5;
  TQRLabel *QRLabel6;
  TQRLabel *QRLabel7;
  TQRLabel *QRLabel8;
  TQRLabel *QRLabel9;
  TQRLabel *QRLabel10;
  TQRLabel *QRLabel11;
  TQRLabel *QRLabel12;
  TQRLabel *QRLabel13;
  TQRLabel *QRLabel14;
  TQRLabel *QRLabel15;
  TQRLabel *QRLabel16;
private:	// User declarations
public:		// User declarations
  __fastcall TFormPolis3x2(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormPolis3x2 *FormPolis3x2;
//---------------------------------------------------------------------------
#endif

