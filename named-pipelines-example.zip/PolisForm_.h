//---------------------------------------------------------------------------

#ifndef PolisForm_H
#define PolisForm_H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include <QRCtrls.hpp>
#include <QuickRpt.hpp>
#include "Tmops_api.h"
#include "Constants.h"

#include "Graphics.hpp"
//---------------------------------------------------------------------------
class TPolisForm : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *qrPolis;
        TQRBand *TitleBand1;
        TQRImage *qrimgHead;
        TQRImage *qrimgTable;
        TQRLabel *qrlbHolder;
        TQRLabel *qrlbBirthday;
        TQRLabel *qrlbTel;
        TQRLabel *qrlbAddress;
        TQRLabel *qrlbStartDate;
        TQRLabel *qrlbEndDate;
        TQRLabel *qrlbDays;
        TQRLabel *qrlbPersonBirthday;
        TQRLabel *qrlbPerson;
        TQRLabel *qrlbTerritory;
        TQRLabel *qrlbCode;
        TQRLabel *qrlbMainSumm;
        TQRLabel *qrlbMainFranchise;
        TQRLabel *qrlbMainPremium;
        TQRLabel *qrlbLossBagSumm;
        TQRLabel *qrlbLossBagFranchise;
        TQRLabel *qrlbLossBagPremium;
        TQRLabel *qrlbCancelTripPremium;
        TQRLabel *qrlbCivilLiabilityPremium;
        TQRLabel *qrlbAccidentPremium;
        TQRLabel *qrlbAccidentFranchise;
        TQRLabel *qrlbCivilLiabilityFranchise;
        TQRLabel *qrlbCancelTripFranchise;
        TQRLabel *qrlbCancelTripSumm;
        TQRLabel *qrlbCivilLiabilitySumm;
        TQRLabel *qrlbAccidentSumm;
        TQRLabel *cbActive;
        TQRLabel *cbSport;
        TQRLabel *cbAge;
        TQRLabel *cbProf;
        TQRLabel *cbOther;
        TQRLabel *qrlbTotalPremium;
        TQRLabel *qrlbPlace;
        TQRLabel *qrlbIssueDate;
        TQRLabel *qrlbDovNum;
        TQRLabel *qrlbDovDateDD;
        TQRLabel *qrlbDovDateMMMM;
        TQRLabel *qrlbDovDateYYYY;
        TQRLabel *qrlbDogNum;
        TQRLabel *qrlbDogDateDD;
        TQRLabel *qrlbDogDateMMMM;
        TQRLabel *qrlbDogDateYYYY;
        TQRImage *qrimgBottom;
        TQRLabel *qrlbPersonFIO;
        TQRLabel *qrlbPersonDate;
        TQRLabel *qrlbPhysicalDate;
        TQRLabel *qrlbJuridicalDate;
        TQRLabel *qrlbJuridicalFIO;
        TQRLabel *qrlbPhysicalFIO;
        TQRLabel *qrlLossBagCode;
        TQRLabel *QRLabel2;
        TQRLabel *qrlCancelTripCode;
        TQRLabel *QRLabel4;
        TQRLabel *qrlCivilLiabilityCode;
        TQRLabel *QRLabel6;
        TQRLabel *qrlAccidentCode;
        TQRLabel *QRLabel8;
        TQRLabel *qrlMainRules;
        TQRLabel *qrlLossBagRules;
        TQRLabel *qrlCancelTripRules;
        TQRLabel *qrlCivilLiabilityRules;
        TQRLabel *qrlAccidentRules;
private:
public:
        mops_api_007* m_api;

        __fastcall TPolisForm(TComponent* Owner);

        void __fastcall  PrintPolis(long calc_id,bool preview, bool blank);
};
//---------------------------------------------------------------------------
extern PACKAGE TPolisForm *PolisForm;
//---------------------------------------------------------------------------
#endif
