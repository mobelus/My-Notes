﻿int
       polis_sernum = 0,  
       count_zastr = 0;
double                       
       tmp_prem_polis = 0;
         
double calc_prem()
{
       int pos = Pos("=", <UserData."str_prem">);
       int len = Length(<UserData."str_prem">);                               
       double prem = StrToFloat(Copy(<UserData."str_prem">, pos + 1, len - pos));                            
       prem = prem * <UserData."k_sg">;                                        
       Set("calc_rez_prem", prem);
         
       return prem;                            
}      
   
void Memo43OnBeforePrint(TfrxComponent Sender)
{
  double prem = 0;             
       if(polis_sernum != <UserData."calc_id">)
       {
        polis_sernum = <UserData."calc_id">;
        count_zastr = <UserData."count_zastr">;
        tmp_prem_polis = 0;            
       }
       else
        count_zastr--;
       prem = calc_prem() * <UserData."kurs_valuta">;               
       if(count_zastr>1)   
        tmp_prem_polis = tmp_prem_polis + prem;
       else 
        prem = <UserData."obsh_prem_rur"> - tmp_prem_polis;
       Set("calc_rez_val", prem);
}
                         
void Memo44OnBeforePrint(TfrxComponent Sender)
{
       calc_prem();               
}

{

}
