//---------------------------------------------------------------------------

#ifndef UPrintSrokDogovorH
#define UPrintSrokDogovorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sCustomComboEdit.hpp"
#include "sLabel.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "sButton.hpp"
#include "UShowHTML.h"
#include "TMops_api.h"
#include "cxCalendar.hpp"
//---------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:	// IDE-managed Components
  TsDateEdit *sDESrokStrS;
  TsDateEdit *sDESrokStrPO;
  TsDateEdit *sDESrokDS;
  TsDateEdit *sDESrokDPO;
  TsLabel *sLabel1;
  TsLabel *sLabel2;
  TsBitBtn *sBitBtn1;
  TsBitBtn *sBitBtn2;
  TsButton *sButton1;
  void __fastcall sBitBtn1Click(TObject *Sender);
  void __fastcall sBitBtn2Click(TObject *Sender);
  void __fastcall sDESrokDSKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall sDESrokDPOKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
  void __fastcall sButton1Click(TObject *Sender);
private:	// User declarations
  mops_api_023 *m_api;
  int m_res;
  int m_id;
  bool __fastcall CheckData();
  TDateTime mtdLimit;
  int mnAddDay;
public:		// User declarations
  __fastcall TForm3(TComponent* Owner);
  __fastcall TForm3(TComponent* Owner, mops_api_023 *api);
  void __fastcall PrepareField(int id);
  int __fastcall CalcData();

};
//---------------------------------------------------------------------------
extern PACKAGE TForm3 *Form3;
//---------------------------------------------------------------------------
#endif

