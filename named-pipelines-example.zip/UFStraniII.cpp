//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UFStraniII.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPageControl"
#pragma link "sTabControl"
#pragma link "sAlphaListBox"
#pragma link "sButton"
#pragma link "sCheckListBox"
#pragma resource "*.dfm"
TFSraniII *FSraniII;
//---------------------------------------------------------------------------
__fastcall TFSraniII::TFSraniII(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
  __fastcall TFSraniII::TFSraniII(TComponent* Owner, mops_api_023 *api)
  : TForm(Owner)
{

}

  void __fastcall  TFSraniII::Init()
{

}

