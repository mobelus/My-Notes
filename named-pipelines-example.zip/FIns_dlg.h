//---------------------------------------------------------------------------

#ifndef FIns_dlgH
#define FIns_dlgH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Tmops_api.h"
#include "sEdit.hpp"
//---------------------------------------------------------------------------
class TFIns : public TForm{
__published:	// IDE-managed Components
   TEdit *Edit_F;
   TEdit *Edit_I;
   TEdit *Edit_O;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TButton *Button1;
   TButton *Button2;
  TsEdit *sESer;
  TsEdit *sENum;
   void __fastcall Edit_FChange(TObject *Sender);
private:	// User declarations
   int terr_id;
   mops_api_023* m_api;
   //std::set<int> keys;
public:		// User declarations
  __fastcall TFIns(TComponent* Owner, const int t, mops_api_023* m);
};
//---------------------------------------------------------------------------
extern PACKAGE TFIns *FIns;
//---------------------------------------------------------------------------
#endif

