#ifndef BSO_H_
#define BSO_H_

class BSO{
public:
        static bool flagD;
        static int flagD1, flagD2, flagD3;
};

bool BSO::flagD=false;
int BSO::flagD1=0;
int BSO::flagD2=0;
int BSO::flagD3=0;

#endif BSO_H_