//---------------------------------------------------------------------------

#ifndef UAnketa_Otkaz_PrintH
#define UAnketa_Otkaz_PrintH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Tmops_api.h"
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sAlphaListBox.hpp"
#include "sCheckListBox.hpp"
#include "sLabel.hpp"
#include "sCheckBox.hpp"
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "CGAUGES.h"
#include "sGauge.hpp"
#include "sGroupBox.hpp"
#include "frxClass.hpp"
#include "frxDBSet.hpp"
//---------------------------------------------------------------------------
typedef enum emun_freport
{
  E_WORD,
  E_FAST_REPORT
}TEREPORT;

class TFAnketa_Otkaz_Print : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel1;
        TsPanel *sPanel2;
        TsCheckListBox *sCheckListBox1;
        TsLabel *sLabel1;
        TsBitBtn *sBitBtn1;
        TsDateEdit *sDateEdit1;
        TsDateEdit *sDateEdit2;
        TsLabel *sLabel2;
        TsLabel *sLabel3;
        TsGauge *sGauge1;
        TsRadioGroup *sRadioGroup1;
        TsBitBtn *sBitBtn2;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
private:	// User declarations
  long id_calc;
  TEREPORT m_freport;
  AnsiString m_qfr;

  void  __fastcall fnFastReport();
public:		// User declarations
        __fastcall TFAnketa_Otkaz_Print(TComponent* Owner);
        __fastcall TFAnketa_Otkaz_Print(TComponent* Owner, TEREPORT rep);
       mops_api_007* m_api;
  void  __fastcall PrepareFields(long id_calc,bool PreViewFlag);
  AnsiString  __fastcall GetQuery2FastReport();
};
//---------------------------------------------------------------------------
extern PACKAGE TFAnketa_Otkaz_Print *FAnketa_Otkaz_Print;
//---------------------------------------------------------------------------
#endif
