//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PolisForm_.h"
#include "windows.h"
#include "wingdi.h"
#include "jpeg.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPolisForm *PolisForm;
//---------------------------------------------------------------------------
__fastcall TPolisForm::TPolisForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall  TPolisForm::PrintPolis(long calc_id, bool preview, bool blank)
{
        qrimgHead->Enabled   = !blank;
        qrimgBottom->Enabled = !blank;

        AnsiString Currency="";
        int res;
        TADOQuery *qw = m_api->dbGetCursor(res, "select c.* "
                                                "  from vzr174Pr_calc c"
                                           " where calc_id=" + IntToStr(calc_id));
        AnsiString stmp;

        if(qw->RecordCount<=0)
        {
                return;
        }

        if(!blank)
        {
         //�������� ����� "�������"
         TJPEGImage *jpg=new TJPEGImage();
         jpg->Assign(qrimgTable->Picture);
         Graphics::TBitmap *btmp2=new Graphics::TBitmap();
         Graphics::TBitmap *btmp=new Graphics::TBitmap();
         btmp->Assign(jpg);
         btmp2->Assign(jpg);
         btmp->PixelFormat=pf32bit;
         btmp2->PixelFormat=pf32bit;
         SetBkMode(btmp2->Canvas->Handle, TRANSPARENT);
         HFONT font = CreateFont(-400,          // ������ ������
                   200,          // ������ ����������
                   300,            //���� ��������
                   0,            //���� �����������
                   FW_BOLD,     //������ ������
                   TRUE,        // ������
                   FALSE,        // �������������
                   FALSE,               // ��������������
                   DEFAULT_CHARSET ,
                   OUT_TT_PRECIS,       // �������� ������
                   CLIP_DEFAULT_PRECIS,   //�������� ���������
                   ANTIALIASED_QUALITY, // �������� ������
                   FF_DONTCARE|DEFAULT_PITCH, // ��������� � ���
                   "Times New Roman");          // ��� ������
         btmp2->Canvas->Font->Handle=font;
         btmp2->Canvas->Font->Color=(TColor)RGB(255,0,0);
         btmp2->Canvas->TextOut(200,btmp->Height-400,"�������");
         TBlendFunction Blend;
         Blend.BlendOp=AC_SRC_OVER;
         Blend.BlendFlags = 0;
         Blend.SourceConstantAlpha = 128; // ������������ 50% (0 - 255)
         Blend.AlphaFormat =0;//AC_SRC_ALPHA; // ���� = 0 (������ ��������)
         ::AlphaBlend(btmp->Canvas->Handle, 0, 0, btmp->Width, btmp->Height,btmp2->Canvas->Handle, 0, 0, btmp->Width, btmp->Height, Blend);
         jpg->Assign(btmp);
         qrimgTable->Picture->Assign(jpg);
        delete jpg;
        delete btmp;
        delete btmp2;
        }


        Currency=qw->FieldByName("CurrencyName")->AsString;

        if (qw->FieldByName("strach_fiz_yur")->AsString=="���������� ����")
        {
                qrlbHolder       ->Caption = qw->FieldByName("strach_fio")->AsString;
                qrlbBirthday     ->Caption = qw->FieldByName("strach_dr")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("strach_dr")->AsString;
                qrlbAddress      ->Caption = qw->FieldByName("strach_address")->AsString;
                qrlbTel          ->Caption = qw->FieldByName("strach_tel")->AsString;
                qrlbPhysicalFIO  ->Caption = qw->FieldByName("strach_fio")->AsString;
                qrlbPhysicalDate ->Caption = qw->FieldByName("data_zayavl")->AsString;
        }
        else
        {
                qrlbHolder        ->Caption = qw->FieldByName("strach_yur_naimen")->AsString;
                qrlbAddress       ->Caption = qw->FieldByName("strach_yur_address")->AsString;
                qrlbTel           ->Caption = qw->FieldByName("strach_yur_tel")->AsString;
                qrlbJuridicalFIO  ->Caption = qw->FieldByName("strach_yur_contact")->AsString;
                qrlbJuridicalDate ->Caption = qw->FieldByName("data_zayavl")->AsString;
        }

        qrlbStartDate      ->Caption = qw->FieldByName("str_polis_start_data")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("str_polis_start_data")->AsString;
        qrlbEndDate        ->Caption = qw->FieldByName("str_polis_end_data")->AsString;
        qrlbDays           ->Caption = qw->FieldByName("MainDays")->AsString;
        qrlbPerson         ->Caption = qw->FieldByName("InsuredPersonFIO")->AsString;
        qrlbPersonBirthday ->Caption = qw->FieldByName("InsuredPersonBirthday")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("InsuredPersonBirthday")->AsString;
        qrlbCode           ->Caption = qw->FieldByName("program")->AsString;

        AnsiString  sterr;
        sterr = qw->FieldByName("MainTerritory")->AsString;
        if(!qw->FieldByName("MainTerritory")->AsString.IsEmpty() && !qw->FieldByName("CountryReport")->AsString.IsEmpty())
          sterr += ",";
        sterr += qw->FieldByName("CountryReport")->AsString;

        qrlbTerritory->Caption = sterr;

        qrlbMainSumm    ->Caption =  qw->FieldByName("MainSumm")->AsString + " " +Currency ;
        if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
          qrlbMainPremium ->Caption = qw->FieldByName("MainPremium")->AsString + " " + Currency;
        qrlMainRules->Caption=qw->FieldByName("MainRules")->AsString;

        if (qw->FieldByName("MainFranchiseValue")->AsFloat>0)
                qrlbMainFranchise->Caption = FloatToStr(qw->FieldByName("MainFranchiseValue")->AsFloat) + " " + Currency;
        



        int lFlags = qw->FieldByName("RisksFlags")->AsInteger;

        if ((lFlags & VZRCALC_RISKSFLAG_LOSSBAG)>0)
        {
                this->qrlLossBagCode->Caption=qw->FieldByName("LossBagTransportTypeName")->AsString.SubString(1,1);
                qrlbLossBagSumm ->Caption=qw->FieldByName("LossBagSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbLossBagPremium ->Caption = qw->FieldByName("LossBagPremium")->AsString + " " + Currency;
                qrlLossBagRules->Caption=qw->FieldByName("LossBagRules")->AsString;
                qrlbLossBagFranchise->Caption=Trim(qw->FieldByName("LossBagTimeFranchiseName")->AsString);
                if (  qw->FieldByName("LossBagFranchiseValue")->AsFloat>0)
                        qrlbLossBagFranchise->Caption =qrlbLossBagFranchise->Caption+ "; "+ FloatToStr(m_api->Round(qw->FieldByName("LossBagFranchiseValue")->AsFloat *qw->FieldByName("LossBagSummValue")->AsFloat/100)) + " " + Currency;


        }
        if ((lFlags & VZRCALC_RISKSFLAG_CANCELTRIP)>0)
        {
                qrlCancelTripRules->Caption=qw->FieldByName("CancelTripRules")->AsString;
                this->qrlCancelTripCode->Caption=qw->FieldByName("CancelTripTypeName")->AsString.SubString(1,1);
                qrlbCancelTripSumm    ->Caption = qw->FieldByName("CancelTripSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbCancelTripPremium ->Caption = qw->FieldByName("CancelTripPremium")->AsString + " " + Currency;
                if (qw->FieldByName("CancelTripFranchiseValue")->AsFloat>0)
                        qrlbCancelTripFranchise->Caption = FloatToStr(m_api->Round(qw->FieldByName("CancelTripFranchiseValue")->AsFloat *qw->FieldByName("CancelTripSummValue")->AsFloat /100)) + " " + Currency;

        }
       if ((lFlags & VZRCALC_RISKSFLAG_CIVILLIABILITY)>0)
        {

                qrlCivilLiabilityRules->Caption=qw->FieldByName("CivilLiabilityRules")->AsString;
                this->qrlCivilLiabilityCode->Caption="F";//qw->FieldByName("")->AsString.SubString(1,1);
                qrlbCivilLiabilitySumm ->Caption =qw->FieldByName("CivilLiabilitySummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbCivilLiabilityPremium ->Caption = qw->FieldByName("CivilLiabilityPremium")->AsString + " " + Currency;
                if (qw->FieldByName("CivilLiabilityFranchiseValue")->AsFloat>0)
                        qrlbCivilLiabilityFranchise->Caption =FloatToStr(m_api->Round(qw->FieldByName("CivilLiabilitySummValue")->AsFloat*qw->FieldByName("CivilLiabilityFranchiseValue")->AsFloat/100)) + " "+ Currency;
        }
        if ((lFlags & VZRCALC_RISKSFLAG_ACCIDENT)>0)
        {
                qrlAccidentRules->Caption=qw->FieldByName("AccidentRules")->AsString;
                this->qrlAccidentCode->Caption=qw->FieldByName("AccidentTypeName")->AsString.SubString(1,10);
                qrlbAccidentSumm    ->Caption =qw->FieldByName("AccidentSummValue")->AsString + " " + Currency;
                if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
                  qrlbAccidentPremium ->Caption = qw->FieldByName("AccidentPremium")->AsString + " " + Currency;
                if (qw->FieldByName("AccidentFranchiseValue")->AsFloat>0)
                        qrlbAccidentFranchise->Caption =FloatToStr(m_api->Round(qw->FieldByName("AccidentSummValue")->AsFloat* qw->FieldByName("AccidentFranchiseValue")->AsFloat/100))+ " " + Currency ;
        }



        if(qw->FieldByName("MainKoefFreeValue")->AsFloat!=1)
        cbOther->Caption = "v";

       if (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==2 ||
            (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==1))
                cbSport->Caption = "v";


//        if (qw->FieldByName("MainKoefSportName")->AsString!="���"  && qw->FieldByName("MainKoefSportType")->AsInteger==1)
//                cbActive->Caption = "v";

        if (qw->FieldByName("MainKoefProfName")->AsString!="���")
                cbProf->Caption = "v";

        if (m_api->dbGetLongFromQuery(res, stmp.sprintf("select count(*) from VZR174Pr_Insured where id_calc = %i and k_age <> 1", calc_id)))
                cbAge->Caption = "v";

        qrlbPlace     ->Caption = qw->FieldByName("mesto_vidachi")->AsString;
        qrlbIssueDate ->Caption = qw->FieldByName("data_zayavl")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("data_zayavl")->AsString;


        if(!qw->FieldByName("disabled_prem_in_polis")->AsBoolean)
          qrlbTotalPremium->Caption = Format("%s %s = %s ������", ARRAYOFCONST((qw->FieldByName("AllPremium")->AsString,
                                                                               qw->FieldByName("CurrencyName")->AsString,
                                                                               qw->FieldByName("AllPremiumRUR")->AsString)));

        qrlbDovNum ->Caption = qw->FieldByName("predst_dov_num")->AsString;
        if(qw->FieldByName("predst_dov_data")->AsDateTime!=(TDateTime)NULL)
        {
                qrlbDovDateDD   ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("dd");
                qrlbDovDateMMMM ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("mmmm");
                qrlbDovDateYYYY ->Caption = qw->FieldByName("predst_dov_data")->AsDateTime.FormatString("yyyy");
        }

        qrlbDogNum->Caption=qw->FieldByName("predst_dog_num")->AsString;
        if(qw->FieldByName("predst_dog_data")->AsDateTime!=(TDateTime)NULL)
        {
                qrlbDogDateDD->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("dd");
                qrlbDogDateMMMM->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("mmmm");
                qrlbDogDateYYYY->Caption=qw->FieldByName("predst_dog_data")->AsDateTime.FormatString("yyyy");
        }

        qrlbPersonFIO  ->Caption = qw->FieldByName("InsuredPersonFIO")->AsString;
        qrlbPersonDate ->Caption = qw->FieldByName("data_zayavl")->AsString=="31.12.1899"?AnsiString(""):qw->FieldByName("data_zayavl")->AsString;

        if (preview)
        {
                qrPolis->Preview();
        }
        else
        {
                qrPolis->Print();
        }
}
//---------------------------------------------------------------------------


