//---------------------------------------------------------------------------

#ifndef USprTerrH
#define USprTerrH

#include "sBitBtn.hpp"
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sListView.hpp"
#include "sPanel.hpp"
#include <Buttons.hpp>
#include <CheckLst.hpp>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <StdCtrls.hpp>

//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include <ExtCtrls.hpp>
#include "sListView.hpp"
#include <ComCtrls.hpp>
#include "sBitBtn.hpp"
#include <Buttons.hpp>
#include "Tmops_api.h"
#include "sCustomComboEdit.hpp"
#include "sEdit.hpp"
#include "sLabel.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include <CheckLst.hpp>
#include "sButton.hpp"
#include "sFrameAdapter.hpp"
#include "sSkinProvider.hpp"
#include "sAlphaListBox.hpp"
#include "sCheckListBox.hpp"




//---------------------------------------------------------------------------
class TFSprTerr : public TForm
{
__published:	// IDE-managed Components
        TsPanel *sPanel2;
        TsPanel *sPanel1;
        TsPanel *sPanel3;
        TsBitBtn *sBitBtn1;
        TsPanel *sPanel4;
        TsBitBtn *sBitBtn2;
        TsListView *LV;
        TsLabel *sLabel1;
        TsEdit *TerrName;
        TsBitBtn *sBitBtn3;
        TsBitBtn *sBitBtn4;
        TsBitBtn *sBitBtn5;
        TLabel *Label1;
        TCheckListBox *strani;
        TCheckBox *CheckBox1;
        TsBitBtn *BBLoad;
        TsBitBtn *BBUnload;
        TCheckBox *CBSelectCountry;
        TCheckBox *CBDisableFR;
        TButton *Button1;
  TsLabel *sLabel2;
  TsEdit *TerrNameRus;
  TsButton *sBRus_Lat;
  TsLabel *sLabel3;
  TCheckListBox *terr;
        void __fastcall sBitBtn1Click(TObject *Sender);
        void __fastcall sBitBtn2Click(TObject *Sender);
        void __fastcall sBitBtn3Click(TObject *Sender);
        void __fastcall sBitBtn4Click(TObject *Sender);
        void __fastcall sBitBtn5Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall straniDrawItem(TWinControl *Control, int Index,
          TRect &Rect, TOwnerDrawState State);
        void __fastcall BBUnloadClick(TObject *Sender);
        void __fastcall BBLoadClick(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
  void __fastcall LVSelectItem(TObject *Sender, TListItem *Item,
          bool Selected);
  void __fastcall sBRus_LatClick(TObject *Sender);
  void __fastcall terrDrawItem(TWinControl *Control, int Index,
          TRect &Rect, TOwnerDrawState State);
  void __fastcall terrClickCheck(TObject *Sender);
  void __fastcall straniClickCheck(TObject *Sender);
private:	// User declarations
  void InitXMLDoc(_di_IXMLDocument XMLDoc);
  void __fastcall ShowStatusFields(bool);
  int m_Res;
  bool fstatus;
public:		// User declarations
        __fastcall TFSprTerr(TComponent* Owner);
        mops_api_010* m_api;
        void __fastcall PrepareFields();
        int insert_update; //-1  - ������, 0 - update, 1- insert
AnsiString __fastcall SwitchRusLat(AnsiString in, bool flag)  ;
  void __fastcall MakeTerrName();
};
//---------------------------------------------------------------------------
extern PACKAGE TFSprTerr *FSprTerr;
//---------------------------------------------------------------------------
#endif
