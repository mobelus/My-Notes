//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("dclFlexCompressb5.res");
USEUNIT("FXCReg.pas");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vclFlexCompressb5.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
