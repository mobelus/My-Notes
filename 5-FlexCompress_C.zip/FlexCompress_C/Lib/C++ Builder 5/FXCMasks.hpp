// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FXCMasks.pas' rev: 5.00

#ifndef FXCMasksHPP
#define FXCMasksHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fxcmasks
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TMask;
class PASCALIMPLEMENTATION TMask : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	void *FMask;
	int FSize;
	
public:
	__fastcall TMask(const AnsiString MaskValue);
	__fastcall virtual ~TMask(void);
	bool __fastcall Matches(const AnsiString Filename);
};


//-- var, const, procedure ---------------------------------------------------
#define SInvalidMask "'%s' is an invalid mask at (%d)"
extern PACKAGE bool __fastcall MatchesMask(const AnsiString Filename, const AnsiString Mask);

}	/* namespace Fxcmasks */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Fxcmasks;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// FXCMasks
