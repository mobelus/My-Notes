// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DesignConst.pas' rev: 6.00

#ifndef DesignConstHPP
#define DesignConstHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Designconst
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::ResourceString _srNone;
#define Designconst_srNone System::LoadResourceString(&Designconst::_srNone)
extern PACKAGE System::ResourceString _srLine;
#define Designconst_srLine System::LoadResourceString(&Designconst::_srLine)
extern PACKAGE System::ResourceString _srLines;
#define Designconst_srLines System::LoadResourceString(&Designconst::_srLines)
extern PACKAGE System::ResourceString _SInvalidFormat;
#define Designconst_SInvalidFormat System::LoadResourceString(&Designconst::_SInvalidFormat)
extern PACKAGE System::ResourceString _SUnableToFindComponent;
#define Designconst_SUnableToFindComponent System::LoadResourceString(&Designconst::_SUnableToFindComponent)
extern PACKAGE System::ResourceString _SCantFindProperty;
#define Designconst_SCantFindProperty System::LoadResourceString(&Designconst::_SCantFindProperty)
extern PACKAGE System::ResourceString _SStringsPropertyInvalid;
#define Designconst_SStringsPropertyInvalid System::LoadResourceString(&Designconst::_SStringsPropertyInvalid)
extern PACKAGE System::ResourceString _SLoadPictureTitle;
#define Designconst_SLoadPictureTitle System::LoadResourceString(&Designconst::_SLoadPictureTitle)
extern PACKAGE System::ResourceString _SSavePictureTitle;
#define Designconst_SSavePictureTitle System::LoadResourceString(&Designconst::_SSavePictureTitle)
extern PACKAGE System::ResourceString _SAboutVerb;
#define Designconst_SAboutVerb System::LoadResourceString(&Designconst::_SAboutVerb)
extern PACKAGE System::ResourceString _SNoPropertyPageAvailable;
#define Designconst_SNoPropertyPageAvailable System::LoadResourceString(&Designconst::_SNoPropertyPageAvailable)
extern PACKAGE System::ResourceString _SNoAboutBoxAvailable;
#define Designconst_SNoAboutBoxAvailable System::LoadResourceString(&Designconst::_SNoAboutBoxAvailable)
extern PACKAGE System::ResourceString _SNull;
#define Designconst_SNull System::LoadResourceString(&Designconst::_SNull)
extern PACKAGE System::ResourceString _SUnassigned;
#define Designconst_SUnassigned System::LoadResourceString(&Designconst::_SUnassigned)
extern PACKAGE System::ResourceString _SUnknown;
#define Designconst_SUnknown System::LoadResourceString(&Designconst::_SUnknown)
extern PACKAGE System::ResourceString _SString;
#define Designconst_SString System::LoadResourceString(&Designconst::_SString)
extern PACKAGE System::ResourceString _SUnknownType;
#define Designconst_SUnknownType System::LoadResourceString(&Designconst::_SUnknownType)
extern PACKAGE System::ResourceString _SCannotCreateName;
#define Designconst_SCannotCreateName System::LoadResourceString(&Designconst::_SCannotCreateName)
extern PACKAGE System::ResourceString _SColEditCaption;
#define Designconst_SColEditCaption System::LoadResourceString(&Designconst::_SColEditCaption)
extern PACKAGE System::ResourceString _SCantDeleteAncestor;
#define Designconst_SCantDeleteAncestor System::LoadResourceString(&Designconst::_SCantDeleteAncestor)
extern PACKAGE System::ResourceString _SCantAddToFrame;
#define Designconst_SCantAddToFrame System::LoadResourceString(&Designconst::_SCantAddToFrame)
extern PACKAGE System::ResourceString _SAllFiles;
#define Designconst_SAllFiles System::LoadResourceString(&Designconst::_SAllFiles)
#define SIniEditorsName "Property Editors"

}	/* namespace Designconst */
using namespace Designconst;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DesignConst
