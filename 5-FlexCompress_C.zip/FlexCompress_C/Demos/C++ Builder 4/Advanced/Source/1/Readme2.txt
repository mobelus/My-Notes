Demos Description
=================

 Demos folder contains some simple examples of 
 using Easy Compression Library.

Archiver
========
  This example demonstrates how to create compressed and 
 encrypted files and change their compression level and password.


CompressedDataStream
====================
  This application illustrates compressing and encrypting data in memory,
 transfering it, decrypting and decompressing the data on the other end.


CompressText
============
  This sample demonstrates how to compress/encrypt and decompress/decrypt
 a string and handle errors if compressed data is corrupted.


CustomHeader
============
  This demo shows how you can add your own not compressed header 
 to a compressed file.


Graphic
=======
  This program demonstrates how to get compressed Blob fields with Paradox table
 using ECL.


TextEdit
========
  This demo illustrates use of ECLFileStream for saving 
 compressed text to disk.
