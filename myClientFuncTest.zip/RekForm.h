//---------------------------------------------------------------------------

#ifndef RekFormH
#define RekFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "Tmops_api.h"
//---------------------------------------------------------------------------
class TReks : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TEdit *Poluch;
        TGroupBox *GroupBox2;
        TEdit *Address;
        TLabel *Label1;
        TLabel *Label2;
        TMemo *Reks;
        TGroupBox *GroupBox3;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *Podp1_dolzh;
        TEdit *Podp1_fio;
        TEdit *Podp2_dolzh;
        TEdit *Podp2_fio;
        TLabel *Label5;
        TLabel *Label6;
        TPanel *Panel1;
        TPanel *Panel2;
        TGroupBox *GroupBox4;
        TLabel *Label7;
        TLabel *Label8;
        TEdit *IspFIO;
        TEdit *IspPhone;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Panel1Click(TObject *Sender);
        void __fastcall Panel2Click(TObject *Sender);
private:	// User declarations
        mops_api_027 *m_api;
public:		// User declarations
        __fastcall TReks(TComponent* Owner,mops_api_027 *m_api);
};
//---------------------------------------------------------------------------
extern PACKAGE TReks *Reks;
//---------------------------------------------------------------------------
#endif
