//---------------------------------------------------------------------------


#pragma hdrstop

#include "excel_cc.h"

//---------------------------------------------------------------------------
void Excel::SetCheckBox(int shape_index, bool checked)
{
   try{
      Sh.OlePropertyGet("CheckBoxes", shape_index).OlePropertySet("Value", checked);
   }
   catch(...){}
}
//---------------------------------------------------------------------------
AnsiString Excel::Get_CheckBox_name(int index)
{
   AnsiString ret(""), st;

   try{
      ret = Sh.OlePropertyGet("CheckBoxes", index).OlePropertyGet("Name");
   }
   catch(...){}

   return ret;
}
//---------------------------------------------------------------------------
int Excel::CheckBoxes_Count()
{
   int ret(0);

   try{
      ret = Sh.OlePropertyGet("CheckBoxes").OlePropertyGet("Count");
   }
   catch(...){}

   return  ret;
}
//---------------------------------------------------------------------------
void Excel::Print()
{
   Sh.OleProcedure("PrintOut");
}
//---------------------------------------------------------------------------
int Excel::StolbecCharToInt(AnsiString st)
{
   int g(0), m;

   st = st.UpperCase();
   if(st.Length() == 1) m = (st.c_str())[0] - (char)'A' + 1;
   else{
      m = (st.c_str())[1] - (char)'A' + 1;
      g = (st.c_str())[0] - (char)'A' + 1;
   }

   return g * 26 + m;
}
//---------------------------------------------------------------------------
AnsiString Excel::GetActiverange()
{
   AnsiString Range;

   try{
      Range = Sh.OlePropertyGet("UsedRange").OlePropertyGet("Address");
   }
   catch(...){}

   return  Range;
}
//---------------------------------------------------------------------------
void Excel::toExcelCell(int Row, int Column, AnsiString data)
{
   try {
      Variant cur = Sh.OlePropertyGet("Cells", Row, Column);
      cur.OlePropertySet("Value", data.c_str());
   }
   catch(...) {}
}
//---------------------------------------------------------------------------
void Excel::toExcelCellV(int Row, int Column, Variant data)
{
   try {
      Variant cur = Sh.OlePropertyGet("Cells", Row, Column);
      cur.OlePropertySet("Value", data);
   }
   catch(...) {}
}
//---------------------------------------------------------------------------
void Excel::Format(int Row, int Column, const char* fmt)
{
   try {
      Variant cur = Sh.OlePropertyGet("Cells", Row, Column);
      cur.OlePropertySet("NumberFormat", fmt/*"��.��.����"*/);
   }
   catch(...) {}                                        //��:�� ��.��.����
}
//---------------------------------------------------------------------------
AnsiString Excel::fromExcelCell(int Row,int Column)
{
   AnsiString ret("");

   try{
      Variant cur  = Sh.OlePropertyGet("Cells", Row, Column);
      Variant cur2 = cur.OlePropertyGet("Value");
      cur2.VType;
      ret = cur2;
  }
  catch(...) {}

  return ret;
}
//---------------------------------------------------------------------------
Variant Excel::VariantFromExcelCell(int Row, int Column)
{
   Variant cur, cur2;

   try{
      cur  = Sh.OlePropertyGet("Cells", Row, Column);
      cur2 = cur.OlePropertyGet("Value");
   }
   catch(...) {  }

   return cur2;
}
//---------------------------------------------------------------------------
void Excel::Visible(bool visible)
{
   if(!App.IsEmpty()) App.OlePropertySet("Visible", visible);
}
//---------------------------------------------------------------------------
void Excel::ExcelInit(AnsiString File)
{
   //Excel �� ������� - ��������� ���
   try{
      App = Variant::CreateObject("Excel.Application");
   }
   catch(...){
      Application->MessageBox("���������� ������� Microsoft Excel!"
      "�������� Excel �� ���������� �� ����������.", "������", MB_OK + MB_ICONERROR);
   }

   try{
      if(File != "") App.OlePropertyGet("WorkBooks").OleProcedure("Open", File.c_str());
      else           App.OlePropertyGet("WorkBooks").OleProcedure("add");
      Sh = App.OlePropertyGet("WorkSheets", 1);
   }
   catch(...){
      Application->MessageBox("������ �������� ����� Microsoft Excel!", "������", MB_OK + MB_ICONERROR);
   }
}
//---------------------------------------------------------------------------
void Excel::Free()
{
   Sh.Clear();
   if(App.OlePropertyGet("Visible") == 0){
      App.OlePropertySet("DisplayAlerts", false);
      App.OleProcedure("Quit");
      App.OlePropertySet("DisplayAlerts", true);
   }
   App.Clear();
}
//---------------------------------------------------------------------------
void Excel::SaveBook()
{
   try{
      CheckCompatibility(false);
      App.OlePropertyGet("ActiveWorkbook").OleProcedure("Save");
   }
   catch(...){}
}
//---------------------------------------------------------------------------
void Excel::InsertRow(int row_num)
{
   try{
      AnsiString st;
      Variant cur = Sh.OlePropertyGet("Rows", st.sprintf("%i:%i", row_num, row_num).c_str());
      cur.OleProcedure("Select");
      cur.OleProcedure("Insert");
   }
   catch(...){}
}
//---------------------------------------------------------------------------
void Excel::SaveBook(AnsiString File_Name)
{
   try{
      CheckCompatibility(false);
      AnsiString st;
      App.OlePropertyGet("ActiveWorkbook").OleProcedure("SaveAs", File_Name/*st.sprintf("Filename:=\"%s\", FileFormat:=xlNormal, Password:=\"\", WriteResPassword:=\"\", ReadOnlyRecommended:=False, CreateBackup:=False",File_Name)*/.c_str());
   }
   catch(...){}
}
//---------------------------------------------------------------------------
void Excel::SetRowOrientation(int row_num,int Orientation)
{
   try{
      AnsiString st;
      Variant cur = Sh.OlePropertyGet("Rows", st.sprintf("%i:%i", row_num, row_num).c_str());
      cur.OleProcedure("Select");
      cur.OlePropertySet("Orientation",st.sprintf("%i",Orientation).c_str());
   }
   catch(...){}
}
//---------------------------------------------------------------------------
void Excel::AutoFit()
{
   try{
      Sh.OlePropertyGet("Rows").OlePropertyGet("EntireRow").OleProcedure("AutoFit");
   }
   catch(...){}
}
//---------------------------------------------------------------------------
bool Excel::CheckCompatibility(int flag)//-1 ret , 0 or 1
{
   try{
      if(flag == -1)
        return App.OlePropertyGet("ActiveWorkbook").OlePropertyGet("CheckCompatibility");
      App.OlePropertyGet("ActiveWorkbook").OlePropertySet("CheckCompatibility", (bool)flag);
   }
   catch(...){}
}

bool Excel::DeletedRangeCollumns(AnsiString sRang)
{
   try{
//      Variant range = App.OlePropertyGet("Range", sRang.c_str());
//      range.OlePropertyGet("Select");
      App.OlePropertyGet("Columns", sRang.c_str()).
          OleProcedure("Select");
      App.OlePropertyGet("Selection").
          OleProcedure("Delete");
   }
   catch(...){}
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
