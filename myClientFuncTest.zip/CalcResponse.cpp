
// **************************************************************************************************************************************************** //
//                                                                                                                                                    
//                                                                  XML Data Binding                                                                  
//                                                                                                                                                    
//         Generated on: 12.10.2012 17:50:37                                                                                                          
//       Generated from: C:\Documents and Settings\AAKuznetsov.RGS77MSKC001\������� ����\xsd-wsdl - v8.0\�������������� ����� � ��\CalcResponse.xsd   
//                                                                                                                                                    
// **************************************************************************************************************************************************** //

#include <vcl.h>
#pragma hdrstop

#include "CalcResponse.h"


// Global Functions 

_di_IXMLCalcResponse __fastcall GetCalcResponse(_di_IXMLDocument Doc)
{
  return (_di_IXMLCalcResponse) Doc->GetDocBinding("CalcResponse", __classid(TXMLCalcResponse));
};

_di_IXMLCalcResponse __fastcall GetCalcResponse(TXMLDocument *Doc)
{
  _di_IXMLDocument DocIntf;
  Doc->GetInterface(DocIntf);
  return GetCalcResponse(DocIntf);
};

_di_IXMLCalcResponse __fastcall LoadCalcResponse(const WideString FileName)
{
  return (_di_IXMLCalcResponse) LoadXMLDocument(FileName)->GetDocBinding("CalcResponse", __classid(TXMLCalcResponse));
};

_di_IXMLCalcResponse __fastcall  NewCalcResponse()
{
  return (_di_IXMLCalcResponse) NewXMLDocument()->GetDocBinding("CalcResponse", __classid(TXMLCalcResponse));
};


// TXMLCalcResponse 

void __fastcall TXMLCalcResponse::AfterConstruction(void)
{
  RegisterChildNode(WideString("CalcResponseValue"), __classid(TXMLCalcResponseType));
  RegisterChildNode(WideString("ErrorList"), __classid(TXMLErrorListType));
  TXMLNode::AfterConstruction();
};

_di_IXMLCalcResponseType __fastcall TXMLCalcResponse::Get_CalcResponseValue()
{
  return (_di_IXMLCalcResponseType) TXMLNode::ChildNodes->Nodes[WideString("CalcResponseValue")];
};

_di_IXMLErrorListType __fastcall TXMLCalcResponse::Get_ErrorList()
{
  return (_di_IXMLErrorListType) TXMLNode::ChildNodes->Nodes[WideString("ErrorList")];
};

// TXMLCalcResponseType 

void __fastcall TXMLCalcResponseType::AfterConstruction(void)
{
  RegisterChildNode(WideString("PolicyCalc"), __classid(TXMLPolicyCalcType));
  RegisterChildNode(WideString("CalcKBMResponses"), __classid(TXMLCalcKBMResps));
  RegisterChildNode(WideString("TicketCarResponse"), __classid(TXMLTicketCarResps));
  TXMLNode::AfterConstruction();
};

WideString __fastcall TXMLCalcResponseType::Get_IdRequestCalc()
{
  return TXMLNode::ChildNodes->Nodes[WideString("IdRequestCalc")]->Text;
};

void __fastcall TXMLCalcResponseType::Set_IdRequestCalc(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("IdRequestCalc")]->NodeValue = Value;
};

_di_IXMLPolicyCalcType __fastcall TXMLCalcResponseType::Get_PolicyCalc()
{
  return (_di_IXMLPolicyCalcType) TXMLNode::ChildNodes->Nodes[WideString("PolicyCalc")];
};

_di_IXMLCalcKBMResps __fastcall TXMLCalcResponseType::Get_CalcKBMResponses()
{
  return (_di_IXMLCalcKBMResps) TXMLNode::ChildNodes->Nodes[WideString("CalcKBMResponses")];
};

_di_IXMLTicketCarResps __fastcall TXMLCalcResponseType::Get_TicketCarResponse()
{
  return (_di_IXMLTicketCarResps) TXMLNode::ChildNodes->Nodes[WideString("TicketCarResponse")];
};

// TXMLPolicyCalcType 

WideString __fastcall TXMLPolicyCalcType::Get_PolicySerialKey()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PolicySerialKey")]->Text;
};

void __fastcall TXMLPolicyCalcType::Set_PolicySerialKey(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PolicySerialKey")]->NodeValue = Value;
};

WideString __fastcall TXMLPolicyCalcType::Get_PolicyNumberKey()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PolicyNumberKey")]->Text;
};

void __fastcall TXMLPolicyCalcType::Set_PolicyNumberKey(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PolicyNumberKey")]->NodeValue = Value;
};

WideString __fastcall TXMLPolicyCalcType::Get_PolicyKBM()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PolicyKBM")]->Text;
};

void __fastcall TXMLPolicyCalcType::Set_PolicyKBM(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PolicyKBM")]->NodeValue = Value;
};

WideString __fastcall TXMLPolicyCalcType::Get_PolicyKBMValue()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PolicyKBMValue")]->Text;
};

void __fastcall TXMLPolicyCalcType::Set_PolicyKBMValue(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PolicyKBMValue")]->NodeValue = Value;
};

WideString __fastcall TXMLPolicyCalcType::Get_InsurerName()
{
  return TXMLNode::ChildNodes->Nodes[WideString("InsurerName")]->Text;
};

void __fastcall TXMLPolicyCalcType::Set_InsurerName(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("InsurerName")]->NodeValue = Value;
};

// TXMLCalcKBMResps 

void __fastcall TXMLCalcKBMResps::AfterConstruction(void)
{
  RegisterChildNode(WideString("ErrorInfo"), __classid(TXMLErrorInfoType));
  RegisterChildNode(WideString("CalcKBMResponse"), __classid(TXMLCalcKBMType));
  FCalcKBMResponse = (IXMLCalcKBMTypeList *) CreateCollection(__classid(TXMLCalcKBMTypeList), __uuidof(IXMLCalcKBMType), "CalcKBMResponse");
  TXMLNode::AfterConstruction();
};

_di_IXMLErrorInfoType __fastcall TXMLCalcKBMResps::Get_ErrorInfo()
{
  return (_di_IXMLErrorInfoType) TXMLNode::ChildNodes->Nodes[WideString("ErrorInfo")];
};

_di_IXMLCalcKBMTypeList __fastcall TXMLCalcKBMResps::Get_CalcKBMResponse()
{
  return (_di_IXMLCalcKBMTypeList) FCalcKBMResponse;
};

// TXMLErrorInfoType 

int __fastcall TXMLErrorInfoType::Get_Code()
{
  return TXMLNode::ChildNodes->Nodes[WideString("Code")]->NodeValue;
};

void __fastcall TXMLErrorInfoType::Set_Code(int Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("Code")]->NodeValue = Value;
};

WideString __fastcall TXMLErrorInfoType::Get_Message()
{
  return TXMLNode::ChildNodes->Nodes[WideString("Message")]->Text;
};

void __fastcall TXMLErrorInfoType::Set_Message(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("Message")]->NodeValue = Value;
};

// TXMLCalcKBMType 

void __fastcall TXMLCalcKBMType::AfterConstruction(void)
{
  RegisterChildNode(WideString("ErrorInfo"), __classid(TXMLErrorInfoType));
  RegisterChildNode(WideString("DriverDocument"), __classid(TXMLDriverDocumentType));
  RegisterChildNode(WideString("Losses"), __classid(TXMLLossesCRTType));
  TXMLNode::AfterConstruction();
};

_di_IXMLErrorInfoType __fastcall TXMLCalcKBMType::Get_ErrorInfo()
{
  return (_di_IXMLErrorInfoType) TXMLNode::ChildNodes->Nodes[WideString("ErrorInfo")];
};

_di_IXMLDriverDocumentType __fastcall TXMLCalcKBMType::Get_DriverDocument()
{
  return (_di_IXMLDriverDocumentType) TXMLNode::ChildNodes->Nodes[WideString("DriverDocument")];
};

WideString __fastcall TXMLCalcKBMType::Get_PersonNameBirthHash()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PersonNameBirthHash")]->Text;
};

void __fastcall TXMLCalcKBMType::Set_PersonNameBirthHash(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PersonNameBirthHash")]->NodeValue = Value;
};

WideString __fastcall TXMLCalcKBMType::Get_KBMFirstLevel()
{
  return TXMLNode::ChildNodes->Nodes[WideString("KBMFirstLevel")]->Text;
};

void __fastcall TXMLCalcKBMType::Set_KBMFirstLevel(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("KBMFirstLevel")]->NodeValue = Value;
};

WideString __fastcall TXMLCalcKBMType::Get_KBMNextLevel()
{
  return TXMLNode::ChildNodes->Nodes[WideString("KBMNextLevel")]->Text;
};

void __fastcall TXMLCalcKBMType::Set_KBMNextLevel(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("KBMNextLevel")]->NodeValue = Value;
};

WideString __fastcall TXMLCalcKBMType::Get_KBMValue()
{
  return TXMLNode::ChildNodes->Nodes[WideString("KBMValue")]->Text;
};

void __fastcall TXMLCalcKBMType::Set_KBMValue(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("KBMValue")]->NodeValue = Value;
};

_di_IXMLLossesCRTType __fastcall TXMLCalcKBMType::Get_Losses()
{
  return (_di_IXMLLossesCRTType) TXMLNode::ChildNodes->Nodes[WideString("Losses")];
};

int __fastcall TXMLCalcKBMType::Get_LossAmount()
{
  return TXMLNode::ChildNodes->Nodes[WideString("LossAmount")]->NodeValue;
};

void __fastcall TXMLCalcKBMType::Set_LossAmount(int Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("LossAmount")]->NodeValue = Value;
};

// TXMLCalcKBMTypeList 

_di_IXMLCalcKBMType __fastcall TXMLCalcKBMTypeList::Add()
{
  return (_di_IXMLCalcKBMType) AddItem(-1);
};

_di_IXMLCalcKBMType __fastcall TXMLCalcKBMTypeList::Insert(const int Index)
{
  return (_di_IXMLCalcKBMType) AddItem(Index);
};

_di_IXMLCalcKBMType __fastcall TXMLCalcKBMTypeList::Get_Item(int Index)
{
  return (_di_IXMLCalcKBMType) TXMLNodeCollection::List->Nodes[Index];
};

// TXMLDriverDocumentType 

WideString __fastcall TXMLDriverDocumentType::Get_Serial()
{
  return TXMLNode::ChildNodes->Nodes[WideString("Serial")]->Text;
};

void __fastcall TXMLDriverDocumentType::Set_Serial(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("Serial")]->NodeValue = Value;
};

WideString __fastcall TXMLDriverDocumentType::Get_Number()
{
  return TXMLNode::ChildNodes->Nodes[WideString("Number")]->Text;
};

void __fastcall TXMLDriverDocumentType::Set_Number(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("Number")]->NodeValue = Value;
};

// TXMLLossesCRTType 

void __fastcall TXMLLossesCRTType::AfterConstruction(void)
{
  RegisterChildNode(WideString("Loss"), __classid(TXMLLossCRTType));
  ItemTag = "Loss";
  ItemInterface = __uuidof(IXMLLossCRTType);
  TXMLNodeCollection::AfterConstruction();
};

_di_IXMLLossCRTType __fastcall TXMLLossesCRTType::Get_Loss(int Index)
{
  return (_di_IXMLLossCRTType) TXMLNodeCollection::List->Nodes[Index];
};

_di_IXMLLossCRTType __fastcall TXMLLossesCRTType::Add()
{
  return (_di_IXMLLossCRTType) AddItem(-1);
};

_di_IXMLLossCRTType __fastcall TXMLLossesCRTType::Insert(const int Index)
{
  return (_di_IXMLLossCRTType) AddItem(Index);
};


// TXMLLossCRTType 

WideString __fastcall TXMLLossCRTType::Get_LossDateTime()
{
  return TXMLNode::ChildNodes->Nodes[WideString("LossDateTime")]->Text;
};

void __fastcall TXMLLossCRTType::Set_LossDateTime(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("LossDateTime")]->NodeValue = Value;
};

WideString __fastcall TXMLLossCRTType::Get_PolicySerialKey()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PolicySerialKey")]->Text;
};

void __fastcall TXMLLossCRTType::Set_PolicySerialKey(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PolicySerialKey")]->NodeValue = Value;
};

WideString __fastcall TXMLLossCRTType::Get_PolicyNumberKey()
{
  return TXMLNode::ChildNodes->Nodes[WideString("PolicyNumberKey")]->Text;
};

void __fastcall TXMLLossCRTType::Set_PolicyNumberKey(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("PolicyNumberKey")]->NodeValue = Value;
};

WideString __fastcall TXMLLossCRTType::Get_InsurerName()
{
  return TXMLNode::ChildNodes->Nodes[WideString("InsurerName")]->Text;
};

void __fastcall TXMLLossCRTType::Set_InsurerName(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("InsurerName")]->NodeValue = Value;
};

// TXMLTicketCarResps 

void __fastcall TXMLTicketCarResps::AfterConstruction(void)
{
  RegisterChildNode(WideString("ErrorList"), __classid(TXMLErrorListType));
  TXMLNode::AfterConstruction();
};

bool __fastcall TXMLTicketCarResps::Get_TicketExisted()
{
  return TXMLNode::ChildNodes->Nodes[WideString("TicketExisted")]->NodeValue;
};

void __fastcall TXMLTicketCarResps::Set_TicketExisted(bool Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("TicketExisted")]->NodeValue = Value;
};

WideString __fastcall TXMLTicketCarResps::Get_DateNextTO()
{
  return TXMLNode::ChildNodes->Nodes[WideString("DateNextTO")]->Text;
};

void __fastcall TXMLTicketCarResps::Set_DateNextTO(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("DateNextTO")]->NodeValue = Value;
};

WideString __fastcall TXMLTicketCarResps::Get_TicketDiagnosticDate()
{
  return TXMLNode::ChildNodes->Nodes[WideString("TicketDiagnosticDate")]->Text;
};

void __fastcall TXMLTicketCarResps::Set_TicketDiagnosticDate(WideString Value)
{
  TXMLNode::ChildNodes->Nodes[WideString("TicketDiagnosticDate")]->NodeValue = Value;
};

_di_IXMLErrorListType __fastcall TXMLTicketCarResps::Get_ErrorList()
{
  return (_di_IXMLErrorListType) TXMLNode::ChildNodes->Nodes[WideString("ErrorList")];
};

// TXMLErrorListType 

void __fastcall TXMLErrorListType::AfterConstruction(void)
{
  RegisterChildNode(WideString("ErrorInfo"), __classid(TXMLErrorInfoType));
  ItemTag = "ErrorInfo";
  ItemInterface = __uuidof(IXMLErrorInfoType);
  TXMLNodeCollection::AfterConstruction();
};

_di_IXMLErrorInfoType __fastcall TXMLErrorListType::Get_ErrorInfo(int Index)
{
  return (_di_IXMLErrorInfoType) TXMLNodeCollection::List->Nodes[Index];
};

_di_IXMLErrorInfoType __fastcall TXMLErrorListType::Add()
{
  return (_di_IXMLErrorInfoType) AddItem(-1);
};

_di_IXMLErrorInfoType __fastcall TXMLErrorListType::Insert(const int Index)
{
  return (_di_IXMLErrorInfoType) AddItem(Index);
};

 