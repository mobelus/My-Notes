//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "form_edit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TFormEdit *FormEdit;
//---------------------------------------------------------------------------

__fastcall TFormEdit::TFormEdit(TComponent* Owner)
  : TForm(Owner)
{
//
}
//---------------------------------------------------------------------------

void __fastcall TFormEdit::CheckBox1Click(TObject *Sender)
{
    TCheckBox* box = (TCheckBox*)Sender;
    edittype += ((box->Checked ? 1 : -1)*box->Tag);   //���� ������������ � �������� int
}
//---------------------------------------------------------------------------

void __fastcall TFormEdit::Button1Click(TObject *Sender)
{
    ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TFormEdit::CheckBox15Click(TObject *Sender)
{
    if (CheckBox15->Checked && CheckBox1->Checked)
    {
        CheckBox1->Checked = false;
    }

    TCheckBox* box = (TCheckBox*)Sender;
    edittype += ((box->Checked ? 1 : -1)*box->Tag);
}
//---------------------------------------------------------------------------

void __fastcall TFormEdit::CheckBox8Click(TObject *Sender)
{
    if (CheckBox15->Checked && CheckBox1->Checked)
    {
        CheckBox15->Checked = false;
    }

    TCheckBox* box = (TCheckBox*)Sender;
    edittype += ((box->Checked ? 1 : -1)*box->Tag);

}
//---------------------------------------------------------------------------

