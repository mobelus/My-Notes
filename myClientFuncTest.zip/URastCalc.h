//---------------------------------------------------------------------------
#ifndef URastCalcH
#define URastCalcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Tmops_api.h"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sCurrEdit.hpp"
#include "sButton.hpp"
#include "sComboBox.hpp"
#include "sCurrencyEdit.hpp"
#include "sEdit.hpp"
#include "sMemo.hpp"
#include <ExtCtrls.hpp>
#include "tools.h"
#include "DateUtils.hpp"
#include "sButton.hpp"
#include "sComboBox.hpp"
#include "sEdit.hpp"
#include "sMemo.hpp"
#include <ExtCtrls.hpp>
#include "sCurrencyEdit.hpp"

#include "vozvrat.h"

//---------------------------------------------------------------------------
class TFRastCalc : public TFrame{
__published:	// IDE-managed Components
    TsDateEdit *date_zayav;
    TsDateEdit *DateRast;
    TRadioGroup *rgOsnovanie;
    TsComboBox *cbReason;
    TsMemo *memo_perechen;
    TGroupBox *GroupBox2;
    TsButton *sButton1;
    TsMemo *memoARMresult;
    TsMemo *memo_dopperechen;
    TLabel *needander;
    TsDateEdit *srok_po;
    TGroupBox *gbrast;
    TGroupBox *GroupBox3;
    TLabel *Label3;
    TLabel *Label4;
    TsCalcEdit *eStrPrem;
    TsCalcEdit *eVozvrat;
    TGroupBox *GroupBox4;
    TsComboBox *cbStrahStatus;
    TsEdit *eFIO;
    TsEdit *eINN;
    TsEdit *ePaspSer;
    TsEdit *ePaspNum;
    TsEdit *eTel;
    TsEdit *eADR;
    TLabel *Label1;
    void __fastcall cbReasonChange(TObject *Sender);
    void __fastcall rgOsnovanieClick(TObject *Sender);
    void __fastcall sButton1Click(TObject *Sender);
    void __fastcall eFIOChange(TObject *Sender);
    void __fastcall ePaspSerChange(TObject *Sender);
    void __fastcall ePaspNumChange(TObject *Sender);
    void __fastcall eTelChange(TObject *Sender);
    void __fastcall eINNChange(TObject *Sender);
    void __fastcall vozvr_dog_numChange(TObject *Sender);
    void __fastcall vozvr_dog_dateChange(TObject *Sender);
    void __fastcall vozvr_vznosChange(TObject *Sender);
    void __fastcall rsChange(TObject *Sender);
    void __fastcall bankChange(TObject *Sender);
    void __fastcall cbStrahStatusChange(TObject *Sender);
        void __fastcall DateRastChange(TObject *Sender);
private:	        // User declarations
   int res;
   mops_api_027* m_api;
   int can_edit_rast_date;
   int can_print;
   TDateTime pol_date;
   AnsiString pol_ser, pol_num, dog_status_text;
   int dog_status;
   int ndays_ispolzovania;
   int ndaytoend;
   bool isekis;
   double prem;
   bool raschet_vozvrata;
   public:
   double premVozvrat;
   AnsiString prev_skk;
   AnsiString branch_name;
   AnsiString branch_addr;
private:
   void CalcVozvrat();
   void __fastcall CheckError();
   void checkdogstatus(int statusid);
public:		// User declarations
   __fastcall TFRastCalc(TComponent* Owner,mops_api_027* _m_api);
   void __fastcall LoadFrame(long calc_id);
   void __fastcall SaveFrame(long calc_id);
public:
   TRichEdit *descr;
   TVozvratForm *frame_vozvrat;
};
//---------------------------------------------------------------------------
extern PACKAGE TFRastCalc *FRastCalc;
//---------------------------------------------------------------------------
#endif
