//---------------------------------------------------------------------------
#ifndef DmCriticalSectionH
#define DmCriticalSectionH
//---------------------------------------------------------------------------
#include <windows.h>
//---------------------------------------------------------------------------
class DmCriticalSection{
public:
   virtual ~DmCriticalSection(){}
   virtual void Acquire() = 0;
   virtual bool TryAcquire() = 0;
   virtual void Release() = 0;
};
//---------------------------------------------------------------------------
class DmSysCriticalSection : public DmCriticalSection{
   CRITICAL_SECTION lock;
private:
   DmSysCriticalSection(const DmSysCriticalSection&);
   DmSysCriticalSection& operator=(const DmSysCriticalSection&);
public:
   DmSysCriticalSection();
   explicit DmSysCriticalSection(DWORD);
   virtual ~DmSysCriticalSection();
   virtual void Acquire();
   virtual bool TryAcquire();
   virtual void Release();
};
//---------------------------------------------------------------------------
#endif
