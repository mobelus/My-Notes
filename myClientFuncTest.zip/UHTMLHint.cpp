//---------------------------------------------------------------------------
#define NO_WIN32_LEAN_AND_MEAN
#include <vcl.h>
#pragma hdrstop
#include "UHTMLHint.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SHDocVw_OCX"
#pragma resource "*.dfm"

TFHTMLHint *FHTMLHint;
//---------------------------------------------------------------------------
__fastcall TFHTMLHint::TFHTMLHint(TComponent* Owner)
        : TForm(Owner)
{

   OleInitialize(NULL);
/* LPITEMIDLIST ItemIdList;
   char path[MAX_PATH];
   SHGetSpecialFolderLocation(NULL,CSIDL_INTERNET_CACHE,&ItemIdList);
   SHGetPathFromIDList(ItemIdList,(char*)&path);
 */

}
//----------------------------------------------------------------------------
void __fastcall TFHTMLHint::ShowHint(int id_templates,int id_topics, const templates &templ_, const topics &topic_,POINT* p)
{
        templ=templ_;
        topic=topic_;
        templ_id=id_templates;
        topic_id=id_topics;
        TMemoryStream *ms=new TMemoryStream();
        string s=templ[templ_id].htmlcode;
        string::size_type pos=s.find(templ[templ_id].html_content_position);
        s.replace(pos,templ[templ_id].html_content_position.size() ,topic[topic_id]);
        ms->WriteBuffer(s.c_str(),s.length());
        ms->Seek(0,0);
        WB->Navigate(L"about:blank");
        IPersistStreamInit *ps;
        WB->Document->QueryInterface(IID_IPersistStreamInit,(void **)&ps);
        TStreamAdapter *sa=new TStreamAdapter(ms,soReference);
        ps->Load(*sa);
        delete ms;
        if (p==NULL){
                p = new POINT();
                GetCursorPos(p);
        }
        Left=p->x;
        Top=p->y;
        delete p;
        ShowModal();
}
//----------------------------------------------------------------------------
void __fastcall TFHTMLHint::WBDocumentComplete(TObject *Sender,
      LPDISPATCH pDisp, Variant *URL)
{
        int clientWidth = WB->OleObject.OlePropertyGet("Document").OlePropertyGet("Body").OlePropertyGet("clientWidth");
        int scrollWidth = WB->OleObject.OlePropertyGet("Document").OlePropertyGet("Body").OlePropertyGet("scrollWidth");
        this->Width=clientWidth>scrollWidth?clientWidth:scrollWidth;
        int clientHeight= WB->OleObject.OlePropertyGet("Document").OlePropertyGet("Body").OlePropertyGet("clientHeight");
        int scrollHeight= WB->OleObject.OlePropertyGet("Document").OlePropertyGet("Body").OlePropertyGet("scrollHeight");
        this->Height=clientHeight>scrollHeight?clientHeight:scrollHeight;
       if(Left+Width > Screen->Width)
               Left=Left-Width;
       if(Top+Height>Screen->Height)
                Top=Top-Height;
}
//---------------------------------------------------------------------------
void __fastcall TFHTMLHint::WBWindowClosing(TObject *Sender,
      VARIANT_BOOL IsChildWindow, VARIANT_BOOL *Cancel)
{
        *Cancel=((VARIANT_BOOL)-1);
        this->Close();
}
//---------------------------------------------------------------------------
void __fastcall TFHTMLHint::WBBeforeNavigate2(TObject *Sender,
      LPDISPATCH pDisp, Variant *URL, Variant *Flags,
      Variant *TargetFrameName, Variant *PostData, Variant *Headers,
      VARIANT_BOOL *Cancel)
{
    AnsiString url=AnsiString(*URL);
    url=url.Delete(1,12);
    if(!url.IsEmpty())
    {
        *Cancel=((VARIANT_BOOL)-1);
        TStringList *sl=new TStringList();
        sl->Text=StringReplace(url,"&","\r\n",TReplaceFlags()<<rfReplaceAll);

        //�������� ����
        if(sl->Values["close"]==1)
        {
         this->Close();
         return;
        }

        //������
        if(sl->Values["print"]==1)
        {
         WB->ExecWB(Shdocvw_tlb::OLECMDID_PRINT,Shdocvw_tlb::OLECMDEXECOPT_DODEFAULT);
         return;
        }
        //�����������
        if(sl->Values["copy"]==1)
        {
         WB->ExecWB(Shdocvw_tlb::OLECMDID_COPY,Shdocvw_tlb::OLECMDEXECOPT_PROMPTUSER);
         return;
        }
        //����������
        if(sl->Values["saveas"]==1)
        {
         WB->ExecWB(Shdocvw_tlb::OLECMDID_SAVEAS,Shdocvw_tlb::OLECMDEXECOPT_PROMPTUSER); // ��-�� ��� ������ ��������.
         return;

        }

        //�������� ������
        int templates_id=sl->Values["template"].ToIntDef(0);
        int topic_id=sl->Values["topic"].ToIntDef(0);
        delete sl;
        if(templates_id>0 && topic_id>0)
        {
                TFHTMLHint *hnt=new TFHTMLHint(NULL);
                POINT* p = new POINT();
                GetCursorPos(p);
                hnt->ShowHint(templates_id,topic_id,this->templ,this->topic,p);
                delete hnt;
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TFHTMLHint::FormClose(TObject *Sender,
      TCloseAction &Action)
{
OleUninitialize();        
}
//---------------------------------------------------------------------------
MESSAGE void __fastcall TFHTMLHint::MWMActivate(TMessage &Msg)
{
  if (Msg.LParamHi == 516)
        Msg.Result= MA_NOACTIVATEANDEAT;    //����� ������ IE - ���� POPUP ����

}
//---------------------------------------------------------------------------


