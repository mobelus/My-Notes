//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "UAkt.h"
#include "excel.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sCustomComboEdit"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma link "CGAUGES"
#pragma link "sFrameAdapter"
#pragma link "sSkinProvider"
#pragma resource "*.dfm"
TFAkt *FAkt;
//---------------------------------------------------------------------------
__fastcall TFAkt::TFAkt(TComponent* Owner)
: TForm(Owner), perr(0), plog(0)
{
}
//---------------------------------------------------------------------------
__fastcall TFAkt::TFAkt(TComponent* Owner, DmErr* pe, DmLog* pl)
: TForm(Owner), perr(pe), plog(pl)
{
}
//---------------------------------------------------------------------------
void __fastcall TFAkt::Button1Click(TObject *Sender)
{
   if(ComboBox1->ItemIndex == -1){
      MessageBox(0, "�� ������� ����������� ����!", "", MB_OK |MB_ICONERROR);
      return;
   }
   /*if(ComboBox2->ItemIndex == -1){
      MessageBox(0, "�� ������ �������������!", "", MB_OK |MB_ICONERROR);
      return;
   }*/
   if(Edit1->Text == ""){
      MessageBox(0, "�� ��������� ���� \"����� ������\"", "", MB_OK | MB_ICONERROR);
      return;
   }
   if(sDateEdit1->Text == "  .  .    "){
      MessageBox(0, "�� ��������� ���� ������ ������� ������������ ������", "", MB_OK | MB_ICONERROR);
      return;
   }
   if(sDateEdit2->Text == "  .  .    "){
      MessageBox(0, "�� ��������� ���� ��������� ������� ������������ ������","",MB_OK | MB_ICONERROR);
      return;
   }

   int f_id = m_api->Internal_Get_Additional_File_Id_By_Name("��� ����������� �����"), res, row(15), rc;
   AnsiString ExcelName = m_api->Excel_tmp_path + "\\tmp_report.xlt";

   m_api->dbSaveFileFromStore(res, f_id, ExcelName, true);

   Excel *excel;
   if (perr && plog) excel = new Excel(perr, plog);
   else              excel = new Excel();
   excel->ExcelInit(ExcelName.c_str());
   excel->toExcelCell(6, 2, "��� ����������� ����� �" + Edit1->Text);
   excel->toExcelCell(9, 2, "�� ������ �  " + FormatDateTime("dd mmmm yyyy", sDateEdit1->Date) +  " �� " + FormatDateTime("dd mmmm yyyy", sDateEdit2->Date));
   excel->toExcelCell(11, 2, schapka);

   TADOQuery *qw = m_api->dbGetCursor(res, "select * from OSAGO_R_main as om inner join _mops_calcs_ as mc on om.calc_id=mc.id where (om.pol_zayav_date_zayav>=" + m_api->Internal_Convert_Date_To_SQL(res, sDateEdit1->Text) + " and om.pol_zayav_date_zayav<=" + m_api->Internal_Convert_Date_To_SQL(res, sDateEdit2->Text) + " and om.broker_name='" + ComboBox1->Text + "' and mc.deleted=0)");
   rc = (qw->IsEmpty() ? 0 : qw->RecordCount);
   CGauge->MinValue = 0;
   CGauge->MaxValue = rc * 18 + 2;
   CGauge->Visible = true;
   for(int i = 0; i < rc; ++i, qw->Next()){
      row = 15 + i;

      excel->InsertRow(row); CGauge->Progress++;
      excel->toExcelCell(row, 2, Variant(i + 1)); CGauge->Progress++;
      excel->toExcelCell(row, 3, qw->FieldByName("pol_zayav_strah_fio")->AsString); CGauge->Progress++;
      excel->toExcelCell(row, 4, qw->FieldByName("pol_zayav_pol_ser")->AsString + " " + qw->FieldByName("pol_zayav_pol_num")->AsString); CGauge->Progress++;
      excel->toExcelCell(row, 5, qw->FieldByName("Kvitanciya_num")->AsString); CGauge->Progress++;
      excel->toExcelCell(row, 6, qw->FieldByName("Kvitanciya_date")->AsString); CGauge->Progress++;
      excel->toExcelCell(row, 7, qw->FieldByName("calc_prem")->AsString); CGauge->Progress++;
      excel->toExcelCell(row, 8, AnsiString("10%")); CGauge->Progress++;
      excel->toExcelCell(row, 9, FloatToStr(qw->FieldByName("calc_prem")->AsFloat * 0.1)); CGauge->Progress++;
      excel->SetFrameCellss(row, 2, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 3, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 4, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 5, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 6, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 7, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 8, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      excel->SetFrameCellss(row, 9, xlDouble, xlThin, RGB(0,0,0)); CGauge->Progress++;
      CGauge->Progress++;
   }

   m_api->dbCloseCursor(res, qw);

   excel->toExcelCell(row + 1, 7, "=����(G15:G" + IntToStr(row) + ")"); CGauge->Progress++;
   excel->toExcelCell(row + 1, 9, "=����(I15:I" + IntToStr(row) + ")"); CGauge->Progress++;

   if(PreViewFlag) excel->Visible(true);
   else            excel->Print();

   excel->Free();
   CGauge->Visible = false;

   Close();
}
//---------------------------------------------------------------------------
void __fastcall TFAkt::FormShow(TObject *Sender)
{
   int res;

   TADOQuery *qw = m_api->dbGetCursor(res, "select * from OSAGO_R_rekv_office");
   ComboBox1->Clear();
   for(qw->First(); !qw->Eof; qw->Next())
      ComboBox1->AddItem(qw->FieldByName("broker_name")->AsString, (TObject*)qw->FieldByName("id_broker")->AsInteger);
   m_api->dbCloseCursor(res, qw);
}
//---------------------------------------------------------------------------
void __fastcall TFAkt::ComboBox1Change(TObject *Sender)
{
   //int res, id = (int)ComboBox1->Items->Objects[ComboBox1->ItemIndex];

   //m_api->dbReadWriteInternalMemo(res, schapka, id, true, "OSAGO_memo_ur_lic_genser_akt");

   /*TADOQuery *qw = m_api->dbGetCursor(res, "select fio_rgs_pred_i, dolgn_pred_i from OSAGO_R_predst where id_broker=" + IntToStr(id));
   ComboBox2->Clear();
   fiodlzh->Clear();
   for(int i = 0, rc = qw->RecordCount; i < rc; ++i, qw->Next()){
      tmp = qw->FieldByName("fio_rgs_pred_i")->AsString;
      fiodlzh->Add(tmp + "=" + qw->FieldByName("dolgn_pred_i")->AsString);
      ComboBox2->Items->Add(tmp);
   }
   m_api->dbCloseCursor(res, qw);*/
}
//---------------------------------------------------------------------------

