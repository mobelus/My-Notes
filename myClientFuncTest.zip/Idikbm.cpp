// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://dkbm:8080/KBM/SePeZ_RSA_KBM.dll/wsdl/Idikbm
// Codegen  : [wfDebug,wfVerbose,wfSkipHttpBindings,wfSkipUnusedTypes]
// Version  : 1.0
// (15.10.2012 09:36:20 - $Revision:   1.0.1.0.1.81  $)
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#if !defined(__Idikbm_h__)
#include "Idikbm.h"
#endif



namespace NS_Idikbm {

_di_Idikbm GetIdikbm(bool useWSDL, AnsiString addr)
{
  static const char* defWSDL= "http://dkbm:8080/KBM/SePeZ_RSA_KBM.dll/wsdl/Idikbm";
  static const char* defURL = "http://dkbm:8080/KBM/SePeZ_RSA_KBM.dll/soap/Idikbm";
  static const char* defSvc = "Idikbmservice";
  static const char* defPrt = "IdikbmPort";
  if (addr=="")
    addr = useWSDL ? defWSDL : defURL;
  THTTPRIO* rio = new THTTPRIO(0);
  if (useWSDL) {
    rio->WSDLLocation = addr;
    rio->Service = defSvc;
    rio->Port = defPrt;
  } else {
    rio->URL = addr;
  }
  _di_Idikbm service;
  rio->QueryInterface(service);
  if (!service)
    delete rio;
  return service;
}


// ************************************************************************ //
// This routine registers the interfaces and types used by invoke the SOAP
// Service.
// ************************************************************************ //
static void RegTypes()
{
  /* Idikbm */
  InvRegistry()->RegisterInterface(__interfaceTypeinfo(Idikbm), L"urn:dikbm-Idikbm", L"");
  InvRegistry()->RegisterDefaultSOAPAction(__interfaceTypeinfo(Idikbm), L"urn:dikbm-Idikbm#GetKbmTo");
}
#pragma startup RegTypes 32

};     // Idikbm

 