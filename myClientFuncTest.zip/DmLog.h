//---------------------------------------------------------------------------

#ifndef DmLogH
#define DmLogH
//---------------------------------------------------------------------------
#include <sys/timeb.h>
#include <time.h>
#include <fstream>
#include <string>
#include "DmCriticalSection.h"
//---------------------------------------------------------------------------
struct DmErr{
   bool err;
   enum { max = 256 };
   char description[max], name[max], msg[max];
   int code;
private:
   DmErr(const DmErr&);
   void operator=(const DmErr&);
public:
   DmErr();
   void operator()(const char* ds, const char* n, const char* msg, int c = 0);
   void Reset();
};
//---------------------------------------------------------------------------

class DmLog{
   DmCriticalSection* lock;
   unsigned long counter;
   std::ofstream fout;
   enum { max_lines = 512, max_line = 256 };
   char buff[max_lines][max_line];
   timeb bftm[max_lines];
   int idx, bf_size;
private:
   unsigned long GetFileSize(const char*);
   void _FlushBuffer();
   void WriteDateTime(const timeb*);
   void WriteDateTime();
public:
   DmLog();
   explicit DmLog(const char*);
   ~DmLog();
   void Open(const char*);
   void Write(const char*);
   template <class T> void Write(const T& t);
   template <class T> void Write(const char*, T);
   void ToBuffer(const char*);
   void FlushBuffer();
   void Write(const char* object, DmErr&);
};
//---------------------------------------------------------------------------
template <class T> void DmLog::Write(const T& t)
{
   Write(t.c_str());
}
//---------------------------------------------------------------------------
template <class T> void DmLog::Write(const char* name, T val)
{
   lock->Acquire();
      if(!!fout){
         fout << ++counter << ". " << name << ": " << val;
         WriteDateTime();
      }
   lock->Release();
}
//---------------------------------------------------------------------------

#endif
 