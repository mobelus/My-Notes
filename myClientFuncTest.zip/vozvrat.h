//---------------------------------------------------------------------------


#ifndef vozvratH
#define vozvratH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

#include "Tmops_api.h"
#include "tools.h"

#include "sComboBox.hpp"
#include "sCurrEdit.hpp"
#include "sCurrencyEdit.hpp"
#include "sCustomComboEdit.hpp"
#include "sEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sMemo.hpp"
//---------------------------------------------------------------------------
class TVozvratForm : public TFrame
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox5;
        TsComboBox *cbVozvrat;
        TGroupBox *gr0;
        TsEdit *rs;
        TsEdit *bank;
        TGroupBox *gr2;
        TsComboBox *vozvr_dog_ser;
        TsEdit *vozvr_dog_num;
        TsDateEdit *vozvr_dog_date;
        TsCurrencyEdit *vozvr_vznos;
        TsMemo *memo_perechen;
        TsEdit *bik;
        void __fastcall cbVozvratChange(TObject *Sender);
        void __fastcall rsChange(TObject *Sender);
        void __fastcall rsKeyPress(TObject *Sender, char &Key);
        void __fastcall bikKeyPress(TObject *Sender, char &Key);
private:	// User declarations
   int res;
   mops_api_027* m_api;
   bool IsRS(AnsiString rs, AnsiString  bik);
   bool IsKS(AnsiString ks, AnsiString  bik);
   Set<char,0,255> s_num;

public:		// User declarations
        TFrame *calc_frame; //����� ������� ��� ��������������(��� ������ ���)
        TFrame *rast_frame; //����� ��� �����������

        __fastcall TVozvratForm(TComponent* Owner, mops_api_027* _m_api);

        void __fastcall LoadFrame(long calc_id);
        void __fastcall SaveFrame(long calc_id);
        void __fastcall CheckError();
};
//---------------------------------------------------------------------------
extern PACKAGE TVozvratForm *VozvratForm;
//---------------------------------------------------------------------------
#endif
