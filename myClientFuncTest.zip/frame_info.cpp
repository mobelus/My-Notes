//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "frame_info.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxContainer"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxMemo"
#pragma link "cxRichEdit"
#pragma link "cxTextEdit"
#pragma link "frxClass"
#pragma link "frxPreview"
#pragma resource "*.dfm"
TInfo *Info;
//---------------------------------------------------------------------------
__fastcall TInfo::TInfo(TComponent* Owner)
    : TFrame(Owner)
{
    frxReport1->ShowReport(0);
}
//---------------------------------------------------------------------------



