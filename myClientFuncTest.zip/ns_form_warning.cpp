//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ns_form_warning.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tform_ns_del_warning *form_ns_del_warning;
//---------------------------------------------------------------------------
__fastcall Tform_ns_del_warning::Tform_ns_del_warning(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall Tform_ns_del_warning::Button1Click(TObject *Sender)
{
   ModalResult = mrCancel;
   Close();   
}
//---------------------------------------------------------------------------

void __fastcall Tform_ns_del_warning::Button2Click(TObject *Sender)
{
 ModalResult = mrOk;
}
//---------------------------------------------------------------------------
