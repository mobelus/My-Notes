//---------------------------------------------------------------------------

#ifndef Date_interval_Form_cH
#define Date_interval_Form_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sPanel.hpp"
#include "sSkinProvider.hpp"
#include "sSpeedButton.hpp"
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "sCustomComboEdit.hpp"
#include "sLabel.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TDate_interval_Form : public TForm
{
__published:	// IDE-managed Components
   TsSkinProvider *sSkinProvider1;
   TsPanel *sPanel5;
   TsSpeedButton *sSpeedButton5;
   TsSpeedButton *sSpeedButton6;
   TsLabel *sLabel3;
   TsDateEdit *sDateEdit1;
   TsLabel *sLabel1;
   TsDateEdit *sDateEdit2;
   TsLabel *sLabel2;
   TCheckBox *CheckBox1;
   TCheckBox *CheckBox2;
   void __fastcall sSpeedButton5Click(TObject *Sender);
   void __fastcall sSpeedButton6Click(TObject *Sender);
   void __fastcall CheckBox1Click(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TDate_interval_Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDate_interval_Form *Date_interval_Form;
//---------------------------------------------------------------------------
#endif
