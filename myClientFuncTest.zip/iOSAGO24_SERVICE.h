// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://apo.rgs.ru/Send_OSAGO_Service_Prod/Send_OSAGO_Service.dll/wsdl/ISend_OSAGO_Service
// Version  : 1.0
// (11.09.2015 16:08:59 - $Revision:   1.0.1.0.1.82  $)
// ************************************************************************ //

#ifndef   iOSAGO24_SERVICEH
#define   iOSAGO24_SERVICEH

#include <System.hpp>
#include <InvokeRegistry.hpp>
#include <XSBuiltIns.hpp>
#include <SoapHTTPClient.hpp>


namespace NS_ISend_OSAGO24_Service {

// ************************************************************************ //
// The following types, referred to in the WSDL document are not being represented
// in this file. They are either aliases[@] of other types represented or were referred
// to but never[!] declared in the document. The types from the latter category
// typically map to predefined/known XML or Borland types; however, they could also 
// indicate incorrect WSDL documents that failed to declare or import a schema type.
// ************************************************************************ //
// !:string          - "http://www.w3.org/2001/XMLSchema"
// !:base64Binary    - "http://www.w3.org/2001/XMLSchema"


// ************************************************************************ //
// Namespace : urn:Send_OSAGO_Service_srv-ISend_OSAGO_Service
// soapAction: urn:Send_OSAGO_Service_srv-ISend_OSAGO_Service#%operationName%
// transport : http://schemas.xmlsoap.org/soap/http
// style     : rpc
// binding   : ISend_OSAGO_Servicebinding
// service   : ISend_OSAGO_Serviceservice
// port      : ISend_OSAGO_ServicePort
// URL       : http://apo.rgs.ru/Send_OSAGO_Service_Prod/Send_OSAGO_Service.dll/soap/ISend_OSAGO_Service
// ************************************************************************ //
__interface INTERFACE_UUID("{FC15C850-566F-9947-B93C-15E3F563ED1B}") ISend_OSAGO24_Service : public IInvokable
{                                      //E
public:
  virtual AnsiString      Send_OSAGO_24(const AnsiString XML_Node_Data, const AnsiString Partner_System_Name, const AnsiString Branch_Code, const AnsiString Agent_LNR, const AnsiString Agent_name, const bool Check_Only_Dont_Send, const AnsiString VersionsSL) = 0;
  virtual AnsiString      Send_OSAGO_Get_Reject_Number(const AnsiString Partner_System_Name, const AnsiString Branch_Code, const AnsiString Agent_LNR, const AnsiString Agent_name) = 0;
  virtual AnsiString      Send_OSAGO_Reject(const AnsiString XML_Node_Data, const TByteDynArray PDF_FileBody, const AnsiString Partner_System_Name) = 0; 
  virtual AnsiString      Send_EOSAGO_2_AS(const AnsiString DraftPolicyID, const AnsiString Region, const AnsiString policy_series, const AnsiString policy_number) = 0; 
};
typedef DelphiInterface<ISend_OSAGO24_Service> _di_ISend_OSAGO24_Service;

_di_ISend_OSAGO24_Service GetISend_OSAGO24_Service(bool useWSDL=false, AnsiString addr="");

static void RegTypes()
{
  /* ISend_OSAGO_Service */
  InvRegistry()->RegisterInterface(__interfaceTypeinfo(ISend_OSAGO24_Service), L"urn:Send_OSAGO_Service_srv-ISend_OSAGO_Service", L"");
  InvRegistry()->RegisterDefaultSOAPAction(__interfaceTypeinfo(ISend_OSAGO24_Service), L"urn:Send_OSAGO_Service_srv-ISend_OSAGO_Service#%operationName%");
}

static void UNRegTypes()
{
  InvRegistry()->UnRegisterInterface(__interfaceTypeinfo(ISend_OSAGO24_Service));
}

#endif // __ISend_OSAGO_Service_h__

};     // NS_ISend_OSAGO_Service

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace NS_ISend_OSAGO24_Service;
#endif

