//---------------------------------------------------------------------------
#ifndef Calc_Descr_Frame_cH
#define Calc_Descr_Frame_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sFrameAdapter.hpp"
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TCalc_Descr_Frame : public TFrame{
__published:	// IDE-managed Components
   TsFrameAdapter *sFrameAdapter1;
        TRichEdit *sMemo1;
private:	// User declarations
public:		// User declarations
   __fastcall TCalc_Descr_Frame(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCalc_Descr_Frame *Calc_Descr_Frame;
//---------------------------------------------------------------------------
#endif



