//---------------------------------------------------------------------------

#ifndef fortunaaddformH
#define fortunaaddformH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sComboBox.hpp"
//---------------------------------------------------------------------------
class Tfortuna_add : public TForm
{
__published:	// IDE-managed Components
  TLabel *Label1;
  TEdit *Efamil;
  TsDateEdit *Ebirth;
  TButton *btncancel;
  TButton *btnok;
  TComboBox *CBsumm;
  TLabel *Label2;
  TEdit *Ename;
  TLabel *labelnam;
  TEdit *Eotch;
  TLabel *Label4;
  TsComboBox *sex;
  void __fastcall btnokClick(TObject *Sender);
  void __fastcall btncancelClick(TObject *Sender);
    void __fastcall EbirthChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall Tfortuna_add(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tfortuna_add *fortuna_add;
//---------------------------------------------------------------------------
#endif
