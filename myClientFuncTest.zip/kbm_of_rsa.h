//---------------------------------------------------------------------------
#ifndef kbm_of_rsaH
#define kbm_of_rsaH
#include <vcl.h>
#include "Idikbm.h"
#include "IAPO2_ARM_READER.h"
#include "types.h"
#include <DateUtils.hpp>


//---------------------------------------------------------------------------
class kbm_of_rsa
{
        private:
                _di_IXMLDocument d_kbm;
                AnsiString URL;
                AnsiString redirect_URL; //��� ��� ������� ����� ���������������� ������ (�������� ��� VPN-����������)
                static AnsiString xml_request_begin;
                static AnsiString xml_request_b1;
                static AnsiString xml_request_b2;
                static AnsiString xml_request_b3;
                static AnsiString  xml_request16_begin;
                static AnsiString xml_request_end;
                static AnsiString xml_kbm;
                mode_checkform mode;
                mode_work mw;
                static AnsiString InsurerId;
                void LoadPersonKBM(_di_IXMLNode CalcKBMResponse, return_value &rv);

                AnsiString XMLRequest;
                AnsiString XMLResponse;

        public:
                AnsiString GetXMLRequest(){return XMLRequest;}
                AnsiString GetXMLResponse(){return XMLResponse;}
                kbm_of_rsa(AnsiString URLService,AnsiString URLRedirectService);
                void SetCheckMode(mode_checkform m){mode=m;}
                void SetWorkMode (mode_work  mw_) {mw=mw_;}
                void CalcKBM(CalcKBMReqType &c);
                static map_skk_to_rsa_doctype mdt;
                bool start_request_in_thread;

                void ConvertXMLRequestToCalcKbmReqType(AnsiString &XML,CalcKBMReqType &c);
                void ConvertXMLResponseToCalcKbmReqType(AnsiString &XML,CalcKBMReqType &c);
                void ClearCalcKBMReqType(CalcKBMReqType &c,bool response_only);

};

     AnsiString kbm_of_rsa::InsurerId="03000000";

     AnsiString kbm_of_rsa::xml_request_begin="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                        "<rsa:CalcRequest xsi:schemaLocation=\"com/rsa/dkbm/schema-1.5 CalcRequest.xsd\" xmlns:rsa=\"com/rsa/dkbm/schema-1.5\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n";

     AnsiString kbm_of_rsa::xml_request16_begin="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                        "<rsa:CalcRequest xsi:schemaLocation=\"com/rsa/dkbm/schema-1.6 CalcRequest.xsd\" xmlns:rsa=\"com/rsa/dkbm/schema-1.6\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n";

     AnsiString kbm_of_rsa::xml_request_b1="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                        "<rsa:CalcRequest xsi:schemaLocation=\"com/rsa/dkbm/schema-";
     AnsiString kbm_of_rsa::xml_request_b2=" CalcRequest.xsd\" xmlns:rsa=\"com/rsa/dkbm/schema-";
     AnsiString kbm_of_rsa::xml_request_b3="\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n";


     AnsiString kbm_of_rsa::xml_request_end="\r\n</rsa:CalcRequest>";


     AnsiString kbm_of_rsa::xml_kbm=    "<?xml version=\"1.0\" encoding=\"Windows-1251\"?>\r\n"
                                        "<CalcRequestValue>\r\n"
 	                                "</CalcRequestValue>\r\n";


map_skk_to_rsa_doctype kbm_of_rsa::mdt;



#endif
