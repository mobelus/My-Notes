//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Date_interval_Form_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sPanel"
#pragma link "sSkinProvider"
#pragma link "sSpeedButton"
#pragma link "sCustomComboEdit"
#pragma link "sLabel"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma resource "*.dfm"
TDate_interval_Form *Date_interval_Form;
//---------------------------------------------------------------------------
__fastcall TDate_interval_Form::TDate_interval_Form(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDate_interval_Form::FormShow(TObject *Sender)
{
   sDateEdit1->Text = "  .  .    ";
   sDateEdit2->Text = "  .  .    ";
   CheckBox1->Enabled = true;
   CheckBox2->Enabled = true;
   CheckBox1->Checked = false;
   CheckBox2->Checked = false;
   ActiveControl = sPanel5;
}
//---------------------------------------------------------------------------
void __fastcall TDate_interval_Form::sSpeedButton5Click(TObject *Sender)
{
   TDateTime dt;
   if(!CheckBox1->Checked && !CheckBox2->Checked && (!TryStrToDate(sDateEdit1->Text, dt) || !TryStrToDate(sDateEdit2->Text, dt)))
      ModalResult = mrCancel;
   else
      ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TDate_interval_Form::sSpeedButton6Click(TObject *Sender)
{
   ModalResult = mrCancel;
}
//---------------------------------------------------------------------------
void __fastcall TDate_interval_Form::CheckBox1Click(TObject *Sender)
{
   TCheckBox* chb = dynamic_cast<TCheckBox*>(Sender);
   bool state = chb->Checked;

   sDateEdit1->Enabled = !state;
   sDateEdit2->Enabled = !state;
   if(chb->Tag == 1) CheckBox2->Enabled = !state;
   if(chb->Tag == 2) CheckBox1->Enabled = !state;
}
//---------------------------------------------------------------------------

