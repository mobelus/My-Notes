//---------------------------------------------------------------------------

#ifndef UAktH
#define UAktH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "Tmops_api.h"
#include "CGAUGES.h"
#include "sFrameAdapter.hpp"
#include "sSkinProvider.hpp"
#include <memory>
#include "DmLog.h"
//---------------------------------------------------------------------------
class TFAkt : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TEdit *Edit1;
   TLabel *Label2;
   TsDateEdit *sDateEdit1;
   TLabel *Label3;
   TsDateEdit *sDateEdit2;
   TButton *Button1;
   TComboBox *ComboBox1;
   TLabel *Label4;
   TCGauge *CGauge;
   TLabel *Label5;
   TComboBox *ComboBox2;
   TsSkinProvider *sSkinProvider1;
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall ComboBox1Change(TObject *Sender);
private:	// User declarations
   AnsiString schapka;
   DmLog *plog;
   DmErr *perr;
public:		// User declarations
   __fastcall TFAkt(TComponent* Owner);
   __fastcall TFAkt(TComponent* Owner, DmErr* pe, DmLog* pl);
   mops_api_014* m_api;
   bool PreViewFlag;
};
//---------------------------------------------------------------------------
extern PACKAGE TFAkt *FAkt;
//---------------------------------------------------------------------------
#endif
