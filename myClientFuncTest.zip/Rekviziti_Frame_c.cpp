//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Rekviziti_Frame_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sFrameAdapter"
#pragma resource "*.dfm"
TRekviziti_Frame *Rekviziti_Frame;
//---------------------------------------------------------------------------
__fastcall TRekviziti_Frame::TRekviziti_Frame(TComponent* Owner)
        : TFrame(Owner)
{


}
//---------------------------------------------------------------------------
void TRekviziti_Frame::InitFrame(mops_api_014* _m_api)
{
   m_api = _m_api;
   int res;

   qw = m_api->dbGetCursor(res, "select * from OSAGO_R_rekv_office");
   CBBroker->Clear();
   for(qw->First(); !qw->Eof; qw->Next())
      CBBroker->AddItem(qw->FieldByName("broker_name")->AsString, (TObject*)qw->FieldByName("id_broker")->AsInteger);
   m_api->dbCloseCursor(res, qw);

   qw = m_api->dbGetCursor(res, "select distinct Ispolnitel from OSAGO_R_main");
   for(qw->First(); !qw->Eof; qw->Next())
      CBIsp->Items->Add(qw->FieldByName("Ispolnitel")->AsString);
   m_api->dbCloseCursor(res, qw);

   CBIsp->Text = m_api->vrGetVariable(res, "_Mops_Global_Ispolnitel");
   CBPredst->Text=m_api->vrGetVariable(res, "_Mops_OSAGO_Predstavitel");

}
//---------------------------------------------------------------------------
void TRekviziti_Frame::LoadFrame(int id_calc)
{
   int res;
   TADOQuery *qw1 = m_api->dbGetCursor(res, "select broker_name, fio_rgs_pred_i, Ispolnitel, dolzh_pred_i,dov_num_data from OSAGO_R_main where calc_id=" + IntToStr(id_calc));
   CBBroker->ItemIndex = CBBroker->Items->IndexOf(qw1->FieldByName("broker_name")->AsString);
   CBBrokerChange(0);
   if(CBBroker->ItemIndex<0)
        CBBroker->Text=qw1->FieldByName("broker_name")->AsString;
   CBPredst->ItemIndex = CBPredst->Items->IndexOf(qw1->FieldByName("fio_rgs_pred_i")->AsString);
   CBPredstChange(0);
   if(CBPredst->ItemIndex<0)
        CBPredst->Text=qw1->FieldByName("fio_rgs_pred_i")->AsString;
   CBIsp->Text = qw1->FieldByName("Ispolnitel")->AsString;
   Edit4->Text = qw1->FieldByName("dolzh_pred_i")->AsString;
   Edit3->Text = qw1->FieldByName("dov_num_data")->AsString;
   m_api->dbCloseCursor(res, qw1);
   CheckData();
}
//---------------------------------------------------------------------------
void __fastcall TRekviziti_Frame::CBBrokerChange(TObject *Sender)
{
   int res;
   if(CBBroker->ItemIndex > -1){
      qw = m_api->dbGetCursor(res, "select * from OSAGO_R_predst where id_broker=" + IntToStr((int)CBBroker->Items->Objects[CBBroker->ItemIndex]));
      CBPredst->Clear();
      for(qw->First(); !qw->Eof; qw->Next())
         CBPredst->AddItem(qw->FieldByName("fio_rgs_pred_i")->AsString, (TObject*)qw->FieldByName("id_predst")->AsInteger);
      m_api->dbCloseCursor(res, qw);
      if(CBPredst->Items->Count == 1) CBPredst->ItemIndex = 0;
   }

   CBPredstChange(0);
   CheckData();
}
//---------------------------------------------------------------------------
void __fastcall TRekviziti_Frame::CBPredstChange(TObject *Sender)
{
   int res;

   Edit4->Text = "";
   Edit3->Text = "";
   if(CBPredst->ItemIndex > -1){
      qw = m_api->dbGetCursor(res, "select * from OSAGO_R_predst where id_predst=" + IntToStr((int)CBPredst->Items->Objects[CBPredst->ItemIndex]));
      Edit4->Text = qw->FieldByName("dolgn_pred_i")->AsString;
      Edit3->Text = qw->FieldByName("dov_num_data")->AsString;
      m_api->dbCloseCursor(res, qw);

   }
   CheckData();
}
//---------------------------------------------------------------------------
void TRekviziti_Frame::SaveFrame(long id)
{
   CheckData();
   int res, id1(0);

   if(CBPredst->ItemIndex > -1) id1 = (int)CBPredst->Items->Objects[CBPredst->ItemIndex];

   qw = m_api->dbGetCursor(res, "select * from OSAGO_R_predst where id_predst=" + IntToStr(id1));
   AnsiString sql =  "update OSAGO_R_main set"
                     " broker_name='" + CBBroker->Text + "'," +
                     " fio_rgs_pred_i='" + CBPredst->Text + "',"
                     " fio_rgs_pred_r='" + qw->FieldByName("fio_rgs_pred_r")->AsString + "',"
                     " dolzh_pred_i='" + Edit4->Text/*qw->FieldByName("dolgn_pred_i")->AsString*/ + "',"
                     " dolzh_pred_r='" + qw->FieldByName("dolgn_pred_r")->AsString + "',"
                     " dov_num_data='" + Edit3->Text /*qw->FieldByName("dov_num_data")->AsString*/ + "',"
                     " Ispolnitel='"   + CBIsp->Text + "'"
                     " where calc_id=" + IntToStr(id);

   m_api->dbCloseCursor(res, qw);
   m_api->dbExecuteQuery(res, sql);

   m_api->vrSetVariable(res, "_Mops_Global_Ispolnitel", CBIsp->Text);
   m_api->vrSetVariable(res,"_Mops_OSAGO_Predstavitel",CBPredst->Text);
}
//---------------------------------------------------------------------------
void TRekviziti_Frame::CheckData()
{
   int res;

   /*
   m_api->Raise_Error_Warning(res, this, 0, "", "", 0);
   if(CBBroker->ItemIndex == -1){
      m_api->Raise_Error_Warning(res, this, 0, "�� ������ ������!", "", 0);
      return ;
   }
   if(CBPredst->ItemIndex == -1){
      m_api->Raise_Error_Warning(res, this, 0, "�� ������ �������������!", "", 0);
      return;
   }
   */
}
//---------------------------------------------------------------------------

void __fastcall TRekviziti_Frame::CBIspChange(TObject *Sender)
{
 if(((TComboBox*)Sender)->Text.Length()>0)
 {
     int cursor_pos=((TComboBox*)Sender)->SelStart;
     AnsiString c(((TComboBox*)Sender)->Text);
     c[1]=AnsiUpperCase(c).c_str()[0];
     //c=AnsiString(c[1])+ AnsiLowerCase(c.SubString(2,c.Length()));
     ((TComboBox*)Sender)->Text=c;
     ((TComboBox*)Sender)->SelStart=cursor_pos;
 }
        
}
//---------------------------------------------------------------------------

