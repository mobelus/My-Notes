//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "XML_Progress_Form_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sGauge"
#pragma link "sLabel"
#pragma resource "*.dfm"
TXML_Progress_Form *XML_Progress_Form;
//---------------------------------------------------------------------------
__fastcall TXML_Progress_Form::TXML_Progress_Form(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
