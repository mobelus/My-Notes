//---------------------------------------------------------------------------


#ifndef Rekviziti_Frame_cH
#define Rekviziti_Frame_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Tmops_api.h"
#include "sFrameAdapter.hpp"
//---------------------------------------------------------------------------
class TRekviziti_Frame : public TFrame
{
__published:	// IDE-managed Components
   TsFrameAdapter *sFrameAdapter1;
   TEdit *Edit3;
   TLabel *Label4;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TEdit *Edit4;
   TComboBox *CBBroker;
   TComboBox *CBPredst;
   TLabel *Label5;
   TComboBox *CBIsp;
   void __fastcall CBBrokerChange(TObject *Sender);
   void __fastcall CBPredstChange(TObject *Sender);
        void __fastcall CBIspChange(TObject *Sender);
private:	// User declarations
   mops_api_014* m_api;
   TADOQuery *qw;
public:		// User declarations
   void InitFrame(mops_api_014* _m_api);
   void LoadFrame(int id_calc);
   void SaveFrame(long id);
   void CheckData();
   __fastcall TRekviziti_Frame(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRekviziti_Frame *Rekviziti_Frame;
//---------------------------------------------------------------------------
#endif
