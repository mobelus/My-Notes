
// **************************************************************************************************************************************************** //
//                                                                                                                                                    
//                                                                  XML Data Binding                                                                  
//                                                                                                                                                    
//         Generated on: 12.10.2012 17:50:37                                                                                                          
//       Generated from: C:\Documents and Settings\AAKuznetsov.RGS77MSKC001\������� ����\xsd-wsdl - v8.0\�������������� ����� � ��\CalcResponse.xsd   
//                                                                                                                                                    
// **************************************************************************************************************************************************** //

#ifndef   CalcResponseH
#define   CalcResponseH

#include <System.hpp>
#include <xmldom.hpp>
#include <XMLDoc.hpp>
#include <XMLIntf.hpp>
#include <XMLNodeImp.h>


// Forward Decls 

__interface IXMLCalcResponse;
typedef System::DelphiInterface<IXMLCalcResponse> _di_IXMLCalcResponse;
__interface IXMLCalcResponseType;
typedef System::DelphiInterface<IXMLCalcResponseType> _di_IXMLCalcResponseType;
__interface IXMLPolicyCalcType;
typedef System::DelphiInterface<IXMLPolicyCalcType> _di_IXMLPolicyCalcType;
__interface IXMLCalcKBMResps;
typedef System::DelphiInterface<IXMLCalcKBMResps> _di_IXMLCalcKBMResps;
__interface IXMLErrorInfoType;
typedef System::DelphiInterface<IXMLErrorInfoType> _di_IXMLErrorInfoType;
__interface IXMLCalcKBMType;
typedef System::DelphiInterface<IXMLCalcKBMType> _di_IXMLCalcKBMType;
__interface IXMLCalcKBMTypeList;
typedef System::DelphiInterface<IXMLCalcKBMTypeList> _di_IXMLCalcKBMTypeList;
__interface IXMLDriverDocumentType;
typedef System::DelphiInterface<IXMLDriverDocumentType> _di_IXMLDriverDocumentType;
__interface IXMLLossesCRTType;
typedef System::DelphiInterface<IXMLLossesCRTType> _di_IXMLLossesCRTType;
__interface IXMLLossCRTType;
typedef System::DelphiInterface<IXMLLossCRTType> _di_IXMLLossCRTType;
__interface IXMLTicketCarResps;
typedef System::DelphiInterface<IXMLTicketCarResps> _di_IXMLTicketCarResps;
__interface IXMLErrorListType;
typedef System::DelphiInterface<IXMLErrorListType> _di_IXMLErrorListType;

// IXMLCalcResponse 

__interface INTERFACE_UUID("{FF2B7F85-C752-4F36-9E0D-10EADF030707}") IXMLCalcResponse : public IXMLNode
{
public:
  // Property Accessors 
  virtual _di_IXMLCalcResponseType __fastcall Get_CalcResponseValue() = 0;
  virtual _di_IXMLErrorListType __fastcall Get_ErrorList() = 0;
  // Methods & Properties 
  __property _di_IXMLCalcResponseType CalcResponseValue = { read=Get_CalcResponseValue };
  __property _di_IXMLErrorListType ErrorList = { read=Get_ErrorList };
};

// IXMLCalcResponseType 

__interface INTERFACE_UUID("{47828B8F-BEC8-435A-909F-8DB690C86F87}") IXMLCalcResponseType : public IXMLNode
{
public:
  // Property Accessors 
  virtual WideString __fastcall Get_IdRequestCalc() = 0;
  virtual _di_IXMLPolicyCalcType __fastcall Get_PolicyCalc() = 0;
  virtual _di_IXMLCalcKBMResps __fastcall Get_CalcKBMResponses() = 0;
  virtual _di_IXMLTicketCarResps __fastcall Get_TicketCarResponse() = 0;
  virtual void __fastcall Set_IdRequestCalc(WideString Value) = 0;
  // Methods & Properties 
  __property WideString IdRequestCalc = { read=Get_IdRequestCalc, write=Set_IdRequestCalc };
  __property _di_IXMLPolicyCalcType PolicyCalc = { read=Get_PolicyCalc };
  __property _di_IXMLCalcKBMResps CalcKBMResponses = { read=Get_CalcKBMResponses };
  __property _di_IXMLTicketCarResps TicketCarResponse = { read=Get_TicketCarResponse };
};

// IXMLPolicyCalcType 

__interface INTERFACE_UUID("{0AC5BCFB-2FD1-40AC-BF2B-E876BC59F491}") IXMLPolicyCalcType : public IXMLNode
{
public:
  // Property Accessors 
  virtual WideString __fastcall Get_PolicySerialKey() = 0;
  virtual WideString __fastcall Get_PolicyNumberKey() = 0;
  virtual WideString __fastcall Get_PolicyKBM() = 0;
  virtual WideString __fastcall Get_PolicyKBMValue() = 0;
  virtual WideString __fastcall Get_InsurerName() = 0;
  virtual void __fastcall Set_PolicySerialKey(WideString Value) = 0;
  virtual void __fastcall Set_PolicyNumberKey(WideString Value) = 0;
  virtual void __fastcall Set_PolicyKBM(WideString Value) = 0;
  virtual void __fastcall Set_PolicyKBMValue(WideString Value) = 0;
  virtual void __fastcall Set_InsurerName(WideString Value) = 0;
  // Methods & Properties 
  __property WideString PolicySerialKey = { read=Get_PolicySerialKey, write=Set_PolicySerialKey };
  __property WideString PolicyNumberKey = { read=Get_PolicyNumberKey, write=Set_PolicyNumberKey };
  __property WideString PolicyKBM = { read=Get_PolicyKBM, write=Set_PolicyKBM };
  __property WideString PolicyKBMValue = { read=Get_PolicyKBMValue, write=Set_PolicyKBMValue };
  __property WideString InsurerName = { read=Get_InsurerName, write=Set_InsurerName };
};

// IXMLCalcKBMResps 

__interface INTERFACE_UUID("{54D0F355-AAC1-437F-9865-6F6D1CEBE0F3}") IXMLCalcKBMResps : public IXMLNode
{
public:
  // Property Accessors 
  virtual _di_IXMLErrorInfoType __fastcall Get_ErrorInfo() = 0;
  virtual _di_IXMLCalcKBMTypeList __fastcall Get_CalcKBMResponse() = 0;
  // Methods & Properties 
  __property _di_IXMLErrorInfoType ErrorInfo = { read=Get_ErrorInfo };
  __property _di_IXMLCalcKBMTypeList CalcKBMResponse = { read=Get_CalcKBMResponse };
};

// IXMLErrorInfoType 

__interface INTERFACE_UUID("{7373557C-1E4C-420C-8AC8-BDC9F8413697}") IXMLErrorInfoType : public IXMLNode
{
public:
  // Property Accessors 
  virtual int __fastcall Get_Code() = 0;
  virtual WideString __fastcall Get_Message() = 0;
  virtual void __fastcall Set_Code(int Value) = 0;
  virtual void __fastcall Set_Message(WideString Value) = 0;
  // Methods & Properties 
  __property int Code = { read=Get_Code, write=Set_Code };
  __property WideString Message = { read=Get_Message, write=Set_Message };
};

// IXMLCalcKBMType 

__interface INTERFACE_UUID("{DCBCAD7B-9355-4247-82EF-080AB5E48F02}") IXMLCalcKBMType : public IXMLNode
{
public:
  // Property Accessors 
  virtual _di_IXMLErrorInfoType __fastcall Get_ErrorInfo() = 0;
  virtual _di_IXMLDriverDocumentType __fastcall Get_DriverDocument() = 0;
  virtual WideString __fastcall Get_PersonNameBirthHash() = 0;
  virtual WideString __fastcall Get_KBMFirstLevel() = 0;
  virtual WideString __fastcall Get_KBMNextLevel() = 0;
  virtual WideString __fastcall Get_KBMValue() = 0;
  virtual _di_IXMLLossesCRTType __fastcall Get_Losses() = 0;
  virtual int __fastcall Get_LossAmount() = 0;
  virtual void __fastcall Set_PersonNameBirthHash(WideString Value) = 0;
  virtual void __fastcall Set_KBMFirstLevel(WideString Value) = 0;
  virtual void __fastcall Set_KBMNextLevel(WideString Value) = 0;
  virtual void __fastcall Set_KBMValue(WideString Value) = 0;
  virtual void __fastcall Set_LossAmount(int Value) = 0;
  // Methods & Properties 
  __property _di_IXMLErrorInfoType ErrorInfo = { read=Get_ErrorInfo };
  __property _di_IXMLDriverDocumentType DriverDocument = { read=Get_DriverDocument };
  __property WideString PersonNameBirthHash = { read=Get_PersonNameBirthHash, write=Set_PersonNameBirthHash };
  __property WideString KBMFirstLevel = { read=Get_KBMFirstLevel, write=Set_KBMFirstLevel };
  __property WideString KBMNextLevel = { read=Get_KBMNextLevel, write=Set_KBMNextLevel };
  __property WideString KBMValue = { read=Get_KBMValue, write=Set_KBMValue };
  __property _di_IXMLLossesCRTType Losses = { read=Get_Losses };
  __property int LossAmount = { read=Get_LossAmount, write=Set_LossAmount };
};

// IXMLCalcKBMTypeList 

__interface INTERFACE_UUID("{7B777860-7043-442F-9B8F-16527A5B2C17}") IXMLCalcKBMTypeList : public IXMLNodeCollection
{
  // Methods & Properties 
  virtual _di_IXMLCalcKBMType __fastcall Add() = 0;
  virtual _di_IXMLCalcKBMType __fastcall Insert(const int Index) = 0;
  virtual _di_IXMLCalcKBMType __fastcall Get_Item(int Index) = 0;
  __property _di_IXMLCalcKBMType Items[int Index] = { read=Get_Item /* default */ };
};

// IXMLDriverDocumentType 

__interface INTERFACE_UUID("{906C61AA-747C-4E97-8ABC-2DDE5DA603C2}") IXMLDriverDocumentType : public IXMLNode
{
public:
  // Property Accessors 
  virtual WideString __fastcall Get_Serial() = 0;
  virtual WideString __fastcall Get_Number() = 0;
  virtual void __fastcall Set_Serial(WideString Value) = 0;
  virtual void __fastcall Set_Number(WideString Value) = 0;
  // Methods & Properties 
  __property WideString Serial = { read=Get_Serial, write=Set_Serial };
  __property WideString Number = { read=Get_Number, write=Set_Number };
};

// IXMLLossesCRTType 

__interface INTERFACE_UUID("{26027254-2BD6-4920-94C0-3E501B2A136A}") IXMLLossesCRTType : public IXMLNodeCollection
{
public:
  // Property Accessors 
  virtual _di_IXMLLossCRTType __fastcall Get_Loss(int Index) = 0;
  // Methods & Properties 
  virtual _di_IXMLLossCRTType __fastcall Add() = 0;
  virtual _di_IXMLLossCRTType __fastcall Insert(const int Index) = 0;
  __property _di_IXMLLossCRTType Loss[int Index] = { read=Get_Loss };/* default */
};

// IXMLLossCRTType 

__interface INTERFACE_UUID("{72CB89FD-7941-4BDB-8B94-DD2C9DD85084}") IXMLLossCRTType : public IXMLNode
{
public:
  // Property Accessors 
  virtual WideString __fastcall Get_LossDateTime() = 0;
  virtual WideString __fastcall Get_PolicySerialKey() = 0;
  virtual WideString __fastcall Get_PolicyNumberKey() = 0;
  virtual WideString __fastcall Get_InsurerName() = 0;
  virtual void __fastcall Set_LossDateTime(WideString Value) = 0;
  virtual void __fastcall Set_PolicySerialKey(WideString Value) = 0;
  virtual void __fastcall Set_PolicyNumberKey(WideString Value) = 0;
  virtual void __fastcall Set_InsurerName(WideString Value) = 0;
  // Methods & Properties 
  __property WideString LossDateTime = { read=Get_LossDateTime, write=Set_LossDateTime };
  __property WideString PolicySerialKey = { read=Get_PolicySerialKey, write=Set_PolicySerialKey };
  __property WideString PolicyNumberKey = { read=Get_PolicyNumberKey, write=Set_PolicyNumberKey };
  __property WideString InsurerName = { read=Get_InsurerName, write=Set_InsurerName };
};

// IXMLTicketCarResps 

__interface INTERFACE_UUID("{4632E52F-F62C-43B8-A85F-EA1392F97F8F}") IXMLTicketCarResps : public IXMLNode
{
public:
  // Property Accessors 
  virtual bool __fastcall Get_TicketExisted() = 0;
  virtual WideString __fastcall Get_DateNextTO() = 0;
  virtual WideString __fastcall Get_TicketDiagnosticDate() = 0;
  virtual _di_IXMLErrorListType __fastcall Get_ErrorList() = 0;
  virtual void __fastcall Set_TicketExisted(bool Value) = 0;
  virtual void __fastcall Set_DateNextTO(WideString Value) = 0;
  virtual void __fastcall Set_TicketDiagnosticDate(WideString Value) = 0;
  // Methods & Properties 
  __property bool TicketExisted = { read=Get_TicketExisted, write=Set_TicketExisted };
  __property WideString DateNextTO = { read=Get_DateNextTO, write=Set_DateNextTO };
  __property WideString TicketDiagnosticDate = { read=Get_TicketDiagnosticDate, write=Set_TicketDiagnosticDate };
  __property _di_IXMLErrorListType ErrorList = { read=Get_ErrorList };
};

// IXMLErrorListType 

__interface INTERFACE_UUID("{23AC4B37-4C80-4C4E-BE70-5E4CE76AD5DB}") IXMLErrorListType : public IXMLNodeCollection
{
public:
  // Property Accessors 
  virtual _di_IXMLErrorInfoType __fastcall Get_ErrorInfo(int Index) = 0;
  // Methods & Properties 
  virtual _di_IXMLErrorInfoType __fastcall Add() = 0;
  virtual _di_IXMLErrorInfoType __fastcall Insert(const int Index) = 0;
  __property _di_IXMLErrorInfoType ErrorInfo[int Index] = { read=Get_ErrorInfo };/* default */
};

// Forward Decls 

class TXMLCalcResponse;
class TXMLCalcResponseType;
class TXMLPolicyCalcType;
class TXMLCalcKBMResps;
class TXMLErrorInfoType;
class TXMLCalcKBMType;
class TXMLCalcKBMTypeList;
class TXMLDriverDocumentType;
class TXMLLossesCRTType;
class TXMLLossCRTType;
class TXMLTicketCarResps;
class TXMLErrorListType;

// TXMLCalcResponse 

class TXMLCalcResponse : public TXMLNode, public IXMLCalcResponse
{
  __IXMLNODE_IMPL__
protected:
  // IXMLCalcResponse 
  virtual _di_IXMLCalcResponseType __fastcall Get_CalcResponseValue();
  virtual _di_IXMLErrorListType __fastcall Get_ErrorList();
public:
  virtual void __fastcall AfterConstruction(void);
};


// TXMLCalcResponseType 

class TXMLCalcResponseType : public TXMLNode, public IXMLCalcResponseType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLCalcResponseType 
  virtual WideString __fastcall Get_IdRequestCalc();
  virtual _di_IXMLPolicyCalcType __fastcall Get_PolicyCalc();
  virtual _di_IXMLCalcKBMResps __fastcall Get_CalcKBMResponses();
  virtual _di_IXMLTicketCarResps __fastcall Get_TicketCarResponse();
  virtual void __fastcall Set_IdRequestCalc(WideString Value);
public:
  virtual void __fastcall AfterConstruction(void);
};


// TXMLPolicyCalcType 

class TXMLPolicyCalcType : public TXMLNode, public IXMLPolicyCalcType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLPolicyCalcType 
  virtual WideString __fastcall Get_PolicySerialKey();
  virtual WideString __fastcall Get_PolicyNumberKey();
  virtual WideString __fastcall Get_PolicyKBM();
  virtual WideString __fastcall Get_PolicyKBMValue();
  virtual WideString __fastcall Get_InsurerName();
  virtual void __fastcall Set_PolicySerialKey(WideString Value);
  virtual void __fastcall Set_PolicyNumberKey(WideString Value);
  virtual void __fastcall Set_PolicyKBM(WideString Value);
  virtual void __fastcall Set_PolicyKBMValue(WideString Value);
  virtual void __fastcall Set_InsurerName(WideString Value);
};


// TXMLCalcKBMResps 

class TXMLCalcKBMResps : public TXMLNode, public IXMLCalcKBMResps
{
  __IXMLNODE_IMPL__
private:
  _di_IXMLCalcKBMTypeList FCalcKBMResponse;
protected:
  // IXMLCalcKBMResps 
  virtual _di_IXMLErrorInfoType __fastcall Get_ErrorInfo();
  virtual _di_IXMLCalcKBMTypeList __fastcall Get_CalcKBMResponse();
public:
  virtual void __fastcall AfterConstruction(void);
};


// TXMLErrorInfoType 

class TXMLErrorInfoType : public TXMLNode, public IXMLErrorInfoType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLErrorInfoType 
  virtual int __fastcall Get_Code();
  virtual WideString __fastcall Get_Message();
  virtual void __fastcall Set_Code(int Value);
  virtual void __fastcall Set_Message(WideString Value);
};


// TXMLCalcKBMType 

class TXMLCalcKBMType : public TXMLNode, public IXMLCalcKBMType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLCalcKBMType 
  virtual _di_IXMLErrorInfoType __fastcall Get_ErrorInfo();
  virtual _di_IXMLDriverDocumentType __fastcall Get_DriverDocument();
  virtual WideString __fastcall Get_PersonNameBirthHash();
  virtual WideString __fastcall Get_KBMFirstLevel();
  virtual WideString __fastcall Get_KBMNextLevel();
  virtual WideString __fastcall Get_KBMValue();
  virtual _di_IXMLLossesCRTType __fastcall Get_Losses();
  virtual int __fastcall Get_LossAmount();
  virtual void __fastcall Set_PersonNameBirthHash(WideString Value);
  virtual void __fastcall Set_KBMFirstLevel(WideString Value);
  virtual void __fastcall Set_KBMNextLevel(WideString Value);
  virtual void __fastcall Set_KBMValue(WideString Value);
  virtual void __fastcall Set_LossAmount(int Value);
public:
  virtual void __fastcall AfterConstruction(void);
};


// TXMLCalcKBMTypeList 

class TXMLCalcKBMTypeList : public TXMLNodeCollection, public IXMLCalcKBMTypeList
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLCalcKBMTypeList 
  virtual _di_IXMLCalcKBMType __fastcall Add();
  virtual _di_IXMLCalcKBMType __fastcall Insert(const int Index);
  virtual _di_IXMLCalcKBMType __fastcall Get_Item(int Index);
};


// TXMLDriverDocumentType 

class TXMLDriverDocumentType : public TXMLNode, public IXMLDriverDocumentType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLDriverDocumentType 
  virtual WideString __fastcall Get_Serial();
  virtual WideString __fastcall Get_Number();
  virtual void __fastcall Set_Serial(WideString Value);
  virtual void __fastcall Set_Number(WideString Value);
};


// TXMLLossesCRTType 

class TXMLLossesCRTType : public TXMLNodeCollection, public IXMLLossesCRTType
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLLossesCRTType 
  virtual _di_IXMLLossCRTType __fastcall Get_Loss(int Index);
  virtual _di_IXMLLossCRTType __fastcall Add();
  virtual _di_IXMLLossCRTType __fastcall Insert(const int Index);
public:
  virtual void __fastcall AfterConstruction(void);
};


// TXMLLossCRTType 

class TXMLLossCRTType : public TXMLNode, public IXMLLossCRTType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLLossCRTType 
  virtual WideString __fastcall Get_LossDateTime();
  virtual WideString __fastcall Get_PolicySerialKey();
  virtual WideString __fastcall Get_PolicyNumberKey();
  virtual WideString __fastcall Get_InsurerName();
  virtual void __fastcall Set_LossDateTime(WideString Value);
  virtual void __fastcall Set_PolicySerialKey(WideString Value);
  virtual void __fastcall Set_PolicyNumberKey(WideString Value);
  virtual void __fastcall Set_InsurerName(WideString Value);
};


// TXMLTicketCarResps 

class TXMLTicketCarResps : public TXMLNode, public IXMLTicketCarResps
{
  __IXMLNODE_IMPL__
protected:
  // IXMLTicketCarResps 
  virtual bool __fastcall Get_TicketExisted();
  virtual WideString __fastcall Get_DateNextTO();
  virtual WideString __fastcall Get_TicketDiagnosticDate();
  virtual _di_IXMLErrorListType __fastcall Get_ErrorList();
  virtual void __fastcall Set_TicketExisted(bool Value);
  virtual void __fastcall Set_DateNextTO(WideString Value);
  virtual void __fastcall Set_TicketDiagnosticDate(WideString Value);
public:
  virtual void __fastcall AfterConstruction(void);
};


// TXMLErrorListType 

class TXMLErrorListType : public TXMLNodeCollection, public IXMLErrorListType
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLErrorListType 
  virtual _di_IXMLErrorInfoType __fastcall Get_ErrorInfo(int Index);
  virtual _di_IXMLErrorInfoType __fastcall Add();
  virtual _di_IXMLErrorInfoType __fastcall Insert(const int Index);
public:
  virtual void __fastcall AfterConstruction(void);
};


// Global Functions 

_di_IXMLCalcResponse __fastcall GetCalcResponse(_di_IXMLDocument Doc);
_di_IXMLCalcResponse __fastcall GetCalcResponse(TXMLDocument *Doc);
_di_IXMLCalcResponse __fastcall LoadCalcResponse(const WideString FileName);
_di_IXMLCalcResponse __fastcall  NewCalcResponse();

#endif 