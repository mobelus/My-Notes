//---------------------------------------------------------------------------

#ifndef Progress_Form_cH
#define Progress_Form_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sGauge.hpp"
#include "sSkinProvider.hpp"
//---------------------------------------------------------------------------
class TProgress_Form : public TForm
{
__published:	// IDE-managed Components
   TsGauge *sGauge1;
   TsSkinProvider *sSkinProvider1;
private:	// User declarations
public:		// User declarations
   __fastcall TProgress_Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
class ProgressForm{
private:
public:
   TProgress_Form *pf;
   ProgressForm(TComponent*, int);
   ~ProgressForm();
   void operator++();
};
//---------------------------------------------------------------------------
extern PACKAGE TProgress_Form *Progress_Form;
//---------------------------------------------------------------------------
#endif
