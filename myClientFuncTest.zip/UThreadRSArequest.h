//---------------------------------------------------------------------------

#ifndef UThreadRSArequestH
#define UThreadRSArequestH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include "kbm_of_rsa.h"
//---------------------------------------------------------------------------
class Rsarequest : public TThread
{
private:
protected:
        void __fastcall Execute();
        AnsiString *xml;
        AnsiString URL;
        AnsiString Redirect_url;
public:
        __fastcall Rsarequest(bool CreateSuspended, AnsiString *xml,AnsiString url,AnsiString redirect_url);

};
//---------------------------------------------------------------------------
#endif
