//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "URastSelect.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFRastSelect *FRastSelect;
//---------------------------------------------------------------------------
__fastcall TFRastSelect::TFRastSelect(TComponent* Owner)
        : TForm(Owner)
{

}
//---------------------------------------------------------------------------










