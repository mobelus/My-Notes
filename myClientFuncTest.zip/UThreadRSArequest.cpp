//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UThreadRSArequest.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall Rsarequest::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------

__fastcall Rsarequest::Rsarequest(bool CreateSuspended,AnsiString *xml_,AnsiString url,AnsiString redirect_url)
        : TThread(CreateSuspended)
{
       xml=xml_;
       URL=url;
       Redirect_url=redirect_url;
}
//---------------------------------------------------------------------------
void __fastcall Rsarequest::Execute()
{
        //---- Place thread code here ----
        try{
         *xml=GetIdikbm(false,URL)->GetKbmTo(*xml);
         }
         catch(Exception &e)
         {
          try{
                   // *xml=StringReplace(*xml,"UTF-8","WIN-1251",TReplaceFlags());
                    *xml=GetIAPO2_ARM_READER(false,Redirect_url)->GetKbmTo(*xml);
          }
          catch(Exception &e)
          {
          *xml="<?xml version=\"1.0\" standalone=\"yes\"?>\r\n"
                "<ns2:CalcResponse xmlns:ns2=\"com/rsa/dkbm/schema-1.0\">\r\n"
                "<ErrorList>\r\n"
                "<ErrorInfo>\r\n"
                "<Code>0</Code>\r\n"
                "<Message>Error connect </Message>\r\n"
                "</ErrorInfo>\r\n"
                "</ErrorList>\r\n"
                "</ns2:CalcResponse>";
          }

         }
}
//---------------------------------------------------------------------------
