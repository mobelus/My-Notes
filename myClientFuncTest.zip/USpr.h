//---------------------------------------------------------------------------

#ifndef USprH
#define USprH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "sGauge.hpp"
#include "Tmops_api.h"
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TFSpr : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TButton *Button1;
        TsGauge *CGauge2;
        TTabControl *TabControl1;
        TDBGrid *DBGrid1;
        TButton *Button2;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall TabControl1Change(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFSpr(TComponent* Owner);
      mops_api_014 *m_api;

};
//---------------------------------------------------------------------------
extern PACKAGE TFSpr *FSpr;
//---------------------------------------------------------------------------
#endif
