//---------------------------------------------------------------------------

#include "excel.h"
#include "math.h"
#include <ComObj.hpp>
#include <typeinfo.h>

#pragma hdrstop
//---------------------------------------------------------------------------
void Excel::SetCheckBox(int shape_index, bool checked)
{
   if(perr) perr->Reset();
   try{
      Sh.OlePropertyGet("CheckBoxes", shape_index).OlePropertySet("Value", checked);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetCheckBox", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetCheckBox", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetCheckBox", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//---------------------------------------------------------------------------
AnsiString Excel::Get_CheckBox_name(int index)
{
   if(perr) perr->Reset();
   AnsiString ret = "", st;
   try{
      ret = Sh.OlePropertyGet("CheckBoxes", index).OlePropertyGet("Name");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("Get_CheckBox_name", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("Get_CheckBox_name", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("Get_CheckBox_name", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

   return  ret;
}
//---------------------------------------------------------------------------
int Excel::CheckBoxes_Count()
{
   int ret(0);

   if(perr) perr->Reset();
   try{
      ret = Sh.OlePropertyGet("CheckBoxes").OlePropertyGet("Count");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("CheckBoxes_Count", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("CheckBoxes_Count", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("CheckBoxes_Count", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

   return ret;
}
//---------------------------------------------------------------------------
void Excel::Print()
{
   if(perr) perr->Reset();
   try{
      Sh.OleProcedure("PrintOut");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("Print", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("Print", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("Print", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

}
//---------------------------------------------------------------------------
int Excel::StolbecCharToInt(AnsiString st)
{
   st = st.UpperCase();
   int g(0), m;
   if(st.Length() == 1)
      m = (st.c_str())[0] - (char)'A' + 1;
   else{
      m = (st.c_str())[1] - (char)'A' + 1;
      g = (st.c_str())[0] - (char)'A' + 1;
   }
   return g * 26 + m;
}
//---------------------------------------------------------------------------
AnsiString Excel::GetActiverange()
{
   AnsiString Range;

   if(perr) perr->Reset();
   try{
      Range = Sh.OlePropertyGet("UsedRange").OlePropertyGet("Address");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("GetActiverange", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("GetActiverange", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("GetActiverange", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

   return Range;
}
//---------------------------------------------------------------------------
void Excel::toExcelCell(int Row, int Column, AnsiString data)
{
   if(perr) perr->Reset();
   try{
      Variant cur = Sh.OlePropertyGet("Cells", Row, Column);
      cur.OlePropertySet("Value", data.c_str());
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("toExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("toExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("toExcelCell", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

}
//---------------------------------------------------------------------------
AnsiString Excel::fromExcelCell(int Row, int Column)
{
   AnsiString ret("");

   if(perr) perr->Reset();
   try{
      Variant  cur =  Sh.OlePropertyGet("Cells", Row, Column);
      Variant  cur2 = cur.OlePropertyGet("Value");
      cur2.VType;
      ret = cur2;
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("fromExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("fromExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("fromExcelCell", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

   return ret;
}
//---------------------------------------------------------------------------
Variant Excel::VariantFromExcelCell(int Row,int Column)
{
   if(perr) perr->Reset();
   Variant cur, cur2;
   try{
      cur  = Sh.OlePropertyGet("Cells", Row, Column);
      cur2 = cur.OlePropertyGet("Value");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("VariantFromExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("VariantFromExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("VariantFromExcelCell", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

   return cur2;
}
//---------------------------------------------------------------------------
void Excel::Visible(bool visible)
{
   if(perr) perr->Reset();
   try{
      if(!App.IsEmpty()) App.OlePropertySet("Visible", visible);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("Visible", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("Visible", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("Visible", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//---------------------------------------------------------------------------
void Excel::ExcelInit(AnsiString File)
{
   if(perr) perr->Reset();
   try{
      App = Variant::CreateObject("Excel.Application");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("ExcelInit:CreateObject", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("ExcelInit:CreateObject", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("ExcelInit:CreateObject", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog){
      plog->Write(typeid(*this).name(), *perr);
      Application->MessageBox("���������� ������� Microsoft Excel! �������� Excel �� ���������� �� ����������.", perr->msg, MB_OK + MB_ICONERROR);
   }
   if(perr) perr->Reset();
   try{
      if(File != "") App.OlePropertyGet("WorkBooks").OleProcedure("Open", File.c_str());
      else App.OlePropertyGet("WorkBooks").OleProcedure("add");
      Sh = App.OlePropertyGet("WorkSheets", 1);

      App.OlePropertyGet("ActiveWorkBook").OlePropertySet("CheckCompatibility", false);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("ExcelInit:Open", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("ExcelInit:Open", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("ExcelInit:Open", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog){
      plog->Write(typeid(*this).name(), *perr);
      Application->MessageBox("������ �������� ����� Microsoft Excel!", "������", MB_OK + MB_ICONERROR);
   }
}
//---------------------------------------------------------------------------
void Excel::Free()
{
   Sh.Clear();
   App.Clear();
}
//---------------------------------------------------------------------------
void Excel::SaveBook()
{
   if(perr) perr->Reset();
   try{
      App.OlePropertyGet("ActiveWorkbook").OleProcedure("Save");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SaveBook", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SaveBook", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SaveBook", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//---------------------------------------------------------------------------
void Excel::InsertRow(int row_num)
{
   if(perr) perr->Reset();
   try{
      AnsiString st;
      Variant cur = Sh.OlePropertyGet("Rows", st.sprintf("%i:%i", row_num, row_num).c_str());
      cur.OleProcedure("Select");
      cur.OleProcedure("Insert");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("InsertRow", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("InsertRow", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("InsertRow", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//---------------------------------------------------------------------------
void Excel::SaveBook(AnsiString File_Name)
{
   if(perr) perr->Reset();
   try{
      AnsiString st;
      App.OlePropertyGet("ActiveWorkbook").OleProcedure("SaveAs", File_Name/*st.sprintf("Filename:=\"%s\", FileFormat:=xlNormal, Password:=\"\", WriteResPassword:=\"\", ReadOnlyRecommended:=False, CreateBackup:=False",File_Name)*/.c_str());
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SaveBook_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SaveBook_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SaveBook_", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//---------------------------------------------------------------------------
void Excel::SetRowOrientation(int row_num, int Orientation)
{
   if(perr) perr->Reset();
   try{
      AnsiString st;
      Variant  cur = Sh.OlePropertyGet("Rows", st.sprintf("%i:%i", row_num, row_num).c_str());
      cur.OleProcedure("Select");
      cur.OlePropertySet("Orientation", st.sprintf("%i", Orientation).c_str());
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetRowOrientation", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetRowOrientation", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetRowOrientation", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//-----------------------------------------------------------------------------
void Excel::toExcelCell(int Row, int Column, Variant data)
{
   if(perr) perr->Reset();
   try{
      Variant  cur = Sh.OlePropertyGet("Cells", Row, Column);
      cur.OlePropertySet("Value", data);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("toExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("toExcelCell", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("toExcelCell", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//---------------------------------------------------------------------------
void Excel::Merge(char* Range)
{
   if(perr) perr->Reset();
   try{
      Variant merge = Sh.OlePropertyGet("Range", Range);
      merge.OleProcedure("Merge");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("Merge", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("Merge", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("Merge", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::HorAlign(int  sRow,int sCol,int val)
{
   if(perr) perr->Reset();
   try{
      App.OlePropertyGet("Cells", sRow, sCol).OlePropertySet("HorizontalAlignment", val);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("HorAlign", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("HorAlign", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("HorAlign", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::VertAlign(int sRow, int sCol, int val)
{
   if(perr) perr->Reset();
   try{
      App.OlePropertyGet("Cells", sRow, sCol).OlePropertySet("VerticalAlignment", val);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("VertAlign", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("VertAlign", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("VertAlign", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::SetFont(int sRow, int sCol, TFont *F)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Cells", sRow, sCol);
      cell.OlePropertyGet("Font").OlePropertySet("Name", F->Name.c_str()); //��� ������
      cell.OlePropertyGet("Font").OlePropertySet("Size", F->Size ); //������ ������
      cell.OlePropertyGet("Font").OlePropertySet("Color", F->Color); // ���� ������
      cell.OlePropertyGet("Font").OlePropertySet("Bold", F->Style.Contains(fsBold)); //;������
      cell.OlePropertyGet("Font").OlePropertySet("Italic", F->Style.Contains(fsItalic)); //������
      cell.OlePropertyGet("Font").OlePropertySet("Strikethrough", F->Style.Contains(fsStrikeOut)); //�����������
      cell.OlePropertyGet("Font").OlePropertySet("Underline", F->Style.Contains(fsUnderline));//������������
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetFont", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetFont", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetFont", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);

/*
//������� ������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Superscript",true);
//������ ������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Subscript",true);
//��� �����
vVarCell.OlePropertyGet("Font").
OlePropertySet("OutlineFont",true);
//C �����
vVarCell.OlePropertyGet("Font").
OlePropertySet("Shadow",true);
//������������ ��������� ������ �� ��������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",2);
//������������ ������� ������ �� ��������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",-4119);
//������������ ��������� ������ �� ������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",4);
//������������ ������� ������ �� ��������
vVarCell.OlePropertyGet("Font").
OlePropertySet("Underline",5);
����� �������� ��������:
xlUnderlineStyleDouble = -4119,
xlUnderlineStyleDoubleAccounting = 5,
xlUnderlineStyleNone = -4142,
xlUnderlineStyleSingle = 2,
xlUnderlineStyleSingleAccounting = 4
*/
}
//------------------------------------------------------------------------------
void Excel::SetColor(int sRow, int sCol, int Color)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Cells", sRow, sCol);
      cell.OlePropertyGet("Interior").OlePropertySet("Color", Color);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetColor", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetColor", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetColor", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::SetColor(char* Range, int Color)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Range", Range);
      cell.OlePropertyGet("Interior").OlePropertySet("Color", Color);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetColor_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetColor_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetColor_", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::SetFrame(int sRow, int sCol, int gde, int line_style, int weight,int color)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Cells", sRow, sCol);
      cell.OlePropertyGet("Borders", gde).OlePropertySet("LineStyle", line_style);
      cell.OlePropertyGet("Borders", gde).OlePropertySet("Weight", weight);
      cell.OlePropertyGet("Borders", gde).OlePropertySet("Color", color);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetFrame", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetFrame", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetFrame", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//-----------------------------------------------------------------------------------------------
void Excel::SetFrameCellss(int sRow, int sCol, int line_style, int weight,int color)
{
   SetFrame(sRow, sCol, xlEdgeRight,  line_style, weight,color);
   SetFrame(sRow, sCol, xlEdgeLeft,   line_style, weight, color);
   SetFrame(sRow, sCol, xlEdgeTop,    line_style, weight, color);
   SetFrame(sRow, sCol, xlEdgeBottom, line_style, weight, color);
}
//---------------------------------------------------------------------------
void Excel::SetFrame(char* Range, int gde, int line_style, int weight, int color)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Range", Range);
      cell.OlePropertyGet("Borders", gde).OlePropertySet("LineStyle", line_style);
      cell.OlePropertyGet("Borders", gde).OlePropertySet("Weight", weight);
      cell.OlePropertyGet("Borders", gde).OlePropertySet("Color", color);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetFrame_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetFrame_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetFrame_", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
AnsiString Excel::GetRange(int start_row, int start_col, int end_row, int end_col)
{
   AnsiString return_str(""), startr(""), endr("");
   div_t start_c = div(start_col, 27);
   while(start_c.quot > 0){
      if(start_c.rem != 0) startr += char(65 + start_c.rem);
      else startr += char(65);
      start_c = div(start_c.quot, 27);
   }

   if(start_c.rem != 0) startr += char(64 + start_c.rem);
   for(int i = startr.Length(); i > 0; i--) return_str += startr[i];
   return_str += (IntToStr(start_row) + ":");

   div_t end_c = div(end_col, 27);
   while(end_c.quot > 0){
      if(end_c.rem != 0) endr += char(65 + end_c.rem);
      else endr += char(65);
      end_c = div(end_c.quot, 27);
   }
   if(end_c.rem != 0) endr += char(64 + end_c.rem);

   for(int i = endr.Length(); i > 0; i--) return_str += endr[i];
   return_str += IntToStr(end_row);

   return return_str;
}
//-----------------------------------------------------------------------------
void Excel::SetOrientation(int sRow, int sCol, int Angle)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Cells", sRow, sCol);
      cell.OlePropertySet("Orientation",Angle);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetOrientation", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetOrientation", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetOrientation", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::SetOrientation(char* Range, int Angle)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Range", Range);
      cell.OlePropertySet("Orientation", Angle);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetOrientation_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetOrientation_", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetOrientation_", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::AutoFit(int sRow, int sCol)
{
   if(perr) perr->Reset();
   try{
      Variant cell = App.OlePropertyGet("Cells", sRow, sCol);
      cell.OlePropertyGet("EntireColumn").OleProcedure("AutoFit");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("AutoFit", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("AutoFit", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("AutoFit", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------
void Excel::AutoFit(int sRow)
{
   if(perr) perr->Reset();
   try{
      Variant row = App.OlePropertyGet("Cells", sRow, sRow);
      row.OlePropertyGet("EntireRow").OleProcedure("AutoFit");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("AutoFit", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("AutoFit", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("AutoFit", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//------------------------------------------------------------------------------

void Excel::Close()
{
   if(perr) perr->Reset();
   try{
      App.OlePropertyGet("WorkBooks", 1).OleProcedure("Close");
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("Close", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("Close", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("Close", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog){
      plog->Write(typeid(*this).name(), *perr);
      ShowMessage("�� �������� ���� ������� Excel.");
   }
}
//------------------------------------------------------------------------------
void Excel::SaveAs(AnsiString FileName)
{
   if(perr) perr->Reset();
   try{
      App.OlePropertyGet("WorkBooks", 1).OleProcedure("SaveAs", FileName.c_str());
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SaveAs", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SaveAs", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SaveAs", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog){
      plog->Write(typeid(*this).name(), *perr);
      ShowMessage("�� ������� ���������! ��������� ���� :)");
   }
}
//--------------------------------------------------------------------------------
TRect Excel::GetActiverange2()
{
   TRect r;



try{
AnsiString Rnge="";
Rnge=Sh.OlePropertyGet("UsedRange").OlePropertyGet("Address");
Rnge=StringReplace(Rnge,"$","",TReplaceFlags()<<rfReplaceAll);
if(Rnge.Pos(":")==0)
  Rnge=Rnge+":"+Rnge;


int  stolbci=0;
int count_str=0;
AnsiString part1="",part2="",part1_inv="",part2_inv="";
part1=Rnge.SubString(1,Rnge.Pos(":")-1);
part2=Rnge.SubString(Rnge.Pos(":")+1,Rnge.Length());

Set <char,'0','9'> number;
number<<'0'<<'1'<<'2'<<'3'<<'4'<<'5'<<'6'<<'7'<<'8'<<'9';
int index=0;
for(int i=1; i<=part1.Length();i++)
 if(number.Contains(part1[i]))
     {index=i; break;}
part1_inv=strrev(part1.SubString(1,index-1).c_str());
for(int i=1; i<=part1_inv.Length();i++)
{
  int temp=(int) part1_inv[i];
  if(temp>=65 && temp<=90) //??????
    {
      stolbci=stolbci+ pow(26,(i-1))*(temp-64);
    }
   if(temp>=48 && temp <58 ) //?????
        break;
}
 r.top=StrToInt(part1.SubString(index,part1.Length()));
 r.left=stolbci;



stolbci=0;
count_str=0;

index=0;
for(int i=1; i<=part2.Length();i++)
 if(number.Contains(part2[i]))
     {index=i; break;}
part2_inv=strrev(part2.SubString(1,index-1).c_str());




for(int i=1; i<=part2_inv.Length();i++)
{
  int temp=(int) part2_inv[i];

   if(temp>=65 && temp<=90) //??????
    {
     stolbci=stolbci+ pow(26,(i-1))*(temp-64);
    }


   if(temp>=48 && temp <58 ) //?????
    break;
}
 r.bottom=StrToInt(part2.SubString(index,part2.Length()));
r.right=stolbci;
}
catch(...){ShowMessage("�� ������� ������� ������������ �������");}
return r;
}
//---------------------------------------------------------------------------
void Excel::SetCheckBoxVisible()
{
   if(perr) perr->Reset();
   try{
      int count = Sh.OlePropertyGet("CheckBoxes").OlePropertyGet("Count");
      for(int i = 1; i <= count; i++)
         Sh.OlePropertyGet("CheckBoxes", i).OlePropertySet("Value", 1);
   }
   catch(EOleSysError& ex){
      if(perr) (*perr)("SetCheckBoxVisible", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(Exception& ex){
      if(perr) (*perr)("SetCheckBoxVisible", typeid(ex).name(), ex.Message.c_str(), 1);
   }
   catch(...){
      if(perr) (*perr)("SetCheckBoxVisible", "FATAL ERROR", "unknown", 1);
   }
   if(perr && perr->err && plog) plog->Write(typeid(*this).name(), *perr);
}
//--------------------------------------------------------------------------------
Variant __fastcall Excel::GetExcelCell(int c1,int c2)
{
 try {
    Variant  cur = Sh.OlePropertyGet("Cells", c1,c2);
   return (Variant)cur.OlePropertyGet("Value");
  } catch(...) { return ""; }


}
#pragma package(smart_init)
