//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Progress_Form_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sGauge"
#pragma link "sSkinProvider"
#pragma resource "*.dfm"
TProgress_Form *Progress_Form;
//---------------------------------------------------------------------------
__fastcall TProgress_Form::TProgress_Form(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
ProgressForm::ProgressForm(TComponent* owner, int init_val)
{
   pf = new TProgress_Form(owner);
   pf->sGauge1->MaxValue = init_val;
   pf->sGauge1->Progress = 0;
   pf->Show();
}
//---------------------------------------------------------------------------
ProgressForm::~ProgressForm()
{
   delete pf;  pf = 0;
}
//---------------------------------------------------------------------------
void ProgressForm::operator++()
{
   pf->sGauge1->Progress++;
}
//---------------------------------------------------------------------------

