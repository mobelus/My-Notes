//---------------------------------------------------------------------------
#ifndef DUFormCH
#define DUFormCH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Mask.hpp>
#include "sCurrEdit.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sSkinProvider.hpp"
#include "ToolEdit.hpp"
#include "sTooledit.hpp"
//---------------------------------------------------------------------------

#define IMPLEMENT_METHOD 1

class TDUForm : public TForm
{
__published:	// IDE-managed Components
   TButton *Button1;
   TButton *Button2;
   TsCalcEdit *v1;
   TsCalcEdit *v2;
   TsDateEdit *DateEdit1;
   TsDateEdit *DateEdit2;
   TComboBox *CBBM;
        TEdit *ELastName;
        TLabel *Label1;
        TEdit *EFirstName;
        TLabel *Label2;
        TEdit *ESecondName;
        TLabel *Label3;
        TGroupBox *GroupBox1;
        TEdit *EVUSer;
        TLabel *Label4;
        TLabel *Label6;
        TEdit *EVUNum;
        TLabel *Label5;
   TGroupBox *GBPrevDopush;
        TEdit *EPrevLastName;
        TEdit *EPrevFirstName;
        TEdit *EPrevSecondName;
        TGroupBox *GroupBoxPrev1;
        TEdit *EVUPrevSer;
        TEdit *EVUPrevNum;
        TsDateEdit *DatePrevVUStart;
        TsDateEdit *DatePrevVUEnd;
   TButton *BtnKBM;
    TLabel *labPrevVUInstruction;
    TCheckBox *cboxFioNotChanged;
    TCheckBox *cboxVUNotChanged;
    TCheckBox *cboxCurrentVU;
   void __fastcall Button2Click(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall DateEdit1Change(TObject *Sender);
   void __fastcall DateEdit2Change(TObject *Sender);
   void __fastcall DateEdit2Exit(TObject *Sender);
   void __fastcall DateEdit2AcceptDate(TObject *Sender, TDateTime &aDate, bool &CanAccept);
   void __fastcall DateEdit1Exit(TObject *Sender);
    void __fastcall EVUSerKeyPress(TObject *Sender, char &Key);
    void __fastcall EVUSerExit(TObject *Sender);
    void __fastcall BtnKBMClick(TObject *Sender);
    void __fastcall cboxFioNotChangedClick(TObject *Sender);
    void __fastcall cboxVUNotChangedClick(TObject *Sender);
    void __fastcall cboxCurrentVUClick(TObject *Sender);

public:
   //*
   void testRSA();

   int getPressedBtn();

   void setPrevDopushLoaded();

   void setPressedBtnAdd(int _indx);
   void setPressedBtnEdit(int _indx);
   void setPressedBtnDel(int _indx);
   //*/

private:
   void disablePrevGroupBox();

   TDateTime today;
   int pressedBtn;
   int m_indx;
   bool isLoadedPrevDopush;

   enum
   { BTN_PRESSED_ADD  = 1,
     BTN_PRESSED_EDIT = 2,
     BTN_PRESSED_DEL  = 3,
   };

public:		// User declarations
   __fastcall TDUForm(TComponent* Owner);
   bool TypeTS_A;
   bool pereoformlenie;
};
//---------------------------------------------------------------------------
extern PACKAGE TDUForm *DUForm;
//---------------------------------------------------------------------------
#endif
