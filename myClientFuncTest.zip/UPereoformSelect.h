//---------------------------------------------------------------------------

#ifndef UPereoformSelectH
#define UPereoformSelectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "Tmops_api.h"
#include <CheckLst.hpp>
//---------------------------------------------------------------------------
class TFPereoformSelect : public TForm
{
__published:	// IDE-managed Components
        TRadioGroup *RadioGroup1;
        TButton *Button1;
        TButton *Button2;
        TLabel *Label1;
        TCheckListBox *CLBPereoform;
        void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
        mops_api_019* m_api;
        int res;

public:		// User declarations
        __fastcall TFPereoformSelect(TComponent* Owner,mops_api_019* _m_api);
        AnsiString id_pereoform;
};
//---------------------------------------------------------------------------
extern PACKAGE TFPereoformSelect *FPereoformSelect;
//---------------------------------------------------------------------------
#endif
