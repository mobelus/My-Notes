
This directory contain resource files for various languages.
You can replace original resource files by the files that 
is placed in corresponding language directory.


If you want to participate in EhLib supported languages,
you can change resource files for new language and send them to
me (dmitryb@farpsot.com). Include in the message
the Language name, 'Supported by' info (your name), Contact info (your e-mail).

I will include these files to EhLib archive and add info about you in
below list. Participating in EhLib supported languages you should
take in attention that if in new versions of EhLib the resource files
will be changed I will send you request to change resource files for
corresponding language to support new EhLib.

Your resource files must be compatible with all versions of Delphi and BCB
with which compatible EhLib. To ensure it you can create new resource files
under lowest version of Delphi with which compatible EhLib. Current lowest
version of Delphi with which compatible EhLib is Delphi version 4.


Language    Directory Name    Supported by            Contact info

English     English           Dmitry V. Bolshakov     dmitryb@farpsot.com
Russian     Russian           Dmitry V. Bolshakov     dmitryb@farpsot.com
Spanish     Spanish           Alberto Garcia Alvarez  tim@telecable.es
German      German            Hartmut Festing         h.festing@edv-service-festing.de
French      French            Tanguy KERNOA           tanguy@menlog.com
Ukrainian   Ukrainian         Sergiy Sekela           Dr_Web@ukr.net
Japanese    Japanese          Tomio Suzuki            suzuki@sslabo.com, sslabo@mba.nifty.com, systemlabo.suzuki@nifty.com