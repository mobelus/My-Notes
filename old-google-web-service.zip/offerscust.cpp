//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "offerscust.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "frxClass"
#pragma link "frxPreview"
#pragma link "frxDBSet"
#pragma link "frxExportPDF"
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma resource "*.dfm"
TframeOffCust *frameOffCust;
//---------------------------------------------------------------------------
__fastcall TframeOffCust::TframeOffCust(TComponent* Owner) : TFrame(Owner){}
//---------------------------------------------------------------------------
void __fastcall TframeOffCust::printButtonClick(TObject *Sender)
{
   frxForClient->Print();  
}
//---------------------------------------------------------------------------
void __fastcall TframeOffCust::btnExportClick(TObject *Sender)
{
   if(sdPDF->Execute()){
      PDFExport->FileName = sdPDF->FileName;
      frxForClient->Export(PDFExport);
   }
}
//---------------------------------------------------------------------------

