//---------------------------------------------------------------------------

#include <vcl.h>
#include <DateUtils.hpp>
#pragma hdrstop
#include "DopUprFormC.h"
//#include "tools.h"
#include "functions.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sCurrEdit"
#pragma link "sCustomComboEdit"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma resource "*.dfm"
TDopUprForm *DopUprForm;
//---------------------------------------------------------------------------
__fastcall TDopUprForm::TDopUprForm(TComponent* Owner)
        : TForm(Owner)
{
   curr_year = YearOf(Date());
}
//---------------------------------------------------------------------------
void __fastcall TDopUprForm::btnCancelClick(TObject *Sender)
{
    ModalResult = mrCancel;
}
//---------------------------------------------------------------------------
void __fastcall TDopUprForm::btnAddClick(TObject *Sender)
{
   if(editAge->Value <= 0 || editStag->Value < 0){
      MessageDlg("������� ������� � ����", mtError, TMsgDlgButtons() << mbOK, 0);
      return;
   }
   if(editAge->Value < 18 || editAge->Value > 100){
      MessageDlg("��������, ������ � ��������", mtError, TMsgDlgButtons() << mbOK, 0);
      return;
   }
   if(editAge->Value - editStag->Value < 18){
      MessageDlg("����� ��������� �������/���� �������� ������������", mtError, TMsgDlgButtons() << mbOK, 0);
      return;
   }

   ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TDopUprForm::dateAgeChange(TObject *Sender)
{
   editAge->OnChange = 0;
   editAge->Value = CalcYears(dateAge->Date, Date());
   editAge->OnChange = editAgeChange;
}
//---------------------------------------------------------------------------
void __fastcall TDopUprForm::dateStagChange(TObject *Sender)
{
   editStag->OnChange = 0;
   editStag->Value = CalcYears(dateStag->Date, Date());
   editStag->OnChange = editStagChange;
}
//---------------------------------------------------------------------------
void __fastcall TDopUprForm::editAgeChange(TObject *Sender)
{
   dateAge->OnChange = 0;
   dateAge->Date = TDateTime(curr_year - editAge->Value, 1, 1);
   dateAge->OnChange = dateAgeChange;
}
//---------------------------------------------------------------------------
void __fastcall TDopUprForm::editStagChange(TObject *Sender)
{
   dateStag->OnChange = 0;
   dateStag->Date = TDateTime(curr_year - editStag->Value, 1, 1);
   dateStag->OnChange = dateStagChange;
}
//---------------------------------------------------------------------------

