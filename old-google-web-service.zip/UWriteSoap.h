//---------------------------------------------------------------------------

#ifndef UWriteSoapH
#define UWriteSoapH

//---------------------------------------------------------------------------
#define NO_WIN32_LEAN_AND_MEAN


#include <vcl.h>
//#include <shlobj.h>
#include "functions.h"
#include "FastStrReplaceUnit.hpp"

//#include "Tmops_api.h"


//---------------------------------------------------------------------------

namespace NS_KaskoProxyService {

using namespace Faststrreplaceunit;

const TReplaceFlags rff(TReplaceFlags() << rfReplaceAll);

/*AnsiString GetPathDesktopUser()
{
   AnsiString desktop_folder("");

   LPITEMIDLIST pidl;
   LPMALLOC pShellMalloc;
   char szDir[MAX_PATH];

   if(SUCCEEDED(SHGetMalloc(&pShellMalloc))){
	  if(SUCCEEDED(SHGetSpecialFolderLocation(0, CSIDL_DESKTOPDIRECTORY, &pidl))){
		 if(SHGetPathFromIDList(pidl, szDir)) desktop_folder = IncludeTrailingBackslash(szDir);
		 pShellMalloc->Free(pidl);
	  }
	  pShellMalloc->Release();
   }

   return desktop_folder;
}      */
//---------------------------------------------------------------------------
class rio_be{

public:
   void __fastcall HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest);
   void __fastcall HTTPRIOAfterExecute(const AnsiString MethodName, TStream *SOAPResponse);
};
//---------------------------------------------------------------------------
//*
void __fastcall rio_be::HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest)
{
   //SOAPRequest = StringReplace(SOAPRequest, "<?xml version=\"1.0\"?>", "<?xml version=\"1.0\" encoding=\"WINDOWS-1251\"?>", TReplaceFlags() << rfReplaceAll);

   SOAPRequest = StringReplace(SOAPRequest, "NULL", "nil", rff);
   SOAPRequest = StringReplace(SOAPRequest, "<ReservationIds>", "<ReservationIds xmlns:d4p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);
   SOAPRequest = StringReplace(SOAPRequest, "<AlarmIds>", "<AlarmIds xmlns:d4p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);
   SOAPRequest = StringReplace(SOAPRequest, "<VehicleIds>", "<VehicleIds xmlns:d2p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);

   if(MethodName == AnsiString("PrintULAddAgreement")) SOAPRequest = StringReplace(SOAPRequest, "string", "d2p1:string", rff);
   else SOAPRequest = StringReplace(SOAPRequest, "string", "d4p1:string", rff);

   if(MethodName == AnsiString("PrintAutoProtectionPolicy") || MethodName == AnsiString("PrintCalculationSheet") || MethodName == AnsiString("PrintKaskoFLSpecial") || MethodName == AnsiString("PrintULAddAgreement"))
   {
      SOAPRequest = StringReplace(SOAPRequest, "<ContractId>", "<ContractId xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
      SOAPRequest = StringReplace(SOAPRequest, "<AtypicalNumber>", "<AtypicalNumber xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
      SOAPRequest = StringReplace(SOAPRequest, "<Draft>", "<Draft xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
   }

   TStringList *sl = new TStringList();
   sl->Text = SOAPRequest;
   sl->Text = StringReplace(sl->Text, "<UserName>apo</UserName>", "", rff);
   sl->Text = StringReplace(sl->Text, "<Password>popa</Password>", "", rff);
   m_api->Internal_SetLastError("������ � ��� - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);

   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_req.xml");
   delete sl;

/*
   SOAPRequest = FastStringReplace(SOAPRequest, "NULL", "nil", rff);
   SOAPRequest = FastStringReplace(SOAPRequest, "<ReservationIds>", "<ReservationIds xmlns:d4p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);
   SOAPRequest = FastStringReplace(SOAPRequest, "<AlarmIds>", "<AlarmIds xmlns:d4p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);
   SOAPRequest = FastStringReplace(SOAPRequest, "<VehicleIds>", "<VehicleIds xmlns:d2p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);

   if(MethodName == AnsiString("PrintULAddAgreement")) SOAPRequest = FastStringReplace(SOAPRequest, "string", "d2p1:string", rff);
   else SOAPRequest = FastStringReplace(SOAPRequest, "string", "d4p1:string", rff);

   if(MethodName == AnsiString("PrintAutoProtectionPolicy") || MethodName == AnsiString("PrintCalculationSheet") || MethodName == AnsiString("PrintKaskoFLSpecial") || MethodName == AnsiString("PrintULAddAgreement"))
   {
      SOAPRequest = FastStringReplace(SOAPRequest, "<ContractId>", "<ContractId xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
      SOAPRequest = FastStringReplace(SOAPRequest, "<AtypicalNumber>", "<AtypicalNumber xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
      SOAPRequest = FastStringReplace(SOAPRequest, "<Draft>", "<Draft xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
   }

   TStringList *sl = new TStringList();
   sl->Text = SOAPRequest;
   sl->Text = FastStringReplace(sl->Text, "<UserName>apo</UserName>", "", rff);
   sl->Text = FastStringReplace(sl->Text, "<Password>popa</Password>", "", rff);
   m_api->Internal_SetLastError("������ � ��� - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);

   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_req.xml");
   delete sl;
*/
}
//*/
//---------------------------------------------------------------------------
void __fastcall rio_be::HTTPRIOAfterExecute(const AnsiString MethodName, TStream *SOAPResponse)
{
   SOAPResponse->Position = 0;
   TStringList *sl = new TStringList();
   sl->LoadFromStream(SOAPResponse);

   m_api->Internal_SetLastError("����� ��� - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);

   //int sl_count = sl->Count;
   //AnsiString sl_str;
   //for (int i = 0, cnt = sl->Count; i < cnt; ++i)
   //	   sl_str += sl->Strings[i];

   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_resp.xml");
   delete sl;
}
//---------------------------------------------------------------------------
}//;

//---------------------------------------------------------------------------
namespace NS_InspectionProxyService {

using namespace Faststrreplaceunit;

//const TReplaceFlags rff(TReplaceFlags() << rfReplaceAll);

/*AnsiString GetPathDesktopUser()
{
   AnsiString desktop_folder("");

   LPITEMIDLIST pidl;
   LPMALLOC pShellMalloc;
   char szDir[MAX_PATH];

   if(SUCCEEDED(SHGetMalloc(&pShellMalloc))){
	  if(SUCCEEDED(SHGetSpecialFolderLocation(0, CSIDL_DESKTOPDIRECTORY, &pidl))){
		 if(SHGetPathFromIDList(pidl, szDir)) desktop_folder = IncludeTrailingBackslash(szDir);
		 pShellMalloc->Free(pidl);
	  }
	  pShellMalloc->Release();
   }

   return desktop_folder;
}                        */
//---------------------------------------------------------------------------
class rio_be{

public:
   void __fastcall HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest);
   void __fastcall HTTPRIOAfterExecute(const AnsiString MethodName, TStream *SOAPResponse);
};

void __fastcall rio_be::HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest)
{
   TStringList *sl = new TStringList();
   sl->Text = SOAPRequest;
   sl->Text = FastStringReplace(sl->Text, "<UserName>apo</UserName>", "", rf);
   sl->Text = FastStringReplace(sl->Text, "<Password>popa</Password>", "", rf);
   m_api->Internal_SetLastError("������ � ���(�������) - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);
   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_req.xml");
   delete sl;
}
//---------------------------------------------------------------------------
void __fastcall rio_be::HTTPRIOAfterExecute(const AnsiString MethodName, TStream *SOAPResponse)
{
   SOAPResponse->Position = 0;
   TStringList *sl = new TStringList();
   sl->LoadFromStream(SOAPResponse);
   
   m_api->Internal_SetLastError("����� ���(�������) - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);

   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_resp.xml");
   delete sl;
}
//---------------------------------------------------------------------------
};

#endif
