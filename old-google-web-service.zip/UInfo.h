//---------------------------------------------------------------------------

#ifndef UInfoH
#define UInfoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TfrmInfo : public TForm
{
__published:	// IDE-managed Components
   TBitBtn *BitBtn1;
   TBitBtn *BitBtn2;
   TLabel *Label1;
   TLabel *Label2;
private:	// User declarations
public:		// User declarations
   __fastcall TfrmInfo(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInfo *frmInfo;
//---------------------------------------------------------------------------
#endif
