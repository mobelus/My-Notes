//---------------------------------------------------------------------------
#define NO_WIN32_LEAN_AND_MEAN
#include <SysUtils.hpp>
#include <shlobj.h>
#include <math.h>
#include <DateUtils.hpp>

#include <stdio.h> // ??????? ???????????? ?????-??????
//#include <system.hpp> // ??? ????????????? CharToOem();

#include "frxDesgn.hpp"
#include "frxClass.hpp"
#include "frxDBSet.hpp"

//#include "newcalc.h"
//#include "oldcalc.h"
#include "offerscust.h"
#include "itogi.h"
#include "mainwinfc.h"
#include "anderrpanel.h"
#include "XML_progress_form_c.h"
#include "UReissCalc.h"
#include "UInfo.h"
#include "UDubl.h"
#include "UReportParams.h"
#include "UTypeDogovor.h"
#include "UInfoRast.h"
//#include "tools.h"
#include "Globals.h"
#include "constants.h"
#include "functions.h"
//#include "structures.h"

//SHOW_NUMBER("CALC_ID that we are working with", cur_calc_id);

//---------------------------------------------------------------------------
#pragma hdrstop
//---------------------------------------------------------------------------
extern "C" void __declspec(dllexport) Create_Frames(TList* frames, TStringList* frames_names);
extern "C" int  __declspec(dllexport) Save_Frame(void* Frame, long id_calc);
extern "C" int  __declspec(dllexport) Save_Frames(TList* frames, long id_calc);
extern "C" int  __declspec(dllexport) Load_Frame(void* Frame, long id_calc);
extern "C" int  __declspec(dllexport) Load_Frames(TList* frames, long id_calc);
extern "C" void __declspec(dllexport) Get_Main_Grid_Tables(TStringList* Tables);
extern "C" void __declspec(dllexport) Get_Module_Print_Forms_Names(TStringList* form_names);
extern "C" int  __declspec(dllexport) Print_Form(AnsiString form_name,long id_calc);
extern "C" int  __declspec(dllexport) Universal_Func(AnsiString command, void* lparam, void* hparam);
extern "C" void __declspec(dllexport) Init_API(void* _Mops_Api);
extern "C" void __declspec(dllexport) Get_Main_Menu(TMainMenu** M_Menu);
extern "C" void __declspec(dllexport) OnMenuClick(TObject *Sender);
extern "C" int  __declspec(dllexport) On_User_Copy_Paste(AnsiString &XML, bool Copy_Flag);
extern "C" int  __declspec(dllexport) OnFastReport(AnsiString Form_Name, int form_type/*0 - ����� 1 - �����*/, long calc_id, int action/*0 - ������, 1 - ������, 2 - ��������*/, TList *data_sets);
//---------------------------------------------------------------------------
mops_api_028 *m_api;

SkkQuery skkq;

int res;
static int nCreateFrames = 1;

bool PreViewFlag, is_message(true), to_print(false);

TMenuItem *mp_1(0), *mp_2_1(0), *mp_3(0), *mp_4_1(0), *mp_7(0);
AnsiString desktop_folder, ander_fio, ander_email;

PersonInfo pi[2], pm[16];
//TSInfo tsi;
VehicleInfo tsi;
Dogovor_Info di;

//---------------------------------------------------------------------------
void ResetData()
{
   for(int i = 0; i < 2;  ++i){ pi[0].status = 0; pi[i].Reset(); }
   for(int i = 0; i < 16; ++i) pm[i].Reset();
   tsi.Reset(); di.Reset();
}
//---------------------------------------------------------------------------
void GetPathDesktopUser()
{
   LPITEMIDLIST pidl;
   LPMALLOC pShellMalloc;
   char szDir[MAX_PATH];

   if(SUCCEEDED(SHGetMalloc(&pShellMalloc))){
      if(SUCCEEDED(SHGetSpecialFolderLocation(0, CSIDL_DESKTOPDIRECTORY, &pidl))){
         if(SHGetPathFromIDList(pidl, szDir)) desktop_folder = IncludeTrailingBackslash(szDir);
         pShellMalloc->Free(pidl);
      }
      pShellMalloc->Release();
   }
}
//---------------------------------------------------------------------------
void AddOpfAndLicense(TList *data_sets)
{
   data_sets->Add(m_api->dbGetCursor(res, " select top 1 "
                                          "(select top 1 rgs_value from gl_dict_rgs_lnz_opf where type_id=1 and (product_name='�����' or product_category='���') and date()>=start_date and date()<=end_date order by product_name desc) as opf, "
                                          "(select top 1 rgs_value from gl_dict_rgs_lnz_opf where type_id=2 and (product_name='�����' or product_category='���') and  date()>=start_date and date()<=end_date order by product_name desc) as license, "
                                          "(select top 1 rgs_value from gl_dict_rgs_lnz_opf where type_id=2  and product_category='��������' and date()>=start_date and date()<=end_date) as license_med "
                                          "from gl_dict_rgs_lnz_opf"));
}
//------------------------------------------------------------------------------
void SaveAnketa(const int calc_id, const int discount)
{
   Anketa a, a_ret;
   a.Init();
   GenerateResponseList(a_ret, a, discount);

   TADOQuery *q_ank = m_api->dbGetCursor(res, "select * from casco_anketa where calc_id=" + IntToStr(calc_id), 0, 1);
   if(q_ank->IsEmpty()) q_ank->Insert();
   q_ank->Edit();
   q_ank->FieldByName("calc_id")->Value = calc_id;
   for(int i = 0; i < 11; ++i) q_ank->FieldByName("q" + IntToStr(a_ret[i].number + 1))->Value = a_ret[i].response[0];
   q_ank->Post();
   m_api->dbCloseCursor(res, q_ank);
}
//---------------------------------------------------------------------------
void SaveMemoToNode(const int m_id, _di_IXMLNode node)
{
   int memo_id = m_id;
   AnsiString memo_text("");
   m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, true, "casco_memo");
   node->Text = StringReplace(memo_text, "\r\n", ";", rf);
}
//---------------------------------------------------------------------------
void SaveNodeToMemo(_di_IXMLNode node, TADOQuery* q, const AnsiString& fieldname)
{
   int memo_id(0);
   AnsiString st = StringReplace(NodeToStr(node), ";", "\r\n", rf);
   if(!st.IsEmpty()) m_api->dbReadWriteInternalMemo(res, st, memo_id, false, "casco_memo");
   q->FieldByName(fieldname)->Value = memo_id;
}
//---------------------------------------------------------------------------
void FillNode(_di_IXMLNode node, const AnsiString& attrib_text, const AnsiString& text)
{
   node->Text = text;
   node->Attributes["code"] = attrib_text;
}
//---------------------------------------------------------------------------
void XML_Save_Query_Row_APO(_di_IXMLNode node, TADOQuery* q)
{
   _di_IXMLNode calc = node->AddChild("casco_calc"), person = node->AddChild("casco_persons"), ad_device, child_node, node_k56, node_permit, node_persons_r, ad_device_r, reasons;
   AnsiString memo_text;
   int calc_id = q->FieldByName("calc_id")->AsInteger, memo_id;

   m_api->XML_Save_Query_Row(res, calc, q, "EXCLUDE#calc_id#");

   SaveMemoToNode(q->FieldByName("comm_sale_mid")->AsInteger,    calc->AddChild("comm_sale"));
   SaveMemoToNode(q->FieldByName("comm_anderr_mid")->AsInteger,  calc->AddChild("comm_anderr"));
   SaveMemoToNode(q->FieldByName("anderrchange_mid")->AsInteger, calc->AddChild("anderrchange"));

   TADOQuery *q_persons = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_persons->IsEmpty()){
      for(q_persons->First(); !q_persons->Eof; q_persons->Next()){
         child_node = person->AddChild("casco_person");
         m_api->XML_Save_Query_Row(res, child_node, q_persons, "EXCLUDE#calc_id#");
         SaveMemoToNode(q_persons->FieldByName("addr_mid")->AsInteger, child_node->AddChild("kladr"));
      }
   }
   m_api->dbCloseCursor(res, q_persons);

   TADOQuery* qad = m_api->dbGetCursor(res, "select * from casco_devices where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!qad->IsEmpty()){
      ad_device = node->AddChild("casco_devices");
      for(qad->First(); !qad->Eof; qad->Next()) m_api->XML_Save_Query_Row(res, ad_device->AddChild("additional_device"), qad, "EXCLUDE#calc_id#");
   }
   m_api->dbCloseCursor(res, qad);

   TADOQuery* q_k56 = m_api->dbGetCursor(res, "select * from casco_dogovors_k5_k6 where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_k56->IsEmpty()){
      node_k56 = node->AddChild("casco_dogovors_k5_k6");
      for(q_k56->First(); !q_k56->Eof; q_k56->Next()) m_api->XML_Save_Query_Row(res, node_k56->AddChild("dogovor_k5_k6"), q_k56, "EXCLUDE#calc_id#");
   }
   m_api->dbCloseCursor(res, q_k56);

   TADOQuery *q_permit = m_api->dbGetCursor(res, "select * from casco_permitted where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_permit->IsEmpty()){
      node_permit = node->AddChild("casco_permitteds");
      for(q_permit->First(); !q_permit->Eof; q_permit->Next()) m_api->XML_Save_Query_Row(res, node_permit->AddChild("casco_permitted"), q_permit, "EXCLUDE#calc_id#");
   }
   m_api->dbCloseCursor(res, q_permit);

   TADOQuery *q_calc_r = m_api->dbGetCursor(res, "select * from casco_calc_r where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_calc_r->IsEmpty()) m_api->XML_Save_Query_Row(res, node->AddChild("casco_calc_r"), q_calc_r, "EXCLUDE#calc_id#");
   m_api->dbCloseCursor(res, q_calc_r);

   TADOQuery *q_persons_r = m_api->dbGetCursor(res, "select * from casco_persons_r where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_persons_r->IsEmpty()){
      node_persons_r = node->AddChild("casco_persons_r");
      for(q_persons_r->First(); !q_persons_r->Eof; q_persons_r->Next()) m_api->XML_Save_Query_Row(res, node_persons_r->AddChild("casco_person_r"), q_persons_r, "EXCLUDE#calc_id#");
   }
   m_api->dbCloseCursor(res, q_persons_r);

   TADOQuery *qad_r = m_api->dbGetCursor(res, "select * from casco_devices_r where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!qad_r->IsEmpty()){
      ad_device_r = node->AddChild("casco_devices_r");
      for(qad_r->First(); !qad_r->Eof; qad_r->Next()) m_api->XML_Save_Query_Row(res, ad_device_r->AddChild("additional_device_r"), qad_r, "EXCLUDE#calc_id#");
   }
   m_api->dbCloseCursor(res, qad_r);

   TADOQuery *q_reasons = m_api->dbGetCursor(res, "select * from casco_reiss_reasons where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_reasons->IsEmpty()){
      reasons = node->AddChild("casco_reiss_reasons");
      for(q_reasons->First(); !q_reasons->Eof; q_reasons->Next()) reasons->AddChild("casco_reiss_reason")->Text = q_reasons->FieldByName("reason_id")->AsString;
   }
   m_api->dbCloseCursor(res, q_reasons);
}
//---------------------------------------------------------------------------
AnsiString ClearStr(const AnsiString& str)
{
   AnsiString result("");

   for(int i = 1, l = str.Length(); i <= l; ++i)
      if(!str.IsDelimiter(not_filename, i)) result += str[i];

   //if(str.Length())
   return result;
}
//---------------------------------------------------------------------------
void MakeHead(_di_IXMLDocument& XMLDoc, _di_IXMLNode& node)
{
   XMLDoc->Active = false;
   XMLDoc->XML->Clear();
   XMLDoc->Active = true;
   XMLDoc->Options.Clear();
   XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;
   XMLDoc->Version       = "1.0";
   XMLDoc->Encoding      = "WINDOWS-1251";
   XMLDoc->StandAlone    = "no";
   XMLDoc->NodeIndentStr = "    ";

   _di_IXMLNode Root = XMLDoc->CreateNode("ROOT");
   XMLDoc->DocumentElement = Root;
   Root->Attributes["export_date"]    = Now().DateTimeString();
   Root->Attributes["export_date_d"]  = IntToStr((int)(Date().Val));
   Root->Attributes["Module"]         = AnsiString("CASCO");
   Root->Attributes["partner"]        = AnsiString("APO2");
   Root->Attributes["export_version"] = AnsiString("07");

   Root = XMLDoc->DocumentElement;
   node = Root->AddChild("policys");
}
//---------------------------------------------------------------------------
int XMLSave(int save_type, const AnsiString& init_dir = empty_str, AnsiString& filename = AnsiString("")) // 1 - ���; 2 - ����� � ������������; 3 - ������� ������
{
   int result(0);

   TSaveDialog *sd = new TSaveDialog(0);
   sd->Filter = "XML|*.xml";
   sd->DefaultExt = "xml";
   sd->InitialDir = init_dir;
   sd->FileName = filename;

   if(sd->Execute()){
      filename = sd->FileName;
      AnsiString sql = "select t.*,mc.guid_str,mc.status_id from casco_calc t, _mops_calcs_ mc where t.calc_id=mc.[id] and mc.deleted=0";
      switch(save_type){
         case 2: sql = sql + " and t.date_unload is NULL"; break;
         case 3: sql = sql + " and t.calc_id=" + IntToStr(m_api->dbGet_Main_Grid_Current_CalcID(res)); break;
      }
      TADOQuery *q = m_api->dbGetCursor(res, sql);

      _di_IXMLDocument XMLDoc = NewXMLDocument();
      _di_IXMLNode node;
      MakeHead(XMLDoc, node);

      TXML_Progress_Form *pr = new TXML_Progress_Form(0);
      pr->sGauge1->MinValue = 0;
      pr->sGauge1->MaxValue = q->RecordCount;
      pr->Show();
      for(q->First(); !q->Eof; q->Next(), Application->ProcessMessages()){
         m_api->dbExecuteQuery(res, "update casco_calc set date_unload=Now() where calc_id=" + q->FieldByName("calc_id")->AsString);
         XML_Save_Query_Row_APO(node->AddChild("policy"), q);
         pr->sGauge1->Progress = q->RecNo;
      }
      m_api->dbCloseCursor(res, q);
      delete pr;

      XMLDoc->SaveToFile(filename);
      delete XMLDoc;
      result = 1;
   }
   delete sd;

   return result;
}
//---------------------------------------------------------------------------
int XMLLoad(const AnsiString& xml_text)
{
   try{
      _di_IXMLDocument XMLDoc = NewXMLDocument();
      XMLDoc->Active = true;
      XMLDoc->Options.Clear();
      XMLDoc->LoadFromXML(xml_text);

      _di_IXMLNode Root = XMLDoc->DocumentElement, policy = Root->ChildNodes->FindNode("policys"), child_node, person, ad_device, node_k56, node_permit, node_calc_r, ad_device_r, person_r, reasons;
      int calc_id(0), cnt_pol = policy->ChildNodes->Count;
      for(int p = 0; p < cnt_pol; ++p){
         child_node = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_calc");
         AnsiString guid = NodeToStr(child_node->ChildNodes->FindNode("guid_str")), st;
         calc_id = m_api->dbGetIntFromQuery(res, st.sprintf("select id from _mops_calcs_ where GUID_Str='%s' and deleted=0", guid.c_str()));
         if(calc_id < 1){
            calc_id = m_api->dbInsert_Empty_Calc(res);
            m_api->dbExecuteQuery(res, st.sprintf("update _mops_calcs_ set GUID_Str='%s' where [id]=%i", guid, m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0), calc_id));
            m_api->dbExecuteQuery(res, st.sprintf("insert into casco_calc (calc_id) values(%i)", calc_id));
         }
         TADOQuery *q = m_api->dbGetCursor(res, st.sprintf("select * from casco_calc where calc_id=%i", calc_id));
         m_api->XML_Load_Query_Row(res, child_node, q, "EXCLUDE#calc_id#comm_sale_mid#comm_anderr_mid#anderrchange_mid#from_whom_sent#");
         m_api->dbCloseCursor(res, q);

         q = m_api->dbGetCursor(res, st.sprintf("select comm_sale_mid,comm_anderr_mid,anderrchange_mid,calc_id from casco_calc where calc_id=%i", calc_id), 0, 1);
         q->Edit();
         SaveNodeToMemo(child_node->ChildNodes->FindNode("comm_sale"), q, "comm_sale_mid");
         SaveNodeToMemo(child_node->ChildNodes->FindNode("comm_anderr"), q, "comm_anderr_mid");
         SaveNodeToMemo(child_node->ChildNodes->FindNode("anderrchange"), q, "anderrchange_mid");
         q->Post();
         m_api->dbCloseCursor(res, q);

         person = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_persons");
         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_persons where [calc_id]=%i", calc_id));
         TADOQuery *q_p = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + IntToStr(calc_id), 0, 1);
         for(int i = 0, cnt = person->ChildNodes->Count; i < cnt; ++i){
            child_node = person->ChildNodes->Get(i);
            q_p->Insert();
            q_p->Edit();
            for(int i = 0, fcnt = q_p->FieldCount; i < fcnt; ++i){
               if(q_p->Fields->Fields[i]->DataType == ftFloat) q_p->Fields->Fields[i]->Value = StrToFloatStr(NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName))).ToDouble();
               else q_p->Fields->Fields[i]->AsString = NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName));
            }
            q_p->FieldByName("calc_id")->Value  = calc_id;
            SaveNodeToMemo(child_node->ChildNodes->FindNode("kladr"), q_p, "addr_mid");
            q_p->Post();
         }
         m_api->dbCloseCursor(res, q_p);

         ad_device = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_devices");
         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_devices where [calc_id]=%i", calc_id));
         if(ad_device){
            for(int i = 0, cnt = ad_device->ChildNodes->Count; i < cnt; ++i){
               child_node = ad_device->ChildNodes->Get(i);
               m_api->dbExecuteQuery(res, st.sprintf("insert into casco_devices values (%i,%s,%s,%s,'%s')", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("number")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("id_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("cost_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("description")->Text).c_str()));
            }
         }

         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_dogovors_k5_k6 where [calc_id]=%i", calc_id));
         node_k56 = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_dogovors_k5_k6");
         if(node_k56){
            for(int i = 0, cnt = node_k56->ChildNodes->Count; i < cnt; ++i){
               child_node = node_k56->ChildNodes->Get(i);
               m_api->dbExecuteQuery(res, st.sprintf("insert into casco_dogovors_k5_k6 values (%i,%s,'%s',%s,'%s',%i)", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("type_person")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("type_dogovor")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("system")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("dogovor_id")->Text).c_str(),
                                                         NodeToStr(child_node->ChildNodes->FindNode("is_last")).ToIntDef(0)));
            }
         }

         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_permitted where [calc_id]=%i", calc_id));
         node_permit = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_permitteds");
         if(node_permit){
            TDateTime dt;
            for(int i = 0, cnt = node_permit->ChildNodes->Count; i < cnt; ++i){
               child_node = node_permit->ChildNodes->Get(i);
               m_api->dbExecuteQuery(res, st.sprintf("insert into casco_permitted values (%i,%s,%s,%s,%s,%s,%s)", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("permitted_number")->Text).c_str(),
                                                         (TryStrToDate(child_node->ChildNodes->FindNode("phisical_birth_date")->Text, dt) ? m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) : null_str),
                                                         (TryStrToDate(child_node->ChildNodes->FindNode("document_issue_date")->Text, dt) ? m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) : null_str),
                                                         AnsiString(child_node->ChildNodes->FindNode("age")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("experience")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("osago_ss")->Text).c_str()));
            }
         }

         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_calc_r where [calc_id]=%i", calc_id));
         m_api->dbExecuteQuery(res, st.sprintf("insert into casco_calc_r (calc_id) values(%i)", calc_id));
         node_calc_r = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_calc_r");
         if(node_calc_r){
            TADOQuery *q_r = m_api->dbGetCursor(res, st.sprintf("select * from casco_calc_r where calc_id=%i", calc_id), 0, 0);
            q_r->CursorLocation = clUseServer;
            q_r->Open();
            m_api->XML_Load_Query_Row(res, node_calc_r, q_r, "EXCLUDE#calc_id#");
            m_api->dbCloseCursor(res, q_r);

         }

         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_persons_r where [calc_id]=%i", calc_id));
         person_r = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_persons_r");
         if(person_r){
            q_p = m_api->dbGetCursor(res, "select * from casco_persons_r where calc_id=" + IntToStr(calc_id), 0, 1);
            for(int i = 0, cnt = person_r->ChildNodes->Count; i < cnt; ++i){
               child_node = person_r->ChildNodes->Get(i);
               q_p->Insert();
               q_p->Edit();
               for(int i = 0, fcnt = q_p->FieldCount; i < fcnt; ++i){
                  if(q_p->Fields->Fields[i]->DataType == ftFloat) q_p->Fields->Fields[i]->Value = StrToFloatStr(NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName))).ToDouble();
                  else q_p->Fields->Fields[i]->AsString = NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName));
               }
               q_p->FieldByName("calc_id")->Value  = calc_id;
               SaveNodeToMemo(child_node->ChildNodes->FindNode("kladr"), q_p, "addr_mid");
               q_p->Post();
            }
            m_api->dbCloseCursor(res, q_p);
         }

         ad_device_r = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_devices_r");
         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_devices_r where [calc_id]=%i", calc_id));
         if(ad_device_r){
            for(int i = 0, cnt = ad_device_r->ChildNodes->Count; i < cnt; ++i){
               child_node = ad_device_r->ChildNodes->Get(i);
               m_api->dbExecuteQuery(res, st.sprintf("insert into casco_devices_r values (%i,%s,%s,%s,'%s')", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("number")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("id_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("cost_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("description")->Text).c_str()));
            }
         }
         reasons = policy->ChildNodes->Get(p)->ChildNodes->FindNode("casco_reiss_reasons");
         m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_reiss_reasons where [calc_id]=%i", calc_id));
         if(reasons){
            for(int i = 0, cnt = reasons->ChildNodes->Count; i < cnt; ++i)
               m_api->dbExecuteQuery(res, st.sprintf("insert into casco_reiss_reasons values (%i,%i)", calc_id, AnsiString(reasons->ChildNodes->Get(i)->Text).ToIntDef(0)));
         }
      }
      delete XMLDoc;

      m_api->Module_Refresh_Main_Grid(res);

      if(cnt_pol == 1) return calc_id;
   }
   catch(Exception& ex) { ShowMessage("�������� XML APO2: " + ex.Message + "\r\n��������, �������� ������ XML");}
   catch(...) { ShowMessage("�������� XML APO2: FATAL ERROR"); }

   return 0;
}
//---------------------------------------------------------------------------
void SendToAgreement()
{
   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
   AnsiString calc_id_str = IntToStr(calc_id);

   int status_insured = m_api->dbGetIntFromQuery(res, "select status_idx from casco_calc where calc_id=" + calc_id_str);
   if(status_insured == 1){
      Application->MessageBox("��������, � ������� ������������ �������� ����������� �����, ��������� �� ������������ ����� ���2 ������!", "������������ ��������. �����!", MB_OK | MB_ICONEXCLAMATION);
      return;
   }

   int is_dta = m_api->dbGetIntFromQuery(res, "select is_data_to_agreed from casco_calc where calc_id=" + calc_id_str);
   if(is_dta){
      AnsiString no_fields("");
      m_api->dbReadWriteInternalMemo(res, no_fields, is_dta, true, "casco_memo");
      no_fields = "��� �������� �������� �� ������������ �.�. ��������� ��������� ������� � ��������� ��������� ���� � ������� ������ ��� ������:\r\n" + no_fields + "\r\n������� � ���������� ���� ������?";
      if(Application->MessageBox(no_fields.c_str(), "������������ ��������. �����!", MB_YESNO | MB_ICONEXCLAMATION) == IDYES){
         m_api->dbExecuteQuery(res, "update casco_calc set [to_print]=True where calc_id = " + calc_id_str);
         m_api->Application_Press_Button(res, "��������");
      }
      return;
   }

   AnsiString save_dir = desktop_folder + "NoStandartDogovor", filename(""),
              sql_for_filename = di.is_ander_login ? "select [filename] from casco_calc where [calc_id]="
                                                : "select (t2.[department] & ' ' & t3.[last_name]) as fn from [_mops_calcs_] t1, [_mops_polzovateli_]  t2, [casco_persons] t3 where t1.id_polzovatelya=t2.[id] and t1.[id]=t3.[calc_id] and t3.[type_person]=1 and t1.[id]=";

   bool is_ok_create;
   if(!DirectoryExists(save_dir)) is_ok_create = CreateDir(save_dir);
   else is_ok_create = true;
   if(!is_ok_create) save_dir = desktop_folder;
   filename = ClearStr(StringReplace(m_api->dbGetStringFromQuery(res, sql_for_filename + calc_id_str), space_str, underline_str, rf) +  "_" + calc_id_str);

   if(XMLSave(3, save_dir, filename)){
      if(!di.is_ander_login){
         m_api->Raschet_Set_Status_id(res, calc_id, 6);
         m_api->dbExecuteQuery(res, "update casco_calc set email_date=Now() where calc_id=" + calc_id_str);
      }
      m_api->Module_Refresh_Main_Grid(res);

      TStringList *sl = new TStringList();
      sl->Add(filename);
      m_api->send_email_using_default_client(res, empty_str, ExtractFileName(filename), empty_str, sl, true);

      if(sl->Text.Trim().ToIntDef(0) > 1) MessageBox(0, "�������� �������� � �������� ��������. ���������� � ������ ������������.", "������ �����", MB_OK | MB_ICONWARNING);

      delete sl;
   }
}
//---------------------------------------------------------------------------
void GetAgreed()
{
   try{
      AnsiString st, calc_date, filename;
      TDateTime dt = Date(), email_date(0.0);
      double d_val;
      int calc_id(0), i_val, terr_type_id, st_dg, status_id(0);

      TOpenDialog *od = new TOpenDialog(0);
      if(!od->Execute()){ delete od; return; }
       _di_IXMLDocument XMLDoc = NewXMLDocument();
      XMLDoc->Active = true;
      XMLDoc->Options.Clear();
      filename = od->FileName;
      XMLDoc->LoadFromFile(filename);
      delete od;

      _di_IXMLNode Root = XMLDoc->DocumentElement, child_node, calc_node, person, ad_device, node_k56, node_calc_r, person_r, ad_device_r, reasons;

      //�������� ����, �������� ���� ���
      /********************************/
      filename = ExtractFileName(filename); filename = filename.Delete(filename.Length() - 3,  4);

      if(Root->HasAttribute("export_date_d")) email_date = TDateTime(StrToInt(Root->Attributes["export_date_d"]));
      else{
         if(TryStrToDateTime(Root->Attributes["export_date"], dt)) email_date = (int)dt;
      }

      calc_node = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_calc");
      AnsiString guid = NodeToStr(calc_node->ChildNodes->FindNode("guid_str"));
      calc_id = m_api->dbGetIntFromQuery(res, st.sprintf("select id from _mops_calcs_ where GUID_Str='%s' and deleted=0", guid.c_str()));
      if(calc_id < 1){
         calc_id = m_api->dbInsert_Empty_Calc(res);
         m_api->dbExecuteQuery(res, st.sprintf("insert into casco_calc (calc_id) values(%i)", calc_id));
      }
      status_id = NodeToStr(calc_node->ChildNodes->FindNode("status_id")).ToIntDef(0);
      if(di.is_ander_login && (status_id < 3 || status_id > 4)) status_id = 0;

      m_api->dbExecuteQuery(res, st.sprintf("update _mops_calcs_ set GUID_Str='%s',id_polzovatelya=%i,status_id=%i,date_add=IIf(%i,date_add,Now()) where [id]=%i", guid, m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0), status_id, int(di.is_ander_login), calc_id));

      TADOQuery *q = m_api->dbGetCursor(res, st.sprintf("select * from casco_calc where calc_id=%i", calc_id), 0, 0);
      q->CursorLocation = clUseServer;
      q->Open();
      m_api->XML_Load_Query_Row(res, calc_node, q, "EXCLUDE#calc_id#comm_sale_mid#comm_anderr_mid#anderrchange_mid#from_whom_sent#filename#email_date#");
      q->Edit();
      SaveNodeToMemo(calc_node->ChildNodes->FindNode("comm_sale"), q, "comm_sale_mid");
      SaveNodeToMemo(calc_node->ChildNodes->FindNode("comm_anderr"), q, "comm_anderr_mid");
      SaveNodeToMemo(calc_node->ChildNodes->FindNode("anderrchange"), q, "anderrchange_mid");
      q->FieldByName("from_whom_sent")->Value = NodeToStr(calc_node->ChildNodes->FindNode(di.is_ander_login ? "agent" : "who_agreed"));
      q->FieldByName("filename")->Value       = filename;
      q->FieldByName(di.is_ander_login ? "email_date" : "date_unload")->Value = email_date;

      q->Post();
      m_api->dbCloseCursor(res, q);

      person = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_persons");
      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_persons where [calc_id]=%i", calc_id));
      TADOQuery *q_p = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + IntToStr(calc_id), 0, 1);
      for(int i = 0, cnt = person->ChildNodes->Count; i < cnt; ++i){
         child_node = person->ChildNodes->Get(i);
         q_p->Insert();
         q_p->Edit();
         for(int i = 0, fcnt = q_p->FieldCount; i < fcnt; ++i){
            if(q_p->Fields->Fields[i]->DataType == ftFloat) q_p->Fields->Fields[i]->Value = StrToFloatStr(NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName))).ToDouble();
            else q_p->Fields->Fields[i]->AsString = NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName));
         }
         q_p->FieldByName("calc_id")->Value  = calc_id;
         SaveNodeToMemo(child_node->ChildNodes->FindNode("kladr"), q_p, "addr_mid");
         q_p->Post();
      }
      m_api->dbCloseCursor(res, q_p);

      ad_device = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_devices");
      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_devices where [calc_id]=%i", calc_id));
      if(ad_device){
         for(int i = 0, cnt = ad_device->ChildNodes->Count; i < cnt; ++i){
            child_node = ad_device->ChildNodes->Get(i);
            m_api->dbExecuteQuery(res, st.sprintf("insert into casco_devices values (%i,%s,%s,%s,'%s')", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("number")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("id_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("cost_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("description")->Text).c_str()));
         }
      }

      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_dogovors_k5_k6 where [calc_id]=%i", calc_id));
      node_k56 = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_dogovors_k5_k6");
      if(node_k56){
         for(int i = 0, cnt = node_k56->ChildNodes->Count; i < cnt; ++i){
            child_node = node_k56->ChildNodes->Get(i);
            m_api->dbExecuteQuery(res, st.sprintf("insert into casco_dogovors_k5_k6 values (%i,%s,'%s',%s,'%s',%i)", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("type_person")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("type_dogovor")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("system")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("dogovor_id")->Text).c_str(),
                                                         NodeToStr(child_node->ChildNodes->FindNode("is_last")).ToIntDef(0)));
         }
      }

      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_calc_r where [calc_id]=%i", calc_id));
      m_api->dbExecuteQuery(res, st.sprintf("insert into casco_calc_r (calc_id) values(%i)", calc_id));
      node_calc_r = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_calc_r");
      if(node_calc_r){
         TADOQuery *q_r = m_api->dbGetCursor(res, st.sprintf("select * from casco_calc_r where calc_id=%i", calc_id), 0, 0);
         q_r->CursorLocation = clUseServer;
         q_r->Open();
         m_api->XML_Load_Query_Row(res, node_calc_r, q_r, "EXCLUDE#calc_id#");
         m_api->dbCloseCursor(res, q_r);
      }

      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_persons_r where [calc_id]=%i", calc_id));
      person_r = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_persons_r");
      if(person_r){
         q_p = m_api->dbGetCursor(res, "select * from casco_persons_r where calc_id=" + IntToStr(calc_id), 0, 1);
         for(int i = 0, cnt = person_r->ChildNodes->Count; i < cnt; ++i){
            child_node = person_r->ChildNodes->Get(i);
            q_p->Insert();
            q_p->Edit();
            for(int i = 0, fcnt = q_p->FieldCount; i < fcnt; ++i){
               if(q_p->Fields->Fields[i]->DataType == ftFloat) q_p->Fields->Fields[i]->Value = StrToFloatStr(NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName))).ToDouble();
               else q_p->Fields->Fields[i]->AsString = NodeToStr(child_node->ChildNodes->FindNode(q_p->Fields->Fields[i]->DisplayName));
            }
            q_p->FieldByName("calc_id")->Value  = calc_id;
            SaveNodeToMemo(child_node->ChildNodes->FindNode("kladr"), q_p, "addr_mid");
            q_p->Post();
         }
         m_api->dbCloseCursor(res, q_p);
      }

      ad_device_r = Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_devices_r");
      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_devices_r where [calc_id]=%i", calc_id));
      if(ad_device_r){
         for(int i = 0, cnt = ad_device_r->ChildNodes->Count; i < cnt; ++i){
            child_node = ad_device_r->ChildNodes->Get(i);
            m_api->dbExecuteQuery(res, st.sprintf("insert into casco_devices_r values (%i,%s,%s,%s,'%s',0)", calc_id,
                                                         AnsiString(child_node->ChildNodes->FindNode("number")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("id_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("cost_device")->Text).c_str(),
                                                         AnsiString(child_node->ChildNodes->FindNode("description")->Text).c_str()));
         }
      }

      reasons =  Root->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy")->ChildNodes->FindNode("casco_reiss_reasons");
      m_api->dbExecuteQuery(res, st.sprintf("delete * from casco_reiss_reasons where [calc_id]=%i", calc_id));
      if(reasons){
         for(int i = 0, cnt = reasons->ChildNodes->Count; i < cnt; ++i)
            m_api->dbExecuteQuery(res, st.sprintf("insert into casco_reiss_reasons values (%i,%i)", calc_id, AnsiString(reasons->ChildNodes->Get(i)->Text).ToIntDef(0)));
      }

      delete XMLDoc;
   }
   catch(Exception& ex) { ShowMessage("�������� UXML: " + ex.Message + "\r\n��������, �������� ������ XML"); }
   catch(...) { ShowMessage("�������� UXML: FATAL ERROR"); }
   m_api->Module_Refresh_Main_Grid(res);
}
//---------------------------------------------------------------------------
void XMLLoadOIB(const AnsiString& xml_text)
{
   try{
      AnsiString sql(""), m("m"), c("c"), attr_i("i"), attr_v("v"), chassis_number(""), body_number("");
      int drv_i(4), product_id, terr_type_id, payment_count, multidrive;
      TDateTime quotes_date = Date();

      _di_IXMLDocument XMLDoc = NewXMLDocument();
      XMLDoc->LoadFromXML(xml_text);
      XMLDoc->Active = true;

      _di_IXMLNode root_rate = XMLDoc->DocumentElement, rate_node_c(0), curr_node(0), curr_node2(0), curr_node3(0);

      int calc_id = m_api->dbInsert_Empty_Calc(res);
      m_api->dbExecuteQuery(res, sql.sprintf("insert into casco_calc (calc_id) values(%i)", calc_id));
      m_api->dbExecuteQuery(res, sql.sprintf("insert into casco_persons (calc_id,type_person,status) values(%i,1,0)", calc_id));
      m_api->dbExecuteQuery(res, sql.sprintf("insert into casco_persons (calc_id,type_person,status) values(%i,2,0)", calc_id));

      TADOQuery *q_calc = m_api->dbGetCursor(res, sql.sprintf("select * from casco_calc where calc_id=%i", calc_id), 0, 0),
                *q_ins = m_api->dbGetCursor(res, sql.sprintf("select * from casco_persons where type_person=1 and calc_id=%i", calc_id), 0, 1),
                *q_bnf = m_api->dbGetCursor(res, sql.sprintf("select * from casco_persons where type_person=2 and calc_id=%i", calc_id), 0, 1),
                *q_drv = m_api->dbGetCursor(res, sql.sprintf("select * from casco_persons where type_person>2 and calc_id=%i", calc_id), 0, 1),
                *q_drv_pc = m_api->dbGetCursor(res, sql.sprintf("select * from casco_permitted where calc_id=%i", calc_id), 0, 1);
      rate_node_c = root_rate->ChildNodes->FindNode("c");
      if(rate_node_c){
         q_calc->CursorLocation = clUseServer; q_calc->Open(); q_calc->Edit();
         q_ins->Edit(); q_bnf->Edit();
         for(int i = 0, cnt = rate_node_c->ChildNodes->Count; i < cnt; ++i){
            curr_node = rate_node_c->ChildNodes->Get(i);
            if(curr_node->HasAttribute(attr_i)){
               if(curr_node->NodeName == m){
                  AnsiString curr_value = NodeAttributeToStr(curr_node, attr_v, attr_v).Trim();
                  switch(AnsiString(curr_node->Attributes[attr_i]).ToIntDef(0)){
                     case 2:  q_calc->FieldByName("srok_date_s")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                     case 3:  q_calc->FieldByName("srok_date_po")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                     case 41: q_calc->FieldByName("bank_id")->AsInteger = m_api->dbGetIntFromQueryDef(res, "select bank_id from gl_dict_banks where bank_code=" + QuotedStr(curr_value)); break;
                     case 45: q_calc->FieldByName("region_id")->AsInteger = curr_value.ToIntDef(77); break;
                     case 47: product_id = curr_value.ToIntDef(301); q_calc->FieldByName("variant_idx")->AsInteger = product_id > 303 ? product_id - 304 : product_id - 301;
                     case 73: payment_count = curr_value.ToIntDef(1); break;
                     // ������������
                     case 36:
                        q_calc->FieldByName("status_idx")->AsInteger = curr_value.ToIntDef(0) == 5 ? 3 : curr_value.ToIntDef(0) - 1;
                        q_ins->FieldByName("status")->AsInteger = q_calc->FieldByName("status_idx")->AsInteger;
                        q_bnf->FieldByName("status")->AsInteger = q_calc->FieldByName("status_idx")->AsInteger;
                        break;
                     case 54:
                        q_ins->FieldByName("first_name")->AsString = curr_value;
                        q_bnf->FieldByName("first_name")->AsString = curr_value;
                        break;
                     case 55:
                        q_ins->FieldByName("second_name")->AsString = curr_value;
                        q_bnf->FieldByName("second_name")->AsString = curr_value;
                        break;
                     case 56:
                        q_ins->FieldByName("last_name")->AsString = curr_value;
                        q_bnf->FieldByName("last_name")->AsString = curr_value;
                        break;
                     case 57:
                        q_ins->FieldByName("phisical_birth_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0));
                        q_bnf->FieldByName("phisical_birth_date")->AsDateTime = q_ins->FieldByName("phisical_birth_date")->AsDateTime;
                        break;
                     case 60:
                        q_ins->FieldByName("document_type_id")->AsInteger = curr_value.ToIntDef(12);
                        q_bnf->FieldByName("document_type_id")->AsInteger = curr_value.ToIntDef(12);
                        break;
                     case 61:
                        q_ins->FieldByName("document_series")->AsString = curr_value;
                        q_bnf->FieldByName("document_series")->AsString = curr_value;
                        break;
                     case 62:
                        q_ins->FieldByName("document_number")->AsString = curr_value;
                        q_bnf->FieldByName("document_number")->AsString = curr_value;
                        break;
                  }
               }
               else if(curr_node->NodeName == c && AnsiString(curr_node->Attributes[attr_i]).ToIntDef(0) == 3){
                  for(int j = 0, cnt_j = curr_node->ChildNodes->Count; j < cnt_j; ++j){
                     curr_node2 = curr_node->ChildNodes->Get(j);
                     if(curr_node2->HasAttribute(attr_i)){
                        if(curr_node2->NodeName == m){
                           AnsiString curr_value = NodeAttributeToStr(curr_node2, attr_v, attr_v).Trim();
                           switch(AnsiString(curr_node2->Attributes[attr_i]).ToIntDef(0)){
                              case 5:   q_calc->FieldByName("ts_model_id")->AsInteger = curr_value.ToIntDef(0); break;
                              case 7:   q_calc->FieldByName("max_massa")->AsInteger = curr_value.ToIntDef(0); break;
                              case 9:   q_calc->FieldByName("seat_count")->AsInteger = curr_value.ToIntDef(0); break;
                              case 51:  q_calc->FieldByName("ts_year")->AsInteger = curr_value.ToIntDef(0); break;
                              case 87:  q_calc->FieldByName("ts_novoe")->AsBoolean = curr_value.ToIntDef(0); break;
                              case 100: q_calc->FieldByName("pts_date_calc")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                              case 28:  q_calc->FieldByName("ts_vin")->AsString = curr_value.UpperCase(); break;
                              case 29:  chassis_number = curr_value.UpperCase(); break;
                              case 30:  body_number = curr_value.UpperCase(); break;
                              case 59:  q_calc->FieldByName("ts_znak")->AsString = m_api->Translit_Text(res, curr_value, true).UpperCase(); break;
                              case 48:  q_calc->FieldByName("ts_cost")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 89:  q_calc->FieldByName("str_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 78:
                                 multidrive = curr_value.ToIntDef(100) == 1 ? 100 : curr_value.ToIntDef(100);
                                 q_calc->FieldByName("multidrive")->AsInteger = multidrive;
                                 q_calc->FieldByName("multidrive_pc")->AsInteger = multidrive;
                                 break;
                              case 76:  q_calc->FieldByName("pay_id")->AsInteger = curr_value.ToIntDef(0); break;
                              case 77:  q_calc->FieldByName("risk_id")->AsInteger = curr_value.ToIntDef(0); break;
                              case 86:  q_calc->FieldByName("full_insur")->AsInteger = curr_value.ToIntDef(0) ? 3 : 1; break;
                              case 82:  q_calc->FieldByName("type_franshiza")->AsInteger = curr_value.ToIntDef(0); break;
                              case 80:  q_calc->FieldByName("franshiza_unit")->AsInteger = curr_value.ToIntDef(0); break;
                              case 81:  q_calc->FieldByName("franshiza")->AsString = curr_value.ToIntDef(0) == 0 ? empty_str : curr_value; break;
                              case 90:  q_calc->FieldByName("dsago_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 91:  q_calc->FieldByName("ts_pricep")->AsBoolean = curr_value.ToIntDef(0); break;
                              case 92:  q_calc->FieldByName("ns_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 93:  q_calc->FieldByName("dms_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                           }
                        }
                        else if(curr_node2->NodeName == c && AnsiString(curr_node2->Attributes[attr_i]).ToIntDef(0) == 1){
                           q_drv->Insert();
                           q_drv->FieldByName("calc_id")->AsInteger = calc_id;
                           q_drv->FieldByName("status")->AsInteger = 0;
                           q_drv->FieldByName("type_person")->AsInteger = drv_i;
                           q_drv->FieldByName("document_type_id")->AsInteger = 17;
                           q_drv->FieldByName("k6")->AsFloat = 2.5;
                           q_drv->FieldByName("phisical_sex")->AsInteger = 1;

                           q_drv_pc->Insert();
                           q_drv_pc->FieldByName("calc_id")->AsInteger = calc_id;
                           q_drv_pc->FieldByName("permitted_number")->AsInteger = drv_i - 3;
                           // ����� ��������� ��������� ����
                           for(int k = 0, cnt_k = curr_node2->ChildNodes->Count; k < cnt_k; ++k){
                              curr_node3 = curr_node2->ChildNodes->Get(k);
                              if(curr_node3->HasAttribute(attr_i)){
                                 if(curr_node3->NodeName == m){
                                    AnsiString curr_value = NodeAttributeToStr(curr_node3, attr_v, attr_v).Trim();
                                    switch(AnsiString(curr_node3->Attributes[attr_i]).ToIntDef(0)){
                                       case 14:
                                          q_drv->FieldByName("phisical_birth_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0));
                                          q_drv_pc->FieldByName("phisical_birth_date")->AsDateTime = q_drv->FieldByName("phisical_birth_date")->AsDateTime;
                                          break;
                                       case 15:
                                          q_drv->FieldByName("document_issue_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0));
                                          q_drv_pc->FieldByName("document_issue_date")->AsDateTime = q_drv->FieldByName("document_issue_date")->AsDateTime;
                                          break;
                                       case 19: q_drv->FieldByName("document_series")->AsString = curr_value; break;
                                       case 20: q_drv->FieldByName("document_number")->AsString = curr_value; break;
                                       case 63: q_drv->FieldByName("first_name")->AsString = curr_value; break;
                                       case 64: q_drv->FieldByName("second_name")->AsString = curr_value; break;
                                       case 65: q_drv->FieldByName("last_name")->AsString = curr_value; break;
                                    }
                                 }
                              }
                           }
                           q_drv->FieldByName("age")->AsInteger = CalcYears(q_drv->FieldByName("phisical_birth_date")->AsDateTime, Date());
                           q_drv_pc->FieldByName("age")->AsInteger = q_drv->FieldByName("age")->AsInteger;
                           q_drv->FieldByName("experience")->AsInteger = CalcYears(q_drv->FieldByName("document_issue_date")->AsDateTime, Date());
                           q_drv_pc->FieldByName("experience")->AsInteger = q_drv->FieldByName("experience")->AsInteger;
                           q_drv->Post(); q_drv_pc->Post(); drv_i++;
                        }
                     }
                  }
               }
            }
         }

         //  ����������� krs_idx
         terr_type_id = m_api->dbGetIntFromQuery(res, "select type_id from gl_dict_dsago_contract where cnt_cl_id=5 and CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date and terr_id=" + IntToStr(q_calc->FieldByName("region_id")->AsInteger));

         q_calc->FieldByName("quotation_date")->AsDateTime = quotes_date;
         q_calc->FieldByName("srok_month")->AsInteger = MonthsCount(q_calc->FieldByName("srok_date_s")->AsDateTime, q_calc->FieldByName("srok_date_po")->AsDateTime);
         if(q_calc->FieldByName("bank_id")->AsInteger > 0){
            q_calc->FieldByName("source_id")->AsInteger = 1;
            TADOQuery *q_b = m_api->dbGetCursor(res, "select * from gl_dict_banks where bank_id=" + IntToStr(q_calc->FieldByName("bank_id")->AsInteger));
            if(q_b->FieldByName("benefic")->AsInteger){
               q_bnf->FieldByName("status")->AsInteger = 1;
               q_bnf->FieldByName("first_name")->AsString = empty_str;
               q_bnf->FieldByName("second_name")->AsString = empty_str;
               q_bnf->FieldByName("last_name")->AsString = q_b->FieldByName("bank_name_print")->AsString;
               q_bnf->FieldByName("inn")->AsString = q_b->FieldByName("bank_inn")->AsString;
               q_bnf->FieldByName("ogrn")->AsString = q_b->FieldByName("bank_ogrn")->AsString;
               q_bnf->FieldByName("address")->AsString = q_b->FieldByName("bank_address")->AsString;
               q_bnf->FieldByName("phisical_birth_date")->Value = variant_null;
               q_bnf->FieldByName("document_type_id")->AsInteger = 0;
               q_bnf->FieldByName("document_series")->AsString = empty_str;
               q_bnf->FieldByName("document_number")->AsString = empty_str;
            }
            m_api->dbCloseCursor(res, q_b);
         }
         TADOQuery *q_mm = m_api->dbGetCursor(res, "select * from gl_dict_carrier_models where code=" + QuotedStr(AddNulls(q_calc->FieldByName("ts_model_id")->AsInteger)));
         q_calc->FieldByName("tstype_id")->Value = q_mm->FieldByName("carrier_type_fk")->Value;
         q_calc->FieldByName("ts_marka_calc")->Value = q_mm->FieldByName("brand_name")->Value;
         q_calc->FieldByName("ts_marka")->Value = q_mm->FieldByName("brand_name")->Value;
         q_calc->FieldByName("ts_model")->Value = q_mm->FieldByName("model_name")->Value;
         m_api->dbCloseCursor(res, q_mm);

         q_calc->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=" + IntToStr(payment_count) + " and Date()>=start_date and Date()<=end_date and terr_type_id=" + IntToStr(terr_type_id) + " and (product_id=0 or product_id=" + IntToStr(product_id) + ") order by product_id desc");

         AnsiString rgpl = q_calc->FieldByName("ts_znak")->AsString;
         if(rgpl.Length() > 7){
            q_calc->FieldByName("is_registration_ts")->Value = 1;
            q_calc->FieldByName("region_isp_id")->Value = rgpl.SubString(7, rgpl.Length() - 6).ToIntDef(0);
         }
         else q_calc->FieldByName("is_registration_ts")->Value = 0;

         q_calc->FieldByName("ident_type")->Value = 0;
         if(q_calc->FieldByName("ts_vin")->AsString.IsEmpty()){
            if(!body_number.IsEmpty()){
               q_calc->FieldByName("ts_vin")->AsString = body_number;
               q_calc->FieldByName("ident_type")->Value = 1;
            }
            else{
               if(!chassis_number.IsEmpty()){
                  q_calc->FieldByName("ts_vin")->AsString = chassis_number;
                  q_calc->FieldByName("ident_type")->Value = 1;
               }
            }
         }

         TADOQuery *q_t = m_api->dbGetCursor(res, "select * from cascotariff where vehgr_id=0 and code_prod<>0 and risk_id=" + IntToStr(q_calc->FieldByName("risk_id")->AsInteger) + " and product_id=" + IntToStr(product_id));
         q_calc->FieldByName("risk_main")->Value = q_t->FieldByName("risk_code")->Value;
         q_calc->FieldByName("code_prod")->Value = q_t->FieldByName("code_prod")->Value;
         q_calc->FieldByName("name_prod")->Value = q_t->FieldByName("name_prod")->Value;
         m_api->dbCloseCursor(res, q_t);

         if(q_calc->FieldByName("ns_summa")->AsFloat > 0){
            q_calc->FieldByName("select_ns")->Value = true;
            q_calc->FieldByName("risk_ns")->Value = m_api->dbGetStringFromQuery(res, "select risk_code from cascotariff where vehgr_id=0 and risk_id=4 and product_id=" + IntToStr(product_id));
         }
         if(q_calc->FieldByName("dsago_summa")->AsFloat > 0){
            q_calc->FieldByName("select_dsago")->Value = true;
            q_calc->FieldByName("risk_dsago")->Value = m_api->dbGetStringFromQuery(res, "select risk_code from cascotariff where vehgr_id=0 and risk_id=5 and product_id=" + IntToStr(product_id));
            q_calc->FieldByName("dsago_territory_id")->Value = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_terr_osago_kasko where map_id=" + IntToStr(q_calc->FieldByName("region_id")->AsInteger));
            q_calc->FieldByName("dsago_city_id")->Value = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_osagoterritorycoeff where Date()>=start_date and Date()<=end_date and parent_id=" + IntToStr(q_calc->FieldByName("dsago_territory_id")->AsInteger));
         }
         if(q_calc->FieldByName("dms_summa")->AsFloat > 0)
            q_calc->FieldByName("select_dms")->Value = true;

         q_calc->FieldByName("ks")->Value = 1;
         q_calc->FieldByName("ka")->Value = 1;
         q_calc->FieldByName("key_count")->Value = 2;
         q_calc->FieldByName("kkv")->Value = 0;
         q_calc->FieldByName("project_id")->Value = 0;
         q_calc->FieldByName("programm_id")->Value = 0;
         q_calc->FieldByName("dogovor")->Value = "��������������";
         q_calc->FieldByName("fio")->Value = Trim(q_ins->FieldByName("last_name")->AsString + space_str + q_ins->FieldByName("first_name")->AsString + space_str + q_ins->FieldByName("second_name")->AsString);
         q_calc->FieldByName("calc_k5_k6")->Value = 1;
         q_calc->FieldByName("polis_date")->Value = quotes_date;
         q_calc->FieldByName("date_vznos1")->Value = quotes_date;
         q_calc->FieldByName("srok_date_s")->Value = quotes_date;
         q_calc->FieldByName("srok_date_po")->Value = CalcEndDateInsur(quotes_date, q_calc->FieldByName("srok_month")->AsInteger);

         q_calc->Post(); q_ins->Post(); q_bnf->Post();
      }

      m_api->dbCloseCursor(res, q_calc); m_api->dbCloseCursor(res, q_ins); m_api->dbCloseCursor(res, q_bnf); m_api->dbCloseCursor(res, q_drv); m_api->dbCloseCursor(res, q_drv_pc);
      delete XMLDoc;
   }
   catch(Exception& ex){ ShowMessage("�������� XML Oracle Insbridge: " + ex.Message); }
   catch(...){ ShowMessage("�������� XML Oracle Insbridge: FATAL ERROR"); }

   m_api->Module_Refresh_Main_Grid(res);
}
//---------------------------------------------------------------------------
void XMLLoadCalen(const AnsiString& xml_text)
{
}
//---------------------------------------------------------------------------
void MakeKladrAddr(_di_IXMLNode child_node, TStringList* addr, int& memo_id)
{
   addr->Clear();
   memo_id = 0;
   AnsiString code_kladr = Trim(child_node->ChildNodes->FindNode("code_kladr")->Text);

   addr->Values["��� �����"]          = code_kladr;
   addr->Values["��������"]           = code_kladr.IsEmpty() ? "���" :"��";
   addr->Values["������������ �����"] = code_kladr.IsEmpty() ? "���" : "��";
   addr->Values["������"]             = "��";
   addr->Values["������ ������"]      = child_node->ChildNodes->FindNode("filter_kladr")->Text;
   addr->Values["�����������"]        = child_node->ChildNodes->FindNode("country")->Text;
   addr->Values["������"]             = child_node->ChildNodes->FindNode("region")->Text;
   addr->Values["�����"]              = child_node->ChildNodes->FindNode("area")->Text;
   addr->Values["�����"]              = child_node->ChildNodes->FindNode("place")->Text;
   addr->Values["������"]             = child_node->ChildNodes->FindNode("zip")->Text;
   addr->Values["�����"]              = child_node->ChildNodes->FindNode("street")->Text;
   addr->Values["���"]                = child_node->ChildNodes->FindNode("house")->Text;
   addr->Values["������/��������"]    = "�";
   addr->Values["����� �������"]      = child_node->ChildNodes->FindNode("building")->Text;
   addr->Values["��������"]           = child_node->ChildNodes->FindNode("flat")->Text;

   AnsiString memo_text = addr->Text;
   m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "casco_memo");
}
//---------------------------------------------------------------------------
AnsiString GetAddr(_di_IXMLNode child_node)
{
   return AnsiString(child_node->ChildNodes->FindNode("COUNTRY")->Text) + ", " + AnsiString(child_node->ChildNodes->FindNode("ZIP")->Text) + ", " + AnsiString(child_node->ChildNodes->FindNode("NAME")->Text) + " " + AnsiString(child_node->ChildNodes->FindNode("EXACT_ADDRESS")->Text);
}
//---------------------------------------------------------------------------
void LoadPerson(TADOQuery *q_p, _di_IXMLNode person, const int type_person, const int calc_id, const TDateTime& q_dt)
{
   bool is_perm = type_person > 3;
   AnsiString ph_mob(""), ph_home(""), ph_rab(""), exact_address("");
   TDateTime dt;
   int memo_id(0), sms(0), doc_type_id, i_val;
   TStringList *kladr_addr = new TStringList();

   MakeKladrAddrFromUXML(m_api, person, kladr_addr, memo_id, exact_address);
   GetPhones(person->ChildNodes->FindNode("contacts"), ph_mob, ph_home, ph_rab, sms);

   q_p->FieldByName("calc_id")->Value = calc_id;
   q_p->FieldByName("status")->Value = NodeToStr(person->ChildNodes->FindNode("is_juridical")).ToIntDef(0);
   q_p->FieldByName("type_person")->Value = type_person;

   q_p->FieldByName("first_name")->Value = NodeToStr(person->ChildNodes->FindNode("first_name"));
   q_p->FieldByName("second_name")->Value = NodeToStr(person->ChildNodes->FindNode("second_name"));
   q_p->FieldByName("last_name")->Value = NodeToStr(person->ChildNodes->FindNode("last_name"));

   if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("physical_bitrh_date")), dt)){
      q_p->FieldByName("phisical_birth_date")->Value = dt;
      q_p->FieldByName("age")->Value = CalcYears(dt, q_dt);
   }
   q_p->FieldByName("phisical_sex")->Value = NodeToStr(person->ChildNodes->FindNode("physical_sex")).ToIntDef(-1) + 1;
   q_p->FieldByName("addr_mid")->Value = memo_id;

   switch(q_p->FieldByName("status")->AsInteger){
      case 0: doc_type_id = TryStrToInt(NodeToStr(person->ChildNodes->FindNode("document_type_id")), i_val) ? i_val : 12; break;
      case 1: doc_type_id = TryStrToInt(NodeToStr(person->ChildNodes->FindNode("document_type_id")), i_val) ? i_val : 25; break;
      case 2: doc_type_id = TryStrToInt(NodeToStr(person->ChildNodes->FindNode("document_type_id")), i_val) ? i_val : 29; break;
   }
   q_p->FieldByName("document_type_id")->Value = is_perm ? 17 : doc_type_id;
   q_p->FieldByName("document_series")->Value  = is_perm ? NormVIN_GN(m_api, NodeToStr(person->ChildNodes->FindNode("license_series"))) : NodeToStr(person->ChildNodes->FindNode("document_series"));
   q_p->FieldByName("document_number")->Value  = is_perm ? NodeToStr(person->ChildNodes->FindNode("license_number")) : NodeToStr(person->ChildNodes->FindNode("document_number"));
   if(is_perm){
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("driving_start_date")), dt)){
         q_p->FieldByName("document_issue_date")->Value = dt;
         q_p->FieldByName("experience")->Value = CalcYears(dt, q_dt);
      }
   }
   else{
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("document_issue_date")), dt)) q_p->FieldByName("document_issue_date")->Value = dt;
      q_p->FieldByName("address")->Value = exact_address;
   }
   q_p->FieldByName("document_issue_org")->Value = NodeToStr(person->ChildNodes->FindNode("document_issue_organization"));
   q_p->FieldByName("phone_mobil")->Value = ph_mob;
   q_p->FieldByName("inn")->Value = NodeToStr(person->ChildNodes->FindNode("inn"));
   q_p->FieldByName("ogrn")->Value = NodeToStr(person->ChildNodes->FindNode("ogrn"));

   q_p->FieldByName("k6")->Value = 3;

   delete kladr_addr;
}
//---------------------------------------------------------------------------
bool LoadDataFromARM(const AnsiString& text_xml = empty_str)
{
   AnsiString xml = text_xml.IsEmpty() ? m_api->Get_Data_From_ARM_Form(res) : text_xml, str(""), st(""), bank_code("");
   TDateTime dt = Date(), dt1 = IncDay(IncYear(dt), -1), dt_po = dt1, quotes_date, dt_s, dt_e;
   double d_val, premium_mr;
   int i_val, terr_type_id(1), dsago_terr_id, product_id(0), programm_id(0);
   bool result(false);

   if(xml.IsEmpty()) return result;

   try{
      _di_IXMLDocument XMLDoc = NewXMLDocument();

      XMLDoc->Active = true;
      XMLDoc->LoadFromXML(xml);
      if(m_api->is_debug) XMLDoc->SaveToFile("F:\\test_load_arm.xml");

      _di_IXMLNode root_response = XMLDoc->DocumentElement, policy, person, vehicle, risks, casco_coeffs, paymentshedules, child_node, error_node, bank, blank, paymentdata, blank_pd;

      error_node = root_response->ChildNodes->FindNode("Error");
      if(error_node){
         delete XMLDoc;
         Application->MessageBox("������� �� ��� �������� � �������. ��������� ������� �������.", "�������� �������� �� ���!", MB_OK | MB_ICONEXCLAMATION);
         return true;
      }
      else{

         policy = root_response->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy");
         person = policy->ChildNodes->FindNode("persons");
         vehicle = policy->ChildNodes->FindNode("autovehicles")->ChildNodes->FindNode("autovehicle");
         risks = vehicle->ChildNodes->FindNode("riskobjects");
         casco_coeffs = vehicle->ChildNodes->FindNode("casco_coefficients");
         paymentshedules = policy->ChildNodes->FindNode("paymentshedules");
         bank = policy->ChildNodes->FindNode("bank_broker");
         blank = policy->ChildNodes->FindNode("blanks")->ChildNodes->FindNode("blank");
         paymentdata = policy->ChildNodes->FindNode("paymentdatas")->ChildNodes->FindNode("paymentdata");
         blank_pd = paymentdata->ChildNodes->FindNode("blank");

         product_id  = NodeToStr(policy->ChildNodes->FindNode("product_class_id")).ToIntDef(301);
         programm_id = NodeToStr(policy->ChildNodes->FindNode("program_id")).ToIntDef(0);
         if(product_id > 306 || programm_id == 1316 || programm_id == 1328){
            delete XMLDoc;
            Application->MessageBox("��������, �������� � ��� ��� \"����� �������\", \"����������\", \"����� ������ �������\", �������������� � �������� ����������� ���� \"������\" ������!!!. ���������� ������� ��� ��������������.", "�������� �������� �� ���!", MB_OK | MB_ICONEXCLAMATION);
            return true;
         }

         int id = m_api->dbInsert_Empty_Calc(res), region_id = m_api->vrGetVariable(res, "KASKO_Territory").Trim().ToIntDef(77);
         if(!region_id) region_id = 77;

         m_api->dbExecuteQuery(res, str.sprintf("update _mops_calcs_ set id_polzovatelya=%i where [id]=%i", m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0), id));
         m_api->dbExecuteQuery(res, str.sprintf("insert into casco_calc (calc_id,source_id,bank_id,region_id,tstype_id,ts_model_id,max_massa,seat_count,risk_id,risk_main,status_idx,ts_year,variant_idx,srok_month,ts_novoe,bez_ogr,multidrive,fr_instead_k1,pay_id,prolong,prev_ubitki_idx,osago_idx,ts_count,ks,ka,franshiza,str_summa,ts_cost,select_ns,select_dsago,ns_summa,ts_pricep,dsago_summa,key_count,ts_power,ns_variant,ns_seat_count,dop_obor,spec_ts,dop_sog,vznos1,vznos2,vznos3,no_osmotr,osmotr,payment_id,payment_doc_id,premium_main_risk,premium_dsago,premium_ns,premiya_all,srok_time_s,srok_date_s,srok_time_po,srok_date_po,project_id,dogovor,ts_doc_type,krs_idx,type_franshiza,kpr,programm_id,polis_id,claim_damages_sum,dogovor_type,dsago_territory_id,kkv,is_registration_ts,calc_k5_k6) "
                                                             "values (%i,0,0,%i,2,0,0,0,2,'_ROOT1000000KASKOA1024221;_ROOT1000000KASKOA1024222',0,%i,0,12,0,0,100,0,3,0,-1,0,1,1,1,'',0,0,0,0,0,0,0,2,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'00:00',%s,'23:59',%s,0,'��������������',1,1,1,1,0,0,0,1,1,0,-1,1)", id, region_id, YearOf(dt), m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false), m_api->Internal_Convert_Date_To_SQL(res, dt1.DateString(), false)));
         ShortDateFormat = "yyyy.MM.dd";

         TADOQuery *q_save = m_api->dbGetCursor(res, "select * from casco_calc where calc_id=" + IntToStr(id), 0, 0);
         q_save->CursorLocation = clUseServer;
         q_save->Open();
         q_save->Edit();

         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_date")), dt)){
            q_save->FieldByName("polis_date")->Value = dt;
            q_save->FieldByName("quotation_date")->Value = quotes_date = dt;
         }
         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("quotes_date")), dt)) q_save->FieldByName("quotation_date")->Value = quotes_date = dt;

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("territory")), i_val)){
            int reg_id = m_api->dbGetIntFromQuery(res, "select [new_region_id] from gl_dict_regions_map where [old_region_id]=" + IntToStr(i_val));
            q_save->FieldByName("region_id")->Value = (reg_id == 0) ? i_val : reg_id;
            terr_type_id = m_api->dbGetIntFromQuery(res, "select type_id from gl_dict_dsago_contract where cnt_cl_id=5 and CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date and terr_id=" + IntToStr(q_save->FieldByName("region_id")->AsInteger));
            dsago_terr_id = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_terr_osago_kasko where map_id=" + IntToStr(q_save->FieldByName("region_id")->AsInteger));
         }

         if(person){
            TADOQuery *q_p = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + IntToStr(id), 0, 1);
            int index_perm(0);
            for(int i = 0, cnt = person->ChildNodes->Count; i < cnt; ++i){
               child_node = person->ChildNodes->Get(i);
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_insured")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, 1, id, quotes_date);
                     q_save->FieldByName("status_idx")->Value = q_p->FieldByName("status")->Value;
                     q_save->FieldByName("fio")->Value = Trim(q_p->FieldByName("last_name")->AsString + space_str + q_p->FieldByName("first_name")->AsString + space_str + q_p->FieldByName("second_name")->AsString);
                     q_save->FieldByName("sms_sending")->Value = NodeToStr(person->ChildNodes->FindNode("sms_sending")).ToIntDef(-1);
                  }
               }
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_beneficiary")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, 2, id, quotes_date);
                  }
               }
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_permitted")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, index_perm + 4, id, quotes_date);
                     ++index_perm;
                  }
               }
            }
            q_p->UpdateBatch();
            m_api->dbCloseCursor(res, q_p);
         }

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("is_pledged_property")), i_val)){
            q_save->FieldByName("source_id")->Value = i_val;
            if(q_save->FieldByName("source_id")->AsInteger){
               if(bank->HasAttribute("bank_code")) bank_code = bank->Attributes["bank_code"];
               q_save->FieldByName("bank_id")->Value = m_api->dbGetIntFromQuery(res, "select bank_id from gl_dict_banks where (bank_code='" + bank_code + "' or bank_name='" + AnsiString(bank->Text) + "') and CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date");
               if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("is_first_risk")), i_val)){
                  if((i_val == 1) && (product_id == 301 || product_id == 304)) q_save->FieldByName("full_insur")->Value = 3;
               }
            }
         }

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("vehicle_type_id")), i_val)) q_save->FieldByName("tstype_id")->Value = i_val;
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("allowed_mass")), i_val)) q_save->FieldByName("max_massa")->Value  = i_val;
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("number_of_seats")), i_val)) q_save->FieldByName("seat_count")->Value = i_val;
         q_save->FieldByName("ts_marka")->Value = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_brand_name"));
         q_save->FieldByName("ts_model")->Value = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_model_name"));
         if(TryStrToFloat(NodeToStr(vehicle->ChildNodes->FindNode("rsa_code")), d_val)){
            q_save->FieldByName("ts_model_id")->Value = d_val;
            q_save->FieldByName("ts_marka_calc")->Value = m_api->dbGetStringFromQuery(res, "select brand_name from gl_dict_carrier_models where val(code)=" + FloatToStr(d_val));
         }

         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("construction_date")), dt)) q_save->FieldByName("ts_year")->Value = YearOf(dt);
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("is_new_vehicle")), i_val)) q_save->FieldByName("ts_novoe")->Value = i_val;
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("vehicle_group")), i_val)) q_save->FieldByName("group_str")->Value = StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(i_val)), "������ ", empty_str, rf);
         q_save->FieldByName("ts_power")->Value = StrToFloatStr(NodeToStr(vehicle->ChildNodes->FindNode("engine_power_hp"))).ToDouble();

         AnsiString rgpl = m_api->Translit_Text(res, NodeToStr(vehicle->ChildNodes->FindNode("registration_mark")), true);
         if(rgpl.Length() > 7){
            q_save->FieldByName("is_registration_ts")->Value = 1;
            q_save->FieldByName("ts_znak")->Value = rgpl.UpperCase();
            q_save->FieldByName("region_isp_id")->Value = rgpl.SubString(7, rgpl.Length() - 6).ToIntDef(0);
         }
         else q_save->FieldByName("is_registration_ts")->Value = 0;

         AnsiString ident_number = NodeToStr(vehicle->ChildNodes->FindNode("vin"));
         if(ident_number.IsEmpty()){
            ident_number = NodeToStr(vehicle->ChildNodes->FindNode("chassis_number"));
            if(ident_number.IsEmpty()){
               ident_number = NodeToStr(vehicle->ChildNodes->FindNode("body_number"));
               if(!ident_number.IsEmpty()) q_save->FieldByName("ident_type")->Value = 1;
            }
            else q_save->FieldByName("ident_type")->Value = 1;
         }
         else q_save->FieldByName("ident_type")->Value = 0;
         q_save->FieldByName("ts_vin")->Value = ident_number.UpperCase();

         q_save->FieldByName("ts_cost")->Value = StrToFloatStr(NodeToStr(vehicle->ChildNodes->FindNode("actual_value"))).ToDouble();

         q_save->FieldByName("ts_doc_type")->Value = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_registration_type_id")).ToIntDef(1);
         q_save->FieldByName("pts_seria")->Value = NodeToStr(vehicle->ChildNodes->FindNode("registration_series"));
         q_save->FieldByName("pts_number")->Value = NodeToStr(vehicle->ChildNodes->FindNode("registration_number"));
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("registration_issue_date")), dt)){
            q_save->FieldByName("pts_date")->Value = dt;
            if(q_save->FieldByName("ts_doc_type")->AsInteger == 1) q_save->FieldByName("pts_date_calc")->Value = dt;
         }

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("trailer")), i_val)) q_save->FieldByName("ts_pricep")->AsBoolean = i_val;

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("alarms")), i_val)) q_save->FieldByName("alarms_info")->Value = i_val;
         q_save->FieldByName("real_alarm")->Value = NodeToStr(vehicle->ChildNodes->FindNode("alarm_systems"));

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("limited_drivers")), i_val)){
            if(i_val != 1){
               q_save->FieldByName("bez_ogr")->Value = q_save->FieldByName("status_idx")->AsInteger ? false : true;
               q_save->FieldByName("multidrive")->Value = q_save->FieldByName("status_idx")->AsInteger ? -1 : i_val;
            }
         }

         q_save->FieldByName("pay_id")->Value = NodeToStr(policy->ChildNodes->FindNode("payment_method_id")).ToIntDef(0);

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("vehicle_count")), i_val)) q_save->FieldByName("ts_count")->AsInteger = m_api->dbGetIntFromQuery(res, "select k2_id from cascodictk02 where CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date and vehcnt_min<=" + IntToStr(i_val) + " and vehcnt_max>=" + IntToStr(i_val));

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("contract_payed_count")), i_val)){
            q_save->FieldByName("prev_ubitki_idx")->Value = i_val > 3 ? 4 : i_val;
            q_save->FieldByName("payed_count")->AsInteger = i_val;
         }
         if(TryStrToFloat(StrToFloatStr(NodeToStr(policy->ChildNodes->FindNode("contract_payed_sum"))), d_val)) q_save->FieldByName("claim_damages_sum")->AsFloat = d_val;

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("option_id")), i_val)){
            if(i_val == 2){
               q_save->FieldByName("prolong")->Value = true;
               if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("preferential_extension")), i_val)) q_save->FieldByName("benefit_prolong")->Value = i_val;
               if(q_save->FieldByName("prev_ubitki_idx")->AsInteger == -1) q_save->FieldByName("prev_ubitki_idx")->AsInteger = 0;
            }
         }

         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_start_date")), dt_s) && TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_end_date")), dt_e)){
            q_save->FieldByName("srok_date_s")->Value  = (int)dt_s;
            q_save->FieldByName("srok_date_po")->Value = (int)dt_e;
            q_save->FieldByName("srok_time_s")->Value  = dt_s.FormatString("hh:ss");
            q_save->FieldByName("srok_time_po")->Value = dt_e.FormatString("hh:ss");
            q_save->FieldByName("srok_month")->Value   = MonthsCount(dt_s, dt_e);
         }

         if(blank && blank->HasAttribute("blank_type_id") && TryStrToInt(AnsiString(blank->Attributes["blank_type_id"]), i_val)){
            AnsiString bso_name = m_api->dbGetStringFromQuery(res, "select bso_name from bso where bso_id=" + IntToStr(i_val));
            if(!bso_name.IsEmpty()){
               q_save->FieldByName("polis_name")->Value = bso_name;
               q_save->FieldByName("polis_id")->Value = i_val;
            }
         } 
         q_save->FieldByName("polis_seria")->Value  = NodeToStr(policy->ChildNodes->FindNode("policy_series"));
         q_save->FieldByName("polis_number")->Value = NodeToStr(policy->ChildNodes->FindNode("policy_number"));
         q_save->FieldByName("prev_seria")->Value   = NodeToStr(policy->ChildNodes->FindNode("prev_contract_series"));
         q_save->FieldByName("prev_number")->Value = NodeToStr(policy->ChildNodes->FindNode("prev_contract_number"));

         q_save->FieldByName("variant_idx")->Value = product_id > 303 ? product_id - 304 : product_id - 301;

         q_save->FieldByName("project_id")->Value = NodeToStr(policy->ChildNodes->FindNode("project_id")).ToIntDef(0);
         q_save->FieldByName("programm_id")->Value = programm_id;

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("sale_channel_type2008_name")), i_val)){
            q_save->FieldByName("sale_channel_id")->Value = i_val;
            q_save->FieldByName("sale_channel")->Value = m_api->dbGetStringFromQuery(res, "select name_kanal from gl_dict_kanal_prodag where id=" + IntToStr(i_val));
         }

         if(paymentdata->HasAttribute("payment_type_id") && TryStrToInt(AnsiString(paymentdata->Attributes["payment_type_id"]), i_val)) q_save->FieldByName("payment_id")->Value = i_val;
         if(paymentdata->HasAttribute("payment_document_type_id") && TryStrToInt(AnsiString(paymentdata->Attributes["payment_document_type_id"]), i_val)) q_save->FieldByName("payment_doc_id")->Value = i_val;
         if(i_val == 10){
            q_save->FieldByName("pp_seria")->Value = AnsiString(blank_pd->Attributes["blank_series"]);
            q_save->FieldByName("pp_number")->Value = AnsiString(blank_pd->Attributes["blank_number"]);
         }
         else q_save->FieldByName("pp_number")->Value = AnsiString(paymentdata->Attributes["payment_document_number"]);

         AnsiString xml_user = m_api->Get_Agent_Data_From_APO2_SOAP_Server_By_AgentID(res, empty_str, Date());
         if(!xml_user.IsEmpty()){
            _di_IXMLDocument XMLDoc_User = NewXMLDocument();
            XMLDoc_User->Active = true;
            XMLDoc_User->LoadFromXML(xml_user);
            _di_IXMLNode Root_User = XMLDoc_User->DocumentElement, agents, agent;
            agents = Root_User->ChildNodes->FindNode("agents");
            if(agents) agent = agents->ChildNodes->FindNode("agent");
            if(agent){
               q_save->FieldByName("agent")->Value = AnsiString(agent->Attributes["full_name"]);
               q_save->FieldByName("sale_place")->Value = AnsiString(agent->Attributes["branch_name"]);
            }
            delete XMLDoc_User;
         }

         bool is_kasko(false);
         for(int i = 0, cnt = risks->ChildNodes->Count; i < cnt; ++i){
            child_node = risks->ChildNodes->Get(i);
            st = AnsiString(child_node->Attributes["risk_object_type_id"]);
            if(!st.IsEmpty()){
               TADOQuery* q_r = m_api->dbGetCursor(res, "select top 1 [risk_id],[risk_code],[product_id] from cascotariff where ([risk_code] like '%" + st + "%') order by [risk_id]");
               if(!q_r->IsEmpty()){
                  switch(q_r->FieldByName("risk_id")->AsInteger){
                     case 1:
                        if(!is_kasko){
                           q_save->FieldByName("risk_id")->Value = q_r->FieldByName("risk_id")->AsInteger;
                           q_save->FieldByName("risk_main")->Value = q_r->FieldByName("risk_code")->AsString;
                           q_save->FieldByName("tariff")->Value = StrToFloatStr(child_node->Attributes["tariff"]).ToDouble();
                           q_save->FieldByName("str_summa")->Value = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                           q_save->FieldByName("premium_main_risk")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                           q_save->FieldByName("type_franshiza")->Value = AnsiString(child_node->Attributes["franchise_id"]).ToIntDef(1);
                           if(q_save->FieldByName("type_franshiza")->AsInteger == 3){
                              q_save->FieldByName("franshiza")->Value = AnsiString(child_node->Attributes["franchise_size"]);
                              q_save->FieldByName("franshiza_unit")->Value = 2;
                           }
                        }
                        break;
                     case 2:
                        is_kasko = true;
                        q_save->FieldByName("risk_id")->Value = q_r->FieldByName("risk_id")->AsInteger;
                        q_save->FieldByName("risk_main")->Value = q_r->FieldByName("risk_code")->AsString;
                        q_save->FieldByName("tariff")->Value = StrToFloatStr(child_node->Attributes["tariff"]).ToDouble();
                        q_save->FieldByName("str_summa")->Value = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_main_risk")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble() * 2;
                        q_save->FieldByName("type_franshiza")->Value = AnsiString(child_node->Attributes["franchise_id"]).ToIntDef(1);
                        if(q_save->FieldByName("type_franshiza")->AsInteger == 3){
                           q_save->FieldByName("franshiza")->Value = AnsiString(child_node->Attributes["franchise_size"]);
                           q_save->FieldByName("franshiza_unit")->Value = 2;
                        }
                        break;
                     case 4:
                        q_save->FieldByName("select_ns")->Value = true;
                        q_save->FieldByName("risk_ns")->Value = st;
                        q_save->FieldByName("ns_variant")->Value = 0;
                        q_save->FieldByName("ns_summa")->Value =  StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_ns")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                        break;
                     case 5:
                        q_save->FieldByName("select_dsago")->Value = true;
                        q_save->FieldByName("risk_dsago")->Value = st;
                        q_save->FieldByName("dsago_territory_id")->Value = dsago_terr_id;
                        q_save->FieldByName("dsago_city_id")->Value = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_osagoterritorycoeff where Date()>=start_date and Date()<=end_date and parent_id=" + IntToStr(dsago_terr_id));
                        q_save->FieldByName("dsago_summa")->Value = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_dsago")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                        break;
                     case 6:
                        q_save->FieldByName("select_dms")->Value = true;
                        q_save->FieldByName("dms_summa")->Value = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_dms")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                        break;
                  }
               }
               m_api->dbCloseCursor(res, q_r);
            }
         }

         // �������� ���������������� �����������
         if(q_save->FieldByName("ts_cost")->AsFloat > q_save->FieldByName("str_summa")->AsFloat && q_save->FieldByName("full_insur")->AsInteger != 3) q_save->FieldByName("full_insur")->AsInteger = 2;

         q_save->FieldByName("premiya_all")->AsFloat = q_save->FieldByName("premium_main_risk")->AsFloat + q_save->FieldByName("premium_ns")->AsFloat + q_save->FieldByName("premium_dsago")->AsFloat + q_save->FieldByName("premium_dms")->AsFloat;

         for(int i = 0, cnt = paymentshedules->ChildNodes->Count; i < cnt; ++i){
            if(i > 2) break;
            child_node = paymentshedules->ChildNodes->Get(i);
            st = IntToStr(i + 1);
            q_save->FieldByName("vznos" + st)->Value = StrToFloatStr(child_node->Attributes["expected_sum"]).ToDouble();
            if(TryStrToDateTime(child_node->Attributes["expected_date"], dt)) q_save->FieldByName("date_vznos" + st)->AsDateTime = dt;
         }
         if(q_save->FieldByName("vznos3")->AsFloat > 0){
            q_save->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=3 and CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date and terr_type_id=" + IntToStr(terr_type_id) + " and (product_id=0 or product_id=" + IntToStr(product_id) + ") order by product_id desc");
         }
         else{
            if(q_save->FieldByName("vznos2")->AsFloat > 0)  q_save->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=2 and credit_month_min=1 and CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date and terr_type_id=" + IntToStr(terr_type_id) + " and (product_id=0 or product_id=" + IntToStr(product_id) + ") order by product_id desc");
            else q_save->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=1 and CDate('" + quotes_date.DateString() + "')>=start_date and CDate('" + quotes_date.DateString() + "')<=end_date and terr_type_id=" + IntToStr(terr_type_id) + " and (product_id=0 or product_id=" + IntToStr(product_id) + ") order by product_id desc");
         }

         q_save->Post();
         m_api->dbCloseCursor(res, q_save);

         m_api->Raschet_Set_Status_id(res, id, 11);
         result = true;
      }
      delete XMLDoc;
   }
   catch(Exception& ex) { result = false; }

   m_api->Module_Refresh_Main_Grid(res);

   ShortDateFormat = "dd.MM.yyyy";

   return result;
}
//---------------------------------------------------------------------------
void CopyPersonsAndAD(const int old_id, const int new_id)
{
   AnsiString st("");

   TADOQuery *q = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + IntToStr(old_id) + " order by type_person"), *q_insert = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + IntToStr(new_id), 0, 1);
   for(q->First(); !q->Eof; q->Next()){
      q_insert->Insert();
      for(int i = 0, fcnt = q_insert->FieldCount; i < fcnt; ++i) q_insert->Fields->Fields[i]->Value = q->Fields->Fields[i]->Value;
      q_insert->FieldByName("calc_id")->Value    = new_id;
      q_insert->FieldByName("age")->Value        = CalcYears(q_insert->FieldByName("phisical_birth_date")->AsDateTime, Date());
      q_insert->FieldByName("experience")->Value = CalcYears(q_insert->FieldByName("document_issue_date")->AsDateTime, Date());;
   }
   q_insert->UpdateBatch(); m_api->dbCloseCursor(res, q_insert);
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select * from casco_devices where calc_id=" + IntToStr(old_id) + " order by number"), q_insert = m_api->dbGetCursor(res, "select * from casco_devices where calc_id=" + IntToStr(new_id), 0, 1);
   for(q->First(); !q->Eof; q->Next()){
      q_insert->Insert();
      for(int i = 0, fcnt = q_insert->FieldCount; i < fcnt; ++i) q_insert->Fields->Fields[i]->Value = q->Fields->Fields[i]->Value;
      q_insert->FieldByName("calc_id")->Value = new_id;
   }
   q_insert->UpdateBatch(); m_api->dbCloseCursor(res, q_insert);
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void Prolongation()
{
   int curr_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
   TDateTime dt = Now(), dt_start, dt_end;
   TADOQuery *q = m_api->dbGetCursor(res, "select srok_month,polis_seria,polis_number,payed_count,sale_channel,sale_channel_id,premium_main_risk,str_summa,srok_date_po,ts_cost from casco_calc where calc_id=" + IntToStr(curr_id));
   AnsiString str, pser = q->FieldByName("polis_seria")->AsString, pnum = q->FieldByName("polis_number")->AsString, sale_channel = q->FieldByName("sale_channel")->AsString;
   int srok = q->FieldByName("srok_month")->AsInteger, pcnt = q->FieldByName("payed_count")->AsInteger, old_sale_channel_id = q->FieldByName("sale_channel_id")->AsInteger, sale_channel_id;

   if((old_sale_channel_id > 140 && old_sale_channel_id < 150) || (old_sale_channel_id > 300 && old_sale_channel_id < 400)){
      sale_channel_id = 139;
      sale_channel = "������� ����������� ������ � �����";
   }
   else if(old_sale_channel_id == 139){
      sale_channel_id = 131;
      sale_channel = "������������ �����";
   }
   else sale_channel_id = old_sale_channel_id;

   double premium_main_risk = q->FieldByName("premium_main_risk")->AsFloat, str_summa = q->FieldByName("str_summa")->AsFloat, ts_cost = q->FieldByName("ts_cost")->AsFloat;
   dt_start = IncDay(q->FieldByName("srok_date_po")->AsDateTime);
   m_api->dbCloseCursor(res, q);

   if(int(dt_start) <= int(dt)) dt_start = dt;
   else dt = int(dt);
   dt_end = Dateutils::IncDay(IncYear(dt_start), -1);

   if(srok == 12){
      int calc_id = m_api->dbInsert_Empty_Calc(res);

      m_api->dbExecuteQuery(res, str.sprintf("update _mops_calcs_ set id_polzovatelya=%i where [id]=%i", m_api->dbGetIntFromQuery(res, "select id_polzovatelya from _mops_calcs_ where id=" + IntToStr(curr_id)), calc_id));
      m_api->dbCopyRowInTable(res, "casco_calc", "calc_id", curr_id, calc_id);

      CopyPersonsAndAD(curr_id, calc_id);
//[programm_id]=0,
      AnsiString str_update = "update casco_calc set "
        " [quotation_date]=Date(),[prolong]=1,[polis_seria]='',[polis_number]='',[dogovor_type]=2,[str_summa]=0,[ts_cost]=0,[premiya_all]=0,[vznos1]=0,[vznos2]=0,[vznos3]=0,[date_vznos1]=null,[date_vznos2]=null,[date_vznos3]=null,[pp_seria]='',[pp_number]='',[calc_k5_k6]=1,[project_id]=0,[benefit_prolong]=0,[ts_novoe]=0,"
        " [old_str_summa]=" +  FloatToSQLStr(str_summa) + ","
        " [old_premium_main_risk]=" +  FloatToSQLStr(premium_main_risk) + ","
        " [old_ts_cost]=" +  FloatToSQLStr(ts_cost) + ","
        " [prev_ubitki_idx] = " + IntToStr(pcnt > 3 ? 4 : pcnt) + ","
        " [sale_channel] = '" + sale_channel + "',"
        " [sale_channel_id] = " + IntToStr(sale_channel_id) + ","
        " [old_sale_channel_id] = " + IntToStr(old_sale_channel_id) + ","
        " [polis_date] = " + m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) + ","
        " [srok_time_s] = '" + dt.FormatString("hh:nn") + "',"
        " [srok_date_s] = " + m_api->Internal_Convert_Date_To_SQL(res, dt_start.DateString(), false) + ","
        " [srok_date_po] = " + m_api->Internal_Convert_Date_To_SQL(res, dt_end.DateString(), false) + ","
        " [prev_seria] = '" + pser + "',"
        " [prev_number] = '" + pnum + "'"
        " where [calc_id] = " + IntToStr(calc_id);
      m_api->dbExecuteQuery(res, str_update);

      m_api->Raschet_Set_Status_id(res, calc_id, 0);
      m_api->dbSet_Main_Grid_Current_CalcID(res, 0);
      m_api->Module_Refresh_Main_Grid(res);
      m_api->Application_Press_Button(res, "��������");
   }
   else ShowMessage("��������, � ������� ���� ����������� ������ 1 ���� �� ��������������!");
}
//---------------------------------------------------------------------------
void PrintDuble()
{
   int curr_id = m_api->dbGet_Main_Grid_Current_CalcID(res);

   TADOQuery *q = m_api->dbGetCursor(res, "select calc_id,prev_seria,prev_number,polis_seria,polis_number,polis_date_d,dop_usl1,dop_usl2,srok_date_s,premiya_all,policy_sign from casco_calc where calc_id=" + IntToStr(curr_id), 0, 1);
   TfrmDubl *fdbl = new TfrmDubl(0);
   fdbl->editReason->EditText = "����� ������ ������ " + q->FieldByName("polis_seria")->AsString + space_str + q->FieldByName("polis_number")->AsString + ", �.�. ";
   if(fdbl->ShowModal() == mrOk && fdbl->IsAllData()){
      q->Edit();
      q->FieldByName("prev_seria")->Value   = q->FieldByName("polis_seria")->Value;
      q->FieldByName("prev_number")->Value  = q->FieldByName("polis_number")->Value;
      q->FieldByName("polis_seria")->Value  = fdbl->editPolisSeria->EditText.Trim();
      q->FieldByName("polis_number")->Value = fdbl->editPolisNumber->EditText.Trim();
      q->FieldByName("polis_date_d")->Value = Date();
      q->FieldByName("dop_usl1")->Value     = fdbl->editReason->EditText.Trim();
      q->FieldByName("dop_usl2")->Value     = empty_str;
      q->FieldByName("policy_sign")->Value  = m_api->GetCrc16ForPolisSign(res, q->FieldByName("polis_seria")->AsString + q->FieldByName("polis_number")->AsString + q->FieldByName("srok_date_s")->AsDateTime.FormatString("ddmmyyyy") + FloatToIntStr(q->FieldByName("premiya_all")->AsFloat));
      q->Post();
      m_api->dbCloseCursor(res, q);

      q = m_api->dbGetCursor(res, "select * from casco_calc where [calc_id]=" + IntToStr(curr_id));

      double prem_RUR = m_api->Round(q->FieldByName("premiya_all")->AsFloat), payed_sum_RUR = m_api->Round(q->FieldByName("payed_sum")->AsFloat);
      int bank_id = q->FieldByName("bank_id")->AsInteger, status = q->FieldByName("status_idx")->AsInteger, pay_id = q->FieldByName("pay_id")->AsInteger, full_insur = q->FieldByName("full_insur")->AsInteger, variant_idx = q->FieldByName("variant_idx")->AsInteger, standart = m_api->dbGetIntFromQuery(res, "select policy_mask from gl_dict_banks where [bank_id]=" + IntToStr(bank_id)), count_permitted = m_api->dbGetIntFromQuery(res, "select count(*) from casco_persons where type_person>3 and calc_id=" + IntToStr(curr_id)), source_id = q->FieldByName("source_id")->AsInteger, product_id = q->FieldByName("variant_idx")->AsInteger + (q->FieldByName("status_idx")->AsInteger == 0 ? 301 : 304);

      AnsiString sql, premium_string = m_api->Summa_Propisyu(q->FieldByName("premiya_all")->AsFloat, true, false), premium_RUR_string = m_api->Summa_Propisyu(prem_RUR, true, false), payed_RUR_string = m_api->Summa_Propisyu(payed_sum_RUR, true, false),
                      refund_value_string = m_api->Summa_Propisyu(q->FieldByName("refund_value")->AsFloat, true, false), policy_date = q->FieldByName("polis_date")->AsDateTime.DateString(),
                      compensation_type = m_api->dbGetStringFromQuery(res, "select compensation_type from gl_dict_banks where [bank_id]=" + IntToStr(bank_id)), num_ds("      ");

      TList *data_sets = new TList();

      TClientDataSet *clds_risks = new TClientDataSet(0), *clds_dms = new TClientDataSet(0), *clds_compensation = new TClientDataSet(0), *clds_shedul = new TClientDataSet(0);

      clds_risks->FieldDefs->Add("risk_name", ftString, 255);
      clds_risks->FieldDefs->Add("risk_sum", ftFloat);
      clds_risks->FieldDefs->Add("risk_premium", ftFloat);
      clds_risks->FieldDefs->Add("franshize", ftString, 255);
      clds_risks->CreateDataSet();

      clds_dms->FieldDefs->Add("dms_text", ftMemo);
      clds_dms->CreateDataSet();

      clds_shedul->FieldDefs->Add("num", ftInteger);
      clds_shedul->FieldDefs->Add("sum", ftFloat);
      clds_shedul->FieldDefs->Add("dt", ftDate);
      clds_shedul->CreateDataSet();

      clds_compensation->FieldDefs->Add("compensation_type", ftString, 255);
      clds_compensation->CreateDataSet();

      if(!source_id){
         data_sets->Add(m_api->dbGetCursor(res, "select 0 as black_print,t1.*,t2.*,t3.categories,t4.doc_type,trim(t5.last_name+' '+t5.first_name+' '+t5.second_name) as benefic_name from ((((casco_calc t1 left join casco_persons t2 on (t1.calc_id=t2.calc_id and t2.type_person=1)) left join casco_persons t5 on (t1.calc_id=t5.calc_id and t5.type_person=2)) left join ts_type t3 on t1.tstype_id=val(t3.code)) left join cascodoctype t4 on t2.document_type_id=t4.id_doc_type) where t1.calc_id=" + IntToStr(curr_id)));

         // ���������� + �����������
         data_sets->Add(m_api->dbGetCursor(res, "select type_person,trim(last_name+' '+first_name+' '+second_name) as fio_pm,phisical_sex,phisical_birth_date,document_issue_date,document_series,document_number from casco_persons where type_person>3 and calc_id=" + IntToStr(curr_id) + " and (select count(*) from casco_persons where type_person>3  and calc_id=" + IntToStr(curr_id) + ") < 4 order by type_person"));
         data_sets->Add(m_api->dbGetCursor(res, "select multidrive_text from cascomultidrivetext where status_id=" + IntToStr(status) + " and count_permitted<=" + IntToStr(count_permitted)));

         //�����
         if(q->FieldByName("select_dsago")->AsBoolean){
            clds_risks->Append();
            clds_risks->FieldByName("risk_name")->Value    = AnsiString("�����") + (q->FieldByName("ts_pricep")->AsBoolean ? "(�� � ��������)" : "");
            clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dsago_summa")->AsFloat;
            clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dsago")->AsFloat;
            clds_risks->FieldByName("franshize")->Value     = "� ������� ������ ��������������� �� �����";
         }
         if(q->FieldByName("select_ns")->AsBoolean){
            clds_risks->Append();
            clds_risks->FieldByName("risk_name")->Value    = "�� (���������� �������)";
            clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("ns_summa")->AsFloat;
            clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_ns")->AsFloat;
            clds_risks->FieldByName("franshize")->Value     = "�����������";
         }
         if(q->FieldByName("select_dms")->AsBoolean){
            clds_risks->Append();
            clds_risks->FieldByName("risk_name")->Value    = "���������� ������������ ������";
            clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dms_summa")->AsFloat;
            clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dms")->AsFloat;
            clds_risks->FieldByName("franshize")->Value     = "�����������";

            clds_dms->Append();
            clds_dms->FieldByName("dms_text")->Value = "�������������� �� �������� \"����������� ������ ��� ��������\" �������� ����, ���������� � ���������� �� � ������������ � ��������� �����������, �� �������� ���������� � ������������ � ������ ��� �� ����� ��.";
         }
         data_sets->Add(clds_risks);

         //������ ��������
         if(q->FieldByName("vznos2")->AsFloat > 0){
            clds_shedul->Append();
            clds_shedul->FieldByName("num")->Value = 2;
            clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos2")->AsFloat;
            clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos2")->AsDateTime;
         }
         if(q->FieldByName("vznos3")->AsFloat > 0){
            clds_shedul->Append();
            clds_shedul->FieldByName("num")->Value = 3;
            clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos3")->AsFloat;
            clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos3")->AsDateTime;
         }
         if(q->FieldByName("vznos4")->AsFloat > 0){
            clds_shedul->Append();
            clds_shedul->FieldByName("num")->Value = 4;
            clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos4")->AsFloat;
            clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos4")->AsDateTime;
         }
         data_sets->Add(clds_shedul);

         data_sets->Add(clds_dms);

         //���������� ������
         clds_compensation->Append();
         if(!variant_idx) clds_compensation->FieldByName("compensation_type")->Value = AnsiString("������� �. ������ �� ���� �� ") + (pay_id == 3 ? "����������� �����������." : "������ ������������.");
         else clds_compensation->FieldByName("compensation_type")->Value = AnsiString("������� ") + (variant_idx == 1 ? "�" : "�");

         data_sets->Add(clds_compensation);

         //���
         AddOpfAndLicense(data_sets);
      }
      else{
         data_sets->Add(m_api->dbGetCursor(res, "select '" + premium_string + "' as SumString,'" + premium_RUR_string + "' as SumRURString,t1.*,t2.*,t3.obobch_cod as full_name,t4.doc_type from casco_calc as t1,casco_persons as t2, ts_type as t3,cascodoctype as t4 where t1.calc_id=t2.calc_id and t1.tstype_id=val(t3.code) and t2.type_person=1 and t2.document_type_id=t4.id_doc_type and t1.calc_id=" + IntToStr(curr_id)));
         //����� �����
         data_sets->Add(m_api->dbGetCursor(res, "select * from gl_dict_banks where bank_id=" + IntToStr(bank_id)));
         data_sets->Add(m_api->dbGetCursor(res, "select depart_sb,number_sb,place_sb,address from casco_persons where type_person=2 and calc_id=" + IntToStr(curr_id)));

         // ���������� + �����������
         data_sets->Add(m_api->dbGetCursor(res, "select type_person,first_name,second_name,last_name,phisical_birth_date,document_issue_date,document_series,document_number from casco_persons where type_person>3 and calc_id=" + IntToStr(curr_id) + " and (select count(*) from casco_persons where type_person>3  and calc_id=" + IntToStr(curr_id) + ") < 4 order by type_person"));
         data_sets->Add(m_api->dbGetCursor(res, "select multidrive_text from cascomultidrivetext where status_id=" + IntToStr(status) + " and count_permitted<=" + IntToStr(count_permitted)));

         //�����
         if(q->FieldByName("select_dsago")->AsBoolean){
            clds_risks->Append();
            clds_risks->FieldByName("risk_name")->Value    = AnsiString("�����") + (q->FieldByName("ts_pricep")->AsBoolean ? "(�� � ��������)" : "");
            clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dsago_summa")->AsFloat;
            clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dsago")->AsFloat;
            clds_risks->FieldByName("franshize")->Value     = "� ������� ������ ��������������� �� �����";
         }
         if(q->FieldByName("select_ns")->AsBoolean){
            clds_risks->Append();
            clds_risks->FieldByName("risk_name")->Value    = "�� (���������� �������)";
            clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("ns_summa")->AsFloat;
            clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_ns")->AsFloat;
            clds_risks->FieldByName("franshize")->Value     = "�����������";
         }
         if(q->FieldByName("select_dms")->AsBoolean){
            clds_risks->Append();
            clds_risks->FieldByName("risk_name")->Value    = "���������� ������������ ������";
            clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dms_summa")->AsFloat;
            clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dms")->AsFloat;
            clds_risks->FieldByName("franshize")->Value    = "�����������";

            clds_dms->Append();
            clds_dms->FieldByName("dms_text")->Value = "�������������� �� �������� \"����������� ������ ��� ��������\" �������� ����, ���������� � ���������� �� � ������������ � ��������� �����������, �� �������� ���������� � ������������ � ������ ��� �� ����� ��.";
         }
         data_sets->Add(clds_risks);

         //������ ��������
         if(q->FieldByName("vznos2")->AsFloat > 0){
            clds_shedul->Append();
            clds_shedul->FieldByName("num")->Value = 2;
            clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos2")->AsFloat;
            clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos2")->AsDateTime;
         }
         if(q->FieldByName("vznos3")->AsFloat > 0){
            clds_shedul->Append();
            clds_shedul->FieldByName("num")->Value = 3;
            clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos3")->AsFloat;
            clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos3")->AsDateTime;
         }
         if(q->FieldByName("vznos4")->AsFloat > 0){
            clds_shedul->Append();
            clds_shedul->FieldByName("num")->Value = 4;
            clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos4")->AsFloat;
            clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos4")->AsDateTime;
         }
         data_sets->Add(clds_shedul);

         //���������� ������
         clds_compensation->Append();
         if(compensation_type.IsEmpty()){
            if(full_insur < 2) clds_compensation->FieldByName("compensation_type")->Value = AnsiString("������� �. ������ �� ���� �� ") + (pay_id == 3 ? "����������� �����������." : "������ ������������.");
            else{
               if(full_insur == 3) num_ds = "  17  ";
               else{
                  if(full_insur == 2){
                     num_ds = variant_idx == 0 ? "  18  " : "  19  ";
                  }
               }
               clds_compensation->FieldByName("compensation_type")->Value = "������� � � � ������������ � ��������� ��������������� ���������� <u>" + num_ds + "</u> � ���������� ������";
            }
         }
         else clds_compensation->FieldByName("compensation_type")->Value = compensation_type;
         data_sets->Add(clds_compensation);

         //������ �������
         TADOQuery *q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=" + IntToStr(product_id) + " and bank_id=" + IntToStr(bank_id) + " and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
         if(q_terms->IsEmpty()){
            m_api->dbCloseCursor(res, q_terms);
            q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=0 and bank_id=" + IntToStr(bank_id) + " and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
            if(q_terms->IsEmpty()){
               m_api->dbCloseCursor(res, q_terms);
               q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=" + IntToStr(product_id) + " and bank_id=0 and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
               if(q_terms->IsEmpty()){
                  m_api->dbCloseCursor(res, q_terms);
                  q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=0 and bank_id=0 and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
               }
            }
         }
         data_sets->Add(q_terms);

         data_sets->Add(clds_dms);

         //���
         AddOpfAndLicense(data_sets);
      }

      dynamic_cast<mops_api_014*>(m_api)->FastReport_Print(res, "�����" + (source_id ? AnsiString("(����������)") : empty_str) + " �� ������(��������)", data_sets);

      delete clds_compensation; delete clds_shedul; delete clds_dms; delete clds_risks;
      delete data_sets;
   }

   delete fdbl;
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void Cancellation_Reissue(const int dogovor_type)
{
   TDateTime dt = Date();
   int id = m_api->dbInsert_Empty_Calc(res), region_id = m_api->vrGetVariable(res, "KASKO_Territory").Trim().ToIntDef(77);
   if(!region_id)
   {
     region_id = 77;
   }
   
   AnsiString str(""), agent_name(""), sale_place(""), xml_user = m_api->Get_Agent_Data_From_APO2_SOAP_Server_By_AgentID(res, empty_str, dt);
   if(!xml_user.IsEmpty())
   {
      _di_IXMLDocument XMLDoc_User = NewXMLDocument();
      XMLDoc_User->Active = true;
      XMLDoc_User->LoadFromXML(xml_user);
      _di_IXMLNode Root_User = XMLDoc_User->DocumentElement, agents, agent;
      agents = Root_User->ChildNodes->FindNode("agents");
      if(agents)
      {
        agent = agents->ChildNodes->FindNode("agent");
      }
      if(agent)
      {
         agent_name = AnsiString(agent->Attributes["full_name"]);
         sale_place = m_api->Internal_Prepare_SQL_Text(res, AnsiString(agent->Attributes["branch_name"]));
      }
      delete XMLDoc_User;
   }

   m_api->dbExecuteQuery(res, str.sprintf("insert into casco_calc (calc_id,source_id,bank_id,region_id,tstype_id,ts_model_id,max_massa,seat_count,risk_id,risk_main,status_idx,ts_year,variant_idx,srok_month,ts_novoe,bez_ogr,multidrive,fr_instead_k1,pay_id,prolong,prev_ubitki_idx,osago_idx,ts_count,ks,ka,franshiza,str_summa,ts_cost,select_ns,select_dsago,ns_summa,ts_pricep,dsago_summa,valuta,valuta_kurs,benef_whois,key_count,ts_power,ns_variant,ns_seat_count,dop_obor,spec_ts,dop_sog,vznos1,vznos2,vznos3,no_osmotr,osmotr,payment_id,payment_doc_id,premium_main_risk,premium_dsago,premium_ns,premiya_all,srok_time_s,srok_time_po,project_id,ts_doc_type,krs_idx,type_franshiza,kpr,programm_id,polis_id,payed_sum,dogovor_type,date_rast,date_zayavl,agent,sale_place) "
                                          "values (%i,0,0,%i,2,0,0,0,2,'_ROOT1000000KASKOA1024221;_ROOT1000000KASKOA1024222',0,%i,0,12,0,0,100,0,3,0,-1,0,1,1,1,'',0,0,0,0,0,0,0,'RUR',1,-1,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'00:00','23:59',0,1,1,1,1,0,0,0,%i,DATE(),DATE(),'%s','%s')", id, region_id, YearOf(dt), dogovor_type, agent_name.c_str(), sale_place.c_str()));

   m_api->dbSet_Main_Grid_Current_CalcID(res, id);
   if(dogovor_type == 3 || dogovor_type == 5) m_api->Raschet_Set_Status_id(res, id, 8);
   else m_api->Raschet_Set_Status_id(res, id, 13);
   m_api->Module_Refresh_Main_Grid(res);
   // ��������� ����� ����� ���������� ������, �� ��-��� �� ����������� � ���� ������ ������
   m_api->Application_Press_Button(res, "��������"); // �� ���, � ���� ....
}
//---------------------------------------------------------------------------
void ExportReportAnderr()
{
   AnsiString filename(""), anderr_comm("");
   Map_Int_Str filter;
   int fltr_index(0);
   bool is_ok(false);

   TfRepParams *frp = new TfRepParams(0, m_api);
   if(frp->ShowModal() == mrOk){
      TADOQuery *q = m_api->dbGetCursor(res, "select " + IntToStr(frp->Tag) + " as type_dg," + report_anderr_sql + frp->GetFilter());
      TClientDataSet *clds = new TClientDataSet(0);
      clds->FieldDefs->Add("calc_id", ftInteger);
      clds->FieldDefs->Add("anderr_comm", ftMemo);
      clds->CreateDataSet();
      for(q->First(); !q->Eof; q->Next()){
         int m_id = q->FieldByName("comm_anderr_mid")->AsInteger;
         if(m_id) m_api->dbReadWriteInternalMemo(res, anderr_comm, m_id, true, "casco_memo");
         else anderr_comm = q->FieldByName("agent_comm")->AsString;
         clds->Append();
         clds->FieldByName("calc_id")->Value = q->FieldByName("calc_id")->AsInteger;
         clds->FieldByName("anderr_comm")->Value = anderr_comm;
         clds->Post();
      }
      clds->Close();
      TList *lst_q = new TList();
      lst_q->Add(q);
      lst_q->Add(clds);
      TSaveDialog *sd = new TSaveDialog(0);
      MakeExportFilters(sd, &di, filter);
      if(sd->Execute()){
         filename = sd->FileName;
         fltr_index = sd->FilterIndex;
         dynamic_cast<mops_api_014*>(m_api)->FastReport_Export(res, "����� �� ���������", lst_q, filename, 0, filter[fltr_index]);
         is_ok = true;
      }
      delete sd;
      delete lst_q;
      m_api->dbCloseCursor(res, q);
      delete clds;
   }

   delete frp;

   if(is_ok) ShellExecute(0, "open", (filename + "." + filter[fltr_index].LowerCase()).c_str(), "", "", SW_SHOW);
}
//---------------------------------------------------------------------------
void SendMonthReport(const TDateTime& dt_s, const TDateTime& dt_po)
{
   AnsiString filename = m_api->Excel_tmp_path + "\\��������_" + StringReplace(ander_fio, space_str, underline_str, rf) + "_" + dt_po.FormatString("ddmmyyyy"),
              anderr_comm("");
   TStringList *list_files = new TStringList();

   TADOQuery *q = m_api->dbGetCursor(res, "select 0 as type_dg," + report_anderr_sql + " and t5.status_id in (3,4) and t5.date_add>=" + m_api->Internal_Convert_Date_To_SQL(res, dt_s) + " and t5.date_add<" + m_api->Internal_Convert_Date_To_SQL(res, dt_po));

   TClientDataSet *clds = new TClientDataSet(0);
   clds->FieldDefs->Add("calc_id", ftInteger);
   clds->FieldDefs->Add("anderr_comm", ftMemo);
   clds->CreateDataSet();
   for(q->First(); !q->Eof; q->Next()){
      int m_id = q->FieldByName("comm_anderr_mid")->AsInteger;
      if(m_id) m_api->dbReadWriteInternalMemo(res, anderr_comm, m_id, true, "casco_memo");
      else anderr_comm = q->FieldByName("agent_comm")->AsString;
      clds->Append();
      clds->FieldByName("calc_id")->Value = q->FieldByName("calc_id")->AsInteger;
      clds->FieldByName("anderr_comm")->Value = anderr_comm;
      clds->Post();
   }
   clds->Close();
   TList *lst_q = new TList();
   lst_q->Add(q);
   lst_q->Add(clds);

   try{
      dynamic_cast<mops_api_014*>(m_api)->FastReport_Export(res, "����� �� ���������", lst_q, filename, 0, "XLS");
      list_files->Add(filename + ".xls");
   }
   catch(...) {}
   try{
      dynamic_cast<mops_api_014*>(m_api)->FastReport_Export(res, "����� �� ���������", lst_q, filename, 0, "ODS");
      list_files->Add(filename + ".ods");
   }
   catch(...) {}
   /*try{
      dynamic_cast<mops_api_014*>(m_api)->FastReport_Export(res, "����� �� ���������", lst_q, filename, 0, "PDF");
      list_files->Add(filename + ".pdf");
   }
   catch(...) {}*/
   try{
      m_api->send_email_using_smtp_server(res, ander_email, "apo@rgs.ru" /*"oleg_dmitriev@rgs.ru"*/, "����������� ����� " + ander_fio, empty_str, list_files, empty_str, 25, empty_str, empty_str);
   }
   catch(Exception& ex){
      m_api->send_email_using_smtp_server(res, empty_str, "apo@rgs.ru" /*"oleg_dmitriev@rgs.ru"*/, "����������� ����� " + ander_fio, empty_str, list_files, empty_str, 25, empty_str, empty_str);
   }

   delete lst_q;
   m_api->dbCloseCursor(res, q);
   delete clds;

   try{
      for(int i = 0; i < list_files->Count; ++i) DeleteFile(list_files->Strings[i]);
   }
   catch(...) {}
   delete list_files;

   m_api->vrSetVariable(res, "KASKO_report_last_date_export", IntToStr((int)dt_po.Val));
}

//---------------------------------------------------------------------------
void Get_Main_Menu(TMainMenu** M_Menu)
{
	//log("����� � Get_Main_Menu");



   if(*M_Menu) delete *M_Menu;
   *M_Menu = 0;
   *M_Menu = new TMainMenu(0);
   
   TMenuItem *mp = new TMenuItem(*M_Menu);
   mp->Caption = "�������";
   mp->Name = "dog";
   mp->Tag  = 100;
   (*M_Menu)->Items->Add(mp);

   TMenuItem *md = new TMenuItem(*M_Menu);
   md->Caption = "��������";
   md->Name = "d1";
   (*M_Menu)->Items->Add(md);

   if(di.is_ander_login){
      TMenuItem *mr = new TMenuItem(*M_Menu);
      mr->Caption = "������";
      mr->Name = "rep";
      (*M_Menu)->Items->Add(mr);

      TMenuItem *mra = new TMenuItem(mr);
      mra->Caption = "����� ������������";
      mra->Name = "rep_a";
      mra->Tag  = 23;
      mr->Add(mra);
   }
   /*else{
      TMenuItem *mo = new TMenuItem(*M_Menu);
      mo->Caption = "���������";
      mo->Name = "opt";
      (*M_Menu)->Items->Add(mo);

      TMenuItem *mo_1 = new TMenuItem(mo);
      mo_1->Caption = "��������������� ������";
      mo_1->Name = "opt_1";
      mo_1->Tag  = 24;
      mo->Add(mo_1);
      mo_1->Checked = m_api->vrGetVariable(res, "KASKO_PreCalc").ToIntDef(1);
   } */

   TMenuItem *md_11 = new TMenuItem(mp);
   md_11->Caption = "��������";
   md_11->Name    = "d1_11";
   md_11->Tag     = 20;
   mp->Add(md_11);
   md_11->Enabled = !di.is_ander_login;

   TMenuItem *md_22 = new TMenuItem(mp);
   md_22->Caption = "��������";
   md_22->Name    = "d1_22";
   md_22->Tag     = 21;
   mp->Add(md_22);

   TMenuItem *md_33 = new TMenuItem(mp);
   md_33->Caption = "�������";
   md_33->Name    = "d1_33";
   md_33->Tag     = 22;
   mp->Add(md_33);

   /*TMenuItem *lne = new TMenuItem(mp);
   lne->Caption = "-";
   lne->Name    = "lne";
   mp->Add(lne);

   TMenuItem *md_1_2 = new TMenuItem(mp);
   md_1_2->Caption = "��������� �� ������� �������";
   md_1_2->Name    = "d1_1_2";
   md_1_2->Tag     = 11;
   mp->Add(md_1_2);

   TMenuItem *line = new TMenuItem(mp);
   line->Caption = "-";
   line->Name    = "line";
   mp->Add(line);

   mp_1 = new TMenuItem(mp);
   mp_1->Caption = "��������������";
   mp_1->Name    = "prolong";
   mp_1->Tag     = 12;
   mp->Add(mp_1);

   mp_3 = new TMenuItem(mp);
   mp_3->Caption = "������������";
   mp_3->Name    = "reissue";
   //mp_3->Enabled = m_api->vrGetVariable(res, "kasko_reiss_cancel").ToIntDef(0);
   mp_3->Tag   = 18;
   mp->Add(mp_3);

   mp_7 = new TMenuItem(mp);
   mp_7->Caption = "������ ���������";
   mp_7->Name    = "print_dubl";
   mp_7->Tag     = 17;
   mp->Add(mp_7);    */

   TMenuItem *mp_line = new TMenuItem(mp);
   mp_line->Caption = "-";
   mp_line->Name    = "mp_line";
   mp->Add(mp_line);

   TMenuItem *mp_4 = new TMenuItem(mp);
   mp_4->Caption = "������������";
   mp_4->Name    = "agreed";
   mp->Add(mp_4);

   mp_4_1 = new TMenuItem(mp_4);
   mp_4_1->Caption = "���������";
   mp_4_1->Name    = "agreed1";
   mp_4_1->Tag     = 15;
   mp_4->Add(mp_4_1);

   TMenuItem *mp_4_2 = new TMenuItem(mp_4);
   mp_4_2->Caption = "�������";
   mp_4_2->Name    = "agreed2";
   mp_4_2->Tag     = 16;
   mp_4->Add(mp_4_2);

   TMenuItem *md_1 = new TMenuItem(md);
   md_1->Caption = "��������� XML";
   md_1->Name    = "d1_1";
   md_1->Tag     = 1;
   md->Add(md_1);

   TMenuItem *md_2 = new TMenuItem(md);
   md_2->Caption = "��������� (������ ���2)";
   md_2->Name    = "d1_2";
   md->Add(md_2);

   TMenuItem *md_2_1_1 = new TMenuItem(md_2);
   md_2_1_1->Caption = "���";
   md_2_1_1->Name    = "d1_2_1_1";
   md_2_1_1->Tag     = 2;
   md_2->Add(md_2_1_1);

   TMenuItem *md_2_1_2 = new TMenuItem(md_2);
   md_2_1_2->Caption = "����� � ����������";
   md_2_1_2->Name    = "d1_2_1_2";
   md_2_1_2->Tag     = 3;
   md_2->Add(md_2_1_2);

   TMenuItem *md_2_1_3 = new TMenuItem(md_2);
   md_2_1_3->Caption = "��������� � �������";
   md_2_1_3->Name    = "d1_2_1_3";
   md_2_1_3->Tag     = 4;
   md_2->Add(md_2_1_3);
}
//---------------------------------------------------------------------------
void SetDisableEnable(int mp4 = 0, int mp1 = 0, int mp2 = 0, int mp3 = 0)
{
   if(mp_1)   mp_1->Enabled   = mp1;
   if(mp_4_1) mp_4_1->Enabled = mp4;
   if(mp_7)   mp_7->Enabled   = mp1;
}
//---------------------------------------------------------------------------
void DisableMenuItems()
{
  switch(m_api->Raschet_Get_Status_id(res, m_api->dbGet_Main_Grid_Current_CalcID(res))){
      case 0: /*case 1:*/ case 5: case 6: case 9: case 10: SetDisableEnable(); break;
      case 3: case 4: SetDisableEnable(di.is_ander_login); break;
      case 1: case 2: case 13: case 14: SetDisableEnable(1); break;
      case 11: SetDisableEnable(0, 1, 1, 1); break;
   }
}
//---------------------------------------------------------------------------
void OnMenuClick(TObject *Sender)
{
   TMenuItem *mi = dynamic_cast<TMenuItem*>(Sender);
   TOpenDialog *od;
   TfrmInfoRast *fi;
   switch(mi->Tag){
      case 1:
         od = new TOpenDialog(0);
         if(od->Execute()) m_api->Analyse_and_Load_XML_f(res, od->FileName);
         delete od;
         break;
      case 2:
         XMLSave(1);
         break;
      case 3:
         XMLSave(2);
         break;
      case 4:
         XMLSave(3);
         break;
      case 11:
         LoadDataFromARM();
         break;
      case 12:
         Prolongation();
         break;
      case 13:
         fi = new TfrmInfoRast(0);
         fi->ShowModal();
         delete fi;
         //Cancellation_Reissue(3);
         break;
      case 15:
         SendToAgreement();
         break;
      case 16:
         GetAgreed();
         break;
      case 17:
         PrintDuble();
         break;
      case 18:
         Cancellation_Reissue(4);
         break;
      case 20:
         m_api->Application_Press_Button(res, "��������");
         break;
      case 21:
         m_api->Application_Press_Button(res, "��������");
         break;
      case 22:
         m_api->Application_Press_Button(res, "�������");
         break;
      case 23:
         ExportReportAnderr();
         break;
      case 24:
         mi->Checked = !mi->Checked;
         m_api->vrSetVariable(res, "KASKO_PreCalc", mi->Checked ? 1 : 0);
         break;
      /*case 25:
         Cancellation_Reissue(5);
         break;*/
      case 100: DisableMenuItems();
   }
}
//---------------------------------------------------------------------------
void NewNode(_di_IXMLNode child_node, const AnsiString& attr, const AnsiString& text)
{
   child_node->Attributes["code"] = attr == -1 ? empty_str : attr;
   child_node->Text = text;
}
//---------------------------------------------------------------------------
AnsiString GetCode(TADOQuery* q)
{
   int code(0);

   if(q->FieldByName("status")->AsInteger) code = 2;
   switch(q->FieldByName("type_person")->AsInteger){
      case 1:  code += 4;  break;
      case 2:  code += 16; break;
      //case 3:  code += 8;  break;
      default: code += 32; break;
   }

   return IntToStr(code);
}
//---------------------------------------------------------------------------
bool Copy(AnsiString &XMLData)
{
   int i_val;
   TDateTime dt;
   try{
      TStringList* sl = new TStringList();
      _di_IXMLDocument XMLDoc = NewXMLDocument();

      XMLDoc->Active = true;
      XMLDoc->LoadFromXML(XMLData);

      _di_IXMLNode Root, ts, persons, child_node, temp_node, contacts;

      Root    = XMLDoc->DocumentElement;
      ts      = Root->ChildNodes->FindNode("ts");
      persons = Root->ChildNodes->FindNode("persons");

      TADOQuery *q = m_api->dbGetCursor(res, "select t1.*,t2.*,t3.full_name,t5.terr_name from casco_calc as t1,casco_persons as t2,ts_type as t3,gl_dict_terr_osago_kasko as t5 where t1.calc_id=t2.calc_id and t1.tstype_id=val(t3.code) and t1.region_id=t5.map_id and t1.calc_id=" + IntToStr(m_api->dbGet_Main_Grid_Current_CalcID(res)));
      //ShowMessage(Root->ChildNodes->FindNode("region")->Text);

      FillNode(Root->ChildNodes->FindNode("region"), q->FieldByName("region_id")->AsString, q->FieldByName("terr_name")->AsString);
      FillNode(Root->ChildNodes->FindNode("sale_channel"), q->FieldByName("sale_channel_id")->AsString, q->FieldByName("sale_channel")->AsString);

      //����� ������������� ��������
      i_val = q->FieldByName("ts_model_id")->AsInteger;
      FillNode(ts->ChildNodes->FindNode("type_ts"), q->FieldByName("tstype_id")->AsString, q->FieldByName("full_name")->AsString);
      FillNode(ts->ChildNodes->FindNode("marka"),  AddNulls(IntToStr((i_val / 1000000) * 1000000)), q->FieldByName("ts_marka")->AsString);
      FillNode(ts->ChildNodes->FindNode("model"),  AddNulls(IntToStr(i_val)),                       q->FieldByName("ts_model")->AsString);

      if(q->FieldByName("ident_type")->AsInteger){
         ts->ChildNodes->FindNode("chassis")->Text       = q->FieldByName("ts_vin")->AsString;
         ts->ChildNodes->FindNode("body")->Text          = q->FieldByName("ts_vin")->AsString;
         ts->ChildNodes->FindNode("engine_number")->Text = q->FieldByName("ts_vin")->AsString;
      }
      else ts->ChildNodes->FindNode("VIN")->Text = q->FieldByName("ts_vin")->AsString;

      ts->ChildNodes->FindNode("year")->Text = q->FieldByName("ts_year")->AsString;
      ts->ChildNodes->FindNode("power")->Text = q->FieldByName("ts_power")->AsString;
      ts->ChildNodes->FindNode("state_reg_sign")->Text = q->FieldByName("ts_znak")->AsString;
      ts->ChildNodes->FindNode("max_mass")->Text = q->FieldByName("max_massa")->AsString;
      ts->ChildNodes->FindNode("passengers_quantity")->Text = q->FieldByName("seat_count")->AsString;
		FillNode(ts->ChildNodes->FindNode("use_purpose"), q->FieldByName("usage_purpose")->AsInteger ? "9" : "1", q->FieldByName("usage_purpose")->AsInteger ? "������" : "������"); 
		ts->ChildNodes->FindNode("use_description")->Text = q->FieldByName("usage_purpose_text")->AsString;

      dt = q->FieldByName("pts_date")->AsDateTime;
      i_val = q->FieldByName("ts_doc_type")->AsInteger;
      temp_node = ts->ChildNodes->FindNode("ts_document");
      temp_node->Attributes["code"]       = IntToStr(i_val);
      temp_node->Attributes["series"]     = q->FieldByName("pts_seria")->AsString;
      temp_node->Attributes["number"]     = q->FieldByName("pts_number")->AsString;
      temp_node->Attributes["issue_date"] = dt.Val ? dt.DateString() : empty_str;
      temp_node->Text = m_api->dbGetStringFromQuery(res, "select [vehicle_registr_type_name] from casco_vehdoctype where vehicle_registr_type_id=" + IntToStr(i_val));

      //����� ����������, ���������� � �������� �����������
      persons = Root->ChildNodes->FindNode("persons");
      for(q->First(); !q->Eof; q->Next()){
         child_node = persons->AddChild("person");
         child_node->Attributes["code"] = GetCode(q);
         child_node->AddChild("first_name")->Text          = q->FieldByName("first_name")->AsString;
         child_node->AddChild("second_name")->Text         = q->FieldByName("second_name")->AsString;
         child_node->AddChild("last_name")->Text           = q->FieldByName("last_name")->AsString;
         child_node->AddChild("inn")->Text                 = q->FieldByName("inn")->AsString;
         child_node->AddChild("opf_id")->Text              = q->FieldByName("opf_id")->AsString;
         child_node->AddChild("ogrn")->Text                = q->FieldByName("ogrn")->AsString;
         dt = q->FieldByName("phisical_birth_date")->AsDateTime;
         child_node->AddChild("physical_bitrh_date")->Text = dt.Val ? dt.DateString() : empty_str;
         child_node->AddChild("physical_sex")->Text        = IntToStr(q->FieldByName("phisical_sex")->AsInteger - 1);
         child_node->AddChild("citizenship")->Text         = q->FieldByName("citizenship")->AsString;
         i_val = q->FieldByName("addr_mid")->AsInteger;
         temp_node = child_node->AddChild("addresses");
         AnsiString memo_text("��� �����=\r\n������ ������\r\n�����������=\r\n������=\r\n�����=\r\n�����=\r\n�������=\r\n�����=\r\n���=\r\n����� �������=\r\n��������=\r\n������=");
         if(i_val) m_api->dbReadWriteInternalMemo(res, memo_text, i_val, true, "casco_memo");
         sl->Text = memo_text;
         temp_node->AddChild("code_kladr")->Text   = sl->Values["��� �����"];
         temp_node->AddChild("filter_kladr")->Text = sl->Values["������ ������"];
         temp_node->AddChild("country")->Text      = sl->Values["�����������"];
         temp_node->AddChild("region")->Text       = sl->Values["������"];
         temp_node->AddChild("place")->Text        = sl->Values["�����"];
         temp_node->AddChild("area")->Text         = sl->Values["�����"];
         temp_node->AddChild("zip")->Text          = sl->Values["������"];
         temp_node->AddChild("street")->Text       = sl->Values["�����"];
         temp_node->AddChild("house")->Text        = sl->Values["���"];
         temp_node->AddChild("building")->Text     = sl->Values["����� �������"];
         temp_node->AddChild("flat")->Text         = sl->Values["��������"];
         temp_node->AddChild("exact_address")->Text= q->FieldByName("address")->AsString;
         temp_node = child_node->AddChild("documents");
         NewNode(temp_node->AddChild("document"), q->FieldByName("document_type_id")->AsString, m_api->dbGetStringFromQuery(res, "select doc_type from cascodoctype where id_doc_type=" + q->FieldByName("document_type_id")->AsString));
         temp_node->AddChild("document_series")->Text             = q->FieldByName("document_series")->AsString;
         temp_node->AddChild("document_number")->Text             = q->FieldByName("document_number")->AsString;
         dt = q->FieldByName("document_issue_date")->AsDateTime;
         temp_node->AddChild("document_issue_date")->Text         = dt.Val ? dt.DateString() : empty_str;
         temp_node->AddChild("document_issue_organization")->Text = q->FieldByName("document_issue_org")->AsString;
         temp_node = child_node->AddChild("contacts")->AddChild("contact");
         temp_node->Attributes["contact_type_id"] = AnsiString(3);
         temp_node->Attributes["contact_data"] = q->FieldByName("phone_mobil")->AsString;
         temp_node->Attributes["spam"] = q->FieldByName("sms_sending")->AsString;
      }

      m_api->dbCloseCursor(res, q);
      XMLDoc->SaveToXML(XMLData);
      if(m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\kasko_copy.xml");
      delete XMLDoc; delete sl;
   }
   catch(...){ return false; }

   return true;
}
//---------------------------------------------------------------------------
bool Paste(const AnsiString& XMLData)
{
   TDateTime dt, dt_s = Date(), dt_po = IncDay(IncYear(dt_s), -1);
   double d_val;
   int i_val, status(0), type(4), memo_id(0), age(0), expir(0), sms(-1), region_id = m_api->vrGetVariable(res, "KASKO_Territory").Trim().ToIntDef(77);
   bool result(true);

   if(XMLData.IsEmpty()) return false;

   if(!region_id) region_id = 77;
   AnsiString str(""), region_default = m_api->dbGetStringFromQuery(res, "select subject_federation_name from gl_dict_subject_rf where [id]=" + IntToStr(region_id));

   TStringList *addr = new TStringList();

   long id = m_api->dbInsert_Empty_Calc(res);
   m_api->dbExecuteQuery(res, str.sprintf("update _mops_calcs_ set id_polzovatelya=%i where [id]=%i", m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0), id));
   m_api->dbExecuteQuery(res, str.sprintf("insert into casco_calc (calc_id,polis_id,source_id,bank_id,region_id,tstype_id,ts_model_id,max_massa,seat_count,risk_id,risk_main,status_idx,ts_year,variant_idx,srok_month,ts_novoe,bez_ogr,multidrive,fr_instead_k1,pay_id,prolong,prev_ubitki_idx,osago_idx,ts_count,ks,ka,franshiza,str_summa,ts_cost,select_ns,select_dsago,ns_summa,ts_pricep,dsago_summa,valuta,valuta_kurs,benef_whois,key_count,ts_power,ns_variant,ns_seat_count,dop_obor,spec_ts,dop_sog,vznos1,vznos2,vznos3,no_osmotr,osmotr,payment_id,payment_doc_id,premium_main_risk,premium_dsago,premium_ns,premiya_all,krs_idx,type_franshiza,dsago_territory_id,kkv,calc_k5_k6,is_registration_ts,polis_date,srok_date_s,srok_date_po) "
                                                             "values (%i,0,0,0,%i,2,0,0,0,2,'_ROOT1000000KASKOA1024221;_ROOT1000000KASKOA1024222',0,%i,0,12,0,1,0,0,3,0,-1,0,1,1,1,'',0,0,0,0,0,0,0,'RUR',1,-1,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,-1,%s,%s,%s)", id, region_id, YearOf(dt_s), m_api->Internal_Convert_Date_To_SQL(res, dt_s.DateString(), false), m_api->Internal_Convert_Date_To_SQL(res, dt_s.DateString(), false), m_api->Internal_Convert_Date_To_SQL(res, dt_po.DateString(), false)));

   TADOQuery *q = m_api->dbGetCursor(res, "select calc_id,region_id,region_isp_id,tstype_id,ts_marka,ts_marka_calc,ts_model,ts_model_id,ts_year,ident_type,ts_vin,is_registration_ts,ts_znak,ts_doc_type,pts_seria,pts_number,ts_power,pts_date,status_idx,fio,sale_channel,sale_channel_id,bez_ogr,multidrive,multidrive_pc,sms_sending,risk_main from casco_calc where [calc_id]=" + IntToStr(id), 0, 1);
   q->Edit();

   _di_IXMLDocument XMLDoc = NewXMLDocument();

   try{
      XMLDoc->Active = true;
      //XMLDoc->LoadFromFile("F:\\osago.xml");
      XMLDoc->LoadFromXML(XMLData);
      if(m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\kasko_paste.xml");

      _di_IXMLNode Root = XMLDoc->DocumentElement, ts, persons, child_node;

      ts      = Root->ChildNodes->FindNode("ts");
      persons = Root->ChildNodes->FindNode("persons");

      i_val = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_regions where terr_name='" + AnsiString(Root->ChildNodes->FindNode("region")->Text) + "'");
      if(i_val) q->FieldByName("region_id")->Value = i_val;


      child_node = Root->ChildNodes->FindNode("sale_channel");
      q->FieldByName("sale_channel")->Value = child_node->Text;
      if(TryStrToInt(child_node->Attributes["code"], i_val)) q->FieldByName("sale_channel_id")->Value = i_val;

      if(TryStrToInt(ts->ChildNodes->FindNode("type_ts")->Attributes["code"], i_val)){
         if(i_val) q->FieldByName("tstype_id")->Value = i_val;
      }
      else{
         i_val = m_api->dbGetIntFromQuery(res, "select val(code) from ts_type where full_name='" + AnsiString(ts->ChildNodes->FindNode("type_ts")->Text) + "'");
         if(i_val) q->FieldByName("tstype_id")->Value = i_val;
      }
      q->FieldByName("ts_marka")->Value      = ts->ChildNodes->FindNode("marka")->Text;
      q->FieldByName("ts_marka_calc")->Value = ts->ChildNodes->FindNode("marka")->Text;
      if(TryStrToFloat(ts->ChildNodes->FindNode("model")->Attributes["code"], d_val)) q->FieldByName("ts_model_id")->Value = d_val;
      else{
         d_val = m_api->dbGetFloatFromQuery(res, "select val(code) from gl_dict_carrier_models where model_name='" + AnsiString(ts->ChildNodes->FindNode("model")->Text) + "'");
         if(d_val) q->FieldByName("ts_model_id")->Value = d_val;
      }
      q->FieldByName("ts_model")->Value = ts->ChildNodes->FindNode("model")->Text;

      AnsiString ident_number = ts->ChildNodes->FindNode("VIN")->Text, reg_plate = ts->ChildNodes->FindNode("state_reg_sign")->Text;
      if(ident_number.IsEmpty()){
         ident_number = ts->ChildNodes->FindNode("chassis")->Text;
         if(ident_number.IsEmpty()){
            ident_number = ts->ChildNodes->FindNode("body")->Text;
            if(!ident_number.IsEmpty()) q->FieldByName("ident_type")->Value = 1;
         }
         else q->FieldByName("ident_type")->Value = 1;
      }
      q->FieldByName("ts_vin")->Value = ident_number;

      if(!reg_plate.IsEmpty()){
         q->FieldByName("is_registration_ts")->Value = 1;
         if(reg_plate.Length() > 7) q->FieldByName("region_isp_id")->Value = reg_plate.SubString(7, reg_plate.Length() - 6).ToIntDef(0);
      }
      q->FieldByName("ts_znak")->Value = reg_plate;

      if(TryStrToInt(ts->ChildNodes->FindNode("year")->Text, i_val)) q->FieldByName("ts_year")->Value = i_val;
      if(TryStrToFloat(ts->ChildNodes->FindNode("power")->Text, d_val)) q->FieldByName("ts_power")->Value = d_val;

      child_node = ts->ChildNodes->FindNode("ts_document");
      q->FieldByName("ts_doc_type")->Value = AnsiString(child_node->Attributes["code"]).ToIntDef(1);
      q->FieldByName("pts_seria")->Value  = AnsiString(child_node->Attributes["series"]);
      q->FieldByName("pts_number")->Value = AnsiString(child_node->Attributes["number"]);
      if(TryStrToDate(child_node->Attributes["issue_date"], dt)) q->FieldByName("pts_date")->Value = dt;

      for(int i = 0, cnt = persons->ChildNodes->GetCount(); i < cnt; ++i, age = expir = 0){
         child_node = persons->ChildNodes->Nodes[i];
         if(child_node->HasAttribute("code") && TryStrToInt(AnsiString(child_node->Attributes["code"]), i_val)){
            AnsiString fname = child_node->ChildNodes->FindNode("first_name")->Text, sname = child_node->ChildNodes->FindNode("second_name")->Text, lname = child_node->ChildNodes->FindNode("last_name")->Text,
                       inn = child_node->ChildNodes->FindNode("inn")->Text, opf_id = child_node->ChildNodes->FindNode("opf_id")->Text, ogrn = child_node->ChildNodes->FindNode("ogrn")->Text, citizenship = child_node->ChildNodes->FindNode("citizenship")->Text,
                       bdate = child_node->ChildNodes->FindNode("physical_bitrh_date")->Text, sex = child_node->ChildNodes->FindNode("physical_sex")->Text, exact_addr = child_node->ChildNodes->FindNode("addresses")->ChildNodes->FindNode("exact_address")->Text,
                       doc_type = child_node->ChildNodes->FindNode("documents")->ChildNodes->FindNode("document")->Attributes["code"], doc_ser = child_node->ChildNodes->FindNode("documents")->ChildNodes->FindNode("document_series")->Text,
                       doc_num  = child_node->ChildNodes->FindNode("documents")->ChildNodes->FindNode("document_number")->Text, doc_org = child_node->ChildNodes->FindNode("documents")->ChildNodes->FindNode("document_issue_organization")->Text,
                       doc_date = child_node->ChildNodes->FindNode("documents")->ChildNodes->FindNode("document_issue_date")->Text, ph_mob(""), ph_home(""), ph_rab("");

            MakeKladrAddr(child_node->ChildNodes->FindNode("addresses"), addr, memo_id);
            status = ((i_val & 2) == 2 ? 1 : 0);
            GetPhones(child_node->ChildNodes->FindNode("contacts"), ph_mob, ph_home, ph_rab, sms);
            q->FieldByName("sms_sending")->Value = sms;  

            if((i_val & 4) == 4){
               q->FieldByName("status_idx")->Value = status;
               if(status){
                  q->FieldByName("bez_ogr")->Value    = false;
                  q->FieldByName("multidrive")->Value = -1;
                  q->FieldByName("multidrive_pc")->Value = -1;
                  q->FieldByName("risk_main")->Value = "_ROOT1000000KASKOA1024211;_ROOT1000000KASKOA1024212";
               }
               q->FieldByName("fio")->Value = Trim(lname + space_str + fname + space_str + sname);
               m_api->dbExecuteQuery(res, str.sprintf("insert into casco_persons values(%i,%i,1,'%s','%s','%s','%s',%0.f,'%s',%s,%i,%i,'%s',%i,'%s','%s',%s,'%s','%s','%s',0,0,'','',0,'%s','','',0,'%s',1,0,'')",
                                     id, status, fname.c_str(), sname.c_str(), lname.c_str(), inn.c_str(), (TryStrToFloat(opf_id, d_val) ? d_val : 0), ogrn.c_str(),
                                     (TryStrToDate(bdate, dt) ? m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) : null_str).c_str(),
                                     (TryStrToInt(sex, i_val) ? i_val + 1 : 0), memo_id, exact_addr.c_str(), (TryStrToInt(doc_type, i_val) ? i_val : 12), doc_ser.c_str(), doc_num.c_str(),
                                     (TryStrToDate(doc_date, dt) ? m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) : null_str).c_str(), doc_org.c_str(), ph_mob.c_str(), ph_home.c_str(), ph_rab.c_str(), citizenship.c_str()));
            }
            if((i_val & 8) == 8) m_api->dbExecuteQuery(res, str.sprintf("insert into casco_persons values(%i,%i,2,'%s','%s','%s','%s',%0.f,'%s',%s,%i,%i,'%s',%i,'%s','%s',%s,'%s','%s','%s',0,0,'','',0,'%s','','',0,'%s',1,0,'')",
                                     id, status, fname.c_str(), sname.c_str(), lname.c_str(), inn.c_str(), (TryStrToFloat(opf_id, d_val) ? d_val : 0), ogrn.c_str(),
                                     (TryStrToDate(bdate, dt) ? m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) : null_str).c_str(),
                                     (TryStrToInt(sex, i_val) ? i_val + 1 : 0), memo_id, exact_addr.c_str(), (TryStrToInt(doc_type, i_val) ? i_val : 12), doc_ser.c_str(), doc_num.c_str(),
                                     (TryStrToDate(doc_date, dt) ? m_api->Internal_Convert_Date_To_SQL(res, dt.DateString(), false) : null_str).c_str(), doc_org.c_str(), ph_mob.c_str(), ph_home.c_str(), ph_rab.c_str(), citizenship.c_str()));
            if((i_val & 32) == 32){
               q->FieldByName("bez_ogr")->Value    = false;
               q->FieldByName("multidrive")->Value = 100;
               q->FieldByName("multidrive_pc")->Value = 100;

               if(TryStrToDate(bdate, dt)) age = CalcYears(dt, Date());
               if(TryStrToDate(doc_date, dt)) expir = CalcYears(dt, Date());
               m_api->dbExecuteQuery(res, str.sprintf("insert into casco_persons values(%i,0,%i,'%s','%s','%s','',0,'',%s,%i,0,'%s',%i,'%s','%s',%s,'%s','','',%i,%i,'','',0,'','','',0,'��������',3,0,'')",
                                     id, type, fname.c_str(), sname.c_str(), lname.c_str(), (age > 0 ? m_api->Internal_Convert_Date_To_SQL(res, bdate, false) : null_str).c_str(),
                                     (TryStrToInt(sex, i_val) ? i_val + 1 : 0), region_default.c_str(), (TryStrToInt(doc_type, i_val) ? i_val : 17),  NormVIN_GN(m_api, doc_ser).c_str(), doc_num.c_str(),
                                     (expir > 0 ? m_api->Internal_Convert_Date_To_SQL(res, doc_date, false) : null_str).c_str(), doc_org.c_str(), age, expir));

               m_api->dbExecuteQuery(res, str.sprintf("insert into casco_permitted ([calc_id],[permitted_number],[phisical_birth_date],[document_issue_date],[age],[experience],[osago_ss]) values(%i,%i,%s,%s,%i,%i,0)",
                                     id, type - 3, (age > 0 ? m_api->Internal_Convert_Date_To_SQL(res, bdate, false) : null_str).c_str(), (expir > 0 ? m_api->Internal_Convert_Date_To_SQL(res, doc_date, false) : null_str).c_str(), age, expir));

               ++type;
            }
         }
      }
   }
   catch(Exception& ex) { result = false; }

   q->Post();
   m_api->dbCloseCursor(res, q);
   delete XMLDoc; delete addr;

   m_api->Module_Refresh_Main_Grid(res);

   return result;
}
//---------------------------------------------------------------------------
int On_User_Copy_Paste(AnsiString &XML, bool Copy_Flag)
{
   int result(0);

   if(Copy_Flag) result = Copy(XML);
   else          result = Paste(XML);

   return result;
}
//---------------------------------------------------------------------------
void Init_API(void* _Mops_Api)
{
   m_api = (mops_api_028*)_Mops_Api;

   TStringList *author_info = new TStringList();
   m_api->Get_Authenticated_User_Info(res, author_info);
   di.is_ander_login = (author_info->Values["�����������"] == "Ok");
   di.calc_info.anderr_summ_limit = StrToFloatStr(author_info->Values["personal_limit"]).ToDouble();
   di.calc_info.anderr_ka_limit   = StrToFloatStr(author_info->Values["personal_koeff"], one_str).ToDouble();
   di.calc_info.anderr_dsago      = author_info->Values["dsago"].ToIntDef(0);
   di.calc_info.anderr_variant_b  = author_info->Values["variant_b"].ToIntDef(0);
   di.calc_info.risk_model        = author_info->Values["risk_model"].ToIntDef(0);

   /*if(di.is_ander_login){
      ander_fio   = author_info->Values["���"];
      ander_email = author_info->Values["email_address"];
      int extraction = author_info->Values["extraction"].ToIntDef(0);
      //SendMonthReport(TDateTime(2013,2,18), TDateTime(2014,7,1));
      if(extraction){
         TDateTime dt_po = Date(), dt_s = TDateTime(m_api->vrGetVariable(res, "KASKO_report_last_date_export").ToIntDef(0));
         int first_send(0);
         if(!dt_s.Val){
            dt_s = TDateTime(2013, 2, 18);
            first_send = 1;
         }
         if(dt_s != dt_po && dt_po > dt_s){
            unsigned short y_dt_s, m_dt_s, d_dt_s, y_dt_po, m_dt_po, d_dt_po;
            dt_s.DecodeDate(&y_dt_s, &m_dt_s, &d_dt_s); dt_po.DecodeDate(&y_dt_po, &m_dt_po, &d_dt_po);
            if(d_dt_po == 1 || (d_dt_po != 1 && m_dt_po != m_dt_s && !first_send)) SendMonthReport(dt_s, dt_po);
         }
      }
   }*/
   delete author_info;

   GetPathDesktopUser();
}
//---------------------------------------------------------------------------
void Create_Frames(TList* frames, TStringList* frames_names)
{
   //if(nCreateFrames % 2) // �������� ��� ... �������-�� ���� �������� � dll-�� Create_Frames ������
   {

   ResetData();
   frames->Clear();
   frames_names->Clear();
   //if(!di.is_new_dogovor) di.dogovor_type = m_api->dbGetIntFromQuery(res, "select dogovor_type from casco_calc where calc_id=" + IntToStr(m_api->dbGet_Main_Grid_Current_CalcID(res)));

   TAnderrFrame *fap(0);

   //if(di.dogovor_type == 4){
      TFReissCalc *frs = new TFReissCalc(0, m_api, pi, pm, &di, &tsi);

      if(di.is_ander_login)
	  {
         fap = new TAnderrFrame(0, m_api, pi, pm, &tsi, &di);
         fap->vg_dateQT->Properties->Options->Editing = false;
         fap->f_reiss = frs;
         frames->Add(fap);
         frames_names->Add("������ ������������");
         frs->f_andr_pan = fap;
      }

      frames->Add(frs);
      frames_names->Add("�������������� ��������");

      TfrmItogi *fi = new TfrmItogi(0);
      frs->memo = fi->memoItogi;

      frames->Add(fi);
      frames_names->Add("������� �������� �������");
   /*}
   else{

      TfrmItogi *fi = new TfrmItogi(0);
      TFrameNew *f = new TFrameNew(0, m_api, pi, pm, &tsi, &di);
      f->memo = fi->memoItogi;
      f->SetAnderFIO(ander_fio);

      TFrame1 *fp;
      TframeOffCust *fo;
      TFramePreCalc *fpc;

      if(di.is_ander_login){
         fap = new TAnderrFrame(0, m_api, pi, pm, &tsi, &di);
         fap->f_calc = f;
         frames->Add(fap);
         frames_names->Add("������ ������������");
      }
      else{
         if(m_api->vrGetVariable(res, "KASKO_PreCalc").ToIntDef(1)){
            fpc = new TFramePreCalc(0, m_api, pi, pm, &tsi, &di);
            frames->Add(fpc);
            frames_names->Add("��������������� ������");
            fpc->Init();
            fpc->f_calc = f;
            f->f_pre_calc = fpc;
         }
      }

      fp = new TFrame1(0, m_api, pi, pm, &tsi, &di);
      fp->Prepare();
      fp->f_calc = f;
      f->f_print = fp;
      f->f_andr_pan = fap;

      if(!di.is_ander_login){
         fo = new TframeOffCust(0);
         f->f_off_cust = fo;
      }

      frames->Add(f);
      frames_names->Add("������");
      f->Init(); // ���������� ����, ����� ����� ������������ ��������� �� ������

      frames->Add(fi);
      frames_names->Add("������� �������� ��������");

      if(!di.is_ander_login){
         frames->Add(fo);
         frames_names->Add("����������� ��� �������");
      }

      frames->Add(fp);
      frames_names->Add("������ ��� ������ ����������");

      frames->Add(0);
      frames_names->Add("���� ������������");
   } */

   }

   nCreateFrames++;
}
//-----------------------------------------------------------------------------
int Save_Frames(TList* frames, long id_calc)
{
   TADOQuery *q = m_api->dbGetCursor(res, "select * from casco_calc where calc_id=" + IntToStr(id_calc), 0, 0);

   q->CursorLocation = clUseServer;
   q->Open();

   if(q->IsEmpty()) { q->Insert(); }
   else             { q->Edit(); }

   q->FieldByName("calc_id")->Value = id_calc;

   //if(di.dogovor_type == 4){
      if(di.is_ander_login)
	  {
         ((TAnderrFrame*)(frames->Items[0]))->SaveFrame(q);
         ((TFReissCalc*)(frames->Items[1]))->SaveFrame(q);
      }
      else
	  {
		  ((TFReissCalc*)(frames->Items[0]))->SaveFrame(q);
	  }
  /*}
   else{
      int is_precalc = m_api->vrGetVariable(res, "KASKO_PreCalc").ToIntDef(1);
      if(di.is_ander_login) ((TAnderrFrame*)(frames->Items[0]))->SaveFrame(q);
      else{
         if(is_precalc) ((TFramePreCalc*)(frames->Items[0]))->SaveFrame(q);
      }
      ((TFrameNew*)(frames->Items[(di.is_ander_login || is_precalc) ? 1 : 0]))->SaveFrame(q);
      ((TFrame1*)(frames->Items[is_precalc && !di.is_ander_login ? 4 : 3]))->SaveFrame(q);
   } */

   q->Post();
   m_api->dbCloseCursor(res, q);

   return 1;
}
//------------------------------------------------------------------------------
  int Load_Frames(TList *frames, long calc_id)
{
   TADOQuery *q = m_api->dbGetCursor(res,
                    //"select t1.*, t2.*, t3.requirements, t3.benefic, t4.date_add, t4.id_polzovatelya, t4.status_id"
                    "select "
" t1.calc_id, t1.region_id, t1.tstype_id, t1.tstype_id, t1.ts_marka, t1.ts_model, t1.max_massa, t1.seat_count, t1.risk_id, t1.status_idx,"
" t1.ts_year, t1.variant_idx, t1.srok_month, t1.ts_novoe, t1.bez_ogr, t1.fr_instead_k1, t1.pay_id, t1.prolong, t1.prev_ubitki_idx, t1.osago_idx,"
" t1.ts_count, t1.ks, t1.ka, t1.franshiza, t1.str_summa, t1.ts_cost, t1.select_ns, t1.select_dsago, t1.ns_summa, t1.ts_pricep, t1.dsago_summa,"
" t1.valuta, t1.valuta_kurs, t1.polis_seria, t1.polis_number, t1.polis_date, t1.srok_time_s, t1.srok_date_s,"
" t1.srok_time_po, t1.srok_date_po, t1.prev_seria, t1.prev_number, t1.fio, t1.ts_vin, t1.pts_seria, t1.pts_number, t1.ts_znak, t1.key_count,"
" t1.ns_variant, t1.dop_obor, t1.spec_ts, t1.dop_sog, t1.dop_sog_number, t1.vznos1, t1.vznos2, t1.vznos3, t1.date_vznos1, t1.date_vznos2,"
" t1.date_vznos3, t1.dop_usl1, t1.dop_usl2, t1.no_osmotr, t1.osmotr, t1.date_osmotr, t1.sale_place,"
" t1.sale_channel,"
" t1.agent, t1.payment_id,"
" t1.payment_doc_id, t1.premiya_all, t1.date_unload, t1.ns_seat_count, t1.car_params, t1.ts_model_id,"
" t1.date_unload_arm, t1.source_id, t1.bank_id, t1.risk_main, t1.multidrive, t1.risk_ns, t1.risk_dsago, t1.benef_whois, t1.pts_date, t1.ts_power,"
" t1.premium_main_risk, t1.premium_dsago, t1.premium_ns,"
" t1.credit_number, t1.zalog_number, t1.project_id, t1.code_prod, t1.name_prod, t1.polis_name, t1.dm_osmotr, t1.alarm,"
" t1.time_osmotr, t1.credit_date,"
" t1.zalog_date, t1.polis_id, t1.pp_seria, t1.pp_number, t1.payed_count, t1.dogovor, t1.ts_volume, t1.ts_doc_type, t1.real_alarm,"
" t1.tariff, t1.krs_idx,"
//" t1.type_franshizaprogramm_id,"
" t1.prg_prj_name, t1.kpr, t1.coeff_prop, t1.sms_sending, t1.payed_sum, t1.dogovor_type, t1.date_zayavl, t1.date_rast, t1.full_insur,"
" t1.reiss_type, t1.sale_channel_id,"
//" t1.old_sale_channel_id," //
" t1.benefit_prolong, t1.premium_main_risk_bp, t1.no_contacts, t1.old_premium_main_risk, t1.old_str_summa, t1.claim_damages_sum,"
" t1.dsago_territory_id, t1.dsago_city_id, t1.dsago_prolong, t1.dsago_accident, t1.ts_marka_calc, t1.region_isp_id, t1.kkv,"
" t1.pts_date_calc, t1.is_registration_ts, t1.anderr_comm, t1.from_whom_sent, t1.alarms_info, t1.agent_comm, t1.obosn_ka,"
" t1.fio_deiizb,"
" t1.quotation_date,"
//" t1.email_date,"
" t1.usage_purpose, t1.usage_purpose_text, t1.base_kkv, t1.filename, t1.is_data_to_agreed, t1.to_print,"
" t1.polis_date_d, t1.ident_type, t1.filial, t1.old_ts_cost, t1.permitteds, t1.bt, t1.k1, t1.kd, t1.k4, t1.kr, t1.kar, t1.kb,"
" t1.group_str,"
" t1.kyu, t1.package_comfort, t1.who_agreed, t1.comm_sale_mid, t1.comm_anderr_mid, t1.anderrchange_mid,"
//" t1.calc_k5_k6,"
" t1.likard_number, t1.likard_date, t1.multidrive_pc, t1.fr_instead_k1_pc, t1.prolong_pc, t1.prev_ubitki_idx_pc, t1.k5, t1.k6_final,"
" t1.central_bd_error, t1.cross_error, t1.select_dms, t1.dms_summa, t1.premium_dms, t1.policy_sign, t1.skk_branch, t1.bases_cancell,"
" t1.reason_id, t1.refund_value, t1.is_autorization, t1.last_polis_ed_incday, t1.kbfprlg, t1.programm_id, t1.old_programm_id,"
" t1.old_premium_paid, t1.vznos4, t1.date_vznos4, t1.extension_territory, t1.result_check_bso,"
" t1.count_check, t1.bigpayment1, t1.payment1,"
" t1.bp_error_text,"
" t1.skk_sale, t1.is_gap, t1.premiya_gap, t1.payment_method_id,"
" t1.payment_authorization_code, t1.franshiza_unit, t1.product_id, t1.no_calc, t1.calculation_id, t1.contract_id, t1.refund_id,"
" t1.account, t1.bank, t1.new_polis_seria, t1.new_polis_number, t1.new_polis_date, t1.new_polis_premium, t1.restmoney_id, t1.documents,"
                    "  t2.*, t3.requirements, t3.benefic, t4.date_add, t4.id_polzovatelya, t4.status_id"
                    "  from ( (casco_calc as t1 left join casco_persons as t2 on t1.calc_id=t2.calc_id)"
                    "    left join gl_dict_banks as t3 on t1.bank_id=t3.bank_id) left join _mops_calcs_"
                    "  as t4 on t1.calc_id=t4.id "
                    "  where t1.calc_id=" + IntToStr(calc_id) +
                    " order by t2.type_person");



   //if(di.dogovor_type == 4){
      if(di.is_ander_login)
	  {
         ((TAnderrFrame*)(frames->Items[0]))->LoadFrame(q);
         ((TFReissCalc*)(frames->Items[1]))->LoadFrame(q);
      }
      else
	  {
		  ((TFReissCalc*)(frames->Items[0]))->LoadFrame(q);
	  }
	  
   /*}
   else{
      int is_precalc = m_api->vrGetVariable(res, "KASKO_PreCalc").ToIntDef(1) && !di.is_ander_login;
      if(di.is_ander_login) ((TAnderrFrame*)(frames->Items[0]))->LoadFrame(q);
      else{
         if(is_precalc) ((TFramePreCalc*)(frames->Items[0]))->LoadFrame(q);
      }
      TFrameNew *fc = ((TFrameNew*)(frames->Items[(di.is_ander_login || is_precalc) ? 1 : 0]));
      TFrame1   *fp = ((TFrame1*)(frames->Items[is_precalc ? 4 : 3]));
      fc->LoadFrame(q);
      fp->LoadFrame(q);
   } */

   m_api->dbCloseCursor(res, q);

   return 1;
}
//------------------------------------------------------------------------------
void Get_Main_Grid_Tables(TStringList *Tables){}
//------------------------------------------------------------------------------
int Save_Frame(void* Frame, long id_calc){ return 1; }
//------------------------------------------------------------------------------
int Load_Frame(void* Frame, long id_calc){ return 1; }
//------------------------------------------------------------------------------
void Get_Module_Print_Forms_Names(TStringList *form_names){}
//------------------------------------------------------------------------------
int OnFastReport(AnsiString Form_Name, int form_type, long calc_id, int action, TList *data_sets)
{
   if(!action) calc_id = m_api->dbGetIntFromQuery(res, "select max(calc_id) from casco_calc");

   TADOQuery *q = m_api->dbGetCursor(res, "select t1.*,t2.surcharge_value_ss,t2.surcharge_value_gp,t2.surcharge_value_gap_ss from casco_calc t1 left join casco_calc_r t2 on t1.calc_id=t2.calc_id  where [t1.calc_id]=" + IntToStr(calc_id));

   double prem_RUR = m_api->Round(q->FieldByName("premiya_all")->AsFloat), payed_sum_RUR = m_api->Round(q->FieldByName("payed_sum")->AsFloat);
   int black_print = Form_Name.AnsiPos("��������") ? 1 : 0, bank_id = q->FieldByName("bank_id")->AsInteger, status = q->FieldByName("status_idx")->AsInteger, pay_id = q->FieldByName("pay_id")->AsInteger, full_insur = q->FieldByName("full_insur")->AsInteger, variant_idx = q->FieldByName("variant_idx")->AsInteger, standart = m_api->dbGetIntFromQuery(res, "select policy_mask from gl_dict_banks where [bank_id]=" + IntToStr(bank_id)), count_permitted = m_api->dbGetIntFromQuery(res, "select count(*) from casco_persons where type_person>3 and calc_id=" + IntToStr(calc_id)), product_id = q->FieldByName("variant_idx")->AsInteger + (q->FieldByName("status_idx")->AsInteger == 0 ? 301 : 304);

   AnsiString sql, premium_string = m_api->Summa_Propisyu(q->FieldByName("premiya_all")->AsFloat, true, false), premium_RUR_string = m_api->Summa_Propisyu(prem_RUR, true, false), payed_RUR_string = m_api->Summa_Propisyu(payed_sum_RUR, true, false),
                   refund_value_string = m_api->Summa_Propisyu(q->FieldByName("refund_value")->AsFloat, true, false), policy_date = q->FieldByName("polis_date")->AsDateTime.DateString(),
                   compensation_type = m_api->dbGetStringFromQuery(res, "select compensation_type from gl_dict_banks where [bank_id]=" + IntToStr(bank_id)), num_ds("      "), rub, kopeik, premium_rub, premium_kopeik;

   if(Form_Name.AnsiPos("����� �� ������")){
      data_sets->Add(m_api->dbGetCursor(res, "select " + IntToStr(black_print) + " as black_print,t1.*,t2.*,t3.categories,t4.doc_type,trim(t5.last_name+' '+t5.first_name+' '+t5.second_name) as benefic_name from ((((casco_calc t1 left join casco_persons t2 on (t1.calc_id=t2.calc_id and t2.type_person=1)) left join casco_persons t5 on (t1.calc_id=t5.calc_id and t5.type_person=2)) left join ts_type t3 on t1.tstype_id=val(t3.code)) left join cascodoctype t4 on t2.document_type_id=t4.id_doc_type) where t1.calc_id=" + IntToStr(calc_id)));

      // ���������� + �����������
      data_sets->Add(m_api->dbGetCursor(res,
      "select"
      " type_person, trim(last_name+' '+first_name+' '+second_name) as fio_pm, phisical_sex, phisical_birth_date, document_issue_date, document_series, document_number"
      " from"
      "  casco_persons"
      " where"
      " type_person>3 and calc_id=" + IntToStr(calc_id) + " and (select count(*) from casco_persons where type_person>3  and calc_id=" + IntToStr(calc_id) + ") < 4 order by type_person"));
      data_sets->Add(m_api->dbGetCursor(res, "select multidrive_text from cascomultidrivetext where status_id=" + IntToStr(status) + " and count_permitted<=" + IntToStr(count_permitted)));

      //�����
      TClientDataSet *clds_risks = new TClientDataSet(0), *clds_dms = new TClientDataSet(0);
      clds_risks->FieldDefs->Add("risk_name", ftString, 255);
      clds_risks->FieldDefs->Add("risk_sum", ftFloat);
      clds_risks->FieldDefs->Add("risk_premium", ftFloat);
      clds_risks->FieldDefs->Add("franshize", ftString, 255);
      clds_risks->CreateDataSet();

      clds_dms->FieldDefs->Add("dms_text", ftMemo);
      clds_dms->CreateDataSet();

      if(q->FieldByName("select_dsago")->AsBoolean){
         clds_risks->Append();
         clds_risks->FieldByName("risk_name")->Value    = AnsiString("�����") + (q->FieldByName("ts_pricep")->AsBoolean ? "(�� � ��������)" : "");
         clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dsago_summa")->AsFloat;
         clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dsago")->AsFloat;
         clds_risks->FieldByName("franshize")->Value    = "� ������� ������ ��������������� �� �����";
      }
      if(q->FieldByName("select_ns")->AsBoolean){
         clds_risks->Append();
         clds_risks->FieldByName("risk_name")->Value    = "�� (���������� �������)";
         clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("ns_summa")->AsFloat;
         clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_ns")->AsFloat;
         clds_risks->FieldByName("franshize")->Value    = "�����������";
      }
      if(q->FieldByName("select_dms")->AsBoolean){
         clds_risks->Append();
         clds_risks->FieldByName("risk_name")->Value    = "���������� ������������ ������";
         clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dms_summa")->AsFloat;
         clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dms")->AsFloat;
         clds_risks->FieldByName("franshize")->Value    = "�����������";

         clds_dms->Append();
         clds_dms->FieldByName("dms_text")->Value = "�������������� �� �������� \"����������� ������ ��� ��������\" �������� ����, ���������� � ���������� �� � ������������ � ��������� �����������, �� �������� ���������� � ������������ � ������ ��� �� ����� ��.";
      }
      data_sets->Add(clds_risks);

      //������ ��������
      TClientDataSet *clds_shedul = new TClientDataSet(0);
      clds_shedul->FieldDefs->Add("num", ftInteger);
      clds_shedul->FieldDefs->Add("sum", ftFloat);
      clds_shedul->FieldDefs->Add("dt", ftDateTime);
      clds_shedul->CreateDataSet();
      if(q->FieldByName("vznos2")->AsFloat > 0){
         clds_shedul->Append();
         clds_shedul->FieldByName("num")->Value = 2;
         clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos2")->AsFloat;
         clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos2")->AsDateTime;
      }
      if(q->FieldByName("vznos3")->AsFloat > 0){
         clds_shedul->Append();
         clds_shedul->FieldByName("num")->Value = 3;
         clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos3")->AsFloat;
         clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos3")->AsDateTime;
      }
      if(q->FieldByName("vznos4")->AsFloat > 0){
         clds_shedul->Append();
         clds_shedul->FieldByName("num")->Value = 4;
         clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos4")->AsFloat;
         clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos4")->AsDateTime;
      }

      data_sets->Add(clds_shedul);

      data_sets->Add(clds_dms);

      //���������� ������
      TClientDataSet *clds_compensation = new TClientDataSet(0);
      clds_compensation->FieldDefs->Add("compensation_type", ftString, 255);
      clds_compensation->CreateDataSet();
      clds_compensation->Append();
      if(!variant_idx) clds_compensation->FieldByName("compensation_type")->Value = AnsiString("������� �. ������ �� ���� �� ") + (pay_id == 3 ? "����������� �����������." : "������ ������������.");
      else clds_compensation->FieldByName("compensation_type")->Value = AnsiString("������� ") + (variant_idx == 1 ? "�" : "�");

      data_sets->Add(clds_compensation);

      // ��� � ��������
      AddOpfAndLicense(data_sets);

      if(action && !black_print){
         m_api->Raschet_Set_Status_id(res, calc_id, 5);
         m_api->Module_Refresh_Main_Grid(res);
      }
   }
   else if(Form_Name.AnsiPos("�����(����������) �� ������")){
      data_sets->Add(m_api->dbGetCursor(res, "select '" + premium_string + "' as SumString,'" + premium_RUR_string + "' as SumRURString," + IntToStr(black_print) + " as black_print,t1.*,t2.*,t3.obobch_cod as full_name,t4.doc_type from casco_calc as t1,casco_persons as t2, ts_type as t3,cascodoctype as t4 where t1.calc_id=t2.calc_id and t1.tstype_id=val(t3.code) and t2.type_person=1 and t2.document_type_id=t4.id_doc_type and t1.calc_id=" + IntToStr(calc_id)));
      //����� �����
      data_sets->Add(m_api->dbGetCursor(res, "select * from gl_dict_banks where bank_id=" + IntToStr(bank_id)));
      data_sets->Add(m_api->dbGetCursor(res, "select depart_sb,number_sb,place_sb,address from casco_persons where type_person=2 and calc_id=" + IntToStr(calc_id)));

      // ���������� + �����������
      data_sets->Add(m_api->dbGetCursor(res, "select type_person,first_name,second_name,last_name,phisical_birth_date,document_issue_date,document_series,document_number from casco_persons where type_person>3 and calc_id=" + IntToStr(calc_id) + " and (select count(*) from casco_persons where type_person>3  and calc_id=" + IntToStr(calc_id) + ") < 4 order by type_person"));
      data_sets->Add(m_api->dbGetCursor(res, "select multidrive_text from cascomultidrivetext where status_id=" + IntToStr(status) + " and count_permitted<=" + IntToStr(count_permitted)));

      //�����
      TClientDataSet *clds_risks = new TClientDataSet(0), *clds_dms = new TClientDataSet(0);
      clds_risks->FieldDefs->Add("risk_name", ftString, 255);
      clds_risks->FieldDefs->Add("risk_sum", ftFloat);
      clds_risks->FieldDefs->Add("risk_premium", ftFloat);
      clds_risks->FieldDefs->Add("franshize", ftString, 255);
      clds_risks->CreateDataSet();

      clds_dms->FieldDefs->Add("dms_text", ftMemo);
      clds_dms->CreateDataSet();

      if(q->FieldByName("select_dsago")->AsBoolean){
         clds_risks->Append();
         clds_risks->FieldByName("risk_name")->Value    = AnsiString("�����") + (q->FieldByName("ts_pricep")->AsBoolean ? "(�� � ��������)" : "");
         clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dsago_summa")->AsFloat;
         clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dsago")->AsFloat;
         clds_risks->FieldByName("franshize")->Value     = "� ������� ������ ��������������� �� �����";
      }
      if(q->FieldByName("select_ns")->AsBoolean){
         clds_risks->Append();
         clds_risks->FieldByName("risk_name")->Value    = "�� (���������� �������)";
         clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("ns_summa")->AsFloat;
         clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_ns")->AsFloat;
         clds_risks->FieldByName("franshize")->Value     = "�����������";
      }
      if(q->FieldByName("select_dms")->AsBoolean){
         clds_risks->Append();
         clds_risks->FieldByName("risk_name")->Value    = "���������� ������������ ������";
         clds_risks->FieldByName("risk_sum")->Value     = q->FieldByName("dms_summa")->AsFloat;
         clds_risks->FieldByName("risk_premium")->Value = q->FieldByName("premium_dms")->AsFloat;
         clds_risks->FieldByName("franshize")->Value    = "�����������";

         clds_dms->Append();
         clds_dms->FieldByName("dms_text")->Value = "�������������� �� �������� \"����������� ������ ��� ��������\" �������� ����, ���������� � ���������� �� � ������������ � ��������� �����������, �� �������� ���������� � ������������ � ������ ��� �� ����� ��.";

      }
      data_sets->Add(clds_risks);

      //������ ��������
      TClientDataSet *clds_shedul = new TClientDataSet(0);
      clds_shedul->FieldDefs->Add("num", ftInteger);
      clds_shedul->FieldDefs->Add("sum", ftFloat);
      clds_shedul->FieldDefs->Add("dt", ftDate);
      clds_shedul->CreateDataSet();
      if(q->FieldByName("vznos2")->AsFloat > 0){
         clds_shedul->Append();
         clds_shedul->FieldByName("num")->Value = 2;
         clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos2")->AsFloat;
         clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos2")->AsDateTime;
      }
      if(q->FieldByName("vznos3")->AsFloat > 0){
         clds_shedul->Append();
         clds_shedul->FieldByName("num")->Value = 3;
         clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos3")->AsFloat;
         clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos3")->AsDateTime;
      }
      if(q->FieldByName("vznos4")->AsFloat > 0){
         clds_shedul->Append();
         clds_shedul->FieldByName("num")->Value = 4;
         clds_shedul->FieldByName("sum")->Value = q->FieldByName("vznos4")->AsFloat;
         clds_shedul->FieldByName("dt")->Value = q->FieldByName("date_vznos4")->AsDateTime;
      }
      data_sets->Add(clds_shedul);

      //���������� ������
      TClientDataSet *clds_compensation = new TClientDataSet(0);
      clds_compensation->FieldDefs->Add("compensation_type", ftMemo);
      clds_compensation->CreateDataSet();
      clds_compensation->Append();
      if(compensation_type.IsEmpty()){
         if(full_insur < 2) clds_compensation->FieldByName("compensation_type")->Value = AnsiString("������� �. ������ �� ���� �� ") + (pay_id == 3 ? "����������� �����������." : "������ ������������.");
         else{
            if(full_insur == 3) num_ds = "  17  ";
            else{
               if(full_insur == 2){
                  num_ds = variant_idx == 0 ? "  18  " : "  19  ";
               }
            }
            clds_compensation->FieldByName("compensation_type")->Value = "������� � � � ������������ � ��������� ��������������� ���������� <u>" + num_ds + "</u> � ���������� ������";
         }
      }
      else clds_compensation->FieldByName("compensation_type")->Value = compensation_type;
      data_sets->Add(clds_compensation);

      //������ �������
      TADOQuery *q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=" + IntToStr(product_id) + " and bank_id=" + IntToStr(bank_id) + " and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
      if(q_terms->IsEmpty()){
         m_api->dbCloseCursor(res, q_terms);
         q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=0 and bank_id=" + IntToStr(bank_id) + " and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
         if(q_terms->IsEmpty()){
            m_api->dbCloseCursor(res, q_terms);
            q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=" + IntToStr(product_id) + " and bank_id=0 and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
            if(q_terms->IsEmpty()){
               m_api->dbCloseCursor(res, q_terms);
               q_terms = m_api->dbGetCursor(res, "select other_terms,is_sign from gl_dict_banksrequirements where is_credit=1 and product_id=0 and bank_id=0 and CDate('" + policy_date + "')>=start_date and CDate('" + policy_date + "')<=end_date order by sort_order");
            }
         }
      }

      data_sets->Add(q_terms);

      data_sets->Add(clds_dms);

      // ��� � ��������
      AddOpfAndLicense(data_sets);

      if(action && !black_print){
         m_api->Raschet_Set_Status_id(res, calc_id, 5);
         m_api->Module_Refresh_Main_Grid(res);
      }
   }

   else if(Form_Name == "�������������� ���������� �� ���. ������������" || Form_Name == "�������������� ���������� � ������������ ����������� ��������"){
      data_sets->Add(m_api->dbGetCursor(res, "select t1.polis_seria,t1.polis_number,t1.polis_date,t1.fio,t1.risk_id,t1.type_franshiza,t1.franshiza,t1.payed_sum,t1.date_vznos1,t2.*,t3.equip_name from (casco_calc as t1 left join casco_devices as t2 on t1.calc_id=t2.calc_id) left join type_equip as t3 on t2.id_device=t3.equip_id where t1.calc_id=" + IntToStr(calc_id)));
      // ��� � ��������
      AddOpfAndLicense(data_sets);
   }
   else if(Form_Name == "���� ������������"){
      data_sets->Add(m_api->dbGetCursor(res, sql.sprintf(f171_sql.c_str(), "01.01.2000", "�����", "����� ���������", "��� ������", "131 �����", "FL", "Insured man", "JL", "Bank Of Scotland", "taz", "2009", "2.4", "409", "XXXX9999", "ptska", "Variant A", "KASKO", "500000", "750000", "����", "���", "100,02", "2,45", "9,73", "1,6", "1,1", "1,2", "1,3", "1,4", "0,9", "1,7", "1,5", "1.0", "0.75", "0.75", "1,8", "0,85", "15,26", "0,75","1,0","12,12", "45236,45", "perm1;perm2", "��� �����", "2", "3", "12", "1/�156", "farsh", "�����", "21.6", "����������", "Dronov", "Sklyar")));
      TClientDataSet *clds = new TClientDataSet(0);
      clds->FieldDefs->Add("comment", ftMemo);
      clds->CreateDataSet();
      clds->Append();
      clds->FieldByName("comment")->Value = "comment";
      data_sets->Add(clds);
   }
   else if(Form_Name == "���� ������� ��������� ������"){
      data_sets->Add(m_api->dbGetCursor(res, sql.sprintf(sql_calc_form.c_str(), di.is_ander_login ? 1 : 0) + IntToStr(calc_id)));
      AddOpfAndLicense(data_sets);
   }
   else if(Form_Name == "����� �� ���������"){
      data_sets->Add(m_api->dbGetCursor(res, "select 2 as type_dg," + report_anderr_sql + " and t5.status_id=4"));
      TClientDataSet *clds = new TClientDataSet(0);
      clds->FieldDefs->Add("calc_id", ftInteger);
      clds->FieldDefs->Add("anderr_comm", ftMemo);
      clds->CreateDataSet();
      clds->Append();
      clds->FieldByName("calc_id")->Value = 1459;
      clds->FieldByName("anderr_comm")->Value = "Test";
      data_sets->Add(clds);
   }
   else if(Form_Name == "�������������� ���������� � ���������� � ����������"/* ���������� ��� ���������� ������, ��� �������������� ������ ������*/){
      data_sets->Add(m_api->dbGetCursor(res, "select (t1.last_name+' '+t1.first_name+' '+t1.second_name) as fio_pm,t1.phisical_birth_date,t1.phisical_sex,t1.document_issue_date,t1.document_series,t1.document_number,t2.polis_seria,t2.polis_number,t2.polis_date,t3.filial_name_vrp from casco_persons as t1,casco_calc as t2,gl_dict_regions t3 where t1.calc_id=t2.calc_id and t2.region_id=t3.terr_id and t1.type_person>3 and t1.calc_id=" + IntToStr(calc_id)));
      // ��� � ��������
      AddOpfAndLicense(data_sets);
   }
   else if(Form_Name == "�������������� ���������� (����� � ���)" || Form_Name == "�������������� ���������� �� ��������� �������������� �������" || Form_Name == "�������������� ���������� � ���������� ���������� �����������" || Form_Name == "�������������� ���������� (������� �� ������)" || Form_Name == "�������������� ���������� (������ 2012)" || Form_Name == "�������������� ���������� � ����������� �� �������� ���������" || Form_Name == "�������������� ���������� � ����������� �� ��������� (��� ����� ������)" || Form_Name == "�������������� ���������� � ����������� �� ��������� (� ������ ������)" || Form_Name == "�������������� ���������� �� ����������� ����� ���, ���������� � ����������" || Form_Name == "��������� (������� �� ������)"){
      FloatToRubAndKopeik(0, rub, kopeik);
      FloatToRubAndKopeik(q->FieldByName("premiya_all")->AsFloat, premium_rub, premium_kopeik);
      data_sets->Add(m_api->dbGetCursor(res, "select '" + rub + "' as field_rub,'" + kopeik + "' as field_kopeik,'" + premium_rub + "' as field_premium_rub,'" + premium_kopeik + "' as field_premium_kopeik,t1.polis_seria,t1.polis_number,t1.polis_date,t1.fio,t1.coeff_prop,t2.filial_name_vrp,t1.programm_id,t1.package_comfort,t3.telematic_service,t1.real_alarm,t1.osmotr,t1.date_vznos1 from ((casco_calc as t1 left join gl_dict_regions as t2 on t1.region_id=t2.terr_id) left join casco_telematic_devices as t3 on t1.package_comfort=t3.telematic_device) where calc_id=" + IntToStr(calc_id)));
      // ��� � ��������
      AddOpfAndLicense(data_sets);
   }
   else if(Form_Name == "�������������� ���������� � ���������� GAP"){
      FloatToRubAndKopeik(q->FieldByName("premiya_gap")->AsFloat, rub, kopeik);
      FloatToRubAndKopeik(q->FieldByName("premiya_gap")->AsFloat + q->FieldByName("premiya_all")->AsFloat, premium_rub, premium_kopeik);
      data_sets->Add(m_api->dbGetCursor(res, "select '" + rub + "' as field_rub,'" + kopeik + "' as field_kopeik,'" + premium_rub + "' as field_premium_rub,'" + premium_kopeik + "' as field_premium_kopeik,t1.polis_seria,t1.polis_number,t1.polis_date,t1.fio,t1.coeff_prop,t2.filial_name_vrp,t1.programm_id,t1.package_comfort,t3.telematic_service,t1.real_alarm,t1.osmotr,t1.date_vznos1 from ((casco_calc as t1 left join gl_dict_regions as t2 on t1.region_id=t2.terr_id) left join casco_telematic_devices as t3 on t1.package_comfort=t3.telematic_device) where calc_id=" + IntToStr(calc_id)));
      // ��� � ��������
      AddOpfAndLicense(data_sets);
   }
   else if(Form_Name == "������ �������") data_sets->Add(m_api->dbGetCursor(res, "select * from casco_anketa where calc_id=" + IntToStr(calc_id)));
   else if(Form_Name == "��� ����(���. ����������)" || Form_Name == "��� ����(���. ����������)" || Form_Name == "��������������(���. ����������)" || Form_Name == "��������� � ��������� ����������� ��������"){
      data_sets->Add(m_api->dbGetCursor(res, "select t1.*,t2.*,t3.reason from casco_calc t1,casco_persons t2,cascocancellreason t3 where t1.calc_id=t2.calc_id and t1.reason_id=t3.id and t2.type_person=1 and t1.calc_id=" + IntToStr(calc_id)));
      // ��� � ��������
      AddOpfAndLicense(data_sets);
   }
   else if(Form_Name.SubString(1, 4) == "�C �" || Form_Name == "��������� �� �������� ��������� � ����� ������������� ����������� ��" || Form_Name == "���������(������) �� �������� ��������� � ����� ������������� ����������� ��"){

      //������� � ���������
      TADOQuery *q_reasons = m_api->dbGetCursor(res, "select reason_id from casco_reiss_reasons where calc_id=" + IntToStr(calc_id)), *q_reasons_dict = m_api->dbGetCursor(res, "select [id] from cascoreissuereason order by [id]");
      TClientDataSet *clds = new TClientDataSet(0);
      for(q_reasons_dict->First(); !q_reasons_dict->Eof; q_reasons_dict->Next()) clds->FieldDefs->Add("r" + q_reasons_dict->FieldByName("id")->AsString, ftInteger);
      m_api->dbCloseCursor(res, q_reasons_dict);
      clds->CreateDataSet();
      clds->Append();
      for(q_reasons->First(); !q_reasons->Eof; q_reasons->Next()) clds->FieldByName("r" + q_reasons->FieldByName("reason_id")->AsString)->Value = 1;
      m_api->dbCloseCursor(res, q_reasons);
      data_sets->Add(clds);

      // �������� � ����� ������
      AnsiString rub_gp, kopeik_gp, rub_ss, kopeik_ss, rub_gap_ss, kopeik_gap_ss, rub_premium_new_ss, kopeik_premium_new_ss, rub_premium_new_gp, kopeik_premium_new_gp, rub_premium_new_gap_ss, kopeik_premium_new_gap_ss;

      FloatToRubAndKopeik(q->FieldByName("surcharge_value_ss")->AsFloat, rub_ss, kopeik_ss);
      FloatToRubAndKopeik(q->FieldByName("surcharge_value_ss")->AsFloat + q->FieldByName("premiya_all")->AsFloat, rub_premium_new_ss, kopeik_premium_new_ss);

      FloatToRubAndKopeik(q->FieldByName("surcharge_value_gp")->AsFloat, rub_gp, kopeik_gp);
      FloatToRubAndKopeik(q->FieldByName("surcharge_value_gp")->AsFloat + q->FieldByName("premiya_all")->AsFloat, rub_premium_new_gp, kopeik_premium_new_gp);

      FloatToRubAndKopeik(q->FieldByName("surcharge_value_gap_ss")->AsFloat, rub_gap_ss, kopeik_gap_ss);
      FloatToRubAndKopeik(q->FieldByName("surcharge_value_gap_ss")->AsFloat + q->FieldByName("premiya_all")->AsFloat, rub_premium_new_gap_ss, kopeik_premium_new_gap_ss);

      data_sets->Add(m_api->dbGetCursor(res, "select t1.*,t2.filial_name_vrp from (casco_calc t1 left join gl_dict_regions t2 on t1.region_id=t2.terr_id) where t1.calc_id=" + IntToStr(calc_id)));
      data_sets->Add(m_api->dbGetCursor(res, "select '" + rub_ss + "' as field_rub_ss,'" + kopeik_ss + "' as field_kopeik_ss,'" + rub_gp + "' as field_rub_gp,'" + kopeik_gp + "' as field_kopeik_gp, '" + rub_gap_ss + "' as field_rub_gap_ss,'" + kopeik_gap_ss + "' as field_kopeik_gap_ss,'" + rub_premium_new_ss + "' as field_rub_premium_new_ss,'" + kopeik_premium_new_ss + "' as field_kopeik_premium_new_ss,'" + rub_premium_new_gp + "' as field_rub_premium_new_gap,'" + kopeik_premium_new_gp + "' as field_kopeik_premium_new_gap,'" + rub_premium_new_gap_ss + "' as field_rub_premium_new_gap_ss,'" + kopeik_premium_new_gap_ss + "' as field_kopeik_premium_new_gap_ss, t1.* from casco_calc_r t1 where t1.calc_id=" + IntToStr(calc_id)));

      //������� �� ������������� �����
      data_sets->Add(m_api->dbGetCursor(res, "select t1.*,t2.doc_type from casco_persons_r t1 left join cascodoctype t2 on t1.document_type_id=t2.id_doc_type where type_person=1 and calc_id=" + IntToStr(calc_id)));

     //������� �� ������������������ �����
      data_sets->Add(m_api->dbGetCursor(res, "select trim(last_name+' '+first_name+' '+second_name) as benefic_name from casco_persons_r where type_person=2 and calc_id=" + IntToStr(calc_id)));

      //�������� � �����������
      // (��������� ������)
      data_sets->Add(m_api->dbGetCursor(res,
        "select (last_name+' '+first_name+' '+second_name) as fio_pm, phisical_sex, phisical_birth_date, document_issue_date, document_series, document_number"
        " from casco_persons_r"
        " where"
        //" type_person > 2 and"
        " permitted_status=1 and" // �������� � ������ ���, ���������� � ����������
        " calc_id=" + IntToStr(calc_id)));
      data_sets->Add(m_api->dbGetCursor(res,
       "select (last_name+' '+first_name+' '+second_name) as fio_pm, phisical_sex, phisical_birth_date, document_issue_date, document_series, document_number"
       " from casco_persons_r"
       " where"
       //" type_person > 2 and"
       " permitted_status=3 and" // ���������� �� ������ ���, ���������� � ����������
       " calc_id=" + IntToStr(calc_id)));
      // (��������� ������)
      // ����� ���������
      data_sets->Add(m_api->dbGetCursor(res,
      "select (last_name+' '+first_name+' '+second_name) as fio_pm, phisical_sex, phisical_birth_date, document_issue_date, document_series, document_number"
      " from casco_persons_r "
      " where permitted_status=2 and calc_id=" + IntToStr(calc_id)));
      // ����� ������ ��������� � ���������
      data_sets->Add(m_api->dbGetCursor(res,
      "select (last_name+' '+first_name+' '+second_name) as fio_pm, phisical_sex, phisical_birth_date, document_issue_date, document_series, document_number"
      " from casco_persons"
      " where calc_id=" + IntToStr(calc_id) + " and type_person"
      "  in(select type_person"
      "  from casco_persons_r"
      "  where permitted_status=2 and calc_id=" + IntToStr(calc_id) + ")"));

      //������� � ��
      data_sets->Add(m_api->dbGetCursor(res, "select t1.*,t2.equip_name from casco_devices_r t1,type_equip t2 where t1.id_device=t2.equip_id and t1.calc_id=" + IntToStr(calc_id) + " order by t1.number"));

      //��� ���������
      data_sets->Add(m_api->dbGetCursor(res, "select trim(last_name+' '+first_name+' '+second_name) as benefic_old_name from casco_persons where type_person=2 and calc_id=" + IntToStr(calc_id)));
      data_sets->Add(m_api->dbGetCursor(res, "select t1.*,t2.doc_type from casco_persons t1 left join cascodoctype t2 on t1.document_type_id=t2.id_doc_type where type_person=1 and calc_id=" + IntToStr(calc_id)));

      // ��� � ��������
      AddOpfAndLicense(data_sets);

      if(action && Form_Name.SubString(1, 4) == "�C �"){
         m_api->Raschet_Set_Status_id(res, calc_id, 10);
         m_api->Module_Refresh_Main_Grid(res);
      }
   }
   else
   {

   }

   m_api->dbCloseCursor(res, q);
   return 1;
}
//------------------------------------------------------------------------------
int Universal_Func(AnsiString command, void* lparam, void* hparam)
{
   Sleep(10);
   int is_precalc = m_api->vrGetVariable(res, "KASKO_PreCalc").ToIntDef(1) && !di.is_ander_login;

   if(command == "� ����� ���, ����� ���� ������ ����� ���������? (������ �������� - ���� ���� bool*, ������ - ������ ���������� �� ������ ���� TList*)")
   {
/* //#include "newcalc.h"
      if(((TList*)hparam)->Count > 3)
      {
         TFrameNew *fc = (TFrameNew*)((TList*)hparam)->Items[(di.is_ander_login || is_precalc) ? 1 : 0];
         TFrame1 *fp = (TFrame1*)((TList*)hparam)->Items[is_precalc ? 4 : 3];
         if(di.is_new_dogovor){
            if(pi[0].phone_mobil.Length() != 15){
               TfrmInfo *fi = new TfrmInfo(0);
               if(fi->ShowModal() == mrNo){
                  *((bool*)lparam) = false;
                  is_message = false;
               }
               else *((bool*)lparam) = true;
               delete fi;
            }
            else *((bool*)lparam) = true;
         }
         else{
            int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
            if(m_api->Raschet_Get_Status_id(res, calc_id) == 4 && (fc->IsChangeData() || fp->IsChangeData())){
               if(MessageBox(0, AnsiString("�� �������� ���� �������������� ��������. ������� ����� ��������� ������������. �� �������?\r\n���������� ��������� ����:\r\n" + fc->ChangeDataToStr()).c_str(), "������ �����", MB_YESNO | MB_ICONQUESTION) == IDYES){
                  m_api->Raschet_Set_Status_id(res, calc_id, 2);
                  *((bool*)lparam) = true;
               }
               else{
                  *((bool*)lparam) = false;
                  is_message = false;
               }
            }
            else *((bool*)lparam) = true;
         }
      }
      else *((bool*)lparam) = true;
//*/
   }

   else if(command == "� ����� ���, ���������� �� MessageBox � ������� ��� ����������? (������ �������� - ���� ���� bool*, ������ - ������ ���������� �� ������ ���� TList*)" && di.is_new_dogovor)
      *((bool*)lparam) = is_message;

   else if(command == "��������� ����� ������������� (������ � ������������ �������� - ���� ���� bool*)")
      PreViewFlag = *((bool*)lparam);

   else if(command == "���� ������ ������ ��������")
   {
      //int cur_calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
      //SHOW_NUMBER("CALC_ID that we are working with", cur_calc_id);
      Cancellation_Reissue(4);
      di.is_new_dogovor = true;
      to_print = false;
   }
   else if(command == "���� ������ ������ ��������")
   {
      di.is_new_dogovor = false;
      int cur_calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
      to_print = m_api->dbGetBoolFromQuery(res, "select to_print from casco_calc where calc_id=" + IntToStr(cur_calc_id));
   }
   else if(command == "�������� ��������� ��� �������� ���� out->Values[<��� �����>]=[0 ��� 1] (������ �������� TStringList* out,������ int* calc_id)"){
      TStringList *out = (TStringList *)lparam, *fr = new TStringList();
      int calc_id = *(int*)hparam;

      for(int i = 0, cnt = out->Count; i < cnt; ++i) out->Values[out->Names[i]] = 0;

      TADOQuery *q = m_api->dbGetCursor(res, "select t1.[bank_id],t1.[full_insur],t1.[multidrive],t1.[variant_idx],t1.[type_franshiza],t1.[dop_sog],t1.[dogovor_type],t1.[reiss_type],t1.[programm_id],t2.[fast_report],t1.[kkv],t1.[polis_date],t1.[quotation_date],t1.[premiya_all],t1.[premium_main_risk],t1.[is_autorization],t1.[refund_value],t1.[date_zayavl],t1.[bases_cancell],t1.[extension_territory],t1.[alarms_info],t1.[is_gap],(select count(*) from casco_persons where calc_id=" + IntToStr(calc_id) + " and type_person > 3) as count_drivers from casco_calc as t1 left join gl_dict_banks as t2 on t1.[bank_id]=t2.[bank_id] where t1.[calc_id]=" + IntToStr(calc_id));
      int dog_type = q->FieldByName("dogovor_type")->AsInteger, sd = m_api->Raschet_Get_Status_id(res, calc_id), is_anketa = (q->FieldByName("kkv")->AsInteger > 0), is_ekonom = (q->FieldByName("programm_id")->AsInteger == 1045), is_comfort = (q->FieldByName("programm_id")->AsInteger > 1260 && q->FieldByName("programm_id")->AsInteger < 1265), is_ext_terr = q->FieldByName("extension_territory")->AsString == "��", is_alarm_ds5 = q->FieldByName("alarms_info")->AsInteger == 2, is_damagedtp = (q->FieldByName("programm_id")->AsInteger == 1286), is_gap = q->FieldByName("is_gap")->AsString == "��";
      if(dog_type < 3){
         int is_visible_list_calc = (DaysBetween((int)q->FieldByName("quotation_date")->AsDateTime, Date()) < 15 && q->FieldByName("premium_main_risk")->AsFloat > 0) || sd == 5;
         int is_visible = !(m_api->Err_Is_Calc_Error_By_Type(res, err_pr, calc_id)) && DaysBetween((int)q->FieldByName("quotation_date")->AsDateTime, Date()) < 15 && (((sd == 1 || sd == 4) && (int)q->FieldByName("polis_date")->AsDateTime >= Date()) || sd == 5);
         if(q->FieldByName("bank_id")->AsInteger > 0 && q->FieldByName("variant_idx")->AsInteger < 2){
            fr->Text = StringReplace(q->FieldByName("fast_report")->AsString, ";", "\r\n", rf);
            for(int i = 0, cnt = fr->Count; i < cnt; ++i) out->Values[fr->Strings[i]] = int(is_visible);
            out->Values["�����(����������) �� ������"] = is_visible;
            out->Values["�����(����������) �� ������(��������)"] = is_visible;
            out->Values["�������������� ���������� � ����������� �� �������� ���������"]           = int(is_visible && (q->FieldByName("full_insur")->AsInteger == 3));
            out->Values["�������������� ���������� � ����������� �� ��������� (��� ����� ������)"] = int(is_visible && (q->FieldByName("full_insur")->AsInteger == 2) && !q->FieldByName("variant_idx")->AsInteger);
            out->Values["�������������� ���������� � ����������� �� ��������� (� ������ ������)"]  = int(is_visible && (q->FieldByName("full_insur")->AsInteger == 2) && (q->FieldByName("variant_idx")->AsInteger == 1));
         }
         else{
            out->Values["����� �� ������"]           = is_visible;
            out->Values["����� �� ������(��������)"] = is_visible;
         }
         out->Values["�������������� ���������� � ������������ ����������� ��������"]               = int(is_visible && (q->FieldByName("type_franshiza")->AsInteger == 6));
         out->Values["�������������� ���������� �� ���. ������������"]                              = int(is_visible && q->FieldByName("dop_sog")->AsBoolean);
         out->Values["�������������� ���������� � ���������� � ����������"]                         = int(is_visible && (q->FieldByName("count_drivers")->AsInteger > 3));
         out->Values["�������������� ���������� �� ����������� ����� ���, ���������� � ����������"] = int(is_visible && (q->FieldByName("multidrive")->AsInteger == 2));
         out->Values["�������������� ���������� (������ 2012)"]                                     = int(is_visible && is_ekonom);
         out->Values["�������������� ���������� (������� �� ������)"]                               = int(is_visible && is_comfort);
         //out->Values["��������� (������� �� ������)"]                                               = int(is_visible && is_comfort);
         out->Values["�������������� ���������� � ���������� ���������� �����������"]               = int(is_visible && is_ext_terr);
         out->Values["�������������� ���������� �� ��������� �������������� �������"]               = int(is_visible && is_alarm_ds5);
         out->Values["�������������� ���������� (����� � ���)"]                                     = int(is_visible && is_damagedtp);
         out->Values["�������������� ���������� � ���������� GAP"]                                  = int(is_visible && is_gap);

         out->Values["���� ������� ��������� ������"] = is_visible_list_calc;
         out->Values["������ �������"]                = int(is_visible && is_anketa);
      }
      else if(dog_type == 3 || dog_type == 5){
         int is_visible = !(m_api->Err_Is_Calc_Error_By_Type(res, err_canc, calc_id)) && (int)q->FieldByName("date_zayavl")->AsDateTime == Date();

         out->Values["��������� � ��������� ����������� ��������"] = int(is_visible && q->FieldByName("bases_cancell")->AsInteger == 0);
         out->Values["�������������� ���������� � ��������� ����������� �������� ������ �����������"] = int(is_visible && q->FieldByName("is_autorization")->AsInteger);
         out->Values["������������ �� ������� ����� ��������� ������"] = int(is_visible && q->FieldByName("is_autorization")->AsInteger && q->FieldByName("refund_value")->AsFloat > 0);
      }
      else if(dog_type == 4){
         int is_visible = !(m_api->Err_Is_Calc_Error_By_Type(res, err_reiss, calc_id)) && (int)q->FieldByName("date_zayavl")->AsDateTime == Date(), agreed = (sd == 13 || sd == 10 || sd == 15);
         out->Values["���������(������) �� �������� ��������� � ����� ������������� ����������� ��"] = int(is_visible && !q->FieldByName("is_autorization")->AsInteger);
         if(is_visible && q->FieldByName("is_autorization")->AsInteger){
            out->Values["��������� �� �������� ��������� � ����� ������������� ����������� ��"] = 1;
            TADOQuery *q_reasons = m_api->dbGetCursor(res, "select t1.reason_id,t2.fast_report from casco_reiss_reasons t1,cascoreissuereason t2 where t1.reason_id=t2.id and t1.calc_id="  + IntToStr(calc_id) + " order by t1.reason_id"), *q_casco_r = m_api->dbGetCursor(res, "select multidrive,str_summa,str_summa1,str_summa2,surcharge_value_ss from casco_calc_r where calc_id=" + IntToStr(calc_id));
            bool is_ds18 = q_reasons->Locate("reason_id", 18, locate) && q_casco_r->FieldByName("surcharge_value_ss")->AsFloat > 0;
            int multidrive = q_casco_r->FieldByName("multidrive")->AsInteger;
            for(q_reasons->First(); !q_reasons->Eof; q_reasons->Next()){
               if(q_reasons->FieldByName("reason_id")->AsInteger == 1){
                  out->Values["�C �4.1 � ������ ����������� �� ������ ���, ���������� � ���������� ������������ ���������"] = int(multidrive == 0 && agreed);
                  out->Values["�C �8 � ������ ����������� �� ������ ���, ���������� � ���������� ������������ ���������"] = int(multidrive == 2 && agreed);
                  out->Values["�C �4 � ���������� � ����������"] = int(multidrive == 100 && agreed);
               }
               else if(q_reasons->FieldByName("reason_id")->AsInteger == 18)
                  out->Values["�C �21�"] = int(agreed && is_ds18);
               else if(q_reasons->FieldByName("reason_id")->AsInteger == 19)
                  out->Values["�C �14� � ���������� GAP"] = int(agreed && (!is_ds18 || q_casco_r->FieldByName("str_summa2")->AsFloat <= q_casco_r->FieldByName("str_summa")->AsFloat));
               else out->Values[q_reasons->FieldByName("fast_report")->AsString] = int(agreed);
            }
            m_api->dbCloseCursor(res, q_reasons); m_api->dbCloseCursor(res, q_casco_r);

            //out->Values["�������������� ���������� � ���������� ���������� �����������"] = int(is_ext_terr);
         }
      }
      else{}
      m_api->dbCloseCursor(res, q);
      delete fr;
   }

   else if(command == "��������� ���������� �� ��� (������ �������� - ��� ����������� AnsiString*, api ��� ����� �������� �������� glDic_Get_SKK_API)"){
      AnsiString key = *((AnsiString*)lparam);
      mops_api_008* skk_api = dynamic_cast<mops_api_008*>(m_api)->glDic_Get_SKK_API(res);
      if(key == "7.2.43"){
         int memo_id(0);
         m_api->dbExecuteQuery(res, "delete * from alarm"); m_api->dbExecuteQuery(res, "delete * from gl_dict_protivougon_memo"); m_api->dbExecuteQuery(res, "delete * from gl_dict_protivougon");
         AnsiString quote("\""), sql("");
         TADOQuery *q_source1 = skk_api->dbGetCursor(res, "select distinct replace(alarm_systems,CHR(34)) from rgsscc.ref_cascoalarmsystems where sysdate<=date_to"), *q_source2, *q_dest = m_api->dbGetCursor(res, "select * from gl_dict_protivougon", 0);
         for(q_source1->First(); !q_source1->Eof; q_source1->Next()){
            AnsiString alarm_text = q_source1->Fields->Fields[0]->AsString;
            //m_api->dbReadWriteInternalMemo(res, alarm_text, memo_id, false, "gl_dict_protivougon_memo");
            //m_api->dbExecuteQuery(res, "insert into alarm (memo_id, memo_text) values(" + IntToStr(++memo_id) + ",'" + alarm_text + "')");
            m_api->dbExecuteQuery(res, "insert into gl_dict_protivougon_memo (memo_id, memo_text) values(" + IntToStr(++memo_id) + ",'" + alarm_text + "')");
            q_source2 = skk_api->dbGetCursor(res, sql.sprintf("select %i as id_alarm, NVL(t2.casco_territory_id,0),t1.autodictvehiclegroup_vehicl_fk,t3.code,NVL(t1.year_prod_min,0),NVL(t1.year_prod_max,0),t1.risk_group,t1.start_date,NVL(t1.end_date,'01.01.3000') from rgsscc.ref_cascoalarmsystems t1,rgsscc.ref_autodictcascoterritory t2,rgsscc.ref_carrier_models t3 where t1.autodictcascoterritory_casc_fk=t2.id(+) and t1.carrier_models_code_fk=t3.id(+) and sysdate<=t1.date_to and sysdate<=NVL(t2.date_to,sysdate) and sysdate<=NVL(t3.date_to,sysdate) and replace(t1.alarm_systems,CHR(34))='%s'", memo_id, alarm_text), 0, 0);
            q_source2->Parameters->Clear();
            q_source2->ParamCheck = false;
            q_source2->Open();
            for(q_source2->First(); !q_source2->Eof; q_source2->Next()){
               q_dest->Insert();
               for(int i = 0, fcnt = q_source2->FieldCount; i < fcnt; ++i) q_dest->Fields->Fields[i]->AsString = q_source2->Fields->Fields[i]->AsString;
            }
            skk_api->dbCloseCursor(res, q_source2);
         }
         q_dest->UpdateBatch();
         m_api->dbCloseCursor(res, q_dest); skk_api->dbCloseCursor(res, q_source1);
      }
      else if(key == "5.4.15"){
         m_api->dbExecuteQuery(res, "delete * from gl_dict_black_list_persons"); m_api->dbExecuteQuery(res, "delete * from gl_dict_black_list_vehicle");
         TDateTime dt;
         TADOQuery *q_source = skk_api->dbGetCursor(res, "select t1.clients_name,t1.db_inn,t1.initiator,t1.link_to_414_fk,t2.subject_federation_name from rgsscc.ref_specialclients t1,apo.subject_rf t2 where t1.link_to_414_fk=t2.id(+) and t1.clients_name is not null and sysdate<t1.date_to"), *q_dest = m_api->dbGetCursor(res, "select * from gl_dict_black_list_persons", 0);
         for(q_source->First(); !q_source->Eof; q_source->Next()){
            if(q_source->Fields->Fields[0]->AsString.IsEmpty() || q_source->Fields->Fields[1]->AsString.IsEmpty() || q_source->Fields->Fields[2]->AsString.IsEmpty() || !TryStrToDate(q_source->Fields->Fields[1]->AsString, dt)) continue;
            q_dest->Insert();
            for(int i = 0, fcnt = q_source->FieldCount; i < fcnt; ++i) q_dest->Fields->Fields[i]->AsString = !i ? AnsiString(m_api->Normalization_String_RSA(res, q_source->Fields->Fields[i]->AsString)) : q_source->Fields->Fields[i]->AsString;
         }
         q_dest->UpdateBatch();
         m_api->dbCloseCursor(res, q_dest); skk_api->dbCloseCursor(res, q_source);
         q_source = skk_api->dbGetCursor(res, "select marka_tc,num_tc,vin_tc,initiator from rgsscc.ref_specialclients where clients_name is null and sysdate<date_to"); q_dest = m_api->dbGetCursor(res, "select * from gl_dict_black_list_vehicle", 0);
         for(q_source->First(); !q_source->Eof; q_source->Next()){
            q_dest->Insert();
            for(int i = 0, fcnt = q_source->FieldCount; i < fcnt; ++i) q_dest->Fields->Fields[i]->AsString = (i == 1 || i == 2) ? NormVIN_GN(m_api, q_source->Fields->Fields[i]->AsString) : q_source->Fields->Fields[i]->AsString;
         }
         q_dest->UpdateBatch();
         m_api->dbCloseCursor(res, q_dest); skk_api->dbCloseCursor(res, q_source);
      }
      else if(key == "7.6.37"){
         int max_id = m_api->dbGetIntFromQuery(res, "select max(bank_id) from gl_dict_banks");
         TblQue val = skkq[key];
         TADOQuery *q_source = skk_api->dbGetCursor(res, val.sql_skk), *q_dest = m_api->dbGetCursor(res, "select * from " + val.table_apo + " order by bank_code", 0);
         for(q_source->First(); !q_source->Eof; q_source->Next()){
            FilterDataSet(q_dest, "bank_code='" + q_source->FieldByName("bank_code")->AsString + "'");
            if(q_dest->IsEmpty()){
               q_dest->Filtered = false;
               q_dest->Insert();
               q_dest->FieldByName("bank_id")->Value   = ++max_id;
               q_dest->FieldByName("bank_code")->Value = q_source->FieldByName("bank_code")->Value;
            }
            else q_dest->Edit();
            q_dest->FieldByName("bank_name")->Value = q_source->FieldByName("bank_name")->Value;
            q_dest->FieldByName("bank_name_print")->Value = q_source->FieldByName("bank_name_print")->Value;
            q_dest->FieldByName("benefic")->Value = q_source->FieldByName("benefic")->Value;
            q_dest->FieldByName("requirements")->Value = q_source->FieldByName("requirements")->Value;
            q_dest->FieldByName("bank_address")->Value = q_source->FieldByName("bank_address")->Value;
            q_dest->FieldByName("compensation_type")->Value = q_source->FieldByName("compensation_type")->Value;
            q_dest->FieldByName("rules_redaction")->Value = q_source->FieldByName("rules_redaction")->Value;
            q_dest->FieldByName("beneficiary")->Value = q_source->FieldByName("beneficiary")->Value;
            q_dest->FieldByName("mortgagee")->Value = q_source->FieldByName("mortgagee")->Value;
            q_dest->FieldByName("policy_mask")->Value = q_source->FieldByName("policy_mask")->Value;
            q_dest->FieldByName("prg_prj_id")->Value = q_source->FieldByName("project_id")->Value;
            q_dest->FieldByName("start_date")->Value = q_source->FieldByName("start_date")->Value;
            q_dest->FieldByName("end_date")->Value = q_source->FieldByName("end_date")->Value;
         }
         q_dest->UpdateBatch();
         m_api->dbCloseCursor(res, q_dest); skk_api->dbCloseCursor(res, q_source);
      }
      else if(key == "7.4.20")  {
      Application->MessageBox("������ ���������� �� ����������� � ���� ������, ������� ������ � ����!","�������������� �����", MB_OK | MB_ICONINFORMATION);}
      else if(key == "7.4.21")  {
      Application->MessageBox("������ ���������� �� ����������� � ���� ������, ������� ������ � ����!","�������������� �����", MB_OK | MB_ICONINFORMATION);}
      else if(key == "7.4.22")  {
      Application->MessageBox("������ ���������� �� ����������� � ���� ������, ������� ������ � ����!","�������������� �����", MB_OK | MB_ICONINFORMATION);}
      else if(key == "7.4.23")  {
      Application->MessageBox("������ ���������� �� ����������� � ���� ������, ������� ������ � ����!","�������������� �����", MB_OK | MB_ICONINFORMATION);}
      else if(key == "7.4.24")  {
      Application->MessageBox("������ ���������� �� ����������� � ���� ������, ������� ������ � ����!","�������������� �����", MB_OK | MB_ICONINFORMATION);}
      else if(key == "7.4.25")  {
      Application->MessageBox("������ ���������� �� ����������� � ���� ������, ������� ������ � ����!","�������������� �����", MB_OK | MB_ICONINFORMATION);}
      else{
         TblQue val = skkq[key];
         mops_api_007* api = val.transdekra ? (mops_api_007*)m_api->glDic_Get_API(res, "����������, ���������") : m_api;
         api->dbExecuteQuery(res, "delete * from " + val.table_apo);
         TADOQuery *q_source = skk_api->dbGetCursor(res, val.sql_skk), *q_dest = api->dbGetCursor(res, "select * from " + val.table_apo, 0);
         for(q_source->First(); !q_source->Eof; q_source->Next()){
            q_dest->Insert();
            for(int i = 0, fcnt = q_source->FieldCount; i < fcnt; ++i) q_dest->Fields->Fields[i]->AsString = q_source->Fields->Fields[i]->AsString;
         }
         q_dest->UpdateBatch();
         api->dbCloseCursor(res, q_dest); skk_api->dbCloseCursor(res, q_source);
         if(key == "7.7.57") api->dbExecuteQuery(res, "update gl_dict_banksrequirements as t1,gl_dict_banks as t2 set t1.bank_id=t2.bank_id where t1.bank_code=t2.bank_code");
         else if(key == "7.3.69") api->dbExecuteQuery(res, "update cascodictkb as t1,gl_dict_banks as t2 set t1.bank_id=t2.bank_id where t1.bank_code=t2.bank_code");
         else if(key == "7.4.30"){
            api->dbExecuteQuery(res, "update gl_dict_programm_project set project_id=0 where project_id=1266");
            //api->dbExecuteQuery(res, "delete from gl_dict_programm_project where project_id in(1271, 1272, 1273, 1278, 1280, 1281, 1282, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 1314, 1315, 1318, 1319, 1320, 1333, 1334, 1335, 1349, 1350, 1352)");
            api->dbExecuteQuery(res, "update gl_dict_programm_project set ka_min=1 where project_id=1286");
         }
         else {}
      }
   }

   else if(command == "������ ������ ��� ������ ������ (������ �������� - ��������� �� ������ TsButton*; ������ - ������ ������� TList*))"){
      TsButton* btn = reinterpret_cast<TsButton*>(lparam);
      if(btn->Caption == "���� ������������"){
         btn->Enabled = false;
/* //#include "newcalc.h"
         reinterpret_cast<TFrameNew*>(reinterpret_cast<TList*>(hparam)->Items[(di.is_ander_login || is_precalc) ? 1 : 0])->btnZapros = btn;
*/
      }
   }

   else if(command == "���� ������ ������ (������ �������� - ��������� �� ������ TsButton*; ������ - ������ ������� TList*))")
   {
/* //#include "newcalc.h"
      if(reinterpret_cast<TsButton*>(lparam)->Caption == "���� ������������") reinterpret_cast<TFrameNew*>(reinterpret_cast<TList*>(hparam)->Items[(di.is_ander_login || is_precalc) ? 1 : 0])->Form171ToExcel();
*/
   }

   else if(command == "������������ ��������� xml ���� (������ �������� ��� ����� AnsiString*,���� ���������; ������ XML - AnsiString*)"){
      AnsiString type_xml = *(AnsiString*)lparam, xml = *(AnsiString*)hparam;
      if(type_xml == "���2"){
         int calc_id = XMLLoad(xml);
         if(calc_id) *(AnsiString*)lparam = "Calc_Id=" + IntToStr(calc_id);
      }
      else if(type_xml == "�����") XMLLoadCalen(xml);
      else if(type_xml == "������ �� ���") LoadDataFromARM(xml);
      else if(type_xml == "OIB") XMLLoadOIB(xml);
   }

   else if(command == "���� ������������ ������� (������ �������� - �������� ����� TFrame*, ������ ������ ���� ������� TList *)"){
      int tg = reinterpret_cast<TFrame*>(lparam)->Tag;
      if(tg == 0){
         if(!di.is_ander_login) m_api->Err_Set_Visible_Errors_Types(res, "������ ����������|�������� � ���", true);
         m_api->Err_Set_Visible_Errors_Types(res, err_calc, false);
      }
      else if(tg == 50){
/* //#include "oldcalc.h"
         m_api->Err_Set_Visible_Errors_Types(res, err_calc, true);
         reinterpret_cast<TFramePreCalc*>(lparam)->InvalidateAll();
*/         
      }

      else if(tg == 100){
         TframeOffCust *fo = reinterpret_cast<TframeOffCust*>(lparam);
/* //#include "newcalc.h"
         bool is_preview = reinterpret_cast<TFrameNew*>(((TList*)hparam)->Items[(di.is_ander_login || is_precalc) ? 1 : 0])->IsOfferEnabled();
         fo->labInfo->Visible     = !is_preview;
         fo->frxPreview1->Visible = is_preview;
         fo->printPanel->Visible  = is_preview;
         if(is_preview){
            fo->frxForClient->Top = fo->printPanel->Height + 2;
            fo->frxForClient->ShowReport(true);
         }
         m_api->Err_Set_Visible_Errors_Types(res, err_calc, false);
*/
      }
      else if(tg == 150){
         bool is_no_agreed = di.status_dogovor != 2;
         m_api->Err_Set_Visible_Errors_Types(res, "������ ����������|�������� � ���", is_no_agreed);
         reinterpret_cast<TFrame1*>(lparam)->SetVisibleDogovorRows(is_no_agreed);
         SetHeightInspector_2(reinterpret_cast<TFrame1*>(lparam)->DogovorInfo);
         reinterpret_cast<TFrame1*>(lparam)->InvalidateAll();
         m_api->Err_Set_Visible_Errors_Types(res, err_calc, false);
      }
   }

   else if(command == "������������ ������� ��������? (������ �������� bool*)") *((bool*)lparam) = true;

   else if(command == "�������� ������ �� ����� �� �������� (������ �������� int* calc_id)"){
      AnsiString calc_id_str = IntToStr(*(int*)lparam), sql("");
      TADOQuery *q = m_api->dbGetCursor(res, "select calc_id,quotation_date,calc_k5_k6,central_bd_error,cross_error from casco_calc where calc_id=" + calc_id_str);
      int calc_k5_k6 = (int)q->FieldByName("quotation_date")->AsDateTime == Date() ? q->FieldByName("calc_k5_k6")->AsInteger : 1, central_bd_error = q->FieldByName("central_bd_error")->AsInteger, cross_error = q->FieldByName("cross_error")->AsInteger;
      m_api->dbCloseCursor(res, q);

      m_api->dbExecuteQuery(res, sql.sprintf("update casco_calc set quotation_date=Date(),calc_k5_k6=%i,central_bd_error=%i,cross_error=%i,dogovor_type=%i where calc_id=%s", calc_k5_k6, central_bd_error, cross_error, di.dogovor_type, calc_id_str));
   }

   else if(command == "��������� ������� TDataForm::FormShow(TObject *Sender) ������ �������� - Sender, ������ - TList * � ��������"){
      if(((TList*)hparam)->Count > 3){
         if(to_print) m_api->Set_Active_Frame(res, reinterpret_cast<TFrame1*>(((TList*)hparam)->Items[is_precalc ? 4 : 3]));
         m_api->Err_Set_Visible_Errors_Types(res, err_calc, true);
/* //#include "oldcalc.h"
         if(is_precalc) reinterpret_cast<TFramePreCalc*>(((TList*)hparam)->Items[0])->InvalidateAll();
*/
      }
   }

   else if(command == "����� � ����� ������� ����� ������ �������� (������ �������� TStringList*, ����������� �������� �������� � ->Values[<������>])"){
      if(!m_api->is_debug){
         TStringList *out = (TStringList *)lparam;
         for(int i = 0, cnt = out->Count; i < cnt; ++i) out->Values[out->Names[i]] = 0;
      }
   }

   else if(command == "����� ��� ������ XML ��� SOAP ������� �������� � ��� (������ �������� AnsiString*)") *(AnsiString*)lparam = AnsiString("0.0.2.0");

   else if(command=="��������� ������� TDataForm::FormShow(TObject *Sender) ������ �������� - Sender, ������ - TList * � ��������"){
      if(di.is_ander_login){
         TList *l = (TList*)hparam;
         TAnderrFrame *af = (TAnderrFrame*)l->Items[0];
         af->ResizeTimer->Enabled = true; // ������� ������ ��������
      }
   }

   else if(command == "�������� ���������� (������ �������� bool*, �������� ��������� �� �������� ������ �� email;������ Exception*)"){
      if(((Exception*)hparam)->Message == "������������ ����") *((bool*)lparam) = false;
   }

   return 1;
}
//------------------------------------------------------------------------------
int Print_Form(AnsiString form_name, long id_calc){ return 1; }
//------------------------------------------------------------------------------
#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
   //log("����� � DllEntryPoint");

   return 1;
}
//---------------------------------------------------------------------------

