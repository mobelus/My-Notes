//---------------------------------------------------------------------------
#define NO_WIN32_LEAN_AND_MEAN
#include <vcl.h>
#include <dateutils.hpp>
#pragma hdrstop
#include "oldcalc.h"
#include "dopuprformc.h"
//#include "newcalc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "frxClass"
#pragma link "frxDesgn"
#pragma link "sBitBtn"
#pragma link "sCheckBox"
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma link "cxCustomData"
#pragma link "cxTextEdit"
#pragma link "cxTL"
#pragma link "cxDropDownEdit"
#pragma link "cxDBEditRepository"
#pragma resource "*.dfm"
TFramePreCalc *FramePreCalc;
//---------------------------------------------------------------------------
__fastcall TFramePreCalc::TFramePreCalc(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, TSInfo *p_tsi, Dogovor_Info *p_di)
    : TFrame(Owner), m_api(mops), in_event(false), group_ts(-1), last_err(""), risk(2), bank_multidrive(true), is_risk_ts(false), is_trans(false), curr_year(YearOf(Date())), nf_bt(true),
    ts_age_min(0), ts_age_max(5), name_prod("�� ��.102, 158 ���� ���.���"), code_prod(445), age_min(0), drv_exp_min(0),
    curr_rg_pl(new TStringList()), non_standart_str(new TStringList()), count_permit_after_load(0), type_multydrive(100), enable_k1f(false), error(new TStringList()),
    pi(p_pi), pm(p_pm), tsi(p_tsi), di(p_di), contract_type(0), k5(1), k6(1), status_dogovor(1), k1(1), kd(1), kar(1), programm_id(0)
{
}
//---------------------------------------------------------------------------
__fastcall TFramePreCalc::~TFramePreCalc()
{
   delete curr_rg_pl;
   delete non_standart_str;
   delete error;

   m_api->dbCloseCursor(res, srok);
   //m_api->dbCloseCursor(res, franshize);
   m_api->dbCloseCursor(res, min_rate);
   m_api->dbCloseCursor(res, region_bl);
   m_api->dbCloseCursor(res, dict_kb);
   m_api->dbCloseCursor(res, q_regions);
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::Button1Click(TObject *Sender)
{
   //int i = RoundTo(89382.97, 4);
   //int i = RoundTo(89382.97, 4);
   //ShowMessage(i);
   //cxTreeList1->Clear();
   //tdr.LoadParamsToTreeList(cxTreeList1);
   //ShowMessage(memoAnderr->Lines->Count);
/*   for(int i = 0, cnt = CalcInfo->TotalRowCount; i < cnt; ++i)
     non_standart_str->Add(IntToStr(i) + "; "  + CalcInfo->Rows[i]->Name );
   non_standart_str->SaveToFile("D:\\CalcInfo.txt");*/
}
//---------------------------------------------------------------------------
void TFramePreCalc::Init()
{
   risk_code[0] = "_ROOT1000000KASKOA1024221;_ROOT1000000KASKOA1024222";
   risk_code[1] = "_ROOT100000KASKOA10270721";
   risk_code[2] = empty_str;

   is_trans = tdr.Init(m_api);
   //PopupItem->Properties->
   q = m_api->dbGetCursor(res, "select * from ts_type order by code");
   for(q->First(); !q->Eof; q->Next())
      cboxTSType->Items->AddObject(q->FieldByName("full_name")->AsString.Trim(), (TObject*)StrToInt(q->FieldByName("code")->AsString.Trim()));
   m_api->dbCloseCursor(res, q);
   cboxTSType->EditText = cboxTSType->Items->Strings[0];

   LoadTSMarkaList();

   srok = m_api->dbGetCursor(res, "select * from cascodictk03");

   //franshize = m_api->dbGetCursor(res, "select * from cascodictk04");

   dict_kb = m_api->dbGetCursor(res, "select * from cascodictkb");

   prg_comfort.insert(1261);
   prg_comfort.insert(1262);
   prg_comfort.insert(1263);
   prg_comfort.insert(1264);

   min_premium_ekonom[1] = 10000;
   min_premium_ekonom[2] = 15000;
   min_premium_ekonom[3] = 33000;
   min_premium_ekonom[6] = 8000;
   min_premium_ekonom[7] = 8000;

   cboxTypeFranshiza->Items->AddObject("�� �����������", new DataDict(1, 1.0, 1));
   //cboxTypeFranshiza->Items->AddObject("�����������",    new DataDict(3, 1.0, 1));

   payment_date[0] = Date();

   if(di->is_new_dogovor){
      LoadRegions();
      LoadData();
      ControlChange(0);
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadRegions()
{
   q_regions = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_regions where CDate('%s')>=start_date and CDate('%s')<=end_date order by terr_name", di->calc_date, di->calc_date));
   for(cboxRegion->Items->Clear(), q_regions->First(); !q_regions->Eof; q_regions->Next()){
      DataDict *rd = new DataDict(q_regions->FieldByName("terr_id")->AsInteger, q_regions->FieldByName("limit_str_summa")->AsFloat, q_regions->FieldByName("transdekra")->AsInteger);
      rd->rg_pl = q_regions->FieldByName("reg_plate")->AsString;
      cboxRegion->Items->AddObject(q_regions->FieldByName("terr_name")->AsString.Trim(), rd);
   }
   //ds_regions->DataSet = q_regions;
   //RegionComboBoxItem->Properties->ListSource = ds_regions;

   if(di->is_new_dogovor){
      AnsiString region = m_api->vrGetVariable(res, "KASKO_Territory").Trim();
      if(!TryStrToInt(region, region_id)) region_id = DEFAULT_CITY;
      int ind = GetIndexObject(cboxRegion->Items, region_id);
      if(ind == -1){
         region_id = DEFAULT_CITY;
         ind = GetIndexObject(cboxRegion->Items, region_id);
      }
      cboxRegion->EditText = cboxRegion->Items->Strings[ind];
      //vgEditorRow1->Properties->Value = region_id;
      LoadRegionData();
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadTSMarkaList()
{
   cboxTSModel->EditText = empty_str;
   cboxTSMarka->EditText = empty_str;
   q = m_api->dbGetCursor(res, "select distinct brand_name from gl_dict_carrier_models where carrier_type_fk=" + IntToStr(tsi->tstype_id), 0);
   for(model_id = 0, cboxTSModel->Items->Clear(), cboxTSMarka->Items->Clear(), q->First(); !q->Eof; q->Next()) cboxTSMarka->Items->Add(q->FieldByName("brand_name")->AsString.Trim());
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadTSModelList()
{
   cboxTSModel->EditText = empty_str;
   q = m_api->dbGetCursor(res, "select code, model_name from gl_dict_carrier_models where brand_name='" + cboxTSMarka->EditText + "' and (carrier_type_fk=" + IntToStr(tsi->tstype_id) + ") order by model_name");
   for(model_id = 0, cboxTSModel->Items->Clear(), q->First(); !q->Eof; q->Next())
      cboxTSModel->Items->AddObject(q->FieldByName("model_name")->AsString.Trim(), (TObject*)StrToInt(q->FieldByName("code")->AsString.Trim()));
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadVozmTypeList()
{
   q = m_api->dbGetCursor(res, sql.sprintf("select cp.pay_id,pay_name from CascoPayment cp, CascoPaymentProd cpp where cp.pay_id=cpp.pay_id and product_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date order by sort_order desc", ProductID(), di->calc_date, di->calc_date));
   for(cboxVozmType->Items->Clear(), q->First(); !q->Eof; q->Next()) cboxVozmType->Items->AddObject(q->FieldByName("pay_name")->AsString.Trim(), (TObject*)q->FieldByName("pay_id")->AsInteger);
   cboxVozmType->EditText = cboxVozmType->Items->Strings[0];
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadRegionData()
{
   int index = cboxRegion->Items->IndexOf(cboxRegion->EditText);
   if(index < 0) return;

   DataDict *rd = (DataDict*)cboxRegion->Items->Objects[index];
   region_id = rd->id;
   tdr.SetRegion(rd->field_val1);
   curr_rg_pl->Text = StringReplace(rd->rg_pl, ";", "\r\n", rf);

   /*region_id = vgEditorRow1->Properties->Value;
   Variant values = RegionComboBoxItem->Properties->ListSource->DataSet->Lookup("terr_id", region_id, "transdekra;reg_plate");
   if(values.IsArray()){
      tdr.SetRegion(values.GetElement(0));
      curr_rg_pl->Text = StringReplace(values.GetElement(1), ";", "\r\n", rf);
   }*/

   curr_limit = m_api->dbGetFloatFromQuery(res, sql.sprintf("select filial_sum_limit from gl_dict_limit_branches where branch_code='' and product_id=%i and casco_territory_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", ProductID(), region_id, di->calc_date, di->calc_date));
   di->REGION_TYPE = m_api->dbGetIntFromQuery(res, sql.sprintf("select type_id from gl_dict_dsago_contract where cnt_cl_id=5 and terr_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", region_id, di->calc_date, di->calc_date));
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::RegionComboBoxItemPropertiesEditValueChanged(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   if(r && !r->Properties->Value.IsNull()) ControlChange(r);
}
//---------------------------------------------------------------------------

inline int TFramePreCalc::ProductID() // �������: 301-306
{
   return cboxVariant->Items->IndexOf(cboxVariant->EditText) + (pi[0].status == 0 ? 301 : 304);
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::cboxRegionCloseUp(TObject *Sender,  Variant &Value, bool &Accept)
{
   AnsiString str = Value;
   TdxInspectorTextPickRow *r = dynamic_cast<TdxInspectorTextPickRow*>(Sender);
   if(!r->ReadOnly && str != r->EditText){
      r->EditText = str;
      this_frame = true;
/* //#include "newcalc.h"
      f_calc->SetFalseThisFrame();
*/
      ControlChange(r);
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::CalcInfoDrawValue(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone)
{
   switch(Sender->Tag){
      case 1:  AColor = (curr_error == "�� ������ ������ ���������� ��������") ? clError : clWhite; break;
      case 2:  AColor = (curr_error == "�� ������ ����") ? clError : clWhite; break;
      case 3:  AColor = (curr_error == "��� ��������� �� ��� �������� ����������� �� ������� ����� ����������� ������������������ ������ ���� ������ 0.8") ? clError : clWhite; break;
      case 10: AColor = (curr_error == "������� ������� ����������� ������������ �����" || curr_error == "���������� ���������� ������ ��, �.�. ������� ������� ����������� ������������ �����") ? clError : clWhite; break;
      case 11: AColor = (curr_error == "������� ������� ����� ���� ������������� ��������" || curr_error == "���������� ���������� ������ �� , �.�. ������� ������� ����� ���� ������������� ��������") ? clError : clWhite; break;
      case 12: AColor = (curr_error == "�� ������� ����� ��") ? clError : clWhite; break;
      case 13: AColor = (curr_error == "�� ������� ������ ��") ? clError : clWhite; break;
      case 14: AColor = (curr_error == "������� ������ ��� ������� ��" || curr_error.AnsiPos("������ ������� �������") > 0) ? clError : clWhite; break;
      case 15: AColor = (curr_error == "������� ������� ���� ������ ���") ? clError : clWhite; break;
      case 19: AColor = (curr_error == "������� ������� �������������� ��������� ��" || curr_error == "����������� ������������������ ������ ���������� � �������� �� 0,5 �� 1" || curr_error == "��� ��������� �� ��� �������� ����������� �� ������� ����� ����������� ������������������ ������ ���� ������ 0.8") ? clError : clWhite; break;
      case 20: AColor = (curr_error == "������� ������� ��������� ����� �� ��������� �����" || curr_error == "����������� ������������������ ������ ���������� � �������� �� 0,5 �� 1" || curr_error == "��� ��������� �� ��� �������� ����������� �� ������� ����� ����������� ������������������ ������ ���� ������ 0.8") ? clError : clWhite; break;
      case 21: AColor = (curr_error == "��� ��������� �� ��� �������� ����������� �� ������� ����� ����������� ������������������ ������ ���� ������ 0.8") ? clError : clWhite; break;
      case 22: AColor = (curr_error == "�� ������� ���������� � �������������� �������� �� ������ ��") ? clError : clWhite; break;
      case 23: AColor = (curr_error == "�� ������� �������������� �������, ������������� �� ��") ? clError : clWhite; break;
      case 24: AColor = (curr_error == "�� ������� ���������� � ����������") ? clError : clWhite; break;
      case 25: AColor = (curr_error.AnsiPos("������ ������� �������") > 0) ? clError : clWhite; break;
      case 26: AColor = (curr_error == "�� ������ ������ ���������� ������") ? clError : clWhite; break;
      case 27: AColor = (curr_error == "�� ������� �������� ����������� ��������") ? clError : clWhite; break;
      case 28: AColor = (curr_error == "�� ������ ��������� ����������� �� �����" || curr_error == "�� ������� ���������� ������� �� ����������� ��������") ? clError : clWhite; break;
      case 29: AColor = (curr_error.AnsiPos("��� ������ ������� ������ ������� ���������") > 0) ? clError : clWhite; break;
      case 31: AColor = (curr_error.AnsiPos("�� ������ ��� �� ���������") > 0) ? clError : clWhite; break;
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::CalcInfoKeyDown(TObject *Sender, WORD &Key,  TShiftState Shift)
{
   if(Key == VK_DOWN && UINT(CalcInfo->FocusedNode) == UINT(cboxMultidrive->Node)){
      TermsInfo->SetFocus();
      rgMainRisk->Node->Focused = true;
   }
   if(UINT(CalcInfo->FocusedNode) == UINT(labCoefProp->Node)){
      labCoefProp->EditText = FloatToStr(di->calc_info.coef_prop);
      CalcInfo->Invalidate();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::TermsInfoKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
   if(Key == VK_UP && UINT(TermsInfo->FocusedNode) == UINT(rgMainRisk->Node)){
      CalcInfo->SetFocus();
      DriversHead->Node->Focused = true;
      cboxMultidrive->Node->Focused = true;
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::CalcInfoEditChange(TObject *Sender)
{
   TdxInspectorRow *r = dynamic_cast<TdxInspectorRow*>(Sender);

   if(!r->Inspector->InplaceEditor) return;

   labHint->Top = GetToplabHint(r->Inspector);

   AnsiString val = r->Inspector->InplaceEditor->GetEditingText().Trim();
   TDateTime dt;
   bool Accept;

   switch(r->Tag){
      case 10: tsi->max_massa = val.ToIntDef(0);  labHint->Visible = true; GetGroupTS(); break;
      case 11: tsi->seat_count = val.ToIntDef(0); labHint->Visible = true; GetGroupTS(); break;
      case 15: if(val.Length() < 10 || !TryStrToDate(val, date_pts)) date_pts.Val = 0; labHint->Visible = true; break;
      case 19:
         di->calc_info.cost_vehicle = StrToFloatStr(val).ToDouble();
         if(editStrSumma->ReadOnly) di->calc_info.str_summa = di->calc_info.cost_vehicle;
         labHint->Visible = true;
         break;
      case 20: di->calc_info.str_summa = StrToFloatStr(val).ToDouble(); labHint->Visible = true; break;
      default: if(AnsiString(r->ClassName()) == combobox) dynamic_cast<TdxInspectorTextPickRow*>(r)->OnCloseUp(Sender, val, Accept);
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::CalcInfoEdited(TObject *Sender, TdxInspectorNode *Node, TdxInspectorRow *Row)
{
   labHint->Visible = false;
   this_frame = true;
   switch(Row->Tag){
      case 10: ControlChange(editMaxMassa); break;
      case 11: ControlChange(editSeatCount); break;
      case 15: ControlChange(datePTS); break;
      case 19:
         if(editStrSumma->ReadOnly) editStrSumma->EditText = FloatToStr(di->calc_info.cost_vehicle); Calc();
/* //#include "newcalc.h"
         f_calc->editTSRealCost->EditText = editTSRealCost->EditText;
         if(f_calc->editStrSumma->ReadOnly) f_calc->editStrSumma->EditText = editStrSumma->EditText;
         f_calc->Calc();
*/
         break;
      case 20:
         Calc();
/* //#include "newcalc.h"
         f_calc->editStrSumma->EditText = editStrSumma->EditText;
         f_calc->Calc();
*/
         break;
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::GeneralInfoHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone)
{
   SetHeightInspector_1(CalcInfo);

   bool state = DriversHead->Node->Expanded && type_multydrive == 100 && !pi[0].status && !tsi->IsSpectech();
   btnDopushPlus->Visible  = state;
   btnDopushEdit->Visible  = state;
   btnDopushMinus->Visible = state;
   gridDopush->Visible     = state && gridDopush->Items->Count;
   gridHead->Visible       = state && gridDopush->Items->Count;
   chkFrInsteadK1->Caption = (state && enable_k1f) ? "��������� ����������� �������� " + IntToStr(FRANSHIZA) + "% �� ��������� ����� ������ ����������� �1" : empty_str;
   chkFrInsteadK1->Visible = (state && enable_k1f) ? true : false;

   int top_btn = CalcInfo->Height + labNonStandardDogovor_Up->Height - 23;
   btnDopushPlus->Top  = top_btn;
   btnDopushEdit->Top  = top_btn;
   btnDopushMinus->Top = top_btn;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::TermsHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone)
{
   SetHeightInspector_1(TermsInfo);
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeControlOnAnotherFrame(TObject *Sender)
{
   if(this_frame
/* //#include "newcalc.h"
   && f_calc->Enabled
*/
   )
   {
      TdxInspectorRow *r_this_frame = dynamic_cast<TdxInspectorRow*>(Sender);
/* //#include "newcalc.h"
      TdxInspectorRow *r = dynamic_cast<TdxInspectorRow*>(f_calc->FindComponent(r_this_frame->Name));
      if(r->EditText != r_this_frame->EditText){
         r->EditText = r_this_frame->EditText;
         f_calc->ControlChange(r);
      }
*/      
   }
}
AnsiString __fastcall TFramePreCalc::GetTSCountryFlag(AnsiString ts_marka, AnsiString ts_model)
{        int res;
         TADOQuery *q_mm = m_api->dbGetCursor(res, "select rf_dev_type_fk from gl_dict_carrier_models where brand_name=" + QuotedStr(ts_marka) +" and model_name="+QuotedStr(ts_model) );
         AnsiString ts_russia = q_mm->FieldByName("rf_dev_type_fk")->Value;
         m_api->dbCloseCursor(res, q_mm);
        return ts_russia;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::ControlChange(TObject *Sender)
{
   if(in_event) return; in_event = true;
   UINT curr_control = UINT(Sender);
   //int index1 = cboxTypeFranshiza->Items->IndexOf(cboxTypeFranshiza->EditText);

   // -------------------------------------------------------
   if(curr_control == UINT(cboxSource)){
      ChangeSource();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxBank)){
      ChangeBank();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxFullInsur)) ChangeControlOnAnotherFrame(Sender);
   else if(curr_control == UINT(cboxRegion)/* || curr_control == UINT(vgEditorRow1)*/){
      LoadRegionData();
      ChangeMultiDrive();
      k1 = K1Final(true);
      Calc_kar();
      CalcAll();
      GetRangeAge();
      ResetAllSumms();
      if(is_trans && cboxRegion->Items->IndexOf(cboxRegion->EditText) > -1 && cboxTSModel->Items->IndexOf(cboxTSModel->EditText) > -1 && tdr.GetPriceDelta(1)){
         RecalcCostTdr();
         if(di->calc_info.cost_vehicle == 0 || !editTSRealCost->Node->Expanded) editTSRealCost->Node->Expand(true);
      }
      else ResetTransdekra();

      ChangeListProject(ProductID());
      ChangeListFullInsur();
      ChangeListCredits();
      ChangeList_K5_K6();
      ChangeFranshizeBox();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxTSType)){
      tsi->tstype_id = (int)cboxTSType->Items->Objects[cboxTSType->Items->IndexOf(cboxTSType->EditText)];
      editMaxMassa->EditText = null_str;
      editSeatCount->EditText = null_str;
      tsi->ts_age = tsi->max_massa = tsi->seat_count = 0;
      ResetAllSumms();
      if(is_trans) ResetTransdekra();
      if(tsi->tstype_id == 3 || tsi->tstype_id == 4) cboxTSType->Node->Expand(true);
      else cboxTSType->Node->Collapse(true);
      if(tsi->IsSpectech()) group_ts = 11;
      else if(tsi->IsPricep()) group_ts = 10;
      SetStatePermitted();
      if(group_ts > 9){
        Calc_bt();
        Protivougon();
        ChangeFranshizeBox();
        if(contract_type) ChangeList_K5_K6();
      }
      GetApplyingKoeffs();
      LoadTSMarkaList();
      tsi->key_count = tsi->tstype_id < 8 ? 2 : 0;
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxTSMarka)){
      LoadTSModelList();
      tsi->ts_age = 0;
      tsi->ts_marka = cboxTSMarka->EditText;
      tsi->ts_model = empty_str;
      ResetAllSumms();
      if(is_trans) ResetTransdekra();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxTSModel) && cboxTSModel->Items->IndexOf(cboxTSModel->EditText) > -1){
      last_err = empty_str;
      model_id = int(cboxTSModel->Items->Objects[cboxTSModel->Items->IndexOf(cboxTSModel->EditText)]);
      GetGroupTS();
      GetApplyingKoeffs();
      CalcAll(true, false, true);
      Calc_kar();
      GetRangeAge();
      if(is_trans){
         if(tdr.SetRSA_ID(AnsiString(model_id))){}
         editTSYear->EditText = empty_str;
         tdr.SetYear(empty_str);
         ResetTransdekra();
      }
      ResetAllSumms();
      tsi->ts_age = 0;
      tsi->ts_model = cboxTSModel->EditText;

      ChangeControlOnAnotherFrame(cboxTSModel);
   }
   else if(curr_control == UINT(editSeatCount) || curr_control == UINT(editMaxMassa)){
      GetGroupTS();
      GetApplyingKoeffs();
      CalcAll(true, false, true);
      GetRangeAge();
      if(curr_control == UINT(editSeatCount)) ChangeControlOnAnotherFrame(editSeatCount);
      else ChangeControlOnAnotherFrame(editMaxMassa);
   }
   else if(curr_control == UINT(rgMainRisk)){
      risk = 2 - rgMainRisk->Items->IndexOf(rgMainRisk->EditText);
      GetApplyingKoeffs();
      CalcAll(true, false, true);
      GetRangeAge();
      GetRiskCode(0, risk, ProductID());
      ChangeControlOnAnotherFrame(rgMainRisk);
   }
   else if(curr_control == UINT(rgStatus) || curr_control == UINT(cboxVariant)){
      LoadVozmTypeList();
      CalcAll(false, false, false);
      GetApplyingKoeffs();
      GetRangeAge();
      if(curr_control == UINT(rgStatus)){
         pi[0].status = rgStatus->Items->IndexOf(rgStatus->EditText);
         SetStatePermitted();
         Calc_kar();
      }
      else ChangeListFullInsur();
      int pid = ProductID();
      GetRiskCode(-1, risk, pid);
      ChangeListProject(pid);
      ChangeListCredits();
      curr_limit = m_api->dbGetFloatFromQuery(res, sql.sprintf("select filial_sum_limit from gl_dict_limit_branches where branch_code='' and product_id=%i and casco_territory_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", ProductID(), region_id, di->calc_date, di->calc_date));
      ChangeFranshizeBox();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxSrok)){
      cboxSrokChange();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(editTSYear)){
      int year = editTSYear->EditText.SubString(1, 4).ToIntDef(curr_year), is_new_ts(0);
      if(editTSYear->EditText == (IntToStr(curr_year - 1) + " �., ����� �� c �������� ����� 1000 ��")){
         editTSYear->Node->Expand(true);
         if(date_pts.Val){
            is_new_ts = (YearOf(date_pts) > curr_year - 2) && (date_pts > TDateTime(curr_year - 1, 7, 31));
            if(!is_new_ts) editTSYear->EditText = editTSYear->Items->Strings[2];
         }
      }
      else editTSYear->Node->Collapse(true);
      tsi->ts_age = is_new_ts ? 0 : curr_year - year;
      CalcAll();
      Calc_kar();
      ResetAllSumms();
      GetRangeAge();
      IsPorsche27RF();
      tdr.SetYear(IntToStr(year));
      if(is_trans && cboxRegion->Items->IndexOf(cboxRegion->EditText) > -1 && cboxTSModel->Items->IndexOf(cboxTSModel->EditText) > -1 && tdr.GetPriceDelta(1)){
         ResetTdrValues();
         RecalcCostTdr();
         if(di->calc_info.cost_vehicle == 0 || !editTSRealCost->Node->Expanded) editTSRealCost->Node->Expand(true);
      }
      else ResetTransdekra();
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(datePTS)){
      if(date_pts.Val){
         int year = editTSYear->EditText.SubString(1, 4).ToIntDef(curr_year);
         tsi->ts_age = (YearOf(date_pts) > curr_year - 2) && (date_pts > TDateTime(curr_year - 1, 7, 31)) ? 0 : (curr_year - year);
         if(editTSYear->EditText == (IntToStr(curr_year - 1) + " �., ����� �� c �������� ����� 1000 ��") && tsi->ts_age == 1){
            editTSYear->EditText = editTSYear->Items->Strings[2];
            datePTS->EditText = date_pts;
         }
         if(tsi->tstype_id == 1) tsi->pts_date = date_pts.DateString();
         CalcAll(false, true, false);
         Calc_kar();
      }
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxVozmType)){
      Calc_k7();
      ChangeControlOnAnotherFrame(cboxVozmType);
   }
   else if(curr_control == UINT(cboxDogovorType)){
      contract_type = cboxDogovorType->Items->IndexOf(cboxDogovorType->EditText);
      ChangeList_K5_K6();
      Calc_kar();
   }
   else if(curr_control == UINT(cboxTypeFranshiza)){
      if(!cboxTypeFranshiza->EditText.Pos("�����������")){
         cboxFranshiza->EditText = empty_str;
         cboxTypeFranshiza->Node->Collapse(true);
      }
      else cboxTypeFranshiza->Node->Expand(true);
      ChangeFranshizeBox(cboxTypeFranshiza);
      ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxFranshiza)) ChangeControlOnAnotherFrame(Sender);
   else if(curr_control == UINT(chkFrInsteadK1)){
      if(chkFrInsteadK1->Checked){
         cboxTypeFranshiza->EditText = "����������� � %";
         ChangeFranshizeBox(cboxTypeFranshiza);
         cboxFranshiza->EditText = IntToStr(FRANSHIZA);
      }
      else k1 = K1Final();
      //ChangeControlOnAnotherFrame(Sender);
   }
   else if(curr_control == UINT(cboxCredit)) ChangeOrderPayments();
   else if(curr_control == UINT(cbox_K5_K6)){
      if(contract_type) Calc_kar();
   }
   else if(curr_control == UINT(cboxMultidrive)){
      type_multydrive = ((DataDict*)cboxMultidrive->Items->Objects[cboxMultidrive->Items->IndexOf(cboxMultidrive->EditText)])->id;
      ResetGridPermitted();
      SetFrInsteadK1(0);
      Calc_kar();
   }
   else if(curr_control == UINT(cboxTSCount)) ChangeControlOnAnotherFrame(Sender);
   else if(curr_control == UINT(cboxProgramms)){
      int ind_prg = cboxProgramms->Items->IndexOf(cboxProgramms->EditText);
      DataDict* data = (DataDict*)cboxProgramms->Items->Objects[ind_prg];
      programm_id = data->id;
      if(data->coeff_max > data->coeff_min) SetRowKpr(data->coeff_min, data->coeff_max);
      else{
         if(cboxProgramms->Node->HasChildren) cboxProgramms->Node->Items[0]->Free();
      }
      ChangeFranshizeBox();
      ChangeControlOnAnotherFrame(Sender);
   }

   cboxFranshiza->ReadOnly = chkFrInsteadK1->Checked || !cboxTypeFranshiza->EditText.Pos("�����������");

   if(!contract_type && (tsi->IsSpectech() || pi[0].status)){
      cbox_K5_K6->ReadOnly = true;
      cbox_K5_K6->EditText = empty_str;
   }
   else cbox_K5_K6->ReadOnly = false;

   if(!di->type_money) editStrSumma->ReadOnly = cboxVariant->Items->IndexOf(cboxVariant->EditText) == 0;
   else                editStrSumma->ReadOnly = cboxFullInsur->Items->IndexOf(cboxFullInsur->EditText) == 0;

   Calc(Sender);
   in_event = false;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::btnDopushPlusClick(TObject *Sender)
{
   int count_permit = gridDopush->Items->Count;
   TDopUprForm *form = new TDopUprForm(this);
   if(form->ShowModal() == mrOk){
      TDateTime dt_age = form->dateAge->Date, dt_stag = form->dateStag->Date;

      TListItem *new_item = gridDopush->Items->Add();
      new_item->Caption = count_permit + 1;
      new_item->SubItems->Add((int)form->editAge->Value);
      new_item->SubItems->Add(dt_age.Val ? dt_age.DateString() : empty_str);
      new_item->SubItems->Add((int)form->editStag->Value);
      new_item->SubItems->Add(dt_stag.Val ? dt_stag.DateString() : empty_str);
      new_item->SubItems->Add(K1(di->REGION_TYPE, form->editAge->Value, form->editStag->Value));
      if(!gridDopush->Visible) ShowGridOrChkPermitted(0);
      gridDopush->Height = 23 + (gridDopush->Items->Count - 1) * 17;
      gridHead->Visible  = true;
      k1 = K1Final(true);
      SetFrInsteadK1(k1);
      if(di->dogovor_type > 3 && ((DataDict*)cboxProgramms->Items->Objects[cboxProgramms->Items->IndexOf(cboxProgramms->EditText)])->id == 1027) cboxProgramms->EditText = "��������� �� ����������";
      ControlChange(btnDopushPlus);
   }
   delete form;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::btnDopushMinusClick(TObject *Sender)
{
   TListItem *delete_item = gridDopush->Selected;
   if(!delete_item) return;
   int delete_index = delete_item->Index;

   gridDopush->Items->Delete(delete_index);
   int cnt = gridDopush->Items->Count;
   for(int i = 0; i < cnt; ++i) gridDopush->Items->Item[i]->Caption = i + 1;
   if(!cnt){
      gridDopush->Visible = false;
      gridHead->Visible   = false;
   }
   else gridDopush->Height = 23 + (gridDopush->Items->Count - 1) * 17;

   k1 = K1Final(true);
   SetFrInsteadK1(k1);
   ControlChange(btnDopushMinus);
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::btnDopushEditClick(TObject *Sender)
{
   TListItem *edit_item = gridDopush->Selected;
   if(!edit_item || !gridDopush->Enabled) return;

   TDopUprForm *form = new TDopUprForm(this);
   form->editAge->Value        = edit_item->SubItems->Strings[0].ToInt();
   form->editStag->Value       = edit_item->SubItems->Strings[2].ToInt();
   form->dateAge->Text         = edit_item->SubItems->Strings[1];
   form->dateStag->Text        = edit_item->SubItems->Strings[3];
   if(form->ShowModal() == mrOk){
      TDateTime dt_age = form->dateAge->Date, dt_stag = form->dateStag->Date;

      edit_item->SubItems->Strings[0] = (int)form->editAge->Value;
      edit_item->SubItems->Strings[1] = dt_age.Val ? dt_age.DateString() : empty_str;
      edit_item->SubItems->Strings[2] = (int)form->editStag->Value;
      edit_item->SubItems->Strings[3] = dt_stag.Val ? dt_stag.DateString() : empty_str;
      edit_item->SubItems->Strings[4] = K1(di->REGION_TYPE, form->editAge->Value, form->editStag->Value);
      k1 = K1Final(true);
      SetFrInsteadK1(k1);
      ControlChange(btnDopushEdit);
      Repaint();
   }
   delete form;
}
//---------------------------------------------------------------------------
void TFramePreCalc::Calc(TObject* Sender)
{
   if(m_api) m_api->Err_Set_False_All_Errors_Warnings(res, this);

   AnsiString marka_id = MarkaId(model_id), err("");
   TDateTime p_dt(di->calc_date), dt;
   labPremiaMain->Caption = "�����: 0.0%, ������ : 0.0";
   osn_risk_itog_tarif = premiya_all = premiya_osn_risk = 0;
   int error_num(0), index = cboxProgramms->EditText.IsEmpty() ? 0 : cboxProgramms->Items->IndexOf(cboxProgramms->EditText);
   non_standart_str->Clear(); //������� ������ ������������� �������
   bool term(true), is_non_sp = IsNonStandartPolis() || is_bl;

   if(status_dogovor < 3) status_dogovor = is_non_sp ? 2 : 1;

   DataDict *data_prg = (DataDict*)cboxProgramms->Items->Objects[index];

   // ADDED RUBIK
   AnsiString sTS_MARKA = cboxTSMarka->EditText;
   AnsiString sTS_MODEL = cboxTSModel->EditText;
   AnsiString sMSG=sTS_MARKA+"-"+sTS_MODEL;
   AnsiString sTS_RUSSIA = "";
   //Application->MessageBox(sMSG.c_str(),"INFO2", MB_OK);
   if (( sTS_MARKA != "") &&  (sTS_MODEL != ""))
      {  sTS_RUSSIA=GetTSCountryFlag(sTS_MARKA, sTS_MODEL);
         // Application->MessageBox(sTS_RUSSIA.c_str(),"COUNTRY", MB_OK);   // CHANGED RUBIK
        }

   Error("����� ������������ ������ � ������� 14 ����.", error_num, DaysBetween(p_dt, Date()) > 14);
   Error("�� ������ ������ ���������� ��������", ++error_num, cboxRegion->EditText.IsEmpty());
   Error("�� ������ ����", ++error_num, cboxSource->Items->IndexOf(cboxSource->EditText) && cboxBank->EditText.IsEmpty());
   Error("�� ������ ��� ��", ++error_num, cboxTSType->Items->IndexOf(cboxTSType->EditText) < 0);
   Error("������� ������� ����������� ������������ �����", ++error_num, tsi->tstype_id == 3 && (tsi->max_massa <= 0 || tsi->max_massa > 100000));
   Error("������� ������� ����� ���� ������������� ��������", ++error_num, tsi->tstype_id == 4 && (tsi->seat_count <= 0 || tsi->seat_count > 200));
   term = cboxTSMarka->Items->IndexOf(cboxTSMarka->EditText) < 0;
   if(term) memoProtivougonki->EditText = empty_str;
   Error("�� ������� ����� ��", ++error_num, term);
   term = cboxTSModel->Items->IndexOf(cboxTSModel->EditText) < 0;
   if(term) memoProtivougonki->EditText = empty_str;
   Error("�� ������� ������ ��", ++error_num, term);
   Error("������� ������ ��� ������� ��", ++error_num, editTSYear->EditText.IsEmpty());
   Error("������� ������� ���� ������ ���", ++error_num, editTSYear->EditText == IntToStr(curr_year - 1) + " �., ����� �� c �������� ����� 1000 ��" && !date_pts.Val);
   Error("���������� ���������� ������ ��" + last_err, ++error_num, group_ts == -1);
   int index_fu = cboxFullInsur->Items->IndexOf(cboxFullInsur->EditText);

   Error("������� ������� �������������� ��������� ��", ++error_num, di->calc_info.cost_vehicle <= 0);
   Error("������� ������� ��������� ����� �� ��������� �����", ++error_num, di->calc_info.str_summa <= 0);
   di->calc_info.coef_prop = Round((di->calc_info.cost_vehicle && di->calc_info.str_summa) ? di->calc_info.str_summa / di->calc_info.cost_vehicle : 1.00);
   labCoefProp->EditText = (!editStrSumma->ReadOnly && (int)cboxFullInsur->Items->Objects[index_fu] != 3) ? FloatToStr(di->calc_info.coef_prop) : one_str;

   Error("����������� ������������������ ������ ���������� � �������� �� 0,5 �� 1", ++error_num, (di->calc_info.coef_prop > 1) || (di->calc_info.coef_prop < 0.5));
   Error("��� ��������� �� ��� �������� ����������� �� ������� ����� ����������� ������������������ ������ ���� ������ 0.8", ++error_num, (int)cboxFullInsur->Items->Objects[index_fu] == 3 && di->calc_info.coef_prop >= 0.8);
   
   int variant = cboxVariant->Items->IndexOf(cboxVariant->EditText);
   Error(err.sprintf("������ ������� ������� \"�\", �.�. ���������� ������ ��� ������������ �� ������ %i ���", ts_age_max), ++error_num, !variant && (tsi->ts_age > ts_age_max));
   Error(err.sprintf("������ ������� ������� \"�\", �.�. ���������� ������ ��� ������������ �� �� ����� � ��������� �� %i �� %i ���", ts_age_min, ts_age_max), ++error_num, (variant == 1) && (tsi->ts_age < ts_age_min) || (tsi->ts_age > ts_age_max));
   Error("������ ������� ������� \"�\" ��� ���������� ��������� � ������ � ������� ��� �� ��������� �� 7 ���", ++error_num, (variant == 1) && (region_id == 77) && (di->bank_id > 0) && (tsi->ts_age < 8));
   Error(err.sprintf("������ ������� ������� \"�\", �.�. ���������� ������ ��� ������������ �� �� ����� � ��������� �� %i �� %i ���", ts_age_min, ts_age_max), ++error_num, (variant == 2) && (tsi->ts_age < ts_age_min) || (tsi->ts_age > ts_age_max));

   Error("���������� ���������� ���������� �� �������������� ��������", ++error_num, risk == 2 && memoProtivougonki->Text.IsEmpty());
   Error("���������� ���������� ������� ����� �� �������� ����������", ++error_num, nf_bt);

   Error("�� ������� ���������� � ����������", ++error_num, type_multydrive == 100 && !gridDopush->Items->Count);

   // K1
   int index_md = cboxMultidrive->Items->IndexOf(cboxMultidrive->EditText);
   if(index_md > -1 && index_md != cboxMultidrive->Items->Count - 1) k1 = ((DataDict*)cboxMultidrive->Items->Objects[index_md])->coeff_value;

   //K� - �����-� �� ���������� ����������
   kd = gridDopush->Items->Count > 0 ? coeff_kd[gridDopush->Items->Count - 1] : 1;

   Error("������� �� ����� ��������� ��������������, ���� ���� ����������� ���������� ����� 6 �������", ++error_num, contract_type && di->monthcount < 6);
   Error("������� �� ����� ��������� ��������������, ���� ��� ������� �� - " + editTSYear->EditText, ++error_num, contract_type && tsi->ts_age == 0);
   Error("�� ������� ���������� ������� �� ����������� ��������", ++error_num, contract_type && cbox_K5_K6->EditText.IsEmpty());
   Error("�� ������ ��������� ����������� �� �����", ++error_num, !contract_type && !tsi->IsSpectech() && !pi[0].status && cbox_K5_K6->EditText.IsEmpty());

   //�2
   int ind_tscount = cboxTSCount->Items->IndexOf(cboxTSCount->EditText);
   di->calc_info.k2 = ind_tscount > -1 ? ((DataDict*)cboxTSCount->Items->Objects[ind_tscount])->coeff_value : 1;

   //Ka
   di->calc_info.ka = 1.0;

   double k_psabank(1), k_rusfinans(1);
   if(di->bank_id == 36 && tsi->ts_age > 1) k_psabank = 1.25;
   if(di->bank_id == 43 && marka_id == porsche && tsi->ts_age > 1) k_rusfinans = 1.3;
   di->calc_info.ka *= k_psabank;
   di->calc_info.ka *= k_rusfinans;

   term = ((int)cboxFullInsur->Items->Objects[index_fu] == 3 && di->calc_info.coef_prop <= 0.79);
   if(term){
      di->calc_info.kfr = GetKprSb(di->calc_info.coef_prop);
      cboxVozmType->EditText = empty_str;
   }
   else di->calc_info.kfr = 1.0;
   cboxVozmType->ReadOnly = term;
   Error("�� ������ ������ ���������� ������", ++error_num, !cboxVozmType->ReadOnly && cboxVozmType->EditText.IsEmpty());

   // ��
   switch(pi[0].status){
      case 0: case 1: di->calc_info.kyu = 1.0; break;
      case 2: di->calc_info.kyu = 1.1; break;
   }
   // K5
   k5 = (contract_type && !cbox_K5_K6->EditText.IsEmpty()) ? double((int)cbox_K5_K6->Items->Objects[cbox_K5_K6->Items->IndexOf(cbox_K5_K6->EditText)]) / 1000 : 1;

   //K4
   int ind_type_fr = cboxTypeFranshiza->Items->IndexOf(cboxTypeFranshiza->EditText);
   int type_fr = ((DataDict*)cboxTypeFranshiza->Items->Objects[ind_type_fr])->id, index_fr = cboxFranshiza->Items->IndexOf(cboxFranshiza->EditText);
   Error("�� ������� �������� ����������� ��������", ++error_num, type_fr == 3 && index_fr == -1);
   di->calc_info.k4 = 1;
   switch(type_fr){
      case 3: if(index_fr > -1) di->calc_info.k4 = double((int)cboxFranshiza->Items->Objects[index_fr]) / 1000; break;
      case 6: di->calc_info.k4 = !pi[0].status ? ((DataDict*)cboxTypeFranshiza->Items->Objects[ind_type_fr])->coeff_value : 1;
   }

   if(chkFrInsteadK1->Checked) k1 = di->calc_info.k4 = 1; // ������� �� � ��������� ���� ���

   // K6
   if(data_prg->id != 1286 && tsi->ts_age && !contract_type && !cbox_K5_K6->ReadOnly && !cbox_K5_K6->EditText.IsEmpty()) k6 = ((DataDict*)cbox_K5_K6->Items->Objects[cbox_K5_K6->Items->IndexOf(cbox_K5_K6->EditText)])->coeff_value;
   else k6 = 1;
   //���
   int ind_crd = cboxCredit->Items->IndexOf(cboxCredit->EditText);
   if(ind_crd > -1) di->calc_info.krs = ((DataDict*)cboxCredit->Items->Objects[ind_crd])->coeff_value;
   //Kb
   Calc_Kb();
   //Kpr
   if(cboxProgramms->Node->HasChildren) di->calc_info.kpr = StrToFloatStr(TermsInfo->RowByName(row_kpr_name)->EditText).ToDouble();
   else{
      if(data_prg->id == 1286 && di->calc_info.kpr_dtp.count(group_ts)) di->calc_info.kpr = di->calc_info.kpr_dtp[tsi->group_ts];
      else di->calc_info.kpr = data_prg->coeff_value;
   }
   Error("�� ������ ��� �� ��������� \"" + cboxProgramms->EditText + "\"", ++error_num, cboxProgramms->Node->HasChildren && di->calc_info.kpr == 0.0);

   //������ 2012
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "�������� ������ ������ �����������", ++error_num, data_prg->id == 1045 && index_fu);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� �������� ��� �� ������ ��1-��3, ��1, ��2", ++error_num, data_prg->id == 1045 && !IsCar());
   //Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "������� �� 0 ���", ++error_num, data_prg->id == 1045 && tsi->ts_age == 0);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "������ �����������", ++error_num, data_prg->id == 1045 && type_multydrive != 100);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "����� ���������� ����� 3-�", ++error_num, data_prg->id == 1045 && gridDopush->Items->Count > 3);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� ������ ���������� ������ ������ ������ �� ���� �����������", ++error_num, data_prg->id == 1045 && cboxVozmType->EditText != "������ �� ���� �����������");
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "���� ����������� ������ ����", ++error_num, data_prg->id == 1045 && di->monthcount < 12);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� ������� �� �������������", ++error_num, data_prg->id == 1045 && ind_crd > 0);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "���������� ����� �������� �� �������������", ++error_num, data_prg->id == 1045 && ind_type_fr > 0);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "�� ����� ������ �� ���� �����-�� ������������", ++error_num, data_prg->id == 1045 && di->calc_info.ka < 1);

// #define TESTIT 1
      #ifdef TESTIT
   Application->MessageBox(sTS_RUSSIA.c_str(),"COUNTRY", MB_OK);   // CHANGED RUBIK
   AnsiString sErr=((data_prg->id == 1045) && (((sTS_RUSSIA!="") && (sTS_RUSSIA=="1"))?((tsi->ts_age<1) || (tsi->ts_age>5)):((tsi->ts_age<1) || (tsi->ts_age>7))))?("TRUE"):("FALSE");
   AnsiString sM="OLD-"+sTS_RUSSIA+":"+AnsiString(  data_prg->id )+"'"+AnsiString(tsi->ts_age)+" = "+ sErr;
   Application->MessageBox(sM.c_str(),"DATA", MB_OK);
      #endif
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "������ ��������� ������� � ��������� ��������� ��", ++error_num,
                                                                 (data_prg->id == 1045) && (sTS_RUSSIA!="") && ((sTS_RUSSIA=="1")?((tsi->ts_age<1) || (tsi->ts_age>5)):((tsi->ts_age<1) || (tsi->ts_age>7))));

   //������� �� ������
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "�������� ������ ������ �����������", ++error_num, prg_comfort.count(data_prg->id) && index_fu);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� �������� ��� �� ������ ��1-��3", ++error_num, prg_comfort.count(data_prg->id) && group_ts > 3);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "������� �� ����� 7-�� ���", ++error_num, prg_comfort.count(data_prg->id) && tsi->ts_age > 7);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "���� ����������� ������ ����", ++error_num, prg_comfort.count(data_prg->id) && di->monthcount < 12);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� ������� �� �������������", ++error_num, prg_comfort.count(data_prg->id) && ind_crd > 0);

   // ��� � ����������� �� �������� ��
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��� ������� �� - " + editTSYear->EditText, ++error_num, (data_prg->id == 1268 || data_prg->id == 1269) && tsi->ts_age == 0);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� �������� ������ ��� ������������� ����������� ���������", ++error_num, (data_prg->id == 1268 || data_prg->id == 1269) && contract_type);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��� ������� �� - " + editTSYear->EditText, ++error_num, data_prg->id == 1268 && tsi->ts_age > 1);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��� ������� �� - " + editTSYear->EditText, ++error_num, data_prg->id == 1269 && tsi->ts_age == 1);

   // ����� � ���
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "�� ����������� �� ���� ������� ������� ����� " + cboxBank->EditText, ++error_num, data_prg->id == 1286 && di->bank_id > 0);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "�������� ������ ������ �����������", ++error_num, data_prg->id == 1286 && index_fu);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� �������� ������ ��� �� ����� ��1, ��2, ��1, ��2", ++error_num, data_prg->id== 1286 && (group_ts != 1 && group_ts != 2 && group_ts != 6 && group_ts != 7));
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� �������� ������ ��� ����� \"�����\"", ++error_num, data_prg->id == 1286 && di->risk == 2);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "��������� ������ ���������� ������ ������ ������ �� ���� �����������", ++error_num, data_prg->id == 1286 && cboxVozmType->EditText != "������ �� ���� �����������");
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "���� ����������� ������ ����", ++error_num, data_prg->id == 1286 && di->monthcount < 12);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "���������� ������������ �������� �� �������������", ++error_num, data_prg->id == 1286 && ind_type_fr == 2);
   Error(err.sprintf(programm_error_text.c_str(), cboxProgramms->EditText.c_str()) + "�� ����� ������ �� ���� �����-�� ������������", ++error_num, data_prg->id == 1286 && di->calc_info.ka < 1);

   error->Text = m_api->Err_Get_Calc_Errors_By_Type_RT(res, err_calc, this);
   int is_error = error->Count;

   if(is_error) curr_error = m_api->Err_Get_Shown_Error_Text(res, this);
   else{
      curr_error = empty_str;
      CalcPremium();
   }
   InvalidateAll();
}
//---------------------------------------------------------------------------
double TFramePreCalc::K1(const int tertype_id, const int age, const int stag)
{
   if(age == 0 && stag == 0)
      q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK01 where tertype_id=%i and drvexp_min=0 and drvexp_max=0 and age_min=0 and age_max=0 and CDate('%s')>=start_date and CDate('%s')<=end_date", tertype_id, di->calc_date, di->calc_date));
   else
      q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK01 where tertype_id=%i and drvexp_min<=%i and drvexp_max>%i and age_min<=%i and age_max>%i and CDate('%s')>=start_date and CDate('%s')<=end_date",
                             tertype_id, stag, stag, age, age, di->calc_date, di->calc_date));
   double k1_res = q->IsEmpty() ? 1 : q->FieldByName("coeff_val")->AsFloat;
   m_api->dbCloseCursor(res, q);

   return k1_res;
}
//---------------------------------------------------------------------------
double TFramePreCalc::K1Final(bool recalc)
{
   double k1t, k1_curr(0);
   int curr_age, curr_drvexp;

   age_min = drv_exp_min = 0;
   for(int i = 0, n = gridDopush->Items->Count; i < n; i++) {
      curr_age    = gridDopush->Items->Item[i]->SubItems->Strings[0].ToIntDef(0);
      curr_drvexp = gridDopush->Items->Item[i]->SubItems->Strings[2].ToIntDef(0);
      if(recalc) gridDopush->Items->Item[i]->SubItems->Strings[4] = K1(di->REGION_TYPE, curr_age, curr_drvexp);
      k1t = StrToFloatStr(gridDopush->Items->Item[i]->SubItems->Strings[4]).ToDouble();
      if(k1_curr < k1t){
         k1_curr = k1t;
         age_min     = curr_age;
         drv_exp_min = curr_drvexp;
      }
   }
   if(recalc) Calc_kar();
   return k1_curr == 0 ? 1 : k1_curr;
}
//---------------------------------------------------------------------------
void TFramePreCalc::Error(const AnsiString& text, const int unique, bool term, int warning, const AnsiString& type_error)
{
    if(m_api) m_api->Raise_Error_Warning(res, this, 0, text, text, warning, type_error, unique, term);
}
//---------------------------------------------------------------------------
void TFramePreCalc::SaveFrame(TADOQuery *q_save)
{
   if(di->status_dogovor == 11) return;

   m_api->vrSetVariable(res, "KASKO_Territory", region_id);

   TDateTime dt;
   int curr_ind, osago_idx(0), prev_ub(-1);

   curr_ind = cbox_K5_K6->Items->IndexOf(cbox_K5_K6->EditText);
   switch(contract_type){
      case 0: osago_idx = curr_ind > -1 ? ((DataDict*)cbox_K5_K6->Items->Objects[curr_ind])->id : 0; break;
      case 1: prev_ub = curr_ind; break;
   }
   q_save->FieldByName("prolong_pc")->Value = contract_type ? true : false; 
   q_save->FieldByName("multidrive_pc")->Value      = type_multydrive;
   q_save->FieldByName("fr_instead_k1_pc")->Value   = chkFrInsteadK1->Checked;
   q_save->FieldByName("prev_ubitki_idx_pc")->Value = prev_ub;
   q_save->FieldByName("osago_idx")->Value          = osago_idx;

   m_api->dbExecuteQuery(res, "delete * from casco_permitted where calc_id=" + q_save->FieldByName("calc_id")->AsString);
   TADOQuery *q_perm = m_api->dbGetCursor(res, "select * from casco_permitted where calc_id=" + q_save->FieldByName("calc_id")->AsString, 0, 1);
   for(int i = 0, drv_count = gridDopush->Items->Count; i < drv_count; ++i){
      TListItem *item = gridDopush->Items->Item[i];
      q_perm->Insert();
      q_perm->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->AsInteger;
      q_perm->FieldByName("permitted_number")->Value = item->Caption.ToIntDef(0);
      q_perm->FieldByName("age")->Value = item->SubItems->Strings[0].ToIntDef(0);
      q_perm->FieldByName("phisical_birth_date")->Value = TryStrToDateTime(item->SubItems->Strings[1], dt) ? dt : TDateTime(curr_year - q_perm->FieldByName("age")->AsInteger, 1, 1);
      q_perm->FieldByName("experience")->Value = item->SubItems->Strings[2].ToIntDef(0);;
      q_perm->FieldByName("document_issue_date")->Value = TryStrToDateTime(item->SubItems->Strings[3], dt) ? dt : TDateTime(curr_year - q_perm->FieldByName("experience")->AsInteger, 1, 1);;
      q_perm->FieldByName("osago_ss")->Value = 0;
   }
   q_perm->UpdateBatch();
   m_api->dbCloseCursor(res, q_perm);
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadFrame(TADOQuery *q)
{
   in_event = true;

   if(q->FieldByName("prolong_pc")->AsBoolean) contract_type = 1;

   TDateTime dt = q->FieldByName("quotation_date")->AsDateTime;

   if(dt.Val){
      if(di->dogovor_type < 3){
         tdr.SetDateR(dt);
         di->calc_date = dt.DateString();
      }
   }

   cboxSource->EditText = cboxSource->Items->Strings[q->FieldByName("source_id")->AsInteger];
   if(q->FieldByName("source_id")->AsInteger) ChangeSource();

   risk = q->FieldByName("risk_id")->AsInteger;
   rgMainRisk->EditText = rgMainRisk->Items->Strings[2 - risk];
   risk_code[0] = q->FieldByName("risk_main")->AsString;
   //risk_code[1] = q->FieldByName("risk_ns")->AsString;
   risk_code[2] = q->FieldByName("risk_dsago")->AsString;
   code_prod = q->FieldByName("code_prod")->AsInteger;
   name_prod = q->FieldByName("name_prod")->AsString;

   rgStatus->EditText = rgStatus->Items->Strings[pi[0].status = q->FieldByName("status_idx")->AsInteger];
   int variant = q->FieldByName("variant_idx")->AsInteger;
   if(variant + 1 > cboxVariant->Items->Count) variant = 0;
   cboxVariant->EditText = cboxVariant->Items->Strings[variant];

   LoadRegions();
   region_id = q->FieldByName("region_id")->AsInteger;
   if(!region_id) TryStrToInt(m_api->vrGetVariable(res, "KASKO_Territory").Trim(), region_id);
   cboxRegion->EditText = cboxRegion->Items->Strings[GetIndexObject(cboxRegion->Items, region_id)];
   LoadRegionData();
   LoadData();
   region_isp_id = q->FieldByName("region_isp_id")->AsInteger;

   di->bank_id = q->FieldByName("bank_id")->AsInteger;
   int index_b = cboxBank->Items->IndexOfObject((TObject*)di->bank_id);
   if(index_b > -1){
      cboxBank->EditText = cboxBank->Items->Strings[index_b];
      MemoBank->EditText = StringReplace(q->FieldByName("requirements")->AsString, ";", "\r\n", rf);
   }

   tsi->tstype_id = q->FieldByName("tstype_id")->AsInteger;
   int index_tstype = cboxTSType->Items->IndexOfObject((TObject*)tsi->tstype_id);
   if(index_tstype == -1){
      tsi->tstype_id = 2;
      index_tstype = cboxTSType->Items->IndexOfObject((TObject*)tsi->tstype_id);
   }
   if(tsi->tstype_id == 3 || tsi->tstype_id == 4) cboxTSType->Node->Expand(true);
   cboxTSType->EditText = cboxTSType->Items->Strings[index_tstype];
   LoadTSMarkaList();
   cboxTSMarka->EditText = q->FieldByName("ts_marka_calc")->AsString.Trim();
   LoadTSModelList();
   model_id = q->FieldByName("ts_model_id")->AsInteger;
   if(model_id){
      int i = cboxTSModel->Items->IndexOfObject((TObject*)model_id);
      if(i > -1) cboxTSModel->EditText = cboxTSModel->Items->Strings[i];
      if(!cboxTSModel->EditText.IsEmpty() && is_trans){
         if(tdr.SetRSA_ID(AnsiString(model_id))){}
      }
   }

   int year = q->FieldByName("ts_year")->AsString.ToIntDef(curr_year);
   date_pts = q->FieldByName("pts_date_calc")->AsDateTime;
   SetValueRowDateEdit(datePTS, date_pts);
   if(q->FieldByName("ts_novoe")->AsBoolean && year == curr_year - 1){
      tsi->ts_age = 0;
      editTSYear->EditText = q->FieldByName("ts_year")->AsString + " �., ����� �� c �������� ����� 1000 ��";
   }
   else{
      tsi->ts_age = curr_year - year;
      if(tsi->ts_age < 13) editTSYear->EditText = q->FieldByName("ts_year")->AsString + ts_age_str[tsi->ts_age];
   }

   if(!editTSYear->EditText.IsEmpty()){
      tdr.SetYear(year);
      if(is_trans && cboxRegion->Items->IndexOf(cboxRegion->EditText) > -1 && cboxTSModel->Items->IndexOf(cboxTSModel->EditText) > -1 && tdr.GetPriceDelta(1)){
         ResetTdrValues();
         SetParams(q->FieldByName("car_params")->AsString);
      }
   }

   editMaxMassa->EditText = tsi->max_massa = q->FieldByName("max_massa")->AsInteger;
   if(tsi->tstype_id == 4) editSeatCount->EditText = tsi->seat_count = q->FieldByName("seat_count")->AsInteger;

   di->monthcount = q->FieldByName("srok_month")->AsInteger;
   cboxSrok->EditText = cboxSrok->Items->Strings[di->monthcount - 6];

   type_multydrive = q->FieldByName("multidrive_pc")->AsInteger;
   if(type_multydrive > -1){
      int index_multy = GetIndexObject(cboxMultidrive->Items, type_multydrive);
      if(index_multy > -1) cboxMultidrive->EditText = cboxMultidrive->Items->Strings[index_multy];
   }
   else{
      cboxMultidrive->ReadOnly = true;
      cboxMultidrive->EditText = q->FieldByName("status_idx")->AsInteger > 0 ? "��� ��,�����,�� ������ ���������� �� ���������" : "";
      DriversHead->Node->Collapse(true);
   }
   TADOQuery *q_perm = m_api->dbGetCursor(res, "select * from casco_permitted where calc_id=" + q->FieldByName("t1.calc_id")->AsString + " order by permitted_number");
   for(q_perm->First(); !q_perm->Eof; q_perm->Next()){
      TListItem *new_item = gridDopush->Items->Add();
      new_item->Caption = q_perm->FieldByName("permitted_number")->AsString;
      new_item->SubItems->Add(q_perm->FieldByName("age")->AsString);
      dt = q_perm->FieldByName("phisical_birth_date")->AsDateTime;
      new_item->SubItems->Add(dt.Val ? dt.DateString() : empty_str);
      new_item->SubItems->Add(q_perm->FieldByName("experience")->AsString);
      dt = q_perm->FieldByName("document_issue_date")->AsDateTime;
      new_item->SubItems->Add(dt.Val ? dt.DateString() : empty_str);
      new_item->SubItems->Add(K1(di->REGION_TYPE, q_perm->FieldByName("age")->AsInteger, q_perm->FieldByName("experience")->AsInteger));
   }
   if(!q_perm->IsEmpty()){
      gridHead->Visible = true;
      ShowGridOrChkPermitted(0);
      gridDopush->Height = 23 + (q_perm->RecordCount - 1) * 17;
   }
   m_api->dbCloseCursor(res, q_perm);
   chkFrInsteadK1->Checked = q->FieldByName("fr_instead_k1_pc")->AsBoolean;

   int i_val = q->FieldByName("full_insur")->AsInteger;
   if(!i_val) i_val = 1;
   cboxFullInsur->EditText = cboxFullInsur->Items->Strings[cboxFullInsur->Items->IndexOfObject((TObject*)i_val)];
   int ind_prg = GetIndexObject(cboxProgramms->Items, programm_id = q->FieldByName("programm_id")->AsInteger);
   if(ind_prg > -1){
      cboxProgramms->EditText = cboxProgramms->Items->Strings[ind_prg];
      DataDict* data = (DataDict*)cboxProgramms->Items->Objects[ind_prg];
      if(data->coeff_max > data->coeff_min) SetRowKpr(data->coeff_min, data->coeff_max, FloatToSQLStr(q->FieldByName("kpr")->AsFloat));
   }

   int vozm_id = cboxVozmType->Items->IndexOfObject((TObject*)q->FieldByName("pay_id")->AsInteger);
   if(vozm_id > -1) cboxVozmType->EditText = cboxVozmType->Items->Strings[vozm_id];

   di->calc_info.old_itog_tarif = q->FieldByName("tariff")->AsFloat;
   cboxDogovorType->EditText = cboxDogovorType->Items->Strings[contract_type];

   i_val = GetIndexObject(cboxCredit->Items, q->FieldByName("krs_idx")->AsInteger);
   if(i_val == -1) i_val = 0; cboxCredit->EditText = cboxCredit->Items->Strings[i_val];
   ChangeOrderPayments();

   i_val = GetIndexObject(cboxTSCount->Items, q->FieldByName("ts_count")->AsInteger);
   if(i_val == -1) i_val = 0; cboxTSCount->EditText = cboxTSCount->Items->Strings[i_val];

   editTSRealCost->EditText = FloatToStr(di->calc_info.cost_vehicle = q->FieldByName("ts_cost")->AsFloat);
   editStrSumma->EditText = FloatToStr(di->calc_info.str_summa = q->FieldByName("str_summa")->AsFloat);
   if(tsi->IsSpectech())    { group_ts = 11; ChangeFranshizeBox(); if(contract_type) ChangeList_K5_K6(); }
   else if(tsi->IsPricep()) { group_ts = 10; ChangeFranshizeBox(); if(contract_type) ChangeList_K5_K6(); }
   else GetGroupTS();

   int index_type_fr = GetIndexObject(cboxTypeFranshiza->Items, q->FieldByName("type_franshiza")->AsInteger);
   if(index_type_fr > -1){
      if(q->FieldByName("type_franshiza")->AsInteger == 3){
         if(q->FieldByName("franshiza_unit")->AsInteger == 2) cboxTypeFranshiza->EditText = cboxTypeFranshiza->Items->Strings[1];
         else if(q->FieldByName("franshiza_unit")->AsInteger == 4){
            int index_frr = cboxTypeFranshiza->Items->IndexOf("����������� � ������ ��������");
            if(index_frr > -1) cboxTypeFranshiza->EditText = cboxTypeFranshiza->Items->Strings[index_frr];
         }
         cboxTypeFranshiza->Node->Expand(true);
         ChangeFranshizeBox(cboxTypeFranshiza);
         cboxFranshiza->EditText = q->FieldByName("franshiza")->AsString;
      }
      else cboxTypeFranshiza->EditText = cboxTypeFranshiza->Items->Strings[index_type_fr];
   }

   if(contract_type){
      int ub_idx = q->FieldByName("prev_ubitki_idx_pc")->AsInteger;
      if(ub_idx > -1) cbox_K5_K6->EditText = cbox_K5_K6->Items->Strings[ub_idx];
   }
   else{
      int osago_idx = GetIndexObject(cbox_K5_K6->Items, q->FieldByName("osago_idx")->AsInteger);
      if(osago_idx > -1) cbox_K5_K6->EditText = cbox_K5_K6->Items->Strings[osago_idx];
   }

   in_event = false;

   GROUP_TS_STR = StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(group_ts)), "������ ", empty_str, rf);
   GetRangeAge();
   GetApplyingKoeffs();
   Calc_k3();
   CalcAll();
   k1 = K1Final(true);
   SetFrInsteadK1(k1);

   RecalcCostTdr(di->calc_info.cost_vehicle == 0);

   status_dogovor = q->FieldByName("status_id")->AsInteger;

   ControlChange(0);
}
//---------------------------------------------------------------------------
void TFramePreCalc::GetGroupTS()
{
   if(tsi->tstype_id == 3 && cboxTSModel->EditText == "������ ������ (��������)"){
      q = m_api->dbGetCursor(res, sql.sprintf("select gruppa_ts from gl_dict_model_po_gruppam where id_ts='%s' and ((min_massa<=0%s and max_massa>=0%s) or (min_massa=0 and max_massa=0)) and CDate('%s')>=start_data and CDate('%s')<=end_data",
                                              AddNulls(model_id), editMaxMassa->EditText.c_str(), editMaxMassa->EditText.c_str(), di->calc_date, di->calc_date));
      group_ts = q->IsEmpty() ? -1 : q->FieldByName("gruppa_ts")->AsString.Trim().ToInt();
      m_api->dbCloseCursor(res, q);
      if(group_ts == -1){  last_err = ", �.�. ������� ������� ����������� ������������ �����"; }
   }
   else if(tsi->tstype_id == 4 && cboxTSModel->EditText == "������ ������ (�������)"){
      q = m_api->dbGetCursor(res, sql.sprintf("select gruppa_ts from gl_dict_model_po_gruppam where id_ts='%s' and ((min_col_m<=0%s and max_col_m>=0%s) or (min_col_m=0 and max_col_m=0)) and CDate('%s')>=start_data and CDate('%s')<=end_data",
                                  AddNulls(model_id), editSeatCount->EditText.c_str(), editSeatCount->EditText.c_str(), di->calc_date, di->calc_date));
      group_ts = q->IsEmpty() ? -1 : q->FieldByName("gruppa_ts")->AsString.Trim().ToInt();
      m_api->dbCloseCursor(res, q);
      if(group_ts == -1){ last_err = ", �.�. ������� ������� ����� ���� ������������� ��������"; }
   }
   else if(tsi->tstype_id < 5){ // ���� ���������� ����� � ������
      q = m_api->dbGetCursor(res, sql.sprintf("select gruppa_ts, group_name from gl_dict_model_po_gruppam, Tar_Gr where val(gl_dict_model_po_gruppam.gruppa_ts)=Tar_Gr.id_group and id_ts='%s' and ((min_massa<=0%s and max_massa>=0%s) or (min_massa=0 and max_massa=0)) and ((min_col_m<=0%s and max_col_m>=0%s) or (min_col_m=0 and max_col_m=0)) and CDate('%s')>=start_data and CDate('%s')<=end_data order by min_massa desc, min_col_m desc", AddNulls(model_id), editMaxMassa->EditText.c_str(), editMaxMassa->EditText.c_str(), editSeatCount->EditText.c_str(), editSeatCount->EditText.c_str(), di->calc_date, di->calc_date));
      group_ts = q->IsEmpty() ? -1 : q->FieldByName("gruppa_ts")->AsString.Trim().ToInt();
      m_api->dbCloseCursor(res, q);
   }
   ChangeFranshizeBox();
   if(contract_type) ChangeList_K5_K6();
}
//---------------------------------------------------------------------------
void TFramePreCalc::GetApplyingKoeffs()
{
    // ������������� ������������� � ��������� ������
   q = m_api->dbGetCursor(res, sql.sprintf("select ctc.coeff_id as coeff,ctc.tariff_id as ctctid,ct.tariff_id as cttid,ct.risk_id as risk from CascoTariffCoeff as ctc"
                                           " left join CascoTariff as ct on ctc.tariff_id=ct.tariff_id where (ct.product_id=%d and ct.vehgr_id=%d and ct.risk_id=%d"
                                           " and CDate('%s')>=ctc.start_date and CDate('%s')<=ctc.end_date)", ProductID(), tsi->IsSpectech() ? 11 : 0, risk, di->calc_date, di->calc_date));
   for(coeff_base.clear(), q->First(); !q->Eof; q->Next()) coeff_base.insert(q->FieldByName("coeff")->AsInteger);
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::CalcPremiumOsnRisk()
{
   osn_risk_itog_tarif = Round(di->calc_info.bt *
        (coeff_base.count(1)  ? k1  : 1) *
        (coeff_base.count(28) ? kd  : 1) *
        (coeff_base.count(2)  ? di->calc_info.k2  : 1) *
        (coeff_base.count(3)  ? di->calc_info.k3  : 1) *
        (coeff_base.count(4)  ? di->calc_info.k4  : 1) *
        (coeff_base.count(5)  ? k5  : 1) *
        (coeff_base.count(7)  ? di->calc_info.k7  : 1) *
        (coeff_base.count(9)  ? kar : 1) *
        (coeff_base.count(11) ? di->calc_info.kr  : 1) *
        (coeff_base.count(14) ? di->calc_info.ka  : 1) *
        (coeff_base.count(18) ? di->calc_info.kyu : 1) *
        (coeff_base.count(19) ? k6  : 1) *
        (coeff_base.count(24) ? di->calc_info.ks  : 1) *
        (coeff_base.count(22) ? di->calc_info.krs : 1) *
        (coeff_base.count(23) ? di->calc_info.kpr : 1) *
        (coeff_base.count(26) ? di->calc_info.kb  : 1) * di->calc_info.kfr);

   double mr = GetMinRate();
   if(mr && mr > osn_risk_itog_tarif) osn_risk_itog_tarif = mr;
   if(osn_risk_itog_tarif > 100) osn_risk_itog_tarif = 100;

   premiya_osn_risk = Round(osn_risk_itog_tarif * di->calc_info.str_summa / 100);
}
//---------------------------------------------------------------------------
void TFramePreCalc::CalcPremium()
{
   osn_risk_itog_tarif = premiya_all = premiya_osn_risk = 0;
   CalcPremiumOsnRisk();

   int index = cboxProgramms->EditText.IsEmpty() ? 0 : cboxProgramms->Items->IndexOf(cboxProgramms->EditText);
   if(((DataDict*)cboxProgramms->Items->Objects[index])->id == 1045 && premiya_osn_risk < min_premium_ekonom[group_ts]) premiya_osn_risk = min_premium_ekonom[group_ts];

   premiya_all = premiya_osn_risk;
   labPremiaMain->Caption = "�����: " + FloatToStr(osn_risk_itog_tarif) + ", ������: " + FormatDigits(premiya_osn_risk);

   if(status_dogovor == 2){
      AnsiString cptn = "����������� ������������. ������� �� ������� �������� �������� ��������������, �.�.: \r\n" + non_standart_str->Text;
      labNonStandardDogovor_Up->Caption   = cptn;
      labNonStandardDogovor_Up->Height    = (non_standart_str->Count + 1) * 20;
      labNonStandardDogovor_Down->Caption = labNonStandardDogovor_Up->Caption;
      labNonStandardDogovor_Down->Height  = labNonStandardDogovor_Up->Height;
   }
   else{ labNonStandardDogovor_Up->Height = 3; labNonStandardDogovor_Down->Height = 3; }
}
//---------------------------------------------------------------------------
inline bool TFramePreCalc::CheckCost(const double& val)
{
   if(!val || !di->calc_info.cost_tdr) return true;

   return (tdr.GetMinCost("RUR") <= val && val <= tdr.GetMaxCost("RUR"));
}
//---------------------------------------------------------------------------
void TFramePreCalc::Calc_bt()
{
   // ������� �����
   q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from gl_dict_cascobaserate where risk_id=%i and tertype_id=%i and veh_age=%i and product_id=%i and vehi_gr_id=%i"
        " and CDate('%s')>=start_date and CDate('%s')<=end_date", risk, di->REGION_TYPE, tsi->ts_age, ProductID(), group_ts, di->calc_date, di->calc_date));
   if(q->IsEmpty()){ nf_bt = 1; di->calc_info.bt = 0; }
   else{
      nf_bt = false;
      di->calc_info.bt = q->FieldByName("coeff_val")->AsFloat;
    }
    m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::Calc_kar()
{
   int status = pi[0].status == 2 ? 35 : (pi[0].status + 1);
   kar = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select top 1 coeff_val from gl_dict_cascokar where terr_id=%i and (product_id=%i or product_id=0) and (vehgroup_id=%i or vehgroup_id=0) and subtype_id=%i and vehmod_id=%i and ((vehage_min<=%i and vehage_max>=%i) or vehage_max is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehage_min desc, vehage_max desc, product_id desc, vehgroup_id desc", region_id, ProductID(), group_ts, status, model_id, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date), 1, false);
}
//---------------------------------------------------------------------------
void TFramePreCalc::Calc_k3()
{
   cboxCredit->ReadOnly = !(di->monthcount == 12);

   FilterDataSet(srok, "srok_min<=" + IntToStr(di->monthcount) + " and srok_max>=" + IntToStr(di->monthcount) + " and start_date<='" + di->calc_date + "' and end_date>='" + di->calc_date + "'");
   di->calc_info.k3 = srok->IsEmpty() ? 1 : srok->FieldByName("coeff_val")->AsFloat;
}
//---------------------------------------------------------------------------
void TFramePreCalc::Calc_k7()
{
    // �7-�
    q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i"
                                            " and CDate('%s')>=start_date and CDate('%s')<=end_date",
                                            !cboxVozmType->EditText.IsEmpty() ? (int)cboxVozmType->Items->Objects[cboxVozmType->Items->IndexOf(cboxVozmType->EditText)] : -1,
                                            di->REGION_TYPE, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date));
    di->calc_info.k7 = q->IsEmpty() ? 1 : q->FieldByName("coeff_val")->AsFloat;
    m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::Protivougon()
{
   AnsiString sql(""), rsa_code = AddNulls(model_id);
   AnsiString brand_rsa_code = rsa_code.SubString(1, 3) + "000000";
   int year = editTSYear->EditText.SubString(1, 4).ToIntDef(curr_year);

   memoProtivougonki->EditText = empty_str; is_risk_ts = false;
   q = m_api->dbGetCursor(res, sql.sprintf("select top 1 *"
                                           " from gl_dict_alarm_schema"
                                           " where"
                                           " (product_id=%i or product_id=0) and"
                                           " (program_id=%i or program_id=%i or program_id=0) and"
                                           " (vehiclersamodelid='%s' or vehiclersamodelid='%s' or vehiclersamodelid='000000000') and"
                                           " (vehiclegroupid=%i or vehiclegroupid=0) and"
                                           " (cascoterritoryid=%i or cascoterritoryid=0) and"
                                           " vehicleyearmin<=%i and vehicleyearmax>=%i"
                                           " and CDate('%s')>=start_date and CDate('%s')<=end_date"
                                           " order by product_id desc, program_id desc, vehiclersamodelid desc, vehiclegroupid desc, cascoterritoryid desc, vehicleyearmax desc, vehicleyearmin desc",
                                           ProductID(), programm_id, 0, brand_rsa_code, rsa_code, group_ts, region_id, year, year, di->calc_date, di->calc_date));

   is_risk_ts = q->FieldByName("risk_group")->AsInteger;
   memoProtivougonki->EditText = m_api->dbGetStringFromQueryDef(res, sql.sprintf("select alarm_systems from gl_dict_alarms where numreqalarm_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q->FieldByName("RequiredAlarmsScheme")->AsInteger, di->calc_date, di->calc_date));
   m_api->dbCloseCursor(res, q);

}
//---------------------------------------------------------------------------
void TFramePreCalc::CalcAll(bool is_kr, bool is_k7, bool is_protivougon)
{
   AnsiString union_sql, sql_bt, sql_k7, sql_kr;
   int status = pi[0].status == 2 ? 35 : (pi[0].status + 1);

   union_sql = sql_bt.sprintf("select 'bt' as coeff_name,coeff_val,veh_age as vag,risk_id,product_id,0 as subtype_id from gl_dict_cascobaserate where risk_id=%i and tertype_id=%i and veh_age=%i and product_id=%i and vehi_gr_id=%i"
               " and CDate('%s')>=start_date and CDate('%s')<=end_date", risk, di->REGION_TYPE, tsi->ts_age, ProductID(), group_ts, di->calc_date, di->calc_date);

   if(is_kr) union_sql = union_sql + sql_kr.sprintf(" union all select top 1 'kr' as coeff_name,coeff_val,vehicle_age_max as vag,risk_id,product_id,subtype_id from gl_dict_cascokr where terr_id=%i and (product_id=%i or product_id=0) and (subtype_id=%i or subtype_id=0) and (risk_id=%i or risk_id is null) and vehi_gr_id=%i and ((vehicle_age_min<=%i and vehicle_age_max>=%i) or vehicle_age_max is null)"
               " and CDate('%s')>=start_date and CDate('%s')<=end_date order by vag desc, risk_id desc,product_id desc,subtype_id desc", region_id, ProductID(), status, risk, group_ts, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date);

   if(is_k7) union_sql = union_sql + sql_k7.sprintf(" union all select 'k7' as coeff_name,coeff_val,vehage_max as vag,0 as risk_id,0 as product_id,0 as subtype_id from CascoDictK07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i"
               " and CDate('%s')>=start_date and CDate('%s')<=end_date", !cboxVozmType->EditText.IsEmpty() ? (int)cboxVozmType->Items->Objects[cboxVozmType->Items->IndexOf(cboxVozmType->EditText)] : -1,
               di->REGION_TYPE, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date);

   q = m_api->dbGetCursor(res, union_sql);
   if(q->Locate("coeff_name", "bt",  locate)){
      di->calc_info.bt = q->FieldByName("coeff_val")->AsFloat;
      nf_bt = false;
   }
   else{ di->calc_info.bt = 0; nf_bt = 1; }
   if(is_kr) di->calc_info.kr = q->Locate("coeff_name", "kr", locate) ? q->FieldByName("coeff_val")->AsFloat : 1;
   if(is_k7) di->calc_info.k7 = q->Locate("coeff_name", "k7", locate) ? q->FieldByName("coeff_val")->AsFloat : 1;

   m_api->dbCloseCursor(res, q);
   if(is_protivougon) Protivougon();
}
//---------------------------------------------------------------------------
void TFramePreCalc::GetRangeAge()
{
   AnsiString sql;
   q = m_api->dbGetCursor(res, sql.sprintf("select min(veh_age) as minvehage,max(veh_age) as maxvehage from gl_dict_cascobaserate where risk_id=%i and tertype_id=%i and product_id=%i and vehi_gr_id=%i"
                                           " and CDate('%s')>=start_date and CDate('%s')<=end_date", risk, di->REGION_TYPE, ProductID(), group_ts, di->calc_date, di->calc_date));
   if(!q->IsEmpty()){
      ts_age_min = q->FieldByName("minvehage")->AsInteger;
      ts_age_max = q->FieldByName("maxvehage")->AsInteger;
   }
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeMultiDrive()
{
   AnsiString str_multy = cboxMultidrive->EditText;
   q = m_api->dbGetCursor(res, sql.sprintf("select id,type_multidrive,coeff_val from cascomultidrive where CDate('%s')>=start_date and CDate('%s')<=end_date and (isnull(terrtype_id) or terrtype_id=%i) order by id", di->calc_date, di->calc_date, di->REGION_TYPE));
   for(cboxMultidrive->Items->Clear(), q->First(); !q->Eof; q->Next()){
      DataDict *multy = new DataDict(q->FieldByName("id")->AsInteger, q->FieldByName("coeff_val")->AsFloat, 0);
      cboxMultidrive->Items->AddObject(q->FieldByName("type_multidrive")->AsString.Trim(), multy);
   }
   m_api->dbCloseCursor(res, q);
   if(cboxMultidrive->Items->IndexOf(str_multy) > -1) cboxMultidrive->EditText = str_multy;
   else cboxMultidrive->EditText = empty_str;
}
//---------------------------------------------------------------------------
void TFramePreCalc::LoadData()
{
   AnsiString sql("");

   q = m_api->dbGetCursor(res, sql.sprintf("select bank_id,bank_name from gl_dict_banks where CDate('%s')>=start_date and CDate('%s')<=end_date order by bank_name", di->calc_date, di->calc_date));
   for(q->First(); !q->Eof; q->Next()) cboxBank->Items->AddObject(q->FieldByName("bank_name")->AsString, (TObject*)q->FieldByName("bank_id")->AsInteger);
   m_api->dbCloseCursor(res, q);

   for(int i = curr_year, end_year = curr_year - 12; i >= end_year; --i){
      if(i == curr_year - 1 && TDateTime(di->calc_date) < TDateTime(curr_year, 7, 1))
         editTSYear->Items->Add(IntToStr(i) + " �., ����� �� c �������� ����� 1000 ��");
      editTSYear->Items->Add(IntToStr(i) + ts_age_str[curr_year - i]);
   }

   q = m_api->dbGetCursor(res, sql.sprintf("select * from cascodictk02 where CDate('%s')>=start_date and CDate('%s')<=end_date order by k2_id", di->calc_date, di->calc_date));
   for(q->First(); !q->Eof; q->Next()){
      DataDict *k2 = new DataDict(q->FieldByName("k2_id")->AsInteger, q->FieldByName("coeff_val")->AsFloat, 0);
      cboxTSCount->Items->AddObject("(" + q->FieldByName("vehcnt_min")->AsString + " - " + q->FieldByName("vehcnt_max")->AsString + ") ��.", k2); 
   }
   m_api->dbCloseCursor(res, q);

   GetApplyingKoeffs();

   LoadVozmTypeList();

   ChangeList_K5_K6();

   ChangeMultiDrive();

   ChangeListFullInsur();

   q = m_api->dbGetCursor(res, sql.sprintf("select driver_count,coeff_value from cascodictkd where CDate('%s')>=start_date and CDate('%s')<=end_date order by driver_count", di->calc_date, di->calc_date));
   for(coeff_kd.clear(), q->First(); !q->Eof; q->Next()) coeff_kd.push_back(q->FieldByName("coeff_value")->AsFloat);
   m_api->dbCloseCursor(res, q);

   int pid = ProductID();
   ChangeListProject(pid);

   ChangeListCredits();

   if(min_rate) m_api->dbCloseCursor(res, min_rate);
   min_rate = m_api->dbGetCursor(res, sql.sprintf("select * from casco_minrate where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));

   if(region_bl) m_api->dbCloseCursor(res, region_bl);
   region_bl = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_black_list_regions where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeSource()
{
   int index = cboxSource->Items->IndexOf(cboxSource->EditText), ii, ii_var = cboxVariant->Items->IndexOf(cboxVariant->EditText), last_ii = cboxSrok->Items->Count - 1;

   cboxBank->EditText      = empty_str;
   MemoBank->EditText      = empty_str;
   cboxBank->ReadOnly      = !index;
   MemoBank->ReadOnly      = !index;
   cboxSrok->ReadOnly      = index;
   cboxFullInsur->ReadOnly = !index;

   if(di->bank_id == 47){ CalcAll(false, false, false); K1Final(true); }
   cboxVariant->EditText = "������� \"�\"";
   di->type_money = index;
   di->bank_id = 0;
   if(ii_var){
      LoadVozmTypeList();
      CalcAll(false, false, false);
      GetApplyingKoeffs();
      GetRangeAge();
      int pid = ProductID();
      GetRiskCode(-1, risk, pid);
      ChangeListProject(pid);
   }
   bank_multidrive = true;

   if(!index){
      cboxVariant->Items->Add(vB);
      cboxSource->Node->Collapse(true);
   }
   else{
      ii = cboxSrok->Items->IndexOf(cboxSrok->EditText);
      if(ii != last_ii){ cboxSrok->EditText = "1 ���"; cboxSrokChange(); }
      cboxVariant->Items->Delete(cboxVariant->Items->IndexOf(vB));
      cboxSource->Node->Expand(true);
   }

   if(cboxFullInsur->Items->Count) cboxFullInsur->EditText = cboxFullInsur->Items->Strings[0];
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeBank()
{
   int index = cboxBank->Items->IndexOf(cboxBank->EditText), field_val;
   if(index == -1) return;

   di->bank_id = int(cboxBank->Items->Objects[index]);
   q = m_api->dbGetCursor(res, "select bank_name_print,benefic,requirements,bank_address,bank_inn,bank_ogrn from gl_dict_banks where bank_id=" + IntToStr(di->bank_id));

   MemoBank->EditText = StringReplace(q->FieldByName("requirements")->AsString, ";", "\r\n", rf);
   m_api->dbCloseCursor(res, q);

   IsPorsche27RF();
}
//---------------------------------------------------------------------------
void TFramePreCalc::GetRiskCode(const int index, const int risk_id, const int prod_id)
{
   if(index == -1){
      q = m_api->dbGetCursor(res, sql.sprintf("select distinct risk_code, risk_id, code_prod, name_prod from cascotariff where product_id=%i and risk_id in (%i, 4, 5) order by risk_id", prod_id, risk_id));
      for(q->First(); !q->Eof; q->Next()){
         if(q->RecNo == 1){
            code_prod = q->FieldByName("code_prod")->AsInteger;
            name_prod = q->FieldByName("name_prod")->AsString;
         }
         risk_code[q->RecNo - 1] = q->FieldByName("risk_code")->AsString;
      }
      m_api->dbCloseCursor(res, q);
   }
   else risk_code[index] = m_api->dbGetStringFromQuery(res, sql.sprintf("select top 1 risk_code from cascotariff where product_id=%i and risk_id=%i", prod_id, risk_id));
}
//---------------------------------------------------------------------------
void TFramePreCalc::cboxSrokChange()
{
   di->monthcount = cboxSrok->Items->IndexOf(cboxSrok->EditText) + 6;
   if(di->monthcount < 12){
      cboxCredit->EditText = "�������������� ������";
      ChangeOrderPayments();
   }
   Calc_k3();
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeListProject(const int pid)
{
   AnsiString str_prg = cboxProgramms->EditText;

   cboxProgramms->Items->Clear();

   q = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_programm_project where (product_id=%i or product_id=0) and (region_id=116 or region_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date and CDate('%s')>=start_date_coeff and CDate('%s')<=end_date_coeff order by project_id", pid, region_id, di->calc_date, di->calc_date, di->calc_date, di->calc_date));
   for(q->First(); !q->Eof; q->Next()){
      DataDict *prj = new DataDict(q->FieldByName("project_id")->AsInteger, 1.0, 0);
      if(q->FieldByName("ka_min")->AsFloat == q->FieldByName("ka_max")->AsFloat) prj->coeff_value = q->FieldByName("ka_max")->AsFloat;
      else{
         prj->coeff_min = q->FieldByName("ka_min")->AsFloat;
         prj->coeff_max = q->FieldByName("ka_max")->AsFloat;
      }
      if(q->FieldByName("project_type_id")->AsInteger == 2)  cboxProgramms->Items->AddObject(q->FieldByName("project_name")->AsString, prj);
   }
   m_api->dbCloseCursor(res, q);

   int index_prg = cboxProgramms->Items->IndexOf(str_prg);
   if(index_prg == -1) index_prg = 0;
   cboxProgramms->EditText = cboxProgramms->Items->Strings[index_prg];
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeListCredits()
{
   AnsiString str_crd = cboxCredit->EditText;

   q = m_api->dbGetCursor(res, sql.sprintf("select id_krs,credit_name,payment_count_min,coeff_value from cascodictk08 where terr_type_id=%i and (product_id=%i or product_id=0) and CDate('%s')>=start_date and CDate('%s')<=end_date order by id_krs", di->REGION_TYPE, ProductID(), di->calc_date, di->calc_date));
   for(cboxCredit->Items->Clear(), q->First(); !q->Eof; q->Next()){
      DataDict *k8 = new DataDict(q->FieldByName("id_krs")->AsInteger, q->FieldByName("coeff_value")->AsFloat, q->FieldByName("payment_count_min")->AsInteger);
      cboxCredit->Items->AddObject(q->FieldByName("credit_name")->AsString, k8);
   }
   m_api->dbCloseCursor(res, q);

   int index_crd = cboxCredit->Items->IndexOf(str_crd);
   cboxCredit->EditText = cboxCredit->Items->Strings[index_crd > -1 ? index_crd : 0];
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeList_K5_K6()
{
   cbox_K5_K6->Caption  = contract_type ? "������ �� ����������� ��������" : "����������� �� ���-��� �� �����";

   AnsiString str_k5_k6 = cbox_K5_K6->EditText;
   cbox_K5_K6->EditText = empty_str;

   q = m_api->dbGetCursor(res, contract_type
                               ? sql.sprintf("select k5_name, coeff_val from CascoDictK05 where terr_type_id=%i and (vehgrp_id=0 or vehgrp_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by pay_num", !pi[0].status ? 0 : di->REGION_TYPE, !pi[0].status ? 100 : group_ts, di->calc_date, di->calc_date)
                               : sql.sprintf("select k6_id,k6_name,coeff_val from CascoDictK06 where terr_id=0 and CDate('%s')>=start_date and CDate('%s')<=end_date order by sort_order", di->calc_date, di->calc_date));
   for(cbox_K5_K6->Items->Clear(), q->First(); !q->Eof; q->Next()){
      if(contract_type){
         double coef = q->FieldByName("coeff_val")->AsFloat;
         cbox_K5_K6->Items->AddObject(q->FieldByName("k5_name")->AsString.Trim(), (TObject*)int(RoundTo(coef * 1000, 0)));
      }
      else{
         DataDict *k6 = new DataDict(q->FieldByName("k6_id")->AsInteger, q->FieldByName("coeff_val")->AsFloat, 0);
         cbox_K5_K6->Items->AddObject(q->FieldByName("k6_name")->AsString.Trim(), k6);
      }
   }
   m_api->dbCloseCursor(res, q);

   int ind = cbox_K5_K6->Items->IndexOf(str_k5_k6);
   if(ind > -1) cbox_K5_K6->EditText = cbox_K5_K6->Items->Strings[ind];
}
//---------------------------------------------------------------------------
void TFramePreCalc::IsPorsche27RF()
{
   if(di->bank_id == 43 && MarkaId(model_id) == porsche && tsi->ts_age > 1){
      int vozm_id = cboxVozmType->Items->IndexOfObject((TObject*)3);
      cboxVozmType->EditText = vozm_id > -1 ? cboxVozmType->Items->Strings[vozm_id] : empty_str;
      Calc_k7();
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeOrderPayments()
{
   int index = cboxCredit->Items->IndexOf(cboxCredit->EditText), index_source = cboxSource->Items->IndexOf(cboxSource->EditText);

   if(index > 0 && !index_source){
      cboxSrok->EditText = "1 ���";
      cboxSrokChange();
   }
   cboxSrok->ReadOnly = (index > 0 || index_source);
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeFranshizeBox(TObject *Sender)
{
   /*AnsiString str_fr = cboxFranshiza->EditText, str_fr_type = cboxTypeFranshiza->EditText;

   if(cboxTypeFranshiza->Items->IndexOf("������������") > -1) cboxTypeFranshiza->Items->Delete(2);

   FilterDataSet(franshize, "terr_id=" + IntToStr(region_id) + " and vehicle_group=" + IntToStr(group_ts) + " and fran_perc=100 and status=" + IntToStr(pi[0].status) + " and start_date<='" + di->calc_date + "' and end_date>='" + di->calc_date + "'");
   if(!franshize->IsEmpty()) cboxTypeFranshiza->Items->AddObject("������������", new DataDict(6, franshize->FieldByName("coeff_val")->AsFloat, 1));
   else{
      FilterDataSet(franshize, "terr_id=0 and vehicle_group=" + IntToStr(group_ts) + " and fran_perc=100 and status=" + IntToStr(pi[0].status) +  " and start_date<='" + di->calc_date + "' and end_date>='" + di->calc_date + "'");
      if(!franshize->IsEmpty()) cboxTypeFranshiza->Items->AddObject("������������", new DataDict(6, franshize->FieldByName("coeff_val")->AsFloat, 1));
   }

   FilterDataSet(franshize, "vehicle_group=" + IntToStr(group_ts) + " and fran_perc<>100 and start_date<='" + di->calc_date + "' and end_date>='" + di->calc_date + "'");
   for(cboxFranshiza->Items->Clear(), franshize->First(); !franshize->Eof; franshize->Next())
      cboxFranshiza->Items->AddObject(franshize->FieldByName("fran_perc")->AsString, (TObject*)int(RoundTo(franshize->FieldByName("coeff_val")->AsFloat * 1000, 0)));

   int index = cboxFranshiza->Items->IndexOf(str_fr);
   cboxFranshiza->EditText = index > -1 ? cboxFranshiza->Items->Strings[index] : empty_str;

   index = cboxTypeFranshiza->Items->IndexOf(str_fr_type);
   if(index == -1) index = 0;
   cboxTypeFranshiza->EditText = cboxTypeFranshiza->Items->Strings[index];*/

   AnsiString str_fr = cboxFranshiza->EditText, str_fr_type = cboxTypeFranshiza->EditText, sql(""), marka_id = MarkaId(model_id);
   int index(0), pid = ProductID();

   if(Sender != cboxTypeFranshiza){
      Variant lv[2];
      for(int i = 1, cnt = cboxTypeFranshiza->Items->Count;  i < cnt; ++i) cboxTypeFranshiza->Items->Delete(1);

      //code_t_fr=%i and code_ed_izm_fr=%i and
      q = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_franshize where (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date", group_ts, pid, di->region_id, AddNulls(model_id), marka_id, 0, programm_id, di->calc_date, di->calc_date));
      lv[0] = 3; lv[1] = 2;
      if(q->Locate("code_t_fr;code_ed_izm_fr", VarArrayOf(lv, 1), locate)) cboxTypeFranshiza->Items->AddObject("����������� � %", new DataDict(3, 1.0, 2));
      lv[1] = 4;
      if(q->Locate("code_t_fr;code_ed_izm_fr", VarArrayOf(lv, 1), locate)) cboxTypeFranshiza->Items->AddObject("����������� � ������ ��������", new DataDict(3, 1.0, 4));
      if(q->Locate("code_t_fr", 6, locate)) cboxTypeFranshiza->Items->AddObject("������������", new DataDict(6, q->FieldByName("coeff_value")->AsFloat, 1));

      m_api->dbCloseCursor(res, q);

      index = cboxTypeFranshiza->Items->IndexOf(str_fr_type);
      if(index == -1) index = 0;
      cboxTypeFranshiza->EditText = cboxTypeFranshiza->Items->Strings[index];
   }

   index = cboxTypeFranshiza->Items->IndexOf(cboxTypeFranshiza->EditText);
   cboxFranshiza->Items->Clear();
   if(index > 0){
      DataDict *fr_data = (DataDict*)cboxTypeFranshiza->Items->Objects[index];
      if(fr_data->id == 3){
         q = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_franshize where code_t_fr=%i and code_ed_izm_fr=%i and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by franchise_percent", 3, fr_data->field_val1, group_ts, pid, di->region_id, AddNulls(model_id), marka_id, 0, programm_id, di->calc_date, di->calc_date));
         for(q->First(); !q->Eof; q->Next()) cboxFranshiza->Items->AddObject(q->FieldByName("franchise_percent")->AsString, (TObject*)int(RoundTo(q->FieldByName("coeff_value")->AsFloat * 1000, 0)));
         m_api->dbCloseCursor(res, q);
      }
   }

   index = cboxFranshiza->Items->IndexOf(str_fr);
   cboxFranshiza->EditText = index > -1 ? cboxFranshiza->Items->Strings[index] : empty_str;
}
//---------------------------------------------------------------------------
double TFramePreCalc::GetKprSb(const double& val)
{
   if(val <= 0.54) return 1.75;
   if(val <= 0.59) return 1.60;         
   if(val <= 0.64) return 1.50;
   if(val <= 0.69) return 1.40;
   if(val <= 0.74) return 1.30;

   return 1.2;
}
//---------------------------------------------------------------------------
void TFramePreCalc::DisableGBP()
{
}
//---------------------------------------------------------------------------
void TFramePreCalc::DisableGBTS()
{
   cboxTSType->ReadOnly  = true;
   cboxTSMarka->ReadOnly = true;
   cboxTSModel->ReadOnly = true;
   editTSYear->ReadOnly  = true;
}
//---------------------------------------------------------------------------
void TFramePreCalc::ChangeListFullInsur()
{
   AnsiString str = cboxFullInsur->EditText;

   cboxFullInsur->Items->Clear();
   cboxFullInsur->Items->AddObject("����������� �� ������ ���������", (TObject*)1);
   switch(cboxVariant->Items->IndexOf(cboxVariant->EditText)){
      case 0:
         cboxFullInsur->Items->AddObject("�������� ���������������� �����������", (TObject*)2);
         cboxFullInsur->Items->AddObject("�������� ����������� �� ������� �����", (TObject*)3);
         break;
      case 1:
        cboxFullInsur->Items->AddObject("�������� ���������������� �����������", (TObject*)2);
   }
   int index = cboxFullInsur->Items->IndexOf(str);
   if(index == -1) index = 0;
   cboxFullInsur->EditText = cboxFullInsur->Items->Strings[index];
}
//---------------------------------------------------------------------------
int TFramePreCalc::GetDrvCount(TADOQuery *qq)
{
   qq->Filtered = false;
   qq->Filter   = "[type_person] > 3";
   qq->Filtered = true;

   int drv_count = qq->RecordCount;

   qq->Filtered = false;

   return drv_count;
}
//---------------------------------------------------------------------------
double TFramePreCalc::GetMinRate()
{
   int i = cboxProgramms->Items->IndexOf(cboxProgramms->EditText);
   if(i == -1) i = 0;
   if(((DataDict*)cboxProgramms->Items->Objects[i])->id == 1045) return 0.0;

   AnsiString f("");
   FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i", region_id));
   if(!min_rate->IsEmpty()){
      FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i and [model_code]=%i", region_id, model_id));
      if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
      else{
         FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i and [vehicle_group_id]=%i", region_id, group_ts));
         if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
         else                     return 0.0;
      }
   }
   else{
      FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i", di->REGION_TYPE));
      if(!min_rate->IsEmpty()){
         FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i and [model_code]=%i", di->REGION_TYPE, model_id));
         if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
         else{
            FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i and [vehicle_group_id]=%i", di->REGION_TYPE, group_ts));
            if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
            else                     return 0.0;
         }
      }
      else return 0.0;
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::Calc_Kb()
{
   if(di->bank_id > 0){
      FilterDataSet(dict_kb, "terr_type_id=" + IntToStr(di->REGION_TYPE) + " and bank_id=" + IntToStr(di->bank_id) + " and start_date<='" + di->calc_date + "' and end_date>='" + di->calc_date + "'");
      if(dict_kb->IsEmpty()){
         FilterDataSet(dict_kb, "terr_type_id=" + IntToStr(di->REGION_TYPE) + " and bank_id=0 and start_date<='" + di->calc_date + "' and end_date>='" + di->calc_date + "'");
         di->calc_info.kb = dict_kb->IsEmpty() ? 1.0 : dict_kb->FieldByName("coeff_value")->AsFloat;
      }
      else di->calc_info.kb = dict_kb->FieldByName("coeff_value")->AsFloat;
   }
   else di->calc_info.kb = 1.0;
}
//---------------------------------------------------------------------------
void TFramePreCalc::RecalcOnTheDate(const TDateTime& dt)
{
   if(!m_api) return;
   di->calc_date = dt.DateString();

   di->REGION_TYPE = m_api->dbGetIntFromQuery(res, sql.sprintf("select type_id from gl_dict_dsago_contract where cnt_cl_id=5 and terr_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", region_id, di->calc_date, di->calc_date));
   LoadData();
   if(tsi->tstype_id < 7) GetGroupTS();
   GROUP_TS_STR = StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(group_ts)), "������ ", empty_str, rf);
   GetRangeAge();
   GetApplyingKoeffs();
   Calc_k3();
   CalcAll();
   k1 = K1Final(true);
   Calc();
}
//---------------------------------------------------------------------------
bool TFramePreCalc::IsNonStandartPolis()
{
   if(!pi[0].status){
      FilterDataSet(region_bl, "region_reg_plate=" + IntToStr(region_isp_id));
      if(!region_bl->IsEmpty()) non_standart_str->Add(" - ������� ������������ ������ ����������� ��");
      if(is_risk_ts) non_standart_str->Add(" - ������ �� ��������� � ������ ��������");
      if(di->calc_info.str_summa > curr_limit) non_standart_str->Add(" - �������� ����� ��������� �����");
      if(tsi->ts_age > 0 && !CheckCost(di->calc_info.str_summa) && cboxFullInsur->Items->IndexOf(cboxFullInsur->EditText) < 1) non_standart_str->Add(" - ��������� ����� ������� �� ���������, ������������ �� ������������ ����������");
      if(contract_type && cbox_K5_K6->Items->IndexOf(cbox_K5_K6->EditText) > 3) non_standart_str->Add(" - ���������� ������� ������ 3-�");
   }

   return non_standart_str->Count;
}
//---------------------------------------------------------------------------
void TFramePreCalc::DisableAllControls()
{
   for(int i = 0, cnt = ControlCount; i < cnt; ++i) Controls[i]->Enabled = false;
}
//---------------------------------------------------------------------------
void TFramePreCalc::RecalcCostTdr(bool all)
{
   if(Param1->Items->Count){
      TdrHead->Caption = "�������� ������ �� ������������ \"����������\"";
      if(!editTSRealCost->Node->Expanded) editTSRealCost->Node->Expand(true);
   }

   for(int i = 1; i < 6; ++i) if(CalcInfo->RowByName("Param" + IntToStr(i))->EditText.IsEmpty()) return;

   double costs[3] = {0.0};
   AnsiString filename(""), car_options("");
   tdr.GetCostAndPicture(params, 1, costs, filename, car_options);
   di->calc_info.cost_min = costs[1];
   di->calc_info.cost_max = costs[2];
   di->calc_info.cost_tdr = costs[0];
   if(all){
      di->calc_info.cost_vehicle = di->calc_info.cost_tdr;
      editTSRealCost->EditText = FloatToStr(di->calc_info.cost_vehicle);
      if(editStrSumma->ReadOnly) editStrSumma->EditText = di->calc_info.str_summa = di->calc_info.cost_vehicle;
      Calc();
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::ResetTransdekra()
{
   for(int i = 0; i < 5; ++i){
      TdxInspectorTextPickRow* curr_row = dynamic_cast<TdxInspectorTextPickRow*>(CalcInfo->RowByName("Param" + IntToStr(i + 1)));
      curr_row->Items->Clear();
      curr_row->EditText = params[i] = empty_str;
   }

   TdrHead->Caption = "�������������� ������ ��������� �� �� �������������� ���������� ����������";
   editTSRealCost->Node->Collapse(true);
}
//---------------------------------------------------------------------------
void TFramePreCalc::ResetAllSumms()
{
   editTSRealCost->EditText = null_str;
   editStrSumma->EditText   = null_str;
   di->calc_info.cost_vehicle = di->calc_info.str_summa = 0;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::Param1CloseUp(TObject *Sender, Variant &Value, bool &Accept)
{
   TdxInspectorTextPickRow *curr_row = dynamic_cast<TdxInspectorTextPickRow*>(Sender);
   AnsiString row_name = curr_row->Name;
   int ind = curr_row->Tag - 200;
   curr_row->EditText = params[ind] = Value;
   if(ind < 4){
      ResetTdrValues(ind + 1);
      tdr.GetListValues((TStringList*)((TdxInspectorTextPickRow*)CalcInfo->RowByName("Param" + IntToStr(ind + 2)))->Items, params, ind + 1);
      for(int i = ind + 1; i < 5; ++i){
         curr_row = dynamic_cast<TdxInspectorTextPickRow*>(CalcInfo->RowByName("Param" + IntToStr(i + 1)));
         if(curr_row->Items->Count == 1){
            curr_row->EditText = params[i] = curr_row->Items->Strings[0];
            if(i < 4) tdr.GetListValues((TStringList*)((TdxInspectorTextPickRow*)CalcInfo->RowByName("Param" + IntToStr(i + 2)))->Items, params, i + 1);
         }
         else break;
      }
   }
   RecalcCostTdr();
/* //#include "newcalc.h"
   if(f_calc->Enabled) f_calc->Param1CloseUp(dynamic_cast<TdxInspectorTextPickRow*>(f_calc->FindComponent(row_name)), Value, Accept);
*/
}
//---------------------------------------------------------------------------
AnsiString TFramePreCalc::GetParams()
{
   AnsiString result(""), curr_text("");
   for(int i = 0; i < 5; ++i){
      curr_text = dynamic_cast<TdxInspectorTextPickRow*>(CalcInfo->RowByName("Param" + IntToStr(i + 1)))->EditText;
      if(!curr_text.IsEmpty()) result += (curr_text + ";");
   }
   return result;
}
//---------------------------------------------------------------------------
void TFramePreCalc::SetParams(const AnsiString& val)
{
   TStringList *sl = new TStringList();

   sl->Text = StringReplace(val, ";", "\n", rf);
   for(int i = 0, cnt = sl->Count; i < cnt; ++i){
      dynamic_cast<TdxInspectorTextPickRow*>(CalcInfo->RowByName("Param" + IntToStr(i + 1)))->EditText = params[i] = sl->Strings[i];
      if(i < 4) tdr.GetListValues((TStringList*)((TdxInspectorTextPickRow*)CalcInfo->RowByName("Param" + IntToStr(i + 2)))->Items, params, i + 1);
   }

   delete sl;
}
//---------------------------------------------------------------------------
void TFramePreCalc::ResetTdrValues(const int index)
{
   for(int i = index; i < 5; ++i){
      TdxInspectorTextPickRow *curr_row = dynamic_cast<TdxInspectorTextPickRow*>(CalcInfo->RowByName("Param" + IntToStr(i + 1)));
      curr_row->Items->Clear();
      curr_row->EditText = params[i] = empty_str;
   }
   if(!index){
      tdr.GetListValues((TStringList*)Param1->Items);
      for(int i = 0; i < 5; ++i){
         TdxInspectorTextPickRow *curr_row = dynamic_cast<TdxInspectorTextPickRow*>(CalcInfo->RowByName("Param" + IntToStr(i + 1)));
         if(curr_row->Items->Count == 1){
            curr_row->EditText = params[i] = curr_row->Items->Strings[0];
            if(i < 4) tdr.GetListValues((TStringList*)((TdxInspectorTextPickRow*)CalcInfo->RowByName("Param" + IntToStr(i + 2)))->Items, params, i + 1);
         }
         else break;
      }
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::SetFrInsteadK1(const double& k1tmp)
{
   enable_k1f = false;
   FRANSHIZA = 0;
   if(k1tmp >= 1.4 && k1tmp <= 1.6){
      FRANSHIZA = 3;
      enable_k1f = true;
   }
   else if(k1tmp >= 1.1 && k1tmp <= 1.3){
      FRANSHIZA = 2;
      enable_k1f = true;
   }
   chkFrInsteadK1->Caption = enable_k1f ? "��������� ����������� �������� " + IntToStr(FRANSHIZA) + "% �� ��������� ����� ������ ����������� �1" : empty_str;
   if(enable_k1f) ShowGridOrChkPermitted(1);
   else chkFrInsteadK1->Visible = false;
   if(!enable_k1f && chkFrInsteadK1->Checked) ResetSChk(chkFrInsteadK1);
}
//---------------------------------------------------------------------------
void TFramePreCalc::SetStatePermitted()
{
   if(pi[0].status || tsi->IsSpectech()){
      cboxMultidrive->ReadOnly = true;
      type_multydrive = -1;
      cboxMultidrive->EditText = pi[0].status > 0 ? "��� ��,�����,�� ������ ���������� �� ���������" : "";
      DriversHead->Node->Collapse(true);
      ResetGridPermitted();
      SetFrInsteadK1(0);
   }
   else{
      cboxMultidrive->ReadOnly = false;
      type_multydrive = 100;
      cboxMultidrive->EditText = "������������ ������ ���������";
      DriversHead->Node->Expand(true);
   }
}
//---------------------------------------------------------------------------
void TFramePreCalc::SetRowKpr(const double& k_min, const double& k_max, const AnsiString& coeff)
{
   if(!cboxProgramms->Node->HasChildren){
      TdxInspectorRowNode *r_kpr = cboxProgramms->Node->AddChildEx(__classid(TdxInspectorTextPickRow));
      r_kpr->Row->Caption = "���";
      r_kpr->Row->Tag = 31;
      for(double kf = k_min; kf <= k_max; kf += 0.01) dynamic_cast<TdxInspectorTextPickRow*>(r_kpr->Row)->Items->Add(FloatToSQLStr(kf));
      dynamic_cast<TdxInspectorTextPickRow*>(r_kpr->Row)->DropDownListStyle = true;
      dynamic_cast<TdxInspectorTextPickRow*>(r_kpr->Row)->DropDownRows = 40;
      dynamic_cast<TdxInspectorTextPickRow*>(r_kpr->Row)->OnCloseUp = cboxRegionCloseUp;
      if(dynamic_cast<TdxInspectorTextPickRow*>(r_kpr->Row)->Items->IndexOf(coeff) > -1) dynamic_cast<TdxInspectorTextPickRow*>(r_kpr->Row)->EditText = coeff;
      row_kpr_name = r_kpr->Row->Name;
   }
   else{
      TdxInspectorTextPickRow *r = dynamic_cast<TdxInspectorTextPickRow*>(TermsInfo->RowByName(row_kpr_name));
      r->Items->Clear();
      for(double kf = k_min; kf <= k_max; kf += 0.01) r->Items->Add(FloatToSQLStr(kf));
   }

   cboxProgramms->Node->Expand(true);
}
//---------------------------------------------------------------------------
void TFramePreCalc::ResetGridPermitted()
{
   gridDopush->Items->Clear();
   gridDopush->Visible = false;
   gridHead->Visible   = false;
}
//---------------------------------------------------------------------------
void TFramePreCalc::ShowGridOrChkPermitted(const int who)
{
   labNonStandardDogovor_Down->Align = alNone;
   labNonStandardDogovor_Down->Top   = 4500;

   TotalInfo->Align = alNone;
   TotalInfo->Top   = 4000;

   TermsInfo->Align = alNone;
   TermsInfo->Top   = 3000;
   TermsInfo->Visible = false;
   if(who) chkFrInsteadK1->Visible = true;
   else{
      chkFrInsteadK1->Align = alNone;
      chkFrInsteadK1->Top = 2500;
      gridDopush->Align = alNone;
      gridDopush->Top   = 2000;
      gridDopush->Visible = false;
      gridHead->Visible = true;
      gridDopush->Visible = true;
      gridDopush->Align = alTop;
      chkFrInsteadK1->Align = alTop;
   }

   TermsInfo->Visible = true;
   TermsInfo->Align = alTop;
   TotalInfo->Align = alTop;
   labNonStandardDogovor_Down->Align = alTop;
}
//---------------------------------------------------------------------------
TRect TFramePreCalc::GetNodeRect(TcxTreeListNode *ANode)
{
   TRect result_rect = cxTreeList1->GetEditRect(ANode, colText1);
   result_rect.Left = 0;
   result_rect.Right = 100;

   return result_rect;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::cxTreeList1MouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
   if(AOldHitNode != cxTreeList1->HitTest->HitNode){
      if(AOldHitNode) cxTreeList1->InvalidateRect(GetNodeRect(AOldHitNode), true);
      AOldHitNode = cxTreeList1->HitTest->HitNode;
      if(AOldHitNode) cxTreeList1->InvalidateRect(GetNodeRect(AOldHitNode), true);
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::cxTreeList1Click(TObject *Sender)
{
   if(cxTreeList1->FocusedNode && cxTreeList1->FocusedNode->Level == 4){
      popup_edit->DroppedDown = false;
      popup_edit->Text = (double)(int)cxTreeList1->FocusedNode->Data / 100.0;
   }
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::cxTreeList1HotTrackNode(TObject *Sender, TcxTreeListNode *ANode, TShiftState AShift, TCursor &ACursor)
{
   ACursor = crHandPoint;
}
//---------------------------------------------------------------------------
void __fastcall TFramePreCalc::PopupItemPropertiesInitPopup(TObject *Sender)
{
   popup_edit = dynamic_cast<TcxPopupEdit*>(Sender);
}
//---------------------------------------------------------------------------

