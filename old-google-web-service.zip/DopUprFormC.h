//---------------------------------------------------------------------------

#ifndef DopUprFormCH
#define DopUprFormCH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Mask.hpp>
#include "sCurrEdit.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
//---------------------------------------------------------------------------
class TDopUprForm : public TForm
{
__published:	// IDE-managed Components
    TButton *btnAdd;
    TButton *btnCancel;
    TsCalcEdit *editAge;
    TsDateEdit *dateAge;
    TsDateEdit *dateStag;
    TsCalcEdit *editStag;
        void __fastcall btnCancelClick(TObject *Sender);
        void __fastcall btnAddClick(TObject *Sender);
        void __fastcall dateAgeChange(TObject *Sender);
        void __fastcall dateStagChange(TObject *Sender);
   void __fastcall editAgeChange(TObject *Sender);
   void __fastcall editStagChange(TObject *Sender);
private:	// User declarations
   int curr_year;
public:		// User declarations
        __fastcall TDopUprForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDopUprForm *DopUprForm;
//---------------------------------------------------------------------------
#endif
