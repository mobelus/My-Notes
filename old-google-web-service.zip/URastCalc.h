//---------------------------------------------------------------------------
#ifndef URastCalcH
#define URastCalcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Tmops_api.h"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sCurrEdit.hpp"
//#include "tools.h"
#include "DateUtils.hpp"
#include <ExtCtrls.hpp>
#include "cxControls.hpp"
#include "cxDBEditRepository.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TFRastCalc : public TFrame{
__published:	// IDE-managed Components
   TcxVerticalGrid *vg;
   TcxCategoryRow *vgCategoryRow1;
   TcxEditorRow *vg_dateStatement;
   TcxEditorRow *vg_dateCancell;
   TcxEditorRow *vg_Bases_for_Cancell;
   TcxEditorRow *vg_Reason;
   TcxCategoryRow *vgCategoryRow2;
   TcxEditorRow *vg_PolicySeries;
   TcxEditorRow *vg_PolicyNumber;
   TcxEditorRow *vg_Date;
   TcxEditRepository *cxEditRepository1;
   TcxEditRepositoryTextItem *TextItem;
   TcxEditRepositoryDateItem *DateItem;
   TcxEditRepositoryMemoItem *MemoItem;
   TcxEditRepositoryButtonItem *ButtonItem;
   TcxEditRepositoryComboBoxItem *Reason_ComboBoxItem;
   TcxEditRepositoryComboBoxItem *Bablo_ComboBoxItem;
   TcxEditRepositoryComboBoxItem *Status_ComboBoxItem;
   TcxEditRepositoryRadioGroupItem *RadioGroupItem;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *cxStyle3;
   TcxStyle *cxStyle4;
   TcxStyle *cxStyle5;
   TcxStyle *cxStyle6;
   TStaticText *labHint;
   TcxCategoryRow *vgCategoryRow3;
   TcxButton *btnRequest;
   TcxEditorRow *vg_AutorizationInfo;
   TcxCategoryRow *vgCategoryRow4;
   TcxEditorRow *vg_Status;
   TcxEditorRow *vg_Name;
   TcxEditorRow *vg_Document;
   TcxEditorRow *vg_Address;
   TcxEditorRow *vg_Phone;
   TcxCategoryRow *vg_HeadRefund;
   TcxEditorRow *vg_Refund;
   TcxEditorRow *vg_NewPolicyDate;
   TcxEditorRow *vg_NewPolicyNumber;
   TcxEditorRow *vg_NewPolicySeries;
   TcxEditorRow *vg_Bank;
   TcxEditorRow *vg_Account;
   TcxCategoryRow *CalcTotal;
   TcxEditorRow *vg_NewPolicyPremium;
   TcxEditRepositoryCurrencyItem *CurrencyItem;
   TcxEditorRow *vg_RestMoney;
   TcxEditorRow *vg_RestMoneyAccount;
   TcxEditorRow *vg_RestMoneyBank;
   TcxEditRepositoryComboBoxItem *Rest_ComboBoxItem;
   TcxEditorRow *vg_Documents;
   void __fastcall Reason_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall vgInitEdit(TObject *Sender, TObject *AItem, TcxCustomEdit *AEdit);
   void __fastcall DateItemPropertiesChange(TObject *Sender);
   void __fastcall DateItemPropertiesEditValueChanged(TObject *Sender);
   void __fastcall TextItemPropertiesChange(TObject *Sender);
   void __fastcall vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties);
   void __fastcall btnRequestClick(TObject *Sender);
   void __fastcall RadioGroupItemPropertiesChange(TObject *Sender);
   void __fastcall ButtonItemPropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall Bablo_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error);
   void __fastcall Rest_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall Status_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall DateItemPropertiesValidate(TObject *Sender,
          Variant &DisplayValue, TCaption &ErrorText, bool &Error);
private:	        // User declarations
   int res, is_autorization, is_unpaid_loss, bablo_index;
   mops_api_028 *m_api;
   double refund_value, premium_paid, new_polis_premium, n, N;
   TDateTime calc_date, new_polis_date;
   AnsiString new_polis_seria, new_polis_number, account, bank;
   PersonInfo *pi;
   Dogovor_Info *di;
   TSInfo *tsi;
   TStringList *error;
   _di_IXMLDocument XMLDoc;
   _di_IXMLNode Root;
private:
   void Recalc();
   void Error(const AnsiString& text, const int unique, bool term, int warning = 0);
   void CalcPaidPremium(TADOQuery *q);
   void SetColorOnCurrentError();
   void LoadReasons(const int set_value = 0);
   void CalcRefund();
   AnsiString CalcText();
public:
   TMemo *memo;
public:		// User declarations
   __fastcall TFRastCalc(TComponent* Owner, mops_api_028* _m_api, PersonInfo *p_pi, Dogovor_Info *p_di, TSInfo *p_tsi);
   __fastcall ~TFRastCalc();
   void LoadFrame(TADOQuery *q);
   void SaveFrame(TADOQuery *q);
};
//---------------------------------------------------------------------------
extern PACKAGE TFRastCalc *FRastCalc;
//---------------------------------------------------------------------------
#endif
