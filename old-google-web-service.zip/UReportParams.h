//---------------------------------------------------------------------------

#ifndef UReportParamsH
#define UReportParamsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "TMops_api.h"
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TfRepParams : public TForm
{
__published:	// IDE-managed Components
   TdxInspector *ParamsInfo;
   TButton *btnOK;
   TButton *btnCancel;
   TdxInspectorTextPickRow *cboxDogovorType;
   TdxInspectorTextDateRow *dateS;
   TdxInspectorTextDateRow *datePo;
   TdxInspectorTextPickRow *cboxFilial;
   TdxInspectorTextPickRow *cboxOSP;
   TdxInspectorTextPickRow *cboxSaler;
   TcxButton *btnClear;
   void __fastcall btnClearClick(TObject *Sender);
   void __fastcall btnOKClick(TObject *Sender);
private:	// User declarations
   mops_api_024 *m_api;
   TADOQuery *q;
   int res;
   AnsiString filter_report;
public:		// User declarations
   __fastcall TfRepParams(TComponent* Owner, mops_api_024 *_m_api);
   AnsiString GetFilter(){ return filter_report;}
};
//---------------------------------------------------------------------------
extern PACKAGE TfRepParams *fRepParams;
//---------------------------------------------------------------------------
#endif
