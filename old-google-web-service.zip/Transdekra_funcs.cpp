#include <algorithm>
#include <vector>

#include "Transdekra_funcs.h"
//#include "tools.h"
#include "functions.h"

#pragma package(smart_init)
const double MIN_COST_K = 0.9;
const double MAX_COST_K = 1.1;

//---------------------------------------------------------------------------
bool CarParams::operator==(const CarParams& v)
{
   if(param1 == v.param1 && param2 == v.param2 && param3 == v.param3 && param4 == v.param4 && param5 == v.param5) return true;

   return false;
}
//---------------------------------------------------------------------------
bool Transdekra::Init(mops_api_007 *module_api)
{
   COST[MIN]["EUR"] = COST[MIN]["USD"] = COST[MIN]["RUR"] = 0;
   COST[MAX]["EUR"] = COST[MAX]["USD"] = COST[MAX]["RUR"] = INT_MAX;

   m_api = module_api;
   td_stoimosti_api = 0;
   return GetTDApi() != 0;
}
//---------------------------------------------------------------------------
AnsiString Transdekra::Get_Picture_By_TD_ID(const AnsiString& td_id, TStream *out)
{
   TSearchRec sr;
   AnsiString filename(""), Path = ExtractFilePath(Application->ExeName) + "\\System\\Transdekra_Pics\\";

   if(FindFirst(Path + td_id + ".*", faAnyFile, sr) == 0){
      filename = Path + sr.Name;
      if(out){
         TFileStream *fs = new TFileStream(filename, fmOpenRead | fmShareDenyNone);
         fs->Position = 0;
         out->CopyFrom(fs, fs->Size);
         out->Position = 0;
         delete fs;
      }
      FindClose(sr);
   }
   return filename;
}
//---------------------------------------------------------------------------
mops_api_007* Transdekra::GetTDApi()
{
   if(!td_stoimosti_api) td_stoimosti_api = (mops_api_007*)m_api->glDic_Get_API(res, "����������, ���������");
   return td_stoimosti_api;
}
//---------------------------------------------------------------------------
bool Transdekra::SetRSA_ID(const AnsiString& val)
{
   RSA_ID = val;
   if(!td_stoimosti_api) return false;

   return td_stoimosti_api->dbGetIntFromQuery(res, "select count(*) from td_531 where val([rsa_id])=" + RSA_ID);
}
//---------------------------------------------------------------------------
bool Transdekra::GetYearsList(TStringList *out)
{
   AnsiString st;
   if(!td_stoimosti_api) return false;

   int maxyear, minyear = YearOf(td_stoimosti_api->dbGetDateTimeFromQuery(res, "select min(CDate(car_prod_start)) from td_531 where val([rsa_id])=" + RSA_ID));
   if(minyear <= 1800) return false;

   if(td_stoimosti_api->dbGetIntFromQuery(res, "select count(car_prod_end) from td_531 where (isnull(car_prod_end) or car_prod_end='') and val([rsa_id])=" + RSA_ID) > 0)
      maxyear = YearOf(Date());
   else
      maxyear = YearOf(td_stoimosti_api->dbGetDateTimeFromQuery(res, "select max(CDate(car_prod_end)) from td_531 where val([rsa_id])=" + RSA_ID));

   out->Clear();
   while(maxyear >= minyear) out->Add(st.sprintf("%i", maxyear--));

   return true;
}
//---------------------------------------------------------------------------
bool Transdekra::GetPowerDelta(int &power_min, int &power_max)
{
   power_min = 0; power_max = INT_MAX;
   AnsiString st;

   if(!td_stoimosti_api) return false;

   power_min = td_stoimosti_api->dbGetIntFromQuery(res, "select min(CInt(car_engpwr)) from td_531 where val([rsa_id])=" + RSA_ID);
   if(power_min <= 0) return false;
   power_max = td_stoimosti_api->dbGetIntFromQuery(res, "select max(CInt(car_engpwr)) from td_531 where val([rsa_id])=" + RSA_ID);
   return true;
}
//---------------------------------------------------------------------------
AnsiString Transdekra::EngineDBToParam(const AnsiString& car_engine)
{
   AnsiString result("");
   AnsiString temp = FloatToSQLStr(car_engine);
   int curr, l = temp.Length();

   for(int i = 1; i <= l; ++i){
      if(TryStrToInt(temp[i], curr) || temp[i] == '.') result += AnsiString(temp[i]);
      else i = l;
   }

   return result;
}
//---------------------------------------------------------------------------
bool Transdekra::GetPriceDelta(const double& currency_val)
{
   COST[MIN]["USD"] = COST[MIN]["EUR"] = COST[MIN]["RUR"] = 0;
   COST[MAX]["USD"] = COST[MAX]["EUR"] = COST[MAX]["RUR"] = INT_MAX;
   if(!td_stoimosti_api || Region == "0" || GodVipuska.IsEmpty()) return false;

   AnsiString sql, param3;
   std::vector<CarParams> params;
   TADOQuery *q = td_stoimosti_api->dbGetCursor(res, sql.sprintf(main_sql.c_str(), Region.c_str(), IntToStr(RSA_ID.ToIntDef(0)).c_str(), GodVipuska.c_str(), Region.c_str(), Region.c_str()));
   CARS.clear();
   if(!q->IsEmpty()){
      COST[MIN]["RUR"] = q->Fields->Fields[6]->AsFloat * MIN_COST_K;
      for(q->First(); !q->Eof; q->Next()){
         param3 = EngineDBToParam(q->Fields->Fields[2]->AsString) + " (" + q->Fields->Fields[3]->AsString + " �.�.)";
         CarParams cp(q->Fields->Fields[0]->AsString, q->Fields->Fields[1]->AsString, param3, q->Fields->Fields[4]->AsString, q->Fields->Fields[5]->AsString);
         std::vector<CarParams>::iterator location = std::find(params.begin(), params.end(), cp);
         if(location != params.end())
            CARS[location->param1][location->param2][location->param3][location->param4][location->param5].cost.push_back(q->Fields->Fields[6]->AsFloat);
         else{
            CARS[q->Fields->Fields[0]->AsString][q->Fields->Fields[1]->AsString][param3][q->Fields->Fields[4]->AsString][q->Fields->Fields[5]->AsString] = CarInfo(q->Fields->Fields[7]->AsString, q->Fields->Fields[8]->AsString);
            CARS[q->Fields->Fields[0]->AsString][q->Fields->Fields[1]->AsString][param3][q->Fields->Fields[4]->AsString][q->Fields->Fields[5]->AsString].cost.push_back(q->Fields->Fields[6]->AsFloat);
         }
         params.push_back(cp);
      }
      COST[MAX]["RUR"] = q->Fields->Fields[6]->AsFloat * MAX_COST_K;
      RecalcDelta(currency_val);
   }
   td_stoimosti_api->dbCloseCursor(res, q);

   return COST[MIN]["RUR"] > 0;
}
//---------------------------------------------------------------------------
void Transdekra::RecalcDelta(const double& currency_val)
{
   COST[MIN]["USD"] = COST[MIN]["EUR"] = COST[MIN]["RUR"] / currency_val;
   if(COST[MAX]["RUR"] != INT_MAX) COST[MAX]["USD"] = COST[MAX]["EUR"] = COST[MAX]["RUR"] / currency_val;
}
//---------------------------------------------------------------------------
void Transdekra::GetCostAndPicture(const AnsiString* params, const double& currency_val, double* cost, AnsiString& filename, AnsiString& car_options)
{
   if(!td_stoimosti_api) return;

   CarInfo ci = CARS[params[0]][params[1]][params[2]][params[3]][params[4]];

   double result = ci.cost.size() ? (std::accumulate(ci.cost.begin(), ci.cost.end(), 0.0) / ci.cost.size()) : 0;

   cost[0] = td_stoimosti_api->Round(result / currency_val);
   std::vector<double>::iterator it_min = std::min_element(ci.cost.begin(), ci.cost.end()), it_max = std::max_element(ci.cost.begin(), ci.cost.end());
   if(it_min) cost[1] = (*it_min);
   if(it_max) cost[2] = (*it_max);

   COST[MIN]["RUR"] = (MIN_COST_K * result);
   COST[MAX]["RUR"] = (MAX_COST_K * result);
   RecalcDelta(currency_val);

   if(ci.cost.size() == 1){
      filename = Get_Picture_By_TD_ID(ci.td_id);

      if(ci.car_options.Length()){
         TADOQuery *q = td_stoimosti_api->dbGetCursor(res, "select [opt_name] from td_532 where [opt_id]='" + StringReplace(ci.car_options, ",", "' or [opt_id]='", TReplaceFlags() << rfReplaceAll) + "'");
         car_options = "�����:\r\n";
         for(q->First(); !q->Eof; q->Next())
            car_options += (q->FieldByName("opt_name")->AsString + ";   ");
         td_stoimosti_api->dbCloseCursor(res, q);
      }
   }
}
//---------------------------------------------------------------------------
bool Transdekra::GetListValues(TStringList *out, const AnsiString* params, const int index)
{
   switch(index){
      case 0:
         for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > > > >::iterator iter1 = CARS.begin(); iter1 != CARS.end(); ++iter1)
            out->Add(iter1->first);
         break;
      case 1:
         for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > > >::iterator iter2 = CARS[params[0]].begin(); iter2 != CARS[params[0]].end(); ++iter2)
            out->Add(iter2->first);
         break;
      case 2:
         for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > >::iterator iter3 = CARS[params[0]][params[1]].begin(); iter3 != CARS[params[0]][params[1]].end(); ++iter3)
            out->Add(iter3->first);
         break;
      case 3:
         for(std::map<AnsiString, std::map<AnsiString, CarInfo> >::iterator iter4 = CARS[params[0]][params[1]][params[2]].begin(); iter4 != CARS[params[0]][params[1]][params[2]].end(); ++iter4)
            out->Add(iter4->first);
         break;
      case 4:
         for(std::map<AnsiString, CarInfo>::iterator iter5 = CARS[params[0]][params[1]][params[2]][params[3]].begin(); iter5 != CARS[params[0]][params[1]][params[2]][params[3]].end(); ++iter5)
            out->Add(iter5->first);
         break;
   }

   return out->Count;
}
//---------------------------------------------------------------------------
void Transdekra::LoadParamsToTree(TTreeView *tree)
{
   for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > > > >::iterator iter1 = CARS.begin(); iter1 != CARS.end(); ++iter1){
      TTreeNode *nd_level_0 = tree->Items->AddChild(0, "��� ������ - " + iter1->first );
      for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > > >::iterator iter2 = CARS[iter1->first].begin(); iter2 != CARS[iter1->first].end(); ++iter2){
         TTreeNode *nd_level_1 = tree->Items->AddChild(nd_level_0, "���������� ������ - " + iter2->first);
         for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > >::iterator iter3 = CARS[iter1->first][iter2->first].begin(); iter3 != CARS[iter1->first][iter2->first].end(); ++iter3){
            TTreeNode *nd_level_2 = tree->Items->AddChild(nd_level_1, "��������� - " + iter3->first);
            for(std::map<AnsiString, std::map<AnsiString, CarInfo> >::iterator iter4 = CARS[iter1->first][iter2->first][iter3->first].begin(); iter4 != CARS[iter1->first][iter2->first][iter3->first].end(); ++iter4){
               TTreeNode *nd_level_3 = tree->Items->AddChild(nd_level_2, "��� ��� - " + iter4->first);
               for(std::map<AnsiString, CarInfo>::iterator iter5 = CARS[iter1->first][iter2->first][iter3->first][iter4->first].begin(); iter5 != CARS[iter1->first][iter2->first][iter3->first][iter4->first].end(); ++iter5)
                  tree->Items->AddChild(nd_level_3, "����������� - " + iter5->first);
            }
         }
      }
   }
}
//---------------------------------------------------------------------------
void Transdekra::LoadParamsToTreeList(TcxTreeList *treelist)
{
   for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > > > >::iterator iter1 = CARS.begin(); iter1 != CARS.end(); ++iter1){
      TcxTreeListNode *nd_level_0 = treelist->Add();
      nd_level_0->Values[0] = "��� ������ - " + iter1->first;
      for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > > >::iterator iter2 = CARS[iter1->first].begin(); iter2 != CARS[iter1->first].end(); ++iter2){
         TcxTreeListNode *nd_level_1 = nd_level_0->AddChild();
         nd_level_1->Values[0] = "���������� ������ - " + iter2->first;
         for(std::map<AnsiString, std::map<AnsiString, std::map<AnsiString, CarInfo> > >::iterator iter3 = CARS[iter1->first][iter2->first].begin(); iter3 != CARS[iter1->first][iter2->first].end(); ++iter3){
            TcxTreeListNode *nd_level_2 = nd_level_1->AddChild();
            nd_level_2->Values[0] = "��������� - " + iter3->first;
            for(std::map<AnsiString, std::map<AnsiString, CarInfo> >::iterator iter4 = CARS[iter1->first][iter2->first][iter3->first].begin(); iter4 != CARS[iter1->first][iter2->first][iter3->first].end(); ++iter4){
               TcxTreeListNode *nd_level_3 = nd_level_2->AddChild();
               nd_level_3->Values[0] = "��� ��� - " + iter4->first;
               for(std::map<AnsiString, CarInfo>::iterator iter5 = CARS[iter1->first][iter2->first][iter3->first][iter4->first].begin(); iter5 != CARS[iter1->first][iter2->first][iter3->first][iter4->first].end(); ++iter5){
                  TcxTreeListNode *nd_level_4 = nd_level_3->AddChild();
                  nd_level_4->Values[0] = "����������� - " + iter5->first;
                  CarInfo ci = iter5->second;
                  double cost = ci.cost.size() ? td_stoimosti_api->Round(std::accumulate(ci.cost.begin(), ci.cost.end(), 0.0) / ci.cost.size())  : 0;
                  nd_level_4->Data = (TObject*)(int)(cost * 100);
               }
            }
         }
      }
   }
}
//---------------------------------------------------------------------------


