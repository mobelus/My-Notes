//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <stdio.h> // ??????? ???????????? ?????-??????

#include "UReissCalc.h"

#include "KaskoProxyService.h"
#include "UThreadUFO.h"

#include "UThreadK5.h"
#include "anderrpanel.h"
#include "functions.h"
#include "constants.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma link "sBitBtn"
#pragma link "cxExtEditRepositoryItems"
#pragma link "cxTextEdit"
#pragma resource "*.dfm"
TFReissCalc *FReissCalc;

void log(AnsiString str)
{
	FILE* f = fopen("C:\\Users\\Public\\file.txt", "a+"); // ������� ����; "wt" - ������� ��� � ������ // t - ��������� ����
	//char* str = "�����-�� �����";
	//if(file1 != NULL) { fprintf(file1, "������ ������: %s\n", str); fclose(file1); }
    str = str + "\n";
    fputs(str.c_str() , f);
    fclose(f);
    Sleep(10);
}

//---------------------------------------------------------------------------
//__fastcall TFReissCalc::TFReissCalc(TComponent* Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di, TSInfo *p_tsi)
__fastcall TFReissCalc::TFReissCalc(TComponent* Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di, VehicleInfo *p_tsi /*TSInfo *p_tsi*/ )
: TFrame(Owner), m_api(_m_api), pi(p_pi), pm(p_pm), di(p_di), tsi(p_tsi),cur_autorization(0), is_autorization(0), is_ufo_req_success(0), error(new TStringList()), non_standart_str(new TStringList()),
memo_comm_sale_id(0), memo_comm_anderr_id(0), payment_count(1), memo(0), is_gap(false), is_pereautorization(0), m_curReason(REASON_EMPTY), curGridDopushindx(-1)
{
   //log("TFReissCalc");

   SetValueRowDateEdit(vg_dateStatement, di->statement_date);
   SetValueRowDateEdit(vg_dateChange, di->cancell_date);
   //statement_date_str = di->statement_date.DateString();
   
   XMLDoc = NewXMLDocument();
   XMLDoc->Active = true;
   XMLDoc->Options.Clear();
   XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;
   XMLDoc->Version    = "1.0";
   XMLDoc->Encoding   = "WINDOWS-1251";
   XMLDoc->StandAlone = "no";
                                           
   Root = XMLDoc->CreateNode("ROOT");
   XMLDoc->DocumentElement = Root;
   Root = XMLDoc->DocumentElement;
   Root->Attributes["Product_Name"] = AnsiString("�����");
   Root->Attributes["xml_version"] = AnsiString("0.0.2.0");
   Root->Attributes["system"] = AnsiString("3");

   q = m_api->dbGetCursor(res, "select * from cascoreissuereason order by id");
   for(Reason_CheckComboBox->Properties->Items->Clear(), q->First(); !q->Eof; q->Next()){
      TcxCheckComboBoxItem *item = Reason_CheckComboBox->Properties->Items->Add();
      item->Description = q->FieldByName("reason")->AsString;
      item->Tag = q->FieldByName("id")->AsInteger;
      reasons_surcharge[item->Tag] = Reason_Surcharge(q->FieldByName("surcharge_recalc")->AsInteger, q->FieldByName("surcharge_constant")->AsInteger);
   }
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select * from cascodoctype where deleted=0 order by id_doc_type");
   for(q->First(); !q->Eof; q->Next()) DocType_ComboBoxItem->Properties->Items->AddObject(q->FieldByName("doc_type")->AsString, (TObject*)q->FieldByName("id_doc_type")->AsInteger);
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select * from casco_vehdoctype order by [vehicle_registr_type_id]");
   for(q->First(); !q->Eof; q->Next()) VehicleDocType_ComboBoxItem->Properties->Items->AddObject(q->FieldByName("vehicle_registr_type_name")->AsString, (TObject*)q->FieldByName("vehicle_registr_type_id")->AsInteger);
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select veh_model_id from cascodictkss");
   for(q->First(); !q->Eof; q->Next()) models_for_gap.insert(q->FieldByName("veh_model_id")->AsInteger);
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select digit_country_code,full_name from mops_global_countries order by full_name");
   for(q->First(); !q->Eof; q->Next()){
      TcxCheckComboBoxItem *item = Country_CheckComboBox->Properties->Items->Add();
      item->Description = q->FieldByName("full_name")->AsString;
      item->Tag = q->FieldByName("digit_country_code")->AsInteger;
   }
   m_api->dbCloseCursor(res, q);

   /*q = m_api->dbGetCursor(res, sql.sprintf("select * from countries_periods where CDate('%s')>=start_date and CDate('%s')<=end_date order by period_id", statement_date_str, statement_date_str));
   for(q->First(); !q->Eof; q->Next()){
      DataDict *cp = new DataDict(q->FieldByName("period_id")->AsInteger, q->FieldByName("surcharge_value")->AsFloat, 0);
      Period_ComboBoxItem->Properties->Items->AddObject(q->FieldByName("period_name")->AsString.Trim(), cp);
   }
   m_api->dbCloseCursor(res, q);*/

   q_bl_persons = m_api->dbGetCursor(res, "select person_name,birthdate,region_id from gl_dict_black_list_persons");
   region_bl = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_black_list_regions where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));

   frmAddPermitted = new TfrmAddPermitted(this, m_api, pi, pm, di, tsi, q_bl_persons);

   frmADevices = new TfrmADevices(this, m_api, adevice);

   frmPayment = new TfrmPayment(this, di);

   for(int i = 20, cnt = vg->Rows->Count; i < cnt; ++i) vg->Rows->Items[i]->Visible = false;

   agreement_type_id_ss.insert(153);
   agreement_type_id_ss.insert(154);
   agreement_type_id_ss.insert(155);

   agreement_type_id_gap.insert(151);
   agreement_type_id_gap.insert(152);

   if(di->is_new_dogovor)
   {
      LoadData();
      Recalc();
   }
}
//------------------------------------------------------------------------------
__fastcall TFReissCalc::~TFReissCalc()
{
   //AnsiString sql("delete * from casco_devices_r");
   //m_api->dbExecuteQuery(res, sql);

   delete error;
   delete XMLDoc;
   delete q_bl_persons;
   delete non_standart_str;
   delete region_bl;
   delete frmADevices;
   delete frmAddPermitted;
   delete frmPayment;
}
//------------------------------------------------------------------------------
void TFReissCalc::LoadFrame(TADOQuery *q_load)
{
   AnsiString memo_text("");

   // ������������� ��������: calculation_id/contract_id
   di->calculation_id = q_load->FieldByName("calculation_id")->AsString;
   di->contract_id    = q_load->FieldByName("contract_id")->AsString;
      
   //di->no_calc = q_load->FieldByName("no_calc")->AsInteger;

   Load_Dogovors_k5_k6(m_api, q_load->FieldByName("t1.calc_id")->AsInteger, di, pi, pm);

   vg_cboxExtension->Properties->Value = q_load->FieldByName("extension_territory")->Value;

   di->cancell_date = q_load->FieldByName("date_rast")->AsDateTime;
   SetValueRowDateEdit(vg_dateChange, di->cancell_date);

   di->statement_date = q_load->FieldByName("date_zayavl")->AsDateTime;
   SetValueRowDateEdit(vg_dateStatement, di->statement_date);

   // ������ �������� ��� ��� �����, �������� ���-�� �������, �� ������������ ��� ���
   // ��������� ����, ��� �� ����������� ������� ��� ���, � �� �������� ������ �������
   // ������������ ���� ��� ������ �������� ��������, ��� ��� ��� ������ ��������� �������� �� ��
   //is_autorization = q_load->FieldByName("is_autorization")->AsInteger;
   // ������ ����� �� ����� �������� - ������� ����� �������� ��� �� ����������� �������
   // ���� ���, �� �� ������� ��� ������ �� ����, �� �� (��� ��� ������� ������������ ������)
   is_autorization = q_load->FieldByName("is_autorization")->AsInteger;

   is_pereautorization = is_autorization && (int)q_load->FieldByName("date_zayavl")->AsDateTime < (int)di->statement_date;

   di->datesrok_s  = q_load->FieldByName("srok_date_s")->AsDateTime;
   di->datesrok_po = q_load->FieldByName("srok_date_po")->AsDateTime;


   AnsiString s_ser1 = di->polis_seria;
   AnsiString s_ser2 = q_load->FieldByName("polis_seria")->AsString;


   vg_PolicySeries->Properties->Value = di->polis_seria = q_load->FieldByName("polis_seria")->AsString;
   vg_PolicyNumber->Properties->Value = di->polis_number = q_load->FieldByName("polis_number")->AsString;
   di->polis_date = q_load->FieldByName("polis_date")->AsDateTime;
   SetValueRowDateEdit(vg_Date, di->polis_date);

   memo_comm_sale_id   = q_load->FieldByName("comm_sale_mid")->AsInteger;
   memo_comm_anderr_id = q_load->FieldByName("comm_anderr_mid")->AsInteger;
   AnsiString memo_sale(""), memo_anderr("");
   m_api->dbReadWriteInternalMemo(res, memo_sale,   memo_comm_sale_id,   true, "casco_memo");
   m_api->dbReadWriteInternalMemo(res, memo_anderr, memo_comm_anderr_id, true, "casco_memo");
   commSale->Properties->Value = memo_sale;
   commAnderr->Properties->Value = memo_anderr;

   pi[0].status = q_load->FieldByName("status_idx")->AsInteger;
   pi[0].lastname = q_load->FieldByName("last_name")->AsString;
   vg_Name->Properties->Value = q_load->FieldByName("fio")->AsString;
   pi[0].doc_number = q_load->FieldByName("document_number")->AsString;
   pi[0].inn = q_load->FieldByName("inn")->AsString;

   vg_Address->Properties->Value = pi[0].address = q_load->FieldByName("address")->AsString;
   pi[0].memo_id = q_load->FieldByName("addr_mid")->AsInteger;
   
   if(pi[0].memo_id)
   {
	   m_api->dbReadWriteInternalMemo(res, memo_text, pi[0].memo_id, true, "casco_memo");
	   if(memo_text.IsEmpty()) m_api->dbReadWriteInternalMemo(res, memo_text, pi[0].memo_id, true, "kasko_memo");
	   pi[0].kladr_addr->Text = memo_text;
   }
   AnsiString strCodeKladr = pi[0].kladr_addr->Values["��� �����"];

   /*
   std::auto_ptr<TStringList> addr(new TStringList());
   tryToReadNode(node2, strCurrNodeName);

   addr->Values["��� �����"]		= strCodeKladr;
   addr->Values["������ ������"]	= strFilterKladr;
   addr->Values["�����������"]		= strCountry;
   addr->Values["������"]			= strRegion;
   addr->Values["�����"]			= strArea;
   addr->Values["�����"]			= strPlace;
   //addr->Values["�������"]			= strPlace;
   addr->Values["������"]			= strZip;
   addr->Values["�����"]			= strStreet;
   addr->Values["���"]				= strHouse;
   addr->Values["����� �������"]	= strBuilding;
   addr->Values["��������"]		= strFlat;

   int resCodeKladr = 0;
   KLADR_Try_Address_to_KLADR(resCodeKladr, addr);
   */
/////////////////////////////////////////////////////////////////////////////////////////////////

   vg_Phone->Properties->Value = pi[0].phone_mobil = q_load->FieldByName("phone_mobil")->AsString;

   di->status_dogovor = q_load->FieldByName("status_id")->AsInteger;

   currency = q_load->FieldByName("valuta")->AsString;

   //if(is_autorization){
   if(is_autorization){
      TDateTime q_dt = q_load->FieldByName("quotation_date")->AsDateTime;
      if(di->is_ander_login) SetValueRowDateEdit(f_andr_pan->vg_dateQT, q_dt);

      di->region_id = q_load->FieldByName("region_id")->AsInteger;
      di->REGION_TYPE = m_api->dbGetIntFromQuery(res, "select type_id from gl_dict_dsago_contract where cnt_cl_id=5 and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date and terr_id=" + IntToStr(di->region_id));

      vg_AutorizationInfo->Properties->Value = "������� ������ � ��� (�����������)";
      pi[0].doc_seria      = q_load->FieldByName("document_series")->AsString;
      pi[0].doc_issue_date = q_load->FieldByName("document_issue_date")->AsDateTime;
      pi[0].doc_issue_org  = q_load->FieldByName("document_issue_org")->AsString;

      is_gap = q_load->FieldByName("is_gap")->AsString == "��";

      TADOQuery *q_load_r = m_api->dbGetCursor(res, "select * from casco_calc_r where calc_id=" + q_load->FieldByName("t1.calc_id")->AsString);

      region_isp_id = q_load_r->FieldByName("region_isp_id")->AsInteger;

      ChangeMultiDrive();
      di->type_multydrive = q_load_r->FieldByName("multidrive")->AsInteger;
      FieldValueIDToVGEditor_(di->type_multydrive, MultyDrive_ComboBoxItem, vg_cboxMultyDrive);
      if(di->type_multydrive != 100) ResetGridPermitted();

      di->pay_id = q_load_r->FieldByName("pay_id")->Value;
      LoadVozmType();

      TADOQuery *q_krs = m_api->dbGetCursor(res, "select credit_name,coeff_value from cascodictk08 where id_krs=" + IntToStr(q_load->FieldByName("krs_idx")->AsInteger));
      vg_cboxCredit->Properties->Value = q_krs->FieldByName("credit_name")->AsString;
      //���
      di->calc_info.krs = q_krs->IsEmpty() ? 1.0 : q_krs->FieldByName("coeff_value")->AsFloat;
      m_api->dbCloseCursor(res, q_krs);

      di->calc_info.payment_part[0] = q_load_r->FieldByName("vznos1")->AsFloat;
      di->payment_date[0] = q_load_r->FieldByName("date_vznos1")->AsDateTime;
      vg_editPayment1->Properties->Value = "1-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[0]) + ", ���� - " + di->payment_date[0].DateString();

      di->calc_info.payment_part[1] = q_load_r->FieldByName("vznos2")->AsFloat;
      di->payment_date[1] = q_load_r->FieldByName("date_vznos2")->AsDateTime;
      if(di->calc_info.payment_part[1] > 0){
         payment_count = 2;
         vg_editPayment2->Properties->Value = "2-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[1]) + ", ���� - " + di->payment_date[1].DateString();
      }

      di->calc_info.payment_part[2] = q_load_r->FieldByName("vznos3")->AsFloat;
      di->payment_date[2] = q_load_r->FieldByName("date_vznos3")->AsDateTime;
      if(di->calc_info.payment_part[2] > 0){
         payment_count = 3;
         vg_editPayment3->Properties->Value = "3-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[2]) + ", ���� - " + di->payment_date[2].DateString();
      }

	  // TSInfo
	  tsi->devices_state_id = q_load_r->FieldByName("devices_state_id")->AsString.IsEmpty() ? 0 : q_load_r->FieldByName("devices_state_id")->AsInteger; // 0 - no devises / 2 - have devices

/*    tsi->ts_ident_type = q_load_r->FieldByName("ident_type")->AsInteger;
      vg_cboxIdentType->Properties->Value = IdentType_ComboBoxItem->Properties->Items->Strings[tsi->ts_ident_type];
      vg_editTSVIN->Properties->Value = tsi->ts_vin = q_load_r->FieldByName("ts_vin")->AsString;

      tsi->type_doc_ts = q_load_r->FieldByName("ts_doc_type")->AsInteger;
      FieldValueIDToVGEditor(tsi->type_doc_ts, VehicleDocType_ComboBoxItem, vg_cboxDocVehicle);
      vg_editVehicleDocSeries->Properties->Value = tsi->pts_series = q_load_r->FieldByName("pts_seria")->AsString;
      vg_editVehicleDocNumber->Properties->Value = tsi->pts_number = q_load_r->FieldByName("pts_number")->AsString;
      tsi->pts_date = q_load_r->FieldByName("pts_date")->AsDateTime;
      SetValueRowDateEdit(vg_editVehicleDocDate, tsi->pts_date);

      int index_reg_vehicle = q_load_r->FieldByName("is_registration_ts")->AsInteger;
      if(index_reg_vehicle != -1){
         vg_cboxRegistration->Properties->Value = RegVehicle_ComboBoxItem->Properties->Items->Strings[index_reg_vehicle];
         vg_editRegPlate->Properties->Value = tsi->ts_znak = q_load_r->FieldByName("ts_znak")->AsString;
      }
//*/
      //tsi->ts_ident_type = q_load_r->FieldByName("ident_type")->AsInteger;
      //vg_cboxIdentType->Properties->Value = IdentType_ComboBoxItem->Properties->Items->Strings[tsi->ts_ident_type];
      vg_editTSVIN->Properties->Value = tsi->vin = q_load_r->FieldByName("ts_vin")->AsString;

      tsi->vehicle_registration_type_id = q_load_r->FieldByName("ts_doc_type")->AsInteger;
      FieldValueIDToVGEditor(tsi->vehicle_registration_type_id, VehicleDocType_ComboBoxItem, vg_cboxDocVehicle);
      vg_editVehicleDocSeries->Properties->Value = tsi->registration_series = q_load_r->FieldByName("pts_seria")->AsString;
      vg_editVehicleDocNumber->Properties->Value = tsi->registration_number = q_load_r->FieldByName("pts_number")->AsString;
      tsi->registration_issue_date = q_load_r->FieldByName("pts_date")->AsDateTime;
      SetValueRowDateEdit(vg_editVehicleDocDate, tsi->registration_issue_date);

      int index_reg_vehicle = q_load_r->FieldByName("is_registration_ts")->AsInteger;
      if(index_reg_vehicle != -1){
         vg_cboxRegistration->Properties->Value = RegVehicle_ComboBoxItem->Properties->Items->Strings[index_reg_vehicle];
         vg_editRegPlate->Properties->Value = tsi->registration_mark = q_load_r->FieldByName("ts_znak")->AsString;
      }

      di->calc_info.str_summa1 = q_load_r->FieldByName("str_summa1")->AsFloat;
      di->calc_info.str_summa2 = q_load_r->FieldByName("str_summa2")->AsFloat;
      contract_payed_count = q_load_r->FieldByName("contract_payed_count")->AsInteger;
      di->calc_info.kgap = q_load_r->FieldByName("kgap")->AsFloat;
      di->calc_info.kdiscount = q_load_r->FieldByName("kdiscount")->AsFloat;
      di->calc_info.cost_vehicle_new = q_load_r->FieldByName("ts_cost")->AsFloat;


      m_api->dbCloseCursor(res, q_load_r);

      TADOQuery *q_load_ad = m_api->dbGetCursor(res, "select t1.*,t2.equip_name from casco_devices_r t1,type_equip t2 where t1.id_device=t2.equip_id and t1.calc_id=" + q_load->FieldByName("t1.calc_id")->AsString + " order by t1.number");
      for(q_load_ad->First(); !q_load_ad->Eof; q_load_ad->Next()){
         int index = q_load_ad->FieldByName("number")->AsInteger - 1;
         adevice[index].id = q_load_ad->FieldByName("id_device")->AsInteger;
         adevice[index].cost = q_load_ad->FieldByName("cost_device")->AsFloat;
         adevice[index].name_dict = q_load_ad->FieldByName("equip_name")->AsString;
         adevice[index].name_detail = q_load_ad->FieldByName("description")->AsString;
         TListItem *new_item = gridAD->Items->Add();
         new_item->Caption = q_load_ad->FieldByName("number")->AsString;
         new_item->SubItems->Add(Trim(adevice[index].name_dict + space_str + adevice[index].name_detail));
         new_item->SubItems->Add(FormatFloat(",0.00�'.';-,0.00�'.'", adevice[index].cost));
         new_item->Checked = true;
      }
      m_api->dbCloseCursor(res, q_load_ad);
      if(gridAD->Items->Count) gridAD->Height = 25 + (gridAD->Items->Count - 1) * 19;

      //
      AnsiString sql = "select * from casco_persons_r where calc_id=" + q_load->FieldByName("t1.calc_id")->AsString + " order by type_person";
      TADOQuery *q_load_persons = m_api->dbGetCursor(res, sql);
      for(q_load_persons->First(); !q_load_persons->Eof; q_load_persons->Next()){
         int index = q_load_persons->FieldByName("type_person")->AsInteger - 1;
         PersonInfo *pi_who = index < 2 ? pi : pm;
         if(q_load_persons->FieldByName("type_person")->AsInteger > 3) index -= 3;
         pi_who[index].status  = q_load_persons->FieldByName("status")->AsInteger;
         if(!pi_who[index].status) pi_who[index].lastname    = q_load_persons->FieldByName("last_name")->AsString;
         else                      pi_who[index].organization = q_load_persons->FieldByName("last_name")->AsString;
         pi_who[index].firstname  = q_load_persons->FieldByName("first_name")->AsString;
         pi_who[index].secondname = q_load_persons->FieldByName("second_name")->AsString;
         pi_who[index].inn        = q_load_persons->FieldByName("inn")->AsString;
         pi_who[index].ogrn       = q_load_persons->FieldByName("ogrn")->AsString;
         pi_who[index].birthdate  = q_load_persons->FieldByName("phisical_birth_date")->AsDateTime;
         pi_who[index].sex        = q_load_persons->FieldByName("phisical_sex")->AsInteger;
         pi_who[index].memo_id    = q_load_persons->FieldByName("addr_mid")->AsInteger;
         if(pi_who[index].memo_id){
            m_api->dbReadWriteInternalMemo(res, memo_text, pi_who[index].memo_id, true, "casco_memo");
            pi_who[index].kladr_addr->Text = memo_text;
         }
         pi_who[index].address  = q_load_persons->FieldByName("address")->AsString;
         pi_who[index].doc_type = q_load_persons->FieldByName("document_type_id")->AsInteger;
         pi_who[index].doc_seria  = q_load_persons->FieldByName("document_series")->AsString;
         pi_who[index].doc_number = q_load_persons->FieldByName("document_number")->AsString;
         pi_who[index].doc_issue_date = q_load_persons->FieldByName("document_issue_date")->AsDateTime;
         pi_who[index].doc_issue_org  = q_load_persons->FieldByName("document_issue_org")->AsString;
         pi_who[index].phone_mobil    = q_load_persons->FieldByName("phone_mobil")->AsString;
         pi_who[index].phone_home     = q_load_persons->FieldByName("phone_home")->AsString;
         pi_who[index].phone_work     = q_load_persons->FieldByName("phone_work")->AsString;
         pi_who[index].email          = q_load_persons->FieldByName("email")->AsString;
         pi_who[index].age            = q_load_persons->FieldByName("age")->AsInteger;
         pi_who[index].experience     = q_load_persons->FieldByName("experience")->AsInteger;
         pi_who[index].depart_sb      = q_load_persons->FieldByName("depart_sb")->AsString;
         pi_who[index].number_sb      = q_load_persons->FieldByName("number_sb")->AsString;
         pi_who[index].place_sb       = q_load_persons->FieldByName("place_sb")->AsString;
         pi_who[index].citizenship    = q_load_persons->FieldByName("citizenship")->AsString;
         pi_who[index].black_list     = q_load_persons->FieldByName("black_list")->AsInteger;
         pi_who[index].k6             = q_load_persons->FieldByName("k6")->AsFloat;
         pi_who[index].is_underwriting = q_load_persons->FieldByName("is_underwriting")->AsInteger;
         pi_who[index].rsa_id          = q_load_persons->FieldByName("rsa_id")->AsString;
      }
      int drv_count = GetDrvCount(q_load_persons);
      m_api->dbCloseCursor(res, q_load_persons);

      //�������� ������������,                    ���������  �� casco_persons_RRRRRRRRRR
      vg_editLastName->Properties->Value = !pi[0].status ? pi[0].lastname : pi[0].organization;
      vg_editFirstName->Properties->Value = pi[0].firstname;
      vg_editSecondName->Properties->Value = pi[0].secondname;
      SetValueRowDateEdit(vg_editBirthDate, pi[0].birthdate);
      vg_Name->Properties->Value = Trim(pi[0].lastname + pi[0].organization + space_str + pi[0].firstname + space_str + pi[0].secondname);
      vg_Document->Properties->Value = pi[0].status > 0 ? pi[0].inn : ("�����: " + pi[0].doc_seria + ", �����: " + pi[0].doc_number + ", �����: " + pi[0].doc_issue_org + space_str + pi[0].doc_issue_date.DateString());
      FieldValueIDToVGEditor(pi[0].doc_type, DocType_ComboBoxItem, vg_DocType);
      //ChangeMask(DocSeries_MaskItem, DocNumber_MaskItem, vg_editDocSeries, vg_editDocNumber, pi, 0, pi[0].doc_seria, pi[0].doc_number);
      vg_editDocSeries->Properties->Value = StringReplace(pi[0].doc_seria, space_str, empty_str, rf);
      vg_editDocNumber->Properties->Value = pi[0].doc_number;
      SetValueRowDateEdit(vg_editDocDate, pi[0].doc_issue_date);
      vg_editDocOrg->Properties->Value = pi[0].doc_issue_org;
      if(pi[0].memo_id){
         AnsiString memo_text("");
         m_api->dbReadWriteInternalMemo(res, memo_text, pi[0].memo_id, true, "casco_memo");
         pi[0].kladr_addr->Text = memo_text.IsEmpty() ? pi[0].address : memo_text;
      }
      vg_Address->Properties->Value = pi[0].address;
      vg_editAddress->Properties->Value = pi[0].address;
      vg_Phone->Properties->Value = pi[0].phone_mobil;

      //�������� ������������������           ��� ������, ��� � �����������
      vg_editBStatus->Properties->Value = BeneficStatus_ComboBoxItem->Properties->Items->Strings[pi[1].status];
      vg_editBLastName_or_Organization->Properties->Value = pi[1].status ? pi[1].organization : pi[1].lastname;
      vg_editBFirstName->Properties->Value = pi[1].firstname;
      vg_editBSecondName->Properties->Value = pi[1].secondname;

      //�������� ���������� ��������� �����
      for(int i = 0; i < drv_count; ++i)
	  {
         //K1(m_api, i, pm, di);
         TListItem *new_item = gridDopush->Items->Add();
         new_item->Caption = i + 1;
         new_item->Checked = true;
         if(pm[i].sex > 0) new_item->SubItems->Add((pm[i].sex == 1) ? "�" : "�");
         else              new_item->SubItems->Add(empty_str);
         new_item->SubItems->Add(pm[i].lastname + space_str + pm[i].firstname.SubString(1, 1) + dot + space_str + pm[i].secondname.SubString(1, 1) + dot);
         new_item->SubItems->Add(IntToStr(pm[i].age) + "/" + IntToStr(pm[i].experience));
         //K1(m_api, i, pm, di);
         //new_item->SubItems->Add(pm[i].k1);
		 new_item->SubItems->Add(AnsiString("-"));
		 //new_item->SubItems->Add(pm[i].k6);
		 new_item->SubItems->Add(AnsiString("-"));
		 
		 /*
         if(di->is_ander_login)
		 {
            TcxMultiEditorRow *multirow = dynamic_cast<TcxMultiEditorRow*>(f_andr_pan->FindComponent("vg_Permitted" + IntToStr(i + 1)));
            multirow->Visible = true;
            multirow->Properties->Editors->Items[0]->Value = new_item->SubItems->Strings[1] + ", K6 = " + FloatToStr(pm[i].k6);
            multirow->Properties->Editors->Items[1]->Value = "True";
         }
		 */
      }
      if(gridDopush->Items->Count) gridDopush->Height = 25 + (gridDopush->Items->Count - 1) * 19;


/*
      tsi->tstype_id = q_load->FieldByName("tstype_id")->AsInteger;
      tsi->ts_marka  = q_load->FieldByName("ts_marka")->AsString;
      tsi->ts_model  = q_load->FieldByName("ts_model")->AsString;
      tsi->model_id  = q_load->FieldByName("ts_model_id")->AsInteger;
      di->product_id = q_load->FieldByName("product_id")->AsInteger;
      di->risk = q_load->FieldByName("risk_id")->AsInteger;
      di->programm_id = q_load->FieldByName("programm_id")->AsInteger;
      di->project_id = q_load->FieldByName("project_id")->AsInteger;

      di->contract_type = q_load->FieldByName("prolong")->AsBoolean ? 1 : 0;
      tsi->group_ts = m_api->dbGetIntFromQuery(res, "select id_group from tar_gr where group_name='������ " + q_load->FieldByName("group_str")->AsString + "'");
//*/
      tsi->vehicle_type_id = q_load->FieldByName("tstype_id")->AsInteger;
      tsi->vehicle_brand_name  = q_load->FieldByName("ts_marka")->AsString;
      tsi->vehicle_model_name  = q_load->FieldByName("ts_model")->AsString;
      tsi->rsa_code  = q_load->FieldByName("ts_model_id")->AsInteger; // DIFFERENT
      di->product_id = q_load->FieldByName("product_id")->AsInteger;
      di->risk = q_load->FieldByName("risk_id")->AsInteger;
      di->programm_id = q_load->FieldByName("programm_id")->AsInteger;
      di->project_id = q_load->FieldByName("project_id")->AsInteger;

      di->contract_type = q_load->FieldByName("prolong")->AsBoolean ? 1 : 0;
      tsi->vehicle_group = m_api->dbGetIntFromQuery(res, "select id_group from tar_gr where group_name='������ " + q_load->FieldByName("group_str")->AsString + "'");

      di->calc_info.paid = q_load->FieldByName("claim_damages_sum")->AsFloat;
      di->calc_info.premiya_osn_risk = q_load->FieldByName("premium_main_risk")->AsFloat;
      di->count_accidents = q_load->FieldByName("prev_ubitki_idx")->AsInteger;
      di->calc_info.str_summa = q_load->FieldByName("str_summa")->AsFloat;
      di->calc_info.old_str_summa = q_load->FieldByName("old_str_summa")->AsFloat;
      di->calc_info.old_premium = q_load->FieldByName("old_premium_main_risk")->AsFloat;
      di->calc_info.old_premium_paid = q_load->FieldByName("old_premium_paid")->AsFloat;
      di->old_programm_id = q_load->FieldByName("old_programm_id")->AsFloat;
      di->calc_info.claims_damages = (di->count_accidents == 1 && di->calc_info.old_premium) ? m_api->Round(di->calc_info.paid * 100 / di->calc_info.old_premium) : 0.0;
      pay_id_arm = q_load->FieldByName("pay_id")->AsInteger;
      di->calc_info.cost_vehicle = q_load->FieldByName("ts_cost")->AsFloat;

      LoadData();
//* // OLD TOOLS.H // Dogovor_Info
//      di->no_calc_k5 = q_load->FieldByName("calc_k5_k6")->AsInteger;
//*/
	  di->no_calc = q_load->FieldByName("no_calc")->AsInteger;
      di->calc_info.bt = q_load->FieldByName("bt")->AsFloat;
      di->calc_info.k1 = q_load->FieldByName("k1")->AsFloat;
      di->calc_info.k4 = q_load->FieldByName("k4")->AsFloat;
      di->calc_info.k5 = q_load->FieldByName("k5")->AsFloat;
      di->calc_info.k6 = q_load->FieldByName("k6_final")->AsFloat;
      di->calc_info.kr = q_load->FieldByName("kr")->AsFloat;
      di->calc_info.kar = q_load->FieldByName("kar")->AsFloat;
      di->calc_info.kpr = q_load->FieldByName("kpr")->AsFloat;
      di->calc_info.kb = q_load->FieldByName("kb")->AsFloat;
      di->calc_info.ka = q_load->FieldByName("ka")->AsFloat;
      di->calc_info.ks = q_load->FieldByName("ks")->AsFloat;
      di->calc_info.coef_prop = q_load->FieldByName("coeff_prop")->AsFloat;

      //K3
      di->monthcount = q_load->FieldByName("srok_month")->AsInteger;
      di->calc_info.k3 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk03 where srok_min<=%i and srok_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->monthcount, di->monthcount, di->calc_date, di->calc_date), 1.0);

      // �7-�
/* // TSInfo
      tsi->ts_age = q_load->FieldByName("ts_novoe")->AsBoolean ? 0 : YearOf(q_dt) - q_load->FieldByName("ts_year")->AsInteger;
      di->calc_info.k7 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->pay_id, di->REGION_TYPE, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date), 1.0);
*/
      tsi->vehicle_age = q_load->FieldByName("ts_novoe")->AsBoolean ? 0 : YearOf(q_dt) - q_load->FieldByName("ts_year")->AsInteger;
      di->calc_info.k7 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->pay_id, di->REGION_TYPE, tsi->vehicle_age, tsi->vehicle_age, di->calc_date, di->calc_date), 1.0);

      //kfr
      if(q_load->FieldByName("full_insur")->AsInteger == 3 &&  di->calc_info.coef_prop <= 0.79) di->calc_info.kfr = GetKprSb(di->calc_info.coef_prop);
      else di->calc_info.kfr = 1.0;



      if(!di->is_ander_login && (di->status_dogovor == 10 || di->status_dogovor == 15)) Enabled = false;
   }
   else vg_Document->Properties->Value = pi[0].status > 0 ? pi[0].inn : pi[0].doc_number;

   LoadKssData();

   TADOQuery *q_reasons = m_api->dbGetCursor(res, "select * from casco_reiss_reasons where calc_id=" + q_load->FieldByName("t1.calc_id")->AsString);
   is_surcharge_recalc = is_surcharge_constant = false;
   for(int i = 0, cnt = Reason_CheckComboBox->Properties->Items->Count; i < cnt; ++i){
      TcxCheckComboBoxItem *item = Reason_CheckComboBox->Properties->Items->Items[i];
      if(q_reasons->Locate("reason_id", item->Tag, locate)){
         last_reasons += (IntToStr(item->Description.Length()) + ":" + item->Description);
         reasons_surcharge[item->Tag].select = 1;
         if(is_autorization) SetVisible_VG_Items(item->Tag);
         if(reasons_surcharge[item->Tag].surcharge_recalc) is_surcharge_recalc = true;
         if(reasons_surcharge[item->Tag].surcharge_constant) is_surcharge_constant = true;
      }
   }
   m_api->dbCloseCursor(res, q_reasons);
   if(!last_reasons.IsEmpty()) vg_Reason->Properties->Value = ";" + last_reasons;

   Recalc();

   if(di->is_ander_login){
      f_andr_pan->vg_paRegion->Properties->Value = m_api->dbGetStringFromQuery(res, "select terr_name from gl_dict_regions where terr_id=" + IntToStr(q_load->FieldByName("region_id")->AsInteger));
      f_andr_pan->vg_paSaleChannel->Properties->Value = q_load->FieldByName("sale_channel")->AsString;
      f_andr_pan->vg_paDogovor->Properties->Value  = AnsiString(di->contract_type ? "��������������" : "��������������") + " ������� (��������������)";
// !!!!!!!!
      //f_andr_pan->vg_paVariant->Properties->Value  = "������� \"" + variant[q_load->FieldByName("variant_idx")->AsInteger] + "\"";
      f_andr_pan->vg_paVariant->Properties->Value  = "������� \"" + variant[q_load->FieldByName("variant_idx")->AsInteger] + "\"";

/*// TSInfo
      f_andr_pan->vg_paVehicle1->Properties->Value =
      q_load->FieldByName("ts_marka")->AsString + space_str + q_load->FieldByName("ts_model")->AsString + ", " + q_load->FieldByName("ts_year")->AsString + (q_load->FieldByName("ts_novoe")->AsBoolean
      ? AnsiString(" �., ����� �� c �������� ����� 1000 ��") : ts_age_str[tsi->ts_age]);

      f_andr_pan->vg_paVehicle2->Properties->Value = m_api->dbGetStringFromQuery(res, "select categories from ts_type where val(code)=" + IntToStr(tsi->tstype_id)) + ", ������ " + q_load->FieldByName("group_str")->AsString;
//*/
      f_andr_pan->vg_paVehicle1->Properties->Value =
      q_load->FieldByName("ts_marka")->AsString + space_str + q_load->FieldByName("ts_model")->AsString + ", " + q_load->FieldByName("ts_year")->AsString + (q_load->FieldByName("ts_novoe")->AsBoolean
      ? AnsiString(" �., ����� �� c �������� ����� 1000 ��") : ts_age_str[tsi->vehicle_age]);

      f_andr_pan->vg_paVehicle2->Properties->Value = m_api->dbGetStringFromQuery(res, "select categories from ts_type where val(code)=" + IntToStr(tsi->vehicle_type_id)) + ", ������ " + q_load->FieldByName("group_str")->AsString;

      f_andr_pan->vg_paVehicleCost->Properties->Value = di->calc_info.cost_vehicle;
      f_andr_pan->vg_paVehicleCost->Properties->Options->Editing = false;
      f_andr_pan->vg_paVehicleStrSumma->Properties->Options->Editing = false;
      f_andr_pan->vg_paVehicleStrSumma->Properties->Value = di->calc_info.str_summa;
      /*f_andr_pan->vg_paPUS->Height = 22 * (memoProtivougonki->EditText.Length() / 70 + 1);
      f_andr_pan->vg_paPUS->Properties->Value = memoProtivougonki->EditText;
      int ind = rgPUS->Items->IndexOf(rgPUS->EditText);
      if(ind > -1){
         AnsiString pus_info = rgPUS->EditText + (ind == 3 ? ", � ������ " + editProtivougon->EditText : empty_str);
         f_andr_pan->vg_paPUSInfo->Height = 22 * (pus_info.Length() / 70 + 1);
         f_andr_pan->vg_paPUSInfo->Properties->Value = pus_info;
      } */
      f_andr_pan->vg_CalcSummaryInfoHead->Properties->Caption = f_andr_pan->vg_CalcSummaryInfoHead->Properties->Caption + (di->risk == 2 ? "�����" : "�����") + "\"";
      f_andr_pan->vg_paBaseTariff->Properties->Value = di->calc_info.bt;
      f_andr_pan->vg_paK1->Properties->Value = coeff_base.count(1) ? FloatToStr(di->calc_info.k1)  : dot_line;
      f_andr_pan->vg_paKd->Properties->Value = coeff_base.count(28) ? FloatToStr(di->calc_info.kd) : dot_line;
      f_andr_pan->vg_paK2->Properties->Value = coeff_base.count(2)  ? FloatToStr(di->calc_info.k2) : dot_line;
      f_andr_pan->vg_paK3->Properties->Value = coeff_base.count(3) ? FloatToStr(di->calc_info.k3)  : dot_line;
      f_andr_pan->vg_paK4->Properties->RepositoryItem = f_andr_pan->TextItem;
      f_andr_pan->vg_paK4->Properties->Options->Editing = false;
      f_andr_pan->vg_paK4->Properties->Value = coeff_base.count(4) ? FloatToStr(di->calc_info.k4)  : dot_line;
      // ������� K5 K6
      f_andr_pan->vg_paK5->Properties->Value = pi[0].lastname + space_str + pi[0].firstname.SubString(1, 1) + dot + space_str + pi[0].secondname.SubString(1, 1) + dot + ", K5 = " + FloatToStr(di->calc_info.k5);
      f_andr_pan->vg_paK6->Properties->Value = di->calc_info.k6;
      if(di->type_multydrive > -1 && di->type_multydrive != 100){
         f_andr_pan->vg_Permitted1->Properties->Editors->Items[0]->Caption = "������������";
         f_andr_pan->vg_Permitted1->Properties->Editors->Items[0]->Value = pi[0].lastname + space_str + pi[0].firstname.SubString(1, 1) + dot + space_str + pi[0].secondname.SubString(1, 1) + dot + ", K6 = " + FloatToStr(di->calc_info.k6);
         f_andr_pan->vg_Permitted1->Properties->Editors->Items[1]->Value = "True";
         f_andr_pan->vg_Permitted1->Properties->Editors->Items[1]->Options->Editing = false;
      }
      f_andr_pan->vg_paK7A->Properties->RepositoryItem = f_andr_pan->TextItem;
      f_andr_pan->vg_paK7A->Properties->Options->Editing = false;
      f_andr_pan->vg_paK7A->Properties->Value = di->calc_info.k7;
      f_andr_pan->vg_paKp->Properties->Value = di->calc_info.kr;
      f_andr_pan->vg_paKc->Properties->RepositoryItem = f_andr_pan->TextItem;
      f_andr_pan->vg_paKc->Properties->Options->Editing = false;
      f_andr_pan->vg_paKc->Properties->Value = di->calc_info.ks;
      f_andr_pan->vg_paKap->Properties->Value = di->calc_info.kar;
      f_andr_pan->vg_paKpc->Properties->Value = di->calc_info.krs;
      f_andr_pan->vg_paKpr->Properties->Value = di->calc_info.kpr;
      f_andr_pan->vg_paKa->Properties->RepositoryItem = f_andr_pan->TextItem;
      f_andr_pan->vg_paKa->Properties->Options->Editing = false;
      f_andr_pan->vg_paKa->Properties->Value = di->calc_info.ka;
      
      if(q_load->FieldByName("bank_id")->AsInteger){
         f_andr_pan->vg_paKb->Properties->Value = FloatToStr(di->calc_info.kb) + " (���� " + m_api->dbGetStringFromQuery(res, "select bank_name from gl_dict_banks where bank_id=" + IntToStr(q_load->FieldByName("bank_id")->AsInteger)) + ")";
         if(q_load->FieldByName("full_insur")->AsInteger == 3) f_andr_pan->vg_paKfr->Properties->Value = FloatToStr(di->calc_info.kfr);
      }

      if(q_load->FieldByName("select_dsago")->AsBoolean || q_load->FieldByName("select_ns")->AsBoolean || q_load->FieldByName("select_dms")->AsBoolean){
         f_andr_pan->vg_DopRisk->Visible = true;

         if(q_load->FieldByName("select_dsago")->AsBoolean){
            f_andr_pan->vg_DopRisk->Height += 16;
            f_andr_pan->vg_DopRisk->Properties->Caption = f_andr_pan->vg_DopRisk->Properties->Caption + "\r\n�����: ��������� ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", q_load->FieldByName("dsago_summa")->AsFloat) + ", ������ - " + FormatFloat(",0.00�'.';-,0.00�'.'", q_load->FieldByName("premium_dsago")->AsFloat);
         }
         if(q_load->FieldByName("select_ns")->AsBoolean){
            f_andr_pan->vg_DopRisk->Height += 16;
            f_andr_pan->vg_DopRisk->Properties->Caption = f_andr_pan->vg_DopRisk->Properties->Caption + "\r\n��: ��������� ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", q->FieldByName("ns_summa")->AsFloat) + ", ������ - " + FormatFloat(",0.00�'.';-,0.00�'.'", q->FieldByName("premium_ns")->AsFloat);
         }
         if(q_load->FieldByName("select_dms")->AsBoolean){
            f_andr_pan->vg_DopRisk->Height += 16;
            f_andr_pan->vg_DopRisk->Properties->Caption = f_andr_pan->vg_DopRisk->Properties->Caption + "\r\n���������� ������������ ������: ��������� ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.str_summa_dms) + ", ������ - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.premiya_dms);
         }
      }

      f_andr_pan->vg_paCommSale->Properties->Value   = memo_sale;
      f_andr_pan->vg_paCommAnderr->Properties->Value = memo_anderr;
   }
}
//------------------------------------------------------------------------------
void TFReissCalc::SaveFrame(TADOQuery *q_save)
{

   // ������������� ��������: calculation_id/contract_id
   q_save->FieldByName("calculation_id")->Value = di->calculation_id;
   q_save->FieldByName("contract_id")->Value = di->contract_id;

	// ���������� ������� ��������
   if(di->is_ander_login){
      if(f_andr_pan->vg_rgAgreed->Visible && !f_andr_pan->vg_rgAgreed->Properties->Value.IsNull()){
         switch(f_andr_pan->RadioGroupItem->Properties->GetRadioGroupItemIndex(f_andr_pan->vg_rgAgreed->Properties->Value)){
            case 0: di->status_dogovor = 15; break;
            case 1: di->status_dogovor = 3; break;
         }
         m_api->Raschet_Set_Status_id(res, q_save->FieldByName("calc_id")->AsInteger, di->status_dogovor);
      }
      else m_api->Raschet_Set_Status_id(res, q_save->FieldByName("calc_id")->AsInteger, 0);

      if(!f_andr_pan->vg_paCommSale->Properties->Value.IsNull())     m_api->dbReadWriteInternalMemo(res, f_andr_pan->vg_paCommSale->Properties->Value,     memo_comm_sale_id,    false, "casco_memo");
      if(!f_andr_pan->vg_paCommAnderr->Properties->Value.IsNull())   m_api->dbReadWriteInternalMemo(res, f_andr_pan->vg_paCommAnderr->Properties->Value,   memo_comm_anderr_id,  false, "casco_memo");
      //if(!f_andr_pan->vg_paAnderrChange->Properties->Value.IsNull()) m_api->dbReadWriteInternalMemo(res, f_andr_pan->vg_paAnderrChange->Properties->Value, memo_anderrchange_id, false, "casco_memo");
   }
   else{
      /*if(di->status_dogovor == 14 || di->status_dogovor == 13 || di->status_dogovor == 3) */m_api->Raschet_Set_Status_id(res, q_save->FieldByName("calc_id")->AsInteger, di->status_dogovor);
      if(!commSale->Properties->Value.IsNull())   m_api->dbReadWriteInternalMemo(res, commSale->Properties->Value,   memo_comm_sale_id,   false, "casco_memo");
      if(!commAnderr->Properties->Value.IsNull()) m_api->dbReadWriteInternalMemo(res, commAnderr->Properties->Value, memo_comm_anderr_id, false, "casco_memo");
   }

   q_save->FieldByName("dogovor_type")->Value = 4;
   q_save->FieldByName("extension_territory")->Value = vg_cboxExtension->Properties->Value;
   if(!is_pereautorization) q_save->FieldByName("date_zayavl")->Value = di->statement_date;
   q_save->FieldByName("date_rast")->Value = di->cancell_date;
   q_save->FieldByName("is_gap")->Value = is_gap ? AnsiString("��") : empty_str;

   m_api->dbExecuteQuery(res, "delete * from casco_reiss_reasons where calc_id=" + q_save->FieldByName("calc_id")->AsString);
   TADOQuery *q_reasons = m_api->dbGetCursor(res, "select * from casco_reiss_reasons where calc_id=" + q_save->FieldByName("calc_id")->AsString, 0, 1);
   for(int i = 0, cnt = Reason_CheckComboBox->Properties->Items->Count; i < cnt; ++i){
      TcxCheckComboBoxItem *item = Reason_CheckComboBox->Properties->Items->Items[i];
      if(reasons_surcharge[item->Tag].select){
         q_reasons->Insert();
         q_reasons->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->Value;
         q_reasons->FieldByName("reason_id")->Value = item->Tag;
      }
   }
   q_reasons->UpdateBatch();
   m_api->dbCloseCursor(res, q_reasons);


   AnsiString s_ser = di->polis_seria;
   AnsiString s_num = di->polis_number;

   q_save->FieldByName("polis_seria")->Value = di->polis_seria;
   q_save->FieldByName("polis_number")->Value = di->polis_number;
   q_save->FieldByName("polis_date")->Value = di->polis_date;
   q_save->FieldByName("is_autorization")->Value = is_autorization;
   //q_save->FieldByName("is_autorization")->Value = was_autorization;
   q_save->FieldByName("comm_sale_mid")->Value = memo_comm_sale_id;
   q_save->FieldByName("comm_anderr_mid")->Value = memo_comm_anderr_id;
   q_save->FieldByName("claim_damages_sum")->Value =  di->calc_info.paid;
   q_save->FieldByName("prev_ubitki_idx")->Value = di->count_accidents;
   q_save->FieldByName("old_str_summa")->Value = di->calc_info.old_str_summa;
   q_save->FieldByName("old_premium_main_risk")->Value = di->calc_info.old_premium;
   q_save->FieldByName("old_premium_paid")->Value = di->calc_info.old_premium_paid;
   q_save->FieldByName("old_programm_id")->Value = di->old_programm_id;
   q_save->FieldByName("bt")->Value = di->calc_info.bt;
   q_save->FieldByName("k1")->Value = di->calc_info.k1;
   q_save->FieldByName("k4")->Value = di->calc_info.k4;
   q_save->FieldByName("k5")->Value = di->calc_info.k5;
   q_save->FieldByName("k6_final")->Value = di->calc_info.k6;
   q_save->FieldByName("kr")->Value = di->calc_info.kr;
   q_save->FieldByName("kar")->Value = di->calc_info.kar;
   q_save->FieldByName("kb")->Value = di->calc_info.kb;
   q_save->FieldByName("coeff_prop")->Value = di->calc_info.coef_prop;
//* // OLD TOOLS.H   DogovorInfo
   //q_save->FieldByName("calc_k5_k6")->Value =  di->no_calc_k5;
//*/
   q_save->FieldByName("no_calc")->Value =  di->no_calc;

   q_save->FieldByName("valuta")->Value = currency;
   q_save->FieldByName("product_id")->Value = di->product_id;

   if(!is_autorization)
   {
      q_save->FieldByName("fio")->Value = pi[0].lastname;

      TADOQuery *q_p = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + q_save->FieldByName("calc_id")->AsString + " and type_person=1 order by type_person", 0, 1);
      AnsiString memo_text = pi[0].kladr_addr->Text;
      //AnsiString memo_text = pi[0].kladr_addr->Text.IsEmpty() ? pi[0].address : pi[0].kladr_addr->Text;

      if(memo_text.IsEmpty())
      {
        if(CheckAddrList(pi[0].kladr_addr))
        m_api->dbReadWriteInternalMemo(res, memo_text, pi[0].memo_id, false, "kasko_memo");
      }
      else
      {
        if(CheckAddrList(pi[0].kladr_addr))
        m_api->dbReadWriteInternalMemo(res, memo_text, pi[0].memo_id, false, "casco_memo");
      }

      AnsiString strCodeKladr = pi[0].kladr_addr->Values["��� �����"];


      //if(CheckAddrList(pi[0].kladr_addr)) m_api->dbReadWriteInternalMemo(res, memo_text, pi[0].memo_id, false, "casco_memo");
      if(q_p->IsEmpty()) q_p->Insert();
      else q_p->Edit();
      q_p->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->AsInteger;
      q_p->FieldByName("status")->Value = 0;
      q_p->FieldByName("type_person")->Value = 1;
      q_p->FieldByName("last_name")->Value = pi[0].lastname;
      q_p->FieldByName("addr_mid")->Value = pi[0].memo_id;
      q_p->FieldByName("address")->Value = pi[0].address;
      q_p->FieldByName("document_number")->Value = pi[0].doc_number;
      q_p->FieldByName("phone_mobil")->Value = pi[0].phone_mobil;
      q_p->UpdateBatch();
      m_api->dbCloseCursor(res, q_p);
   }
   else
   {
      TADOQuery *q_save_r = m_api->dbGetCursor(res, "select * from casco_calc_r where calc_id=" + q_save->FieldByName("calc_id")->AsString, 0, 0);
      q_save_r->CursorLocation = clUseServer;
      q_save_r->Open();

      if(q_save_r->IsEmpty()) q_save_r->Insert();
      else                    q_save_r->Edit();

      q_save_r->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->Value;
      q_save_r->FieldByName("region_isp_id")->Value = region_isp_id;
      q_save_r->FieldByName("bez_ogr")->Value = di->type_multydrive > -1 && di->type_multydrive < 100;
      q_save_r->FieldByName("multidrive")->Value = di->type_multydrive;
      q_save_r->FieldByName("pay_id")->Value = di->pay_id;
      /*if(vg_cboxCredit->Properties->Value.IsNull())*/
      q_save_r->FieldByName("krs_idx")->Value = q_save->FieldByName("krs_idx")->Value;
      //else q_save_r->FieldByName("krs_idx")->Value = ((DataDict*)Credit_ComboBoxItem->Properties->Items->Objects[Credit_ComboBoxItem->Properties->Items->IndexOf(vg_cboxCredit->Properties->Value)])->id;
      q_save_r->FieldByName("vznos1")->Value = di->calc_info.payment_part[0];
      q_save_r->FieldByName("vznos2")->Value = di->calc_info.payment_part[1];
      q_save_r->FieldByName("vznos3")->Value = di->calc_info.payment_part[2];
      q_save_r->FieldByName("date_vznos1")->Value = di->payment_date[0];
      q_save_r->FieldByName("date_vznos2")->Value = di->payment_date[1];
      q_save_r->FieldByName("date_vznos3")->Value = di->payment_date[2];


	  // TSInfo
      q_save_r->FieldByName("devices_state_id")->Value = tsi->devices_state_id;
/*
      q_save_r->FieldByName("ident_type")->Value = tsi->ts_ident_type;
      q_save_r->FieldByName("ts_vin")->Value = tsi->ts_vin;
      q_save_r->FieldByName("ts_doc_type")->Value = tsi->type_doc_ts;
      q_save_r->FieldByName("pts_seria")->Value = tsi->pts_series;
      q_save_r->FieldByName("pts_number")->Value = tsi->pts_number;
      q_save_r->FieldByName("pts_date")->Value = tsi->pts_date;
      q_save_r->FieldByName("is_registration_ts")->Value = vg_cboxRegistration->Properties->Value.IsNull() ? -1 : RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value);
      q_save_r->FieldByName("ts_znak")->Value = tsi->ts_znak;
//*/
      // VehicleInfo
      //q_save_r->FieldByName("ident_type")->Value = tsi->ts_ident_type;
//log("SF_18");
      q_save_r->FieldByName("ts_vin")->Value = tsi->vin;
      q_save_r->FieldByName("ts_doc_type")->Value = tsi->vehicle_registration_type_id;
      q_save_r->FieldByName("pts_seria")->Value = tsi->registration_series;
      q_save_r->FieldByName("pts_number")->Value = tsi->registration_number;
      q_save_r->FieldByName("pts_date")->Value = tsi->registration_issue_date;
      q_save_r->FieldByName("is_registration_ts")->Value = vg_cboxRegistration->Properties->Value.IsNull() ? -1 : RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value);
      q_save_r->FieldByName("ts_znak")->Value = tsi->registration_mark;

      q_save_r->FieldByName("surcharge_value")->Value = surcharge_value;
      q_save_r->FieldByName("surcharge_value_ss")->Value = surcharge_value_ss;
      q_save_r->FieldByName("surcharge_value_gp")->Value = surcharge_value_gp;
      q_save_r->FieldByName("surcharge_value_gap_ss")->Value = surcharge_value_gap_ss;
      q_save_r->FieldByName("ts_cost")->Value = di->calc_info.cost_vehicle_new;
      q_save_r->FieldByName("str_summa")->Value = di->calc_info.str_summa;
      q_save_r->FieldByName("str_summa1")->Value = di->calc_info.str_summa1;
      q_save_r->FieldByName("str_summa2")->Value = di->calc_info.str_summa2;
      q_save_r->FieldByName("contract_payed_count")->Value = contract_payed_count;
      q_save_r->FieldByName("kgap")->Value = di->calc_info.kgap;
      q_save_r->FieldByName("kdiscount")->Value = di->calc_info.kdiscount;
      q_save_r->FieldByName("dopnumber")->Value = (int)di->polis_date < TDateTime(2014, 10, 1) ? "ds_old" : "ds_new";

      q_save_r->Post();
      m_api->dbCloseCursor(res, q_save_r);

      //������������, �������������������
      TADOQuery *q_p_r = m_api->dbGetCursor(res, "select * from casco_persons_r where calc_id=" + q_save->FieldByName("calc_id")->AsString + " and type_person in(1,2) order by type_person", 0, 1), *q_orig_perm = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + q_save->FieldByName("calc_id")->AsString + " and type_person > 2 order by type_person");;
      for(int i = 0, rc = q_p_r->RecordCount; i < 2; ++i)
	  {
         AnsiString memo_text = pi[i].kladr_addr->Text;
         if(CheckAddrList(pi[i].kladr_addr)) m_api->dbReadWriteInternalMemo(res, memo_text, pi[i].memo_id, false, "casco_memo");
         if(!rc) q_p_r->Insert();
         else q_p_r->Edit();
         q_p_r->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->AsInteger;
         q_p_r->FieldByName("status")->Value = pi[i].status;
         q_p_r->FieldByName("type_person")->Value = i + 1;
         q_p_r->FieldByName("first_name")->Value = pi[i].firstname;
         q_p_r->FieldByName("second_name")->Value = pi[i].secondname;
         q_p_r->FieldByName("last_name")->Value = !pi[i].status ? pi[i].lastname : pi[i].organization;
         q_p_r->FieldByName("inn")->Value = pi[i].inn;
         q_p_r->FieldByName("ogrn")->Value = pi[i].ogrn;
         q_p_r->FieldByName("phisical_birth_date")->Value = pi[i].birthdate;
         q_p_r->FieldByName("phisical_sex")->Value = pi[i].sex;
         q_p_r->FieldByName("addr_mid")->Value = pi[i].memo_id;
         q_p_r->FieldByName("address")->Value = pi[i].address;
         q_p_r->FieldByName("document_type_id")->Value = pi[i].doc_type;
         q_p_r->FieldByName("document_series")->Value = pi[i].doc_seria;
         q_p_r->FieldByName("document_number")->Value = pi[i].doc_number;
         q_p_r->FieldByName("document_issue_date")->Value = pi[i].doc_issue_date;
         q_p_r->FieldByName("document_issue_org")->Value = pi[i].doc_issue_org;
         q_p_r->FieldByName("phone_mobil")->Value = pi[i].phone_mobil;
         q_p_r->FieldByName("black_list")->Value = pi[i].black_list;
         q_p_r->FieldByName("citizenship")->Value = pi[i].citizenship;
         q_p_r->FieldByName("k6")->Value = pi[i].k6;
         q_p_r->FieldByName("is_underwriting")->Value = pi[i].is_underwriting;
         q_p_r->FieldByName("rsa_id")->Value = pi[i].rsa_id;
         if(rc) q_p_r->Next();

	  }
      q_p_r->UpdateBatch();
      m_api->dbCloseCursor(res, q_p_r);

	  //����������
      m_api->dbExecuteQuery(res, "delete * from casco_persons_r where calc_id=" + q_save->FieldByName("calc_id")->AsString + " and type_person > 2");
      q_p_r = m_api->dbGetCursor(res, "select * from casco_persons_r where calc_id=" + q_save->FieldByName("calc_id")->AsString + " and type_person > 2 order by type_person", 0, 1);
      for(int i = 0, cnt = gridDopush->Items->Count; i < cnt; ++i)
	  {
         int pm_status = gridDopush->Items->Item[i]->Checked ? CheckPermitted(q_orig_perm, pm[i], i) : 3;
         q_p_r->Insert();
         PmDataToRecord(q_p_r, pm, q_save->FieldByName("calc_id")->AsInteger, i, i, pm_status);
	  }
      q_p_r->UpdateBatch();

      m_api->dbCloseCursor(res, q_p_r);
      m_api->dbCloseCursor(res, q_orig_perm);

      //////Save_Dogovors_k5_k6(m_api, q_save->FieldByName("calc_id")->AsInteger, di, pi, pm, gridDopush);

      //
      if(reasons_surcharge[17].select)
      {
         m_api->dbExecuteQuery(res, "delete * from casco_devices_r where calc_id=" + q_save->FieldByName("calc_id")->AsString);
         TADOQuery *q_ad_r = m_api->dbGetCursor(res, "select * from casco_devices_r where calc_id=" + q_save->FieldByName("calc_id")->AsString, 0, 1);
		 for (int i = 0, j = 0, cnt = gridAD->Items->Count; i < cnt; ++i)
		 {
			 if (gridAD->Items->Item[i]->Checked)
			 {
				 q_ad_r->Insert();
				 q_ad_r->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->AsInteger;
				 q_ad_r->FieldByName("number")->Value = j + 1;
				 q_ad_r->FieldByName("id_device")->Value = adevice[i].id;
				 q_ad_r->FieldByName("cost_device")->Value = adevice[i].cost;
				 q_ad_r->FieldByName("description")->Value = adevice[i].name_detail;
				 ++j;
			 }
		 }
         q_ad_r->UpdateBatch();
         m_api->dbCloseCursor(res, q_ad_r);
      }
   }
}
//------------------------------------------------------------------------------
int TFReissCalc::CheckPermitted(TADOQuery *q_orig_perm, const PersonInfo& pinf, const int num)
{
   if(!q_orig_perm->Locate("type_person", num + 4, locate)) return 1;
   else{
      if(q_orig_perm->FieldByName("first_name")->AsString != pinf.firstname ||
         q_orig_perm->FieldByName("second_name")->AsString != pinf.secondname ||
         q_orig_perm->FieldByName("last_name")->AsString != pinf.lastname ||
         q_orig_perm->FieldByName("document_series")->AsString != pinf.doc_seria ||
         q_orig_perm->FieldByName("document_number")->AsString != pinf.doc_number)  return 2;
   }

   return 0;
}
//---------------------------------------------------------------------------
void TFReissCalc::Error(const AnsiString& text, const int unique, bool term, int warning)
{
    if(m_api) m_api->Raise_Error_Warning(res, this, 0, text, text, warning, err_reiss, unique, term);
}
//---------------------------------------------------------------------------
void TFReissCalc::SetColorOnCurrentError()
{
   AnsiString curr_error = m_api->Err_Get_Shown_Error_Text(res, this);

   if(curr_error == "������� ������� ���� ���������� � ���� ��������� � ��������" || curr_error == "���� ���������� � ���� ��������� � �������� �� ����� ���� ������ ���� ��������� � ��������������" || curr_error == "���� ���������� � ���� ��������� � �������� ������ ���� ������ ��� ����� ���� ������ �������� �������� � ������ ���� ��������� �������� ��������") vg_dateChange->Styles->Content = cxStyle6;
   else vg_dateChange->Styles->Content = 0;

   if(curr_error == "�� �������(�) �������(�) �������������� ��������") vg_Reason->Styles->Content = cxStyle6;
   else vg_Reason->Styles->Content = 0;

   if(curr_error == "�� ������� ����� ������") vg_PolicySeries->Styles->Content = cxStyle6;
   else vg_PolicySeries->Styles->Content = 0;

   if(curr_error == "�� ������ ����� ������") vg_PolicyNumber->Styles->Content = cxStyle6;
   else vg_PolicyNumber->Styles->Content = 0;

   if(curr_error == "������� ������� ���� ������ ������" || curr_error == "���� ������ ������ ������ ���� ������ ���� ��������� � ��������������") vg_Date->Styles->Content = cxStyle6;
   else vg_Date->Styles->Content = 0;

   if(curr_error == "�� �������: �������, ���, �������� ������������") vg_Name->Styles->Content = cxStyle6;
   else vg_Name->Styles->Content = 0;

   if(curr_error == "�� ������� ���������� ������ ������������") vg_Document->Styles->Content = cxStyle6;
   else vg_Document->Styles->Content = 0;

   if(curr_error == "�� ������ ����� ������������") vg_Address->Styles->Content = cxStyle6;
   else vg_Address->Styles->Content = 0;

   if(curr_error == "�� ������� ������� ������������") vg_editLastName->Styles->Content = cxStyle6;
   else vg_editLastName->Styles->Content = 0;

   if(curr_error == "�� ������� ��� ������������") vg_editFirstName->Styles->Content = cxStyle6;
   else vg_editFirstName->Styles->Content = 0;

   if(curr_error == "�� ������� �������� ������������") vg_editSecondName->Styles->Content = cxStyle6;
   else vg_editSecondName->Styles->Content = 0;

   if(curr_error == "�� ������� ���� �������� ������������") vg_editBirthDate->Styles->Content = cxStyle6;
   else vg_editBirthDate->Styles->Content = 0;

   if(curr_error == "�� ������� ����� ��������� ������������") vg_editDocSeries->Styles->Content = cxStyle6;
   else vg_editDocSeries->Styles->Content = 0;

   if(curr_error == "�� ������ ����� ��������� ������������") vg_editDocNumber->Styles->Content = cxStyle6;
   else vg_editDocNumber->Styles->Content = 0;

   if(curr_error == "�� ������� ���� ������ ��������� ������������") vg_editDocDate->Styles->Content = cxStyle6;
   else vg_editDocDate->Styles->Content = 0;

   if(curr_error == "�� ������� ��� ����� �������� ������������") vg_editDocOrg->Styles->Content = cxStyle6;
   else vg_editDocOrg->Styles->Content = 0;

   if(curr_error == "�� ������ ����� ������������ ") vg_editAddress->Styles->Content = cxStyle6;
   else vg_editAddress->Styles->Content = 0;

   if(curr_error == "�� ������� ������� �������������������"
   || curr_error == "�� ������� �������� �����������(��)-�������������������") vg_editBLastName_or_Organization->Styles->Content = cxStyle6;
   else vg_editBLastName_or_Organization->Styles->Content = 0;

   if(curr_error == "�� ������� ��� �������������������") vg_editBFirstName->Styles->Content = cxStyle6;
   else vg_editBFirstName->Styles->Content = 0;

   if(curr_error == "�� ������� �������� �������������������") vg_editBSecondName->Styles->Content = cxStyle6;
   else vg_editBSecondName->Styles->Content = 0;

   if(curr_error == "������� ������ ���. ����� �� (������ ��������� ������ ����� � ������� ����� '�','�','�','�','�','�','�','�','�','�','�','�')"
   || curr_error == "������� ������ ��� ������� ���. ������ ��") vg_editRegPlate->Styles->Content = cxStyle6;
   else vg_editRegPlate->Styles->Content = 0;

   if(curr_error == "������� ������ VIN ��" || curr_error == "�� ������ � ������(�����, ���������) ��") vg_editTSVIN->Styles->Content = cxStyle6;
   else vg_editTSVIN->Styles->Content = 0;

   if(curr_error == "�� ������� ����� ��������� ��") vg_editVehicleDocSeries->Styles->Content = cxStyle6;
   else vg_editVehicleDocSeries->Styles->Content = 0;

   if(curr_error == "�� ������ ����� ��������� ��") vg_editVehicleDocNumber->Styles->Content = cxStyle6;
   else vg_editVehicleDocNumber->Styles->Content = 0;

   if(curr_error == "�� ������� ���������� � ����������") vg_cboxMultyDrive->Styles->Content = cxStyle6;
   else vg_cboxMultyDrive->Styles->Content = 0;

   if(curr_error == "���� 2 ������� ������ �������� ����� ��� �� 7 �������") vg_editPayment2->Styles->Content = cxStyle6;
   else vg_editPayment2->Styles->Content = 0;

   if(curr_error == "���� 3 ������� ������ �������� ����� ��� �� 7 �������") vg_editPayment3->Styles->Content = cxStyle6;
   else vg_editPayment3->Styles->Content = 0;
}
//---------------------------------------------------------------------------
void TFReissCalc::CalcSurcharge()
{
   n = DaysBetween((int)di->datesrok_s, (int)di->cancell_date) + 1, N = DaysBetween((int)di->datesrok_s, (int)di->datesrok_po) + 1;

   if(is_surcharge_recalc && IsChangeDataForRecalc())
   {
      di->calc_info.osn_risk_itog_tarif = m_api->Round(di->calc_info.bt *
                               (coeff_base.count(1)  ? di->calc_info.k1  : 1) *
                               (coeff_base.count(28) ? di->calc_info.kd  : 1) *
                               (coeff_base.count(3)  ? di->calc_info.k3  : 1) *
                               (coeff_base.count(4)  ? di->calc_info.k4  : 1) *
                               (coeff_base.count(5)  ? di->calc_info.k5  : 1) *
                               (coeff_base.count(7)  ? di->calc_info.k7  : 1) *
                               (coeff_base.count(9)  ? di->calc_info.kar : 1) *
                               (coeff_base.count(11) ? di->calc_info.kr  : 1) *
                               (coeff_base.count(14) ? di->calc_info.ka  : 1) *
                               (coeff_base.count(19) ? di->calc_info.k6  : 1) *
                               (coeff_base.count(24) ? di->calc_info.ks  : 1) *
                               (coeff_base.count(22) ? di->calc_info.krs : 1) *
                               (coeff_base.count(23) ? di->calc_info.kpr : 1) *
                               (coeff_base.count(26) ? di->calc_info.kb  : 1) * di->calc_info.kfr);

      double mr = GetMinRate();
      if(mr && mr > di->calc_info.osn_risk_itog_tarif) di->calc_info.osn_risk_itog_tarif = mr;
      if(di->calc_info.osn_risk_itog_tarif > 100)      di->calc_info.osn_risk_itog_tarif = 100;

      new_premiya_osn_risk = m_api->Round(di->calc_info.osn_risk_itog_tarif * (di->calc_info.str_summa + (reasons_surcharge[17].select ? SumAD() : 0.0)) / 100);

      AnsiString str___ = "new_premiya_osn_risk= " + FloatToStr(new_premiya_osn_risk) + " " +
                          "di->calc_info.osn_risk_itog_tarif= " + FloatToStr(di->calc_info.osn_risk_itog_tarif) + " " +
                               "bt= " + FloatToStr( m_api->Round(di->calc_info.bt ) ) + " " +					  //
                               "k1= " + (coeff_base.count(1)  ? FloatToStr( di->calc_info.k1 ) : IntToStr(1) ) + " " + //*
                               "kd= " + (coeff_base.count(28) ? FloatToStr( di->calc_info.kd ) : IntToStr(1) ) + " " + //*
                               "k3= " + (coeff_base.count(3)  ? FloatToStr( di->calc_info.k3 ) : IntToStr(1) ) + " " + //*
                               "k4= " + (coeff_base.count(4)  ? FloatToStr( di->calc_info.k4 ) : IntToStr(1) ) + " " + //*
                               "k5= " + (coeff_base.count(5)  ? FloatToStr( di->calc_info.k5 ) : IntToStr(1) ) + " " + //*
                               "k7= " + (coeff_base.count(7)  ? FloatToStr( di->calc_info.k7 ) : IntToStr(1) ) + " " + //*
                               "kar= " + (coeff_base.count(9)  ? FloatToStr( di->calc_info.kar) : IntToStr(1) ) + " " + //*
                               "kr= " + (coeff_base.count(11) ? FloatToStr( di->calc_info.kr ) : IntToStr(1) ) + " " + //*
                               "ka= " + (coeff_base.count(14) ? FloatToStr( di->calc_info.ka ) : IntToStr(1) ) + " " + //*
                               "k6= " + (coeff_base.count(19) ? FloatToStr( di->calc_info.k6 ) : IntToStr(1) ) + " " + //*
                               "ks= " + (coeff_base.count(24) ? FloatToStr( di->calc_info.ks ) : IntToStr(1) ) + " " + //*
                               "krs= " + (coeff_base.count(22) ? FloatToStr( di->calc_info.krs) : IntToStr(1) ) + " " + //*
                               "kpr= " + (coeff_base.count(23) ? FloatToStr( di->calc_info.kpr) : IntToStr(1) ) + " " + //*
                               "kb= " + (coeff_base.count(26) ? FloatToStr( di->calc_info.kb ) : IntToStr(1) ) + " " + //*
							   "kfr= " + FloatToStr( di->calc_info.kfr ) ;

      if(di->contract_type){
         if(di->old_programm_id == 886)
            di->calc_info.min_premiya_osn_risk = m_api->Round((di->programm_id == 1045 ? di->calc_info.old_premium_paid : di->calc_info.old_premium) * di->calc_info.coeff_limit * di->calc_info.ka);
         else if(di->old_programm_id == 1045)
            di->calc_info.min_premiya_osn_risk = m_api->Round(di->calc_info.old_premium * di->calc_info.coeff_limit * di->calc_info.ka / (di->programm_id == 1045 ? 1.0 : 0.55));
         else
            di->calc_info.min_premiya_osn_risk = m_api->Round(di->calc_info.old_premium * di->calc_info.coeff_limit * di->calc_info.ka);

         if(new_premiya_osn_risk < di->calc_info.min_premiya_osn_risk) new_premiya_osn_risk = di->calc_info.min_premiya_osn_risk;

/* // TSInfo
         if(di->programm_id == 1045 && new_premiya_osn_risk < di->calc_info.min_premium_ekonom[tsi->group_ts]) new_premiya_osn_risk = di->calc_info.min_premium_ekonom[tsi->group_ts];
      }
      else{
         if(di->programm_id == 1045 && new_premiya_osn_risk < di->calc_info.min_premium_ekonom[tsi->group_ts]) new_premiya_osn_risk = di->calc_info.min_premium_ekonom[tsi->group_ts];
      }
//*/
        // VehicleInfo
         if(di->programm_id == 1045 && new_premiya_osn_risk < di->calc_info.min_premium_ekonom[tsi->vehicle_group]) new_premiya_osn_risk = di->calc_info.min_premium_ekonom[tsi->vehicle_group];
      }
      else{
         if(di->programm_id == 1045 && new_premiya_osn_risk < di->calc_info.min_premium_ekonom[tsi->vehicle_group]) new_premiya_osn_risk = di->calc_info.min_premium_ekonom[tsi->vehicle_group];
      }

      int n182 = n;
      if(n182 > 182) n182 = 182;
      double days_coeff = 1.0 - double(n182) / double(N);
      //surcharge_value = m_api->Round((new_premiya_osn_risk - di->calc_info.premiya_osn_risk) * days_coeff);
      surcharge_value = m_api->Round((new_premiya_osn_risk - premiya_osn_risk_orig) * days_coeff);
      if(surcharge_value < 0.0) surcharge_value = 0.0;
   }

   if(is_surcharge_constant){
      n300 = n;
      if(n300 > 300) n300 = 300;
      double days_coeff = 1.0 - double(n300) / double(N);
      surcharge_value_ss = surcharge_value_gp = 0;

      //if(reasons_surcharge[18].select) surcharge_value_ss = !is_gap ? m_api->Round((di->calc_info.str_summa2 - di->calc_info.str_summa) * di->calc_info.premiya_osn_risk / di->calc_info.str_summa1 * di->calc_info.kdiscount * days_coeff / 100) * 100 : m_api->Round((((di->calc_info.str_summa2 - di->calc_info.str_summa) * di->calc_info.kgap / 100) + ((di->calc_info.str_summa2 - di->calc_info.str_summa) * di->calc_info.premiya_osn_risk / di->calc_info.str_summa1 * di->calc_info.kdiscount)) * days_coeff / 100) * 100;
      if(reasons_surcharge[19].select) surcharge_value_gp = m_api->Round(di->calc_info.str_summa * days_coeff * di->calc_info.kgap / 10000) * 100;

      surcharge_value_gap_ss = surcharge_value_ss + surcharge_value_gp;
   }

   if(memo) memo->Text = CalcText();
}
//---------------------------------------------------------------------------
AnsiString TFReissCalc::CalcText()
{
   AnsiString tmp, text(""), bt_calcstr = "T = " + S(di->calc_info.bt) + "(��)";

   text.sprintf("������������� ��������: %s / %s.\r\n"
    "������ ���������� ��������: %s.\r\n"
    "���� ���������� ��������: %s �. \r\n"
    "���������� ����: %s.\r\n"
    "���� �����������: %i ���. \r\n"
    "�����, ������: %s.\r\n"
    "������ ��: %s.\r\n"
    "������� ��: %i ���. \r\n"
    "%s\r\n"
    "�������������� ���������: %s ���.\r\n"
    "��������� ����� �� ��������� �����: %s ���.\r\n"
    "������ �� ��������� ��������: %s ���.\r\n" //������ ��������
    "C��� ����������� � ���� (N): %i.\r\n"
    "���������� ���� �� �������� ���� ����������� (n): %i.\r\n",
    di->calculation_id,  di->contract_id,
    di->region_id ? m_api->dbGetStringFromQuery(res, "select terr_name from gl_dict_regions where terr_id=" + IntToStr(di->region_id)) : AnsiString("������ ����������� � ���."),
    di->polis_date.DateString(),
    di->risk == 2 ? "�����" : "�����",
    di->monthcount,
/* // TSInfo
    tsi->ts_marka + ", " + tsi->ts_model,

    StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(tsi->group_ts)), "������ ", empty_str, rf),
    tsi->ts_age,
//*/
    tsi->vehicle_brand_name + ", " + tsi->vehicle_model_name,

    StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(tsi->vehicle_group)), "������ ", empty_str, rf),
    tsi->vehicle_age,
    di->contract_type ? "�������������� �������" : "�������������� �������",
    FormatDigits(di->calc_info.cost_vehicle),
    FormatDigits(di->calc_info.str_summa),
    //FormatDigits(di->calc_info.premiya_osn_risk),
    FormatDigits(premiya_osn_risk_orig),
    N, n);

   if(coeff_base.count(1))  bt_calcstr += " * " + S(di->calc_info.k1)  + "(K1)";
   if(coeff_base.count(28)) bt_calcstr += " * " + S(di->calc_info.kd)  + "(K�)";
   if(coeff_base.count(18)) bt_calcstr += " * " + S(di->calc_info.kyu) + "(K�)";
   if(coeff_base.count(2))  bt_calcstr += " * " + S(di->calc_info.k2)  + "(K2)";
   if(coeff_base.count(3))  bt_calcstr += " * " + S(di->calc_info.k3)  + "(K3)";
   if(coeff_base.count(4))  bt_calcstr += " * " + S(di->calc_info.k4)  + "(K4)";
   if(coeff_base.count(5))  bt_calcstr += " * " + S(di->calc_info.k5)  + "(K5)";
   if(coeff_base.count(19)) bt_calcstr += " * " + S(di->calc_info.k6)  + "(K6)";
   if(coeff_base.count(7))  bt_calcstr += " * " + S(di->calc_info.k7)  + "(K7)";
   if(coeff_base.count(11)) bt_calcstr += " * " + S(di->calc_info.kr)  + "(K�)";
   if(coeff_base.count(9))  bt_calcstr += " * " + S(di->calc_info.kar) + "(K��)";
   if(coeff_base.count(23)) bt_calcstr += " * " + S(di->calc_info.kpr) + "(K��)";
   if(coeff_base.count(24)) bt_calcstr += " * " + S(di->calc_info.ks)  + "(K�)";
   if(coeff_base.count(22)) bt_calcstr += " * " + S(di->calc_info.krs) + "(K��)";
   if(coeff_base.count(26) && di->bank_id > 0)
                            bt_calcstr += " * " + S(di->calc_info.kb)  + "(K�)";
   if(di->bank_id > 0)      bt_calcstr += " * " + S(di->calc_info.kfr) + "(K�����)";
   if(coeff_base.count(14)) bt_calcstr += " * " + S(di->calc_info.ka)  + "(K�)";

   if(is_surcharge_recalc){
      text += tmp.sprintf(
         "�������� ����� (�����): %.2f %%\r\n"
         "%s\r\n" //������ � �����-����
         "������ � ����������� ���������: %s ���.\r\n" // ������ �����
         "\r\n�������: %s ���.",
          di->calc_info.osn_risk_itog_tarif,
          bt_calcstr.c_str(),
          FormatDigits(new_premiya_osn_risk),
          FormatDigits(surcharge_value)
         );
  }

  if(is_surcharge_constant){
      /*if(reasons_surcharge[18].select)
         text += (AnsiString("\r\n ������� �� ���������� ��")  + AnsiString(is_gap ? ", ��������� �� GAP: " : ": ") +
                  (is_gap ? tmp.sprintf("((%s(CC2) - %s(CC�)) * %s%%(����� GAP)  + (%s(CC2) - %s(CC�)) * %s(��) / %s(CC1) * %s(�������)) * (%i(N) - %i(n)) / %i(N) = %s ���.", FormatDigits(di->calc_info.str_summa2), FormatDigits(di->calc_info.str_summa), FormatDigits(di->calc_info.kgap), FormatDigits(di->calc_info.str_summa2), FormatDigits(di->calc_info.str_summa), FormatDigits(di->calc_info.premiya_osn_risk), FormatDigits(di->calc_info.str_summa1), FormatDigits(di->calc_info.kdiscount), N, n300, N, FormatDigits(surcharge_value_ss))
                          : tmp.sprintf("(%s(CC2) - %s(CC�)) * %s(��) / %s(CC1) * %s(�������) * (%i(N) - %i(n)) / %i(N) = %s ���.", FormatDigits(di->calc_info.str_summa2), FormatDigits(di->calc_info.str_summa), FormatDigits(di->calc_info.premiya_osn_risk), FormatDigits(di->calc_info.str_summa1), FormatDigits(di->calc_info.kdiscount), N, n300, N, FormatDigits(surcharge_value_ss))));*/

      if(reasons_surcharge[19].select)
         text += (AnsiString("\r\n ������� �� ���������� GAP: ") +
                  (tmp.sprintf("%s(CC�) * %s%%(����� GAP) * (%i(N) - %i(n)) / %i(N) = %s ���.",
                   FormatDigits(di->calc_info.str_summa),
                   FormatDigits(di->calc_info.kgap),
                   N, n300, N,
                   FormatDigits(surcharge_value_gp))
                  )
                 );

   }

   text += ("\r\n\r\n������\ ����������: " + di->calc_date);
   return text;
}
//---------------------------------------------------------------------------
void TFReissCalc::Recalc()
{
   TDateTime dt;
   int error_num(0), count_permitted = GetCountPermitted(gridDopush);

   if(m_api) m_api->Err_Set_False_All_Errors_Warnings(res, this);

   surcharge_value = 0.0;
   non_standart_str->Clear(); // ������� ������ ������������� �������
   if(memo) memo->Text = empty_str;
   bool is_non_sr = IsNonStandartReissue();

   if(di->status_dogovor != 15) di->status_dogovor = is_non_sr ? 14 : 13;

   Error("������ ������� UFO ������ ��������� ������ ���������:" + di->validations_errors->Text, ++error_num, di->validations_errors->Count);
   Error("Oracle Insbridge ������ ��������� ������ �������:" + di->insbridge_errors->Text, ++error_num, di->insbridge_errors->Count);
   Error("������ ������� UFO ������ ��������� ������: \"" + di->system_error + "\"", ++error_num, !di->system_error.IsEmpty());

   //Error("��������, ����������� �� �� �������� ����������� ���� \"������\" �������(�,�,�), � ���2 �� ��������������.", ++error_num, di->product_id > 306);
   Error("�������������� ��������� ����� ��, ���� ���, ����� ���2 �� ��������������.", ++error_num, di->product_id == 304 || di->product_id == 305 || di->product_id == 306 || di->product_id == 335);
   Error("�������������� ��������� �����, ����������� �� �� �������� ����������� ����"
         " \"������\" �������(�,�,�), ���� �������������� ������ �� ������� \"���������� GAP\"."
         " ������ ������� �������������� ���� ����������.", ++error_num, di->product_id != 301 && di->product_id != 302 && di->product_id != 303
         && (   reasons_surcharge[1].select || reasons_surcharge[2].select || reasons_surcharge[3].select || reasons_surcharge[4].select
             || reasons_surcharge[5].select || reasons_surcharge[6].select || reasons_surcharge[7].select || reasons_surcharge[8].select
             || reasons_surcharge[9].select || reasons_surcharge[10].select || reasons_surcharge[11].select || reasons_surcharge[12].select
             || reasons_surcharge[14].select || reasons_surcharge[15].select || reasons_surcharge[17].select)
        );
   Error("������� ������� ���� ���������� � ���� ��������� � ��������", ++error_num, !di->cancell_date.Val);
   Error("���� ���������� � ���� ��������� � �������� �� ����� ���� ������ ���� ��������� � ��������������", ++error_num, (int)di->statement_date > (int)di->cancell_date);

   AnsiString s_0 = is_autorization ? AnsiString("1") : AnsiString("0");
   unsigned short Year, Month, Day;
   di->cancell_date.DecodeDate(&Year, &Month, &Day);
   AnsiString s_1 = " "+ String(Year) +"."+ String(Month) +"."+ String(Day);

   di->datesrok_s.DecodeDate(&Year, &Month, &Day);
   AnsiString s_2 = " "+ String(Year) +"."+ String(Month) +"."+ String(Day);

   di->datesrok_po.DecodeDate(&Year, &Month, &Day);
   AnsiString s_3 = " "+ String(Year) +"."+ String(Month) +"."+ String(Day);

   Error("���� ���������� � ���� ��������� � �������� ������ ���� ������ ��� ����� ���� ������ �������� �������� � ������ ���� ��������� �������� ��������",
                            ++error_num, is_autorization && (((int)di->cancell_date < (int)di->datesrok_s) || ((int)di->cancell_date >= (int)di->datesrok_po)));
   Error("��� �������� �������������� �� ��������� � ����������� ��� ����� ��� ��������, ������� ���������� ����������������", ++error_num, is_pereautorization);
   Error("�� �������(�) �������(�) �������������� ��������", ++error_num, vg_Reason->Properties->Value == empty_str);

   Error("�� ������� ����� ������", ++error_num, di->polis_seria.IsEmpty());
   Error("�� ������ ����� ������", ++error_num, di->polis_number.IsEmpty());
   Error("������� ������� ���� ������ ������", ++error_num, !di->polis_date.Val);
   Error("���� ������ ������ ������ ���� ������ ���� ��������� � ��������������", ++error_num, di->polis_date.Val && ((int)di->statement_date < (int)di->polis_date));

   //Error("���������� ������������ �������", ++error_num, !is_autorization);
   Error("���������� ������������ �������", ++error_num, !cur_autorization);

/////////////////////////////////////////////////////////////////// Error("���������� ���������� ������(���������� ������)", ++error_num, di->no_calc);

   Error("�� �������: �������, ���, �������� ������������", ++error_num, !is_autorization && !pi[0].status && pi[0].lastname.IsEmpty());
   Error("�� ������� ���������� ������ ������������", ++error_num, !is_autorization && !pi[0].status && pi[0].doc_number.IsEmpty());
   Error("�� ������ ����� ������������", ++error_num, !is_autorization && pi[0].address.IsEmpty());

/* // TSInfo
   //Error("������� \"���������� ��\" ����� ������� ������ ��� ��������� � �� �������� 0 ���", ++error_num, is_autorization && reasons_surcharge[18].select && tsi->ts_age > 0);
   Error("������� \"���������� GAP\" ����� ������� ������ ��� ��������� � �� �� 5 ��� ������������", ++error_num, is_autorization && reasons_surcharge[19].select && tsi->ts_age > 5);
   Error("������� \"���������� GAP\" ����� ������� ������ ��� ��������� � �� ����� ��� ����� �������", ++error_num, is_autorization && reasons_surcharge[19].select && contract_payed_count > 1);
   //Error("������� \"���������� ��\" ��� �������� � ������ ������� �� ������� ������", ++error_num, is_autorization && reasons_surcharge[18].select && !models_for_gap.count(tsi->model_id));
   Error("������� \"���������� GAP\" ���������� ��� ������� ��������, �.�. ��� > CC2", ++error_num, is_autorization && reasons_surcharge[19].select && !tsi->ts_age && di->calc_info.str_summa2 < di->calc_info.str_summa);
//*/
    // VehicleInfo
   //Error("������� \"���������� ��\" ����� ������� ������ ��� ��������� � �� �������� 0 ���", ++error_num, is_autorization && reasons_surcharge[18].select && tsi->ts_age > 0);
   Error("������� \"���������� GAP\" ����� ������� ������ ��� ��������� � �� �� 5 ��� ������������", ++error_num, is_autorization && reasons_surcharge[19].select && tsi->vehicle_age > 5);
   Error("������� \"���������� GAP\" ����� ������� ������ ��� ��������� � �� ����� ��� ����� �������", ++error_num, is_autorization && reasons_surcharge[19].select && contract_payed_count > 1);
   //Error("������� \"���������� ��\" ��� �������� � ������ ������� �� ������� ������", ++error_num, is_autorization && reasons_surcharge[18].select && !models_for_gap.count(tsi->model_id));
   Error("������� \"���������� GAP\" ���������� ��� ������� ��������, �.�. ��� > CC2", ++error_num, is_autorization && reasons_surcharge[19].select && !tsi->vehicle_age && di->calc_info.str_summa2 < di->calc_info.str_summa);

   Error("������� \"���������� GAP\" ��� ��������, ��� GAP ��� �������� ������� ������", ++error_num, is_autorization && reasons_surcharge[19].select && is_gap);
   Error("������� \"���������� GAP\" �������� ������ ��� �������� ���������", ++error_num, is_autorization && reasons_surcharge[19].select && currency != "RUR");
   Error("������� \"���������� GAP\" ���������� ��� ��������� �� ������ ����������� ������ ����", ++error_num, is_autorization && reasons_surcharge[19].select && N > 366);
   //Error("������� \"���������� ��\" ���������� ��� ������� ��������, �.�. ����������� ������ ������ �������������� ������", ++error_num, is_autorization && reasons_surcharge[18].select && di->calc_info.premiya_osn_risk <= di->calc_info.kss_premium_limit && (di->programm_id != 1258 && di->programm_id != 1272 && di->programm_id != 1278 && di->programm_id != 1317 && di->programm_id != 1318 && di->programm_id != 1320 && di->project_id != 1258 && di->project_id != 1272 && di->project_id != 1278 && di->project_id != 1317 && di->project_id != 1318 && di->project_id != 1320));
   Error("������� \"���������� GAP\" ��� ������������� \"�������� ����� Renault\" ����������", ++error_num, is_autorization && reasons_surcharge[19].select && (di->programm_id == 1259 || di->project_id == 1259));

   //
   //   , \"TOYOTA ����������� ������� ���������\", \"MAZDA ����������� �����!\", \"MAZDA �����������\", \"������ ����� KIA\", \"HYUNDAI ����� 3,5%\", \"����-�����\"

   Error("�� ������� ������� ������������", ++error_num, is_autorization && (reasons_surcharge[2].select || reasons_surcharge[14].select) && !pi[0].status && pi[0].lastname.IsEmpty());
   Error("�� ������� ��� ������������", ++error_num, is_autorization && (reasons_surcharge[2].select || reasons_surcharge[14].select) && !pi[0].status && pi[0].firstname.IsEmpty());
   Error("�� ������� �������� ������������", ++error_num, is_autorization && (reasons_surcharge[2].select || reasons_surcharge[14].select) && !pi[0].status && pi[0].secondname.IsEmpty());
   Error("�� ������� ���� �������� ������������", ++error_num, is_autorization && reasons_surcharge[14].select && !pi[0].status && !pi[0].birthdate.Val);

   Error("�� ������� ����� ��������� ������������", ++error_num, is_autorization && (reasons_surcharge[8].select || reasons_surcharge[14].select) && !pi[0].status && ((!DocSeries_MaskItem->Properties->EditMask.IsEmpty() && (pi[0].doc_seria.IsEmpty() || pi[0].doc_seria.Pos(underline_str))) || (DocSeries_MaskItem->Properties->EditMask.IsEmpty() && pi[0].doc_seria.IsEmpty())));
   Error("�� ������ ����� ��������� ������������", ++error_num, is_autorization && (reasons_surcharge[8].select || reasons_surcharge[14].select) && !pi[0].status && ((!DocNumber_MaskItem->Properties->EditMask.IsEmpty() && (pi[0].doc_number.IsEmpty() || pi[0].doc_number.Pos(underline_str) > mask_doc_type[pi[0].doc_type].position)) || (DocNumber_MaskItem->Properties->EditMask.IsEmpty() && pi[0].doc_number.IsEmpty())));
   Error("�� ������� ���� ������ ��������� ������������", ++error_num, is_autorization && (reasons_surcharge[8].select || reasons_surcharge[14].select) && !pi[0].status && !pi[0].doc_issue_date.Val);
   Error("�� ������� ��� ����� �������� ������������", ++error_num, is_autorization && (reasons_surcharge[8].select || reasons_surcharge[14].select) && !pi[0].status && pi[0].doc_issue_org.IsEmpty());

   Error("�� ������ ����� ������������ ", ++error_num, is_autorization && (reasons_surcharge[7].select || reasons_surcharge[14].select) && pi[0].address.IsEmpty());

   Error("�� ������� ������� �������������������", ++error_num, is_autorization && (reasons_surcharge[3].select || reasons_surcharge[14].select) && !pi[1].status && pi[1].lastname.IsEmpty());
   Error("�� ������� ��� �������������������", ++error_num, is_autorization && (reasons_surcharge[3].select || reasons_surcharge[14].select) && !pi[1].status && pi[1].firstname.IsEmpty());
   Error("�� ������� �������� �������������������", ++error_num, is_autorization && (reasons_surcharge[3].select || reasons_surcharge[14].select) && !pi[1].status && pi[1].secondname.IsEmpty());
   Error("�� ������� �������� �����������(��)-�������������������", ++error_num, is_autorization && (reasons_surcharge[3].select || reasons_surcharge[14].select) && pi[1].status > 0 && pi[1].organization.IsEmpty());
/* // TSInfo
   Error("������� ������ ���. ����� �� (������ ��������� ������ ����� � ������� ����� '�','�','�','�','�','�','�','�','�','�','�','�')", ++error_num, is_autorization && reasons_surcharge[5].select && RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value) == 1 && !CheckRegPlate(tsi->ts_znak));
   Error("������� ������ ��� ������� ���. ������ ��", ++error_num, is_autorization && reasons_surcharge[5].select && RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value) == 1 && region_isp_id < 1);
   Error("������� ������ VIN ��", ++error_num, is_autorization && reasons_surcharge[6].select && !tsi->ts_ident_type && !CheckVIN(tsi->ts_vin));
   Error("�� ������ � ������(�����, ���������) ��", ++error_num, is_autorization && reasons_surcharge[6].select && tsi->ts_ident_type && tsi->ts_vin.IsEmpty());
   Error("�� ������� ����� ��������� ��", ++error_num, is_autorization && reasons_surcharge[10].select && tsi->pts_series.IsEmpty());
   Error("�� ������ ����� ��������� ��", ++error_num, is_autorization && reasons_surcharge[10].select && ((!VehicleDocNumber_MaskItem->Properties->EditMask.IsEmpty() && (tsi->pts_number.IsEmpty() || tsi->pts_number.Pos(underline_str))) || (VehicleDocNumber_MaskItem->Properties->EditMask.IsEmpty() && tsi->pts_number.IsEmpty())));
*/
   //bool b1 = is_autorization;
   //bool b2 = (bool)reasons_surcharge[5].select;
   //int  bb = RegVehicle_ComboBoxItem->Properties->Items->InstanceSize();

   bool bRegVehOption = false;
   Variant vt = vg_cboxRegistration->Properties->Value;
   if(!vt.IsNull())
     bRegVehOption = RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value) == 1;

   Error("������� ������ ���. ����� �� (������ ��������� ������ ����� � ������� ����� '�','�','�','�','�','�','�','�','�','�','�','�')",
         ++error_num, is_autorization && reasons_surcharge[5].select && bRegVehOption && !CheckRegPlate(tsi->registration_mark));
   Error("������� ������ ��� ������� ���. ������ ��", ++error_num, is_autorization && reasons_surcharge[5].select && RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value) == 1 && region_isp_id < 1);
   Error("������� ������ VIN ��", ++error_num, is_autorization && reasons_surcharge[6].select && /*!tsi->ts_ident_type &&*/ !CheckVIN(tsi->vin));
   Error("�� ������ � ������(�����, ���������) ��", ++error_num, is_autorization && reasons_surcharge[6].select && /*tsi->ts_ident_type &&*/ tsi->vin.IsEmpty());
   Error("�� ������� ����� ��������� ��", ++error_num, is_autorization && reasons_surcharge[10].select && tsi->registration_series.IsEmpty());
   Error("�� ������ ����� ��������� ��", ++error_num, is_autorization && reasons_surcharge[10].select && ((!VehicleDocNumber_MaskItem->Properties->EditMask.IsEmpty() && (tsi->registration_number.IsEmpty() || tsi->registration_number.Pos(underline_str))) || (VehicleDocNumber_MaskItem->Properties->EditMask.IsEmpty() && tsi->registration_number.IsEmpty())));

   Error("�� ������� ���������� � ����������", ++error_num, is_autorization && di->type_multydrive == 100 && !count_permitted);

   Error("�������������� ����������, �.�. ���� 2 ������� ������ �������� ����� ��� �� 7 �������", ++error_num, is_autorization && reasons_surcharge[12].select && (int)di->payment_date[1] > (int)IncMonth(di->payment_date[0], 7));
   Error("�������������� ����������, �.�. ���� 3 ������� ������ �������� ����� ��� �� 7 �������", ++error_num, is_autorization && reasons_surcharge[12].select && (int)di->payment_date[2] > (int)IncMonth(di->payment_date[0], 7));

   Error("�� ��������� ������ 2012 ������ ������ ������ ���������� ������", ++error_num, is_autorization && reasons_surcharge[11].select && di->programm_id == 1045);
   Error("�� ��������� ������ 2012 ������ ������� �����������", ++error_num, is_autorization && di->programm_id == 1045 && di->type_multydrive != 100);
   Error("�� ��������� ������ 2012 ����� ���� �� ����� 3-� ����������", ++error_num, is_autorization && di->programm_id == 1045 && count_permitted > 3);
   //Error("�� ��������� ������ 2012 ������� \"���������� ��\" �������� ������", ++error_num, is_autorization && di->programm_id == 1045 && reasons_surcharge[18].select);

   Error("������������� ������� ���������� � �������� ����� ����� ������ �� ������� \"���������� GAP\".", ++error_num, is_autorization && di->programm_id == 1316 && (reasons_surcharge[1].select || reasons_surcharge[2].select || reasons_surcharge[3].select || reasons_surcharge[4].select || reasons_surcharge[5].select || reasons_surcharge[6].select || reasons_surcharge[7].select || reasons_surcharge[8].select || reasons_surcharge[9].select || reasons_surcharge[10].select || reasons_surcharge[11].select || reasons_surcharge[12].select || reasons_surcharge[14].select || reasons_surcharge[15].select || reasons_surcharge[17].select));

/* // TSInfo
   Error("���������� ���������� �������� ������ ��� �� ������ ��1-��3, ��1", ++error_num, is_autorization && reasons_surcharge[15].select && tsi->group_ts != 1 && tsi->group_ts != 2 && tsi->group_ts != 3 && tsi->group_ts != 6);
   Error("���������� ���������� �������� ������ ��� ���������� ��� �� �������� �", ++error_num, is_autorization && reasons_surcharge[15].select && di->product_id != 301);
   Error("���������� ���������� �������� ������ ��� �� ��������� �� 5 ��� ������������", ++error_num, is_autorization && reasons_surcharge[15].select && tsi->ts_age > 5);
//*/
   Error("���������� ���������� �������� ������ ��� �� ������ ��1-��3, ��1", ++error_num, is_autorization && reasons_surcharge[15].select && tsi->vehicle_group != 1 && tsi->vehicle_group != 2 && tsi->vehicle_group != 3 && tsi->vehicle_group != 6);
   Error("���������� ���������� �������� ������ ��� ���������� ��� �� �������� �", ++error_num, is_autorization && reasons_surcharge[15].select && di->product_id != 301);
   Error("���������� ���������� �������� ������ ��� �� ��������� �� 5 ��� ������������", ++error_num, is_autorization && reasons_surcharge[15].select && tsi->vehicle_age > 5);

   di->calc_info.kd = coeff_kd.size() ? coeff_kd[count_permitted] : 1.0;

   //Error("�� ������� ����� ������", ++error_num, vg_PolicySeries->Properties->Value.IsNull() || vg_PolicySeries->Properties->Value == empty_str);

   //*

   // �� ����������� - ���� �� ����� �����+�����+���� - ������ ��������� ������ �����������
   // ����� ����������� - ������ ������ � (*)
   btnRequest->Enabled = !is_autorization && !di->polis_seria.IsEmpty() && !di->polis_number.IsEmpty() && di->polis_date.Val;
   // (*) � ������ ����� � ������ ��� �����+�����+���� - �� ���������� ��� ��������������
   vg_PolicySeries->Properties->Options->Editing = !is_autorization;
   vg_PolicyNumber->Properties->Options->Editing = !is_autorization;
   vg_Date->Properties->Options->Editing         = !is_autorization;

   if(!di->polis_seria.IsEmpty())   NextPolisSeria = di->polis_seria;
   if(!di->polis_number.IsEmpty())  NextPolisNumber = di->polis_number;
   if( (NextPolisSeria != di->polis_seria) || (NextPolisNumber != di->polis_number) )
   {
     btnRequest->Enabled = true;
     btnRequestUFO->Enabled = false;
   }

   if(is_autorization)
   { btnRequestUFO->Enabled = (!btnRequest->Enabled); }
   
   // ������ ������ ����������� ��� ���������� ������� � ������ � ���� �� �������
   //btnRequest->Enabled = false;

   //*/

   vg_Name->Properties->Options->Editing     = !is_autorization;
   vg_Document->Properties->Options->Editing = !is_autorization;
   vg_Address->Properties->Options->Editing  = !is_autorization;

   /****************************************************************************/
   error->Text = m_api->Err_Get_Calc_Errors_By_Type_RT(res, err_reiss, this);
   int is_error = error->Count;

   if(is_error)
   {
     //SetColorOnCurrentError();
   }
   else
   {
      for(int i = 0, cnt = vg->Rows->Count; i < cnt; ++i)
      {
         if(AnsiString(vg->Rows->Items[i]->ClassName()) == AnsiString("TcxEditorRow")) dynamic_cast<TcxEditorRow*>(vg->Rows->Items[i])->Styles->Content = 0;
      }

      // ������ ��������� ����� ����� �����������, ������ ����� ����������� � ��������� ������� � ���.
      //if(is_autorization && (is_surcharge_recalc || is_surcharge_constant))
      if(is_autorization && is_ufo_req_success && (is_surcharge_recalc || is_surcharge_constant))
      {
        CalcSurcharge();
      }

      if(di->is_ander_login){
         f_andr_pan->Calc();
         labNonStandardDogovor_Up->Properties->Caption = empty_str;
         labNonStandardDogovor_Up->Visible = false;
      }
      else{
         AnsiString cptn("");
         switch(di->status_dogovor){
            case 3:  cptn = "������� �� ����������."; break;
            case 10: cptn = "������� ������������."; break;
            case 13: cptn = empty_str;  break;
            case 14: cptn = "����������� ������������. ������� �� ������� �������� �������� ��������������, �.�.: \r\n" + non_standart_str->Text; break;
            case 15: cptn = "������� ����������."; break;
         }
         labNonStandardDogovor_Up->Properties->Caption = cptn;
         labNonStandardDogovor_Up->Height = di->status_dogovor == 14 ? (non_standart_str->Count + 1) * 22 : 22;
         labNonStandardDogovor_Up->Visible = di->status_dogovor != 13;
      }
   }

   if(!is_autorization)
   {
      CalcTotal->Properties->Caption = "���������� �� ��������������:\r\n - ������� �� �����������;";
      if(!is_error)
      {
        CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + "\r\n - � ������ �������� ������ ���������(������).";
        //PrintInfoCalcTotal();
      }
      else
      {
        CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + "\r\n - ��� ���������� ��������� � ������.";
        //PrintInfoCalcTotal();
      }

      CalcTotal->Visible = true;
      //CalcTotal->VisibleIndex = 17;
   }
   else
   {
      CalcTotal->Properties->Caption = "���������� �� ��������������:\r\n - ������� �����������;";
      if(!is_error)
      {
         if(   (is_surcharge_recalc || is_surcharge_constant)
            && (surcharge_value > 0.0 || surcharge_value_gap_ss > 0.0)
           )
         {
            CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + "\r\n";
            // ���� ����������� ������ ������� � ������ � ��� ������ ������� ������ ����� ������� ����� ������� !
            //if(is_autorization && is_ufo_req_success)
            {
                if(is_surcharge_recalc && surcharge_value > 0.0)
                {
                  CalcTotal->Properties->Caption
                  = CalcTotal->Properties->Caption + "- ����� �������: " + FormatFloat(",0.00�'.';-,0.00�'.'", m_api->Round(surcharge_value));
                }
                if(is_surcharge_constant)
                {
                  //if(reasons_surcharge[18].select) CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + " ����� ������� (���������� ��): " + FormatFloat(",0.00�'.';-,0.00�'.'", m_api->Round(surcharge_value_ss));
                  if(reasons_surcharge[19].select)
                  {
                    CalcTotal->Properties->Caption
                    = CalcTotal->Properties->Caption + " ����� ������� (���������� GAP): " + FormatFloat(",0.00�'.';-,0.00�'.'", m_api->Round(surcharge_value_gp));
                  }

                  //PrintInfoCalcTotal();
                }
            }
         }
         else
         {
           CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + "\r\n - ������� �� ���������;";
         }
         if(di->status_dogovor == 13 || di->status_dogovor == 15)
         {
           CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + "\r\n - � ������ �������� ��� ����������� ���������.";
           //PrintInfoCalcTotal();
         }
      }
      else
      {
        CalcTotal->Properties->Caption = CalcTotal->Properties->Caption + "\r\n - ��� ���������� ��������� � ������.";
        //PrintInfoCalcTotal();
      }

      CalcTotal->Visible = true;
      //CalcTotal->VisibleIndex = 17;
   }


   Error("���������� ���������� ������(���������� ������)", ++error_num, di->no_calc);

}
//------------------------------------------------------------------------------

void TFReissCalc::PrintInfoCalcTotal()
{
        int vis             = CalcTotal->Visible ? 1 : 0;
        int isfirst         = CalcTotal->IsFirst()? 1 : 0;;
        int islast          = CalcTotal->IsLast()? 1 : 0;;
        int has_vis_child   = CalcTotal->HasVisibleChildren()? 1 : 0;;
        int hasparent       = CalcTotal->HasParent()? 1 : 0;;
        int expanded        = CalcTotal->Expanded? 1 : 0;;

        int count           = CalcTotal->Count;
        int visindex        = CalcTotal->VisibleIndex;
        int height          = CalcTotal->Height;

        AnsiString cptn("");
        cptn = cptn +"vis           = " +IntToStr(CalcTotal->Visible ? 1 : 0			) + "\n";
        cptn = cptn +"isfirst       = " +IntToStr(CalcTotal->IsFirst()? 1 : 0			) + "\n";
        cptn = cptn +"islast        = " +IntToStr(CalcTotal->IsLast()? 1 : 0			) + "\n";
        cptn = cptn +"has_vis_child = " +IntToStr(CalcTotal->HasVisibleChildren()? 1 : 0) + "\n";
        cptn = cptn +"hasparent     = " +IntToStr(CalcTotal->HasParent()? 1 : 0			) + "\n";
        cptn = cptn +"expanded      = " +IntToStr(CalcTotal->Expanded? 1 : 0			) + "\n";

		cptn = cptn +"count         = " +IntToStr(CalcTotal->Count						) + "\n";
        cptn = cptn +"visindex      = " +IntToStr(CalcTotal->VisibleIndex				) + "\n";
        cptn = cptn +"height        = " +IntToStr(CalcTotal->Height						) + "\n";

        Application->MessageBox(cptn.c_str(),"����� ����", MB_OK | MB_ICONEXCLAMATION);
        //CalcTotal->MakeVisible();
        //CalcTotal->Expand();
}


void TFReissCalc::ChangeMultiDrive()
{
   vg_cboxMultyDrive->Properties->Value = empty_str;
   q = m_api->dbGetCursor(res, sql.sprintf("select id,type_multidrive,coeff_val from cascomultidrive where CDate('%s')>=start_date and CDate('%s')<=end_date and (isnull(terrtype_id) or terrtype_id=%i) order by id", di->calc_date, di->calc_date, di->REGION_TYPE));
   for(MultyDrive_ComboBoxItem->Properties->Items->Clear(), q->First(); !q->Eof; q->Next()){
      DataDict *multy = new DataDict(q->FieldByName("id")->AsInteger, q->FieldByName("coeff_val")->AsFloat, 0);
      MultyDrive_ComboBoxItem->Properties->Items->AddObject(q->FieldByName("type_multidrive")->AsString.Trim(), multy);
   }
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void TFReissCalc::LoadListCredits(const int payment_count)
{
   vg_cboxCredit->Properties->Value = variant_null;
   Credit_ComboBoxItem->Properties->Items->Clear();
   if(payment_count == 2){
      q = m_api->dbGetCursor(res, sql.sprintf("select id_krs,credit_name,coeff_value from cascodictk08 where payment_count_min=3 and terr_type_id=%i and (product_id=%i or product_id=0) and CDate('%s')>=start_date and CDate('%s')<=end_date order by id_krs", di->REGION_TYPE, di->product_id, di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next()){
         DataDict *k8 = new DataDict(q->FieldByName("id_krs")->AsInteger, q->FieldByName("coeff_value")->AsFloat, 3);
         Credit_ComboBoxItem->Properties->Items->AddObject(q->FieldByName("credit_name")->AsString, k8);
      }
      m_api->dbCloseCursor(res, q);
   }
   //int index_crd = Credit_ComboBoxItem->Properties->Items->IndexOf(str_crd);
   //vg_cboxCredit->Properties->Value = Credit_ComboBoxItem->Properties->Items->Strings[index_crd > -1 ? index_crd : 0];
}
//---------------------------------------------------------------------------
void TFReissCalc::LoadVozmType()
{
   VozmType_ComboBoxItem->Properties->Items->Clear();
   vg_cboxVozmType->Properties->Value = empty_str;

   if(di->pay_id == 1 || di->pay_id == 3){
      VozmType_ComboBoxItem->Properties->Items->AddObject("������ �� ���� �����������",  (TObject*)3);
      VozmType_ComboBoxItem->Properties->Items->AddObject("������ �� ���� ������������", (TObject*)1);

      vg_cboxVozmType->Properties->Value = VozmType_ComboBoxItem->Properties->Items->Strings[VozmType_ComboBoxItem->Properties->Items->IndexOfObject((TObject*)di->pay_id)];
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::vgInitEdit(TObject *Sender, TObject *AItem, TcxCustomEdit *AEdit)
{
   AEdit->Style->Color = clWhite;
}
//---------------------------------------------------------------------------

#define addFunc(Name, Type) void set##Name(Type val) { Name = val; } Type get#Name { return Name; }

void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesCloseUp(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();
   AnsiString val = vg_Reason->Properties->Value;
   //if(/*is_autorization && */val != last_reasons){

      frmAddPermitted->rgPmSex->Properties->Options->Editing = true;
      frmAddPermitted->deditPmBirthDate->Properties->Options->Editing = true;
      frmAddPermitted->deditPmStartDriving->Properties->Options->Editing = true;

      btnDopushPlus->Visible = false;
      //btnDopushMinus->Visible = false;
      btnDopushEdit->Visible = false;
      gridDopush->Visible = false;
      btnADPlus->Visible = false; btnADEdit->Visible = false; ADHead->Visible = false; gridAD->Visible = false;

      for(int i = 18, cnt = vg->Rows->Count; i < cnt; ++i) vg->Rows->Items[i]->Visible = false;
      is_surcharge_recalc = is_surcharge_constant = false;
      for(int i = 0, cnt = Reason_CheckComboBox->Properties->Items->Count; i < cnt; ++i){
         TcxCheckComboBoxItem *item = Reason_CheckComboBox->Properties->Items->Items[i];
         if(val.Pos(item->Description)){
            if(is_autorization) SetVisible_VG_Items(item->Tag);
            reasons_surcharge[item->Tag].select = 1;
            if(reasons_surcharge[item->Tag].surcharge_recalc) is_surcharge_recalc = true;
            if(reasons_surcharge[item->Tag].surcharge_constant) is_surcharge_constant = true;
         }
         else reasons_surcharge[item->Tag].select = 0;
      }
   //}

//   if( is_surcharge_recalc && (last_reasons != vg_Reason->Properties->Value) ) // last_reasons != current_reasons  
//     di->no_calc = DO_RECALC_USING_UFO;

   //if(vg_Reason->Properties->Value != empty_str)
     Recalc();
}
//---------------------------------------------------------------------------
void TFReissCalc::SetVisible_VG_Items(const int reason)
{
   m_curReason = reason;
   switch(reason)
   {
      case REASON_CHNG_DOPUSH_NUM:
         btnDopushPlus->Visible = true;
         //btnDopushMinus->Visible = true;
         btnDopushEdit->Visible = true;
         gridDopush->Visible = true;
         vg_HeadPermitted->Visible = true;
         vg_cboxMultyDrive->Visible = true;
         vg_HeadGrid->Visible = true;
         gridDopush->Checkboxes = true;
         ////////////////////////////////
         //is_surcharge_recalc;
         //is_surcharge_constant;
         di->no_calc = DO_RECALC_USING_UFO;
         break;
      case REASON_INSURANT_FIO:
         vgHeadInsured->Visible = true;
         vg_editLastName->Visible = true;
         vg_editFirstName->Visible = true;
         vg_editSecondName->Visible = true;
         break;
      case REASON_BENEFIC_FIO:
         vgHeadBenefic->Visible = true;
         vg_editBStatus->Visible = true;
         vg_editBLastName_or_Organization->Visible = true;
         vg_editBLastName_or_Organization->Properties->Caption = pi[1].status ? "������������ ����������� / ��" : "�������";
         vg_editBFirstName->Visible = !pi[1].status;
         vg_editBSecondName->Visible = !pi[1].status;
         break;
      case REASON_DOPUSH_FIO:
      case REASON_CHNG_LICENCE_DOP:
         frmAddPermitted->rgPmSex->Properties->Options->Editing = reasons_surcharge[1].select;
         frmAddPermitted->deditPmBirthDate->Properties->Options->Editing = reasons_surcharge[1].select;
         frmAddPermitted->deditPmStartDriving->Properties->Options->Editing = reasons_surcharge[1].select;
         gridDopush->Checkboxes = reasons_surcharge[1].select;
         btnDopushEdit->Visible = true;
         vg_HeadPermitted->Visible = true;
         vg_cboxMultyDrive->Visible = true;
         gridDopush->Visible = true;
         vg_HeadGrid->Visible = true;
         break;
      case REASON_CHNG_GOS_REG_ZNAK:
         vgHeadVehicle->Visible = true;
         vg_cboxRegistration->Visible = true;
         vg_editRegPlate->Visible = true;
         break;
      case REASON_CHNG_VIN:
         vgHeadVehicle->Visible = true;
         vg_cboxIdentType->Visible = true;
         vg_editTSVIN->Visible = true;
         break;
      case REASON_CHNG_INS_ADDRESS:
         vgHeadInsured->Visible = true;
         vg_editAddress->Visible = true;
         break;
      case REASON_CHNG_INS_DOC:
         vgHeadInsured->Visible = true;
         vg_DocType->Visible = true;
         vg_editDocSeries->Visible = true;
         vg_editDocNumber->Visible = true;
         vg_editDocDate->Visible = true;
         vg_editDocOrg->Visible = true;
         break;
      case REASON_CHNG_REG_DOC_VEH:
         vgHeadVehicle->Visible = true;
         vg_cboxDocVehicle->Visible = true;
         vg_editVehicleDocSeries->Visible = true;
         vg_editVehicleDocNumber->Visible = true;
         vg_editVehicleDocDate->Visible = true;
         break;
      case REASON_COMPENSATION:
         vg_HeadTerms->Visible = true;
         vg_cboxVozmType->Visible = true;
         ////////////////////////////////
         //is_surcharge_recalc;
         //is_surcharge_constant;
         di->no_calc = DO_RECALC_USING_UFO;
         break;
      case REASON_CHNG_PAYTIME:
         vg_HeadTerms->Visible = true;
         vg_cboxCredit->Visible = true;
         vg_editPayment1->Visible = true;
         vg_editPayment2->Visible = payment_count > 1;
         vg_editPayment3->Visible = payment_count > 2;
         break;
      case REASON_CHNG_INS:
         vgHeadInsured->Visible = true;
         vg_editLastName->Visible = true;
         vg_editFirstName->Visible = true;
         vg_editSecondName->Visible = true;
         vg_editBirthDate->Visible = true;
         vg_DocType->Visible = true;
         vg_editDocSeries->Visible = true;
         vg_editDocNumber->Visible = true;
         vg_editDocDate->Visible = true;
         vg_editDocOrg->Visible = true;
         vg_editAddress->Visible = true;
         //* ������ - ��������� � 9
         // ��� ������ ������� �������������� "������ ������������"
         // ���������� ���� "�������������������", ���� �������� ���� ����� ������
         vgHeadBenefic->Visible = true;
         vg_editBStatus->Visible = true;
         vg_editBLastName_or_Organization->Visible = true;
         vg_editBLastName_or_Organization->Properties->Caption = pi[1].status ? "������������ ����������� / ��" : "�������";
         vg_editBFirstName->Visible = !pi[1].status;
         vg_editBSecondName->Visible = !pi[1].status;
         //*/
         break;
      case REASON_TERRITORY_EXPAND:
         vg_HeadTerms->Visible      = true; //
         vg_cboxVozmType->Visible   = false;
         vg_cboxCredit->Visible     = false;
         vg_chkboxCountry->Visible  = true; //
         vg_cboxPeriod->Visible     = false;
      case REASON_CHNG_DEVICES:
         ADHead->Visible = true;
         gridAD->Visible = true;
         btnADPlus->Visible = true;
         btnADEdit->Visible = true;

         di->no_calc = DO_RECALC_USING_UFO;
         break;
   }

   if(gridAD->Visible)
   {
     for(int i = 0, n = gridAD->Items->Count; i < n; i++)
       if(gridAD->Items->Item[i]->Checked)
       {
         tsi->devices_state_id = 2;
         break;
       }
   }
   else
   {
     tsi->devices_state_id = 0;
   }
   
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::vgDrawRowHeader(TObject *Sender, TcxCanvas *ACanvas, TcxvgPainter *APainter, TcxCustomRowHeaderInfo *AHeaderViewInfo, bool &Done)
{
   int h(0), cnt_visible_rows(0);
   for(int i = 0, cnt = vg->Rows->Count; i < cnt; ++i){
      if(vg->IsRowVisible(vg->Rows->Items[i])){
         h += vg->Rows->Items[i]->Height;
         ++cnt_visible_rows;
      }
   }
   vg->Height = h + cnt_visible_rows + 5;

   int ADHeadHeight = vg->Height + (gridDopush->Items->Count * 19);
   ADHead->Top = ADHeadHeight;

   int t1 = vg_cboxMultyDrive->ViewInfo->RowRect.Top + 2, t2 = ADHead->Top;
   btnDopushPlus->Top = t1; btnADPlus->Top = t2;
   //btnDopushMinus->Top = t1;
   btnDopushEdit->Top = t1; btnADEdit->Top = t2;
   btnRequest->Top = vgCategoryRow3->ViewInfo->RowRect.Top + 1;
   //btnRequestUFO->Top = btnRequest->Top + btnRequest->Height + vg_AutorizationInfo->Height + 5;
   btnRequestUFO->Top = vgCategoryRowUfo->ViewInfo->RowRect.Top + 1;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesInitPopup(TObject *Sender)
{
   last_reasons = vg_Reason->Properties->Value;
}
//---------------------------------------------------------------------------
void TFReissCalc::LoadPerson(TADOQuery *q_p, _di_IXMLNode person, PersonInfo& pinf, const int type_person, const int calc_id)
{
   bool is_perm = type_person > 3;
   AnsiString ph_mob(""), ph_home(""), ph_rab(""), exact_address("");
   TDateTime q_dt(di->calc_date);
   int memo_id(0), sms(0);

   MakeKladrAddrFromUXML(m_api, person, pinf.kladr_addr, memo_id, exact_address);
   GetPhones(person->ChildNodes->FindNode("contacts"), ph_mob, ph_home, ph_rab, sms);

   q_p->FieldByName("calc_id")->Value = calc_id;
   q_p->FieldByName("status")->Value = pinf.status = NodeToStr(person->ChildNodes->FindNode("is_juridical")).ToIntDef(0);
   q_p->FieldByName("type_person")->Value = type_person;

   q_p->FieldByName("first_name")->Value = pinf.firstname = NodeToStr(person->ChildNodes->FindNode("first_name"));
   q_p->FieldByName("second_name")->Value = pinf.secondname = NodeToStr(person->ChildNodes->FindNode("second_name"));
   q_p->FieldByName("last_name")->Value = NodeToStr(person->ChildNodes->FindNode("last_name"));
   if(pinf.status) pinf.organization = q_p->FieldByName("last_name")->Value;
   else pinf.lastname = q_p->FieldByName("last_name")->Value;

   pinf.sms_sending = NodeToStr(person->ChildNodes->FindNode("sms_sending")).ToIntDef(-1);

   if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("physical_bitrh_date")), pinf.birthdate)){
      q_p->FieldByName("phisical_birth_date")->Value = pinf.birthdate;
      q_p->FieldByName("age")->Value = pinf.age = CalcYears(pinf.birthdate, q_dt);
   }
   q_p->FieldByName("phisical_sex")->Value = pinf.sex = NodeToStr(person->ChildNodes->FindNode("physical_sex")).ToIntDef(0) + 1;
   if(pinf.sex == 0) q_p->FieldByName("phisical_sex")->Value = pinf.sex = 1;
   q_p->FieldByName("addr_mid")->Value = memo_id;

   q_p->FieldByName("document_type_id")->Value = pinf.doc_type   = is_perm ? 17 : NodeToStr(person->ChildNodes->FindNode("document_type_id")).ToIntDef(12);
   q_p->FieldByName("document_series")->Value  = pinf.doc_seria  = is_perm ? NormVIN_GN(m_api, NodeToStr(person->ChildNodes->FindNode("license_series"))) : NodeToStr(person->ChildNodes->FindNode("document_series"));
   q_p->FieldByName("document_number")->Value  = pinf.doc_number = is_perm ? NodeToStr(person->ChildNodes->FindNode("license_number")) : NodeToStr(person->ChildNodes->FindNode("document_number"));
   if(is_perm){
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("driving_start_date")), pinf.doc_issue_date)){
         q_p->FieldByName("document_issue_date")->Value = pinf.doc_issue_date;
         q_p->FieldByName("experience")->Value = pinf.experience = CalcYears(pinf.doc_issue_date, q_dt);
      }
   }
   else{
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("document_issue_date")), pinf.doc_issue_date)) q_p->FieldByName("document_issue_date")->Value = pinf.doc_issue_date;
      q_p->FieldByName("address")->Value = pinf.address = exact_address;
   }
   q_p->FieldByName("document_issue_org")->Value = pinf.doc_issue_org = NodeToStr(person->ChildNodes->FindNode("document_issue_organization"));
   q_p->FieldByName("phone_mobil")->Value = pinf.phone_mobil = ph_mob;
   q_p->FieldByName("inn")->Value = pinf.inn = NodeToStr(person->ChildNodes->FindNode("inn"));
   q_p->FieldByName("ogrn")->Value = pinf.ogrn = NodeToStr(person->ChildNodes->FindNode("ogrn"));

   pinf.k6 = 1.7;
}
//---------------------------------------------------------------------------

void __fastcall TFReissCalc::btnRequestUFOClick(TObject *Sender)
{
//  FROM KASKO_UFO UCalc.cpp
//void __fastcall TframeCalc::btnCalcClick(TObject *Sender)

   di->calc_info.SetPremiumNull();
   di->ResetErrors();
   di->no_calc = NO_RECALC_USING_UFO;
   is_ufo_req_success = RECALC_UFO_ERR;

   AnsiString s_ser = di->polis_seria;
   AnsiString s_num = di->polis_number;

   ThreadUFO *thr_calc = new ThreadUFO(true, ufo_calc, m_api->vrGetVariable(res, "_mops_global_ufo_server_address_"), m_api, di, tsi, pi, pm);
   try
   {
      thr_calc->Resume();
      while(WaitForSingleObject((HANDLE)thr_calc->Handle, 0) == WAIT_TIMEOUT)
      {
         btnRequestUFO->Caption = "���� ������";
         if(!Sender) btnRequestUFO->Caption = "���� ��������";

         for(int i = 0; i < 3; ++i)
         {
            btnRequestUFO->Caption = btnRequestUFO->Caption + dot;
            Application->ProcessMessages();
            Sleep(333);
         }
      }
   }
   catch(Exception& ex){
      di->system_error = di->system_error + "\r\n" + ex.Message;
      di->no_calc = DO_RECALC_USING_UFO;
   }
   catch(...){
      di->system_error = di->system_error + "\r\n FATAL ERROR.";
      di->no_calc = DO_RECALC_USING_UFO;
   }

   delete thr_calc;

   btnRequestUFO->Caption = "������ �������";
   if(di->no_calc)
   {
     //btnRequestUFO->Caption = "������ ������� (���������� � �������!)";
     vg_UFOInfo->Properties->Value = "������ ������� (���������� � �������!)";
   }
   else
   {
     //if(di->validations_errors->Count == 0)
     if(di->system_error.IsEmpty())
     {
       //btnRequestUFO->Caption = "������ ������� (��������� �������)";
       vg_UFOInfo->Properties->Value = "������ ������� (��������� �������)";
     }
     else
     {
       //btnRequestUFO->Caption = "������ ������� (���������, �� ������ ������!)";
       vg_UFOInfo->Properties->Value = "������ ������� (���������, �� ������ ������!)";
     }
   }

   is_ufo_req_success = di->system_error.IsEmpty(); // ������, ���� � ������ ������ �����, ����� ������ �������

   //di->status_dogovor = di->non_standart_str_calc->Count ? 2 : 1;
   di->calc_info.premiya_osn_risk_ufo = di->calc_info.premiya_osn_risk;

   Recalc();


   
   AnsiString s_ser_ = di->polis_seria;
   AnsiString s_num_ = di->polis_number;


   if(di->calc_info.premiya_osn_risk)
   {
        int count_permit = gridDopush->Items->Count;
        for (int i = 0; i < count_permit; ++i)
        {
            gridDopush->Items->Item[i]->SubItems->Strings[3] = pm[i].k1;
            gridDopush->Items->Item[i]->SubItems->Strings[4] = pm[i].k6;
        }

        //is_ufo_req_success = NO_RECALC_USING_UFO;  // ����������, ��� - ������� ������������� ����������� �����������
   }
   else
   {
     di->no_calc = DO_RECALC_USING_UFO;
   }

/*
   btnCalc->Caption = "���ר�";
   if(di->is_ander_login) f_andr_pan->ButtonCalcItem->Properties->Buttons->Items[0]->Caption = "�����������!";
   Enabled = true;

   btnApproveList1->Enabled  = !di->no_calc && di->non_standart_str_calc->Count;
   btnApproveList1->Caption  = (!di->no_calc && di->non_standart_str_calc->Count) ? "���� ������� ��� ������������ ��������. ��� ������ ������ ������ ������� �� ����." : "������ ��� ������������ �������� ���";
   labInfoNoStandart->Height = (!di->no_calc && di->non_standart_str_calc->Count) ? 40 : 1;
*/

//*//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
}

//---------------------------------------------------------------------------


//tsi
void __fastcall TFReissCalc::btnRequestClick(TObject *Sender)
{
//#if 0
   Enabled = is_autorization = is_surcharge_recalc = is_surcharge_constant = 0;
   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);

   try
   {
      Root->ChildNodes->Clear();

      Root->AddChild("pol_ser")->Text = di->polis_seria;
      Root->AddChild("pol_num")->Text = di->polis_number;
      Root->AddChild("pol_zakl_date")->Text = di->polis_date.FormatString("dd.mm.yyyy");
      //Root->AddChild("contract_id")->Text = L"5001336275306014813c15772";
      //Root->AddChild("user_skk")->Text = "1111";

      AnsiString xml_result(""), st, str, lname, fname, sname, bank_code;

      Thread_APO2_ARM_READER *thr_getdata = new Thread_APO2_ARM_READER(true, 2, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"), XMLDoc->GetXML()->Text, &xml_result);
      thr_getdata->Resume();
      while(WaitForSingleObject((HANDLE)thr_getdata->Handle, 0) == WAIT_TIMEOUT)
      {
         btnRequest->Caption = "���� ������ � ���";
         for(int i = 0; i < 3; ++i)
         {
            btnRequest->Caption = btnRequest->Caption + dot;
            Application->ProcessMessages();
            Sleep(333);
         }
      }
      delete thr_getdata;

      _di_IXMLDocument XMLDoc_Response = NewXMLDocument();

      XMLDoc_Response->Active = true;
      XMLDoc_Response->LoadFromXML(xml_result);
      //if(m_api->is_debug) XMLDoc_Response->Save]ToFile("F:\\test_reiss.xml");
      if(m_api->is_debug) XMLDoc_Response->SaveToFile("C:\\Users\\Public\\test_reiss.xml");


      _di_IXMLNode root_response = XMLDoc_Response->DocumentElement, policy, person, vehicle, risks, casco_coeffs, paymentshedules, child_node, error_node, bank, blank, agreements;

      error_node = root_response->ChildNodes->FindNode("Error");
	  if (error_node)
	  {
		  vg_AutorizationInfo->Properties->Value = error_node->Text;
	  }
	  else
	  {
         policy = root_response->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy");
         person = policy->ChildNodes->FindNode("persons");
         vehicle = policy->ChildNodes->FindNode("autovehicles")->ChildNodes->FindNode("autovehicle");
         risks = vehicle->ChildNodes->FindNode("riskobjects");
         casco_coeffs = vehicle->ChildNodes->FindNode("casco_coefficients");
         paymentshedules = policy->ChildNodes->FindNode("paymentshedules");
         bank = policy->ChildNodes->FindNode("bank_broker");
         blank = policy->ChildNodes->FindNode("blanks")->ChildNodes->FindNode("blank");
         agreements = policy->ChildNodes->FindNode("agreements");

         int i_val, dsago_terr_id, memo_id, calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
         double d_val;
         TDateTime dt, q_dt, quotes_date = TDateTime(di->calc_date), dt_s, dt_e;

         di->product_id = NodeToStr(policy->ChildNodes->FindNode("product_class_id")).ToIntDef(301);
         if(di->product_id == 304 || di->product_id == 305 || di->product_id == 306 || di->product_id == 335)
		 {
            delete XMLDoc_Response;
            btnRequest->Caption = "������������ ������� (��������� � ���)";
            vg_AutorizationInfo->Properties->Value = "������� ������ � ���";
            Enabled = true;
            Recalc();
            return;
         }

         ShortDateFormat = "yyyy.MM.dd";

         TADOQuery *q_save = m_api->dbGetCursor(res, "select * from casco_calc where calc_id=" + IntToStr(calc_id), 0, 0);
         q_save->CursorLocation = clUseServer;
         q_save->Open();
         q_save->Edit();

         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_date")), q_dt))  q_save->FieldByName("polis_date")->Value = q_dt;
         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("quotes_date")), q_dt))  q_save->FieldByName("quotation_date")->Value = q_dt;
         di->calc_date = quotes_date.DateString();

         currency = NodeToStr(policy->ChildNodes->FindNode("currency_type"));
         if(currency.IsEmpty()) currency = "RUR";
         q_save->FieldByName("valuta")->Value = currency;

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("territory")), i_val)){
            q_save->FieldByName("region_id")->Value = di->region_id = i_val;
            di->REGION_TYPE = m_api->dbGetIntFromQuery(res, "select type_id from gl_dict_dsago_contract where cnt_cl_id=5 and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date and terr_id=" + IntToStr(i_val));
            dsago_terr_id = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_terr_osago_kasko where map_id=" + IntToStr(di->region_id));
            ChangeMultiDrive();
         }

         ////////////////////////////////////////////////////////////////////
         // ����� ������������ ���������� �������� ��� ������, ��� ... ����� ����� ��� ����� ����������� ���� �����.
         m_api->dbExecuteQuery(res, "delete * from casco_devices_r where calc_id=" + IntToStr(calc_id));
         //������� ���������� ������ � ������ ����� => ������� grid � �����.
         int count_devices = gridAD->Items->Count;
         for(int ii = 0; ii < count_devices; ++ii)
         {
           adevice[ii].Reset();
           gridAD->Items->Delete(ii);
           //gridAD->Items->Clear(); // (���� �������� � ������, � ������ �� ������������, �� ����������������� ������, ��� ������ ���� � �� ���������� ����)
         }


         if(person)
         {
           m_api->dbExecuteQuery(res, "delete * from casco_persons_r where calc_id=" + IntToStr(calc_id));
           m_api->dbExecuteQuery(res, "delete * from casco_persons where [calc_id]=" + IntToStr(calc_id));

           //������� ���������� ������ � ������ ����� => ������� grid � �����.
	       int count_permit = gridDopush->Items->Count;
	       for(int ii = 0; ii < count_permit; ++ii)
           {
             pm[ii].Reset();
             gridDopush->Items->Delete(ii);
             //gridDopush->Items->Clear(); // (���� �������� � ������, � ������ �� ������������, �� ����������������� ������, ��� ������ ���� � �� ���������� ����)
           }
         }


         if(person)
         {
            TADOQuery *q_p = m_api->dbGetCursor(res, "select * from casco_persons where calc_id=" + IntToStr(calc_id), 0, 1);
            int index_perm(0);
            for(int i = 0, cnt = person->ChildNodes->Count; i < cnt; ++i)
            {
               child_node = person->ChildNodes->Get(i);
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_insured")), i_val))
               {
                  if(i_val)
                  {
                     q_p->Insert();
                     LoadPerson(q_p, child_node, pi[0], 1, calc_id);

                     vg_editLastName->Properties->Value = pi[0].lastname;
                     vg_editFirstName->Properties->Value = pi[0].firstname;
                     vg_editSecondName->Properties->Value = pi[0].secondname;
                     SetValueRowDateEdit(vg_editBirthDate, pi[0].birthdate);
                     int index_doc_type = DocType_ComboBoxItem->Properties->Items->IndexOfObject((TObject*)pi[0].doc_type);
                     if(index_doc_type == -1){
                        pi[0].doc_type = 12;
                        pi[0].doc_seria = pi[0].doc_number = pi[0].doc_issue_org = empty_str;
                        pi[0].doc_issue_date.Val = 0;
                        vg_editDocDate->Properties->Value = variant_null;
                        vg_editDocOrg->Properties->Value = empty_str;
                        vg_editDocSeries->Properties->Value = empty_str;
                        vg_editDocNumber->Properties->Value = empty_str;
                     }
                     if(pi[0].doc_type != 12){
                        vg_DocType->Properties->Value = DocType_ComboBoxItem->Properties->Items->Strings[index_doc_type];
                        //ChangeMask(DocSeries_MaskItem, DocNumber_MaskItem, vg_editDocSeries, vg_editDocNumber, pi, 0);
                        pi[0].doc_issue_date.Val = 0.0;
                        vg_editDocDate->Properties->Value = variant_null;
                        vg_editDocOrg->Properties->Value = pi[0].doc_issue_org = empty_str;
                     }
                     if(index_doc_type != -1){
                        vg_editDocSeries->Properties->Value = StringReplace(pi[0].doc_seria, space_str, empty_str, rf);
                        vg_editDocNumber->Properties->Value = pi[0].doc_number;
                        if(pi[0].doc_issue_date.Val) vg_editDocDate->Properties->Value = pi[0].doc_issue_date;
                        vg_editDocOrg->Properties->Value = pi[0].doc_issue_org;
                     }
                     vg_editAddress->Properties->Value = pi[0].address;
                  }
               }
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_beneficiary")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, pi[1], 2, calc_id);
                     vg_editBStatus->Properties->Value = BeneficStatus_ComboBoxItem->Properties->Items->Strings[pi[1].status];
                     vg_editBLastName_or_Organization->Properties->Value = pi[1].status ? pi[1].organization : pi[1].lastname;
                     vg_editBFirstName->Properties->Value  = pi[1].firstname;
                     vg_editBSecondName->Properties->Value = pi[1].secondname;
                  }
               }
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_permitted")), i_val)){
                  if(i_val){
/*    TListItem *new_item = gridDopush->Items->Add();
      new_item->Caption = count_permit + 1;
      pm[count_permit].permitted_check = 1; //set checked by default
      new_item->SubItems->Add(AnsiString(frmAddPermitted->rgPmSex->Properties->Value).SubString(1, 1));
      new_item->SubItems->Add(pm[count_permit].lastname + space_str + pm[count_permit].firstname.SubString(1, 1) + dot + space_str + pm[count_permit].secondname.SubString(1, 1) + dot); //���
      new_item->SubItems->Add(IntToStr(pm[count_permit].age) + "/" + IntToStr(pm[count_permit].experience));
	  new_item->SubItems->Add(AnsiString("-"));
	  new_item->SubItems->Add(AnsiString("-"));
	  new_item->Checked = true;
      gridDopush->Height = 25 + (gridDopush->Items->Count - 1) * 19;
      gridDopush->Invalidate();

      di->count_permitted = count_permit + 1;
      Recalc();
      di->no_calc = DO_RECALC_USING_UFO; // ��������� => �������������
*/
                     q_p->Insert();
                     LoadPerson(q_p, child_node, pm[index_perm], index_perm + 4, calc_id);
                     K1(m_api, index_perm, pm, di);

                     TListItem *new_item = gridDopush->Items->Add();
                     new_item->Caption = index_perm + 1;
                     //new_item->Checked = pm[index_perm].permitted_check = true;
                     new_item->Checked = pm[index_perm].permitted_check = true;
					 new_item->Checked = true;
					 if(pm[index_perm].sex > 0) new_item->SubItems->Add((pm[index_perm].sex == 1) ? "�" : "�");
                     else              new_item->SubItems->Add(empty_str);
                     new_item->SubItems->Add(pm[index_perm].lastname + space_str + pm[index_perm].firstname.SubString(1, 1) + dot + space_str + pm[index_perm].secondname.SubString(1, 1) + dot);
                     new_item->SubItems->Add(q_p->FieldByName("age")->AsString + "/" + q_p->FieldByName("experience")->AsString);
                     //new_item->SubItems->Add(pm[index_perm].k1);
					 new_item->SubItems->Add(AnsiString("-"));
					 //new_item->SubItems->Add(pm[index_perm].k6);
					 new_item->SubItems->Add(AnsiString("-"));

					 ++index_perm;
                  }
               }
            }
            di->count_permitted = index_perm;

            q_p->UpdateBatch();
            m_api->dbCloseCursor(res, q_p);
            gridDopush->Height = 25 + (gridDopush->Items->Count - 1) * 19;
         }

         vg_Phone->Properties->Value    = pi[0].phone_mobil;
         vg_Document->Properties->Value = pi[0].status > 0 ? pi[0].inn : ("�����: " + pi[0].doc_seria + ", �����: " + pi[0].doc_number + ", �����: " + pi[0].doc_issue_org + space_str + pi[0].doc_issue_date.DateString());
         vg_Address->Properties->Value  = pi[0].address;
         vg_Name->Properties->Value     = Trim(pi[0].status ? pi[0].organization : (pi[0].lastname + space_str + pi[0].firstname + space_str + pi[0].secondname));

         q_save->FieldByName("status_idx")->Value = pi[0].status;
         q_save->FieldByName("fio")->Value = vg_Name->Properties->Value;
         q_save->FieldByName("sms_sending")->Value = pi[0].sms_sending;

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("is_pledged_property")), i_val)){
            q_save->FieldByName("source_id")->Value = i_val;
            if(q_save->FieldByName("source_id")->AsInteger){
               if(bank->HasAttribute("bank_code")) bank_code = bank->Attributes["bank_code"];
               q_save->FieldByName("bank_id")->Value = di->bank_id = m_api->dbGetIntFromQuery(res, "select bank_id from gl_dict_banks where (bank_code='" + bank_code + "' or bank_name='" + AnsiString(bank->Text) + "') and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date");
               if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("is_first_risk")), i_val)){
                  if(i_val == 1 && (di->product_id == 301 || di->product_id == 304)) q_save->FieldByName("full_insur")->Value = 3;
               }
            }
         }

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("vehicle_type_id")), i_val))
         {
           q_save->FieldByName("tstype_id")->Value = i_val;
           int v = i_val;
           tsi->vehicle_type_id = i_val;
         }
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("allowed_mass")), i_val))
         {
           q_save->FieldByName("max_massa")->Value  = i_val;
           int v = i_val;
           tsi->allowed_mass = i_val;
         }
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("number_of_seats")), i_val))
         {
           q_save->FieldByName("seat_count")->Value = i_val;
         }

/* // TSInfo
		 q_save->FieldByName("ts_marka")->Value = tsi->ts_marka = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_brand_name"));
         q_save->FieldByName("ts_model")->Value = tsi->ts_model = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_model_name"));
         if(TryStrToFloat(NodeToStr(vehicle->ChildNodes->FindNode("rsa_code")), d_val)){
            q_save->FieldByName("ts_model_id")->Value = tsi->model_id = d_val;
            q_save->FieldByName("ts_marka_calc")->Value = m_api->dbGetStringFromQuery(res, "select brand_name from gl_dict_carrier_models where val(code)=" + FloatToStr(d_val));
         }

         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("construction_date")), dt)) q_save->FieldByName("ts_year")->Value = tsi->ts_year = YearOf(dt);
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("is_new_vehicle")), i_val)) q_save->FieldByName("ts_novoe")->Value = i_val;

         // ����������� �������� ��
         tsi->ts_age = YearOf(q_dt) - tsi->ts_year;
         if(q_save->FieldByName("ts_novoe")->AsBoolean && tsi->ts_age == 1) tsi->ts_age = 0;
         else q_save->FieldByName("ts_novoe")->AsBoolean = false;

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("vehicle_group")), i_val)){
            tsi->group_ts = i_val;
            q_save->FieldByName("group_str")->Value = StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(tsi->group_ts)), "������ ", empty_str, rf);
         }

         AnsiString rgpl = m_api->Translit_Text(res, NodeToStr(vehicle->ChildNodes->FindNode("registration_mark")), true);
         if(rgpl.Length() > 7){
            q_save->FieldByName("is_registration_ts")->Value = 1;
            q_save->FieldByName("ts_znak")->Value = tsi->ts_znak = rgpl;
            q_save->FieldByName("region_isp_id")->Value = region_isp_id = rgpl.SubString(7, rgpl.Length() - 6).ToIntDef(0);
            vg_cboxRegistration->Properties->Value = "��";
            RegPlate_MaskItem->Properties->EditMask = "[0-9������������D������������d]{6}[0-9]{2}|[0-9������������D������������d]{6}[0-9]{3}";
            vg_editRegPlate->Properties->Value = rgpl;
         }
         else{
            vg_cboxRegistration->Properties->Value = "���";
            RegPlate_MaskItem->Properties->EditMask = empty_str;
            vg_editRegPlate->Properties->Value = rgpl;
         }
         
         AnsiString ident_number = NodeToStr(vehicle->ChildNodes->FindNode("vin"));
         if(ident_number.IsEmpty()){
            ident_number = NodeToStr(vehicle->ChildNodes->FindNode("chassis_number"));
            if(ident_number.IsEmpty()){
               ident_number = NodeToStr(vehicle->ChildNodes->FindNode("body_number"));
               if(!ident_number.IsEmpty()){
                  q_save->FieldByName("ident_type")->Value = tsi->ts_ident_type = 1;
                  vg_cboxIdentType->Properties->Value = "� ������(�����, ���������)";
                  VIN_MaskItem->Properties->EditMask = empty_str;
               }
            }
            else{
               q_save->FieldByName("ident_type")->Value = tsi->ts_ident_type = 1;
               vg_cboxIdentType->Properties->Value = "� ������(�����, ���������)";
               VIN_MaskItem->Properties->EditMask = empty_str;
            }
         }
         else{
            q_save->FieldByName("ident_type")->Value = tsi->ts_ident_type = 0;
            vg_cboxIdentType->Properties->Value = "VIN";
            VIN_MaskItem->Properties->EditMask = "[0-9ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz]{17}";
         }

         q_save->FieldByName("ts_vin")->Value = tsi->ts_vin = ident_number;
         vg_editTSVIN->Properties->Value = tsi->ts_vin;
//*/
		 q_save->FieldByName("ts_marka")->Value = tsi->vehicle_brand_name = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_brand_name"));
		 q_save->FieldByName("ts_model")->Value = tsi->vehicle_model_name = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_model_name"));
		 if (TryStrToFloat(NodeToStr(vehicle->ChildNodes->FindNode("rsa_code")), d_val)) {
			 q_save->FieldByName("ts_model_id")->Value = tsi->rsa_code = d_val; // difference
			 q_save->FieldByName("ts_marka_calc")->Value = m_api->dbGetStringFromQuery(res, "select brand_name from gl_dict_carrier_models where val(code)=" + FloatToStr(d_val));
		 }

		 if (TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("construction_date")), dt)) q_save->FieldByName("ts_year")->Value = tsi->construction_year = YearOf(dt);
		 if (TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("is_new_vehicle")), i_val)) q_save->FieldByName("ts_novoe")->Value = i_val;

		 // ����������� �������� ��
		 tsi->vehicle_age = YearOf(q_dt) - tsi->construction_year;
		 if (q_save->FieldByName("ts_novoe")->AsBoolean && tsi->vehicle_age == 1) tsi->vehicle_age = 0;
		 else q_save->FieldByName("ts_novoe")->AsBoolean = false;

		 if (TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("vehicle_group")), i_val)) {
			 tsi->vehicle_group = i_val;
			 q_save->FieldByName("group_str")->Value = StringReplace(m_api->dbGetStringFromQuery(res, "select group_name from tar_gr where id_group=" + IntToStr(tsi->vehicle_group)), "������ ", empty_str, rf);
		 }

		 AnsiString rgpl = m_api->Translit_Text(res, NodeToStr(vehicle->ChildNodes->FindNode("registration_mark")), true);
		 if (rgpl.Length() > 7) {
			 q_save->FieldByName("is_registration_ts")->Value = 1;
			 q_save->FieldByName("ts_znak")->Value = tsi->registration_mark = rgpl;
			 q_save->FieldByName("region_isp_id")->Value = region_isp_id = rgpl.SubString(7, rgpl.Length() - 6).ToIntDef(0);
			 vg_cboxRegistration->Properties->Value = "��";
			 RegPlate_MaskItem->Properties->EditMask = "[0-9������������D������������d]{6}[0-9]{2}|[0-9������������D������������d]{6}[0-9]{3}";
			 vg_editRegPlate->Properties->Value = rgpl;
		 }
		 else {
			 vg_cboxRegistration->Properties->Value = "���";
			 RegPlate_MaskItem->Properties->EditMask = empty_str;
			 vg_editRegPlate->Properties->Value = rgpl;
		 }

		 AnsiString ident_number = NodeToStr(vehicle->ChildNodes->FindNode("vin"));
		 if (ident_number.IsEmpty()) {
			 ident_number = NodeToStr(vehicle->ChildNodes->FindNode("chassis_number"));
			 if (ident_number.IsEmpty()) {
				 ident_number = NodeToStr(vehicle->ChildNodes->FindNode("body_number"));
				 if (!ident_number.IsEmpty()) {
					 //q_save->FieldByName("ident_type")->Value = tsi->ts_ident_type = 1;
					 vg_cboxIdentType->Properties->Value = "� ������(�����, ���������)";
					 VIN_MaskItem->Properties->EditMask = empty_str;
				 }
			 }
			 else {
				 //q_save->FieldByName("ident_type")->Value = tsi->ts_ident_type = 1;
				 vg_cboxIdentType->Properties->Value = "� ������(�����, ���������)";
				 VIN_MaskItem->Properties->EditMask = empty_str;
			 }
		 }
		 else {
			 //q_save->FieldByName("ident_type")->Value = tsi->ts_ident_type = 0;
			 vg_cboxIdentType->Properties->Value = "VIN";
			 VIN_MaskItem->Properties->EditMask = "[0-9ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz]{17}";
		 }

		 q_save->FieldByName("ts_vin")->Value = tsi->vin = ident_number;
		 vg_editTSVIN->Properties->Value = tsi->vin;
////////////////////////////////////////////////////////////////////////////
		 q_save->FieldByName("ts_cost")->Value = di->calc_info.cost_vehicle = StrToFloatStr(NodeToStr(vehicle->ChildNodes->FindNode("actual_value"))).ToDouble();

         // #OPA 21.12.2017 - ���������� ��� ����� ��� ��� �������, �������� ����.
         //if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("alarms")), i_val)) q_save->FieldByName("alarms_info")->Value = i_val;
         //q_save->FieldByName("real_alarm")->Value = NodeToStr(vehicle->ChildNodes->FindNode("alarm_systems"));

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("limited_drivers")), i_val)){
            if(i_val != 1){
               q_save->FieldByName("bez_ogr")->Value = true;
               q_save->FieldByName("multidrive")->Value = di->type_multydrive = i_val;
               int index_md = GetIndexObject(MultyDrive_ComboBoxItem->Properties->Items, i_val);
               if(index_md > -1){
                  vg_cboxMultyDrive->Properties->Value = MultyDrive_ComboBoxItem->Properties->Items->Strings[index_md];
                  di->calc_info.k1 = ((DataDict*)MultyDrive_ComboBoxItem->Properties->Items->Objects[index_md])->coeff_value;
               }
            }
            else{ di->type_multydrive = 100; vg_cboxMultyDrive->Properties->Value = "������������ ������ ���������"; }
         }
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("trailer")), i_val)) q_save->FieldByName("ts_pricep")->AsBoolean = i_val;

         for(int i = 0, cnt = casco_coeffs->ChildNodes->Count; i < cnt; ++i){
            child_node = casco_coeffs->ChildNodes->Get(i);
            if(TryStrToInt(child_node->Attributes["coefficient_id"], i_val))
               switch(i_val){
                  case 14:
                     if(TryStrToFloat(StrToFloatStr(child_node->Attributes["value"]), d_val)) q_save->FieldByName("ka")->Value = di->calc_info.ka = d_val;
                     break;
                  case 23:
                     if(TryStrToFloat(StrToFloatStr(child_node->Attributes["value"]), d_val)) q_save->FieldByName("kpr")->Value = di->calc_info.kpr = d_val;
                     break;
                  case 29:
                     if(TryStrToFloat(StrToFloatStr(child_node->Attributes["value"]), d_val)){
                        q_save->FieldByName("ks")->Value = di->calc_info.ks = d_val;
                        q_save->FieldByName("kkv")->Value = 100.0 - d_val * 100.0;
                     }
                     break;
               }
         }
         if(di->product_id > 303 && di->product_id < 307) q_save->FieldByName("variant_idx")->Value = di->product_id > 303 ? (di->product_id - 304) : (di->product_id - 301);
         else q_save->FieldByName("variant_idx")->Value = 0;

         bool is_kasko(false);
         for(int i = 0, cnt = risks->ChildNodes->Count; i < cnt; ++i){
            child_node = risks->ChildNodes->Get(i);
            st = AnsiString(child_node->Attributes["risk_object_type_id"]);
            if(!st.IsEmpty()){
               TADOQuery* q_r = m_api->dbGetCursor(res, "select top 1 [risk_id],[risk_code],[product_id] from cascotariff where ([risk_code] like '%" + st + "%') order by [risk_id]");
               if(!q_r->IsEmpty()){
                  switch(q_r->FieldByName("risk_id")->AsInteger){
                     case 1:
                        if(!is_kasko){
                           q_save->FieldByName("risk_id")->Value = di->risk = q_r->FieldByName("risk_id")->AsInteger;
                           q_save->FieldByName("risk_main")->Value = q_r->FieldByName("risk_code")->AsString;
                           q_save->FieldByName("tariff")->Value = StrToFloatStr(child_node->Attributes["tariff"]).ToDouble();
                           q_save->FieldByName("str_summa")->Value = di->calc_info.str_summa = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                           q_save->FieldByName("premium_main_risk")->Value = di->calc_info.premiya_osn_risk = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                           q_save->FieldByName("type_franshiza")->Value = AnsiString(child_node->Attributes["franchise_id"]).ToIntDef(1);
                           if(q_save->FieldByName("type_franshiza")->AsInteger == 3){
                              q_save->FieldByName("franshiza_unit")->Value = child_node->HasAttribute("franchiseunit_id") ? AnsiString(child_node->Attributes["franchiseunit_id"]).ToIntDef(2) : 2;
                              q_save->FieldByName("franshiza")->Value = q_save->FieldByName("franshiza_unit")->AsInteger == 2 ? AnsiString(child_node->Attributes["franchise_size"]).ToIntDef(0) : AnsiString(child_node->Attributes["franchise_sum"]).ToIntDef(0);
                              //q_save->FieldByName("franshiza_unit")->Value = 2;
                              //q_save->FieldByName("franshiza")->Value = AnsiString(child_node->Attributes["franchise_size"]);
                           }
                        }
                        break;
                     case 2:
                        is_kasko = true;
                        q_save->FieldByName("risk_id")->Value = di->risk = q_r->FieldByName("risk_id")->AsInteger;
                        q_save->FieldByName("risk_main")->Value = q_r->FieldByName("risk_code")->AsString;
                        q_save->FieldByName("tariff")->Value = StrToFloatStr(child_node->Attributes["tariff"]).ToDouble();
                        q_save->FieldByName("str_summa")->Value = di->calc_info.str_summa = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_main_risk")->Value = di->calc_info.premiya_osn_risk = StrToFloatStr(child_node->Attributes["premium"]).ToDouble() * 2;
                        q_save->FieldByName("type_franshiza")->Value = AnsiString(child_node->Attributes["franchise_id"]).ToIntDef(1);
                        if(q_save->FieldByName("type_franshiza")->AsInteger == 3){
                           q_save->FieldByName("franshiza_unit")->Value = child_node->HasAttribute("franchiseunit_id") ? AnsiString(child_node->Attributes["franchiseunit_id"]).ToIntDef(2) : 2;
                           q_save->FieldByName("franshiza")->Value = q_save->FieldByName("franshiza_unit")->AsInteger == 2 ? AnsiString(child_node->Attributes["franchise_size"]).ToIntDef(0) : AnsiString(child_node->Attributes["franchise_sum"]).ToIntDef(0);
                           //q_save->FieldByName("franshiza_unit")->Value = 2;
                           //q_save->FieldByName("franshiza")->Value = AnsiString(child_node->Attributes["franchise_size"]);
                        }

                        premia_di = 0;
                        premia_di_str = 0;

                        premia_di = di->calc_info.premiya_osn_risk;
                        premia_di_str = StrToFloatStr(child_node->Attributes["premium"]).ToDouble() * 2;

                        break;
                     case 4:
                        q_save->FieldByName("select_ns")->Value = true;
                        q_save->FieldByName("risk_ns")->Value = st;
                        q_save->FieldByName("ns_variant")->Value = 0;
                        q_save->FieldByName("ns_summa")->Value =  StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_ns")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                        break;
                     case 5:
                        q_save->FieldByName("select_dsago")->Value = true;
                        q_save->FieldByName("risk_dsago")->Value = st;
                        q_save->FieldByName("dsago_territory_id")->Value = dsago_terr_id;
                        q_save->FieldByName("dsago_city_id")->Value = m_api->dbGetIntFromQuery(res, "select terr_id from gl_dict_osagoterritorycoeff where Date()>=start_date and Date()<=end_date and parent_id=" + IntToStr(dsago_terr_id));
                        q_save->FieldByName("dsago_summa")->Value = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_dsago")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                        break;
                     case 6:
                        q_save->FieldByName("select_dms")->Value = true;
                        q_save->FieldByName("dms_summa")->Value = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();
                        q_save->FieldByName("premium_dms")->Value = StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
                        break;
                  }
               }
               m_api->dbCloseCursor(res, q_r);
            }
         }

         if(q_save->FieldByName("ts_cost")->AsFloat > q_save->FieldByName("str_summa")->AsFloat && q_save->FieldByName("full_insur")->AsInteger != 3) q_save->FieldByName("full_insur")->AsInteger = 2;

         q_save->FieldByName("premiya_all")->AsFloat = q_save->FieldByName("premium_main_risk")->AsFloat + q_save->FieldByName("premium_ns")->AsFloat + q_save->FieldByName("premium_dsago")->AsFloat + q_save->FieldByName("premium_dms")->AsFloat;

         // ����������� �� ��������� ������ �� gap � ����������
         is_gap = false;

         di->calc_info.kss_old = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictkss where (veh_model_id=%i or veh_model_id=0) and (veh_age=%i or veh_age is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by veh_model_id desc, veh_age desc", tsi->rsa_code, tsi->vehicle_age, di->polis_date.DateString(), di->polis_date.DateString()), 1.0, false); // difference RSA
         di->calc_info.str_summa1 = di->calc_info.str_summa / di->calc_info.kss_old;
         double cost_vehicle1 = di->calc_info.cost_vehicle / di->calc_info.kss_old;
         LoadKssData();
         for(int i = 0, cnt = agreements->ChildNodes->Count; i < cnt; ++i){
            child_node = agreements->ChildNodes->Get(i);
            if(TryStrToInt(child_node->Attributes["agreement_type_id"], i_val))
			{
/* // TSInfo
				if(!tsi->ts_age && agreement_type_id_ss.count(i_val) && TryStrToDateTime(child_node->Attributes["agreement_start_date"], dt))
*/
				if(!tsi->vehicle_age && agreement_type_id_ss.count(i_val) && TryStrToDateTime(child_node->Attributes["agreement_start_date"], dt))
				{
                  di->calc_info.kss_old = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictkss where (veh_model_id=%i or veh_model_id=0) and (veh_age=%i or veh_age is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by veh_model_id desc, veh_age desc", tsi->rsa_code, tsi->vehicle_age, dt.DateString(), dt.DateString()), 1.0, false); // diference RSA
                  di->calc_info.str_summa1 = di->calc_info.str_summa / di->calc_info.kss_old;
                  cost_vehicle1 = di->calc_info.cost_vehicle / di->calc_info.kss_old;
               }

			   if(agreement_type_id_gap.count(i_val)) is_gap = true;
            }
         }
         di->calc_info.str_summa2 = m_api->Round(di->calc_info.str_summa1 * di->calc_info.kss_new);
         di->calc_info.cost_vehicle_new = m_api->Round(cost_vehicle1 * di->calc_info.kss_new);

         q_save->FieldByName("pay_id")->Value = di->pay_id = pay_id_arm = NodeToStr(policy->ChildNodes->FindNode("payment_method_id")).ToIntDef(0);
         LoadVozmType();
         
         q_save->FieldByName("ts_count")->Value = NodeToStr(policy->ChildNodes->FindNode("vehicle_count")).ToIntDef(0);
         q_save->FieldByName("project_id")->Value = di->project_id = NodeToStr(policy->ChildNodes->FindNode("project_id")).ToIntDef(0);
         q_save->FieldByName("programm_id")->Value = di->programm_id = NodeToStr(policy->ChildNodes->FindNode("program_id")).ToIntDef(0);
         contract_payed_count = NodeToStr(policy->ChildNodes->FindNode("contract_payed_count")).ToIntDef(0);

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("option_id")), i_val)){
            //q_save->FieldByName("dogovor_type")->Value = i_val;
            if(i_val == 2){
               di->contract_type = 1;
               q_save->FieldByName("prolong")->Value = true;
               //q_save->FieldByName("dogovor")->Value = "�������������";
               if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("preferential_extension")), i_val)) q_save->FieldByName("benefit_prolong")->Value = i_val;
            }
         }
         //q_save->FieldByName("usage_purpose_text")->Value = NodeToStr(vehicle->ChildNodes->FindNode("usage_purpose"));
         //q_save->FieldByName("usage_purpose")->Value      = q_save->FieldByName("usage_purpose_text")->AsString.IsEmpty() ? 0 : 1;

         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_start_date")), dt_s) && TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_end_date")), dt_e)){
            q_save->FieldByName("srok_date_s")->AsDateTime  = di->datesrok_s  = (int)dt_s;
            q_save->FieldByName("srok_date_po")->AsDateTime = di->datesrok_po = (int)dt_e;
            q_save->FieldByName("srok_time_s")->AsString    = dt_s.FormatString("hh:ss");
            q_save->FieldByName("srok_time_po")->AsString   = dt_e.FormatString("hh:ss");
            q_save->FieldByName("srok_month")->AsInteger    = di->monthcount = MonthsCount(di->datesrok_s, di->datesrok_po);
         }
         payment_count = 1;
         for(int i = 0, cnt = paymentshedules->ChildNodes->Count; i < cnt; ++i){
            if(i > 2) break;
            child_node = paymentshedules->ChildNodes->Get(i);
            st = IntToStr(payment_count = i + 1);
            q_save->FieldByName("vznos" + st)->Value = di->calc_info.payment_part[i] = StrToFloatStr(child_node->Attributes["expected_sum"]).ToDouble();
            if(TryStrToDateTime(child_node->Attributes["expected_date"], dt)) q_save->FieldByName("date_vznos" + st)->AsDateTime = di->payment_date[i] = dt;
         }
         vg_editPayment1->Properties->Value = "1-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[0]) + ", ���� - " + di->payment_date[0].DateString();
         if(q_save->FieldByName("vznos3")->AsFloat > 0){
            payment_count = 3;
            q_save->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=3 and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date and terr_type_id=" + IntToStr(di->REGION_TYPE) + " and (product_id=0 or product_id=" + IntToStr(di->product_id) + ") order by product_id desc");
            vg_editPayment2->Properties->Value = "2-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[1]) + ", ���� - " + di->payment_date[1].DateString();
            vg_editPayment3->Properties->Value = "3-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[2]) + ", ���� - " + di->payment_date[2].DateString();
         }
         else{
            vg_editPayment3->Properties->Value = empty_str;
            if(q_save->FieldByName("vznos2")->AsFloat > 0){
               payment_count = 2;
               q_save->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=2 and credit_month_min=1 and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date and terr_type_id=" + IntToStr(di->REGION_TYPE) + " and (product_id=0 or product_id=" + IntToStr(di->product_id) + ") order by product_id desc");
               vg_editPayment2->Properties->Value = "2-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[1]) + ", ���� - " + di->payment_date[1].DateString();
            }
            else{
               vg_editPayment2->Properties->Value = empty_str;
               q_save->FieldByName("krs_idx")->AsInteger = m_api->dbGetIntFromQuery(res, "select top 1 id_krs from cascodictk08 where payment_count_min=1 and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date and terr_type_id=" + IntToStr(di->REGION_TYPE) + " and (product_id=0 or product_id=" + IntToStr(di->product_id) + ") order by product_id desc");
            }
         }

         vg_cboxCredit->Properties->Value = m_api->dbGetStringFromQuery(res, "select credit_name from cascodictk08 where id_krs=" + q_save->FieldByName("krs_idx")->AsString);
         //LoadListCredits(payment_count);

         //������ �����-��� 
         int status = pi[0].status == 2 ? 35 : (pi[0].status + 1);

/* // TSInfo 
         // ������� �����
         di->calc_info.bt = m_api->dbGetFloatFromQuery(res, sql.sprintf("select coeff_val from gl_dict_cascobaserate where risk_id=%i and tertype_id=%i and veh_age=%i and product_id=%i and vehi_gr_id=%i"
        " and CDate('%s')>=start_date and CDate('%s')<=end_date", di->risk, di->REGION_TYPE, tsi->ts_age, di->product_id, tsi->group_ts, di->calc_date, di->calc_date));

		//K4
		 AnsiString marka_id = MarkaId(tsi->model_id), s;
		 if(!pi[0].status)
            switch(q_save->FieldByName("type_franshiza")->AsInteger){
               //case 3: di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk04 where fran_perc=%i and vehicle_group=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q_save->FieldByName("franshiza")->AsString.ToIntDef(0), tsi->group_ts, di->calc_date, di->calc_date), 1.0); break;
               case 3:
                  //s = sql.sprintf("select coeff_value from gl_dict_franshize where code_t_fr=%i and code_ed_izm_fr=%i and franchise_percent='%s' and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_group_id, product_id, casco_territory_id, code, project_id", 3, q_save->FieldByName("franshiza_unit")->AsInteger, q_save->FieldByName("franshiza")->AsString, tsi->group_ts, di->product_id, di->region_id, AddNulls(tsi->model_id), marka_id, di->project_id, di->programm_id, di->calc_date, di->calc_date);
                  di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from gl_dict_franshize where code_t_fr=%i and code_ed_izm_fr=%i and franchise_percent=%i and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_group_id, product_id, casco_territory_id, code, project_id", 3, q_save->FieldByName("franshiza_unit")->AsInteger, q_save->FieldByName("franshiza")->AsString.ToIntDef(0), tsi->group_ts, di->product_id, di->region_id, AddNulls(tsi->model_id), marka_id, di->project_id, di->programm_id, di->calc_date, di->calc_date), 1.0); break;
               //case 6: di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk04 where fran_perc=100 and vehicle_group=%i and (terr_id=0 or terr_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by terr_id desc", tsi->group_ts, di->region_id, di->calc_date, di->calc_date), 1.0); break;
               case 6: di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from gl_dict_franshize where code_t_fr=%i and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_group_id, product_id, casco_territory_id, code, project_id", 6, tsi->group_ts, di->product_id, di->region_id, AddNulls(tsi->model_id), marka_id, di->project_id, di->programm_id, di->calc_date, di->calc_date), 1.0); break;
               default: di->calc_info.k4 = 1.0;
            }


         //Kr
         di->calc_info.kr = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from gl_dict_cascokr where terr_id=%i and (product_id=%i or product_id=0) and (subtype_id=%i or subtype_id=0) and vehi_gr_id=%i and ((vehicle_age_min<=%i and vehicle_age_max>=%i) or vehicle_age_max is null)"
               " and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_age_max desc, product_id desc,subtype_id desc", di->region_id, di->product_id, status, tsi->group_ts, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date), 1.0);
         //Kar
         di->calc_info.kar = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select top 1 coeff_val from gl_dict_cascokar where terr_id=%i and (product_id=%i or product_id=0) and (vehgroup_id=%i or vehgroup_id=0) and subtype_id=%i and vehmod_id=%i and ((vehage_min<=%i and vehage_max>=%i) or vehage_max is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehage_min desc, vehage_max desc, product_id desc, vehgroup_id desc", di->region_id, di->product_id, tsi->group_ts, status, tsi->model_id, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date), 1.0, false);
*/

         // ������� �����
         di->calc_info.bt = m_api->dbGetFloatFromQuery(res, sql.sprintf("select coeff_val from gl_dict_cascobaserate where risk_id=%i and tertype_id=%i and veh_age=%i and product_id=%i and vehi_gr_id=%i"
        " and CDate('%s')>=start_date and CDate('%s')<=end_date", di->risk, di->REGION_TYPE, tsi->vehicle_age, di->product_id, tsi->vehicle_group, di->calc_date, di->calc_date));

		//�4
		//AnsiString marka_id = MarkaId(tsi->model_id), s; // difference
		AnsiString marka_id = MarkaId(StrToInt(tsi->rsa_code)), s; // difference
		 if (!pi[0].status)
			 switch (q_save->FieldByName("type_franshiza")->AsInteger) {
				 //case 3: di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk04 where fran_perc=%i and vehicle_group=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q_save->FieldByName("franshiza")->AsString.ToIntDef(0), tsi->vehicle_group, di->calc_date, di->calc_date), 1.0); break;
			 case 3:
				 //s = sql.sprintf("select coeff_value from gl_dict_franshize where code_t_fr=%i and code_ed_izm_fr=%i and franchise_percent='%s' and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_group_id, product_id, casco_territory_id, code, project_id", 3, q_save->FieldByName("franshiza_unit")->AsInteger, q_save->FieldByName("franshiza")->AsString, tsi->vehicle_group, di->product_id, di->region_id, AddNulls(tsi->rsa_code), marka_id, di->project_id, di->programm_id, di->calc_date, di->calc_date); // diference
				 di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from gl_dict_franshize where code_t_fr=%i and code_ed_izm_fr=%i and franchise_percent=%i and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_group_id, product_id, casco_territory_id, code, project_id", 3, q_save->FieldByName("franshiza_unit")->AsInteger, q_save->FieldByName("franshiza")->AsString.ToIntDef(0), tsi->vehicle_group, di->product_id, di->region_id, AddNulls(tsi->rsa_code), marka_id, di->project_id, di->programm_id, di->calc_date, di->calc_date), 1.0); break; // diference
				 //case 6: di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk04 where fran_perc=100 and vehicle_group=%i and (terr_id=0 or terr_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by terr_id desc", tsi->vehicle_group, di->region_id, di->calc_date, di->calc_date), 1.0); break;
			 case 6: di->calc_info.k4 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from gl_dict_franshize where code_t_fr=%i and (vehicle_group_id=%i or vehicle_group_id is null) and (product_id=%i or product_id is null) and (casco_territory_id=%i or casco_territory_id is null) and (code='%s' or code='%s' or code='' or code is null) and (project_id in(%i,%i) or project_id is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_group_id, product_id, casco_territory_id, code, project_id", 6, tsi->vehicle_group, di->product_id, di->region_id, AddNulls(tsi->rsa_code), marka_id, di->project_id, di->programm_id, di->calc_date, di->calc_date), 1.0); break; // difference
			 default: di->calc_info.k4 = 1.0;
			 }

/* // DISABLE_KOEFFS
		 //Kr
		 di->calc_info.kr = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from gl_dict_cascokr where terr_id=%i and (product_id=%i or product_id=0) and (subtype_id=%i or subtype_id=0) and vehi_gr_id=%i and ((vehicle_age_min<=%i and vehicle_age_max>=%i) or vehicle_age_max is null)"
			 " and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehicle_age_max desc, product_id desc,subtype_id desc", di->region_id, di->product_id, status, tsi->vehicle_group, tsi->vehicle_age, tsi->vehicle_age, di->calc_date, di->calc_date), 1.0);
		 //Kar
		 di->calc_info.kar = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select top 1 coeff_val from gl_dict_cascokar where terr_id=%i and (product_id=%i or product_id=0) and (vehgroup_id=%i or vehgroup_id=0) and subtype_id=%i and vehmod_id=%i and ((vehage_min<=%i and vehage_max>=%i) or vehage_max is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehage_min desc, vehage_max desc, product_id desc, vehgroup_id desc", di->region_id, di->product_id, tsi->vehicle_group, status, tsi->rsa_code, tsi->vehicle_age, tsi->vehicle_age, di->calc_date, di->calc_date), 1.0, false); // difference


         //Kpr
         if(q_save->FieldByName("programm_id")->AsInteger){
            q = m_api->dbGetCursor(res, sql.sprintf("select ka_min, ka_max from gl_dict_programm_project where project_id=%i and product_id=%i and (region_id=%i or region_id=116) and CDate('%s')>=start_date and CDate('%s')<=end_date and CDate('%s')>=start_date_coeff and CDate('%s')<=end_date_coeff order by region_id", q_save->FieldByName("programm_id")->AsInteger, di->product_id, di->region_id, di->calc_date, di->calc_date, di->calc_date, di->calc_date));
            if(q->FieldByName("ka_min")->AsFloat == q->FieldByName("ka_max")->AsFloat) q_save->FieldByName("kpr")->Value = di->calc_info.kpr = q->FieldByName("ka_min")->AsFloat;
            m_api->dbCloseCursor(res, q);
         }

         //Kb
         if(di->bank_id > 0) di->calc_info.kb = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from cascodictkb where terr_type_id=%i and (bank_id=0 or bank_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by bank_id desc", di->REGION_TYPE, di->bank_id, di->calc_date, di->calc_date), 1.0);
         else di->calc_info.kb = 1.0;

         //K3
         di->calc_info.k3 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk03 where srok_min<=%i and srok_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->monthcount, di->monthcount, di->calc_date, di->calc_date), 1.0);
//*/  // DISABLE_KOEFFS

/*       
		 // �7-�
         di->calc_info.k7 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q_save->FieldByName("pay_id")->AsInteger, di->REGION_TYPE, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date), 1.0);
         //���
         di->calc_info.krs = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from cascodictk08 where id_krs=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q_save->FieldByName("krs_idx")->AsInteger, di->calc_date, di->calc_date), 1.0);
         //kfr
         di->calc_info.coef_prop = m_api->Round((di->calc_info.cost_vehicle && di->calc_info.str_summa) ? di->calc_info.str_summa / di->calc_info.cost_vehicle : 1.00);
         if(q_save->FieldByName("full_insur")->AsInteger == 3 && di->calc_info.coef_prop <= 0.79) di->calc_info.kfr = GetKprSb(di->calc_info.coef_prop);
         else di->calc_info.kfr = 1.0;
         //kgap
         di->calc_info.kgap = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictgap where (vehi_gr_id=0 or vehi_gr_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehi_gr_id desc", tsi->group_ts, di->calc_date, di->calc_date), 1.0, false);
         //kdiscount
         di->calc_info.kdiscount = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictdiscount where (veh_group_id=0 or veh_group_id=%i) and (veh_model_id=0 or veh_model_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by veh_model_id desc, veh_group_id desc", tsi->group_ts, tsi->model_id, di->calc_date, di->calc_date), 1.0, false);
*/

/* // DISABLE_KOEFFS
		 // �7-�
         di->calc_info.k7 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q_save->FieldByName("pay_id")->AsInteger, di->REGION_TYPE, tsi->vehicle_age, tsi->vehicle_age, di->calc_date, di->calc_date), 1.0);
         //���
         di->calc_info.krs = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_value from cascodictk08 where id_krs=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", q_save->FieldByName("krs_idx")->AsInteger, di->calc_date, di->calc_date), 1.0);
         //kfr
         di->calc_info.coef_prop = m_api->Round((di->calc_info.cost_vehicle && di->calc_info.str_summa) ? di->calc_info.str_summa / di->calc_info.cost_vehicle : 1.00);
         if(q_save->FieldByName("full_insur")->AsInteger == 3 && di->calc_info.coef_prop <= 0.79) di->calc_info.kfr = GetKprSb(di->calc_info.coef_prop);
         else di->calc_info.kfr = 1.0;
         //kgap
         di->calc_info.kgap = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictgap where (vehi_gr_id=0 or vehi_gr_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by vehi_gr_id desc", tsi->vehicle_group, di->calc_date, di->calc_date), 1.0, false);
         //kdiscount
         di->calc_info.kdiscount = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictdiscount where (veh_group_id=0 or veh_group_id=%i) and (veh_model_id=0 or veh_model_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by veh_model_id desc, veh_group_id desc", tsi->vehicle_group, tsi->rsa_code, di->calc_date, di->calc_date), 1.0, false); // difference

//*/  // DISABLE_KOEFFS
		 /*-----------------------------------------------------------------------------------------------------------------------------------------------*/

         if(blank){
            if(TryStrToInt(blank->Attributes["blank_type_id"], i_val)){
               q_save->FieldByName("polis_id")->Value  = i_val;
               q_save->FieldByName("polis_name")->Value = m_api->dbGetStringFromQuery(res, "select bso_name from bso where bso_id=" + IntToStr(i_val));
            }
         }
         q_save->FieldByName("prev_seria")->Value  = NodeToStr(policy->ChildNodes->FindNode("prev_contract_series"));
         q_save->FieldByName("prev_number")->Value = NodeToStr(policy->ChildNodes->FindNode("prev_contract_number"));

/* // TSInfo
         q_save->FieldByName("ts_doc_type")->Value = tsi->type_doc_ts = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_registration_type_id")).ToIntDef(1);
         FieldValueIDToVGEditor(tsi->type_doc_ts, VehicleDocType_ComboBoxItem, vg_cboxDocVehicle);
         q_save->FieldByName("pts_seria")->Value = tsi->pts_series = NodeToStr(vehicle->ChildNodes->FindNode("registration_series"));
         vg_editVehicleDocSeries->Properties->Value = tsi->pts_series;
         q_save->FieldByName("pts_number")->Value = tsi->pts_number = NodeToStr(vehicle->ChildNodes->FindNode("registration_number"));
         vg_editVehicleDocNumber->Properties->Value = tsi->pts_number;
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("registration_issue_date")), dt)){
            q_save->FieldByName("pts_date")->Value = tsi->pts_date = dt;
            SetValueRowDateEdit(vg_editVehicleDocDate, tsi->pts_date);
            if(tsi->type_doc_ts == 1) q_save->FieldByName("pts_date_calc")->Value = dt;
         }
         q_save->FieldByName("ts_power")->Value = StrToFloatStr(NodeToStr(vehicle->ChildNodes->FindNode("engine_power_hp"))).ToDouble();
*/

         q_save->FieldByName("ts_doc_type")->Value = tsi->vehicle_registration_type_id = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_registration_type_id")).ToIntDef(1);
         FieldValueIDToVGEditor(tsi->vehicle_registration_type_id, VehicleDocType_ComboBoxItem, vg_cboxDocVehicle);
         //if(tsi->vehicle_registration_type_id != 1) ChangeMask();
         q_save->FieldByName("pts_seria")->Value = tsi->registration_series = NodeToStr(vehicle->ChildNodes->FindNode("registration_series"));
         vg_editVehicleDocSeries->Properties->Value = tsi->registration_series;
         q_save->FieldByName("pts_number")->Value = tsi->registration_number = NodeToStr(vehicle->ChildNodes->FindNode("registration_number"));
         vg_editVehicleDocNumber->Properties->Value = tsi->registration_number;
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("registration_issue_date")), dt)){
            q_save->FieldByName("pts_date")->Value = tsi->registration_issue_date = dt;
            SetValueRowDateEdit(vg_editVehicleDocDate, tsi->registration_issue_date);
            if(tsi->vehicle_registration_type_id == 1) q_save->FieldByName("pts_date_calc")->Value = dt;
         }
         q_save->FieldByName("ts_power")->Value = StrToFloatStr(NodeToStr(vehicle->ChildNodes->FindNode("engine_power_hp"))).ToDouble();


		 q_save->Post();
         m_api->dbCloseCursor(res, q_save);

         cur_autorization = 1;
         is_autorization = 1;
         is_pereautorization = 0;
         vg_AutorizationInfo->Properties->Value = "������� ������ � ��� (�����������)";

         ShortDateFormat = "dd.MM.yyyy";
         di->calc_date = quotes_date.DateString();

      }
      delete XMLDoc_Response;
   }
   catch(Exception& ex)
   {
     vg_AutorizationInfo->Properties->Value = ex.Message;
   }

/*  // DISABLE_KOEFFS
	// ������ �5
	// ������ �6 "������������� �6 �� ���������� � ����������"; 
	btnRequestK5Click(btnRequest);
*/
   Enabled = true;
   premiya_osn_risk_orig = di->calc_info.premiya_osn_risk;

   btnRequest->Caption = "������������ ������� (��������� � ���)";

   LoadData();

   Reason_CheckComboBoxPropertiesCloseUp(0);

   Recalc();


   vg->Invalidate();
//#endif
}
//---------------------------------------------------------------------------

void __fastcall TFReissCalc::btnRequestK5Click(TObject *Sender)
{
   TcxButton *btn = dynamic_cast<TcxButton*>(Sender);

   Root->ChildNodes->Clear();
   Root->AddChild("type")->Text = "1";
   Root->AddChild("system")->Text = "3";
   Root->AddChild("date_quotes")->Text = TDateTime(di->calc_date).FormatString("dd.mm.yyyy");
   Root->AddChild("casco_territory_id")->Text = IntToStr(di->region_id);
	Root->AddChild("product_id")->Text = IntToStr(di->product_id);
	Root->AddChild("project_id")->Text = IntToStr(di->project_id);
	Root->AddChild("program_id")->Text = IntToStr(di->programm_id);

   _di_IXMLNode persons = Root->AddChild("persons"), vehicle = Root->AddChild("vehicle"), person;

   person = persons->AddChild("person");
   person->Attributes["id"] = pi[0].lastname + space_str + pi[0].firstname + space_str + pi[0].secondname;
   person->AddChild("person_type_id")->Text = one_str;
   person->AddChild("first_name")->Text  = pi[0].firstname;
   person->AddChild("second_name")->Text = pi[0].secondname;                        
   person->AddChild("last_name")->Text   = pi[0].lastname;
   person->AddChild("birth_date")->Text  = pi[0].birthdate.FormatString("dd.mm.yyyy");
/* // TSInfo
   vehicle->AddChild("registration_mark")->Text  = tsi->ts_znak;
   vehicle->AddChild("vin")->Text                = tsi->ts_vin;
   vehicle->AddChild("engine_number")->Text      = tsi->ts_vin;
   vehicle->AddChild("body_number")->Text        = tsi->ts_vin;
   vehicle->AddChild("chassis_number")->Text     = tsi->ts_vin;
	vehicle->AddChild("rsa_model_code")->Text     = AddNulls(tsi->model_id);
   vehicle->AddChild("year_of_production")->Text = IntToStr(tsi->ts_year);
   vehicle->AddChild("age")->Text                = IntToStr(tsi->ts_age);
*/

   vehicle->AddChild("registration_mark")->Text = tsi->registration_mark;
   vehicle->AddChild("vin")->Text = tsi->vin;
   vehicle->AddChild("engine_number")->Text = tsi->vin;
   vehicle->AddChild("body_number")->Text = tsi->vin;
   vehicle->AddChild("chassis_number")->Text = tsi->vin;
   vehicle->AddChild("rsa_model_code")->Text = AddNulls(tsi->rsa_code); // difference
   vehicle->AddChild("year_of_production")->Text = IntToStr(tsi->construction_year);
   vehicle->AddChild("age")->Text = IntToStr(tsi->vehicle_age);
   
   try{
      //  OLD TOOLS.H   DocumentInfo
      //di->no_calc_k5 = false;
 
      _di_IXMLDocument XMLDoc_Resp = NewXMLDocument();
      XMLDoc_Resp->Active = true;
      XMLDoc_Resp->Options.Clear();

      AnsiString xml_result("");
      Thread_APO2_ARM_READER *thr_k5 = new Thread_APO2_ARM_READER(true, 4, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"), XMLDoc->GetXML()->Text, &xml_result);
      thr_k5->Resume();
      while(WaitForSingleObject((HANDLE)thr_k5->Handle, 0) == WAIT_TIMEOUT){
         btn->Caption = "������������� �5 �� ������������ � ��";
         for(int i = 0; i < 3; ++i){
            btn->Caption = btn->Caption + dot;
            Application->ProcessMessages();
            Sleep(333);
         }
      }
      delete thr_k5;

      XMLDoc_Resp->LoadFromXML(xml_result);
      _di_IXMLNode Root_Resp = XMLDoc_Resp->DocumentElement, errors = Root_Resp->ChildNodes->FindNode("Errors"), contracts = Root_Resp->ChildNodes->FindNode("contracts");
      if(errors->ChildNodes->Count){
         for(int e = 0, cnt_errors = errors->ChildNodes->Count; e < cnt_errors; ++e){
            _di_IXMLNode error = errors->ChildNodes->Get(e);
            switch(AnsiString(error->Attributes["type"]).ToIntDef(0)){
               case 1: is_autorization = 0; break;
               case 2: break;
            }
         }
      }

      if(is_autorization){
         pi[0].dogovors["k5"].clear();
         if(contracts){
            for(int c = 0, cnt_contracts = contracts->ChildNodes->Count; c < cnt_contracts; ++c){
               _di_IXMLNode contract = contracts->ChildNodes->Get(c);
               pi[0].dogovors["k5"].push_back(Dogovor(NodeToStr(contract->ChildNodes->FindNode("id")), NodeToStr(contract->ChildNodes->FindNode("system")).ToIntDef(0)));
            }
         }
         di->old_programm_id = NodeToStr(Root_Resp->ChildNodes->FindNode("PROGRAMM_ID")).ToIntDef(0);
         di->calc_info.k5 = StrToFloatStr(NodeToStr(Root_Resp->ChildNodes->FindNode("K5"))).ToDouble();
         di->contract_type = NodeToStr(Root_Resp->ChildNodes->FindNode("CONTRACT_TYPE")).ToIntDef(1) - 1;
         di->calc_info.old_str_summa = StrToFloatStr(NodeToStr(Root_Resp->ChildNodes->FindNode("LIABILITY"))).ToDouble();
         di->calc_info.old_premium = StrToFloatStr(NodeToStr(Root_Resp->ChildNodes->FindNode("PREMIUM"))).ToDouble();
         di->calc_info.old_premium_paid = StrToFloatStr(NodeToStr(Root_Resp->ChildNodes->FindNode("PREMIUM_PAID"))).ToDouble();
         di->calc_info.old_cost_vehicle = StrToFloatStr(NodeToStr(Root_Resp->ChildNodes->FindNode("REAL_COST"))).ToDouble();
         di->count_accidents = NodeToStr(Root_Resp->ChildNodes->FindNode("ACCIDENTS_COUNT")).ToIntDef(0);
         di->calc_info.paid = StrToFloatStr(NodeToStr(Root_Resp->ChildNodes->FindNode("DAMAGE_SUM_RUR"))).ToDouble();
         di->calc_info.claims_damages = (di->count_accidents == 1 && di->calc_info.old_premium) ? m_api->Round(di->calc_info.paid * 100 / di->calc_info.old_premium) : 0.0;
         // DocumentInfo // OLD TOOLS.H
         //di->no_calc_k6 = NodeToStr(Root_Resp->ChildNodes->FindNode("CASCO_K6_NO_CALC")).ToIntDef(0);
      }

      int drv_count = gridDopush->Items->Count;
      if(drv_count){
         for(int i = 0; i < drv_count; ++i){
            frmAddPermitted->Tag = i;
            if(frmAddPermitted->DataToXML()){
               Thread_APO2_ARM_READER *thr_k6 = new Thread_APO2_ARM_READER(true, 4, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"), frmAddPermitted->GetXML(), &xml_result);
               thr_k6->Resume();
               while(WaitForSingleObject((HANDLE)thr_k6->Handle, 0) == WAIT_TIMEOUT){
                  btn->Caption = "������������� �6 �� ���������� � ����������";
                  for(int i = 0; i < 3; ++i){
                     btn->Caption = btn->Caption + dot;
                     Application->ProcessMessages();
                     Sleep(333);
                  }
               }
               delete thr_k6;
               frmAddPermitted->CalcK6(xml_result);
               gridDopush->Items->Item[i]->SubItems->Strings[4] = pm[i].k6;
            }
         }
         //K1_K6_Final(false);
         gridDopush->Invalidate();
      }
      else{
         if(di->type_multydrive != 100 && di->type_multydrive != -1) CalcK6Insured(btn);
      }
   }
   //* // DocumentInfo // OLD TOOLS.H
   catch(Exception& ex)
   {
     cur_autorization = 0;
     is_autorization = 0;
     //di->no_calc_k5 = true;
   }
   catch(...)
   {
     cur_autorization = 0;
     is_autorization = 0;
     //di->no_calc_k5 = true;
   }
   //*///

   btn->Caption = "��������� ������ �� ������������ � ��";
   Enabled = true;

   Recalc();
}
//---------------------------------------------------------------------------
void TFReissCalc::CalcK6Insured(TObject *Sender)
{
   TcxButton *btn = dynamic_cast<TcxButton*>(Sender);

   Root->ChildNodes->Clear();
   Root->AddChild("type")->Text = "2";
   Root->AddChild("system")->Text = "3";
   Root->AddChild("date_quotes")->Text = TDateTime(di->calc_date).FormatString("dd.mm.yyyy");
   Root->AddChild("casco_dogovor_type")->Text = IntToStr(di->contract_type + 1);
//* //  DocumentInfo  // OLD TOOLS.H
   Root->AddChild("casco_k6_no_calc")->Text = IntToStr(di->no_calc_k6);
//*/

   Root->AddChild("casco_territory_id")->Text = IntToStr(di->region_id);

   _di_IXMLNode persons = Root->AddChild("persons"), person, vehicle = Root->AddChild("vehicle");

   person = persons->AddChild("person");
   person->Attributes["id"] = pi[0].lastname + space_str + pi[0].firstname + space_str + pi[0].secondname;
   person->AddChild("first_name")->Text  = pi[0].firstname;
   person->AddChild("second_name")->Text = pi[0].secondname;
   person->AddChild("last_name")->Text   = pi[0].lastname;
   person->AddChild("birth_date")->Text  = pi[0].birthdate.FormatString("dd.mm.yyyy");
   person->AddChild("is_insurant")->Text = one_str;
   _di_IXMLNode document = person->AddChild("person_document");
   document->AddChild("document_type_id")->Text = IntToStr(pi[0].doc_type);
   document->AddChild("document_series")->Text = StringReplace(pi[0].doc_seria, space_str, empty_str, rf);
   document->AddChild("document_number")->Text = pi[0].doc_number;
/* // TSInfo
   vehicle->AddChild("vin")->Text            = tsi->ts_vin;
   vehicle->AddChild("body_number")->Text    = tsi->ts_vin;
   vehicle->AddChild("chassis_number")->Text = tsi->ts_vin;
   vehicle->AddChild("age")->Text            = IntToStr(tsi->ts_age);
*/

   vehicle->AddChild("vin")->Text = tsi->vin;
   vehicle->AddChild("body_number")->Text = tsi->vin;
   vehicle->AddChild("chassis_number")->Text = tsi->vin;
   vehicle->AddChild("age")->Text = IntToStr(tsi->vehicle_age);

   try{
      _di_IXMLDocument XMLDoc_Resp = NewXMLDocument();

      XMLDoc_Resp->Active = true;
      XMLDoc_Resp->Options.Clear();

      AnsiString xml_result("");
      Thread_APO2_ARM_READER *thr_k6 = new Thread_APO2_ARM_READER(true, 1, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"), XMLDoc->GetXML()->Text, &xml_result);
      thr_k6->Resume();
      while(WaitForSingleObject((HANDLE)thr_k6->Handle, 0) == WAIT_TIMEOUT){
         btn->Caption = "�������� �6 ������������";
         for(int i = 0; i < 3; ++i){
            btn->Caption = btn->Caption + dot;
            Application->ProcessMessages();
            Sleep(333);
         }
      }
      delete thr_k6;

      XMLDoc_Resp->LoadFromXML(xml_result);
      _di_IXMLNode Root_Resp = XMLDoc_Resp->DocumentElement;
      _di_IXMLNode errors = Root_Resp->ChildNodes->FindNode("Errors");

      if(errors->ChildNodes->Count){}
      else{
         _di_IXMLNode person = Root_Resp->ChildNodes->FindNode("persons")->ChildNodes->FindNode("person");
         _di_IXMLNode contracts = person->ChildNodes->FindNode("contracts");
         pi[0].dogovors["k6"].clear();
         if(contracts){
            for(int c = 0, cnt_contracts = contracts->ChildNodes->Count; c < cnt_contracts; ++c){
               _di_IXMLNode contract = contracts->ChildNodes->Get(c);
               pi[0].dogovors["k6"].push_back(Dogovor(NodeToStr(contract->ChildNodes->FindNode("id")), NodeToStr(contract->ChildNodes->FindNode("system")).ToIntDef(0)));
            }
         }
         di->calc_info.k6 = StrToFloatStr(NodeToStr(person->ChildNodes->FindNode("K6"))).ToDouble();
         pi[0].is_underwriting = NodeToStr(person->ChildNodes->FindNode("IS_UNDERWRITING")).ToIntDef(0);
         pi[0].rsa_id = NodeToStr(person->ChildNodes->FindNode("IS_RSA"));
      }
      delete XMLDoc_Resp;
   }
   catch(Exception& ex) { cur_autorization = 0; is_autorization = 0; }
   catch(...) { cur_autorization = 0; is_autorization = 0; }

   btn->Caption = "������������ ������� (��������� � ���)";
}
//---------------------------------------------------------------------------
void TFReissCalc::K1_K6_Final(bool recalc)
{
   double k1t, k1_curr(0), k6t, k6_curr(0);

   for(int i = 0, n = gridDopush->Items->Count; i < n; i++){
      if(recalc){
         K1(m_api, i, pm, di);
         gridDopush->Items->Item[i]->SubItems->Strings[3] = pm[i].k1;
      }

      pm[i].permitted_check = gridDopush->Items->Item[i]->Checked;
      if(gridDopush->Items->Item[i]->Checked)
      {
         k1t = pm[i].k1;
         if(k1_curr < k1t){
            k1_curr = k1t;
         }
         k6t = pm[i].k6;
         if(k6_curr < k6t){
            k6_curr = k6t;
            index_max_k6 = i;
         }
      }
   }

   di->calc_info.k1 = k1_curr == 0 ? 1 : k1_curr;
   di->calc_info.k6 = k6_curr == 0 ? 1 : k6_curr;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::TextItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();

   labHint->Top = vg->InplaceEditor->Top + 2;
   labHint->Visible = true;

   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   switch(r->Tag){
      case 4: di->polis_seria = val.IsNull() ? empty_str : AnsiString(val); break;
      case 5: di->polis_number = val.IsNull() ? empty_str : AnsiString(val); break;
      case 9: case 13: pi[0].lastname = val.IsNull() ? empty_str : AnsiString(val).Trim(); break;
      case 10:
         if(!pi[0].status) pi[0].doc_number = val.IsNull() ? empty_str : AnsiString(val);
         else pi[0].inn = val.IsNull() ? empty_str : AnsiString(val);
         break;
      case 12: pi[0].phone_mobil = val.IsNull() ? empty_str : AnsiString(val); break;
      case 14: pi[0].firstname = val.IsNull() ? empty_str : AnsiString(val).Trim(); break;
      case 15: pi[0].secondname = val.IsNull() ? empty_str : AnsiString(val); break;
      case 16: pi[0].doc_seria = val.IsNull() ? empty_str : AnsiString(val); break;
      case 17: pi[0].doc_number = val.IsNull() ? empty_str : AnsiString(val); break;
      case 19: pi[0].doc_issue_org = val.IsNull() ? empty_str : AnsiString(val); break;
      case 21:
         if(!pi[1].status) pi[1].lastname = val.IsNull() ? empty_str : AnsiString(val).Trim();
         else pi[1].organization = val.IsNull() ? empty_str : AnsiString(val).Trim();
         break;
      case 22: pi[1].firstname = val.IsNull() ? empty_str : AnsiString(val).Trim(); break;
      case 23: pi[1].secondname = val.IsNull() ? empty_str : AnsiString(val); break;
      case 24:
/* // TSInfo
         if(!val.IsNull()){
            tsi->ts_znak = StringReplace(val, underline_str, empty_str, rf).Trim();
            if(tsi->ts_znak.Length() > 7) region_isp_id = tsi->ts_znak.SubString(7, tsi->ts_znak.Length() - 6).ToIntDef(0);
         }
         else{ tsi->ts_znak = empty_str; region_isp_id = 0; }
         break;
      case 25: tsi->ts_vin = val.IsNull() ? empty_str : AnsiString(val); break;
      case 26: tsi->pts_series = val.IsNull() ? empty_str : AnsiString(val); break;
      case 27: tsi->pts_number = val.IsNull() ? empty_str : AnsiString(val); break;
*/

         if(!val.IsNull()){
            tsi->registration_mark = StringReplace(val, underline_str, empty_str, rf).Trim();
            if(tsi->registration_mark.Length() > 7) region_isp_id = tsi->registration_mark.SubString(7, tsi->registration_mark.Length() - 6).ToIntDef(0);
         }
         else{ tsi->registration_mark = empty_str; region_isp_id = 0; }
         break;
      case 25: tsi->vin = val.IsNull() ? empty_str : AnsiString(val); break;
      case 26: tsi->registration_series = val.IsNull() ? empty_str : AnsiString(val); break;
      case 27: tsi->registration_number = val.IsNull() ? empty_str : AnsiString(val); break;

   }

   AnsiString s_ser = di->polis_seria ;
   AnsiString s_num = di->polis_number;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::DateItemPropertiesEditValueChanged(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   AnsiString dt_str("");
   switch(r->Tag){
      case 2:
         //vg_dateChange
         if(!val.IsNull()){
            dt_str = val;
            if(dt_str.Length() < 10 || !TryStrToDate(dt_str, di->cancell_date)) di->cancell_date.Val = surcharge_value = surcharge_value_ss = surcharge_value_gp = surcharge_value_gap_ss = 0;
            else CalcSurcharge();
         }
         else di->cancell_date.Val = surcharge_value = surcharge_value_ss = surcharge_value_gp = surcharge_value_gap_ss = 0;
         break;
      case  8: VariantToDate(val, di->polis_date); break; //vg_Date
      case 18: VariantToDate(val, pi[0].doc_issue_date); break; //vg_editDocDate
 /* // TSInfo
	  case 28: VariantToDate(val, tsi->pts_date); break; //vg_editVehicleDocDate
*/
	  case 28: VariantToDate(val, tsi->registration_issue_date); break; //vg_editVehicleDocDate

	  case 33: VariantToDate(val, pi[0].birthdate); break; //vg_editBirthDate
   }
   labHint->Visible = false;
   Recalc();
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::DateItemPropertiesChange(TObject *Sender)
{
   if(vg->FocusedRow && vg->InplaceEditor){
      labHint->Top = vg->InplaceEditor->Top + 2;
      labHint->Visible = true;
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::VIN_MaskItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   if(Error) DisplayValue = empty_str;
   Error = false;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties)
{
   labHint->Visible = false;
   Recalc();
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::ButtonItemPropertiesButtonClick(TObject *Sender, int AButtonIndex)
{
   int t = vg->FocusedRow->Tag;

   if(t == 11 || t == 20){
      m_api->KLADR_Get_Name(res, "����� �� ������");
      if(res == _Mops_API_KLADR_not_inited_){
         Application->MessageBox("� ��� �� ���������� �����, ���������� � ������ ���������","������ �����", MB_OK | MB_ICONEXCLAMATION);
         return;
      }

      TStringList* KladrStr = pi[0].kladr_addr;
      m_api->KLADR_Visual_Get_Separated_Address(res, this, pi[0].kladr_addr);
      if(pi[0].kladr_addr->Values["������"] == "��" && pi[0].kladr_addr->Count > 1){
         pi[0].address = m_api->KLADR_Get_Print_Address_By_Separated(res, pi[0].kladr_addr);
         if(t == 11) vg_Address->Properties->Value = pi[0].address;
         else    vg_editAddress->Properties->Value = pi[0].address;
         vg->FocusRow(vg_Phone, vg_Phone->Index);
         Recalc();
      }
   }

   else if(t == 30 || t == 31 || t == 32){
      TcxEditorRow *btn_row = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
      frmPayment->Tag = t - 30;
      frmPayment->SetCurrBtnRow(btn_row);

      TPoint pt = ClientToScreen(TPoint(btn_row->ViewInfo->RowRect.Right, btn_row->ViewInfo->RowRect.Bottom));
      frmPayment->Left = pt.x - frmPayment->Width;
      frmPayment->Top  = pt.y;
      frmPayment->Show();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::DocType_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_DocType->Properties->Value.IsNull()){
      int index = DocType_ComboBoxItem->Properties->Items->IndexOf(vg_DocType->Properties->Value);
      pi[0].doc_type = (int)DocType_ComboBoxItem->Properties->Items->Objects[index];
      //ChangeMask(DocSeries_MaskItem, DocNumber_MaskItem, vg_editDocSeries, vg_editDocNumber, pi, 0);
      pi[0].doc_issue_date.Val = 0.0;
      vg_editDocDate->Properties->Value = variant_null;
      vg_editDocOrg->Properties->Value = pi[0].doc_issue_org = empty_str;
      Recalc();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::IdentType_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_cboxIdentType->Properties->Value.IsNull()){
/* // TSInfo
	  vg_editTSVIN->Properties->Value = tsi->ts_vin = empty_str;
*/
	   vg_editTSVIN->Properties->Value = tsi->vin = empty_str;

	  VIN_MaskItem->Properties->EditMask = IdentType_ComboBoxItem->Properties->Items->IndexOf(vg_cboxIdentType->Properties->Value) ? empty_str : AnsiString("[0-9ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz]{17}");
      Recalc();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::MultyDriive_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_cboxMultyDrive->Properties->Value.IsNull()){
      int old_type_multydrive = di->type_multydrive;
      DataDict *data = (DataDict*)MultyDrive_ComboBoxItem->Properties->Items->Objects[MultyDrive_ComboBoxItem->Properties->Items->IndexOf(vg_cboxMultyDrive->Properties->Value)];
      di->type_multydrive = data->id;
      di->calc_info.k1 = data->coeff_value;
      ResetGridPermitted();
      if(old_type_multydrive == 100) CalcK6Insured(btnRequest);
      Recalc();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::Period_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();
   if(!vg_cboxPeriod->Properties->Value.IsNull()){
      reasons_surcharge[13].surcharge_const_value = ((DataDict*)Period_ComboBoxItem->Properties->Items->Objects[Period_ComboBoxItem->Properties->Items->IndexOf(vg_cboxDocVehicle->Properties->Value)])->coeff_value;
      Recalc();
   }
   else {}
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::RegVehicle_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_cboxRegistration->Properties->Value.IsNull()){
/* // TSInfo
	  vg_editRegPlate->Properties->Value = tsi->ts_znak = empty_str;
*/
	   vg_editRegPlate->Properties->Value = tsi->registration_mark = empty_str;

	   RegPlate_MaskItem->Properties->EditMask = RegVehicle_ComboBoxItem->Properties->Items->IndexOf(vg_cboxRegistration->Properties->Value) ? empty_str : AnsiString("[0-9������������D������������d]{6}[0-9]{2}|[0-9������������D������������d]{6}[0-9]{3}");
      Recalc();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::VehicleDocType_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_cboxDocVehicle->Properties->Value.IsNull())
   {
      int index = VehicleDocType_ComboBoxItem->Properties->Items->IndexOf(vg_cboxDocVehicle->Properties->Value);
/* // TSInfo
	  tsi->type_doc_ts = (int)VehicleDocType_ComboBoxItem->Properties->Items->Objects[index];
      ChangeMask(VehicleDocSeries_MaskItem, VehicleDocNumber_MaskItem, vg_editVehicleDocSeries, vg_editVehicleDocNumber, tsi, 0);
      tsi->pts_date.Val = 0.0;
*/
	  tsi->vehicle_registration_type_id = (int)VehicleDocType_ComboBoxItem->Properties->Items->Objects[index];
	  //ChangeMask(VehicleDocSeries_MaskItem, VehicleDocNumber_MaskItem, vg_editVehicleDocSeries, vg_editVehicleDocNumber, tsi, 0);
	  tsi->registration_issue_date.Val = 0.0;

	  vg_editVehicleDocDate->Properties->Value = variant_null;
      Recalc();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::VozmType_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   int p_id = pay_id_arm;

   if(!vg_cboxVozmType->Properties->Value.IsNull())
   {
      int pay_id_prev = di->pay_id;
      di->pay_id = (int)VozmType_ComboBoxItem->Properties->Items->Objects[VozmType_ComboBoxItem->Properties->Items->IndexOf(vg_cboxVozmType->Properties->Value)];
 /* // TSInfo
	  di->calc_info.k7 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->pay_id, di->REGION_TYPE, tsi->ts_age, tsi->ts_age, di->calc_date, di->calc_date), 1.0);
*/
	  di->calc_info.k7 = m_api->dbGetFloatFromQueryDef(res, sql.sprintf("select coeff_val from cascodictk07 where pay_id=%i and tertype_id=%i and vehage_min<%i and vehage_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->pay_id, di->REGION_TYPE, tsi->vehicle_age, tsi->vehicle_age, di->calc_date, di->calc_date), 1.0);

      if(pay_id_prev != di->pay_id) // previous pay_id  !=  current pay_id
        di->no_calc = DO_RECALC_USING_UFO;

	  Recalc();
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::Credit_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_cboxCredit->Properties->Value.IsNull()){
      di->calc_info.krs = ((DataDict*)Credit_ComboBoxItem->Properties->Items->Objects[Credit_ComboBoxItem->Properties->Items->IndexOf(vg_cboxCredit->Properties->Value)])->coeff_value;
      Recalc();
   }
}
//---------------------------------------------------------------------------
void TFReissCalc::ResetGridPermitted()
{
   gridDopush->Items->Clear();
   gridDopush->Visible  = false;
   vg_HeadGrid->Visible = false;
}
//---------------------------------------------------------------------------
bool TFReissCalc::IsNonStandartReissue()
{
   FilterDataSet(region_bl, "region_reg_plate=" + IntToStr(region_isp_id));
   if(reasons_surcharge[5].select && !region_bl->IsEmpty()) non_standart_str->Add(" - ������� ������������ ������ ����������� ��");
/* // TSInfo
   if(reasons_surcharge[5].select && !tsi->ts_znak.IsEmpty() && tsi->ts_znak != AnsiString("�/�") && m_api->dbGetIntFromQuery(res, "select count(*) from gl_dict_black_list_vehicle where reg_plate='" + NormVIN_GN(m_api, tsi->ts_znak) + "'") > 0) non_standart_str->Add(di->is_ander_login ? " - ���. �����  �� � ������ ������" : " - �� ������� ���������� �� ���. ������ � ���� ���");
   if(reasons_surcharge[6].select && !tsi->ts_vin.IsEmpty() && m_api->dbGetIntFromQuery(res, "select count(*) from gl_dict_black_list_vehicle where vin='" + NormVIN_GN(m_api, tsi->ts_vin) + "'") > 0) non_standart_str->Add(AnsiString(di->is_ander_login ? " - ����������������� ����� �� � ������ ������" : " - �� ������� ���������� �� VIN � ���� ���"));
*/
   if (reasons_surcharge[5].select && !tsi->registration_mark.IsEmpty() && tsi->registration_mark != AnsiString("�/�") && m_api->dbGetIntFromQuery(res, "select count(*) from gl_dict_black_list_vehicle where reg_plate='" + NormVIN_GN(m_api, tsi->registration_mark) + "'") > 0) non_standart_str->Add(di->is_ander_login ? " - ���. �����  �� � ������ ������" : " - �� ������� ���������� �� ���. ������ � ���� ���");
   if (reasons_surcharge[6].select && !tsi->vin.IsEmpty() && m_api->dbGetIntFromQuery(res, "select count(*) from gl_dict_black_list_vehicle where vin='" + NormVIN_GN(m_api, tsi->vin) + "'") > 0) non_standart_str->Add(AnsiString(di->is_ander_login ? " - ����������������� ����� �� � ������ ������" : " - �� ������� ���������� �� VIN � ���� ���"));

   FilterDataSet(q_bl_persons, "person_name='" + m_api->Normalization_String_RSA(res, pi[0].lastname + pi[0].firstname + pi[0].secondname) + "' and birthdate='" + pi[0].birthdate.DateString() + "'");
   pi[0].black_list = q_bl_persons->IsEmpty() ? 0 : 1;
   if(pi[0].black_list) non_standart_str->Add(di->is_ander_login ? AnsiString(" - ������������ � ������ ������") : AnsiString(" - �� ������� ���������� �� ������������ � ���� ���"));
   if(pi[0].is_underwriting) non_standart_str->Add(" - ������������ ����� ������ ������� �� �����");
   for(int i = 0, cnt = gridDopush->Items->Count; i < cnt; ++i){
      AnsiString num(i + 1);
      if(gridDopush->Items->Item[i]->Checked){
         if(pm[i].black_list) non_standart_str->Add(di->is_ander_login ? AnsiString(" - ���������� �" + num + " � ������ ������") : AnsiString(" - �� ������� ���������� �� ����������� �" + num + " � ���� ���"));
         if(pm[i].is_underwriting) non_standart_str->Add(" - ���������� �" + num + " ����� ������ ������� �� �����");
      }
   }

   if(reasons_surcharge[10].select) non_standart_str->Add(" - ������� ������������(��) ������� \"������ ��������������� ���������� ��\"");
   //if(reasons_surcharge[11].select) non_standart_str->Add(" - ������� ������������ ������� \"��������� �������� ������� ���������� ����������\"");
   if(reasons_surcharge[12].select) non_standart_str->Add(" - ������� ������������ ������� \"��������� ������ ������ ��������� �������\"");

   if(reasons_surcharge[17].select && SumAD() > di->calc_info.str_summa * 0.1) non_standart_str->Add(AnsiString(" - ��������� ����� �� �� ������� �� ����� 10% �� ��������� ����� �� ����� ") + (di->risk == 2 ? "�����" : "�����"));
   //if(reasons_surcharge[18].select && (di->calc_info.str_summa2 > di->calc_info.kss_sum_limit || di->calc_info.cost_vehicle_new > di->calc_info.kss_sum_limit)) non_standart_str->Add(" - ������� ������������ ������� \"���������� ��������� �����\"");
   //if(reasons_surcharge[19].select && !reasons_surcharge[18].select && (di->calc_info.str_summa > di->calc_info.kss_sum_limit || di->calc_info.cost_vehicle > di->calc_info.kss_sum_limit)) non_standart_str->Add(" - ������� ������������ ������� \"���������� GAP\"");

   return non_standart_str->Count;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::btnDopushPlusClick(TObject *Sender)
{
/*
   int count_permit = gridDopush->Items->Count;
   TListItem *new_item = gridDopush->Items->Add();
   new_item->Caption = count_permit + 1;
   new_item->SubItems->Add(AnsiString("x"));
   new_item->SubItems->Add(AnsiString("xx")); //���
   new_item->SubItems->Add(AnsiString("xxx"));
   new_item->SubItems->Add(AnsiString("xxxx"));
   new_item->SubItems->Add(AnsiString("xxxxx"));
   new_item->Checked = true;
   gridDopush->Height = 25 + (gridDopush->Items->Count - 1) * 19;
   di->count_permitted = count_permit + 1;
*/
#if 1
   int count_permit = gridDopush->Items->Count;
   frmAddPermitted->Tag = count_permit;
   frmAddPermitted->SetButtonPress(0);
   pm[count_permit].doc_type = 17;

   if(frmAddPermitted->ShowModal() == IDOK) //mrOk)
   {
      TListItem *new_item = gridDopush->Items->Add();
      new_item->Caption = count_permit + 1;
      pm[count_permit].permitted_check = 1; //set checked by default
      new_item->SubItems->Add(AnsiString(frmAddPermitted->rgPmSex->Properties->Value).SubString(1, 1));
      new_item->SubItems->Add(pm[count_permit].lastname + space_str + pm[count_permit].firstname.SubString(1, 1) + dot + space_str + pm[count_permit].secondname.SubString(1, 1) + dot); //���
      new_item->SubItems->Add(IntToStr(pm[count_permit].age) + "/" + IntToStr(pm[count_permit].experience));
      //new_item->SubItems->Add(pm[count_permit].k1);
	  new_item->SubItems->Add(AnsiString("-"));
	  //new_item->SubItems->Add(pm[count_permit].k6);
	  new_item->SubItems->Add(AnsiString("-"));
	  new_item->Checked = true;

      gridDopush->Height = 25 + (gridDopush->Items->Count - 1) * 19;
      //K1_K6_Final(false);
      gridDopush->Invalidate();

      di->count_permitted = count_permit + 1;
      Recalc();
      di->no_calc = DO_RECALC_USING_UFO; // ��������� => �������������
   }


   //int cnt = person->ChildNodes->Count;
   //di->count_permitted = /*index_perm*/;

   // Auto Recalc
   //if(di->no_calc)
   //{
   //  btnRequestUFOClick(0);
   //  di->no_calc = NO_RECALC_USING_UFO;
   //}

   //Recalc();
#endif
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::btnDopushMinusClick(TObject *Sender)
{
   if(curGridDopushindx > -1)
   { gridDopush->Items->Item[curGridDopushindx]->Checked = false; }
   
   //gridDopush->Items->Clear();

#if 0
   int count_permit = gridDopush->Items->Count;
   di->count_permitted = count_permit>0 ? count_permit - 1 : count_permit; // ��� ������ ������ � ����

   int indx = gridDopush->ItemIndex;
   if(indx > -1)
   {
     gridDopush->Items->Delete(indx);
     pm[indx].Reset();
   }
   //int cnt = person->ChildNodes->Count;
   //di->count_permitted = index_perm;

   if(gridDopush->Items->Count < count_permit) di->no_calc = DO_RECALC_USING_UFO; // ����� ������ => �������������

   //btnRequestUFOClick(0);
   Recalc();
#endif
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::btnDopushEditClick(TObject *Sender)
{
   curGridDopushindx = gridDopush->ItemIndex;

#if 1
   TListItem *edit_item = gridDopush->Selected;
   if(!btnDopushEdit->Enabled || !edit_item || !gridDopush->Enabled) return;
   int index = edit_item->Index;
   frmAddPermitted->Tag = index;
   frmAddPermitted->SetButtonPress(1);

   if(frmAddPermitted->ShowModal() == IDOK)
   {
      edit_item->SubItems->Strings[0] = AnsiString(frmAddPermitted->rgPmSex->Properties->Value).SubString(1, 1);
      edit_item->SubItems->Strings[1] = pm[index].lastname + space_str + pm[index].firstname.SubString(1, 1) + dot + space_str + pm[index].secondname.SubString(1, 1) + dot;
      edit_item->SubItems->Strings[2] = IntToStr(pm[index].age) + "/" + IntToStr(pm[index].experience);
      //edit_item->SubItems->Strings[3] = pm[index].k1;
      //edit_item->SubItems->Strings[4] = pm[index].k6;
      edit_item->SubItems->Strings[3] = AnsiString("-");
      edit_item->SubItems->Strings[4] = AnsiString("-");
      //K1_K6_Final(false);
      gridDopush->Invalidate();
      Recalc();

      di->no_calc = DO_RECALC_USING_UFO; // ���������� ���-�� => �������������
    }
#endif
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::btnADPlusClick(TObject *Sender)
{
   int count_ad = gridAD->Items->Count;
   frmADevices->Tag = count_ad;
   frmADevices->SetButtonPress(0);

   if(frmADevices->ShowModal() == IDOK)
   {
     TListItem *new_item = gridAD->Items->Add();
     new_item->Caption = count_ad + 1;
     new_item->SubItems->Add(Trim(adevice[count_ad].name_dict + space_str + adevice[count_ad].name_detail));
     new_item->SubItems->Add(FormatFloat(",0.00�'.';-,0.00�'.'", adevice[count_ad].cost));
     new_item->Checked = true;

     //gridAD->Height = 25 + (gridAD->Items->Count - 1) * 19;
     gridAD->Height = 30 + (gridAD->Items->Count - 1) * 19;
     Recalc();

	 int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
	 // Format of INSERT into TableName values (v1,v2,...,vn)
     AnsiString sqlInsert = "insert into casco_devices_r";
     //AnsiString sqlTbl = " (";
     AnsiString sqlVal = " values (";

     /*sqlTbl = sqlTbl + "calc_id" + ",";        */ sqlVal = sqlVal +     IntToStr(calc_id)                 + ",";
     /*sqlTbl = sqlTbl + "number" + ",";         */ sqlVal = sqlVal +     IntToStr(count_ad + 1)            + ",";
     /*sqlTbl = sqlTbl + "id_device" + ",";      */ sqlVal = sqlVal +     adevice[count_ad].id              + ","; //FloatToSQLStr(
     /*sqlTbl = sqlTbl + "cost_device" + ",";    */ sqlVal = sqlVal +     adevice[count_ad].cost            + ",";
     /*sqlTbl = sqlTbl + "description" + ",";    */ sqlVal = sqlVal +"'"+ adevice[count_ad].name_detail +"'"+ ",";
     /*sqlTbl = sqlTbl + "premium_device" + ","; */ sqlVal = sqlVal +     /*adevice[count_ad].*/ "0"        + ",";

     //sqlTbl = DeleteLastSymbol(sqlTbl); // ������� ��������� �������
     sqlVal = DeleteLastSymbol(sqlVal); // ������� ��������� �������
     //sqlTbl = sqlTbl + ")";
     sqlVal = sqlVal + ")";

     sqlInsert = sqlInsert /*+ sqlTbl*/ + sqlVal;
     m_api->dbExecuteQuery(res, sqlInsert);
   }
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::btnADMinusClick(TObject *Sender)
{
   TListItem *edit_item = gridAD->Selected;
   if(!edit_item) return;
   int index = edit_item->Index;
   if(index > -1)
   {
     gridAD->Items->Delete(index);

     int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
     // Format of UPDATE TableName set t1='str',t2=num,...,tn=vn where calc_id=id
     AnsiString sql("delete from casco_devices_r ");
     sql = sql + " where calc_id=" + IntToStr(calc_id);
     sql = sql + " and number=" + IntToStr(index + 1);
     sql = sql + " and id_device=" + adevice[index].id;
     m_api->dbExecuteQuery(res, sql);
   }

   //if(gridDopush->Items->Count < count_permit) di->no_calc = DO_RECALC_USING_UFO; // ����� ������ => �������������

   Recalc();
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::btnADEditClick(TObject *Sender)
{
   TListItem *edit_item = gridAD->Selected;
   if(!edit_item) return;
   int index = edit_item->Index;
   frmADevices->Tag = index;
   frmADevices->SetButtonPress(1);

   if(frmADevices->ShowModal() == IDOK){
      edit_item->SubItems->Strings[0] = Trim(adevice[index].name_dict + space_str + adevice[index].name_detail);
      edit_item->SubItems->Strings[1] = FormatFloat(",0.00�'.';-,0.00�'.'", adevice[index].cost);
      Recalc();
   }


   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
    // Format of UPDATE TableName set t1='str',t2=num,...,tn=vn where calc_id=id
	AnsiString sql("update casco_devices_r set ");
	sql = sql + "calc_id ="       + IntToStr(calc_id)             +",";
    sql = sql + "number ="        + IntToStr(index + 1)        +",";
	sql = sql + "id_device ="     + adevice[index].id          +",";
	sql = sql + "cost_device = "  + adevice[index].cost        +",";
	sql = sql + "description = '" + adevice[index].name_detail +"',";
	sql = sql + "premium_device=" + "0"    +",";

	sql = DeleteLastSymbol(sql);

	sql = sql + " where calc_id=" + IntToStr(calc_id);
	sql = sql + " and number=" + IntToStr(index + 1);
	sql = sql + " and id_device=" + adevice[index].id;

	m_api->dbExecuteQuery(res, sql);
}
//---------------------------------------------------------------------------
void TFReissCalc::GetApplyingKoeffs()
{
/* // TSInfo
	// ������������� ������������� � ��������� ������
   q = m_api->dbGetCursor(res, sql.sprintf("select ctc.coeff_id as coeff,ctc.tariff_id as ctctid,ct.tariff_id as cttid,ct.risk_id as risk from CascoTariffCoeff as ctc"
                                           " left join CascoTariff as ct on ctc.tariff_id=ct.tariff_id where (ct.product_id=%d and ct.vehgr_id=%d and ct.risk_id=%d"
                                           " and CDate('%s')>=ctc.start_date and CDate('%s')<=ctc.end_date)", di->product_id, tsi->IsSpectech() ? 11 : 0, di->risk, di->calc_date, di->calc_date));
//*/
// ������������� ������������� � ��������� ������
	q = m_api->dbGetCursor(res, sql.sprintf("select ctc.coeff_id as coeff,ctc.tariff_id as ctctid,ct.tariff_id as cttid,ct.risk_id as risk from CascoTariffCoeff as ctc"
		" left join CascoTariff as ct on ctc.tariff_id=ct.tariff_id where (ct.product_id=%d and ct.vehgr_id=%d and ct.risk_id=%d"
		" and CDate('%s')>=ctc.start_date and CDate('%s')<=ctc.end_date)", di->product_id, tsi->IsSpectech() ? 11 : 0, di->risk, di->calc_date, di->calc_date));

	for(coeff_base.clear(), q->First(); !q->Eof; q->Next()) coeff_base.insert(q->FieldByName("coeff")->AsInteger);
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
double TFReissCalc::GetMinRate()
{
   if(di->programm_id == 1045) return 0.0;
/* // TSInfo
   AnsiString f("");
   FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i", di->region_id));
   if(!min_rate->IsEmpty()){
      FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i and [model_code]=%i", di->region_id, tsi->model_id));
      if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
      else{
         FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i and [vehicle_group_id]=%i", di->region_id, tsi->group_ts));
         if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
         else                     return 0.0;
      }
   }
   else{
      FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i", di->REGION_TYPE));
      if(!min_rate->IsEmpty()){
         FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i and [model_code]=%i", di->REGION_TYPE, tsi->model_id));
         if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
         else{
            FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i and [vehicle_group_id]=%i", di->REGION_TYPE, tsi->group_ts));
            if(!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
            else                     return 0.0;
         }
      }
      else return 0.0;
   }
//*/

   AnsiString f("");
   FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i", di->region_id));
   if (!min_rate->IsEmpty()) {
	   FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i and [model_code]=%i", di->region_id, tsi->rsa_code)); // difference
	   if (!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
	   else {
		   FilterDataSet(min_rate, f.sprintf("[casco_territory_id]=%i and [vehicle_group_id]=%i", di->region_id, tsi->vehicle_group));
		   if (!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
		   else                     return 0.0;
	   }
   }
   else {
	   FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i", di->REGION_TYPE));
	   if (!min_rate->IsEmpty()) {
		   FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i and [model_code]=%i", di->REGION_TYPE, tsi->rsa_code)); // difference
		   if (!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
		   else {
			   FilterDataSet(min_rate, f.sprintf("[casco_territory_type_id]=%i and [vehicle_group_id]=%i", di->REGION_TYPE, tsi->vehicle_group));
			   if (!min_rate->IsEmpty()) return min_rate->FieldByName("min_rate")->AsFloat;
			   else                     return 0.0;
		   }
	   }
	   else return 0.0;
   }


}
//---------------------------------------------------------------------------
void TFReissCalc::LoadData()
{
   GetApplyingKoeffs();

   q = m_api->dbGetCursor(res, sql.sprintf("select driver_count,coeff_value from cascodictkd where CDate('%s')>=start_date and CDate('%s')<=end_date order by driver_count", di->calc_date, di->calc_date));
   for(coeff_kd.clear(), q->First(); !q->Eof; q->Next()) coeff_kd.push_back(q->FieldByName("coeff_value")->AsFloat);
   m_api->dbCloseCursor(res, q);

   if(min_rate) m_api->dbCloseCursor(res, min_rate);
   min_rate = m_api->dbGetCursor(res, sql.sprintf("select * from casco_minrate where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));

   di->calc_info.coeff_limit = m_api->dbGetFloatFromQuery(res, sql.sprintf("select coeff_limit from cascopremiumlimit where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::gridDopushClick(TObject *Sender)
{
   curGridDopushindx = gridDopush->ItemIndex;

   //K1_K6_Final(false);
   Recalc();
   gridDopush->Invalidate();
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::gridDopushCustomDrawItem(TCustomListView *Sender, TListItem *Item, TCustomDrawState State,  bool &DefaultDraw)
{
   int nIndx = Item->Index;
   int nChck = Item->Checked;
   //if(Item->Checked && Item->Index == index_max_k6) Sender->Canvas->Brush->Color = clTeal;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::gridADClick(TObject *Sender)
{
   Recalc();
}
//---------------------------------------------------------------------------
double TFReissCalc::SumAD()
{
   double result(0.0);

   for(int i = 0, n = gridAD->Items->Count; i < n; i++)
      if(gridAD->Items->Item[i]->Checked) result += adevice[i].cost;

   return result;
}
//---------------------------------------------------------------------------
int TFReissCalc::IsChangeDataForRecalc()
{
   if(reasons_surcharge[1].select){

      return 1;
   }

   if(reasons_surcharge[11].select && di->pay_id != pay_id_arm) return 1;

   if(reasons_surcharge[17].select && SumAD() > 0) return 1;

   return 0;
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::BeneficStatus_ComboBoxItemPropertiesChange(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();

   if(!vg_editBStatus->Properties->Value.IsNull()){
      pi[1].status = BeneficStatus_ComboBoxItem->Properties->Items->IndexOf(vg_editBStatus->Properties->Value);
      pi[1].Reset();
      vg_editBLastName_or_Organization->Properties->Caption = pi[1].status ? "������������ ����������� / ��" : "�������";
      vg_editBFirstName->Visible = !pi[1].status;
      vg_editBSecondName->Visible = !pi[1].status;
      vg_editBLastName_or_Organization->Properties->Value = empty_str;
      vg_editBFirstName->Properties->Value = empty_str;
      vg_editBSecondName->Properties->Value = empty_str;

      Recalc();
   }
}
//---------------------------------------------------------------------------

void __fastcall TFReissCalc::Button1Click(TObject *Sender)
{
   int max_tag(0);
   for(int i = 0, cnt = vg->Rows->Count; i < cnt; ++i){
      if(vg->Rows->Items[i]->Tag > max_tag) max_tag = vg->Rows->Items[i]->Tag;
   }

   ShowMessage(max_tag);
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::Extension_ComboBoxItemPropertiesChange(TObject *Sender)
{
   Recalc();
}
//---------------------------------------------------------------------------
void TFReissCalc::LoadKssData()
{
/* // TSInfo
	TADOQuery *q_kss = m_api->dbGetCursor(res, sql.sprintf("select coeff_val,sum_limit,premium_limit from cascodictkss where (veh_model_id=%i or veh_model_id=0) and (veh_age=%i or veh_age is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by veh_model_id desc, veh_age desc", tsi->model_id, tsi->ts_age, di->calc_date, di->calc_date));
*/
	TADOQuery *q_kss = m_api->dbGetCursor(res, sql.sprintf("select coeff_val,sum_limit,premium_limit from cascodictkss where (veh_model_id=%i or veh_model_id=0) and (veh_age=%i or veh_age is null) and CDate('%s')>=start_date and CDate('%s')<=end_date order by veh_model_id desc, veh_age desc", tsi->rsa_code, tsi->vehicle_age, di->calc_date, di->calc_date)); // difference

	if(!q_kss->IsEmpty())
	{
      di->calc_info.kss_new = q_kss->FieldByName("coeff_val")->AsFloat;
      di->calc_info.kss_sum_limit = q_kss->FieldByName("sum_limit")->AsFloat;
      di->calc_info.kss_premium_limit = q_kss->FieldByName("premium_limit")->AsFloat;
   }
   m_api->dbCloseCursor(res, q_kss);
}
//---------------------------------------------------------------------------
void __fastcall TFReissCalc::DateItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   if(Error) DisplayValue = variant_null;
   Error = false;
}
//---------------------------------------------------------------------------

