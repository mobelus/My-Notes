//---------------------------------------------------------------------------


#ifndef licardH
#define licardH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//#include "tools.h"
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "cxBlobEdit.hpp"
#include "cxButtonEdit.hpp"
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include "cxCalendar.hpp"
#include "cxExtEditRepositoryItems.hpp"
#include <Mask.hpp>
#include "cxDropDownEdit.hpp"
#include "cxDBEditRepository.hpp"
#include <DB.hpp>
#include "cxDBLookupComboBox.hpp"
#include "cxTextEdit.hpp"
//---------------------------------------------------------------------------
class TfrmLicard : public TFrame
{
__published:	// IDE-managed Components
   TdxInspector *LikardInfo;
   TdxInspectorTextDateRow *dateCardVidan;
   TdxInspectorTextRow *editNumberLikard;
private:	// User declarations
   mops_api_026 *m_api;
public:		// User declarations
   __fastcall TfrmLicard(TComponent* Owner, mops_api_026 *mops);
   void SaveFrame(TADOQuery *q);
   void LoadFrame(TADOQuery *q);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmLicard *frmLicard;
//---------------------------------------------------------------------------
#endif

/*
class TcxRadioGroupItemAccess : public TcxRadioGroupItem
    {
    public:
        __property Enabled;
    };

    ((TcxRadioGroupItemAccess*)cxRadioGroup1->Properties->Items->Items[1])->Enabled = false;
*/

