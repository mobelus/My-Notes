//---------------------------------------------------------------------------

#ifndef UViewHistoryH
#define UViewHistoryH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "SHDocVw_OCX.h"
#include <OleCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmViewHistory : public TForm
{
__published:	// IDE-managed Components
   TCppWebBrowser *WB;
private:	// User declarations
public:		// User declarations
   __fastcall TfrmViewHistory(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmViewHistory *frmViewHistory;
//---------------------------------------------------------------------------
#endif
