//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UDubl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma resource "*.dfm"
TfrmDubl *frmDubl;
//---------------------------------------------------------------------------
__fastcall TfrmDubl::TfrmDubl(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmDubl::btnOKClick(TObject *Sender)
{
   DublInfo->PostEditor();
}
//---------------------------------------------------------------------------
bool TfrmDubl::IsAllData()
{
   return (!editPolisSeria->EditText.IsEmpty() && !editPolisNumber->EditText.IsEmpty() && !editReason->EditText.IsEmpty());
}
//---------------------------------------------------------------------------

