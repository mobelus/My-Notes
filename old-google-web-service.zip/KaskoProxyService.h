// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>0
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>1
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>2
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>3
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>4
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>5
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>6
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>7
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>8
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>9
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>10
// Encoding : utf-8
// Codegen  : [wfMapStringsToWideStrings+, wfUseSerializerClassForAttrs-]
// Version  : 1.0
// (20.04.2017 15:46:43 - - $Rev: 16699 $)
// ************************************************************************ //

#ifndef   KaskoProxyServiceH
#define   KaskoProxyServiceH

#include <System.hpp>
#include <InvokeRegistry.hpp>
#include <XSBuiltIns.hpp>
#include <SOAPHTTPClient.hpp>
#include "functions.h"

#if !defined(SOAP_REMOTABLE_CLASS)
#define SOAP_REMOTABLE_CLASS __declspec(delphiclass)
#endif
#if !defined(IS_OPTN)
#define IS_OPTN 0x0001
#endif
#if !defined(IS_UNBD)
#define IS_UNBD 0x0002
#endif
#if !defined(IS_NLBL)
#define IS_NLBL 0x0004
#endif
#if !defined(IS_REF)
#define IS_REF 0x0080
#endif


namespace NS_KaskoProxyService {

// ************************************************************************ //
// The following types, referred to in the WSDL document are not being represented
// in this file. They are either aliases[@] of other types represented or were referred
// to but never[!] declared in the document. The types from the latter category
// typically map to predefined/known XML or Borland types; however, they could also 
// indicate incorrect WSDL documents that failed to declare or import a schema type.
// ************************************************************************ //
// !:string          - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:int             - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:boolean         - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:decimal         - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:dateTime        - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:anyType         - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:base64Binary    - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:short           - "http://www.w3.org/2001/XMLSchema"[Gbl]

class SOAP_REMOTABLE_CLASS User;
class SOAP_REMOTABLE_CLASS CalculationRequest;
class SOAP_REMOTABLE_CLASS Insurant;
class SOAP_REMOTABLE_CLASS PersonName;
class SOAP_REMOTABLE_CLASS LegalEntity;
class SOAP_REMOTABLE_CLASS Document;
class SOAP_REMOTABLE_CLASS InsurantDocument;
class SOAP_REMOTABLE_CLASS VehicleBaseDto;
class SOAP_REMOTABLE_CLASS Vehicle;
class SOAP_REMOTABLE_CLASS Franchise;
class SOAP_REMOTABLE_CLASS AddEquipmentRequest;
class SOAP_REMOTABLE_CLASS Driver;
class SOAP_REMOTABLE_CLASS DriverLicense;
class SOAP_REMOTABLE_CLASS KaskoReCalculateRequest;
class SOAP_REMOTABLE_CLASS KaskoReCalculateVehicle;
class SOAP_REMOTABLE_CLASS CalculationResult;
class SOAP_REMOTABLE_CLASS UsagePeriod;
class SOAP_REMOTABLE_CLASS Coefficients;
class SOAP_REMOTABLE_CLASS PaymentDto;
class SOAP_REMOTABLE_CLASS PrevPolicyDto;
class SOAP_REMOTABLE_CLASS VehicleCalculationResult;
class SOAP_REMOTABLE_CLASS AddEquipmentResponse;
class SOAP_REMOTABLE_CLASS AdmitResultsDto;
class SOAP_REMOTABLE_CLASS DriverPrevContractDto;
class SOAP_REMOTABLE_CLASS PrevContractIdDto;
class SOAP_REMOTABLE_CLASS ReservationCoefficient;
class SOAP_REMOTABLE_CLASS RiskObject;
class SOAP_REMOTABLE_CLASS UnderwritingRequirement;
class SOAP_REMOTABLE_CLASS KaskoUnderwritingRequirements;
class SOAP_REMOTABLE_CLASS ContractorName;
class SOAP_REMOTABLE_CLASS BrandModel;
class SOAP_REMOTABLE_CLASS Address;
class SOAP_REMOTABLE_CLASS Proxy;
class SOAP_REMOTABLE_CLASS Pledgeholder;
class SOAP_REMOTABLE_CLASS KaskoPrintRequestDto;
class SOAP_REMOTABLE_CLASS PrintCertificateRequest;
class SOAP_REMOTABLE_CLASS PrintRequest;
class SOAP_REMOTABLE_CLASS Signer;
class SOAP_REMOTABLE_CLASS AppInsurer;
class SOAP_REMOTABLE_CLASS PrintAppRequest;
class SOAP_REMOTABLE_CLASS SignerDocument;
class SOAP_REMOTABLE_CLASS Inspection;
class SOAP_REMOTABLE_CLASS PrintAppVehicle;
class SOAP_REMOTABLE_CLASS PrintAppRequestUl;
class SOAP_REMOTABLE_CLASS VehicleAddInformation;
class SOAP_REMOTABLE_CLASS PrintContractRequest;
class SOAP_REMOTABLE_CLASS BeneficiaryPrintRequest;
class SOAP_REMOTABLE_CLASS ContractInsurant;
class SOAP_REMOTABLE_CLASS ContractInsurer;
class SOAP_REMOTABLE_CLASS Payments;
class SOAP_REMOTABLE_CLASS Passport;
class SOAP_REMOTABLE_CLASS Payment;
class SOAP_REMOTABLE_CLASS KaskoPrintContractUlRequestDto;
class SOAP_REMOTABLE_CLASS LeasingContract;
class SOAP_REMOTABLE_CLASS Beneficiary;
class SOAP_REMOTABLE_CLASS LeaseHolder;
class SOAP_REMOTABLE_CLASS UnderwritingAdditionalInfo;
class SOAP_REMOTABLE_CLASS CommonDocument;
class SOAP_REMOTABLE_CLASS Group;
class SOAP_REMOTABLE_CLASS VehicleAdditionalInfo;
class SOAP_REMOTABLE_CLASS VehicleProlongation;
class SOAP_REMOTABLE_CLASS QuotationStateInfo;
class SOAP_REMOTABLE_CLASS Quotation;
class SOAP_REMOTABLE_CLASS VehicleResult;
class SOAP_REMOTABLE_CLASS VehicleStateInfo;
class SOAP_REMOTABLE_CLASS VehicleComment;
class SOAP_REMOTABLE_CLASS CalculateVzdRequest;
class SOAP_REMOTABLE_CLASS CalculateVzdVehicleRequest;
class SOAP_REMOTABLE_CLASS CalculateVzdResult;
class SOAP_REMOTABLE_CLASS CalculateVzdVehicleResponse;
class SOAP_REMOTABLE_CLASS PrintULAddAgreementRequest;
class SOAP_REMOTABLE_CLASS InsurerProxyDto;
class SOAP_REMOTABLE_CLASS AddEquipmentInfo;
class SOAP_REMOTABLE_CLASS PrintULBLAddAgreementRequest;
class SOAP_REMOTABLE_CLASS EarlyApproveInfo;
class SOAP_REMOTABLE_CLASS EarlyApproveResult;
class SOAP_REMOTABLE_CLASS CalculationSheet;
class SOAP_REMOTABLE_CLASS KaskoFLSpecialRequest;
class SOAP_REMOTABLE_CLASS InsurantInfo;
class SOAP_REMOTABLE_CLASS RegistrationAgencyDto;
class SOAP_REMOTABLE_CLASS ExtendedBankInfo;
class SOAP_REMOTABLE_CLASS KaskoAutoProtectionRequest;
class SOAP_REMOTABLE_CLASS InsurantPrintDto;
class SOAP_REMOTABLE_CLASS DocumentWithValidityDto;
class SOAP_REMOTABLE_CLASS KaskoAutoProtectionRequestUL;
class SOAP_REMOTABLE_CLASS User2;
class SOAP_REMOTABLE_CLASS CalculationRequest2;
class SOAP_REMOTABLE_CLASS Insurant2;
class SOAP_REMOTABLE_CLASS InsurantDocument2;
class SOAP_REMOTABLE_CLASS Document2;
class SOAP_REMOTABLE_CLASS PersonName2;
class SOAP_REMOTABLE_CLASS LegalEntity2;
class SOAP_REMOTABLE_CLASS Vehicle2;
class SOAP_REMOTABLE_CLASS VehicleBaseDto2;
class SOAP_REMOTABLE_CLASS AddEquipmentRequest2;
class SOAP_REMOTABLE_CLASS Driver2;
class SOAP_REMOTABLE_CLASS DriverLicense2;
class SOAP_REMOTABLE_CLASS Franchise2;
class SOAP_REMOTABLE_CLASS KaskoReCalculateRequest2;
class SOAP_REMOTABLE_CLASS KaskoReCalculateVehicle2;
class SOAP_REMOTABLE_CLASS CalculationResult2;
class SOAP_REMOTABLE_CLASS UsagePeriod2;
class SOAP_REMOTABLE_CLASS VehicleCalculationResult2;
class SOAP_REMOTABLE_CLASS AddEquipmentResponse2;
class SOAP_REMOTABLE_CLASS AdmitResultsDto2;
class SOAP_REMOTABLE_CLASS DriverPrevContractDto2;
class SOAP_REMOTABLE_CLASS Coefficients2;
class SOAP_REMOTABLE_CLASS PaymentDto2;
class SOAP_REMOTABLE_CLASS PrevContractIdDto2;
class SOAP_REMOTABLE_CLASS PrevPolicyDto2;
class SOAP_REMOTABLE_CLASS ReservationCoefficient2;
class SOAP_REMOTABLE_CLASS RiskObject2;
class SOAP_REMOTABLE_CLASS KaskoUnderwritingRequirements2;
class SOAP_REMOTABLE_CLASS UnderwritingRequirement2;
class SOAP_REMOTABLE_CLASS PrintRequest2;
class SOAP_REMOTABLE_CLASS PrintCertificateRequest2;
class SOAP_REMOTABLE_CLASS ContractorName2;
class SOAP_REMOTABLE_CLASS BrandModel2;
class SOAP_REMOTABLE_CLASS Address2;
class SOAP_REMOTABLE_CLASS Proxy2;
class SOAP_REMOTABLE_CLASS Pledgeholder2;
class SOAP_REMOTABLE_CLASS PrintAppRequest2;
class SOAP_REMOTABLE_CLASS Signer2;
class SOAP_REMOTABLE_CLASS SignerDocument2;
class SOAP_REMOTABLE_CLASS AppInsurer2;
class SOAP_REMOTABLE_CLASS PrintAppVehicle2;
class SOAP_REMOTABLE_CLASS Inspection2;
class SOAP_REMOTABLE_CLASS PrintAppRequestUl2;
class SOAP_REMOTABLE_CLASS VehicleAddInformation2;
class SOAP_REMOTABLE_CLASS PrintContractRequest2;
class SOAP_REMOTABLE_CLASS BeneficiaryPrintRequest2;
class SOAP_REMOTABLE_CLASS ContractInsurant2;
class SOAP_REMOTABLE_CLASS Passport2;
class SOAP_REMOTABLE_CLASS ContractInsurer2;
class SOAP_REMOTABLE_CLASS Payments2;
class SOAP_REMOTABLE_CLASS Payment2;
class SOAP_REMOTABLE_CLASS KaskoPrintContractUlRequestDto2;
class SOAP_REMOTABLE_CLASS LeasingContract2;
class SOAP_REMOTABLE_CLASS UnderwritingAdditionalInfo2;
class SOAP_REMOTABLE_CLASS Beneficiary2;
class SOAP_REMOTABLE_CLASS CommonDocument2;
class SOAP_REMOTABLE_CLASS Group2;
class SOAP_REMOTABLE_CLASS LeaseHolder2;
class SOAP_REMOTABLE_CLASS VehicleAdditionalInfo2;
class SOAP_REMOTABLE_CLASS VehicleProlongation2;
class SOAP_REMOTABLE_CLASS QuotationStateInfo2;
class SOAP_REMOTABLE_CLASS Quotation2;
class SOAP_REMOTABLE_CLASS VehicleResult2;
class SOAP_REMOTABLE_CLASS VehicleStateInfo2;
class SOAP_REMOTABLE_CLASS VehicleComment2;
class SOAP_REMOTABLE_CLASS CalculateVzdRequest2;
class SOAP_REMOTABLE_CLASS CalculateVzdVehicleRequest2;
class SOAP_REMOTABLE_CLASS CalculateVzdResult2;
class SOAP_REMOTABLE_CLASS CalculateVzdVehicleResponse2;
class SOAP_REMOTABLE_CLASS PrintULAddAgreementRequest2;
class SOAP_REMOTABLE_CLASS AddEquipmentInfo2;
class SOAP_REMOTABLE_CLASS InsurerProxyDto2;
class SOAP_REMOTABLE_CLASS PrintULBLAddAgreementRequest2;
class SOAP_REMOTABLE_CLASS EarlyApproveInfo2;
class SOAP_REMOTABLE_CLASS EarlyApproveResult2;
class SOAP_REMOTABLE_CLASS CalculationSheet2;
class SOAP_REMOTABLE_CLASS KaskoFLSpecialRequest2;
class SOAP_REMOTABLE_CLASS InsurantInfo2;
class SOAP_REMOTABLE_CLASS RegistrationAgencyDto2;
class SOAP_REMOTABLE_CLASS ExtendedBankInfo2;
class SOAP_REMOTABLE_CLASS KaskoAutoProtectionRequest2;
class SOAP_REMOTABLE_CLASS InsurantPrintDto2;
class SOAP_REMOTABLE_CLASS DocumentWithValidityDto2;
class SOAP_REMOTABLE_CLASS KaskoAutoProtectionRequestUL2;
class SOAP_REMOTABLE_CLASS DateTimeOffset;
class SOAP_REMOTABLE_CLASS OperationResultOfSelfTestResultBmLUPtsk;
class SOAP_REMOTABLE_CLASS OperationResultOfEarlyApproveResultoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfCalculateVzdResultoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfQuotationStateInfooTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfContractStatusNamesmxVaabBO;
class SOAP_REMOTABLE_CLASS OperationResultOfPrintResult1QqCV82X;
class SOAP_REMOTABLE_CLASS OperationResultOfCalculationResultoTurZuT3;
class SOAP_REMOTABLE_CLASS PrintResult;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfPrintResult1QqCV82X;
class SOAP_REMOTABLE_CLASS OperationResultOfCalculationResultoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfPrintResult1QqCV82X2;
class SOAP_REMOTABLE_CLASS OperationResultOfContractStatusNamesmxVaabBO2;
class SOAP_REMOTABLE_CLASS OperationResultOfQuotationStateInfooTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfCalculateVzdResultoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfPrintResult1QqCV82X2;
class SOAP_REMOTABLE_CLASS OperationResultOfEarlyApproveResultoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfSelfTestResultBmLUPtsk2;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringArrayOfstringty7Ep6D1;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringstring;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringVehicleAddInformationo_S6zkk9u;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringArrayOfstringty7Ep6D12;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringstring2;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringVehicleAddInformationo_S6zkk9u2;
class SOAP_REMOTABLE_CLASS BLTSInsRiskDto;
class SOAP_REMOTABLE_CLASS BLPeriodDto;
class SOAP_REMOTABLE_CLASS BLPaymentDto;
class SOAP_REMOTABLE_CLASS AddEquipmentByVehicle;
class SOAP_REMOTABLE_CLASS BLInsPeriod;
class SOAP_REMOTABLE_CLASS KaskoPrintRequestDto2;
class SOAP_REMOTABLE_CLASS BLTSInsRiskDto2;
class SOAP_REMOTABLE_CLASS BLPeriodDto2;
class SOAP_REMOTABLE_CLASS BLPaymentDto2;
class SOAP_REMOTABLE_CLASS AddEquipmentByVehicle2;
class SOAP_REMOTABLE_CLASS BLInsPeriod2;
class SOAP_REMOTABLE_CLASS PrintResult2;
class SOAP_REMOTABLE_CLASS ProcessStateFault;
class SOAP_REMOTABLE_CLASS ProcessStateFault2;
class SOAP_REMOTABLE_CLASS DateTimeOffset2;
class SOAP_REMOTABLE_CLASS SelfTestResult;
class SOAP_REMOTABLE_CLASS SelfTestResult2;

enum AntiTheftSystemRequirements   /* "Rgs.Ufo"[GblSmpl] */
{
  NotInstalled,
  InstalledRequired,
  InstalledOther,
  SupplAgreementNo5
};

class AntiTheftSystemRequirements_TypeInfoHolder : public TObject {
  AntiTheftSystemRequirements __instanceType;
public:
__published:
  __property AntiTheftSystemRequirements __propType = { read=__instanceType };
};

enum RequirementsToAddEquipment   /* "Rgs.Ufo"[GblSmpl] */
{
  NoRequirements,
  Specification,
  AddAgree9
};

class RequirementsToAddEquipment_TypeInfoHolder : public TObject {
  RequirementsToAddEquipment __instanceType;
public:
__published:
  __property RequirementsToAddEquipment __propType = { read=__instanceType };
};

enum ApproveType   /* "Rgs.Ufo"[GblSmpl] */
{
  NonStandardQuotation,
  ProlongQuotation
};

class ApproveType_TypeInfoHolder : public TObject {
  ApproveType __instanceType;
public:
__published:
  __property ApproveType __propType = { read=__instanceType };
};

enum ContractStatusNames   /* "http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums"[GblSmpl] */
{
  None,
  Project,
  Active,
  Finish,
  StandartCalcNPD,
  NonstandartCalcNPD,
  StandartCalcPPD,
  NonstandartCalcPPD,
  NotRequired,
  Required,
  OnApproval,
  Approval,
  Reject,
  Withdrawn,
  DataRequest,
  OnPreliminaryApproval,
  PreliminaryApproval,
  PreliminaryReject,
  PreliminaryWithdrawn,
  Contract,
  Cancelled,
  ProbablyDealCommitted,
  SubmittedToAccounting,
  TakenIntoAccount
};

class ContractStatusNames_TypeInfoHolder : public TObject {
  ContractStatusNames __instanceType;
public:
__published:
  __property ContractStatusNames __propType = { read=__instanceType };
};

enum GroupNames   /* "Rgs.Ufo"[GblSmpl] */
{
  Error,
  Sb,
  Zks,
  Cska,
  UndCo,
  UndBranch
};

class GroupNames_TypeInfoHolder : public TObject {
  GroupNames __instanceType;
public:
__published:
  __property GroupNames __propType = { read=__instanceType };
};

enum ULAddAgreementType   /* "http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print"[GblSmpl] */
{
  Agreement_9_1,
  Agreement_5_1,
  Agreement_AE,
  Agreement_ATS,
  Agreement_16,
  Agreement_10_1
};

class ULAddAgreementType_TypeInfoHolder : public TObject {
  ULAddAgreementType __instanceType;
public:
__published:
  __property ULAddAgreementType __propType = { read=__instanceType };
};

enum EarlyApproveResulState   /* "Rgs.Ufo"[GblSmpl] */
{
  SuccesEarlyApprove,
  ErrorEarlyApprove
};

class EarlyApproveResulState_TypeInfoHolder : public TObject {
  EarlyApproveResulState __instanceType;
public:
__published:
  __property EarlyApproveResulState __propType = { read=__instanceType };
};



// ************************************************************************ //
// XML       : User, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class User : public TRemotable {
private:
  WideString      FPassword;
  WideString      FUserName;
__published:
  __property WideString   Password = { index=(IS_NLBL), read=FPassword, write=FPassword };
  __property WideString   UserName = { index=(IS_NLBL), read=FUserName, write=FUserName };
};


typedef WideString guid; /* "http://schemas.microsoft.com/2003/10/Serialization/"[GblSmpl] */
typedef DynamicArray<Vehicle*>    ArrayOfVehicle; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : CalculationRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculationRequest : public TRemotable {
private:
  int             FActivePoliciesVehiclesCount;
  bool            FActivePoliciesVehiclesCount_Specified;
  WideString      FAutoDealerId;
  bool            FAutoDealerId_Specified;
  WideString      FBankId;
  bool            FBankId_Specified;
  WideString      FBranchId;
  bool            FBranchId_Specified;
  WideString      FCalculationDate;
  guid            FContractId;
  bool            FContractId_Specified;
  guid            FCorellationId;
  bool            FCorellationId_Specified;
  Insurant*       FInsurant;
  bool            FIsNonTypicalDocuments;
  bool            FIsNonTypicalDocuments_Specified;
  bool            FIsPreCalculation;
  int             FKaskoTerritoryId;
  WideString      FLeasingCompanyId;
  bool            FLeasingCompanyId_Specified;
  int             FLesseeSubjectTypeId;
  bool            FLesseeSubjectTypeId_Specified;
  WideString      FOtherPartnerId;
  bool            FOtherPartnerId_Specified;
  TXSDecimal*     FPlanVzd;
  bool            FPlanVzd_Specified;
  WideString      FPolicyEndDate;
  int             FPolicyPaymentsCount;
  WideString      FPolicyStartDate;
  int             FProductId;
  WideString      FProgramId;
  bool            FProgramId_Specified;
  WideString      FProjectId;
  bool            FProjectId_Specified;
  WideString      FSaleChannelType2008Id;
  bool            FSaleChannelType2008Id_Specified;
  ArrayOfVehicle  FVehicles;
  void __fastcall SetActivePoliciesVehiclesCount(int Index, int _prop_val)
  {  FActivePoliciesVehiclesCount = _prop_val; FActivePoliciesVehiclesCount_Specified = true;  }
  bool __fastcall ActivePoliciesVehiclesCount_Specified(int Index)
  {  return FActivePoliciesVehiclesCount_Specified;  } 
  void __fastcall SetAutoDealerId(int Index, WideString _prop_val)
  {  FAutoDealerId = _prop_val; FAutoDealerId_Specified = true;  }
  bool __fastcall AutoDealerId_Specified(int Index)
  {  return FAutoDealerId_Specified;  } 
  void __fastcall SetBankId(int Index, WideString _prop_val)
  {  FBankId = _prop_val; FBankId_Specified = true;  }
  bool __fastcall BankId_Specified(int Index)
  {  return FBankId_Specified;  } 
  void __fastcall SetBranchId(int Index, WideString _prop_val)
  {  FBranchId = _prop_val; FBranchId_Specified = true;  }
  bool __fastcall BranchId_Specified(int Index)
  {  return FBranchId_Specified;  } 
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
  void __fastcall SetCorellationId(int Index, guid _prop_val)
  {  FCorellationId = _prop_val; FCorellationId_Specified = true;  }
  bool __fastcall CorellationId_Specified(int Index)
  {  return FCorellationId_Specified;  } 
  void __fastcall SetIsNonTypicalDocuments(int Index, bool _prop_val)
  {  FIsNonTypicalDocuments = _prop_val; FIsNonTypicalDocuments_Specified = true;  }
  bool __fastcall IsNonTypicalDocuments_Specified(int Index)
  {  return FIsNonTypicalDocuments_Specified;  } 
  void __fastcall SetLeasingCompanyId(int Index, WideString _prop_val)
  {  FLeasingCompanyId = _prop_val; FLeasingCompanyId_Specified = true;  }
  bool __fastcall LeasingCompanyId_Specified(int Index)
  {  return FLeasingCompanyId_Specified;  } 
  void __fastcall SetLesseeSubjectTypeId(int Index, int _prop_val)
  {  FLesseeSubjectTypeId = _prop_val; FLesseeSubjectTypeId_Specified = true;  }
  bool __fastcall LesseeSubjectTypeId_Specified(int Index)
  {  return FLesseeSubjectTypeId_Specified;  } 
  void __fastcall SetOtherPartnerId(int Index, WideString _prop_val)
  {  FOtherPartnerId = _prop_val; FOtherPartnerId_Specified = true;  }
  bool __fastcall OtherPartnerId_Specified(int Index)
  {  return FOtherPartnerId_Specified;  } 
  void __fastcall SetPlanVzd(int Index, TXSDecimal* _prop_val)
  {  FPlanVzd = _prop_val; FPlanVzd_Specified = true;  }
  bool __fastcall PlanVzd_Specified(int Index)
  {  return FPlanVzd_Specified;  } 
  void __fastcall SetProgramId(int Index, WideString _prop_val)
  {  FProgramId = _prop_val; FProgramId_Specified = true;  }
  bool __fastcall ProgramId_Specified(int Index)
  {  return FProgramId_Specified;  } 
  void __fastcall SetProjectId(int Index, WideString _prop_val)
  {  FProjectId = _prop_val; FProjectId_Specified = true;  }
  bool __fastcall ProjectId_Specified(int Index)
  {  return FProjectId_Specified;  } 
  void __fastcall SetSaleChannelType2008Id(int Index, WideString _prop_val)
  {  FSaleChannelType2008Id = _prop_val; FSaleChannelType2008Id_Specified = true;  }
  bool __fastcall SaleChannelType2008Id_Specified(int Index)
  {  return FSaleChannelType2008Id_Specified;  } 

public:
  __fastcall ~CalculationRequest();
__published:
  __property int        ActivePoliciesVehiclesCount = { index=(IS_OPTN|IS_NLBL), read=FActivePoliciesVehiclesCount, write=SetActivePoliciesVehiclesCount, stored = ActivePoliciesVehiclesCount_Specified };
  __property WideString AutoDealerId = { index=(IS_OPTN|IS_NLBL), read=FAutoDealerId, write=SetAutoDealerId, stored = AutoDealerId_Specified };
  __property WideString     BankId = { index=(IS_OPTN|IS_NLBL), read=FBankId, write=SetBankId, stored = BankId_Specified };
  __property WideString   BranchId = { index=(IS_OPTN|IS_NLBL), read=FBranchId, write=SetBranchId, stored = BranchId_Specified };
  __property WideString CalculationDate = { index=(IS_NLBL), read=FCalculationDate, write=FCalculationDate };
  __property guid       ContractId = { index=(IS_OPTN|IS_NLBL), read=FContractId, write=SetContractId, stored = ContractId_Specified };
  __property guid       CorellationId = { index=(IS_OPTN|IS_NLBL), read=FCorellationId, write=SetCorellationId, stored = CorellationId_Specified };
  __property Insurant*    Insurant = { index=(IS_NLBL), read=FInsurant, write=FInsurant };
  __property bool       IsNonTypicalDocuments = { index=(IS_OPTN), read=FIsNonTypicalDocuments, write=SetIsNonTypicalDocuments, stored = IsNonTypicalDocuments_Specified };
  __property bool       IsPreCalculation = { read=FIsPreCalculation, write=FIsPreCalculation };
  __property int        KaskoTerritoryId = { read=FKaskoTerritoryId, write=FKaskoTerritoryId };
  __property WideString LeasingCompanyId = { index=(IS_OPTN|IS_NLBL), read=FLeasingCompanyId, write=SetLeasingCompanyId, stored = LeasingCompanyId_Specified };
  __property int        LesseeSubjectTypeId = { index=(IS_OPTN|IS_NLBL), read=FLesseeSubjectTypeId, write=SetLesseeSubjectTypeId, stored = LesseeSubjectTypeId_Specified };
  __property WideString OtherPartnerId = { index=(IS_OPTN|IS_NLBL), read=FOtherPartnerId, write=SetOtherPartnerId, stored = OtherPartnerId_Specified };
  __property TXSDecimal*    PlanVzd = { index=(IS_OPTN|IS_NLBL), read=FPlanVzd, write=SetPlanVzd, stored = PlanVzd_Specified };
  __property WideString PolicyEndDate = { index=(IS_NLBL), read=FPolicyEndDate, write=FPolicyEndDate };
  __property int        PolicyPaymentsCount = { read=FPolicyPaymentsCount, write=FPolicyPaymentsCount };
  __property WideString PolicyStartDate = { index=(IS_NLBL), read=FPolicyStartDate, write=FPolicyStartDate };
  __property int         ProductId = { read=FProductId, write=FProductId };
  __property WideString  ProgramId = { index=(IS_OPTN|IS_NLBL), read=FProgramId, write=SetProgramId, stored = ProgramId_Specified };
  __property WideString  ProjectId = { index=(IS_OPTN|IS_NLBL), read=FProjectId, write=SetProjectId, stored = ProjectId_Specified };
  __property WideString SaleChannelType2008Id = { index=(IS_OPTN|IS_NLBL), read=FSaleChannelType2008Id, write=SetSaleChannelType2008Id, stored = SaleChannelType2008Id_Specified };
  __property ArrayOfVehicle   Vehicles = { index=(IS_NLBL), read=FVehicles, write=FVehicles };
};




// ************************************************************************ //
// XML       : Insurant, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Insurant : public TRemotable {
private:
  TXSDateTime*    FBirthDate;
  bool            FBirthDate_Specified;
  InsurantDocument* FDocument;
  bool            FDocument_Specified;
  WideString      FINN;
  bool            FINN_Specified;
  bool            FIsKeyClient;
  bool            FIsKeyClient_Specified;
  WideString      FKladrCode;
  bool            FKladrCode_Specified;
  PersonName*     FName;
  bool            FName_Specified;
  WideString      FOGRN;
  bool            FOGRN_Specified;
  WideString      FOGRNIP;
  bool            FOGRNIP_Specified;
  LegalEntity*    FOrganization;
  bool            FOrganization_Specified;
  int             FSubjectTypeId;
  void __fastcall SetBirthDate(int Index, TXSDateTime* _prop_val)
  {  FBirthDate = _prop_val; FBirthDate_Specified = true;  }
  bool __fastcall BirthDate_Specified(int Index)
  {  return FBirthDate_Specified;  } 
  void __fastcall SetDocument(int Index, InsurantDocument* _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetINN(int Index, WideString _prop_val)
  {  FINN = _prop_val; FINN_Specified = true;  }
  bool __fastcall INN_Specified(int Index)
  {  return FINN_Specified;  } 
  void __fastcall SetIsKeyClient(int Index, bool _prop_val)
  {  FIsKeyClient = _prop_val; FIsKeyClient_Specified = true;  }
  bool __fastcall IsKeyClient_Specified(int Index)
  {  return FIsKeyClient_Specified;  } 
  void __fastcall SetKladrCode(int Index, WideString _prop_val)
  {  FKladrCode = _prop_val; FKladrCode_Specified = true;  }
  bool __fastcall KladrCode_Specified(int Index)
  {  return FKladrCode_Specified;  } 
  void __fastcall SetName(int Index, PersonName* _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetOGRN(int Index, WideString _prop_val)
  {  FOGRN = _prop_val; FOGRN_Specified = true;  }
  bool __fastcall OGRN_Specified(int Index)
  {  return FOGRN_Specified;  } 
  void __fastcall SetOGRNIP(int Index, WideString _prop_val)
  {  FOGRNIP = _prop_val; FOGRNIP_Specified = true;  }
  bool __fastcall OGRNIP_Specified(int Index)
  {  return FOGRNIP_Specified;  } 
  void __fastcall SetOrganization(int Index, LegalEntity* _prop_val)
  {  FOrganization = _prop_val; FOrganization_Specified = true;  }
  bool __fastcall Organization_Specified(int Index)
  {  return FOrganization_Specified;  } 

public:
  __fastcall ~Insurant();
__published:
  __property TXSDateTime*  BirthDate = { index=(IS_OPTN|IS_NLBL), read=FBirthDate, write=SetBirthDate, stored = BirthDate_Specified };
  __property InsurantDocument*   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property WideString        INN = { index=(IS_OPTN|IS_NLBL), read=FINN, write=SetINN, stored = INN_Specified };
  __property bool       IsKeyClient = { index=(IS_OPTN), read=FIsKeyClient, write=SetIsKeyClient, stored = IsKeyClient_Specified };
  __property WideString  KladrCode = { index=(IS_OPTN|IS_NLBL), read=FKladrCode, write=SetKladrCode, stored = KladrCode_Specified };
  __property PersonName*       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString       OGRN = { index=(IS_OPTN|IS_NLBL), read=FOGRN, write=SetOGRN, stored = OGRN_Specified };
  __property WideString     OGRNIP = { index=(IS_OPTN|IS_NLBL), read=FOGRNIP, write=SetOGRNIP, stored = OGRNIP_Specified };
  __property LegalEntity* Organization = { index=(IS_OPTN|IS_NLBL), read=FOrganization, write=SetOrganization, stored = Organization_Specified };
  __property int        SubjectTypeId = { read=FSubjectTypeId, write=FSubjectTypeId };
};




// ************************************************************************ //
// XML       : PersonName, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PersonName : public TRemotable {
private:
  WideString      FFirstName;
  bool            FFirstName_Specified;
  WideString      FLastName;
  bool            FLastName_Specified;
  WideString      FSecondName;
  bool            FSecondName_Specified;
  void __fastcall SetFirstName(int Index, WideString _prop_val)
  {  FFirstName = _prop_val; FFirstName_Specified = true;  }
  bool __fastcall FirstName_Specified(int Index)
  {  return FFirstName_Specified;  } 
  void __fastcall SetLastName(int Index, WideString _prop_val)
  {  FLastName = _prop_val; FLastName_Specified = true;  }
  bool __fastcall LastName_Specified(int Index)
  {  return FLastName_Specified;  } 
  void __fastcall SetSecondName(int Index, WideString _prop_val)
  {  FSecondName = _prop_val; FSecondName_Specified = true;  }
  bool __fastcall SecondName_Specified(int Index)
  {  return FSecondName_Specified;  } 
__published:
  __property WideString  FirstName = { index=(IS_OPTN|IS_NLBL), read=FFirstName, write=SetFirstName, stored = FirstName_Specified };
  __property WideString   LastName = { index=(IS_OPTN|IS_NLBL), read=FLastName, write=SetLastName, stored = LastName_Specified };
  __property WideString SecondName = { index=(IS_OPTN|IS_NLBL), read=FSecondName, write=SetSecondName, stored = SecondName_Specified };
};




// ************************************************************************ //
// XML       : LegalEntity, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class LegalEntity : public TRemotable {
private:
  WideString      FName;
  bool            FName_Specified;
  WideString      FOrgForm;
  bool            FOrgForm_Specified;
  WideString      FOrgFormFull;
  bool            FOrgFormFull_Specified;
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetOrgForm(int Index, WideString _prop_val)
  {  FOrgForm = _prop_val; FOrgForm_Specified = true;  }
  bool __fastcall OrgForm_Specified(int Index)
  {  return FOrgForm_Specified;  } 
  void __fastcall SetOrgFormFull(int Index, WideString _prop_val)
  {  FOrgFormFull = _prop_val; FOrgFormFull_Specified = true;  }
  bool __fastcall OrgFormFull_Specified(int Index)
  {  return FOrgFormFull_Specified;  } 
__published:
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString    OrgForm = { index=(IS_OPTN|IS_NLBL), read=FOrgForm, write=SetOrgForm, stored = OrgForm_Specified };
  __property WideString OrgFormFull = { index=(IS_OPTN|IS_NLBL), read=FOrgFormFull, write=SetOrgFormFull, stored = OrgFormFull_Specified };
};




// ************************************************************************ //
// XML       : Document, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Document : public TRemotable {
private:
  WideString      FNumber;
  bool            FNumber_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 
__published:
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
};




// ************************************************************************ //
// XML       : InsurantDocument, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurantDocument : public Document {
private:
  WideString      FTypeId;
__published:
  __property WideString     TypeId = { index=(IS_NLBL), read=FTypeId, write=FTypeId };
};


typedef DynamicArray<AddEquipmentRequest*> ArrayOfAddEquipmentRequest; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<WideString>  ArrayOfstring;  /* "http://schemas.microsoft.com/2003/10/Serialization/Arrays"[GblCplx] */


// ************************************************************************ //
// XML       : VehicleBaseDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleBaseDto : public TRemotable {
private:
  WideString      FChassisNumber;
  bool            FChassisNumber_Specified;
  WideString      FFrameNumber;
  bool            FFrameNumber_Specified;
  ArrayOfstring   FReservationIds;
  bool            FReservationIds_Specified;
  WideString      FVIN;
  bool            FVIN_Specified;
  WideString      FVehNumber;
  void __fastcall SetChassisNumber(int Index, WideString _prop_val)
  {  FChassisNumber = _prop_val; FChassisNumber_Specified = true;  }
  bool __fastcall ChassisNumber_Specified(int Index)
  {  return FChassisNumber_Specified;  } 
  void __fastcall SetFrameNumber(int Index, WideString _prop_val)
  {  FFrameNumber = _prop_val; FFrameNumber_Specified = true;  }
  bool __fastcall FrameNumber_Specified(int Index)
  {  return FFrameNumber_Specified;  } 
  void __fastcall SetReservationIds(int Index, ArrayOfstring _prop_val)
  {  FReservationIds = _prop_val; FReservationIds_Specified = true;  }
  bool __fastcall ReservationIds_Specified(int Index)
  {  return FReservationIds_Specified;  } 
  void __fastcall SetVIN(int Index, WideString _prop_val)
  {  FVIN = _prop_val; FVIN_Specified = true;  }
  bool __fastcall VIN_Specified(int Index)
  {  return FVIN_Specified;  } 
__published:
  __property WideString ChassisNumber = { index=(IS_OPTN|IS_NLBL), read=FChassisNumber, write=SetChassisNumber, stored = ChassisNumber_Specified };
  __property WideString FrameNumber = { index=(IS_OPTN|IS_NLBL), read=FFrameNumber, write=SetFrameNumber, stored = FrameNumber_Specified };
  __property ArrayOfstring ReservationIds = { index=(IS_OPTN|IS_NLBL), read=FReservationIds, write=SetReservationIds, stored = ReservationIds_Specified };
  __property WideString        VIN = { index=(IS_OPTN|IS_NLBL), read=FVIN, write=SetVIN, stored = VIN_Specified };
  __property WideString  VehNumber = { index=(IS_NLBL), read=FVehNumber, write=FVehNumber };
};


typedef DynamicArray<Driver*>     ArrayOfDriver;  /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : Vehicle, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Vehicle : public VehicleBaseDto {
private:
  TXSDecimal*     FAccidentLiability;
  ArrayOfAddEquipmentRequest FAddEquipments;
  bool            FAddEquipments_Specified;
  int             FAdmittedLimitId;
  bool            FAdmittedLimitId_Specified;
  ArrayOfstring   FAlarmIds;
  bool            FAlarmIds_Specified;
  int             FAllowWeight;
  bool            FAllowWeight_Specified;
  TXSDecimal*     FCost;
  bool            FCost_Specified;
  TXSDecimal*     FDmsLiability;
  ArrayOfDriver   FDrivers;
  bool            FDrivers_Specified;
  TXSDecimal*     FDsagoLiability;
  TXSDecimal*     FDsagoPremium;
  bool            FDsagoPremium_Specified;
  Franchise*      FFranchise;
  guid            FGroupId;
  bool            FGroupId_Specified;
  WideString      FGroupName;
  bool            FGroupName_Specified;
  bool            FHasTrailer;
  bool            FHasTrailer_Specified;
  bool            FIsFirstRisk;
  bool            FIsFranchiseForK1;
  bool            FIsFranchiseForK1_Specified;
  bool            FIsGroupDisabled;
  bool            FIsGroupDisabled_Specified;
  bool            FIsLiabilityNonAggregate;
  bool            FIsLiabilityNonAggregate_Specified;
  bool            FIsNeedAddAgreement5;
  bool            FIsNeedAddAgreement5_Specified;
  TXSDecimal*     FKa;
  bool            FKa_Specified;
  TXSDecimal*     FKans;
  bool            FKans_Specified;
  int             FKaskoRiskId;
  TXSDecimal*     FKc;
  bool            FKc_Specified;
  TXSDecimal*     FLiability;
  bool            FLiability_Specified;
  WideString      FLicensePlate;
  bool            FLicensePlate_Specified;
  int             FManufactureYear;
  WideString      FPaymentMethodId;
  int             FPreCalcKaskoClaimsCount;
  bool            FPreCalcKaskoClaimsCount_Specified;
  int             FPreCalcOsagoHistoryClass;
  bool            FPreCalcOsagoHistoryClass_Specified;
  WideString      FRsaModelId;
  int             FSeatCount;
  bool            FSeatCount_Specified;
  WideString      FTransdekraId;
  bool            FTransdekraId_Specified;
  TXSDecimal*     FTransdekraPrice;
  bool            FTransdekraPrice_Specified;
  WideString      FUsagePurposeId;
  bool            FUsagePurposeId_Specified;
  TXSDecimal*     FVehMileage;
  bool            FVehMileage_Specified;
  TXSDecimal*     FVehicleDamageSumLimit;
  bool            FVehicleDamageSumLimit_Specified;
  TXSDateTime*    FVehiclePTSDate;
  bool            FVehiclePTSDate_Specified;
  void __fastcall SetAddEquipments(int Index, ArrayOfAddEquipmentRequest _prop_val)
  {  FAddEquipments = _prop_val; FAddEquipments_Specified = true;  }
  bool __fastcall AddEquipments_Specified(int Index)
  {  return FAddEquipments_Specified;  } 
  void __fastcall SetAdmittedLimitId(int Index, int _prop_val)
  {  FAdmittedLimitId = _prop_val; FAdmittedLimitId_Specified = true;  }
  bool __fastcall AdmittedLimitId_Specified(int Index)
  {  return FAdmittedLimitId_Specified;  } 
  void __fastcall SetAlarmIds(int Index, ArrayOfstring _prop_val)
  {  FAlarmIds = _prop_val; FAlarmIds_Specified = true;  }
  bool __fastcall AlarmIds_Specified(int Index)
  {  return FAlarmIds_Specified;  } 
  void __fastcall SetAllowWeight(int Index, int _prop_val)
  {  FAllowWeight = _prop_val; FAllowWeight_Specified = true;  }
  bool __fastcall AllowWeight_Specified(int Index)
  {  return FAllowWeight_Specified;  } 
  void __fastcall SetCost(int Index, TXSDecimal* _prop_val)
  {  FCost = _prop_val; FCost_Specified = true;  }
  bool __fastcall Cost_Specified(int Index)
  {  return FCost_Specified;  } 
  void __fastcall SetDrivers(int Index, ArrayOfDriver _prop_val)
  {  FDrivers = _prop_val; FDrivers_Specified = true;  }
  bool __fastcall Drivers_Specified(int Index)
  {  return FDrivers_Specified;  } 
  void __fastcall SetDsagoPremium(int Index, TXSDecimal* _prop_val)
  {  FDsagoPremium = _prop_val; FDsagoPremium_Specified = true;  }
  bool __fastcall DsagoPremium_Specified(int Index)
  {  return FDsagoPremium_Specified;  } 
  void __fastcall SetGroupId(int Index, guid _prop_val)
  {  FGroupId = _prop_val; FGroupId_Specified = true;  }
  bool __fastcall GroupId_Specified(int Index)
  {  return FGroupId_Specified;  } 
  void __fastcall SetGroupName(int Index, WideString _prop_val)
  {  FGroupName = _prop_val; FGroupName_Specified = true;  }
  bool __fastcall GroupName_Specified(int Index)
  {  return FGroupName_Specified;  } 
  void __fastcall SetHasTrailer(int Index, bool _prop_val)
  {  FHasTrailer = _prop_val; FHasTrailer_Specified = true;  }
  bool __fastcall HasTrailer_Specified(int Index)
  {  return FHasTrailer_Specified;  } 
  void __fastcall SetIsFranchiseForK1(int Index, bool _prop_val)
  {  FIsFranchiseForK1 = _prop_val; FIsFranchiseForK1_Specified = true;  }
  bool __fastcall IsFranchiseForK1_Specified(int Index)
  {  return FIsFranchiseForK1_Specified;  } 
  void __fastcall SetIsGroupDisabled(int Index, bool _prop_val)
  {  FIsGroupDisabled = _prop_val; FIsGroupDisabled_Specified = true;  }
  bool __fastcall IsGroupDisabled_Specified(int Index)
  {  return FIsGroupDisabled_Specified;  } 
  void __fastcall SetIsLiabilityNonAggregate(int Index, bool _prop_val)
  {  FIsLiabilityNonAggregate = _prop_val; FIsLiabilityNonAggregate_Specified = true;  }
  bool __fastcall IsLiabilityNonAggregate_Specified(int Index)
  {  return FIsLiabilityNonAggregate_Specified;  } 
  void __fastcall SetIsNeedAddAgreement5(int Index, bool _prop_val)
  {  FIsNeedAddAgreement5 = _prop_val; FIsNeedAddAgreement5_Specified = true;  }
  bool __fastcall IsNeedAddAgreement5_Specified(int Index)
  {  return FIsNeedAddAgreement5_Specified;  } 
  void __fastcall SetKa(int Index, TXSDecimal* _prop_val)
  {  FKa = _prop_val; FKa_Specified = true;  }
  bool __fastcall Ka_Specified(int Index)
  {  return FKa_Specified;  } 
  void __fastcall SetKans(int Index, TXSDecimal* _prop_val)
  {  FKans = _prop_val; FKans_Specified = true;  }
  bool __fastcall Kans_Specified(int Index)
  {  return FKans_Specified;  } 
  void __fastcall SetKc(int Index, TXSDecimal* _prop_val)
  {  FKc = _prop_val; FKc_Specified = true;  }
  bool __fastcall Kc_Specified(int Index)
  {  return FKc_Specified;  } 
  void __fastcall SetLiability(int Index, TXSDecimal* _prop_val)
  {  FLiability = _prop_val; FLiability_Specified = true;  }
  bool __fastcall Liability_Specified(int Index)
  {  return FLiability_Specified;  } 
  void __fastcall SetLicensePlate(int Index, WideString _prop_val)
  {  FLicensePlate = _prop_val; FLicensePlate_Specified = true;  }
  bool __fastcall LicensePlate_Specified(int Index)
  {  return FLicensePlate_Specified;  } 
  void __fastcall SetPreCalcKaskoClaimsCount(int Index, int _prop_val)
  {  FPreCalcKaskoClaimsCount = _prop_val; FPreCalcKaskoClaimsCount_Specified = true;  }
  bool __fastcall PreCalcKaskoClaimsCount_Specified(int Index)
  {  return FPreCalcKaskoClaimsCount_Specified;  } 
  void __fastcall SetPreCalcOsagoHistoryClass(int Index, int _prop_val)
  {  FPreCalcOsagoHistoryClass = _prop_val; FPreCalcOsagoHistoryClass_Specified = true;  }
  bool __fastcall PreCalcOsagoHistoryClass_Specified(int Index)
  {  return FPreCalcOsagoHistoryClass_Specified;  } 
  void __fastcall SetSeatCount(int Index, int _prop_val)
  {  FSeatCount = _prop_val; FSeatCount_Specified = true;  }
  bool __fastcall SeatCount_Specified(int Index)
  {  return FSeatCount_Specified;  } 
  void __fastcall SetTransdekraId(int Index, WideString _prop_val)
  {  FTransdekraId = _prop_val; FTransdekraId_Specified = true;  }
  bool __fastcall TransdekraId_Specified(int Index)
  {  return FTransdekraId_Specified;  } 
  void __fastcall SetTransdekraPrice(int Index, TXSDecimal* _prop_val)
  {  FTransdekraPrice = _prop_val; FTransdekraPrice_Specified = true;  }
  bool __fastcall TransdekraPrice_Specified(int Index)
  {  return FTransdekraPrice_Specified;  } 
  void __fastcall SetUsagePurposeId(int Index, WideString _prop_val)
  {  FUsagePurposeId = _prop_val; FUsagePurposeId_Specified = true;  }
  bool __fastcall UsagePurposeId_Specified(int Index)
  {  return FUsagePurposeId_Specified;  } 
  void __fastcall SetVehMileage(int Index, TXSDecimal* _prop_val)
  {  FVehMileage = _prop_val; FVehMileage_Specified = true;  }
  bool __fastcall VehMileage_Specified(int Index)
  {  return FVehMileage_Specified;  } 
  void __fastcall SetVehicleDamageSumLimit(int Index, TXSDecimal* _prop_val)
  {  FVehicleDamageSumLimit = _prop_val; FVehicleDamageSumLimit_Specified = true;  }
  bool __fastcall VehicleDamageSumLimit_Specified(int Index)
  {  return FVehicleDamageSumLimit_Specified;  } 
  void __fastcall SetVehiclePTSDate(int Index, TXSDateTime* _prop_val)
  {  FVehiclePTSDate = _prop_val; FVehiclePTSDate_Specified = true;  }
  bool __fastcall VehiclePTSDate_Specified(int Index)
  {  return FVehiclePTSDate_Specified;  } 

public:
  __fastcall ~Vehicle();
__published:
  __property TXSDecimal* AccidentLiability = { read=FAccidentLiability, write=FAccidentLiability };
  __property ArrayOfAddEquipmentRequest AddEquipments = { index=(IS_OPTN|IS_NLBL), read=FAddEquipments, write=SetAddEquipments, stored = AddEquipments_Specified };
  __property int        AdmittedLimitId = { index=(IS_OPTN), read=FAdmittedLimitId, write=SetAdmittedLimitId, stored = AdmittedLimitId_Specified };
  __property ArrayOfstring   AlarmIds = { index=(IS_OPTN|IS_NLBL), read=FAlarmIds, write=SetAlarmIds, stored = AlarmIds_Specified };
  __property int        AllowWeight = { index=(IS_OPTN|IS_NLBL), read=FAllowWeight, write=SetAllowWeight, stored = AllowWeight_Specified };
  __property TXSDecimal*       Cost = { index=(IS_OPTN), read=FCost, write=SetCost, stored = Cost_Specified };
  __property TXSDecimal* DmsLiability = { read=FDmsLiability, write=FDmsLiability };
  __property ArrayOfDriver    Drivers = { index=(IS_OPTN|IS_NLBL), read=FDrivers, write=SetDrivers, stored = Drivers_Specified };
  __property TXSDecimal* DsagoLiability = { read=FDsagoLiability, write=FDsagoLiability };
  __property TXSDecimal* DsagoPremium = { index=(IS_OPTN|IS_NLBL), read=FDsagoPremium, write=SetDsagoPremium, stored = DsagoPremium_Specified };
  __property Franchise*  Franchise = { index=(IS_NLBL), read=FFranchise, write=FFranchise };
  __property guid          GroupId = { index=(IS_OPTN|IS_NLBL), read=FGroupId, write=SetGroupId, stored = GroupId_Specified };
  __property WideString  GroupName = { index=(IS_OPTN|IS_NLBL), read=FGroupName, write=SetGroupName, stored = GroupName_Specified };
  __property bool       HasTrailer = { index=(IS_OPTN|IS_NLBL), read=FHasTrailer, write=SetHasTrailer, stored = HasTrailer_Specified };
  __property bool       IsFirstRisk = { read=FIsFirstRisk, write=FIsFirstRisk };
  __property bool       IsFranchiseForK1 = { index=(IS_OPTN|IS_NLBL), read=FIsFranchiseForK1, write=SetIsFranchiseForK1, stored = IsFranchiseForK1_Specified };
  __property bool       IsGroupDisabled = { index=(IS_OPTN), read=FIsGroupDisabled, write=SetIsGroupDisabled, stored = IsGroupDisabled_Specified };
  __property bool       IsLiabilityNonAggregate = { index=(IS_OPTN), read=FIsLiabilityNonAggregate, write=SetIsLiabilityNonAggregate, stored = IsLiabilityNonAggregate_Specified };
  __property bool       IsNeedAddAgreement5 = { index=(IS_OPTN), read=FIsNeedAddAgreement5, write=SetIsNeedAddAgreement5, stored = IsNeedAddAgreement5_Specified };
  __property TXSDecimal*         Ka = { index=(IS_OPTN|IS_NLBL), read=FKa, write=SetKa, stored = Ka_Specified };
  __property TXSDecimal*       Kans = { index=(IS_OPTN|IS_NLBL), read=FKans, write=SetKans, stored = Kans_Specified };
  __property int        KaskoRiskId = { read=FKaskoRiskId, write=FKaskoRiskId };
  __property TXSDecimal*         Kc = { index=(IS_OPTN|IS_NLBL), read=FKc, write=SetKc, stored = Kc_Specified };
  __property TXSDecimal*  Liability = { index=(IS_OPTN), read=FLiability, write=SetLiability, stored = Liability_Specified };
  __property WideString LicensePlate = { index=(IS_OPTN|IS_NLBL), read=FLicensePlate, write=SetLicensePlate, stored = LicensePlate_Specified };
  __property int        ManufactureYear = { read=FManufactureYear, write=FManufactureYear };
  __property WideString PaymentMethodId = { index=(IS_NLBL), read=FPaymentMethodId, write=FPaymentMethodId };
  __property int        PreCalcKaskoClaimsCount = { index=(IS_OPTN|IS_NLBL), read=FPreCalcKaskoClaimsCount, write=SetPreCalcKaskoClaimsCount, stored = PreCalcKaskoClaimsCount_Specified };
  __property int        PreCalcOsagoHistoryClass = { index=(IS_OPTN|IS_NLBL), read=FPreCalcOsagoHistoryClass, write=SetPreCalcOsagoHistoryClass, stored = PreCalcOsagoHistoryClass_Specified };
  __property WideString RsaModelId = { index=(IS_NLBL), read=FRsaModelId, write=FRsaModelId };
  __property int         SeatCount = { index=(IS_OPTN|IS_NLBL), read=FSeatCount, write=SetSeatCount, stored = SeatCount_Specified };
  __property WideString TransdekraId = { index=(IS_OPTN|IS_NLBL), read=FTransdekraId, write=SetTransdekraId, stored = TransdekraId_Specified };
  __property TXSDecimal* TransdekraPrice = { index=(IS_OPTN|IS_NLBL), read=FTransdekraPrice, write=SetTransdekraPrice, stored = TransdekraPrice_Specified };
  __property WideString UsagePurposeId = { index=(IS_OPTN|IS_NLBL), read=FUsagePurposeId, write=SetUsagePurposeId, stored = UsagePurposeId_Specified };
  __property TXSDecimal* VehMileage = { index=(IS_OPTN|IS_NLBL), read=FVehMileage, write=SetVehMileage, stored = VehMileage_Specified };
  __property TXSDecimal* VehicleDamageSumLimit = { index=(IS_OPTN|IS_NLBL), read=FVehicleDamageSumLimit, write=SetVehicleDamageSumLimit, stored = VehicleDamageSumLimit_Specified };
  __property TXSDateTime* VehiclePTSDate = { index=(IS_OPTN|IS_NLBL), read=FVehiclePTSDate, write=SetVehiclePTSDate, stored = VehiclePTSDate_Specified };
};




// ************************************************************************ //
// XML       : Franchise, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Franchise : public TRemotable {
private:
  WideString      FTypeId;
  WideString      FUnitId;
  bool            FUnitId_Specified;
  TXSDecimal*     FValue;
  bool            FValue_Specified;
  void __fastcall SetUnitId(int Index, WideString _prop_val)
  {  FUnitId = _prop_val; FUnitId_Specified = true;  }
  bool __fastcall UnitId_Specified(int Index)
  {  return FUnitId_Specified;  } 
  void __fastcall SetValue(int Index, TXSDecimal* _prop_val)
  {  FValue = _prop_val; FValue_Specified = true;  }
  bool __fastcall Value_Specified(int Index)
  {  return FValue_Specified;  } 

public:
  __fastcall ~Franchise();
__published:
  __property WideString     TypeId = { index=(IS_NLBL), read=FTypeId, write=FTypeId };
  __property WideString     UnitId = { index=(IS_OPTN|IS_NLBL), read=FUnitId, write=SetUnitId, stored = UnitId_Specified };
  __property TXSDecimal*      Value = { index=(IS_OPTN), read=FValue, write=SetValue, stored = Value_Specified };
};




// ************************************************************************ //
// XML       : AddEquipmentRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddEquipmentRequest : public TRemotable {
private:
  WideString      FId;
  TXSDecimal*     FLiability;

public:
  __fastcall ~AddEquipmentRequest();
__published:
  __property WideString         Id = { index=(IS_NLBL), read=FId, write=FId };
  __property TXSDecimal*  Liability = { read=FLiability, write=FLiability };
};




// ************************************************************************ //
// XML       : Driver, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Driver : public TRemotable {
private:
  TXSDateTime*    FBirthDate;
  DriverLicense*  FDriverLicense;
  bool            FDriverLicense_Specified;
  TXSDateTime*    FDrivingStartDate;
  bool            FDrivingStartDate_Specified;
  PersonName*     FFullName;
  bool            FFullName_Specified;
  WideString      FGenderCode;
  WideString      FId;
  bool            FId_Specified;
  void __fastcall SetDriverLicense(int Index, DriverLicense* _prop_val)
  {  FDriverLicense = _prop_val; FDriverLicense_Specified = true;  }
  bool __fastcall DriverLicense_Specified(int Index)
  {  return FDriverLicense_Specified;  } 
  void __fastcall SetDrivingStartDate(int Index, TXSDateTime* _prop_val)
  {  FDrivingStartDate = _prop_val; FDrivingStartDate_Specified = true;  }
  bool __fastcall DrivingStartDate_Specified(int Index)
  {  return FDrivingStartDate_Specified;  } 
  void __fastcall SetFullName(int Index, PersonName* _prop_val)
  {  FFullName = _prop_val; FFullName_Specified = true;  }
  bool __fastcall FullName_Specified(int Index)
  {  return FFullName_Specified;  } 
  void __fastcall SetId(int Index, WideString _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 

public:
  __fastcall ~Driver();
__published:
  __property TXSDateTime*  BirthDate = { read=FBirthDate, write=FBirthDate };
  __property DriverLicense* DriverLicense = { index=(IS_OPTN|IS_NLBL), read=FDriverLicense, write=SetDriverLicense, stored = DriverLicense_Specified };
  __property TXSDateTime* DrivingStartDate = { index=(IS_OPTN), read=FDrivingStartDate, write=SetDrivingStartDate, stored = DrivingStartDate_Specified };
  __property PersonName*   FullName = { index=(IS_OPTN|IS_NLBL), read=FFullName, write=SetFullName, stored = FullName_Specified };
  __property WideString GenderCode = { index=(IS_NLBL), read=FGenderCode, write=FGenderCode };
  __property WideString         Id = { index=(IS_OPTN|IS_NLBL), read=FId, write=SetId, stored = Id_Specified };
};




// ************************************************************************ //
// XML       : DriverLicense, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverLicense : public Document {
private:
  WideString      FType;
  bool            FType_Specified;
  void __fastcall SetType(int Index, WideString _prop_val)
  {  FType = _prop_val; FType_Specified = true;  }
  bool __fastcall Type_Specified(int Index)
  {  return FType_Specified;  } 
__published:
  __property WideString       Type = { index=(IS_OPTN|IS_NLBL), read=FType, write=SetType, stored = Type_Specified };
};


typedef DynamicArray<KaskoReCalculateVehicle*> ArrayOfKaskoReCalculateVehicle; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : KaskoReCalculateRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoReCalculateRequest : public CalculationRequest {
private:
  ArrayOfKaskoReCalculateVehicle FReCalculateVehicles;
  bool            FReCalculateVehicles_Specified;
  WideString      FUnderwriterLnr;
  bool            FUnderwriterLnr_Specified;
  void __fastcall SetReCalculateVehicles(int Index, ArrayOfKaskoReCalculateVehicle _prop_val)
  {  FReCalculateVehicles = _prop_val; FReCalculateVehicles_Specified = true;  }
  bool __fastcall ReCalculateVehicles_Specified(int Index)
  {  return FReCalculateVehicles_Specified;  } 
  void __fastcall SetUnderwriterLnr(int Index, WideString _prop_val)
  {  FUnderwriterLnr = _prop_val; FUnderwriterLnr_Specified = true;  }
  bool __fastcall UnderwriterLnr_Specified(int Index)
  {  return FUnderwriterLnr_Specified;  } 

public:
  __fastcall ~KaskoReCalculateRequest();
__published:
  __property ArrayOfKaskoReCalculateVehicle ReCalculateVehicles = { index=(IS_OPTN|IS_NLBL), read=FReCalculateVehicles, write=SetReCalculateVehicles, stored = ReCalculateVehicles_Specified };
  __property WideString UnderwriterLnr = { index=(IS_OPTN|IS_NLBL), read=FUnderwriterLnr, write=SetUnderwriterLnr, stored = UnderwriterLnr_Specified };
};




// ************************************************************************ //
// XML       : KaskoReCalculateVehicle, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoReCalculateVehicle : public TRemotable {
private:
  TXSDecimal*     FKpr;
  bool            FKpr_Specified;
  WideString      FVehicleBodyNumber;
  bool            FVehicleBodyNumber_Specified;
  WideString      FVehicleChassisNumber;
  bool            FVehicleChassisNumber_Specified;
  WideString      FVehicleEngineNumber;
  bool            FVehicleEngineNumber_Specified;
  WideString      FVehicleGosRegNumRegion;
  bool            FVehicleGosRegNumRegion_Specified;
  WideString      FVehicleNumber;
  bool            FVehicleNumber_Specified;
  TXSDateTime*    FVehiclePtsDate;
  bool            FVehiclePtsDate_Specified;
  void __fastcall SetKpr(int Index, TXSDecimal* _prop_val)
  {  FKpr = _prop_val; FKpr_Specified = true;  }
  bool __fastcall Kpr_Specified(int Index)
  {  return FKpr_Specified;  } 
  void __fastcall SetVehicleBodyNumber(int Index, WideString _prop_val)
  {  FVehicleBodyNumber = _prop_val; FVehicleBodyNumber_Specified = true;  }
  bool __fastcall VehicleBodyNumber_Specified(int Index)
  {  return FVehicleBodyNumber_Specified;  } 
  void __fastcall SetVehicleChassisNumber(int Index, WideString _prop_val)
  {  FVehicleChassisNumber = _prop_val; FVehicleChassisNumber_Specified = true;  }
  bool __fastcall VehicleChassisNumber_Specified(int Index)
  {  return FVehicleChassisNumber_Specified;  } 
  void __fastcall SetVehicleEngineNumber(int Index, WideString _prop_val)
  {  FVehicleEngineNumber = _prop_val; FVehicleEngineNumber_Specified = true;  }
  bool __fastcall VehicleEngineNumber_Specified(int Index)
  {  return FVehicleEngineNumber_Specified;  } 
  void __fastcall SetVehicleGosRegNumRegion(int Index, WideString _prop_val)
  {  FVehicleGosRegNumRegion = _prop_val; FVehicleGosRegNumRegion_Specified = true;  }
  bool __fastcall VehicleGosRegNumRegion_Specified(int Index)
  {  return FVehicleGosRegNumRegion_Specified;  } 
  void __fastcall SetVehicleNumber(int Index, WideString _prop_val)
  {  FVehicleNumber = _prop_val; FVehicleNumber_Specified = true;  }
  bool __fastcall VehicleNumber_Specified(int Index)
  {  return FVehicleNumber_Specified;  } 
  void __fastcall SetVehiclePtsDate(int Index, TXSDateTime* _prop_val)
  {  FVehiclePtsDate = _prop_val; FVehiclePtsDate_Specified = true;  }
  bool __fastcall VehiclePtsDate_Specified(int Index)
  {  return FVehiclePtsDate_Specified;  } 

public:
  __fastcall ~KaskoReCalculateVehicle();
__published:
  __property TXSDecimal*        Kpr = { index=(IS_OPTN|IS_NLBL), read=FKpr, write=SetKpr, stored = Kpr_Specified };
  __property WideString VehicleBodyNumber = { index=(IS_OPTN|IS_NLBL), read=FVehicleBodyNumber, write=SetVehicleBodyNumber, stored = VehicleBodyNumber_Specified };
  __property WideString VehicleChassisNumber = { index=(IS_OPTN|IS_NLBL), read=FVehicleChassisNumber, write=SetVehicleChassisNumber, stored = VehicleChassisNumber_Specified };
  __property WideString VehicleEngineNumber = { index=(IS_OPTN|IS_NLBL), read=FVehicleEngineNumber, write=SetVehicleEngineNumber, stored = VehicleEngineNumber_Specified };
  __property WideString VehicleGosRegNumRegion = { index=(IS_OPTN|IS_NLBL), read=FVehicleGosRegNumRegion, write=SetVehicleGosRegNumRegion, stored = VehicleGosRegNumRegion_Specified };
  __property WideString VehicleNumber = { index=(IS_OPTN|IS_NLBL), read=FVehicleNumber, write=SetVehicleNumber, stored = VehicleNumber_Specified };
  __property TXSDateTime* VehiclePtsDate = { index=(IS_OPTN|IS_NLBL), read=FVehiclePtsDate, write=SetVehiclePtsDate, stored = VehiclePtsDate_Specified };
};


typedef DynamicArray<UsagePeriod*> ArrayOfUsagePeriod; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<VehicleCalculationResult*> ArrayOfVehicleCalculationResult; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : CalculationResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculationResult : public TRemotable {
private:
  TXSDateTime*    FCalculationDate;
  bool            FCalculationDate_Specified;
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  guid            FContractId;
  bool            FContractId_Specified;
  TXSDecimal*     FInsurantK5;
  bool            FInsurantK5_Specified;
  TXSDecimal*     FInsurantK6;
  bool            FInsurantK6_Specified;
  WideString      FKaskoRequirementsToBank;
  bool            FKaskoRequirementsToBank_Specified;
  int             FPolicyPeriodInMonths;
  bool            FPolicyPeriodInMonths_Specified;
  int             FPolicyPeriodsCount;
  bool            FPolicyPeriodsCount_Specified;
  TXSDecimal*     FPolicyPremium;
  bool            FPolicyPremium_Specified;
  ArrayOfUsagePeriod FUsagePeriods;
  bool            FUsagePeriods_Specified;
  ArrayOfVehicleCalculationResult FVehicleResults;
  bool            FVehicleResults_Specified;
  void __fastcall SetCalculationDate(int Index, TXSDateTime* _prop_val)
  {  FCalculationDate = _prop_val; FCalculationDate_Specified = true;  }
  bool __fastcall CalculationDate_Specified(int Index)
  {  return FCalculationDate_Specified;  } 
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
  void __fastcall SetInsurantK5(int Index, TXSDecimal* _prop_val)
  {  FInsurantK5 = _prop_val; FInsurantK5_Specified = true;  }
  bool __fastcall InsurantK5_Specified(int Index)
  {  return FInsurantK5_Specified;  } 
  void __fastcall SetInsurantK6(int Index, TXSDecimal* _prop_val)
  {  FInsurantK6 = _prop_val; FInsurantK6_Specified = true;  }
  bool __fastcall InsurantK6_Specified(int Index)
  {  return FInsurantK6_Specified;  } 
  void __fastcall SetKaskoRequirementsToBank(int Index, WideString _prop_val)
  {  FKaskoRequirementsToBank = _prop_val; FKaskoRequirementsToBank_Specified = true;  }
  bool __fastcall KaskoRequirementsToBank_Specified(int Index)
  {  return FKaskoRequirementsToBank_Specified;  } 
  void __fastcall SetPolicyPeriodInMonths(int Index, int _prop_val)
  {  FPolicyPeriodInMonths = _prop_val; FPolicyPeriodInMonths_Specified = true;  }
  bool __fastcall PolicyPeriodInMonths_Specified(int Index)
  {  return FPolicyPeriodInMonths_Specified;  } 
  void __fastcall SetPolicyPeriodsCount(int Index, int _prop_val)
  {  FPolicyPeriodsCount = _prop_val; FPolicyPeriodsCount_Specified = true;  }
  bool __fastcall PolicyPeriodsCount_Specified(int Index)
  {  return FPolicyPeriodsCount_Specified;  } 
  void __fastcall SetPolicyPremium(int Index, TXSDecimal* _prop_val)
  {  FPolicyPremium = _prop_val; FPolicyPremium_Specified = true;  }
  bool __fastcall PolicyPremium_Specified(int Index)
  {  return FPolicyPremium_Specified;  } 
  void __fastcall SetUsagePeriods(int Index, ArrayOfUsagePeriod _prop_val)
  {  FUsagePeriods = _prop_val; FUsagePeriods_Specified = true;  }
  bool __fastcall UsagePeriods_Specified(int Index)
  {  return FUsagePeriods_Specified;  } 
  void __fastcall SetVehicleResults(int Index, ArrayOfVehicleCalculationResult _prop_val)
  {  FVehicleResults = _prop_val; FVehicleResults_Specified = true;  }
  bool __fastcall VehicleResults_Specified(int Index)
  {  return FVehicleResults_Specified;  } 

public:
  __fastcall ~CalculationResult();
__published:
  __property TXSDateTime* CalculationDate = { index=(IS_OPTN), read=FCalculationDate, write=SetCalculationDate, stored = CalculationDate_Specified };
  __property guid       CalculationId = { index=(IS_OPTN), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
  __property TXSDecimal* InsurantK5 = { index=(IS_OPTN|IS_NLBL), read=FInsurantK5, write=SetInsurantK5, stored = InsurantK5_Specified };
  __property TXSDecimal* InsurantK6 = { index=(IS_OPTN|IS_NLBL), read=FInsurantK6, write=SetInsurantK6, stored = InsurantK6_Specified };
  __property WideString KaskoRequirementsToBank = { index=(IS_OPTN|IS_NLBL), read=FKaskoRequirementsToBank, write=SetKaskoRequirementsToBank, stored = KaskoRequirementsToBank_Specified };
  __property int        PolicyPeriodInMonths = { index=(IS_OPTN|IS_NLBL), read=FPolicyPeriodInMonths, write=SetPolicyPeriodInMonths, stored = PolicyPeriodInMonths_Specified };
  __property int        PolicyPeriodsCount = { index=(IS_OPTN|IS_NLBL), read=FPolicyPeriodsCount, write=SetPolicyPeriodsCount, stored = PolicyPeriodsCount_Specified };
  __property TXSDecimal* PolicyPremium = { index=(IS_OPTN|IS_NLBL), read=FPolicyPremium, write=SetPolicyPremium, stored = PolicyPremium_Specified };
  __property ArrayOfUsagePeriod UsagePeriods = { index=(IS_OPTN|IS_NLBL), read=FUsagePeriods, write=SetUsagePeriods, stored = UsagePeriods_Specified };
  __property ArrayOfVehicleCalculationResult VehicleResults = { index=(IS_OPTN|IS_NLBL), read=FVehicleResults, write=SetVehicleResults, stored = VehicleResults_Specified };
};




// ************************************************************************ //
// XML       : UsagePeriod, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UsagePeriod : public TRemotable {
private:
  TXSDateTime*    FUsagePeriodEndDate;
  bool            FUsagePeriodEndDate_Specified;
  int             FUsagePeriodNumber;
  bool            FUsagePeriodNumber_Specified;
  TXSDateTime*    FUsagePeriodStartDate;
  bool            FUsagePeriodStartDate_Specified;
  void __fastcall SetUsagePeriodEndDate(int Index, TXSDateTime* _prop_val)
  {  FUsagePeriodEndDate = _prop_val; FUsagePeriodEndDate_Specified = true;  }
  bool __fastcall UsagePeriodEndDate_Specified(int Index)
  {  return FUsagePeriodEndDate_Specified;  } 
  void __fastcall SetUsagePeriodNumber(int Index, int _prop_val)
  {  FUsagePeriodNumber = _prop_val; FUsagePeriodNumber_Specified = true;  }
  bool __fastcall UsagePeriodNumber_Specified(int Index)
  {  return FUsagePeriodNumber_Specified;  } 
  void __fastcall SetUsagePeriodStartDate(int Index, TXSDateTime* _prop_val)
  {  FUsagePeriodStartDate = _prop_val; FUsagePeriodStartDate_Specified = true;  }
  bool __fastcall UsagePeriodStartDate_Specified(int Index)
  {  return FUsagePeriodStartDate_Specified;  } 

public:
  __fastcall ~UsagePeriod();
__published:
  __property TXSDateTime* UsagePeriodEndDate = { index=(IS_OPTN), read=FUsagePeriodEndDate, write=SetUsagePeriodEndDate, stored = UsagePeriodEndDate_Specified };
  __property int        UsagePeriodNumber = { index=(IS_OPTN), read=FUsagePeriodNumber, write=SetUsagePeriodNumber, stored = UsagePeriodNumber_Specified };
  __property TXSDateTime* UsagePeriodStartDate = { index=(IS_OPTN), read=FUsagePeriodStartDate, write=SetUsagePeriodStartDate, stored = UsagePeriodStartDate_Specified };
};


typedef DynamicArray<AddEquipmentResponse*> ArrayOfAddEquipmentResponse; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<AdmitResultsDto*> ArrayOfAdmitResultsDto; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : Coefficients, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Coefficients : public TRemotable {
private:
  TXSDecimal*     FK1;
  bool            FK1_Specified;
  TXSDecimal*     FK1D;
  bool            FK1D_Specified;
  TXSDecimal*     FK2;
  bool            FK2_Specified;
  TXSDecimal*     FK3;
  bool            FK3_Specified;
  TXSDecimal*     FK4;
  bool            FK4_Specified;
  TXSDecimal*     FK5;
  bool            FK5_Specified;
  TXSDecimal*     FK6;
  bool            FK6_Specified;
  TXSDecimal*     FK7A;
  bool            FK7A_Specified;
  TXSDecimal*     FKA;
  bool            FKA_Specified;
  TXSDecimal*     FKAR;
  bool            FKAR_Specified;
  TXSDecimal*     FKAct;
  bool            FKAct_Specified;
  TXSDecimal*     FKB;
  bool            FKB_Specified;
  TXSDecimal*     FKC;
  bool            FKC_Specified;
  TXSDecimal*     FKPR;
  bool            FKPR_Specified;
  TXSDecimal*     FKPRisk;
  bool            FKPRisk_Specified;
  TXSDecimal*     FKR;
  bool            FKR_Specified;
  TXSDecimal*     FKRS;
  bool            FKRS_Specified;
  TXSDecimal*     FKReservation;
  bool            FKReservation_Specified;
  TXSDecimal*     FKSR;
  bool            FKSR_Specified;
  TXSDecimal*     FKU;
  bool            FKU_Specified;
  TXSDecimal*     FKVozv;
  bool            FKVozv_Specified;
  TXSDecimal*     FKY;
  bool            FKY_Specified;
  TXSDecimal*     FKans;
  bool            FKans_Specified;
  TXSDecimal*     FTB;
  bool            FTB_Specified;
  TXSDecimal*     FTariff;
  bool            FTariff_Specified;
  TXSDecimal*     FTariffPrefProlongation;
  bool            FTariffPrefProlongation_Specified;
  void __fastcall SetK1(int Index, TXSDecimal* _prop_val)
  {  FK1 = _prop_val; FK1_Specified = true;  }
  bool __fastcall K1_Specified(int Index)
  {  return FK1_Specified;  } 
  void __fastcall SetK1D(int Index, TXSDecimal* _prop_val)
  {  FK1D = _prop_val; FK1D_Specified = true;  }
  bool __fastcall K1D_Specified(int Index)
  {  return FK1D_Specified;  } 
  void __fastcall SetK2(int Index, TXSDecimal* _prop_val)
  {  FK2 = _prop_val; FK2_Specified = true;  }
  bool __fastcall K2_Specified(int Index)
  {  return FK2_Specified;  } 
  void __fastcall SetK3(int Index, TXSDecimal* _prop_val)
  {  FK3 = _prop_val; FK3_Specified = true;  }
  bool __fastcall K3_Specified(int Index)
  {  return FK3_Specified;  } 
  void __fastcall SetK4(int Index, TXSDecimal* _prop_val)
  {  FK4 = _prop_val; FK4_Specified = true;  }
  bool __fastcall K4_Specified(int Index)
  {  return FK4_Specified;  } 
  void __fastcall SetK5(int Index, TXSDecimal* _prop_val)
  {  FK5 = _prop_val; FK5_Specified = true;  }
  bool __fastcall K5_Specified(int Index)
  {  return FK5_Specified;  } 
  void __fastcall SetK6(int Index, TXSDecimal* _prop_val)
  {  FK6 = _prop_val; FK6_Specified = true;  }
  bool __fastcall K6_Specified(int Index)
  {  return FK6_Specified;  } 
  void __fastcall SetK7A(int Index, TXSDecimal* _prop_val)
  {  FK7A = _prop_val; FK7A_Specified = true;  }
  bool __fastcall K7A_Specified(int Index)
  {  return FK7A_Specified;  } 
  void __fastcall SetKA(int Index, TXSDecimal* _prop_val)
  {  FKA = _prop_val; FKA_Specified = true;  }
  bool __fastcall KA_Specified(int Index)
  {  return FKA_Specified;  } 
  void __fastcall SetKAR(int Index, TXSDecimal* _prop_val)
  {  FKAR = _prop_val; FKAR_Specified = true;  }
  bool __fastcall KAR_Specified(int Index)
  {  return FKAR_Specified;  } 
  void __fastcall SetKAct(int Index, TXSDecimal* _prop_val)
  {  FKAct = _prop_val; FKAct_Specified = true;  }
  bool __fastcall KAct_Specified(int Index)
  {  return FKAct_Specified;  } 
  void __fastcall SetKB(int Index, TXSDecimal* _prop_val)
  {  FKB = _prop_val; FKB_Specified = true;  }
  bool __fastcall KB_Specified(int Index)
  {  return FKB_Specified;  } 
  void __fastcall SetKC(int Index, TXSDecimal* _prop_val)
  {  FKC = _prop_val; FKC_Specified = true;  }
  bool __fastcall KC_Specified(int Index)
  {  return FKC_Specified;  } 
  void __fastcall SetKPR(int Index, TXSDecimal* _prop_val)
  {  FKPR = _prop_val; FKPR_Specified = true;  }
  bool __fastcall KPR_Specified(int Index)
  {  return FKPR_Specified;  } 
  void __fastcall SetKPRisk(int Index, TXSDecimal* _prop_val)
  {  FKPRisk = _prop_val; FKPRisk_Specified = true;  }
  bool __fastcall KPRisk_Specified(int Index)
  {  return FKPRisk_Specified;  } 
  void __fastcall SetKR(int Index, TXSDecimal* _prop_val)
  {  FKR = _prop_val; FKR_Specified = true;  }
  bool __fastcall KR_Specified(int Index)
  {  return FKR_Specified;  } 
  void __fastcall SetKRS(int Index, TXSDecimal* _prop_val)
  {  FKRS = _prop_val; FKRS_Specified = true;  }
  bool __fastcall KRS_Specified(int Index)
  {  return FKRS_Specified;  } 
  void __fastcall SetKReservation(int Index, TXSDecimal* _prop_val)
  {  FKReservation = _prop_val; FKReservation_Specified = true;  }
  bool __fastcall KReservation_Specified(int Index)
  {  return FKReservation_Specified;  } 
  void __fastcall SetKSR(int Index, TXSDecimal* _prop_val)
  {  FKSR = _prop_val; FKSR_Specified = true;  }
  bool __fastcall KSR_Specified(int Index)
  {  return FKSR_Specified;  } 
  void __fastcall SetKU(int Index, TXSDecimal* _prop_val)
  {  FKU = _prop_val; FKU_Specified = true;  }
  bool __fastcall KU_Specified(int Index)
  {  return FKU_Specified;  } 
  void __fastcall SetKVozv(int Index, TXSDecimal* _prop_val)
  {  FKVozv = _prop_val; FKVozv_Specified = true;  }
  bool __fastcall KVozv_Specified(int Index)
  {  return FKVozv_Specified;  } 
  void __fastcall SetKY(int Index, TXSDecimal* _prop_val)
  {  FKY = _prop_val; FKY_Specified = true;  }
  bool __fastcall KY_Specified(int Index)
  {  return FKY_Specified;  } 
  void __fastcall SetKans(int Index, TXSDecimal* _prop_val)
  {  FKans = _prop_val; FKans_Specified = true;  }
  bool __fastcall Kans_Specified(int Index)
  {  return FKans_Specified;  } 
  void __fastcall SetTB(int Index, TXSDecimal* _prop_val)
  {  FTB = _prop_val; FTB_Specified = true;  }
  bool __fastcall TB_Specified(int Index)
  {  return FTB_Specified;  } 
  void __fastcall SetTariff(int Index, TXSDecimal* _prop_val)
  {  FTariff = _prop_val; FTariff_Specified = true;  }
  bool __fastcall Tariff_Specified(int Index)
  {  return FTariff_Specified;  } 
  void __fastcall SetTariffPrefProlongation(int Index, TXSDecimal* _prop_val)
  {  FTariffPrefProlongation = _prop_val; FTariffPrefProlongation_Specified = true;  }
  bool __fastcall TariffPrefProlongation_Specified(int Index)
  {  return FTariffPrefProlongation_Specified;  } 

public:
  __fastcall ~Coefficients();
__published:
  __property TXSDecimal*         K1 = { index=(IS_OPTN), read=FK1, write=SetK1, stored = K1_Specified };
  __property TXSDecimal*        K1D = { index=(IS_OPTN), read=FK1D, write=SetK1D, stored = K1D_Specified };
  __property TXSDecimal*         K2 = { index=(IS_OPTN), read=FK2, write=SetK2, stored = K2_Specified };
  __property TXSDecimal*         K3 = { index=(IS_OPTN), read=FK3, write=SetK3, stored = K3_Specified };
  __property TXSDecimal*         K4 = { index=(IS_OPTN), read=FK4, write=SetK4, stored = K4_Specified };
  __property TXSDecimal*         K5 = { index=(IS_OPTN), read=FK5, write=SetK5, stored = K5_Specified };
  __property TXSDecimal*         K6 = { index=(IS_OPTN), read=FK6, write=SetK6, stored = K6_Specified };
  __property TXSDecimal*        K7A = { index=(IS_OPTN), read=FK7A, write=SetK7A, stored = K7A_Specified };
  __property TXSDecimal*         KA = { index=(IS_OPTN), read=FKA, write=SetKA, stored = KA_Specified };
  __property TXSDecimal*        KAR = { index=(IS_OPTN), read=FKAR, write=SetKAR, stored = KAR_Specified };
  __property TXSDecimal*       KAct = { index=(IS_OPTN), read=FKAct, write=SetKAct, stored = KAct_Specified };
  __property TXSDecimal*         KB = { index=(IS_OPTN), read=FKB, write=SetKB, stored = KB_Specified };
  __property TXSDecimal*         KC = { index=(IS_OPTN), read=FKC, write=SetKC, stored = KC_Specified };
  __property TXSDecimal*        KPR = { index=(IS_OPTN), read=FKPR, write=SetKPR, stored = KPR_Specified };
  __property TXSDecimal*     KPRisk = { index=(IS_OPTN), read=FKPRisk, write=SetKPRisk, stored = KPRisk_Specified };
  __property TXSDecimal*         KR = { index=(IS_OPTN), read=FKR, write=SetKR, stored = KR_Specified };
  __property TXSDecimal*        KRS = { index=(IS_OPTN), read=FKRS, write=SetKRS, stored = KRS_Specified };
  __property TXSDecimal* KReservation = { index=(IS_OPTN), read=FKReservation, write=SetKReservation, stored = KReservation_Specified };
  __property TXSDecimal*        KSR = { index=(IS_OPTN), read=FKSR, write=SetKSR, stored = KSR_Specified };
  __property TXSDecimal*         KU = { index=(IS_OPTN), read=FKU, write=SetKU, stored = KU_Specified };
  __property TXSDecimal*      KVozv = { index=(IS_OPTN), read=FKVozv, write=SetKVozv, stored = KVozv_Specified };
  __property TXSDecimal*         KY = { index=(IS_OPTN), read=FKY, write=SetKY, stored = KY_Specified };
  __property TXSDecimal*       Kans = { index=(IS_OPTN), read=FKans, write=SetKans, stored = Kans_Specified };
  __property TXSDecimal*         TB = { index=(IS_OPTN), read=FTB, write=SetTB, stored = TB_Specified };
  __property TXSDecimal*     Tariff = { index=(IS_OPTN), read=FTariff, write=SetTariff, stored = Tariff_Specified };
  __property TXSDecimal* TariffPrefProlongation = { index=(IS_OPTN|IS_NLBL), read=FTariffPrefProlongation, write=SetTariffPrefProlongation, stored = TariffPrefProlongation_Specified };
};




// ************************************************************************ //
// XML       : PaymentDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PaymentDto : public TRemotable {
private:
  WideString      FDate;
  TXSDecimal*     FValue;

public:
  __fastcall ~PaymentDto();
__published:
  __property WideString       Date = { index=(IS_NLBL), read=FDate, write=FDate };
  __property TXSDecimal*      Value = { read=FValue, write=FValue };
};


typedef DynamicArray<PrevContractIdDto*> ArrayOfPrevContractIdDto; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : PrevPolicyDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrevPolicyDto : public Document {
private:
  TXSDateTime*    FEndDate;
  bool            FEndDate_Specified;
  TXSDecimal*     FKaskoLiability;
  bool            FKaskoLiability_Specified;
  TXSDecimal*     FKaskoPremium;
  bool            FKaskoPremium_Specified;
  int             FNumberLoss;
  bool            FNumberLoss_Specified;
  TXSDecimal*     FPaySumLoss;
  bool            FPaySumLoss_Specified;
  WideString      FPolicyId;
  bool            FPolicyId_Specified;
  WideString      FProgramId;
  bool            FProgramId_Specified;
  bool            FProlongCheck;
  bool            FProlongCheck_Specified;
  int             FSystemId;
  bool            FSystemId_Specified;
  TXSDecimal*     FVehicleCost;
  bool            FVehicleCost_Specified;
  void __fastcall SetEndDate(int Index, TXSDateTime* _prop_val)
  {  FEndDate = _prop_val; FEndDate_Specified = true;  }
  bool __fastcall EndDate_Specified(int Index)
  {  return FEndDate_Specified;  } 
  void __fastcall SetKaskoLiability(int Index, TXSDecimal* _prop_val)
  {  FKaskoLiability = _prop_val; FKaskoLiability_Specified = true;  }
  bool __fastcall KaskoLiability_Specified(int Index)
  {  return FKaskoLiability_Specified;  } 
  void __fastcall SetKaskoPremium(int Index, TXSDecimal* _prop_val)
  {  FKaskoPremium = _prop_val; FKaskoPremium_Specified = true;  }
  bool __fastcall KaskoPremium_Specified(int Index)
  {  return FKaskoPremium_Specified;  } 
  void __fastcall SetNumberLoss(int Index, int _prop_val)
  {  FNumberLoss = _prop_val; FNumberLoss_Specified = true;  }
  bool __fastcall NumberLoss_Specified(int Index)
  {  return FNumberLoss_Specified;  } 
  void __fastcall SetPaySumLoss(int Index, TXSDecimal* _prop_val)
  {  FPaySumLoss = _prop_val; FPaySumLoss_Specified = true;  }
  bool __fastcall PaySumLoss_Specified(int Index)
  {  return FPaySumLoss_Specified;  } 
  void __fastcall SetPolicyId(int Index, WideString _prop_val)
  {  FPolicyId = _prop_val; FPolicyId_Specified = true;  }
  bool __fastcall PolicyId_Specified(int Index)
  {  return FPolicyId_Specified;  } 
  void __fastcall SetProgramId(int Index, WideString _prop_val)
  {  FProgramId = _prop_val; FProgramId_Specified = true;  }
  bool __fastcall ProgramId_Specified(int Index)
  {  return FProgramId_Specified;  } 
  void __fastcall SetProlongCheck(int Index, bool _prop_val)
  {  FProlongCheck = _prop_val; FProlongCheck_Specified = true;  }
  bool __fastcall ProlongCheck_Specified(int Index)
  {  return FProlongCheck_Specified;  } 
  void __fastcall SetSystemId(int Index, int _prop_val)
  {  FSystemId = _prop_val; FSystemId_Specified = true;  }
  bool __fastcall SystemId_Specified(int Index)
  {  return FSystemId_Specified;  } 
  void __fastcall SetVehicleCost(int Index, TXSDecimal* _prop_val)
  {  FVehicleCost = _prop_val; FVehicleCost_Specified = true;  }
  bool __fastcall VehicleCost_Specified(int Index)
  {  return FVehicleCost_Specified;  } 

public:
  __fastcall ~PrevPolicyDto();
__published:
  __property TXSDateTime*    EndDate = { index=(IS_OPTN|IS_NLBL), read=FEndDate, write=SetEndDate, stored = EndDate_Specified };
  __property TXSDecimal* KaskoLiability = { index=(IS_OPTN|IS_NLBL), read=FKaskoLiability, write=SetKaskoLiability, stored = KaskoLiability_Specified };
  __property TXSDecimal* KaskoPremium = { index=(IS_OPTN|IS_NLBL), read=FKaskoPremium, write=SetKaskoPremium, stored = KaskoPremium_Specified };
  __property int        NumberLoss = { index=(IS_OPTN|IS_NLBL), read=FNumberLoss, write=SetNumberLoss, stored = NumberLoss_Specified };
  __property TXSDecimal* PaySumLoss = { index=(IS_OPTN|IS_NLBL), read=FPaySumLoss, write=SetPaySumLoss, stored = PaySumLoss_Specified };
  __property WideString   PolicyId = { index=(IS_OPTN|IS_NLBL), read=FPolicyId, write=SetPolicyId, stored = PolicyId_Specified };
  __property WideString  ProgramId = { index=(IS_OPTN|IS_NLBL), read=FProgramId, write=SetProgramId, stored = ProgramId_Specified };
  __property bool       ProlongCheck = { index=(IS_OPTN|IS_NLBL), read=FProlongCheck, write=SetProlongCheck, stored = ProlongCheck_Specified };
  __property int          SystemId = { index=(IS_OPTN), read=FSystemId, write=SetSystemId, stored = SystemId_Specified };
  __property TXSDecimal* VehicleCost = { index=(IS_OPTN|IS_NLBL), read=FVehicleCost, write=SetVehicleCost, stored = VehicleCost_Specified };
};


typedef DynamicArray<ReservationCoefficient*> ArrayOfReservationCoefficient; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<RiskObject*> ArrayOfRiskObject; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : VehicleCalculationResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleCalculationResult : public VehicleBaseDto {
private:
  TXSDecimal*     FAccidentLiability;
  bool            FAccidentLiability_Specified;
  TXSDecimal*     FAccidentPremium;
  bool            FAccidentPremium_Specified;
  ArrayOfAddEquipmentResponse FAddEquipments;
  bool            FAddEquipments_Specified;
  ArrayOfAdmitResultsDto FAdmitResults;
  bool            FAdmitResults_Specified;
  ArrayOfstring   FAlarmMessages;
  bool            FAlarmMessages_Specified;
  ArrayOfstring   FCalculationErrors;
  bool            FCalculationErrors_Specified;
  guid            FContractId;
  bool            FContractId_Specified;
  TXSDecimal*     FDmsPremium;
  bool            FDmsPremium_Specified;
  TXSDecimal*     FDsagoLiability;
  bool            FDsagoLiability_Specified;
  TXSDecimal*     FDsagoVehiclePremium;
  bool            FDsagoVehiclePremium_Specified;
  TXSDecimal*     FFranchiseJokerSum;
  bool            FFranchiseJokerSum_Specified;
  bool            FInspectionNeeded;
  bool            FInspectionNeeded_Specified;
  bool            FIsRenewalContract;
  bool            FIsRenewalContract_Specified;
  Coefficients*   FK;
  bool            FK_Specified;
  TXSDecimal*     FKaskoTotal;
  bool            FKaskoTotal_Specified;
  TXSDecimal*     FKaskoVehicleGapPremium;
  bool            FKaskoVehicleGapPremium_Specified;
  WideString      FKbmRsaRequestId;
  bool            FKbmRsaRequestId_Specified;
  TXSDecimal*     FLiabilityCostProportion;
  bool            FLiabilityCostProportion_Specified;
  PaymentDto*     FPayment1;
  bool            FPayment1_Specified;
  PaymentDto*     FPayment2;
  bool            FPayment2_Specified;
  PaymentDto*     FPayment3;
  bool            FPayment3_Specified;
  PaymentDto*     FPayment4;
  bool            FPayment4_Specified;
  TXSDecimal*     FPndLiabilityExp;
  bool            FPndLiabilityExp_Specified;
  TXSDecimal*     FPndLiabilityTech;
  bool            FPndLiabilityTech_Specified;
  TXSDecimal*     FPndPremiumExp;
  bool            FPndPremiumExp_Specified;
  TXSDecimal*     FPndPremiumTech;
  bool            FPndPremiumTech_Specified;
  int             FPolicyPeriodInMonths;
  bool            FPolicyPeriodInMonths_Specified;
  WideString      FPrefProlongError;
  bool            FPrefProlongError_Specified;
  ArrayOfPrevContractIdDto FPrevContractIds;
  bool            FPrevContractIds_Specified;
  PrevPolicyDto*  FPrevPolicy;
  bool            FPrevPolicy_Specified;
  ArrayOfReservationCoefficient FReservations;
  bool            FReservations_Specified;
  ArrayOfRiskObject FRiskObjects;
  bool            FRiskObjects_Specified;
  TXSDecimal*     FTransdekraMaxPrice;
  bool            FTransdekraMaxPrice_Specified;
  TXSDecimal*     FTransdekraMinPrice;
  bool            FTransdekraMinPrice_Specified;
  TXSDecimal*     FTransdekraPrice;
  bool            FTransdekraPrice_Specified;
  KaskoUnderwritingRequirements* FUnderwritingRequirements;
  bool            FUnderwritingRequirements_Specified;
  ArrayOfstring   FUwMessagesToAgent;
  bool            FUwMessagesToAgent_Specified;
  ArrayOfstring   FUwMessagesToClient;
  bool            FUwMessagesToClient_Specified;
  ArrayOfstring   FUwSecurityMessages;
  bool            FUwSecurityMessages_Specified;
  ArrayOfstring   FUwUnderwriterMessages;
  bool            FUwUnderwriterMessages_Specified;
  int             FVehicleAge;
  bool            FVehicleAge_Specified;
  TXSDecimal*     FVehicleGapCoeff;
  bool            FVehicleGapCoeff_Specified;
  TXSDecimal*     FVehiclePremium;
  bool            FVehiclePremium_Specified;
  int             FVehiclePremiumCalcType;
  bool            FVehiclePremiumCalcType_Specified;
  TXSDecimal*     FVehiclePremiumPrefProlCoeff;
  bool            FVehiclePremiumPrefProlCoeff_Specified;
  TXSDecimal*     FVehiclePremiumPrefProlongation;
  bool            FVehiclePremiumPrefProlongation_Specified;
  void __fastcall SetAccidentLiability(int Index, TXSDecimal* _prop_val)
  {  FAccidentLiability = _prop_val; FAccidentLiability_Specified = true;  }
  bool __fastcall AccidentLiability_Specified(int Index)
  {  return FAccidentLiability_Specified;  } 
  void __fastcall SetAccidentPremium(int Index, TXSDecimal* _prop_val)
  {  FAccidentPremium = _prop_val; FAccidentPremium_Specified = true;  }
  bool __fastcall AccidentPremium_Specified(int Index)
  {  return FAccidentPremium_Specified;  } 
  void __fastcall SetAddEquipments(int Index, ArrayOfAddEquipmentResponse _prop_val)
  {  FAddEquipments = _prop_val; FAddEquipments_Specified = true;  }
  bool __fastcall AddEquipments_Specified(int Index)
  {  return FAddEquipments_Specified;  } 
  void __fastcall SetAdmitResults(int Index, ArrayOfAdmitResultsDto _prop_val)
  {  FAdmitResults = _prop_val; FAdmitResults_Specified = true;  }
  bool __fastcall AdmitResults_Specified(int Index)
  {  return FAdmitResults_Specified;  } 
  void __fastcall SetAlarmMessages(int Index, ArrayOfstring _prop_val)
  {  FAlarmMessages = _prop_val; FAlarmMessages_Specified = true;  }
  bool __fastcall AlarmMessages_Specified(int Index)
  {  return FAlarmMessages_Specified;  } 
  void __fastcall SetCalculationErrors(int Index, ArrayOfstring _prop_val)
  {  FCalculationErrors = _prop_val; FCalculationErrors_Specified = true;  }
  bool __fastcall CalculationErrors_Specified(int Index)
  {  return FCalculationErrors_Specified;  } 
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
  void __fastcall SetDmsPremium(int Index, TXSDecimal* _prop_val)
  {  FDmsPremium = _prop_val; FDmsPremium_Specified = true;  }
  bool __fastcall DmsPremium_Specified(int Index)
  {  return FDmsPremium_Specified;  } 
  void __fastcall SetDsagoLiability(int Index, TXSDecimal* _prop_val)
  {  FDsagoLiability = _prop_val; FDsagoLiability_Specified = true;  }
  bool __fastcall DsagoLiability_Specified(int Index)
  {  return FDsagoLiability_Specified;  } 
  void __fastcall SetDsagoVehiclePremium(int Index, TXSDecimal* _prop_val)
  {  FDsagoVehiclePremium = _prop_val; FDsagoVehiclePremium_Specified = true;  }
  bool __fastcall DsagoVehiclePremium_Specified(int Index)
  {  return FDsagoVehiclePremium_Specified;  } 
  void __fastcall SetFranchiseJokerSum(int Index, TXSDecimal* _prop_val)
  {  FFranchiseJokerSum = _prop_val; FFranchiseJokerSum_Specified = true;  }
  bool __fastcall FranchiseJokerSum_Specified(int Index)
  {  return FFranchiseJokerSum_Specified;  } 
  void __fastcall SetInspectionNeeded(int Index, bool _prop_val)
  {  FInspectionNeeded = _prop_val; FInspectionNeeded_Specified = true;  }
  bool __fastcall InspectionNeeded_Specified(int Index)
  {  return FInspectionNeeded_Specified;  } 
  void __fastcall SetIsRenewalContract(int Index, bool _prop_val)
  {  FIsRenewalContract = _prop_val; FIsRenewalContract_Specified = true;  }
  bool __fastcall IsRenewalContract_Specified(int Index)
  {  return FIsRenewalContract_Specified;  } 
  void __fastcall SetK(int Index, Coefficients* _prop_val)
  {  FK = _prop_val; FK_Specified = true;  }
  bool __fastcall K_Specified(int Index)
  {  return FK_Specified;  } 
  void __fastcall SetKaskoTotal(int Index, TXSDecimal* _prop_val)
  {  FKaskoTotal = _prop_val; FKaskoTotal_Specified = true;  }
  bool __fastcall KaskoTotal_Specified(int Index)
  {  return FKaskoTotal_Specified;  } 
  void __fastcall SetKaskoVehicleGapPremium(int Index, TXSDecimal* _prop_val)
  {  FKaskoVehicleGapPremium = _prop_val; FKaskoVehicleGapPremium_Specified = true;  }
  bool __fastcall KaskoVehicleGapPremium_Specified(int Index)
  {  return FKaskoVehicleGapPremium_Specified;  } 
  void __fastcall SetKbmRsaRequestId(int Index, WideString _prop_val)
  {  FKbmRsaRequestId = _prop_val; FKbmRsaRequestId_Specified = true;  }
  bool __fastcall KbmRsaRequestId_Specified(int Index)
  {  return FKbmRsaRequestId_Specified;  } 
  void __fastcall SetLiabilityCostProportion(int Index, TXSDecimal* _prop_val)
  {  FLiabilityCostProportion = _prop_val; FLiabilityCostProportion_Specified = true;  }
  bool __fastcall LiabilityCostProportion_Specified(int Index)
  {  return FLiabilityCostProportion_Specified;  } 
  void __fastcall SetPayment1(int Index, PaymentDto* _prop_val)
  {  FPayment1 = _prop_val; FPayment1_Specified = true;  }
  bool __fastcall Payment1_Specified(int Index)
  {  return FPayment1_Specified;  } 
  void __fastcall SetPayment2(int Index, PaymentDto* _prop_val)
  {  FPayment2 = _prop_val; FPayment2_Specified = true;  }
  bool __fastcall Payment2_Specified(int Index)
  {  return FPayment2_Specified;  } 
  void __fastcall SetPayment3(int Index, PaymentDto* _prop_val)
  {  FPayment3 = _prop_val; FPayment3_Specified = true;  }
  bool __fastcall Payment3_Specified(int Index)
  {  return FPayment3_Specified;  } 
  void __fastcall SetPayment4(int Index, PaymentDto* _prop_val)
  {  FPayment4 = _prop_val; FPayment4_Specified = true;  }
  bool __fastcall Payment4_Specified(int Index)
  {  return FPayment4_Specified;  } 
  void __fastcall SetPndLiabilityExp(int Index, TXSDecimal* _prop_val)
  {  FPndLiabilityExp = _prop_val; FPndLiabilityExp_Specified = true;  }
  bool __fastcall PndLiabilityExp_Specified(int Index)
  {  return FPndLiabilityExp_Specified;  } 
  void __fastcall SetPndLiabilityTech(int Index, TXSDecimal* _prop_val)
  {  FPndLiabilityTech = _prop_val; FPndLiabilityTech_Specified = true;  }
  bool __fastcall PndLiabilityTech_Specified(int Index)
  {  return FPndLiabilityTech_Specified;  } 
  void __fastcall SetPndPremiumExp(int Index, TXSDecimal* _prop_val)
  {  FPndPremiumExp = _prop_val; FPndPremiumExp_Specified = true;  }
  bool __fastcall PndPremiumExp_Specified(int Index)
  {  return FPndPremiumExp_Specified;  } 
  void __fastcall SetPndPremiumTech(int Index, TXSDecimal* _prop_val)
  {  FPndPremiumTech = _prop_val; FPndPremiumTech_Specified = true;  }
  bool __fastcall PndPremiumTech_Specified(int Index)
  {  return FPndPremiumTech_Specified;  } 
  void __fastcall SetPolicyPeriodInMonths(int Index, int _prop_val)
  {  FPolicyPeriodInMonths = _prop_val; FPolicyPeriodInMonths_Specified = true;  }
  bool __fastcall PolicyPeriodInMonths_Specified(int Index)
  {  return FPolicyPeriodInMonths_Specified;  } 
  void __fastcall SetPrefProlongError(int Index, WideString _prop_val)
  {  FPrefProlongError = _prop_val; FPrefProlongError_Specified = true;  }
  bool __fastcall PrefProlongError_Specified(int Index)
  {  return FPrefProlongError_Specified;  } 
  void __fastcall SetPrevContractIds(int Index, ArrayOfPrevContractIdDto _prop_val)
  {  FPrevContractIds = _prop_val; FPrevContractIds_Specified = true;  }
  bool __fastcall PrevContractIds_Specified(int Index)
  {  return FPrevContractIds_Specified;  } 
  void __fastcall SetPrevPolicy(int Index, PrevPolicyDto* _prop_val)
  {  FPrevPolicy = _prop_val; FPrevPolicy_Specified = true;  }
  bool __fastcall PrevPolicy_Specified(int Index)
  {  return FPrevPolicy_Specified;  } 
  void __fastcall SetReservations(int Index, ArrayOfReservationCoefficient _prop_val)
  {  FReservations = _prop_val; FReservations_Specified = true;  }
  bool __fastcall Reservations_Specified(int Index)
  {  return FReservations_Specified;  } 
  void __fastcall SetRiskObjects(int Index, ArrayOfRiskObject _prop_val)
  {  FRiskObjects = _prop_val; FRiskObjects_Specified = true;  }
  bool __fastcall RiskObjects_Specified(int Index)
  {  return FRiskObjects_Specified;  } 
  void __fastcall SetTransdekraMaxPrice(int Index, TXSDecimal* _prop_val)
  {  FTransdekraMaxPrice = _prop_val; FTransdekraMaxPrice_Specified = true;  }
  bool __fastcall TransdekraMaxPrice_Specified(int Index)
  {  return FTransdekraMaxPrice_Specified;  } 
  void __fastcall SetTransdekraMinPrice(int Index, TXSDecimal* _prop_val)
  {  FTransdekraMinPrice = _prop_val; FTransdekraMinPrice_Specified = true;  }
  bool __fastcall TransdekraMinPrice_Specified(int Index)
  {  return FTransdekraMinPrice_Specified;  } 
  void __fastcall SetTransdekraPrice(int Index, TXSDecimal* _prop_val)
  {  FTransdekraPrice = _prop_val; FTransdekraPrice_Specified = true;  }
  bool __fastcall TransdekraPrice_Specified(int Index)
  {  return FTransdekraPrice_Specified;  } 
  void __fastcall SetUnderwritingRequirements(int Index, KaskoUnderwritingRequirements* _prop_val)
  {  FUnderwritingRequirements = _prop_val; FUnderwritingRequirements_Specified = true;  }
  bool __fastcall UnderwritingRequirements_Specified(int Index)
  {  return FUnderwritingRequirements_Specified;  } 
  void __fastcall SetUwMessagesToAgent(int Index, ArrayOfstring _prop_val)
  {  FUwMessagesToAgent = _prop_val; FUwMessagesToAgent_Specified = true;  }
  bool __fastcall UwMessagesToAgent_Specified(int Index)
  {  return FUwMessagesToAgent_Specified;  } 
  void __fastcall SetUwMessagesToClient(int Index, ArrayOfstring _prop_val)
  {  FUwMessagesToClient = _prop_val; FUwMessagesToClient_Specified = true;  }
  bool __fastcall UwMessagesToClient_Specified(int Index)
  {  return FUwMessagesToClient_Specified;  } 
  void __fastcall SetUwSecurityMessages(int Index, ArrayOfstring _prop_val)
  {  FUwSecurityMessages = _prop_val; FUwSecurityMessages_Specified = true;  }
  bool __fastcall UwSecurityMessages_Specified(int Index)
  {  return FUwSecurityMessages_Specified;  } 
  void __fastcall SetUwUnderwriterMessages(int Index, ArrayOfstring _prop_val)
  {  FUwUnderwriterMessages = _prop_val; FUwUnderwriterMessages_Specified = true;  }
  bool __fastcall UwUnderwriterMessages_Specified(int Index)
  {  return FUwUnderwriterMessages_Specified;  } 
  void __fastcall SetVehicleAge(int Index, int _prop_val)
  {  FVehicleAge = _prop_val; FVehicleAge_Specified = true;  }
  bool __fastcall VehicleAge_Specified(int Index)
  {  return FVehicleAge_Specified;  } 
  void __fastcall SetVehicleGapCoeff(int Index, TXSDecimal* _prop_val)
  {  FVehicleGapCoeff = _prop_val; FVehicleGapCoeff_Specified = true;  }
  bool __fastcall VehicleGapCoeff_Specified(int Index)
  {  return FVehicleGapCoeff_Specified;  } 
  void __fastcall SetVehiclePremium(int Index, TXSDecimal* _prop_val)
  {  FVehiclePremium = _prop_val; FVehiclePremium_Specified = true;  }
  bool __fastcall VehiclePremium_Specified(int Index)
  {  return FVehiclePremium_Specified;  } 
  void __fastcall SetVehiclePremiumCalcType(int Index, int _prop_val)
  {  FVehiclePremiumCalcType = _prop_val; FVehiclePremiumCalcType_Specified = true;  }
  bool __fastcall VehiclePremiumCalcType_Specified(int Index)
  {  return FVehiclePremiumCalcType_Specified;  } 
  void __fastcall SetVehiclePremiumPrefProlCoeff(int Index, TXSDecimal* _prop_val)
  {  FVehiclePremiumPrefProlCoeff = _prop_val; FVehiclePremiumPrefProlCoeff_Specified = true;  }
  bool __fastcall VehiclePremiumPrefProlCoeff_Specified(int Index)
  {  return FVehiclePremiumPrefProlCoeff_Specified;  } 
  void __fastcall SetVehiclePremiumPrefProlongation(int Index, TXSDecimal* _prop_val)
  {  FVehiclePremiumPrefProlongation = _prop_val; FVehiclePremiumPrefProlongation_Specified = true;  }
  bool __fastcall VehiclePremiumPrefProlongation_Specified(int Index)
  {  return FVehiclePremiumPrefProlongation_Specified;  } 

public:
  __fastcall ~VehicleCalculationResult();
__published:
  __property TXSDecimal* AccidentLiability = { index=(IS_OPTN), read=FAccidentLiability, write=SetAccidentLiability, stored = AccidentLiability_Specified };
  __property TXSDecimal* AccidentPremium = { index=(IS_OPTN), read=FAccidentPremium, write=SetAccidentPremium, stored = AccidentPremium_Specified };
  __property ArrayOfAddEquipmentResponse AddEquipments = { index=(IS_OPTN|IS_NLBL), read=FAddEquipments, write=SetAddEquipments, stored = AddEquipments_Specified };
  __property ArrayOfAdmitResultsDto AdmitResults = { index=(IS_OPTN|IS_NLBL), read=FAdmitResults, write=SetAdmitResults, stored = AdmitResults_Specified };
  __property ArrayOfstring AlarmMessages = { index=(IS_OPTN|IS_NLBL), read=FAlarmMessages, write=SetAlarmMessages, stored = AlarmMessages_Specified };
  __property ArrayOfstring CalculationErrors = { index=(IS_OPTN|IS_NLBL), read=FCalculationErrors, write=SetCalculationErrors, stored = CalculationErrors_Specified };
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
  __property TXSDecimal* DmsPremium = { index=(IS_OPTN), read=FDmsPremium, write=SetDmsPremium, stored = DmsPremium_Specified };
  __property TXSDecimal* DsagoLiability = { index=(IS_OPTN), read=FDsagoLiability, write=SetDsagoLiability, stored = DsagoLiability_Specified };
  __property TXSDecimal* DsagoVehiclePremium = { index=(IS_OPTN), read=FDsagoVehiclePremium, write=SetDsagoVehiclePremium, stored = DsagoVehiclePremium_Specified };
  __property TXSDecimal* FranchiseJokerSum = { index=(IS_OPTN|IS_NLBL), read=FFranchiseJokerSum, write=SetFranchiseJokerSum, stored = FranchiseJokerSum_Specified };
  __property bool       InspectionNeeded = { index=(IS_OPTN|IS_NLBL), read=FInspectionNeeded, write=SetInspectionNeeded, stored = InspectionNeeded_Specified };
  __property bool       IsRenewalContract = { index=(IS_OPTN), read=FIsRenewalContract, write=SetIsRenewalContract, stored = IsRenewalContract_Specified };
  __property Coefficients*          K = { index=(IS_OPTN|IS_NLBL), read=FK, write=SetK, stored = K_Specified };
  __property TXSDecimal* KaskoTotal = { index=(IS_OPTN|IS_NLBL), read=FKaskoTotal, write=SetKaskoTotal, stored = KaskoTotal_Specified };
  __property TXSDecimal* KaskoVehicleGapPremium = { index=(IS_OPTN|IS_NLBL), read=FKaskoVehicleGapPremium, write=SetKaskoVehicleGapPremium, stored = KaskoVehicleGapPremium_Specified };
  __property WideString KbmRsaRequestId = { index=(IS_OPTN|IS_NLBL), read=FKbmRsaRequestId, write=SetKbmRsaRequestId, stored = KbmRsaRequestId_Specified };
  __property TXSDecimal* LiabilityCostProportion = { index=(IS_OPTN), read=FLiabilityCostProportion, write=SetLiabilityCostProportion, stored = LiabilityCostProportion_Specified };
  __property PaymentDto*   Payment1 = { index=(IS_OPTN|IS_NLBL), read=FPayment1, write=SetPayment1, stored = Payment1_Specified };
  __property PaymentDto*   Payment2 = { index=(IS_OPTN|IS_NLBL), read=FPayment2, write=SetPayment2, stored = Payment2_Specified };
  __property PaymentDto*   Payment3 = { index=(IS_OPTN|IS_NLBL), read=FPayment3, write=SetPayment3, stored = Payment3_Specified };
  __property PaymentDto*   Payment4 = { index=(IS_OPTN|IS_NLBL), read=FPayment4, write=SetPayment4, stored = Payment4_Specified };
  __property TXSDecimal* PndLiabilityExp = { index=(IS_OPTN), read=FPndLiabilityExp, write=SetPndLiabilityExp, stored = PndLiabilityExp_Specified };
  __property TXSDecimal* PndLiabilityTech = { index=(IS_OPTN), read=FPndLiabilityTech, write=SetPndLiabilityTech, stored = PndLiabilityTech_Specified };
  __property TXSDecimal* PndPremiumExp = { index=(IS_OPTN), read=FPndPremiumExp, write=SetPndPremiumExp, stored = PndPremiumExp_Specified };
  __property TXSDecimal* PndPremiumTech = { index=(IS_OPTN), read=FPndPremiumTech, write=SetPndPremiumTech, stored = PndPremiumTech_Specified };
  __property int        PolicyPeriodInMonths = { index=(IS_OPTN|IS_NLBL), read=FPolicyPeriodInMonths, write=SetPolicyPeriodInMonths, stored = PolicyPeriodInMonths_Specified };
  __property WideString PrefProlongError = { index=(IS_OPTN|IS_NLBL), read=FPrefProlongError, write=SetPrefProlongError, stored = PrefProlongError_Specified };
  __property ArrayOfPrevContractIdDto PrevContractIds = { index=(IS_OPTN|IS_NLBL), read=FPrevContractIds, write=SetPrevContractIds, stored = PrevContractIds_Specified };
  __property PrevPolicyDto* PrevPolicy = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicy, write=SetPrevPolicy, stored = PrevPolicy_Specified };
  __property ArrayOfReservationCoefficient Reservations = { index=(IS_OPTN|IS_NLBL), read=FReservations, write=SetReservations, stored = Reservations_Specified };
  __property ArrayOfRiskObject RiskObjects = { index=(IS_OPTN|IS_NLBL), read=FRiskObjects, write=SetRiskObjects, stored = RiskObjects_Specified };
  __property TXSDecimal* TransdekraMaxPrice = { index=(IS_OPTN|IS_NLBL), read=FTransdekraMaxPrice, write=SetTransdekraMaxPrice, stored = TransdekraMaxPrice_Specified };
  __property TXSDecimal* TransdekraMinPrice = { index=(IS_OPTN|IS_NLBL), read=FTransdekraMinPrice, write=SetTransdekraMinPrice, stored = TransdekraMinPrice_Specified };
  __property TXSDecimal* TransdekraPrice = { index=(IS_OPTN|IS_NLBL), read=FTransdekraPrice, write=SetTransdekraPrice, stored = TransdekraPrice_Specified };
  __property KaskoUnderwritingRequirements* UnderwritingRequirements = { index=(IS_OPTN|IS_NLBL), read=FUnderwritingRequirements, write=SetUnderwritingRequirements, stored = UnderwritingRequirements_Specified };
  __property ArrayOfstring UwMessagesToAgent = { index=(IS_OPTN|IS_NLBL), read=FUwMessagesToAgent, write=SetUwMessagesToAgent, stored = UwMessagesToAgent_Specified };
  __property ArrayOfstring UwMessagesToClient = { index=(IS_OPTN|IS_NLBL), read=FUwMessagesToClient, write=SetUwMessagesToClient, stored = UwMessagesToClient_Specified };
  __property ArrayOfstring UwSecurityMessages = { index=(IS_OPTN|IS_NLBL), read=FUwSecurityMessages, write=SetUwSecurityMessages, stored = UwSecurityMessages_Specified };
  __property ArrayOfstring UwUnderwriterMessages = { index=(IS_OPTN|IS_NLBL), read=FUwUnderwriterMessages, write=SetUwUnderwriterMessages, stored = UwUnderwriterMessages_Specified };
  __property int        VehicleAge = { index=(IS_OPTN|IS_NLBL), read=FVehicleAge, write=SetVehicleAge, stored = VehicleAge_Specified };
  __property TXSDecimal* VehicleGapCoeff = { index=(IS_OPTN|IS_NLBL), read=FVehicleGapCoeff, write=SetVehicleGapCoeff, stored = VehicleGapCoeff_Specified };
  __property TXSDecimal* VehiclePremium = { index=(IS_OPTN), read=FVehiclePremium, write=SetVehiclePremium, stored = VehiclePremium_Specified };
  __property int        VehiclePremiumCalcType = { index=(IS_OPTN|IS_NLBL), read=FVehiclePremiumCalcType, write=SetVehiclePremiumCalcType, stored = VehiclePremiumCalcType_Specified };
  __property TXSDecimal* VehiclePremiumPrefProlCoeff = { index=(IS_OPTN|IS_NLBL), read=FVehiclePremiumPrefProlCoeff, write=SetVehiclePremiumPrefProlCoeff, stored = VehiclePremiumPrefProlCoeff_Specified };
  __property TXSDecimal* VehiclePremiumPrefProlongation = { index=(IS_OPTN|IS_NLBL), read=FVehiclePremiumPrefProlongation, write=SetVehiclePremiumPrefProlongation, stored = VehiclePremiumPrefProlongation_Specified };
};




// ************************************************************************ //
// XML       : AddEquipmentResponse, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddEquipmentResponse : public TRemotable {
private:
  WideString      FId;
  TXSDecimal*     FPremium;
  bool            FPremium_Specified;
  void __fastcall SetPremium(int Index, TXSDecimal* _prop_val)
  {  FPremium = _prop_val; FPremium_Specified = true;  }
  bool __fastcall Premium_Specified(int Index)
  {  return FPremium_Specified;  } 

public:
  __fastcall ~AddEquipmentResponse();
__published:
  __property WideString         Id = { index=(IS_NLBL), read=FId, write=FId };
  __property TXSDecimal*    Premium = { index=(IS_OPTN|IS_NLBL), read=FPremium, write=SetPremium, stored = Premium_Specified };
};


typedef DynamicArray<DriverPrevContractDto*> ArrayOfDriverPrevContractDto; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : AdmitResultsDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AdmitResultsDto : public TRemotable {
private:
  WideString      FDriverId;
  bool            FDriverId_Specified;
  ArrayOfDriverPrevContractDto FDriverPrevContracts;
  bool            FDriverPrevContracts_Specified;
  TXSDecimal*     FK1Driver;
  bool            FK1Driver_Specified;
  TXSDecimal*     FK6Driver;
  bool            FK6Driver_Specified;
  WideString      FKbmRsaRequestId;
  bool            FKbmRsaRequestId_Specified;
  void __fastcall SetDriverId(int Index, WideString _prop_val)
  {  FDriverId = _prop_val; FDriverId_Specified = true;  }
  bool __fastcall DriverId_Specified(int Index)
  {  return FDriverId_Specified;  } 
  void __fastcall SetDriverPrevContracts(int Index, ArrayOfDriverPrevContractDto _prop_val)
  {  FDriverPrevContracts = _prop_val; FDriverPrevContracts_Specified = true;  }
  bool __fastcall DriverPrevContracts_Specified(int Index)
  {  return FDriverPrevContracts_Specified;  } 
  void __fastcall SetK1Driver(int Index, TXSDecimal* _prop_val)
  {  FK1Driver = _prop_val; FK1Driver_Specified = true;  }
  bool __fastcall K1Driver_Specified(int Index)
  {  return FK1Driver_Specified;  } 
  void __fastcall SetK6Driver(int Index, TXSDecimal* _prop_val)
  {  FK6Driver = _prop_val; FK6Driver_Specified = true;  }
  bool __fastcall K6Driver_Specified(int Index)
  {  return FK6Driver_Specified;  } 
  void __fastcall SetKbmRsaRequestId(int Index, WideString _prop_val)
  {  FKbmRsaRequestId = _prop_val; FKbmRsaRequestId_Specified = true;  }
  bool __fastcall KbmRsaRequestId_Specified(int Index)
  {  return FKbmRsaRequestId_Specified;  } 

public:
  __fastcall ~AdmitResultsDto();
__published:
  __property WideString   DriverId = { index=(IS_OPTN|IS_NLBL), read=FDriverId, write=SetDriverId, stored = DriverId_Specified };
  __property ArrayOfDriverPrevContractDto DriverPrevContracts = { index=(IS_OPTN|IS_NLBL), read=FDriverPrevContracts, write=SetDriverPrevContracts, stored = DriverPrevContracts_Specified };
  __property TXSDecimal*   K1Driver = { index=(IS_OPTN), read=FK1Driver, write=SetK1Driver, stored = K1Driver_Specified };
  __property TXSDecimal*   K6Driver = { index=(IS_OPTN), read=FK6Driver, write=SetK6Driver, stored = K6Driver_Specified };
  __property WideString KbmRsaRequestId = { index=(IS_OPTN|IS_NLBL), read=FKbmRsaRequestId, write=SetKbmRsaRequestId, stored = KbmRsaRequestId_Specified };
};




// ************************************************************************ //
// XML       : DriverPrevContractDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverPrevContractDto : public TRemotable {
private:
  WideString      FK6_ContractId;
  bool            FK6_ContractId_Specified;
  bool            FK6_IsCalc;
  bool            FK6_IsCalc_Specified;
  int             FK6_SystemId;
  bool            FK6_SystemId_Specified;
  void __fastcall SetK6_ContractId(int Index, WideString _prop_val)
  {  FK6_ContractId = _prop_val; FK6_ContractId_Specified = true;  }
  bool __fastcall K6_ContractId_Specified(int Index)
  {  return FK6_ContractId_Specified;  } 
  void __fastcall SetK6_IsCalc(int Index, bool _prop_val)
  {  FK6_IsCalc = _prop_val; FK6_IsCalc_Specified = true;  }
  bool __fastcall K6_IsCalc_Specified(int Index)
  {  return FK6_IsCalc_Specified;  } 
  void __fastcall SetK6_SystemId(int Index, int _prop_val)
  {  FK6_SystemId = _prop_val; FK6_SystemId_Specified = true;  }
  bool __fastcall K6_SystemId_Specified(int Index)
  {  return FK6_SystemId_Specified;  } 
__published:
  __property WideString K6_ContractId = { index=(IS_OPTN|IS_NLBL), read=FK6_ContractId, write=SetK6_ContractId, stored = K6_ContractId_Specified };
  __property bool        K6_IsCalc = { index=(IS_OPTN), read=FK6_IsCalc, write=SetK6_IsCalc, stored = K6_IsCalc_Specified };
  __property int        K6_SystemId = { index=(IS_OPTN), read=FK6_SystemId, write=SetK6_SystemId, stored = K6_SystemId_Specified };
};




// ************************************************************************ //
// XML       : PrevContractIdDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrevContractIdDto : public TRemotable {
private:
  WideString      FK5_ContractId;
  bool            FK5_ContractId_Specified;
  int             FK5_SystemId;
  bool            FK5_SystemId_Specified;
  WideString      FK6_ContractId;
  bool            FK6_ContractId_Specified;
  bool            FK6_IsCalc;
  bool            FK6_IsCalc_Specified;
  int             FK6_SystemId;
  bool            FK6_SystemId_Specified;
  void __fastcall SetK5_ContractId(int Index, WideString _prop_val)
  {  FK5_ContractId = _prop_val; FK5_ContractId_Specified = true;  }
  bool __fastcall K5_ContractId_Specified(int Index)
  {  return FK5_ContractId_Specified;  } 
  void __fastcall SetK5_SystemId(int Index, int _prop_val)
  {  FK5_SystemId = _prop_val; FK5_SystemId_Specified = true;  }
  bool __fastcall K5_SystemId_Specified(int Index)
  {  return FK5_SystemId_Specified;  } 
  void __fastcall SetK6_ContractId(int Index, WideString _prop_val)
  {  FK6_ContractId = _prop_val; FK6_ContractId_Specified = true;  }
  bool __fastcall K6_ContractId_Specified(int Index)
  {  return FK6_ContractId_Specified;  } 
  void __fastcall SetK6_IsCalc(int Index, bool _prop_val)
  {  FK6_IsCalc = _prop_val; FK6_IsCalc_Specified = true;  }
  bool __fastcall K6_IsCalc_Specified(int Index)
  {  return FK6_IsCalc_Specified;  } 
  void __fastcall SetK6_SystemId(int Index, int _prop_val)
  {  FK6_SystemId = _prop_val; FK6_SystemId_Specified = true;  }
  bool __fastcall K6_SystemId_Specified(int Index)
  {  return FK6_SystemId_Specified;  } 
__published:
  __property WideString K5_ContractId = { index=(IS_OPTN|IS_NLBL), read=FK5_ContractId, write=SetK5_ContractId, stored = K5_ContractId_Specified };
  __property int        K5_SystemId = { index=(IS_OPTN), read=FK5_SystemId, write=SetK5_SystemId, stored = K5_SystemId_Specified };
  __property WideString K6_ContractId = { index=(IS_OPTN|IS_NLBL), read=FK6_ContractId, write=SetK6_ContractId, stored = K6_ContractId_Specified };
  __property bool        K6_IsCalc = { index=(IS_OPTN|IS_NLBL), read=FK6_IsCalc, write=SetK6_IsCalc, stored = K6_IsCalc_Specified };
  __property int        K6_SystemId = { index=(IS_OPTN), read=FK6_SystemId, write=SetK6_SystemId, stored = K6_SystemId_Specified };
};




// ************************************************************************ //
// XML       : ReservationCoefficient, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ReservationCoefficient : public TRemotable {
private:
  WideString      FName;
  bool            FName_Specified;
  TXSDecimal*     FValue;
  bool            FValue_Specified;
  int             FValueId;
  bool            FValueId_Specified;
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetValue(int Index, TXSDecimal* _prop_val)
  {  FValue = _prop_val; FValue_Specified = true;  }
  bool __fastcall Value_Specified(int Index)
  {  return FValue_Specified;  } 
  void __fastcall SetValueId(int Index, int _prop_val)
  {  FValueId = _prop_val; FValueId_Specified = true;  }
  bool __fastcall ValueId_Specified(int Index)
  {  return FValueId_Specified;  } 

public:
  __fastcall ~ReservationCoefficient();
__published:
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property TXSDecimal*      Value = { index=(IS_OPTN|IS_NLBL), read=FValue, write=SetValue, stored = Value_Specified };
  __property int           ValueId = { index=(IS_OPTN|IS_NLBL), read=FValueId, write=SetValueId, stored = ValueId_Specified };
};




// ************************************************************************ //
// XML       : RiskObject, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RiskObject : public TRemotable {
private:
  TXSDecimal*     FLiability;
  bool            FLiability_Specified;
  int             FNumber;
  bool            FNumber_Specified;
  TXSDecimal*     FPremium;
  bool            FPremium_Specified;
  TXSDecimal*     FTariff;
  bool            FTariff_Specified;
  WideString      FTypeId;
  bool            FTypeId_Specified;
  void __fastcall SetLiability(int Index, TXSDecimal* _prop_val)
  {  FLiability = _prop_val; FLiability_Specified = true;  }
  bool __fastcall Liability_Specified(int Index)
  {  return FLiability_Specified;  } 
  void __fastcall SetNumber(int Index, int _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetPremium(int Index, TXSDecimal* _prop_val)
  {  FPremium = _prop_val; FPremium_Specified = true;  }
  bool __fastcall Premium_Specified(int Index)
  {  return FPremium_Specified;  } 
  void __fastcall SetTariff(int Index, TXSDecimal* _prop_val)
  {  FTariff = _prop_val; FTariff_Specified = true;  }
  bool __fastcall Tariff_Specified(int Index)
  {  return FTariff_Specified;  } 
  void __fastcall SetTypeId(int Index, WideString _prop_val)
  {  FTypeId = _prop_val; FTypeId_Specified = true;  }
  bool __fastcall TypeId_Specified(int Index)
  {  return FTypeId_Specified;  } 

public:
  __fastcall ~RiskObject();
__published:
  __property TXSDecimal*  Liability = { index=(IS_OPTN|IS_NLBL), read=FLiability, write=SetLiability, stored = Liability_Specified };
  __property int            Number = { index=(IS_OPTN), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property TXSDecimal*    Premium = { index=(IS_OPTN|IS_NLBL), read=FPremium, write=SetPremium, stored = Premium_Specified };
  __property TXSDecimal*     Tariff = { index=(IS_OPTN|IS_NLBL), read=FTariff, write=SetTariff, stored = Tariff_Specified };
  __property WideString     TypeId = { index=(IS_OPTN|IS_NLBL), read=FTypeId, write=SetTypeId, stored = TypeId_Specified };
};




// ************************************************************************ //
// XML       : UnderwritingRequirement, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UnderwritingRequirement : public TRemotable {
private:
  WideString      FMessage;
  bool            FMessage_Specified;
  void __fastcall SetMessage(int Index, WideString _prop_val)
  {  FMessage = _prop_val; FMessage_Specified = true;  }
  bool __fastcall Message_Specified(int Index)
  {  return FMessage_Specified;  } 
__published:
  __property WideString    Message = { index=(IS_OPTN|IS_NLBL), read=FMessage, write=SetMessage, stored = Message_Specified };
};


typedef DynamicArray<TXSDecimal*> ArrayOfdecimal; /* "http://schemas.microsoft.com/2003/10/Serialization/Arrays"[GblCplx] */


// ************************************************************************ //
// XML       : KaskoUnderwritingRequirements, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoUnderwritingRequirements : public TRemotable {
private:
  UnderwritingRequirement* FCO;
  bool            FCO_Specified;
  UnderwritingRequirement* FCSKA;
  bool            FCSKA_Specified;
  UnderwritingRequirement* FControllerPse;
  bool            FControllerPse_Specified;
  UnderwritingRequirement* FCorpZam;
  bool            FCorpZam_Specified;
  UnderwritingRequirement* FFilial;
  bool            FFilial_Specified;
  UnderwritingRequirement* FPartnerZam;
  bool            FPartnerZam_Specified;
  ArrayOfdecimal  FReasonIds;
  bool            FReasonIds_Specified;
  UnderwritingRequirement* FSecurity;
  bool            FSecurity_Specified;
  WideString      FVehicleNumber;
  bool            FVehicleNumber_Specified;
  void __fastcall SetCO(int Index, UnderwritingRequirement* _prop_val)
  {  FCO = _prop_val; FCO_Specified = true;  }
  bool __fastcall CO_Specified(int Index)
  {  return FCO_Specified;  } 
  void __fastcall SetCSKA(int Index, UnderwritingRequirement* _prop_val)
  {  FCSKA = _prop_val; FCSKA_Specified = true;  }
  bool __fastcall CSKA_Specified(int Index)
  {  return FCSKA_Specified;  } 
  void __fastcall SetControllerPse(int Index, UnderwritingRequirement* _prop_val)
  {  FControllerPse = _prop_val; FControllerPse_Specified = true;  }
  bool __fastcall ControllerPse_Specified(int Index)
  {  return FControllerPse_Specified;  } 
  void __fastcall SetCorpZam(int Index, UnderwritingRequirement* _prop_val)
  {  FCorpZam = _prop_val; FCorpZam_Specified = true;  }
  bool __fastcall CorpZam_Specified(int Index)
  {  return FCorpZam_Specified;  } 
  void __fastcall SetFilial(int Index, UnderwritingRequirement* _prop_val)
  {  FFilial = _prop_val; FFilial_Specified = true;  }
  bool __fastcall Filial_Specified(int Index)
  {  return FFilial_Specified;  } 
  void __fastcall SetPartnerZam(int Index, UnderwritingRequirement* _prop_val)
  {  FPartnerZam = _prop_val; FPartnerZam_Specified = true;  }
  bool __fastcall PartnerZam_Specified(int Index)
  {  return FPartnerZam_Specified;  } 
  void __fastcall SetReasonIds(int Index, ArrayOfdecimal _prop_val)
  {  FReasonIds = _prop_val; FReasonIds_Specified = true;  }
  bool __fastcall ReasonIds_Specified(int Index)
  {  return FReasonIds_Specified;  } 
  void __fastcall SetSecurity(int Index, UnderwritingRequirement* _prop_val)
  {  FSecurity = _prop_val; FSecurity_Specified = true;  }
  bool __fastcall Security_Specified(int Index)
  {  return FSecurity_Specified;  } 
  void __fastcall SetVehicleNumber(int Index, WideString _prop_val)
  {  FVehicleNumber = _prop_val; FVehicleNumber_Specified = true;  }
  bool __fastcall VehicleNumber_Specified(int Index)
  {  return FVehicleNumber_Specified;  } 

public:
  __fastcall ~KaskoUnderwritingRequirements();
__published:
  __property UnderwritingRequirement*         CO = { index=(IS_OPTN|IS_NLBL), read=FCO, write=SetCO, stored = CO_Specified };
  __property UnderwritingRequirement*       CSKA = { index=(IS_OPTN|IS_NLBL), read=FCSKA, write=SetCSKA, stored = CSKA_Specified };
  __property UnderwritingRequirement* ControllerPse = { index=(IS_OPTN|IS_NLBL), read=FControllerPse, write=SetControllerPse, stored = ControllerPse_Specified };
  __property UnderwritingRequirement*    CorpZam = { index=(IS_OPTN|IS_NLBL), read=FCorpZam, write=SetCorpZam, stored = CorpZam_Specified };
  __property UnderwritingRequirement*     Filial = { index=(IS_OPTN|IS_NLBL), read=FFilial, write=SetFilial, stored = Filial_Specified };
  __property UnderwritingRequirement* PartnerZam = { index=(IS_OPTN|IS_NLBL), read=FPartnerZam, write=SetPartnerZam, stored = PartnerZam_Specified };
  __property ArrayOfdecimal  ReasonIds = { index=(IS_OPTN|IS_NLBL), read=FReasonIds, write=SetReasonIds, stored = ReasonIds_Specified };
  __property UnderwritingRequirement*   Security = { index=(IS_OPTN|IS_NLBL), read=FSecurity, write=SetSecurity, stored = Security_Specified };
  __property WideString VehicleNumber = { index=(IS_OPTN|IS_NLBL), read=FVehicleNumber, write=SetVehicleNumber, stored = VehicleNumber_Specified };
};




// ************************************************************************ //
// XML       : ContractorName, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractorName : public TRemotable {
private:
  PersonName*     FIndividualPerson;
  bool            FIndividualPerson_Specified;
  LegalEntity*    FLegalEntity;
  bool            FLegalEntity_Specified;
  void __fastcall SetIndividualPerson(int Index, PersonName* _prop_val)
  {  FIndividualPerson = _prop_val; FIndividualPerson_Specified = true;  }
  bool __fastcall IndividualPerson_Specified(int Index)
  {  return FIndividualPerson_Specified;  } 
  void __fastcall SetLegalEntity(int Index, LegalEntity* _prop_val)
  {  FLegalEntity = _prop_val; FLegalEntity_Specified = true;  }
  bool __fastcall LegalEntity_Specified(int Index)
  {  return FLegalEntity_Specified;  } 

public:
  __fastcall ~ContractorName();
__published:
  __property PersonName* IndividualPerson = { index=(IS_OPTN|IS_NLBL), read=FIndividualPerson, write=SetIndividualPerson, stored = IndividualPerson_Specified };
  __property LegalEntity* LegalEntity = { index=(IS_OPTN|IS_NLBL), read=FLegalEntity, write=SetLegalEntity, stored = LegalEntity_Specified };
};




// ************************************************************************ //
// XML       : BrandModel, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class BrandModel : public TRemotable {
private:
  WideString      FBrand;
  WideString      FModel;
__published:
  __property WideString      Brand = { index=(IS_NLBL), read=FBrand, write=FBrand };
  __property WideString      Model = { index=(IS_NLBL), read=FModel, write=FModel };
};




// ************************************************************************ //
// XML       : Address, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Address : public TRemotable {
private:
  WideString      FArea;
  bool            FArea_Specified;
  WideString      FBuilding;
  bool            FBuilding_Specified;
  WideString      FCity;
  bool            FCity_Specified;
  int             FCountryCode;
  bool            FCountryCode_Specified;
  WideString      FFlat;
  bool            FFlat_Specified;
  WideString      FFullAddressCompany;
  bool            FFullAddressCompany_Specified;
  WideString      FHouse;
  bool            FHouse_Specified;
  WideString      FKladrCode;
  bool            FKladrCode_Specified;
  WideString      FPlace;
  bool            FPlace_Specified;
  WideString      FPostCode;
  bool            FPostCode_Specified;
  WideString      FRegion;
  bool            FRegion_Specified;
  WideString      FStreet;
  bool            FStreet_Specified;
  void __fastcall SetArea(int Index, WideString _prop_val)
  {  FArea = _prop_val; FArea_Specified = true;  }
  bool __fastcall Area_Specified(int Index)
  {  return FArea_Specified;  } 
  void __fastcall SetBuilding(int Index, WideString _prop_val)
  {  FBuilding = _prop_val; FBuilding_Specified = true;  }
  bool __fastcall Building_Specified(int Index)
  {  return FBuilding_Specified;  } 
  void __fastcall SetCity(int Index, WideString _prop_val)
  {  FCity = _prop_val; FCity_Specified = true;  }
  bool __fastcall City_Specified(int Index)
  {  return FCity_Specified;  } 
  void __fastcall SetCountryCode(int Index, int _prop_val)
  {  FCountryCode = _prop_val; FCountryCode_Specified = true;  }
  bool __fastcall CountryCode_Specified(int Index)
  {  return FCountryCode_Specified;  } 
  void __fastcall SetFlat(int Index, WideString _prop_val)
  {  FFlat = _prop_val; FFlat_Specified = true;  }
  bool __fastcall Flat_Specified(int Index)
  {  return FFlat_Specified;  } 
  void __fastcall SetFullAddressCompany(int Index, WideString _prop_val)
  {  FFullAddressCompany = _prop_val; FFullAddressCompany_Specified = true;  }
  bool __fastcall FullAddressCompany_Specified(int Index)
  {  return FFullAddressCompany_Specified;  } 
  void __fastcall SetHouse(int Index, WideString _prop_val)
  {  FHouse = _prop_val; FHouse_Specified = true;  }
  bool __fastcall House_Specified(int Index)
  {  return FHouse_Specified;  } 
  void __fastcall SetKladrCode(int Index, WideString _prop_val)
  {  FKladrCode = _prop_val; FKladrCode_Specified = true;  }
  bool __fastcall KladrCode_Specified(int Index)
  {  return FKladrCode_Specified;  } 
  void __fastcall SetPlace(int Index, WideString _prop_val)
  {  FPlace = _prop_val; FPlace_Specified = true;  }
  bool __fastcall Place_Specified(int Index)
  {  return FPlace_Specified;  } 
  void __fastcall SetPostCode(int Index, WideString _prop_val)
  {  FPostCode = _prop_val; FPostCode_Specified = true;  }
  bool __fastcall PostCode_Specified(int Index)
  {  return FPostCode_Specified;  } 
  void __fastcall SetRegion(int Index, WideString _prop_val)
  {  FRegion = _prop_val; FRegion_Specified = true;  }
  bool __fastcall Region_Specified(int Index)
  {  return FRegion_Specified;  } 
  void __fastcall SetStreet(int Index, WideString _prop_val)
  {  FStreet = _prop_val; FStreet_Specified = true;  }
  bool __fastcall Street_Specified(int Index)
  {  return FStreet_Specified;  } 
__published:
  __property WideString       Area = { index=(IS_OPTN|IS_NLBL), read=FArea, write=SetArea, stored = Area_Specified };
  __property WideString   Building = { index=(IS_OPTN|IS_NLBL), read=FBuilding, write=SetBuilding, stored = Building_Specified };
  __property WideString       City = { index=(IS_OPTN|IS_NLBL), read=FCity, write=SetCity, stored = City_Specified };
  __property int        CountryCode = { index=(IS_OPTN), read=FCountryCode, write=SetCountryCode, stored = CountryCode_Specified };
  __property WideString       Flat = { index=(IS_OPTN|IS_NLBL), read=FFlat, write=SetFlat, stored = Flat_Specified };
  __property WideString FullAddressCompany = { index=(IS_OPTN|IS_NLBL), read=FFullAddressCompany, write=SetFullAddressCompany, stored = FullAddressCompany_Specified };
  __property WideString      House = { index=(IS_OPTN|IS_NLBL), read=FHouse, write=SetHouse, stored = House_Specified };
  __property WideString  KladrCode = { index=(IS_OPTN|IS_NLBL), read=FKladrCode, write=SetKladrCode, stored = KladrCode_Specified };
  __property WideString      Place = { index=(IS_OPTN|IS_NLBL), read=FPlace, write=SetPlace, stored = Place_Specified };
  __property WideString   PostCode = { index=(IS_OPTN|IS_NLBL), read=FPostCode, write=SetPostCode, stored = PostCode_Specified };
  __property WideString     Region = { index=(IS_OPTN|IS_NLBL), read=FRegion, write=SetRegion, stored = Region_Specified };
  __property WideString     Street = { index=(IS_OPTN|IS_NLBL), read=FStreet, write=SetStreet, stored = Street_Specified };
};




// ************************************************************************ //
// XML       : Proxy, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Proxy : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  WideString      FName;
  bool            FName_Specified;
  WideString      FNameGenitive;
  bool            FNameGenitive_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetNameGenitive(int Index, WideString _prop_val)
  {  FNameGenitive = _prop_val; FNameGenitive_Specified = true;  }
  bool __fastcall NameGenitive_Specified(int Index)
  {  return FNameGenitive_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString NameGenitive = { index=(IS_OPTN|IS_NLBL), read=FNameGenitive, write=SetNameGenitive, stored = NameGenitive_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
};




// ************************************************************************ //
// XML       : Pledgeholder, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Pledgeholder : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  LegalEntity*    FLegalEntity;
  bool            FLegalEntity_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetLegalEntity(int Index, LegalEntity* _prop_val)
  {  FLegalEntity = _prop_val; FLegalEntity_Specified = true;  }
  bool __fastcall LegalEntity_Specified(int Index)
  {  return FLegalEntity_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 

public:
  __fastcall ~Pledgeholder();
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property LegalEntity* LegalEntity = { index=(IS_OPTN|IS_NLBL), read=FLegalEntity, write=SetLegalEntity, stored = LegalEntity_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
};




// ************************************************************************ //
// XML       : KaskoPrintRequestDto, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class KaskoPrintRequestDto : public Document {
private:
  WideString      FAtypicalNumber;
  bool            FAtypicalNumber_Specified;
  guid            FContractId;
  guid            FCorellationId;
  bool            FCorellationId_Specified;
  bool            FDraft;
  bool            FDraft_Specified;
  void __fastcall SetAtypicalNumber(int Index, WideString _prop_val)
  {  FAtypicalNumber = _prop_val; FAtypicalNumber_Specified = true;  }
  bool __fastcall AtypicalNumber_Specified(int Index)
  {  return FAtypicalNumber_Specified;  } 
  void __fastcall SetCorellationId(int Index, guid _prop_val)
  {  FCorellationId = _prop_val; FCorellationId_Specified = true;  }
  bool __fastcall CorellationId_Specified(int Index)
  {  return FCorellationId_Specified;  } 
  void __fastcall SetDraft(int Index, bool _prop_val)
  {  FDraft = _prop_val; FDraft_Specified = true;  }
  bool __fastcall Draft_Specified(int Index)
  {  return FDraft_Specified;  } 
__published:
  __property WideString AtypicalNumber = { index=(IS_OPTN|IS_NLBL), read=FAtypicalNumber, write=SetAtypicalNumber, stored = AtypicalNumber_Specified };
  __property guid       ContractId = { read=FContractId, write=FContractId };
  __property guid       CorellationId = { index=(IS_OPTN|IS_NLBL), read=FCorellationId, write=SetCorellationId, stored = CorellationId_Specified };
  __property bool            Draft = { index=(IS_OPTN|IS_NLBL), read=FDraft, write=SetDraft, stored = Draft_Specified };
};




// ************************************************************************ //
// XML       : PrintCertificateRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintCertificateRequest : public KaskoPrintRequestDto {
private:
  TXSDecimal*     FPremiumTsDo;
  WideString      FServiceCardNumber;
  bool            FServiceCardNumber_Specified;
  WideString      FVehNumber;
  void __fastcall SetServiceCardNumber(int Index, WideString _prop_val)
  {  FServiceCardNumber = _prop_val; FServiceCardNumber_Specified = true;  }
  bool __fastcall ServiceCardNumber_Specified(int Index)
  {  return FServiceCardNumber_Specified;  } 

public:
  __fastcall ~PrintCertificateRequest();
__published:
  __property TXSDecimal* PremiumTsDo = { read=FPremiumTsDo, write=FPremiumTsDo };
  __property WideString ServiceCardNumber = { index=(IS_OPTN|IS_NLBL), read=FServiceCardNumber, write=SetServiceCardNumber, stored = ServiceCardNumber_Specified };
  __property WideString  VehNumber = { index=(IS_NLBL), read=FVehNumber, write=FVehNumber };
};




// ************************************************************************ //
// XML       : PrintRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintRequest : public PrintCertificateRequest {
private:
  WideString      FAdditionalConditions;
  bool            FAdditionalConditions_Specified;
  ContractorName* FBeneficiary;
  BrandModel*     FBrandModel;
  Address*        FInsurantAddress;
  PersonName*     FInsurer;
  WideString      FInsurerPost;
  bool            FInsurerPost_Specified;
  Proxy*          FInsurerProxy;
  bool            FInsurerProxy_Specified;
  WideString      FOtherConditions;
  bool            FOtherConditions_Specified;
  Pledgeholder*   FPledgeholder;
  bool            FPledgeholder_Specified;
  void __fastcall SetAdditionalConditions(int Index, WideString _prop_val)
  {  FAdditionalConditions = _prop_val; FAdditionalConditions_Specified = true;  }
  bool __fastcall AdditionalConditions_Specified(int Index)
  {  return FAdditionalConditions_Specified;  } 
  void __fastcall SetInsurerPost(int Index, WideString _prop_val)
  {  FInsurerPost = _prop_val; FInsurerPost_Specified = true;  }
  bool __fastcall InsurerPost_Specified(int Index)
  {  return FInsurerPost_Specified;  } 
  void __fastcall SetInsurerProxy(int Index, Proxy* _prop_val)
  {  FInsurerProxy = _prop_val; FInsurerProxy_Specified = true;  }
  bool __fastcall InsurerProxy_Specified(int Index)
  {  return FInsurerProxy_Specified;  } 
  void __fastcall SetOtherConditions(int Index, WideString _prop_val)
  {  FOtherConditions = _prop_val; FOtherConditions_Specified = true;  }
  bool __fastcall OtherConditions_Specified(int Index)
  {  return FOtherConditions_Specified;  } 
  void __fastcall SetPledgeholder(int Index, Pledgeholder* _prop_val)
  {  FPledgeholder = _prop_val; FPledgeholder_Specified = true;  }
  bool __fastcall Pledgeholder_Specified(int Index)
  {  return FPledgeholder_Specified;  } 

public:
  __fastcall ~PrintRequest();
__published:
  __property WideString AdditionalConditions = { index=(IS_OPTN|IS_NLBL), read=FAdditionalConditions, write=SetAdditionalConditions, stored = AdditionalConditions_Specified };
  __property ContractorName* Beneficiary = { index=(IS_NLBL), read=FBeneficiary, write=FBeneficiary };
  __property BrandModel* BrandModel = { index=(IS_NLBL), read=FBrandModel, write=FBrandModel };
  __property Address*   InsurantAddress = { index=(IS_NLBL), read=FInsurantAddress, write=FInsurantAddress };
  __property PersonName*    Insurer = { index=(IS_NLBL), read=FInsurer, write=FInsurer };
  __property WideString InsurerPost = { index=(IS_OPTN|IS_NLBL), read=FInsurerPost, write=SetInsurerPost, stored = InsurerPost_Specified };
  __property Proxy*     InsurerProxy = { index=(IS_OPTN|IS_NLBL), read=FInsurerProxy, write=SetInsurerProxy, stored = InsurerProxy_Specified };
  __property WideString OtherConditions = { index=(IS_OPTN|IS_NLBL), read=FOtherConditions, write=SetOtherConditions, stored = OtherConditions_Specified };
  __property Pledgeholder* Pledgeholder = { index=(IS_OPTN|IS_NLBL), read=FPledgeholder, write=SetPledgeholder, stored = Pledgeholder_Specified };
};




// ************************************************************************ //
// XML       : Signer, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Signer : public TRemotable {
private:
  SignerDocument* FDocument;
  bool            FDocument_Specified;
  PersonName*     FName;
  bool            FName_Specified;
  WideString      FPost;
  bool            FPost_Specified;
  void __fastcall SetDocument(int Index, SignerDocument* _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetName(int Index, PersonName* _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetPost(int Index, WideString _prop_val)
  {  FPost = _prop_val; FPost_Specified = true;  }
  bool __fastcall Post_Specified(int Index)
  {  return FPost_Specified;  } 

public:
  __fastcall ~Signer();
__published:
  __property SignerDocument*   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property PersonName*       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString       Post = { index=(IS_OPTN|IS_NLBL), read=FPost, write=SetPost, stored = Post_Specified };
};




// ************************************************************************ //
// XML       : AppInsurer, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AppInsurer : public TRemotable {
private:
  PersonName*     FName;
  WideString      FPost;
  bool            FPost_Specified;
  WideString      FProxyDate;
  bool            FProxyDate_Specified;
  WideString      FProxyNumber;
  bool            FProxyNumber_Specified;
  void __fastcall SetPost(int Index, WideString _prop_val)
  {  FPost = _prop_val; FPost_Specified = true;  }
  bool __fastcall Post_Specified(int Index)
  {  return FPost_Specified;  } 
  void __fastcall SetProxyDate(int Index, WideString _prop_val)
  {  FProxyDate = _prop_val; FProxyDate_Specified = true;  }
  bool __fastcall ProxyDate_Specified(int Index)
  {  return FProxyDate_Specified;  } 
  void __fastcall SetProxyNumber(int Index, WideString _prop_val)
  {  FProxyNumber = _prop_val; FProxyNumber_Specified = true;  }
  bool __fastcall ProxyNumber_Specified(int Index)
  {  return FProxyNumber_Specified;  } 

public:
  __fastcall ~AppInsurer();
__published:
  __property PersonName*       Name = { index=(IS_NLBL), read=FName, write=FName };
  __property WideString       Post = { index=(IS_OPTN|IS_NLBL), read=FPost, write=SetPost, stored = Post_Specified };
  __property WideString  ProxyDate = { index=(IS_OPTN|IS_NLBL), read=FProxyDate, write=SetProxyDate, stored = ProxyDate_Specified };
  __property WideString ProxyNumber = { index=(IS_OPTN|IS_NLBL), read=FProxyNumber, write=SetProxyNumber, stored = ProxyNumber_Specified };
};


typedef DynamicArray<PrintAppVehicle*> ArrayOfPrintAppVehicle; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : PrintAppRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintAppRequest : public KaskoPrintRequestDto {
private:
  PersonName*     FInsurant;
  bool            FInsurant_Specified;
  Signer*         FInsurantRepresentative;
  bool            FInsurantRepresentative_Specified;
  AppInsurer*     FInsurer;
  bool            FInsurer_Specified;
  Signer*         FInsurerRepresentative;
  bool            FInsurerRepresentative_Specified;
  ArrayOfPrintAppVehicle FVehicles;
  bool            FVehicles_Specified;
  void __fastcall SetInsurant(int Index, PersonName* _prop_val)
  {  FInsurant = _prop_val; FInsurant_Specified = true;  }
  bool __fastcall Insurant_Specified(int Index)
  {  return FInsurant_Specified;  } 
  void __fastcall SetInsurantRepresentative(int Index, Signer* _prop_val)
  {  FInsurantRepresentative = _prop_val; FInsurantRepresentative_Specified = true;  }
  bool __fastcall InsurantRepresentative_Specified(int Index)
  {  return FInsurantRepresentative_Specified;  } 
  void __fastcall SetInsurer(int Index, AppInsurer* _prop_val)
  {  FInsurer = _prop_val; FInsurer_Specified = true;  }
  bool __fastcall Insurer_Specified(int Index)
  {  return FInsurer_Specified;  } 
  void __fastcall SetInsurerRepresentative(int Index, Signer* _prop_val)
  {  FInsurerRepresentative = _prop_val; FInsurerRepresentative_Specified = true;  }
  bool __fastcall InsurerRepresentative_Specified(int Index)
  {  return FInsurerRepresentative_Specified;  } 
  void __fastcall SetVehicles(int Index, ArrayOfPrintAppVehicle _prop_val)
  {  FVehicles = _prop_val; FVehicles_Specified = true;  }
  bool __fastcall Vehicles_Specified(int Index)
  {  return FVehicles_Specified;  } 

public:
  __fastcall ~PrintAppRequest();
__published:
  __property PersonName*   Insurant = { index=(IS_OPTN|IS_NLBL), read=FInsurant, write=SetInsurant, stored = Insurant_Specified };
  __property Signer*    InsurantRepresentative = { index=(IS_OPTN|IS_NLBL), read=FInsurantRepresentative, write=SetInsurantRepresentative, stored = InsurantRepresentative_Specified };
  __property AppInsurer*    Insurer = { index=(IS_OPTN|IS_NLBL), read=FInsurer, write=SetInsurer, stored = Insurer_Specified };
  __property Signer*    InsurerRepresentative = { index=(IS_OPTN|IS_NLBL), read=FInsurerRepresentative, write=SetInsurerRepresentative, stored = InsurerRepresentative_Specified };
  __property ArrayOfPrintAppVehicle   Vehicles = { index=(IS_OPTN|IS_NLBL), read=FVehicles, write=SetVehicles, stored = Vehicles_Specified };
};




// ************************************************************************ //
// XML       : SignerDocument, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class SignerDocument : public TRemotable {
private:
  WideString      FIssueDate;
  bool            FIssueDate_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  WideString      FType;
  bool            FType_Specified;
  void __fastcall SetIssueDate(int Index, WideString _prop_val)
  {  FIssueDate = _prop_val; FIssueDate_Specified = true;  }
  bool __fastcall IssueDate_Specified(int Index)
  {  return FIssueDate_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 
  void __fastcall SetType(int Index, WideString _prop_val)
  {  FType = _prop_val; FType_Specified = true;  }
  bool __fastcall Type_Specified(int Index)
  {  return FType_Specified;  } 
__published:
  __property WideString  IssueDate = { index=(IS_OPTN|IS_NLBL), read=FIssueDate, write=SetIssueDate, stored = IssueDate_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
  __property WideString       Type = { index=(IS_OPTN|IS_NLBL), read=FType, write=SetType, stored = Type_Specified };
};




// ************************************************************************ //
// XML       : Inspection, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Inspection : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  bool            FWasInspected;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property bool       WasInspected = { read=FWasInspected, write=FWasInspected };
};




// ************************************************************************ //
// XML       : PrintAppVehicle, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintAppVehicle : public PrintCertificateRequest {
private:
  AntiTheftSystemRequirements FAntiTheftSystemRequirements;
  bool            FAntiTheftSystemRequirements_Specified;
  BrandModel*     FBrandModel;
  Inspection*     FInspection;
  bool            FInspection_Specified;
  WideString      FPledgeContractNumber;
  bool            FPledgeContractNumber_Specified;
  RequirementsToAddEquipment FRequirementToAddEquip;
  bool            FRequirementToAddEquip_Specified;
  void __fastcall SetAntiTheftSystemRequirements(int Index, AntiTheftSystemRequirements _prop_val)
  {  FAntiTheftSystemRequirements = _prop_val; FAntiTheftSystemRequirements_Specified = true;  }
  bool __fastcall AntiTheftSystemRequirements_Specified(int Index)
  {  return FAntiTheftSystemRequirements_Specified;  } 
  void __fastcall SetInspection(int Index, Inspection* _prop_val)
  {  FInspection = _prop_val; FInspection_Specified = true;  }
  bool __fastcall Inspection_Specified(int Index)
  {  return FInspection_Specified;  } 
  void __fastcall SetPledgeContractNumber(int Index, WideString _prop_val)
  {  FPledgeContractNumber = _prop_val; FPledgeContractNumber_Specified = true;  }
  bool __fastcall PledgeContractNumber_Specified(int Index)
  {  return FPledgeContractNumber_Specified;  } 
  void __fastcall SetRequirementToAddEquip(int Index, RequirementsToAddEquipment _prop_val)
  {  FRequirementToAddEquip = _prop_val; FRequirementToAddEquip_Specified = true;  }
  bool __fastcall RequirementToAddEquip_Specified(int Index)
  {  return FRequirementToAddEquip_Specified;  } 

public:
  __fastcall ~PrintAppVehicle();
__published:
  __property AntiTheftSystemRequirements AntiTheftSystemRequirements = { index=(IS_OPTN|IS_NLBL), read=FAntiTheftSystemRequirements, write=SetAntiTheftSystemRequirements, stored = AntiTheftSystemRequirements_Specified };
  __property BrandModel* BrandModel = { index=(IS_NLBL), read=FBrandModel, write=FBrandModel };
  __property Inspection* Inspection = { index=(IS_OPTN|IS_NLBL), read=FInspection, write=SetInspection, stored = Inspection_Specified };
  __property WideString PledgeContractNumber = { index=(IS_OPTN|IS_NLBL), read=FPledgeContractNumber, write=SetPledgeContractNumber, stored = PledgeContractNumber_Specified };
  __property RequirementsToAddEquipment RequirementToAddEquip = { index=(IS_OPTN|IS_NLBL), read=FRequirementToAddEquip, write=SetRequirementToAddEquip, stored = RequirementToAddEquip_Specified };
};


typedef DynamicArray<BLTSInsRiskDto*> ArrayOfBLTSInsRiskDto; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print"[GblCplx] */
typedef DynamicArray<KeyValuePairOfstringVehicleAddInformationo_S6zkk9u*> ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */


// ************************************************************************ //
// XML       : PrintAppRequestUl, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintAppRequestUl : public PrintAppRequest {
private:
  TXSDecimal*     FAdditionalExpensesPremKop;
  bool            FAdditionalExpensesPremKop_Specified;
  TXSDecimal*     FAdditionalExpensesPremRub;
  bool            FAdditionalExpensesPremRub_Specified;
  ArrayOfBLTSInsRiskDto FKascoAppInsRiskPeriod1;
  bool            FKascoAppInsRiskPeriod1_Specified;
  ArrayOfBLTSInsRiskDto FKascoAppInsRiskPeriod2;
  bool            FKascoAppInsRiskPeriod2_Specified;
  ArrayOfBLTSInsRiskDto FKascoAppInsRiskPeriod3;
  bool            FKascoAppInsRiskPeriod3_Specified;
  ArrayOfBLTSInsRiskDto FKascoAppInsRiskPeriod4;
  bool            FKascoAppInsRiskPeriod4_Specified;
  ArrayOfBLTSInsRiskDto FKascoAppInsRiskPeriod5;
  bool            FKascoAppInsRiskPeriod5_Specified;
  TXSDecimal*     FMedicalCarePremKop;
  bool            FMedicalCarePremKop_Specified;
  TXSDecimal*     FMedicalCarePremRub;
  bool            FMedicalCarePremRub_Specified;
  BLPeriodDto*    FPayPeriod1;
  bool            FPayPeriod1_Specified;
  BLPeriodDto*    FPayPeriod2;
  bool            FPayPeriod2_Specified;
  BLPeriodDto*    FPayPeriod3;
  bool            FPayPeriod3_Specified;
  BLPeriodDto*    FPayPeriod4;
  bool            FPayPeriod4_Specified;
  BLPeriodDto*    FPayPeriod5;
  bool            FPayPeriod5_Specified;
  TXSDecimal*     FPremiumDSAGOKop;
  bool            FPremiumDSAGOKop_Specified;
  TXSDecimal*     FPremiumDSAGORub;
  bool            FPremiumDSAGORub_Specified;
  TXSDecimal*     FPremiumKASCOKop;
  bool            FPremiumKASCOKop_Specified;
  TXSDecimal*     FPremiumKASCORub;
  bool            FPremiumKASCORub_Specified;
  TXSDecimal*     FPremiumNSKop;
  bool            FPremiumNSKop_Specified;
  TXSDecimal*     FPremiumNSRub;
  bool            FPremiumNSRub_Specified;
  TXSDecimal*     FTechnicalAssistancePremKop;
  bool            FTechnicalAssistancePremKop_Specified;
  TXSDecimal*     FTechnicalAssistancePremRub;
  bool            FTechnicalAssistancePremRub_Specified;
  TXSDecimal*     FTotalPremiumKop;
  bool            FTotalPremiumKop_Specified;
  TXSDecimal*     FTotalPremiumRub;
  bool            FTotalPremiumRub_Specified;
  ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u FVehicleData;
  bool            FVehicleData_Specified;
  void __fastcall SetAdditionalExpensesPremKop(int Index, TXSDecimal* _prop_val)
  {  FAdditionalExpensesPremKop = _prop_val; FAdditionalExpensesPremKop_Specified = true;  }
  bool __fastcall AdditionalExpensesPremKop_Specified(int Index)
  {  return FAdditionalExpensesPremKop_Specified;  } 
  void __fastcall SetAdditionalExpensesPremRub(int Index, TXSDecimal* _prop_val)
  {  FAdditionalExpensesPremRub = _prop_val; FAdditionalExpensesPremRub_Specified = true;  }
  bool __fastcall AdditionalExpensesPremRub_Specified(int Index)
  {  return FAdditionalExpensesPremRub_Specified;  } 
  void __fastcall SetKascoAppInsRiskPeriod1(int Index, ArrayOfBLTSInsRiskDto _prop_val)
  {  FKascoAppInsRiskPeriod1 = _prop_val; FKascoAppInsRiskPeriod1_Specified = true;  }
  bool __fastcall KascoAppInsRiskPeriod1_Specified(int Index)
  {  return FKascoAppInsRiskPeriod1_Specified;  } 
  void __fastcall SetKascoAppInsRiskPeriod2(int Index, ArrayOfBLTSInsRiskDto _prop_val)
  {  FKascoAppInsRiskPeriod2 = _prop_val; FKascoAppInsRiskPeriod2_Specified = true;  }
  bool __fastcall KascoAppInsRiskPeriod2_Specified(int Index)
  {  return FKascoAppInsRiskPeriod2_Specified;  } 
  void __fastcall SetKascoAppInsRiskPeriod3(int Index, ArrayOfBLTSInsRiskDto _prop_val)
  {  FKascoAppInsRiskPeriod3 = _prop_val; FKascoAppInsRiskPeriod3_Specified = true;  }
  bool __fastcall KascoAppInsRiskPeriod3_Specified(int Index)
  {  return FKascoAppInsRiskPeriod3_Specified;  } 
  void __fastcall SetKascoAppInsRiskPeriod4(int Index, ArrayOfBLTSInsRiskDto _prop_val)
  {  FKascoAppInsRiskPeriod4 = _prop_val; FKascoAppInsRiskPeriod4_Specified = true;  }
  bool __fastcall KascoAppInsRiskPeriod4_Specified(int Index)
  {  return FKascoAppInsRiskPeriod4_Specified;  } 
  void __fastcall SetKascoAppInsRiskPeriod5(int Index, ArrayOfBLTSInsRiskDto _prop_val)
  {  FKascoAppInsRiskPeriod5 = _prop_val; FKascoAppInsRiskPeriod5_Specified = true;  }
  bool __fastcall KascoAppInsRiskPeriod5_Specified(int Index)
  {  return FKascoAppInsRiskPeriod5_Specified;  } 
  void __fastcall SetMedicalCarePremKop(int Index, TXSDecimal* _prop_val)
  {  FMedicalCarePremKop = _prop_val; FMedicalCarePremKop_Specified = true;  }
  bool __fastcall MedicalCarePremKop_Specified(int Index)
  {  return FMedicalCarePremKop_Specified;  } 
  void __fastcall SetMedicalCarePremRub(int Index, TXSDecimal* _prop_val)
  {  FMedicalCarePremRub = _prop_val; FMedicalCarePremRub_Specified = true;  }
  bool __fastcall MedicalCarePremRub_Specified(int Index)
  {  return FMedicalCarePremRub_Specified;  } 
  void __fastcall SetPayPeriod1(int Index, BLPeriodDto* _prop_val)
  {  FPayPeriod1 = _prop_val; FPayPeriod1_Specified = true;  }
  bool __fastcall PayPeriod1_Specified(int Index)
  {  return FPayPeriod1_Specified;  } 
  void __fastcall SetPayPeriod2(int Index, BLPeriodDto* _prop_val)
  {  FPayPeriod2 = _prop_val; FPayPeriod2_Specified = true;  }
  bool __fastcall PayPeriod2_Specified(int Index)
  {  return FPayPeriod2_Specified;  } 
  void __fastcall SetPayPeriod3(int Index, BLPeriodDto* _prop_val)
  {  FPayPeriod3 = _prop_val; FPayPeriod3_Specified = true;  }
  bool __fastcall PayPeriod3_Specified(int Index)
  {  return FPayPeriod3_Specified;  } 
  void __fastcall SetPayPeriod4(int Index, BLPeriodDto* _prop_val)
  {  FPayPeriod4 = _prop_val; FPayPeriod4_Specified = true;  }
  bool __fastcall PayPeriod4_Specified(int Index)
  {  return FPayPeriod4_Specified;  } 
  void __fastcall SetPayPeriod5(int Index, BLPeriodDto* _prop_val)
  {  FPayPeriod5 = _prop_val; FPayPeriod5_Specified = true;  }
  bool __fastcall PayPeriod5_Specified(int Index)
  {  return FPayPeriod5_Specified;  } 
  void __fastcall SetPremiumDSAGOKop(int Index, TXSDecimal* _prop_val)
  {  FPremiumDSAGOKop = _prop_val; FPremiumDSAGOKop_Specified = true;  }
  bool __fastcall PremiumDSAGOKop_Specified(int Index)
  {  return FPremiumDSAGOKop_Specified;  } 
  void __fastcall SetPremiumDSAGORub(int Index, TXSDecimal* _prop_val)
  {  FPremiumDSAGORub = _prop_val; FPremiumDSAGORub_Specified = true;  }
  bool __fastcall PremiumDSAGORub_Specified(int Index)
  {  return FPremiumDSAGORub_Specified;  } 
  void __fastcall SetPremiumKASCOKop(int Index, TXSDecimal* _prop_val)
  {  FPremiumKASCOKop = _prop_val; FPremiumKASCOKop_Specified = true;  }
  bool __fastcall PremiumKASCOKop_Specified(int Index)
  {  return FPremiumKASCOKop_Specified;  } 
  void __fastcall SetPremiumKASCORub(int Index, TXSDecimal* _prop_val)
  {  FPremiumKASCORub = _prop_val; FPremiumKASCORub_Specified = true;  }
  bool __fastcall PremiumKASCORub_Specified(int Index)
  {  return FPremiumKASCORub_Specified;  } 
  void __fastcall SetPremiumNSKop(int Index, TXSDecimal* _prop_val)
  {  FPremiumNSKop = _prop_val; FPremiumNSKop_Specified = true;  }
  bool __fastcall PremiumNSKop_Specified(int Index)
  {  return FPremiumNSKop_Specified;  } 
  void __fastcall SetPremiumNSRub(int Index, TXSDecimal* _prop_val)
  {  FPremiumNSRub = _prop_val; FPremiumNSRub_Specified = true;  }
  bool __fastcall PremiumNSRub_Specified(int Index)
  {  return FPremiumNSRub_Specified;  } 
  void __fastcall SetTechnicalAssistancePremKop(int Index, TXSDecimal* _prop_val)
  {  FTechnicalAssistancePremKop = _prop_val; FTechnicalAssistancePremKop_Specified = true;  }
  bool __fastcall TechnicalAssistancePremKop_Specified(int Index)
  {  return FTechnicalAssistancePremKop_Specified;  } 
  void __fastcall SetTechnicalAssistancePremRub(int Index, TXSDecimal* _prop_val)
  {  FTechnicalAssistancePremRub = _prop_val; FTechnicalAssistancePremRub_Specified = true;  }
  bool __fastcall TechnicalAssistancePremRub_Specified(int Index)
  {  return FTechnicalAssistancePremRub_Specified;  } 
  void __fastcall SetTotalPremiumKop(int Index, TXSDecimal* _prop_val)
  {  FTotalPremiumKop = _prop_val; FTotalPremiumKop_Specified = true;  }
  bool __fastcall TotalPremiumKop_Specified(int Index)
  {  return FTotalPremiumKop_Specified;  } 
  void __fastcall SetTotalPremiumRub(int Index, TXSDecimal* _prop_val)
  {  FTotalPremiumRub = _prop_val; FTotalPremiumRub_Specified = true;  }
  bool __fastcall TotalPremiumRub_Specified(int Index)
  {  return FTotalPremiumRub_Specified;  } 
  void __fastcall SetVehicleData(int Index, ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u _prop_val)
  {  FVehicleData = _prop_val; FVehicleData_Specified = true;  }
  bool __fastcall VehicleData_Specified(int Index)
  {  return FVehicleData_Specified;  } 

public:
  __fastcall ~PrintAppRequestUl();
__published:
  __property TXSDecimal* AdditionalExpensesPremKop = { index=(IS_OPTN|IS_NLBL), read=FAdditionalExpensesPremKop, write=SetAdditionalExpensesPremKop, stored = AdditionalExpensesPremKop_Specified };
  __property TXSDecimal* AdditionalExpensesPremRub = { index=(IS_OPTN|IS_NLBL), read=FAdditionalExpensesPremRub, write=SetAdditionalExpensesPremRub, stored = AdditionalExpensesPremRub_Specified };
  __property ArrayOfBLTSInsRiskDto KascoAppInsRiskPeriod1 = { index=(IS_OPTN|IS_NLBL), read=FKascoAppInsRiskPeriod1, write=SetKascoAppInsRiskPeriod1, stored = KascoAppInsRiskPeriod1_Specified };
  __property ArrayOfBLTSInsRiskDto KascoAppInsRiskPeriod2 = { index=(IS_OPTN|IS_NLBL), read=FKascoAppInsRiskPeriod2, write=SetKascoAppInsRiskPeriod2, stored = KascoAppInsRiskPeriod2_Specified };
  __property ArrayOfBLTSInsRiskDto KascoAppInsRiskPeriod3 = { index=(IS_OPTN|IS_NLBL), read=FKascoAppInsRiskPeriod3, write=SetKascoAppInsRiskPeriod3, stored = KascoAppInsRiskPeriod3_Specified };
  __property ArrayOfBLTSInsRiskDto KascoAppInsRiskPeriod4 = { index=(IS_OPTN|IS_NLBL), read=FKascoAppInsRiskPeriod4, write=SetKascoAppInsRiskPeriod4, stored = KascoAppInsRiskPeriod4_Specified };
  __property ArrayOfBLTSInsRiskDto KascoAppInsRiskPeriod5 = { index=(IS_OPTN|IS_NLBL), read=FKascoAppInsRiskPeriod5, write=SetKascoAppInsRiskPeriod5, stored = KascoAppInsRiskPeriod5_Specified };
  __property TXSDecimal* MedicalCarePremKop = { index=(IS_OPTN|IS_NLBL), read=FMedicalCarePremKop, write=SetMedicalCarePremKop, stored = MedicalCarePremKop_Specified };
  __property TXSDecimal* MedicalCarePremRub = { index=(IS_OPTN|IS_NLBL), read=FMedicalCarePremRub, write=SetMedicalCarePremRub, stored = MedicalCarePremRub_Specified };
  __property BLPeriodDto* PayPeriod1 = { index=(IS_OPTN|IS_NLBL), read=FPayPeriod1, write=SetPayPeriod1, stored = PayPeriod1_Specified };
  __property BLPeriodDto* PayPeriod2 = { index=(IS_OPTN|IS_NLBL), read=FPayPeriod2, write=SetPayPeriod2, stored = PayPeriod2_Specified };
  __property BLPeriodDto* PayPeriod3 = { index=(IS_OPTN|IS_NLBL), read=FPayPeriod3, write=SetPayPeriod3, stored = PayPeriod3_Specified };
  __property BLPeriodDto* PayPeriod4 = { index=(IS_OPTN|IS_NLBL), read=FPayPeriod4, write=SetPayPeriod4, stored = PayPeriod4_Specified };
  __property BLPeriodDto* PayPeriod5 = { index=(IS_OPTN|IS_NLBL), read=FPayPeriod5, write=SetPayPeriod5, stored = PayPeriod5_Specified };
  __property TXSDecimal* PremiumDSAGOKop = { index=(IS_OPTN|IS_NLBL), read=FPremiumDSAGOKop, write=SetPremiumDSAGOKop, stored = PremiumDSAGOKop_Specified };
  __property TXSDecimal* PremiumDSAGORub = { index=(IS_OPTN|IS_NLBL), read=FPremiumDSAGORub, write=SetPremiumDSAGORub, stored = PremiumDSAGORub_Specified };
  __property TXSDecimal* PremiumKASCOKop = { index=(IS_OPTN|IS_NLBL), read=FPremiumKASCOKop, write=SetPremiumKASCOKop, stored = PremiumKASCOKop_Specified };
  __property TXSDecimal* PremiumKASCORub = { index=(IS_OPTN|IS_NLBL), read=FPremiumKASCORub, write=SetPremiumKASCORub, stored = PremiumKASCORub_Specified };
  __property TXSDecimal* PremiumNSKop = { index=(IS_OPTN|IS_NLBL), read=FPremiumNSKop, write=SetPremiumNSKop, stored = PremiumNSKop_Specified };
  __property TXSDecimal* PremiumNSRub = { index=(IS_OPTN|IS_NLBL), read=FPremiumNSRub, write=SetPremiumNSRub, stored = PremiumNSRub_Specified };
  __property TXSDecimal* TechnicalAssistancePremKop = { index=(IS_OPTN|IS_NLBL), read=FTechnicalAssistancePremKop, write=SetTechnicalAssistancePremKop, stored = TechnicalAssistancePremKop_Specified };
  __property TXSDecimal* TechnicalAssistancePremRub = { index=(IS_OPTN|IS_NLBL), read=FTechnicalAssistancePremRub, write=SetTechnicalAssistancePremRub, stored = TechnicalAssistancePremRub_Specified };
  __property TXSDecimal* TotalPremiumKop = { index=(IS_OPTN|IS_NLBL), read=FTotalPremiumKop, write=SetTotalPremiumKop, stored = TotalPremiumKop_Specified };
  __property TXSDecimal* TotalPremiumRub = { index=(IS_OPTN|IS_NLBL), read=FTotalPremiumRub, write=SetTotalPremiumRub, stored = TotalPremiumRub_Specified };
  __property ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u VehicleData = { index=(IS_OPTN|IS_NLBL), read=FVehicleData, write=SetVehicleData, stored = VehicleData_Specified };
};




// ************************************************************************ //
// XML       : VehicleAddInformation, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleAddInformation : public Document {
private:
  WideString      FBrandByPTS;
  bool            FBrandByPTS_Specified;
  WideString      FDocType;
  bool            FDocType_Specified;
  int             FEngineCapacity;
  bool            FEngineCapacity_Specified;
  int             FEnginePower;
  bool            FEnginePower_Specified;
  WideString      FModelByPTS;
  bool            FModelByPTS_Specified;
  int             FVehicleKeysCount;
  bool            FVehicleKeysCount_Specified;
  void __fastcall SetBrandByPTS(int Index, WideString _prop_val)
  {  FBrandByPTS = _prop_val; FBrandByPTS_Specified = true;  }
  bool __fastcall BrandByPTS_Specified(int Index)
  {  return FBrandByPTS_Specified;  } 
  void __fastcall SetDocType(int Index, WideString _prop_val)
  {  FDocType = _prop_val; FDocType_Specified = true;  }
  bool __fastcall DocType_Specified(int Index)
  {  return FDocType_Specified;  } 
  void __fastcall SetEngineCapacity(int Index, int _prop_val)
  {  FEngineCapacity = _prop_val; FEngineCapacity_Specified = true;  }
  bool __fastcall EngineCapacity_Specified(int Index)
  {  return FEngineCapacity_Specified;  } 
  void __fastcall SetEnginePower(int Index, int _prop_val)
  {  FEnginePower = _prop_val; FEnginePower_Specified = true;  }
  bool __fastcall EnginePower_Specified(int Index)
  {  return FEnginePower_Specified;  } 
  void __fastcall SetModelByPTS(int Index, WideString _prop_val)
  {  FModelByPTS = _prop_val; FModelByPTS_Specified = true;  }
  bool __fastcall ModelByPTS_Specified(int Index)
  {  return FModelByPTS_Specified;  } 
  void __fastcall SetVehicleKeysCount(int Index, int _prop_val)
  {  FVehicleKeysCount = _prop_val; FVehicleKeysCount_Specified = true;  }
  bool __fastcall VehicleKeysCount_Specified(int Index)
  {  return FVehicleKeysCount_Specified;  } 
__published:
  __property WideString BrandByPTS = { index=(IS_OPTN|IS_NLBL), read=FBrandByPTS, write=SetBrandByPTS, stored = BrandByPTS_Specified };
  __property WideString    DocType = { index=(IS_OPTN|IS_NLBL), read=FDocType, write=SetDocType, stored = DocType_Specified };
  __property int        EngineCapacity = { index=(IS_OPTN), read=FEngineCapacity, write=SetEngineCapacity, stored = EngineCapacity_Specified };
  __property int        EnginePower = { index=(IS_OPTN), read=FEnginePower, write=SetEnginePower, stored = EnginePower_Specified };
  __property WideString ModelByPTS = { index=(IS_OPTN|IS_NLBL), read=FModelByPTS, write=SetModelByPTS, stored = ModelByPTS_Specified };
  __property int        VehicleKeysCount = { index=(IS_OPTN), read=FVehicleKeysCount, write=SetVehicleKeysCount, stored = VehicleKeysCount_Specified };
};




// ************************************************************************ //
// XML       : PrintContractRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintContractRequest : public KaskoPrintRequestDto {
private:
  BeneficiaryPrintRequest* FBeneficiary;
  WideString      FCity;
  ContractInsurant* FInsurant;
  ContractInsurer* FInsurer;
  WideString      FLiabilityStartDate;
  bool            FLiabilityStartDate_Specified;
  Payments*       FPayments;
  bool            FRepresentativeOfInsurer;
  bool            FRepresentativeOfInsurer_Specified;
  void __fastcall SetLiabilityStartDate(int Index, WideString _prop_val)
  {  FLiabilityStartDate = _prop_val; FLiabilityStartDate_Specified = true;  }
  bool __fastcall LiabilityStartDate_Specified(int Index)
  {  return FLiabilityStartDate_Specified;  } 
  void __fastcall SetRepresentativeOfInsurer(int Index, bool _prop_val)
  {  FRepresentativeOfInsurer = _prop_val; FRepresentativeOfInsurer_Specified = true;  }
  bool __fastcall RepresentativeOfInsurer_Specified(int Index)
  {  return FRepresentativeOfInsurer_Specified;  } 

public:
  __fastcall ~PrintContractRequest();
__published:
  __property BeneficiaryPrintRequest* Beneficiary = { index=(IS_NLBL), read=FBeneficiary, write=FBeneficiary };
  __property WideString       City = { index=(IS_NLBL), read=FCity, write=FCity };
  __property ContractInsurant*   Insurant = { index=(IS_NLBL), read=FInsurant, write=FInsurant };
  __property ContractInsurer*    Insurer = { index=(IS_NLBL), read=FInsurer, write=FInsurer };
  __property WideString LiabilityStartDate = { index=(IS_OPTN|IS_NLBL), read=FLiabilityStartDate, write=SetLiabilityStartDate, stored = LiabilityStartDate_Specified };
  __property Payments*    Payments = { index=(IS_NLBL), read=FPayments, write=FPayments };
  __property bool       RepresentativeOfInsurer = { index=(IS_OPTN), read=FRepresentativeOfInsurer, write=SetRepresentativeOfInsurer, stored = RepresentativeOfInsurer_Specified };
};




// ************************************************************************ //
// XML       : BeneficiaryPrintRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class BeneficiaryPrintRequest : public TRemotable {
private:
  PersonName*     FName;
  bool            FName_Specified;
  LegalEntity*    FOrganization;
  bool            FOrganization_Specified;
  int             FTypeId;
  bool            FTypeId_Specified;
  void __fastcall SetName(int Index, PersonName* _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetOrganization(int Index, LegalEntity* _prop_val)
  {  FOrganization = _prop_val; FOrganization_Specified = true;  }
  bool __fastcall Organization_Specified(int Index)
  {  return FOrganization_Specified;  } 
  void __fastcall SetTypeId(int Index, int _prop_val)
  {  FTypeId = _prop_val; FTypeId_Specified = true;  }
  bool __fastcall TypeId_Specified(int Index)
  {  return FTypeId_Specified;  } 

public:
  __fastcall ~BeneficiaryPrintRequest();
__published:
  __property PersonName*       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property LegalEntity* Organization = { index=(IS_OPTN|IS_NLBL), read=FOrganization, write=SetOrganization, stored = Organization_Specified };
  __property int            TypeId = { index=(IS_OPTN|IS_NLBL), read=FTypeId, write=SetTypeId, stored = TypeId_Specified };
};




// ************************************************************************ //
// XML       : ContractInsurant, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractInsurant : public TRemotable {
private:
  Address*        FAddress;
  WideString      FINN;
  bool            FINN_Specified;
  WideString      FOGRN;
  bool            FOGRN_Specified;
  Passport*       FPassport;
  WideString      FPost;
  bool            FPost_Specified;
  WideString      FPostGenitive;
  bool            FPostGenitive_Specified;
  Proxy*          FProxy;
  PersonName*     FSigner;
  PersonName*     FSignerGenitive;
  void __fastcall SetINN(int Index, WideString _prop_val)
  {  FINN = _prop_val; FINN_Specified = true;  }
  bool __fastcall INN_Specified(int Index)
  {  return FINN_Specified;  } 
  void __fastcall SetOGRN(int Index, WideString _prop_val)
  {  FOGRN = _prop_val; FOGRN_Specified = true;  }
  bool __fastcall OGRN_Specified(int Index)
  {  return FOGRN_Specified;  } 
  void __fastcall SetPost(int Index, WideString _prop_val)
  {  FPost = _prop_val; FPost_Specified = true;  }
  bool __fastcall Post_Specified(int Index)
  {  return FPost_Specified;  } 
  void __fastcall SetPostGenitive(int Index, WideString _prop_val)
  {  FPostGenitive = _prop_val; FPostGenitive_Specified = true;  }
  bool __fastcall PostGenitive_Specified(int Index)
  {  return FPostGenitive_Specified;  } 

public:
  __fastcall ~ContractInsurant();
__published:
  __property Address*      Address = { index=(IS_NLBL), read=FAddress, write=FAddress };
  __property WideString        INN = { index=(IS_OPTN|IS_NLBL), read=FINN, write=SetINN, stored = INN_Specified };
  __property WideString       OGRN = { index=(IS_OPTN|IS_NLBL), read=FOGRN, write=SetOGRN, stored = OGRN_Specified };
  __property Passport*    Passport = { index=(IS_NLBL), read=FPassport, write=FPassport };
  __property WideString       Post = { index=(IS_OPTN|IS_NLBL), read=FPost, write=SetPost, stored = Post_Specified };
  __property WideString PostGenitive = { index=(IS_OPTN|IS_NLBL), read=FPostGenitive, write=SetPostGenitive, stored = PostGenitive_Specified };
  __property Proxy*          Proxy = { index=(IS_NLBL), read=FProxy, write=FProxy };
  __property PersonName*     Signer = { index=(IS_NLBL), read=FSigner, write=FSigner };
  __property PersonName* SignerGenitive = { index=(IS_NLBL), read=FSignerGenitive, write=FSignerGenitive };
};




// ************************************************************************ //
// XML       : ContractInsurer, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractInsurer : public TRemotable {
private:
  PersonName*     FName;
  bool            FName_Specified;
  PersonName*     FNameGenitive;
  bool            FNameGenitive_Specified;
  WideString      FPost;
  bool            FPost_Specified;
  WideString      FPostGenitive;
  bool            FPostGenitive_Specified;
  Proxy*          FProxy;
  bool            FProxy_Specified;
  void __fastcall SetName(int Index, PersonName* _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetNameGenitive(int Index, PersonName* _prop_val)
  {  FNameGenitive = _prop_val; FNameGenitive_Specified = true;  }
  bool __fastcall NameGenitive_Specified(int Index)
  {  return FNameGenitive_Specified;  } 
  void __fastcall SetPost(int Index, WideString _prop_val)
  {  FPost = _prop_val; FPost_Specified = true;  }
  bool __fastcall Post_Specified(int Index)
  {  return FPost_Specified;  } 
  void __fastcall SetPostGenitive(int Index, WideString _prop_val)
  {  FPostGenitive = _prop_val; FPostGenitive_Specified = true;  }
  bool __fastcall PostGenitive_Specified(int Index)
  {  return FPostGenitive_Specified;  } 
  void __fastcall SetProxy(int Index, Proxy* _prop_val)
  {  FProxy = _prop_val; FProxy_Specified = true;  }
  bool __fastcall Proxy_Specified(int Index)
  {  return FProxy_Specified;  } 

public:
  __fastcall ~ContractInsurer();
__published:
  __property PersonName*       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property PersonName* NameGenitive = { index=(IS_OPTN|IS_NLBL), read=FNameGenitive, write=SetNameGenitive, stored = NameGenitive_Specified };
  __property WideString       Post = { index=(IS_OPTN|IS_NLBL), read=FPost, write=SetPost, stored = Post_Specified };
  __property WideString PostGenitive = { index=(IS_OPTN|IS_NLBL), read=FPostGenitive, write=SetPostGenitive, stored = PostGenitive_Specified };
  __property Proxy*          Proxy = { index=(IS_OPTN|IS_NLBL), read=FProxy, write=SetProxy, stored = Proxy_Specified };
};




// ************************************************************************ //
// XML       : Payments, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Payments : public TRemotable {
private:
  Payment*        FFirstPayment;
  bool            FFirstPayment_Specified;
  Payment*        FFourthPayment;
  bool            FFourthPayment_Specified;
  TXSDecimal*     FNextPaymentSum;
  bool            FNextPaymentSum_Specified;
  WideString      FPolicyNextPaymentDate;
  bool            FPolicyNextPaymentDate_Specified;
  Payment*        FSecondPayment;
  bool            FSecondPayment_Specified;
  Payment*        FThirdPayment;
  bool            FThirdPayment_Specified;
  void __fastcall SetFirstPayment(int Index, Payment* _prop_val)
  {  FFirstPayment = _prop_val; FFirstPayment_Specified = true;  }
  bool __fastcall FirstPayment_Specified(int Index)
  {  return FFirstPayment_Specified;  } 
  void __fastcall SetFourthPayment(int Index, Payment* _prop_val)
  {  FFourthPayment = _prop_val; FFourthPayment_Specified = true;  }
  bool __fastcall FourthPayment_Specified(int Index)
  {  return FFourthPayment_Specified;  } 
  void __fastcall SetNextPaymentSum(int Index, TXSDecimal* _prop_val)
  {  FNextPaymentSum = _prop_val; FNextPaymentSum_Specified = true;  }
  bool __fastcall NextPaymentSum_Specified(int Index)
  {  return FNextPaymentSum_Specified;  } 
  void __fastcall SetPolicyNextPaymentDate(int Index, WideString _prop_val)
  {  FPolicyNextPaymentDate = _prop_val; FPolicyNextPaymentDate_Specified = true;  }
  bool __fastcall PolicyNextPaymentDate_Specified(int Index)
  {  return FPolicyNextPaymentDate_Specified;  } 
  void __fastcall SetSecondPayment(int Index, Payment* _prop_val)
  {  FSecondPayment = _prop_val; FSecondPayment_Specified = true;  }
  bool __fastcall SecondPayment_Specified(int Index)
  {  return FSecondPayment_Specified;  } 
  void __fastcall SetThirdPayment(int Index, Payment* _prop_val)
  {  FThirdPayment = _prop_val; FThirdPayment_Specified = true;  }
  bool __fastcall ThirdPayment_Specified(int Index)
  {  return FThirdPayment_Specified;  } 

public:
  __fastcall ~Payments();
__published:
  __property Payment*   FirstPayment = { index=(IS_OPTN|IS_NLBL), read=FFirstPayment, write=SetFirstPayment, stored = FirstPayment_Specified };
  __property Payment*   FourthPayment = { index=(IS_OPTN|IS_NLBL), read=FFourthPayment, write=SetFourthPayment, stored = FourthPayment_Specified };
  __property TXSDecimal* NextPaymentSum = { index=(IS_OPTN|IS_NLBL), read=FNextPaymentSum, write=SetNextPaymentSum, stored = NextPaymentSum_Specified };
  __property WideString PolicyNextPaymentDate = { index=(IS_OPTN|IS_NLBL), read=FPolicyNextPaymentDate, write=SetPolicyNextPaymentDate, stored = PolicyNextPaymentDate_Specified };
  __property Payment*   SecondPayment = { index=(IS_OPTN|IS_NLBL), read=FSecondPayment, write=SetSecondPayment, stored = SecondPayment_Specified };
  __property Payment*   ThirdPayment = { index=(IS_OPTN|IS_NLBL), read=FThirdPayment, write=SetThirdPayment, stored = ThirdPayment_Specified };
};




// ************************************************************************ //
// XML       : Passport, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Passport : public Document {
private:
  TXSDateTime*    FDate;
  bool            FDate_Specified;
  WideString      FIssueBy;
  bool            FIssueBy_Specified;
  void __fastcall SetDate(int Index, TXSDateTime* _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetIssueBy(int Index, WideString _prop_val)
  {  FIssueBy = _prop_val; FIssueBy_Specified = true;  }
  bool __fastcall IssueBy_Specified(int Index)
  {  return FIssueBy_Specified;  } 

public:
  __fastcall ~Passport();
__published:
  __property TXSDateTime*       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString    IssueBy = { index=(IS_OPTN|IS_NLBL), read=FIssueBy, write=SetIssueBy, stored = IssueBy_Specified };
};




// ************************************************************************ //
// XML       : Payment, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Payment : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  TXSDecimal*     FSum;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 

public:
  __fastcall ~Payment();
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property TXSDecimal*        Sum = { read=FSum, write=FSum };
};




// ************************************************************************ //
// XML       : KaskoPrintContractUlRequestDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoPrintContractUlRequestDto : public PrintContractRequest {
private:
  LeasingContract* FLeasingContract;
  BeneficiaryPrintRequest* FLessee;
  bool            FLessee_Specified;
  int             FLessorId;
  bool            FLessorId_Specified;
  BeneficiaryPrintRequest* FPayer;
  bool            FPayer_Specified;
  void __fastcall SetLessee(int Index, BeneficiaryPrintRequest* _prop_val)
  {  FLessee = _prop_val; FLessee_Specified = true;  }
  bool __fastcall Lessee_Specified(int Index)
  {  return FLessee_Specified;  } 
  void __fastcall SetLessorId(int Index, int _prop_val)
  {  FLessorId = _prop_val; FLessorId_Specified = true;  }
  bool __fastcall LessorId_Specified(int Index)
  {  return FLessorId_Specified;  } 
  void __fastcall SetPayer(int Index, BeneficiaryPrintRequest* _prop_val)
  {  FPayer = _prop_val; FPayer_Specified = true;  }
  bool __fastcall Payer_Specified(int Index)
  {  return FPayer_Specified;  } 

public:
  __fastcall ~KaskoPrintContractUlRequestDto();
__published:
  __property LeasingContract* LeasingContract = { index=(IS_NLBL), read=FLeasingContract, write=FLeasingContract };
  __property BeneficiaryPrintRequest*     Lessee = { index=(IS_OPTN|IS_NLBL), read=FLessee, write=SetLessee, stored = Lessee_Specified };
  __property int          LessorId = { index=(IS_OPTN|IS_NLBL), read=FLessorId, write=SetLessorId, stored = LessorId_Specified };
  __property BeneficiaryPrintRequest*      Payer = { index=(IS_OPTN|IS_NLBL), read=FPayer, write=SetPayer, stored = Payer_Specified };
};




// ************************************************************************ //
// XML       : LeasingContract, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class LeasingContract : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
};




// ************************************************************************ //
// XML       : Beneficiary, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Beneficiary : public TRemotable {
private:
  TXSDateTime*    FBirthDate;
  bool            FBirthDate_Specified;
  CommonDocument* FDocument;
  bool            FDocument_Specified;
  WideString      FInn;
  bool            FInn_Specified;
  WideString      FOgrn;
  bool            FOgrn_Specified;
  LegalEntity*    FOrganization;
  bool            FOrganization_Specified;
  PersonName*     FPerson;
  bool            FPerson_Specified;
  WideString      FRegistrationAddressCode;
  bool            FRegistrationAddressCode_Specified;
  Address*        FRegistrationAddressCompany;
  bool            FRegistrationAddressCompany_Specified;
  int             FSubjectType;
  void __fastcall SetBirthDate(int Index, TXSDateTime* _prop_val)
  {  FBirthDate = _prop_val; FBirthDate_Specified = true;  }
  bool __fastcall BirthDate_Specified(int Index)
  {  return FBirthDate_Specified;  } 
  void __fastcall SetDocument(int Index, CommonDocument* _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetInn(int Index, WideString _prop_val)
  {  FInn = _prop_val; FInn_Specified = true;  }
  bool __fastcall Inn_Specified(int Index)
  {  return FInn_Specified;  } 
  void __fastcall SetOgrn(int Index, WideString _prop_val)
  {  FOgrn = _prop_val; FOgrn_Specified = true;  }
  bool __fastcall Ogrn_Specified(int Index)
  {  return FOgrn_Specified;  } 
  void __fastcall SetOrganization(int Index, LegalEntity* _prop_val)
  {  FOrganization = _prop_val; FOrganization_Specified = true;  }
  bool __fastcall Organization_Specified(int Index)
  {  return FOrganization_Specified;  } 
  void __fastcall SetPerson(int Index, PersonName* _prop_val)
  {  FPerson = _prop_val; FPerson_Specified = true;  }
  bool __fastcall Person_Specified(int Index)
  {  return FPerson_Specified;  } 
  void __fastcall SetRegistrationAddressCode(int Index, WideString _prop_val)
  {  FRegistrationAddressCode = _prop_val; FRegistrationAddressCode_Specified = true;  }
  bool __fastcall RegistrationAddressCode_Specified(int Index)
  {  return FRegistrationAddressCode_Specified;  } 
  void __fastcall SetRegistrationAddressCompany(int Index, Address* _prop_val)
  {  FRegistrationAddressCompany = _prop_val; FRegistrationAddressCompany_Specified = true;  }
  bool __fastcall RegistrationAddressCompany_Specified(int Index)
  {  return FRegistrationAddressCompany_Specified;  } 

public:
  __fastcall ~Beneficiary();
__published:
  __property TXSDateTime*  BirthDate = { index=(IS_OPTN|IS_NLBL), read=FBirthDate, write=SetBirthDate, stored = BirthDate_Specified };
  __property CommonDocument*   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property WideString        Inn = { index=(IS_OPTN|IS_NLBL), read=FInn, write=SetInn, stored = Inn_Specified };
  __property WideString       Ogrn = { index=(IS_OPTN|IS_NLBL), read=FOgrn, write=SetOgrn, stored = Ogrn_Specified };
  __property LegalEntity* Organization = { index=(IS_OPTN|IS_NLBL), read=FOrganization, write=SetOrganization, stored = Organization_Specified };
  __property PersonName*     Person = { index=(IS_OPTN|IS_NLBL), read=FPerson, write=SetPerson, stored = Person_Specified };
  __property WideString RegistrationAddressCode = { index=(IS_OPTN|IS_NLBL), read=FRegistrationAddressCode, write=SetRegistrationAddressCode, stored = RegistrationAddressCode_Specified };
  __property Address*   RegistrationAddressCompany = { index=(IS_OPTN|IS_NLBL), read=FRegistrationAddressCompany, write=SetRegistrationAddressCompany, stored = RegistrationAddressCompany_Specified };
  __property int        SubjectType = { read=FSubjectType, write=FSubjectType };
};


typedef DynamicArray<Group*>      ArrayOfGroup;   /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : LeaseHolder, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class LeaseHolder : public TRemotable {
private:
  TXSDateTime*    FBirthDate;
  bool            FBirthDate_Specified;
  CommonDocument* FDocument;
  bool            FDocument_Specified;
  WideString      FInn;
  bool            FInn_Specified;
  WideString      FOgrn;
  bool            FOgrn_Specified;
  LegalEntity*    FOrganization;
  bool            FOrganization_Specified;
  PersonName*     FPerson;
  bool            FPerson_Specified;
  WideString      FRegistrationAddressCode;
  bool            FRegistrationAddressCode_Specified;
  Address*        FRegistrationAddressCompany;
  bool            FRegistrationAddressCompany_Specified;
  int             FSubjectType;
  void __fastcall SetBirthDate(int Index, TXSDateTime* _prop_val)
  {  FBirthDate = _prop_val; FBirthDate_Specified = true;  }
  bool __fastcall BirthDate_Specified(int Index)
  {  return FBirthDate_Specified;  } 
  void __fastcall SetDocument(int Index, CommonDocument* _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetInn(int Index, WideString _prop_val)
  {  FInn = _prop_val; FInn_Specified = true;  }
  bool __fastcall Inn_Specified(int Index)
  {  return FInn_Specified;  } 
  void __fastcall SetOgrn(int Index, WideString _prop_val)
  {  FOgrn = _prop_val; FOgrn_Specified = true;  }
  bool __fastcall Ogrn_Specified(int Index)
  {  return FOgrn_Specified;  } 
  void __fastcall SetOrganization(int Index, LegalEntity* _prop_val)
  {  FOrganization = _prop_val; FOrganization_Specified = true;  }
  bool __fastcall Organization_Specified(int Index)
  {  return FOrganization_Specified;  } 
  void __fastcall SetPerson(int Index, PersonName* _prop_val)
  {  FPerson = _prop_val; FPerson_Specified = true;  }
  bool __fastcall Person_Specified(int Index)
  {  return FPerson_Specified;  } 
  void __fastcall SetRegistrationAddressCode(int Index, WideString _prop_val)
  {  FRegistrationAddressCode = _prop_val; FRegistrationAddressCode_Specified = true;  }
  bool __fastcall RegistrationAddressCode_Specified(int Index)
  {  return FRegistrationAddressCode_Specified;  } 
  void __fastcall SetRegistrationAddressCompany(int Index, Address* _prop_val)
  {  FRegistrationAddressCompany = _prop_val; FRegistrationAddressCompany_Specified = true;  }
  bool __fastcall RegistrationAddressCompany_Specified(int Index)
  {  return FRegistrationAddressCompany_Specified;  } 

public:
  __fastcall ~LeaseHolder();
__published:
  __property TXSDateTime*  BirthDate = { index=(IS_OPTN|IS_NLBL), read=FBirthDate, write=SetBirthDate, stored = BirthDate_Specified };
  __property CommonDocument*   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property WideString        Inn = { index=(IS_OPTN|IS_NLBL), read=FInn, write=SetInn, stored = Inn_Specified };
  __property WideString       Ogrn = { index=(IS_OPTN|IS_NLBL), read=FOgrn, write=SetOgrn, stored = Ogrn_Specified };
  __property LegalEntity* Organization = { index=(IS_OPTN|IS_NLBL), read=FOrganization, write=SetOrganization, stored = Organization_Specified };
  __property PersonName*     Person = { index=(IS_OPTN|IS_NLBL), read=FPerson, write=SetPerson, stored = Person_Specified };
  __property WideString RegistrationAddressCode = { index=(IS_OPTN|IS_NLBL), read=FRegistrationAddressCode, write=SetRegistrationAddressCode, stored = RegistrationAddressCode_Specified };
  __property Address*   RegistrationAddressCompany = { index=(IS_OPTN|IS_NLBL), read=FRegistrationAddressCompany, write=SetRegistrationAddressCompany, stored = RegistrationAddressCompany_Specified };
  __property int        SubjectType = { read=FSubjectType, write=FSubjectType };
};


typedef DynamicArray<VehicleAdditionalInfo*> ArrayOfVehicleAdditionalInfo; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<VehicleProlongation*> ArrayOfVehicleProlongation; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : UnderwritingAdditionalInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UnderwritingAdditionalInfo : public TRemotable {
private:
  ApproveType     FApproveType;
  bool            FApproveType_Specified;
  Beneficiary*    FBeneficiary;
  bool            FBeneficiary_Specified;
  WideString      FCommentSeller;
  bool            FCommentSeller_Specified;
  ArrayOfGroup    FGroups;
  bool            FGroups_Specified;
  PersonName*     FInsurer;
  LeaseHolder*    FLeaseHolder;
  bool            FLeaseHolder_Specified;
  int             FLessorId;
  bool            FLessorId_Specified;
  TXSDateTime*    FProlongTillDate;
  bool            FProlongTillDate_Specified;
  guid            FQuotationId;
  ArrayOfVehicleAdditionalInfo FVehicleAdditionalInfos;
  bool            FVehicleAdditionalInfos_Specified;
  ArrayOfVehicleProlongation FVehicleProlongations;
  void __fastcall SetApproveType(int Index, ApproveType _prop_val)
  {  FApproveType = _prop_val; FApproveType_Specified = true;  }
  bool __fastcall ApproveType_Specified(int Index)
  {  return FApproveType_Specified;  } 
  void __fastcall SetBeneficiary(int Index, Beneficiary* _prop_val)
  {  FBeneficiary = _prop_val; FBeneficiary_Specified = true;  }
  bool __fastcall Beneficiary_Specified(int Index)
  {  return FBeneficiary_Specified;  } 
  void __fastcall SetCommentSeller(int Index, WideString _prop_val)
  {  FCommentSeller = _prop_val; FCommentSeller_Specified = true;  }
  bool __fastcall CommentSeller_Specified(int Index)
  {  return FCommentSeller_Specified;  } 
  void __fastcall SetGroups(int Index, ArrayOfGroup _prop_val)
  {  FGroups = _prop_val; FGroups_Specified = true;  }
  bool __fastcall Groups_Specified(int Index)
  {  return FGroups_Specified;  } 
  void __fastcall SetLeaseHolder(int Index, LeaseHolder* _prop_val)
  {  FLeaseHolder = _prop_val; FLeaseHolder_Specified = true;  }
  bool __fastcall LeaseHolder_Specified(int Index)
  {  return FLeaseHolder_Specified;  } 
  void __fastcall SetLessorId(int Index, int _prop_val)
  {  FLessorId = _prop_val; FLessorId_Specified = true;  }
  bool __fastcall LessorId_Specified(int Index)
  {  return FLessorId_Specified;  } 
  void __fastcall SetProlongTillDate(int Index, TXSDateTime* _prop_val)
  {  FProlongTillDate = _prop_val; FProlongTillDate_Specified = true;  }
  bool __fastcall ProlongTillDate_Specified(int Index)
  {  return FProlongTillDate_Specified;  } 
  void __fastcall SetVehicleAdditionalInfos(int Index, ArrayOfVehicleAdditionalInfo _prop_val)
  {  FVehicleAdditionalInfos = _prop_val; FVehicleAdditionalInfos_Specified = true;  }
  bool __fastcall VehicleAdditionalInfos_Specified(int Index)
  {  return FVehicleAdditionalInfos_Specified;  } 

public:
  __fastcall ~UnderwritingAdditionalInfo();
__published:
  __property ApproveType ApproveType = { index=(IS_OPTN), read=FApproveType, write=SetApproveType, stored = ApproveType_Specified };
  __property Beneficiary* Beneficiary = { index=(IS_OPTN|IS_NLBL), read=FBeneficiary, write=SetBeneficiary, stored = Beneficiary_Specified };
  __property WideString CommentSeller = { index=(IS_OPTN|IS_NLBL), read=FCommentSeller, write=SetCommentSeller, stored = CommentSeller_Specified };
  __property ArrayOfGroup     Groups = { index=(IS_OPTN|IS_NLBL), read=FGroups, write=SetGroups, stored = Groups_Specified };
  __property PersonName*    Insurer = { index=(IS_NLBL), read=FInsurer, write=FInsurer };
  __property LeaseHolder* LeaseHolder = { index=(IS_OPTN|IS_NLBL), read=FLeaseHolder, write=SetLeaseHolder, stored = LeaseHolder_Specified };
  __property int          LessorId = { index=(IS_OPTN|IS_NLBL), read=FLessorId, write=SetLessorId, stored = LessorId_Specified };
  __property TXSDateTime* ProlongTillDate = { index=(IS_OPTN|IS_NLBL), read=FProlongTillDate, write=SetProlongTillDate, stored = ProlongTillDate_Specified };
  __property guid       QuotationId = { read=FQuotationId, write=FQuotationId };
  __property ArrayOfVehicleAdditionalInfo VehicleAdditionalInfos = { index=(IS_OPTN|IS_NLBL), read=FVehicleAdditionalInfos, write=SetVehicleAdditionalInfos, stored = VehicleAdditionalInfos_Specified };
  __property ArrayOfVehicleProlongation VehicleProlongations = { index=(IS_NLBL), read=FVehicleProlongations, write=FVehicleProlongations };
};




// ************************************************************************ //
// XML       : CommonDocument, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CommonDocument : public Document {
private:
  WideString      FTypeId;
  bool            FTypeId_Specified;
  void __fastcall SetTypeId(int Index, WideString _prop_val)
  {  FTypeId = _prop_val; FTypeId_Specified = true;  }
  bool __fastcall TypeId_Specified(int Index)
  {  return FTypeId_Specified;  } 
__published:
  __property WideString     TypeId = { index=(IS_OPTN|IS_NLBL), read=FTypeId, write=SetTypeId, stored = TypeId_Specified };
};




// ************************************************************************ //
// XML       : Group, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Group : public TRemotable {
private:
  guid            FId;
  bool            FId_Specified;
  bool            FIsGroupDisabled;
  bool            FIsGroupDisabled_Specified;
  WideString      FName;
  bool            FName_Specified;
  int             FVehiclesCount;
  bool            FVehiclesCount_Specified;
  void __fastcall SetId(int Index, guid _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetIsGroupDisabled(int Index, bool _prop_val)
  {  FIsGroupDisabled = _prop_val; FIsGroupDisabled_Specified = true;  }
  bool __fastcall IsGroupDisabled_Specified(int Index)
  {  return FIsGroupDisabled_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetVehiclesCount(int Index, int _prop_val)
  {  FVehiclesCount = _prop_val; FVehiclesCount_Specified = true;  }
  bool __fastcall VehiclesCount_Specified(int Index)
  {  return FVehiclesCount_Specified;  } 
__published:
  __property guid               Id = { index=(IS_OPTN), read=FId, write=SetId, stored = Id_Specified };
  __property bool       IsGroupDisabled = { index=(IS_OPTN), read=FIsGroupDisabled, write=SetIsGroupDisabled, stored = IsGroupDisabled_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property int        VehiclesCount = { index=(IS_OPTN), read=FVehiclesCount, write=SetVehiclesCount, stored = VehiclesCount_Specified };
};




// ************************************************************************ //
// XML       : VehicleAdditionalInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleAdditionalInfo : public TRemotable {
private:
  WideString      FBrandNamePrint;
  bool            FBrandNamePrint_Specified;
  guid            FGroupId;
  bool            FGroupId_Specified;
  bool            FIsNeedAddAgreement5;
  bool            FIsNeedAddAgreement5_Specified;
  WideString      FModelNamePrint;
  bool            FModelNamePrint_Specified;
  WideString      FVehicleId;
  void __fastcall SetBrandNamePrint(int Index, WideString _prop_val)
  {  FBrandNamePrint = _prop_val; FBrandNamePrint_Specified = true;  }
  bool __fastcall BrandNamePrint_Specified(int Index)
  {  return FBrandNamePrint_Specified;  } 
  void __fastcall SetGroupId(int Index, guid _prop_val)
  {  FGroupId = _prop_val; FGroupId_Specified = true;  }
  bool __fastcall GroupId_Specified(int Index)
  {  return FGroupId_Specified;  } 
  void __fastcall SetIsNeedAddAgreement5(int Index, bool _prop_val)
  {  FIsNeedAddAgreement5 = _prop_val; FIsNeedAddAgreement5_Specified = true;  }
  bool __fastcall IsNeedAddAgreement5_Specified(int Index)
  {  return FIsNeedAddAgreement5_Specified;  } 
  void __fastcall SetModelNamePrint(int Index, WideString _prop_val)
  {  FModelNamePrint = _prop_val; FModelNamePrint_Specified = true;  }
  bool __fastcall ModelNamePrint_Specified(int Index)
  {  return FModelNamePrint_Specified;  } 
__published:
  __property WideString BrandNamePrint = { index=(IS_OPTN|IS_NLBL), read=FBrandNamePrint, write=SetBrandNamePrint, stored = BrandNamePrint_Specified };
  __property guid          GroupId = { index=(IS_OPTN|IS_NLBL), read=FGroupId, write=SetGroupId, stored = GroupId_Specified };
  __property bool       IsNeedAddAgreement5 = { index=(IS_OPTN|IS_NLBL), read=FIsNeedAddAgreement5, write=SetIsNeedAddAgreement5, stored = IsNeedAddAgreement5_Specified };
  __property WideString ModelNamePrint = { index=(IS_OPTN|IS_NLBL), read=FModelNamePrint, write=SetModelNamePrint, stored = ModelNamePrint_Specified };
  __property WideString  VehicleId = { index=(IS_NLBL), read=FVehicleId, write=FVehicleId };
};




// ************************************************************************ //
// XML       : VehicleProlongation, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleProlongation : public TRemotable {
private:
  bool            FIsPrefProlongation;
  WideString      FVehicleId;
__published:
  __property bool       IsPrefProlongation = { read=FIsPrefProlongation, write=FIsPrefProlongation };
  __property WideString  VehicleId = { index=(IS_NLBL), read=FVehicleId, write=FVehicleId };
};


typedef DynamicArray<VehicleStateInfo*> ArrayOfVehicleStateInfo; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : QuotationStateInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class QuotationStateInfo : public TRemotable {
private:
  bool            FIsChanged;
  bool            FIsChanged_Specified;
  Quotation*      FQuotation;
  bool            FQuotation_Specified;
  guid            FQuotationId;
  bool            FQuotationId_Specified;
  ContractStatusNames FState;
  bool            FState_Specified;
  ContractStatusNames FStatus;
  bool            FStatus_Specified;
  ArrayOfVehicleStateInfo FVehicleStateInfos;
  bool            FVehicleStateInfos_Specified;
  void __fastcall SetIsChanged(int Index, bool _prop_val)
  {  FIsChanged = _prop_val; FIsChanged_Specified = true;  }
  bool __fastcall IsChanged_Specified(int Index)
  {  return FIsChanged_Specified;  } 
  void __fastcall SetQuotation(int Index, Quotation* _prop_val)
  {  FQuotation = _prop_val; FQuotation_Specified = true;  }
  bool __fastcall Quotation_Specified(int Index)
  {  return FQuotation_Specified;  } 
  void __fastcall SetQuotationId(int Index, guid _prop_val)
  {  FQuotationId = _prop_val; FQuotationId_Specified = true;  }
  bool __fastcall QuotationId_Specified(int Index)
  {  return FQuotationId_Specified;  } 
  void __fastcall SetState(int Index, ContractStatusNames _prop_val)
  {  FState = _prop_val; FState_Specified = true;  }
  bool __fastcall State_Specified(int Index)
  {  return FState_Specified;  } 
  void __fastcall SetStatus(int Index, ContractStatusNames _prop_val)
  {  FStatus = _prop_val; FStatus_Specified = true;  }
  bool __fastcall Status_Specified(int Index)
  {  return FStatus_Specified;  } 
  void __fastcall SetVehicleStateInfos(int Index, ArrayOfVehicleStateInfo _prop_val)
  {  FVehicleStateInfos = _prop_val; FVehicleStateInfos_Specified = true;  }
  bool __fastcall VehicleStateInfos_Specified(int Index)
  {  return FVehicleStateInfos_Specified;  } 

public:
  __fastcall ~QuotationStateInfo();
__published:
  __property bool        IsChanged = { index=(IS_OPTN), read=FIsChanged, write=SetIsChanged, stored = IsChanged_Specified };
  __property Quotation*  Quotation = { index=(IS_OPTN|IS_NLBL), read=FQuotation, write=SetQuotation, stored = Quotation_Specified };
  __property guid       QuotationId = { index=(IS_OPTN), read=FQuotationId, write=SetQuotationId, stored = QuotationId_Specified };
  __property ContractStatusNames      State = { index=(IS_OPTN), read=FState, write=SetState, stored = State_Specified };
  __property ContractStatusNames     Status = { index=(IS_OPTN), read=FStatus, write=SetStatus, stored = Status_Specified };
  __property ArrayOfVehicleStateInfo VehicleStateInfos = { index=(IS_OPTN|IS_NLBL), read=FVehicleStateInfos, write=SetVehicleStateInfos, stored = VehicleStateInfos_Specified };
};


typedef DynamicArray<VehicleResult*> ArrayOfVehicleResult; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : Quotation, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Quotation : public TRemotable {
private:
  Beneficiary*    FBeneficiary;
  bool            FBeneficiary_Specified;
  guid            FId;
  bool            FId_Specified;
  Insurant*       FInsurant;
  bool            FInsurant_Specified;
  int             FPolicyPaymentsCount;
  bool            FPolicyPaymentsCount_Specified;
  ArrayOfVehicleResult FVehicles;
  bool            FVehicles_Specified;
  void __fastcall SetBeneficiary(int Index, Beneficiary* _prop_val)
  {  FBeneficiary = _prop_val; FBeneficiary_Specified = true;  }
  bool __fastcall Beneficiary_Specified(int Index)
  {  return FBeneficiary_Specified;  } 
  void __fastcall SetId(int Index, guid _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetInsurant(int Index, Insurant* _prop_val)
  {  FInsurant = _prop_val; FInsurant_Specified = true;  }
  bool __fastcall Insurant_Specified(int Index)
  {  return FInsurant_Specified;  } 
  void __fastcall SetPolicyPaymentsCount(int Index, int _prop_val)
  {  FPolicyPaymentsCount = _prop_val; FPolicyPaymentsCount_Specified = true;  }
  bool __fastcall PolicyPaymentsCount_Specified(int Index)
  {  return FPolicyPaymentsCount_Specified;  } 
  void __fastcall SetVehicles(int Index, ArrayOfVehicleResult _prop_val)
  {  FVehicles = _prop_val; FVehicles_Specified = true;  }
  bool __fastcall Vehicles_Specified(int Index)
  {  return FVehicles_Specified;  } 

public:
  __fastcall ~Quotation();
__published:
  __property Beneficiary* Beneficiary = { index=(IS_OPTN|IS_NLBL), read=FBeneficiary, write=SetBeneficiary, stored = Beneficiary_Specified };
  __property guid               Id = { index=(IS_OPTN), read=FId, write=SetId, stored = Id_Specified };
  __property Insurant*    Insurant = { index=(IS_OPTN|IS_NLBL), read=FInsurant, write=SetInsurant, stored = Insurant_Specified };
  __property int        PolicyPaymentsCount = { index=(IS_OPTN), read=FPolicyPaymentsCount, write=SetPolicyPaymentsCount, stored = PolicyPaymentsCount_Specified };
  __property ArrayOfVehicleResult   Vehicles = { index=(IS_OPTN|IS_NLBL), read=FVehicles, write=SetVehicles, stored = Vehicles_Specified };
};




// ************************************************************************ //
// XML       : VehicleResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleResult : public VehicleCalculationResult {
private:
  int             FAdmittedLimitId;
  bool            FAdmittedLimitId_Specified;
  ArrayOfstring   FAlarmIds;
  bool            FAlarmIds_Specified;
  int             FAllowWeight;
  bool            FAllowWeight_Specified;
  TXSDecimal*     FCost;
  bool            FCost_Specified;
  Franchise*      FFranchise;
  bool            FFranchise_Specified;
  guid            FGroupId;
  bool            FGroupId_Specified;
  WideString      FGroupName;
  bool            FGroupName_Specified;
  bool            FIsNeedAddAgreement5;
  bool            FIsNeedAddAgreement5_Specified;
  TXSDecimal*     FLiability;
  bool            FLiability_Specified;
  WideString      FPaymentMethodId;
  bool            FPaymentMethodId_Specified;
  int             FSeatCount;
  bool            FSeatCount_Specified;
  WideString      FUsagePurposeId;
  bool            FUsagePurposeId_Specified;
  void __fastcall SetAdmittedLimitId(int Index, int _prop_val)
  {  FAdmittedLimitId = _prop_val; FAdmittedLimitId_Specified = true;  }
  bool __fastcall AdmittedLimitId_Specified(int Index)
  {  return FAdmittedLimitId_Specified;  } 
  void __fastcall SetAlarmIds(int Index, ArrayOfstring _prop_val)
  {  FAlarmIds = _prop_val; FAlarmIds_Specified = true;  }
  bool __fastcall AlarmIds_Specified(int Index)
  {  return FAlarmIds_Specified;  } 
  void __fastcall SetAllowWeight(int Index, int _prop_val)
  {  FAllowWeight = _prop_val; FAllowWeight_Specified = true;  }
  bool __fastcall AllowWeight_Specified(int Index)
  {  return FAllowWeight_Specified;  } 
  void __fastcall SetCost(int Index, TXSDecimal* _prop_val)
  {  FCost = _prop_val; FCost_Specified = true;  }
  bool __fastcall Cost_Specified(int Index)
  {  return FCost_Specified;  } 
  void __fastcall SetFranchise(int Index, Franchise* _prop_val)
  {  FFranchise = _prop_val; FFranchise_Specified = true;  }
  bool __fastcall Franchise_Specified(int Index)
  {  return FFranchise_Specified;  } 
  void __fastcall SetGroupId(int Index, guid _prop_val)
  {  FGroupId = _prop_val; FGroupId_Specified = true;  }
  bool __fastcall GroupId_Specified(int Index)
  {  return FGroupId_Specified;  } 
  void __fastcall SetGroupName(int Index, WideString _prop_val)
  {  FGroupName = _prop_val; FGroupName_Specified = true;  }
  bool __fastcall GroupName_Specified(int Index)
  {  return FGroupName_Specified;  } 
  void __fastcall SetIsNeedAddAgreement5(int Index, bool _prop_val)
  {  FIsNeedAddAgreement5 = _prop_val; FIsNeedAddAgreement5_Specified = true;  }
  bool __fastcall IsNeedAddAgreement5_Specified(int Index)
  {  return FIsNeedAddAgreement5_Specified;  } 
  void __fastcall SetLiability(int Index, TXSDecimal* _prop_val)
  {  FLiability = _prop_val; FLiability_Specified = true;  }
  bool __fastcall Liability_Specified(int Index)
  {  return FLiability_Specified;  } 
  void __fastcall SetPaymentMethodId(int Index, WideString _prop_val)
  {  FPaymentMethodId = _prop_val; FPaymentMethodId_Specified = true;  }
  bool __fastcall PaymentMethodId_Specified(int Index)
  {  return FPaymentMethodId_Specified;  } 
  void __fastcall SetSeatCount(int Index, int _prop_val)
  {  FSeatCount = _prop_val; FSeatCount_Specified = true;  }
  bool __fastcall SeatCount_Specified(int Index)
  {  return FSeatCount_Specified;  } 
  void __fastcall SetUsagePurposeId(int Index, WideString _prop_val)
  {  FUsagePurposeId = _prop_val; FUsagePurposeId_Specified = true;  }
  bool __fastcall UsagePurposeId_Specified(int Index)
  {  return FUsagePurposeId_Specified;  } 

public:
  __fastcall ~VehicleResult();
__published:
  __property int        AdmittedLimitId = { index=(IS_OPTN), read=FAdmittedLimitId, write=SetAdmittedLimitId, stored = AdmittedLimitId_Specified };
  __property ArrayOfstring   AlarmIds = { index=(IS_OPTN|IS_NLBL), read=FAlarmIds, write=SetAlarmIds, stored = AlarmIds_Specified };
  __property int        AllowWeight = { index=(IS_OPTN|IS_NLBL), read=FAllowWeight, write=SetAllowWeight, stored = AllowWeight_Specified };
  __property TXSDecimal*       Cost = { index=(IS_OPTN), read=FCost, write=SetCost, stored = Cost_Specified };
  __property Franchise*  Franchise = { index=(IS_OPTN|IS_NLBL), read=FFranchise, write=SetFranchise, stored = Franchise_Specified };
  __property guid          GroupId = { index=(IS_OPTN|IS_NLBL), read=FGroupId, write=SetGroupId, stored = GroupId_Specified };
  __property WideString  GroupName = { index=(IS_OPTN|IS_NLBL), read=FGroupName, write=SetGroupName, stored = GroupName_Specified };
  __property bool       IsNeedAddAgreement5 = { index=(IS_OPTN), read=FIsNeedAddAgreement5, write=SetIsNeedAddAgreement5, stored = IsNeedAddAgreement5_Specified };
  __property TXSDecimal*  Liability = { index=(IS_OPTN), read=FLiability, write=SetLiability, stored = Liability_Specified };
  __property WideString PaymentMethodId = { index=(IS_OPTN|IS_NLBL), read=FPaymentMethodId, write=SetPaymentMethodId, stored = PaymentMethodId_Specified };
  __property int         SeatCount = { index=(IS_OPTN|IS_NLBL), read=FSeatCount, write=SetSeatCount, stored = SeatCount_Specified };
  __property WideString UsagePurposeId = { index=(IS_OPTN|IS_NLBL), read=FUsagePurposeId, write=SetUsagePurposeId, stored = UsagePurposeId_Specified };
};


typedef DynamicArray<VehicleComment*> ArrayOfVehicleComment; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : VehicleStateInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleStateInfo : public TRemotable {
private:
  ArrayOfVehicleComment FComments;
  bool            FComments_Specified;
  guid            FQuotationId;
  bool            FQuotationId_Specified;
  ContractStatusNames FState;
  bool            FState_Specified;
  ContractStatusNames FStatus;
  bool            FStatus_Specified;
  WideString      FVehicleNumber;
  bool            FVehicleNumber_Specified;
  void __fastcall SetComments(int Index, ArrayOfVehicleComment _prop_val)
  {  FComments = _prop_val; FComments_Specified = true;  }
  bool __fastcall Comments_Specified(int Index)
  {  return FComments_Specified;  } 
  void __fastcall SetQuotationId(int Index, guid _prop_val)
  {  FQuotationId = _prop_val; FQuotationId_Specified = true;  }
  bool __fastcall QuotationId_Specified(int Index)
  {  return FQuotationId_Specified;  } 
  void __fastcall SetState(int Index, ContractStatusNames _prop_val)
  {  FState = _prop_val; FState_Specified = true;  }
  bool __fastcall State_Specified(int Index)
  {  return FState_Specified;  } 
  void __fastcall SetStatus(int Index, ContractStatusNames _prop_val)
  {  FStatus = _prop_val; FStatus_Specified = true;  }
  bool __fastcall Status_Specified(int Index)
  {  return FStatus_Specified;  } 
  void __fastcall SetVehicleNumber(int Index, WideString _prop_val)
  {  FVehicleNumber = _prop_val; FVehicleNumber_Specified = true;  }
  bool __fastcall VehicleNumber_Specified(int Index)
  {  return FVehicleNumber_Specified;  } 

public:
  __fastcall ~VehicleStateInfo();
__published:
  __property ArrayOfVehicleComment   Comments = { index=(IS_OPTN|IS_NLBL), read=FComments, write=SetComments, stored = Comments_Specified };
  __property guid       QuotationId = { index=(IS_OPTN), read=FQuotationId, write=SetQuotationId, stored = QuotationId_Specified };
  __property ContractStatusNames      State = { index=(IS_OPTN), read=FState, write=SetState, stored = State_Specified };
  __property ContractStatusNames     Status = { index=(IS_OPTN), read=FStatus, write=SetStatus, stored = Status_Specified };
  __property WideString VehicleNumber = { index=(IS_OPTN|IS_NLBL), read=FVehicleNumber, write=SetVehicleNumber, stored = VehicleNumber_Specified };
};




// ************************************************************************ //
// XML       : VehicleComment, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleComment : public TRemotable {
private:
  WideString      FComment;
  bool            FComment_Specified;
  WideString      FCommentatorGroupName;
  bool            FCommentatorGroupName_Specified;
  WideString      FCommentatorName;
  bool            FCommentatorName_Specified;
  WideString      FEmail;
  bool            FEmail_Specified;
  GroupNames      FGroup;
  bool            FGroup_Specified;
  void __fastcall SetComment(int Index, WideString _prop_val)
  {  FComment = _prop_val; FComment_Specified = true;  }
  bool __fastcall Comment_Specified(int Index)
  {  return FComment_Specified;  } 
  void __fastcall SetCommentatorGroupName(int Index, WideString _prop_val)
  {  FCommentatorGroupName = _prop_val; FCommentatorGroupName_Specified = true;  }
  bool __fastcall CommentatorGroupName_Specified(int Index)
  {  return FCommentatorGroupName_Specified;  } 
  void __fastcall SetCommentatorName(int Index, WideString _prop_val)
  {  FCommentatorName = _prop_val; FCommentatorName_Specified = true;  }
  bool __fastcall CommentatorName_Specified(int Index)
  {  return FCommentatorName_Specified;  } 
  void __fastcall SetEmail(int Index, WideString _prop_val)
  {  FEmail = _prop_val; FEmail_Specified = true;  }
  bool __fastcall Email_Specified(int Index)
  {  return FEmail_Specified;  } 
  void __fastcall SetGroup(int Index, GroupNames _prop_val)
  {  FGroup = _prop_val; FGroup_Specified = true;  }
  bool __fastcall Group_Specified(int Index)
  {  return FGroup_Specified;  } 
__published:
  __property WideString    Comment = { index=(IS_OPTN|IS_NLBL), read=FComment, write=SetComment, stored = Comment_Specified };
  __property WideString CommentatorGroupName = { index=(IS_OPTN|IS_NLBL), read=FCommentatorGroupName, write=SetCommentatorGroupName, stored = CommentatorGroupName_Specified };
  __property WideString CommentatorName = { index=(IS_OPTN|IS_NLBL), read=FCommentatorName, write=SetCommentatorName, stored = CommentatorName_Specified };
  __property WideString      Email = { index=(IS_OPTN|IS_NLBL), read=FEmail, write=SetEmail, stored = Email_Specified };
  __property GroupNames      Group = { index=(IS_OPTN), read=FGroup, write=SetGroup, stored = Group_Specified };
};


typedef DynamicArray<CalculateVzdVehicleRequest*> ArrayOfCalculateVzdVehicleRequest; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : CalculateVzdRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdRequest : public TRemotable {
private:
  TXSDateTime*    FCalculationDate;
  int             FCascoTerritoryId;
  guid            FCorellationId;
  bool            FCorellationId_Specified;
  int             FPolicyPartnerAutoDealerId;
  bool            FPolicyPartnerAutoDealerId_Specified;
  WideString      FPolicyPartnerBankCode;
  bool            FPolicyPartnerBankCode_Specified;
  int             FPolicyPartnerLeasingCompanyId;
  bool            FPolicyPartnerLeasingCompanyId_Specified;
  int             FPolicyPartnerOtherPartnerId;
  bool            FPolicyPartnerOtherPartnerId_Specified;
  int             FProductId;
  int             FSaleChannelType2008Id;
  ArrayOfCalculateVzdVehicleRequest FVehicles;
  void __fastcall SetCorellationId(int Index, guid _prop_val)
  {  FCorellationId = _prop_val; FCorellationId_Specified = true;  }
  bool __fastcall CorellationId_Specified(int Index)
  {  return FCorellationId_Specified;  } 
  void __fastcall SetPolicyPartnerAutoDealerId(int Index, int _prop_val)
  {  FPolicyPartnerAutoDealerId = _prop_val; FPolicyPartnerAutoDealerId_Specified = true;  }
  bool __fastcall PolicyPartnerAutoDealerId_Specified(int Index)
  {  return FPolicyPartnerAutoDealerId_Specified;  } 
  void __fastcall SetPolicyPartnerBankCode(int Index, WideString _prop_val)
  {  FPolicyPartnerBankCode = _prop_val; FPolicyPartnerBankCode_Specified = true;  }
  bool __fastcall PolicyPartnerBankCode_Specified(int Index)
  {  return FPolicyPartnerBankCode_Specified;  } 
  void __fastcall SetPolicyPartnerLeasingCompanyId(int Index, int _prop_val)
  {  FPolicyPartnerLeasingCompanyId = _prop_val; FPolicyPartnerLeasingCompanyId_Specified = true;  }
  bool __fastcall PolicyPartnerLeasingCompanyId_Specified(int Index)
  {  return FPolicyPartnerLeasingCompanyId_Specified;  } 
  void __fastcall SetPolicyPartnerOtherPartnerId(int Index, int _prop_val)
  {  FPolicyPartnerOtherPartnerId = _prop_val; FPolicyPartnerOtherPartnerId_Specified = true;  }
  bool __fastcall PolicyPartnerOtherPartnerId_Specified(int Index)
  {  return FPolicyPartnerOtherPartnerId_Specified;  } 

public:
  __fastcall ~CalculateVzdRequest();
__published:
  __property TXSDateTime* CalculationDate = { read=FCalculationDate, write=FCalculationDate };
  __property int        CascoTerritoryId = { read=FCascoTerritoryId, write=FCascoTerritoryId };
  __property guid       CorellationId = { index=(IS_OPTN|IS_NLBL), read=FCorellationId, write=SetCorellationId, stored = CorellationId_Specified };
  __property int        PolicyPartnerAutoDealerId = { index=(IS_OPTN|IS_NLBL), read=FPolicyPartnerAutoDealerId, write=SetPolicyPartnerAutoDealerId, stored = PolicyPartnerAutoDealerId_Specified };
  __property WideString PolicyPartnerBankCode = { index=(IS_OPTN|IS_NLBL), read=FPolicyPartnerBankCode, write=SetPolicyPartnerBankCode, stored = PolicyPartnerBankCode_Specified };
  __property int        PolicyPartnerLeasingCompanyId = { index=(IS_OPTN|IS_NLBL), read=FPolicyPartnerLeasingCompanyId, write=SetPolicyPartnerLeasingCompanyId, stored = PolicyPartnerLeasingCompanyId_Specified };
  __property int        PolicyPartnerOtherPartnerId = { index=(IS_OPTN|IS_NLBL), read=FPolicyPartnerOtherPartnerId, write=SetPolicyPartnerOtherPartnerId, stored = PolicyPartnerOtherPartnerId_Specified };
  __property int         ProductId = { read=FProductId, write=FProductId };
  __property int        SaleChannelType2008Id = { read=FSaleChannelType2008Id, write=FSaleChannelType2008Id };
  __property ArrayOfCalculateVzdVehicleRequest   Vehicles = { index=(IS_NLBL), read=FVehicles, write=FVehicles };
};




// ************************************************************************ //
// XML       : CalculateVzdVehicleRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdVehicleRequest : public TRemotable {
private:
  TXSDecimal*     FChanchedVZD;
  bool            FChanchedVZD_Specified;
  TXSDecimal*     FKc;
  bool            FKc_Specified;
  WideString      FVehicleId;
  bool            FVehicleId_Specified;
  void __fastcall SetChanchedVZD(int Index, TXSDecimal* _prop_val)
  {  FChanchedVZD = _prop_val; FChanchedVZD_Specified = true;  }
  bool __fastcall ChanchedVZD_Specified(int Index)
  {  return FChanchedVZD_Specified;  } 
  void __fastcall SetKc(int Index, TXSDecimal* _prop_val)
  {  FKc = _prop_val; FKc_Specified = true;  }
  bool __fastcall Kc_Specified(int Index)
  {  return FKc_Specified;  } 
  void __fastcall SetVehicleId(int Index, WideString _prop_val)
  {  FVehicleId = _prop_val; FVehicleId_Specified = true;  }
  bool __fastcall VehicleId_Specified(int Index)
  {  return FVehicleId_Specified;  } 

public:
  __fastcall ~CalculateVzdVehicleRequest();
__published:
  __property TXSDecimal* ChanchedVZD = { index=(IS_OPTN|IS_NLBL), read=FChanchedVZD, write=SetChanchedVZD, stored = ChanchedVZD_Specified };
  __property TXSDecimal*         Kc = { index=(IS_OPTN|IS_NLBL), read=FKc, write=SetKc, stored = Kc_Specified };
  __property WideString  VehicleId = { index=(IS_OPTN|IS_NLBL), read=FVehicleId, write=SetVehicleId, stored = VehicleId_Specified };
};


typedef DynamicArray<CalculateVzdVehicleResponse*> ArrayOfCalculateVzdVehicleResponse; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : CalculateVzdResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdResult : public TRemotable {
private:
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  ArrayOfCalculateVzdVehicleResponse FVehicles;
  bool            FVehicles_Specified;
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetVehicles(int Index, ArrayOfCalculateVzdVehicleResponse _prop_val)
  {  FVehicles = _prop_val; FVehicles_Specified = true;  }
  bool __fastcall Vehicles_Specified(int Index)
  {  return FVehicles_Specified;  } 

public:
  __fastcall ~CalculateVzdResult();
__published:
  __property guid       CalculationId = { index=(IS_OPTN), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property ArrayOfCalculateVzdVehicleResponse   Vehicles = { index=(IS_OPTN|IS_NLBL), read=FVehicles, write=SetVehicles, stored = Vehicles_Specified };
};




// ************************************************************************ //
// XML       : CalculateVzdVehicleResponse, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdVehicleResponse : public TRemotable {
private:
  TXSDecimal*     FChanchedVZD;
  bool            FChanchedVZD_Specified;
  TXSDecimal*     FKaskoKC;
  bool            FKaskoKC_Specified;
  TXSDecimal*     FPlanVZD;
  bool            FPlanVZD_Specified;
  WideString      FVehicleId;
  bool            FVehicleId_Specified;
  void __fastcall SetChanchedVZD(int Index, TXSDecimal* _prop_val)
  {  FChanchedVZD = _prop_val; FChanchedVZD_Specified = true;  }
  bool __fastcall ChanchedVZD_Specified(int Index)
  {  return FChanchedVZD_Specified;  } 
  void __fastcall SetKaskoKC(int Index, TXSDecimal* _prop_val)
  {  FKaskoKC = _prop_val; FKaskoKC_Specified = true;  }
  bool __fastcall KaskoKC_Specified(int Index)
  {  return FKaskoKC_Specified;  } 
  void __fastcall SetPlanVZD(int Index, TXSDecimal* _prop_val)
  {  FPlanVZD = _prop_val; FPlanVZD_Specified = true;  }
  bool __fastcall PlanVZD_Specified(int Index)
  {  return FPlanVZD_Specified;  } 
  void __fastcall SetVehicleId(int Index, WideString _prop_val)
  {  FVehicleId = _prop_val; FVehicleId_Specified = true;  }
  bool __fastcall VehicleId_Specified(int Index)
  {  return FVehicleId_Specified;  } 

public:
  __fastcall ~CalculateVzdVehicleResponse();
__published:
  __property TXSDecimal* ChanchedVZD = { index=(IS_OPTN), read=FChanchedVZD, write=SetChanchedVZD, stored = ChanchedVZD_Specified };
  __property TXSDecimal*    KaskoKC = { index=(IS_OPTN), read=FKaskoKC, write=SetKaskoKC, stored = KaskoKC_Specified };
  __property TXSDecimal*    PlanVZD = { index=(IS_OPTN), read=FPlanVZD, write=SetPlanVZD, stored = PlanVZD_Specified };
  __property WideString  VehicleId = { index=(IS_OPTN|IS_NLBL), read=FVehicleId, write=SetVehicleId, stored = VehicleId_Specified };
};


typedef DynamicArray<AddEquipmentInfo*> ArrayOfAddEquipmentInfo; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : PrintULAddAgreementRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintULAddAgreementRequest : public KaskoPrintRequestDto {
private:
  ArrayOfAddEquipmentInfo FAddEquipmentInfo;
  ULAddAgreementType FAgreementType;
  Signer*         FInsurantRepresentative;
  bool            FInsurantRepresentative_Specified;
  InsurerProxyDto* FInsurerProxy;
  bool            FInsurerProxy_Specified;
  Signer*         FInsurerRepresentative;
  bool            FInsurerRepresentative_Specified;
  WideString      FIssueDate;
  ArrayOfstring   FVehicleIds;
  bool            FVehicleIds_Specified;
  void __fastcall SetInsurantRepresentative(int Index, Signer* _prop_val)
  {  FInsurantRepresentative = _prop_val; FInsurantRepresentative_Specified = true;  }
  bool __fastcall InsurantRepresentative_Specified(int Index)
  {  return FInsurantRepresentative_Specified;  } 
  void __fastcall SetInsurerProxy(int Index, InsurerProxyDto* _prop_val)
  {  FInsurerProxy = _prop_val; FInsurerProxy_Specified = true;  }
  bool __fastcall InsurerProxy_Specified(int Index)
  {  return FInsurerProxy_Specified;  } 
  void __fastcall SetInsurerRepresentative(int Index, Signer* _prop_val)
  {  FInsurerRepresentative = _prop_val; FInsurerRepresentative_Specified = true;  }
  bool __fastcall InsurerRepresentative_Specified(int Index)
  {  return FInsurerRepresentative_Specified;  } 
  void __fastcall SetVehicleIds(int Index, ArrayOfstring _prop_val)
  {  FVehicleIds = _prop_val; FVehicleIds_Specified = true;  }
  bool __fastcall VehicleIds_Specified(int Index)
  {  return FVehicleIds_Specified;  } 

public:
  __fastcall ~PrintULAddAgreementRequest();
__published:
  __property ArrayOfAddEquipmentInfo AddEquipmentInfo = { index=(IS_NLBL), read=FAddEquipmentInfo, write=FAddEquipmentInfo };
  __property ULAddAgreementType AgreementType = { read=FAgreementType, write=FAgreementType };
  __property Signer*    InsurantRepresentative = { index=(IS_OPTN|IS_NLBL), read=FInsurantRepresentative, write=SetInsurantRepresentative, stored = InsurantRepresentative_Specified };
  __property InsurerProxyDto* InsurerProxy = { index=(IS_OPTN|IS_NLBL), read=FInsurerProxy, write=SetInsurerProxy, stored = InsurerProxy_Specified };
  __property Signer*    InsurerRepresentative = { index=(IS_OPTN|IS_NLBL), read=FInsurerRepresentative, write=SetInsurerRepresentative, stored = InsurerRepresentative_Specified };
  __property WideString  IssueDate = { index=(IS_NLBL), read=FIssueDate, write=FIssueDate };
  __property ArrayOfstring VehicleIds = { index=(IS_OPTN|IS_NLBL), read=FVehicleIds, write=SetVehicleIds, stored = VehicleIds_Specified };
};




// ************************************************************************ //
// XML       : InsurerProxyDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurerProxyDto : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  WideString      FLegalEntityName;
  bool            FLegalEntityName_Specified;
  WideString      FName;
  bool            FName_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  WideString      FPost;
  bool            FPost_Specified;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetLegalEntityName(int Index, WideString _prop_val)
  {  FLegalEntityName = _prop_val; FLegalEntityName_Specified = true;  }
  bool __fastcall LegalEntityName_Specified(int Index)
  {  return FLegalEntityName_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetPost(int Index, WideString _prop_val)
  {  FPost = _prop_val; FPost_Specified = true;  }
  bool __fastcall Post_Specified(int Index)
  {  return FPost_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString LegalEntityName = { index=(IS_OPTN|IS_NLBL), read=FLegalEntityName, write=SetLegalEntityName, stored = LegalEntityName_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property WideString       Post = { index=(IS_OPTN|IS_NLBL), read=FPost, write=SetPost, stored = Post_Specified };
};




// ************************************************************************ //
// XML       : AddEquipmentInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddEquipmentInfo : public TRemotable {
private:
  WideString      FAddEquipmentId;
  WideString      FDescription;
  bool            FDescription_Specified;
  WideString      FId;
  void __fastcall SetDescription(int Index, WideString _prop_val)
  {  FDescription = _prop_val; FDescription_Specified = true;  }
  bool __fastcall Description_Specified(int Index)
  {  return FDescription_Specified;  } 
__published:
  __property WideString AddEquipmentId = { index=(IS_NLBL), read=FAddEquipmentId, write=FAddEquipmentId };
  __property WideString Description = { index=(IS_OPTN|IS_NLBL), read=FDescription, write=SetDescription, stored = Description_Specified };
  __property WideString         Id = { index=(IS_NLBL), read=FId, write=FId };
};


typedef DynamicArray<AddEquipmentByVehicle*> ArrayOfAddEquipmentByVehicle; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print"[GblCplx] */
typedef DynamicArray<BLInsPeriod*> ArrayOfBLInsPeriod; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print"[GblCplx] */


// ************************************************************************ //
// XML       : PrintULBLAddAgreementRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintULBLAddAgreementRequest : public PrintULAddAgreementRequest {
private:
  ArrayOfAddEquipmentByVehicle FAddEquipmentByVehicle;
  bool            FAddEquipmentByVehicle_Specified;
  ArrayOfBLInsPeriod FPeriodList;
  bool            FPeriodList_Specified;
  void __fastcall SetAddEquipmentByVehicle(int Index, ArrayOfAddEquipmentByVehicle _prop_val)
  {  FAddEquipmentByVehicle = _prop_val; FAddEquipmentByVehicle_Specified = true;  }
  bool __fastcall AddEquipmentByVehicle_Specified(int Index)
  {  return FAddEquipmentByVehicle_Specified;  } 
  void __fastcall SetPeriodList(int Index, ArrayOfBLInsPeriod _prop_val)
  {  FPeriodList = _prop_val; FPeriodList_Specified = true;  }
  bool __fastcall PeriodList_Specified(int Index)
  {  return FPeriodList_Specified;  } 

public:
  __fastcall ~PrintULBLAddAgreementRequest();
__published:
  __property ArrayOfAddEquipmentByVehicle AddEquipmentByVehicle = { index=(IS_OPTN|IS_NLBL), read=FAddEquipmentByVehicle, write=SetAddEquipmentByVehicle, stored = AddEquipmentByVehicle_Specified };
  __property ArrayOfBLInsPeriod PeriodList = { index=(IS_OPTN|IS_NLBL), read=FPeriodList, write=SetPeriodList, stored = PeriodList_Specified };
};




// ************************************************************************ //
// XML       : EarlyApproveInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class EarlyApproveInfo : public TRemotable {
private:
  guid            FQuotationId;
  ArrayOfstring   FVehicleNumbers;
__published:
  __property guid       QuotationId = { read=FQuotationId, write=FQuotationId };
  __property ArrayOfstring VehicleNumbers = { index=(IS_NLBL), read=FVehicleNumbers, write=FVehicleNumbers };
};




// ************************************************************************ //
// XML       : EarlyApproveResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class EarlyApproveResult : public TRemotable {
private:
  ArrayOfstring   FErrorsVehicleNumbers;
  bool            FErrorsVehicleNumbers_Specified;
  guid            FQuotationId;
  bool            FQuotationId_Specified;
  EarlyApproveResulState FState;
  bool            FState_Specified;
  void __fastcall SetErrorsVehicleNumbers(int Index, ArrayOfstring _prop_val)
  {  FErrorsVehicleNumbers = _prop_val; FErrorsVehicleNumbers_Specified = true;  }
  bool __fastcall ErrorsVehicleNumbers_Specified(int Index)
  {  return FErrorsVehicleNumbers_Specified;  } 
  void __fastcall SetQuotationId(int Index, guid _prop_val)
  {  FQuotationId = _prop_val; FQuotationId_Specified = true;  }
  bool __fastcall QuotationId_Specified(int Index)
  {  return FQuotationId_Specified;  } 
  void __fastcall SetState(int Index, EarlyApproveResulState _prop_val)
  {  FState = _prop_val; FState_Specified = true;  }
  bool __fastcall State_Specified(int Index)
  {  return FState_Specified;  } 
__published:
  __property ArrayOfstring ErrorsVehicleNumbers = { index=(IS_OPTN|IS_NLBL), read=FErrorsVehicleNumbers, write=SetErrorsVehicleNumbers, stored = ErrorsVehicleNumbers_Specified };
  __property guid       QuotationId = { index=(IS_OPTN), read=FQuotationId, write=SetQuotationId, stored = QuotationId_Specified };
  __property EarlyApproveResulState      State = { index=(IS_OPTN), read=FState, write=SetState, stored = State_Specified };
};




// ************************************************************************ //
// XML       : CalculationSheet, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculationSheet : public KaskoPrintRequestDto {
private:
  WideString      FBrandByPTS;
  bool            FBrandByPTS_Specified;
  PersonName*     FCalculatedBy;
  bool            FCalculatedBy_Specified;
  WideString      FModelByPTS;
  bool            FModelByPTS_Specified;
  WideString      FPointSale;
  bool            FPointSale_Specified;
  bool            FPrefProlongation;
  bool            FPrefProlongation_Specified;
  WideString      FVehicleId;
  void __fastcall SetBrandByPTS(int Index, WideString _prop_val)
  {  FBrandByPTS = _prop_val; FBrandByPTS_Specified = true;  }
  bool __fastcall BrandByPTS_Specified(int Index)
  {  return FBrandByPTS_Specified;  } 
  void __fastcall SetCalculatedBy(int Index, PersonName* _prop_val)
  {  FCalculatedBy = _prop_val; FCalculatedBy_Specified = true;  }
  bool __fastcall CalculatedBy_Specified(int Index)
  {  return FCalculatedBy_Specified;  } 
  void __fastcall SetModelByPTS(int Index, WideString _prop_val)
  {  FModelByPTS = _prop_val; FModelByPTS_Specified = true;  }
  bool __fastcall ModelByPTS_Specified(int Index)
  {  return FModelByPTS_Specified;  } 
  void __fastcall SetPointSale(int Index, WideString _prop_val)
  {  FPointSale = _prop_val; FPointSale_Specified = true;  }
  bool __fastcall PointSale_Specified(int Index)
  {  return FPointSale_Specified;  } 
  void __fastcall SetPrefProlongation(int Index, bool _prop_val)
  {  FPrefProlongation = _prop_val; FPrefProlongation_Specified = true;  }
  bool __fastcall PrefProlongation_Specified(int Index)
  {  return FPrefProlongation_Specified;  } 

public:
  __fastcall ~CalculationSheet();
__published:
  __property WideString BrandByPTS = { index=(IS_OPTN|IS_NLBL), read=FBrandByPTS, write=SetBrandByPTS, stored = BrandByPTS_Specified };
  __property PersonName* CalculatedBy = { index=(IS_OPTN|IS_NLBL), read=FCalculatedBy, write=SetCalculatedBy, stored = CalculatedBy_Specified };
  __property WideString ModelByPTS = { index=(IS_OPTN|IS_NLBL), read=FModelByPTS, write=SetModelByPTS, stored = ModelByPTS_Specified };
  __property WideString  PointSale = { index=(IS_OPTN|IS_NLBL), read=FPointSale, write=SetPointSale, stored = PointSale_Specified };
  __property bool       PrefProlongation = { index=(IS_OPTN), read=FPrefProlongation, write=SetPrefProlongation, stored = PrefProlongation_Specified };
  __property WideString  VehicleId = { index=(IS_NLBL), read=FVehicleId, write=FVehicleId };
};




// ************************************************************************ //
// XML       : KaskoFLSpecialRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoFLSpecialRequest : public KaskoPrintRequestDto {
private:
  ArrayOfAddEquipmentInfo FAddEquipmentsInfo;
  bool            FAddEquipmentsInfo_Specified;
  Insurant*       FBeneficiary;
  bool            FBeneficiary_Specified;
  int             FEquipmentInsuranceType;
  bool            FEquipmentInsuranceType_Specified;
  TXSDecimal*     FFirstPayment;
  bool            FFirstPayment_Specified;
  Inspection*     FInspection;
  bool            FInspection_Specified;
  InsurantInfo*   FInsurant;
  bool            FInsurant_Specified;
  InsurerProxyDto* FInsurerProxy;
  bool            FInsurerProxy_Specified;
  bool            FIsPrefProlongation;
  bool            FIsPrefProlongation_Specified;
  WideString      FLiabilityStartDate;
  bool            FLiabilityStartDate_Specified;
  bool            FPrintAddAgreement16;
  bool            FPrintAddAgreement16_Specified;
  bool            FPrintAddAgreement5;
  bool            FPrintAddAgreement5_Specified;
  RegistrationAgencyDto* FRegistrationAgency;
  bool            FRegistrationAgency_Specified;
  ExtendedBankInfo* FSberbank;
  bool            FSberbank_Specified;
  VehicleAddInformation* FVehicleData;
  bool            FVehicleData_Specified;
  void __fastcall SetAddEquipmentsInfo(int Index, ArrayOfAddEquipmentInfo _prop_val)
  {  FAddEquipmentsInfo = _prop_val; FAddEquipmentsInfo_Specified = true;  }
  bool __fastcall AddEquipmentsInfo_Specified(int Index)
  {  return FAddEquipmentsInfo_Specified;  } 
  void __fastcall SetBeneficiary(int Index, Insurant* _prop_val)
  {  FBeneficiary = _prop_val; FBeneficiary_Specified = true;  }
  bool __fastcall Beneficiary_Specified(int Index)
  {  return FBeneficiary_Specified;  } 
  void __fastcall SetEquipmentInsuranceType(int Index, int _prop_val)
  {  FEquipmentInsuranceType = _prop_val; FEquipmentInsuranceType_Specified = true;  }
  bool __fastcall EquipmentInsuranceType_Specified(int Index)
  {  return FEquipmentInsuranceType_Specified;  } 
  void __fastcall SetFirstPayment(int Index, TXSDecimal* _prop_val)
  {  FFirstPayment = _prop_val; FFirstPayment_Specified = true;  }
  bool __fastcall FirstPayment_Specified(int Index)
  {  return FFirstPayment_Specified;  } 
  void __fastcall SetInspection(int Index, Inspection* _prop_val)
  {  FInspection = _prop_val; FInspection_Specified = true;  }
  bool __fastcall Inspection_Specified(int Index)
  {  return FInspection_Specified;  } 
  void __fastcall SetInsurant(int Index, InsurantInfo* _prop_val)
  {  FInsurant = _prop_val; FInsurant_Specified = true;  }
  bool __fastcall Insurant_Specified(int Index)
  {  return FInsurant_Specified;  } 
  void __fastcall SetInsurerProxy(int Index, InsurerProxyDto* _prop_val)
  {  FInsurerProxy = _prop_val; FInsurerProxy_Specified = true;  }
  bool __fastcall InsurerProxy_Specified(int Index)
  {  return FInsurerProxy_Specified;  } 
  void __fastcall SetIsPrefProlongation(int Index, bool _prop_val)
  {  FIsPrefProlongation = _prop_val; FIsPrefProlongation_Specified = true;  }
  bool __fastcall IsPrefProlongation_Specified(int Index)
  {  return FIsPrefProlongation_Specified;  } 
  void __fastcall SetLiabilityStartDate(int Index, WideString _prop_val)
  {  FLiabilityStartDate = _prop_val; FLiabilityStartDate_Specified = true;  }
  bool __fastcall LiabilityStartDate_Specified(int Index)
  {  return FLiabilityStartDate_Specified;  } 
  void __fastcall SetPrintAddAgreement16(int Index, bool _prop_val)
  {  FPrintAddAgreement16 = _prop_val; FPrintAddAgreement16_Specified = true;  }
  bool __fastcall PrintAddAgreement16_Specified(int Index)
  {  return FPrintAddAgreement16_Specified;  } 
  void __fastcall SetPrintAddAgreement5(int Index, bool _prop_val)
  {  FPrintAddAgreement5 = _prop_val; FPrintAddAgreement5_Specified = true;  }
  bool __fastcall PrintAddAgreement5_Specified(int Index)
  {  return FPrintAddAgreement5_Specified;  } 
  void __fastcall SetRegistrationAgency(int Index, RegistrationAgencyDto* _prop_val)
  {  FRegistrationAgency = _prop_val; FRegistrationAgency_Specified = true;  }
  bool __fastcall RegistrationAgency_Specified(int Index)
  {  return FRegistrationAgency_Specified;  } 
  void __fastcall SetSberbank(int Index, ExtendedBankInfo* _prop_val)
  {  FSberbank = _prop_val; FSberbank_Specified = true;  }
  bool __fastcall Sberbank_Specified(int Index)
  {  return FSberbank_Specified;  } 
  void __fastcall SetVehicleData(int Index, VehicleAddInformation* _prop_val)
  {  FVehicleData = _prop_val; FVehicleData_Specified = true;  }
  bool __fastcall VehicleData_Specified(int Index)
  {  return FVehicleData_Specified;  } 

public:
  __fastcall ~KaskoFLSpecialRequest();
__published:
  __property ArrayOfAddEquipmentInfo AddEquipmentsInfo = { index=(IS_OPTN|IS_NLBL), read=FAddEquipmentsInfo, write=SetAddEquipmentsInfo, stored = AddEquipmentsInfo_Specified };
  __property Insurant*  Beneficiary = { index=(IS_OPTN|IS_NLBL), read=FBeneficiary, write=SetBeneficiary, stored = Beneficiary_Specified };
  __property int        EquipmentInsuranceType = { index=(IS_OPTN), read=FEquipmentInsuranceType, write=SetEquipmentInsuranceType, stored = EquipmentInsuranceType_Specified };
  __property TXSDecimal* FirstPayment = { index=(IS_OPTN|IS_NLBL), read=FFirstPayment, write=SetFirstPayment, stored = FirstPayment_Specified };
  __property Inspection* Inspection = { index=(IS_OPTN|IS_NLBL), read=FInspection, write=SetInspection, stored = Inspection_Specified };
  __property InsurantInfo*   Insurant = { index=(IS_OPTN|IS_NLBL), read=FInsurant, write=SetInsurant, stored = Insurant_Specified };
  __property InsurerProxyDto* InsurerProxy = { index=(IS_OPTN|IS_NLBL), read=FInsurerProxy, write=SetInsurerProxy, stored = InsurerProxy_Specified };
  __property bool       IsPrefProlongation = { index=(IS_OPTN), read=FIsPrefProlongation, write=SetIsPrefProlongation, stored = IsPrefProlongation_Specified };
  __property WideString LiabilityStartDate = { index=(IS_OPTN|IS_NLBL), read=FLiabilityStartDate, write=SetLiabilityStartDate, stored = LiabilityStartDate_Specified };
  __property bool       PrintAddAgreement16 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement16, write=SetPrintAddAgreement16, stored = PrintAddAgreement16_Specified };
  __property bool       PrintAddAgreement5 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement5, write=SetPrintAddAgreement5, stored = PrintAddAgreement5_Specified };
  __property RegistrationAgencyDto* RegistrationAgency = { index=(IS_OPTN|IS_NLBL), read=FRegistrationAgency, write=SetRegistrationAgency, stored = RegistrationAgency_Specified };
  __property ExtendedBankInfo*   Sberbank = { index=(IS_OPTN|IS_NLBL), read=FSberbank, write=SetSberbank, stored = Sberbank_Specified };
  __property VehicleAddInformation* VehicleData = { index=(IS_OPTN|IS_NLBL), read=FVehicleData, write=SetVehicleData, stored = VehicleData_Specified };
};




// ************************************************************************ //
// XML       : InsurantInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurantInfo : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  WideString      FEMail;
  bool            FEMail_Specified;
  WideString      FHomePhone;
  bool            FHomePhone_Specified;
  bool            FIsCitizenOfRF;
  WideString      FIssueBy;
  bool            FIssueBy_Specified;
  WideString      FMobilePhone;
  bool            FMobilePhone_Specified;
  WideString      FRegistrationAddress;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetEMail(int Index, WideString _prop_val)
  {  FEMail = _prop_val; FEMail_Specified = true;  }
  bool __fastcall EMail_Specified(int Index)
  {  return FEMail_Specified;  } 
  void __fastcall SetHomePhone(int Index, WideString _prop_val)
  {  FHomePhone = _prop_val; FHomePhone_Specified = true;  }
  bool __fastcall HomePhone_Specified(int Index)
  {  return FHomePhone_Specified;  } 
  void __fastcall SetIssueBy(int Index, WideString _prop_val)
  {  FIssueBy = _prop_val; FIssueBy_Specified = true;  }
  bool __fastcall IssueBy_Specified(int Index)
  {  return FIssueBy_Specified;  } 
  void __fastcall SetMobilePhone(int Index, WideString _prop_val)
  {  FMobilePhone = _prop_val; FMobilePhone_Specified = true;  }
  bool __fastcall MobilePhone_Specified(int Index)
  {  return FMobilePhone_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString      EMail = { index=(IS_OPTN|IS_NLBL), read=FEMail, write=SetEMail, stored = EMail_Specified };
  __property WideString  HomePhone = { index=(IS_OPTN|IS_NLBL), read=FHomePhone, write=SetHomePhone, stored = HomePhone_Specified };
  __property bool       IsCitizenOfRF = { read=FIsCitizenOfRF, write=FIsCitizenOfRF };
  __property WideString    IssueBy = { index=(IS_OPTN|IS_NLBL), read=FIssueBy, write=SetIssueBy, stored = IssueBy_Specified };
  __property WideString MobilePhone = { index=(IS_OPTN|IS_NLBL), read=FMobilePhone, write=SetMobilePhone, stored = MobilePhone_Specified };
  __property WideString RegistrationAddress = { index=(IS_NLBL), read=FRegistrationAddress, write=FRegistrationAddress };
};




// ************************************************************************ //
// XML       : RegistrationAgencyDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RegistrationAgencyDto : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  WideString      FName;
  bool            FName_Specified;
  WideString      FOGRN;
  bool            FOGRN_Specified;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetOGRN(int Index, WideString _prop_val)
  {  FOGRN = _prop_val; FOGRN_Specified = true;  }
  bool __fastcall OGRN_Specified(int Index)
  {  return FOGRN_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString       OGRN = { index=(IS_OPTN|IS_NLBL), read=FOGRN, write=SetOGRN, stored = OGRN_Specified };
};




// ************************************************************************ //
// XML       : ExtendedBankInfo, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ExtendedBankInfo : public TRemotable {
private:
  WideString      FBank;
  WideString      FBranchNumber;
  WideString      FBranchPlace;
  WideString      FBranchPostAddress;
  WideString      FCreditContractDate;
  bool            FCreditContractDate_Specified;
  WideString      FCreditContractNumber;
  WideString      FPledgeAgreementDate;
  bool            FPledgeAgreementDate_Specified;
  WideString      FPledgeAgreementNumber;
  void __fastcall SetCreditContractDate(int Index, WideString _prop_val)
  {  FCreditContractDate = _prop_val; FCreditContractDate_Specified = true;  }
  bool __fastcall CreditContractDate_Specified(int Index)
  {  return FCreditContractDate_Specified;  } 
  void __fastcall SetPledgeAgreementDate(int Index, WideString _prop_val)
  {  FPledgeAgreementDate = _prop_val; FPledgeAgreementDate_Specified = true;  }
  bool __fastcall PledgeAgreementDate_Specified(int Index)
  {  return FPledgeAgreementDate_Specified;  } 
__published:
  __property WideString       Bank = { index=(IS_NLBL), read=FBank, write=FBank };
  __property WideString BranchNumber = { index=(IS_NLBL), read=FBranchNumber, write=FBranchNumber };
  __property WideString BranchPlace = { index=(IS_NLBL), read=FBranchPlace, write=FBranchPlace };
  __property WideString BranchPostAddress = { index=(IS_NLBL), read=FBranchPostAddress, write=FBranchPostAddress };
  __property WideString CreditContractDate = { index=(IS_OPTN|IS_NLBL), read=FCreditContractDate, write=SetCreditContractDate, stored = CreditContractDate_Specified };
  __property WideString CreditContractNumber = { index=(IS_NLBL), read=FCreditContractNumber, write=FCreditContractNumber };
  __property WideString PledgeAgreementDate = { index=(IS_OPTN|IS_NLBL), read=FPledgeAgreementDate, write=SetPledgeAgreementDate, stored = PledgeAgreementDate_Specified };
  __property WideString PledgeAgreementNumber = { index=(IS_NLBL), read=FPledgeAgreementNumber, write=FPledgeAgreementNumber };
};




// ************************************************************************ //
// XML       : KaskoAutoProtectionRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoAutoProtectionRequest : public KaskoPrintRequestDto {
private:
  ArrayOfAddEquipmentInfo FAddEquipmentsInfo;
  bool            FAddEquipmentsInfo_Specified;
  Insurant*       FBeneficiary;
  bool            FBeneficiary_Specified;
  int             FEquipmentInsuranceType;
  bool            FEquipmentInsuranceType_Specified;
  TXSDecimal*     FFirstPayment;
  bool            FFirstPayment_Specified;
  Inspection*     FInspection;
  bool            FInspection_Specified;
  InsurantPrintDto* FInsurant;
  bool            FInsurant_Specified;
  bool            FInsurantIsCitizenOfRF;
  bool            FInsurantIsCitizenOfRF_Specified;
  InsurerProxyDto* FInsurerProxy;
  bool            FInsurerProxy_Specified;
  bool            FIsPrefProlongation;
  bool            FIsPrefProlongation_Specified;
  WideString      FLiabilityStartDate;
  bool            FLiabilityStartDate_Specified;
  DocumentWithValidityDto* FMigrationCard;
  bool            FMigrationCard_Specified;
  DocumentWithValidityDto* FPermissionForStay;
  bool            FPermissionForStay_Specified;
  bool            FPrintAddAgreement16;
  bool            FPrintAddAgreement16_Specified;
  bool            FPrintAddAgreement5;
  bool            FPrintAddAgreement5_Specified;
  RegistrationAgencyDto* FRegistrationAgency;
  bool            FRegistrationAgency_Specified;
  ExtendedBankInfo* FSberbank;
  bool            FSberbank_Specified;
  WideString      FTelematicsDeviceCode;
  bool            FTelematicsDeviceCode_Specified;
  VehicleAddInformation* FVehicleData;
  bool            FVehicleData_Specified;
  void __fastcall SetAddEquipmentsInfo(int Index, ArrayOfAddEquipmentInfo _prop_val)
  {  FAddEquipmentsInfo = _prop_val; FAddEquipmentsInfo_Specified = true;  }
  bool __fastcall AddEquipmentsInfo_Specified(int Index)
  {  return FAddEquipmentsInfo_Specified;  } 
  void __fastcall SetBeneficiary(int Index, Insurant* _prop_val)
  {  FBeneficiary = _prop_val; FBeneficiary_Specified = true;  }
  bool __fastcall Beneficiary_Specified(int Index)
  {  return FBeneficiary_Specified;  } 
  void __fastcall SetEquipmentInsuranceType(int Index, int _prop_val)
  {  FEquipmentInsuranceType = _prop_val; FEquipmentInsuranceType_Specified = true;  }
  bool __fastcall EquipmentInsuranceType_Specified(int Index)
  {  return FEquipmentInsuranceType_Specified;  } 
  void __fastcall SetFirstPayment(int Index, TXSDecimal* _prop_val)
  {  FFirstPayment = _prop_val; FFirstPayment_Specified = true;  }
  bool __fastcall FirstPayment_Specified(int Index)
  {  return FFirstPayment_Specified;  } 
  void __fastcall SetInspection(int Index, Inspection* _prop_val)
  {  FInspection = _prop_val; FInspection_Specified = true;  }
  bool __fastcall Inspection_Specified(int Index)
  {  return FInspection_Specified;  } 
  void __fastcall SetInsurant(int Index, InsurantPrintDto* _prop_val)
  {  FInsurant = _prop_val; FInsurant_Specified = true;  }
  bool __fastcall Insurant_Specified(int Index)
  {  return FInsurant_Specified;  } 
  void __fastcall SetInsurantIsCitizenOfRF(int Index, bool _prop_val)
  {  FInsurantIsCitizenOfRF = _prop_val; FInsurantIsCitizenOfRF_Specified = true;  }
  bool __fastcall InsurantIsCitizenOfRF_Specified(int Index)
  {  return FInsurantIsCitizenOfRF_Specified;  } 
  void __fastcall SetInsurerProxy(int Index, InsurerProxyDto* _prop_val)
  {  FInsurerProxy = _prop_val; FInsurerProxy_Specified = true;  }
  bool __fastcall InsurerProxy_Specified(int Index)
  {  return FInsurerProxy_Specified;  } 
  void __fastcall SetIsPrefProlongation(int Index, bool _prop_val)
  {  FIsPrefProlongation = _prop_val; FIsPrefProlongation_Specified = true;  }
  bool __fastcall IsPrefProlongation_Specified(int Index)
  {  return FIsPrefProlongation_Specified;  } 
  void __fastcall SetLiabilityStartDate(int Index, WideString _prop_val)
  {  FLiabilityStartDate = _prop_val; FLiabilityStartDate_Specified = true;  }
  bool __fastcall LiabilityStartDate_Specified(int Index)
  {  return FLiabilityStartDate_Specified;  } 
  void __fastcall SetMigrationCard(int Index, DocumentWithValidityDto* _prop_val)
  {  FMigrationCard = _prop_val; FMigrationCard_Specified = true;  }
  bool __fastcall MigrationCard_Specified(int Index)
  {  return FMigrationCard_Specified;  } 
  void __fastcall SetPermissionForStay(int Index, DocumentWithValidityDto* _prop_val)
  {  FPermissionForStay = _prop_val; FPermissionForStay_Specified = true;  }
  bool __fastcall PermissionForStay_Specified(int Index)
  {  return FPermissionForStay_Specified;  } 
  void __fastcall SetPrintAddAgreement16(int Index, bool _prop_val)
  {  FPrintAddAgreement16 = _prop_val; FPrintAddAgreement16_Specified = true;  }
  bool __fastcall PrintAddAgreement16_Specified(int Index)
  {  return FPrintAddAgreement16_Specified;  } 
  void __fastcall SetPrintAddAgreement5(int Index, bool _prop_val)
  {  FPrintAddAgreement5 = _prop_val; FPrintAddAgreement5_Specified = true;  }
  bool __fastcall PrintAddAgreement5_Specified(int Index)
  {  return FPrintAddAgreement5_Specified;  } 
  void __fastcall SetRegistrationAgency(int Index, RegistrationAgencyDto* _prop_val)
  {  FRegistrationAgency = _prop_val; FRegistrationAgency_Specified = true;  }
  bool __fastcall RegistrationAgency_Specified(int Index)
  {  return FRegistrationAgency_Specified;  } 
  void __fastcall SetSberbank(int Index, ExtendedBankInfo* _prop_val)
  {  FSberbank = _prop_val; FSberbank_Specified = true;  }
  bool __fastcall Sberbank_Specified(int Index)
  {  return FSberbank_Specified;  } 
  void __fastcall SetTelematicsDeviceCode(int Index, WideString _prop_val)
  {  FTelematicsDeviceCode = _prop_val; FTelematicsDeviceCode_Specified = true;  }
  bool __fastcall TelematicsDeviceCode_Specified(int Index)
  {  return FTelematicsDeviceCode_Specified;  } 
  void __fastcall SetVehicleData(int Index, VehicleAddInformation* _prop_val)
  {  FVehicleData = _prop_val; FVehicleData_Specified = true;  }
  bool __fastcall VehicleData_Specified(int Index)
  {  return FVehicleData_Specified;  } 

public:
  __fastcall ~KaskoAutoProtectionRequest();
__published:
  __property ArrayOfAddEquipmentInfo AddEquipmentsInfo = { index=(IS_OPTN|IS_NLBL), read=FAddEquipmentsInfo, write=SetAddEquipmentsInfo, stored = AddEquipmentsInfo_Specified };
  __property Insurant*  Beneficiary = { index=(IS_OPTN|IS_NLBL), read=FBeneficiary, write=SetBeneficiary, stored = Beneficiary_Specified };
  __property int        EquipmentInsuranceType = { index=(IS_OPTN), read=FEquipmentInsuranceType, write=SetEquipmentInsuranceType, stored = EquipmentInsuranceType_Specified };
  __property TXSDecimal* FirstPayment = { index=(IS_OPTN|IS_NLBL), read=FFirstPayment, write=SetFirstPayment, stored = FirstPayment_Specified };
  __property Inspection* Inspection = { index=(IS_OPTN|IS_NLBL), read=FInspection, write=SetInspection, stored = Inspection_Specified };
  __property InsurantPrintDto*   Insurant = { index=(IS_OPTN|IS_NLBL), read=FInsurant, write=SetInsurant, stored = Insurant_Specified };
  __property bool       InsurantIsCitizenOfRF = { index=(IS_OPTN), read=FInsurantIsCitizenOfRF, write=SetInsurantIsCitizenOfRF, stored = InsurantIsCitizenOfRF_Specified };
  __property InsurerProxyDto* InsurerProxy = { index=(IS_OPTN|IS_NLBL), read=FInsurerProxy, write=SetInsurerProxy, stored = InsurerProxy_Specified };
  __property bool       IsPrefProlongation = { index=(IS_OPTN), read=FIsPrefProlongation, write=SetIsPrefProlongation, stored = IsPrefProlongation_Specified };
  __property WideString LiabilityStartDate = { index=(IS_OPTN|IS_NLBL), read=FLiabilityStartDate, write=SetLiabilityStartDate, stored = LiabilityStartDate_Specified };
  __property DocumentWithValidityDto* MigrationCard = { index=(IS_OPTN|IS_NLBL), read=FMigrationCard, write=SetMigrationCard, stored = MigrationCard_Specified };
  __property DocumentWithValidityDto* PermissionForStay = { index=(IS_OPTN|IS_NLBL), read=FPermissionForStay, write=SetPermissionForStay, stored = PermissionForStay_Specified };
  __property bool       PrintAddAgreement16 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement16, write=SetPrintAddAgreement16, stored = PrintAddAgreement16_Specified };
  __property bool       PrintAddAgreement5 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement5, write=SetPrintAddAgreement5, stored = PrintAddAgreement5_Specified };
  __property RegistrationAgencyDto* RegistrationAgency = { index=(IS_OPTN|IS_NLBL), read=FRegistrationAgency, write=SetRegistrationAgency, stored = RegistrationAgency_Specified };
  __property ExtendedBankInfo*   Sberbank = { index=(IS_OPTN|IS_NLBL), read=FSberbank, write=SetSberbank, stored = Sberbank_Specified };
  __property WideString TelematicsDeviceCode = { index=(IS_OPTN|IS_NLBL), read=FTelematicsDeviceCode, write=SetTelematicsDeviceCode, stored = TelematicsDeviceCode_Specified };
  __property VehicleAddInformation* VehicleData = { index=(IS_OPTN|IS_NLBL), read=FVehicleData, write=SetVehicleData, stored = VehicleData_Specified };
};




// ************************************************************************ //
// XML       : InsurantPrintDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurantPrintDto : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  WideString      FEmail;
  bool            FEmail_Specified;
  WideString      FIssueBy;
  bool            FIssueBy_Specified;
  WideString      FPhone;
  bool            FPhone_Specified;
  WideString      FRegistrationAddress;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetEmail(int Index, WideString _prop_val)
  {  FEmail = _prop_val; FEmail_Specified = true;  }
  bool __fastcall Email_Specified(int Index)
  {  return FEmail_Specified;  } 
  void __fastcall SetIssueBy(int Index, WideString _prop_val)
  {  FIssueBy = _prop_val; FIssueBy_Specified = true;  }
  bool __fastcall IssueBy_Specified(int Index)
  {  return FIssueBy_Specified;  } 
  void __fastcall SetPhone(int Index, WideString _prop_val)
  {  FPhone = _prop_val; FPhone_Specified = true;  }
  bool __fastcall Phone_Specified(int Index)
  {  return FPhone_Specified;  } 
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString      Email = { index=(IS_OPTN|IS_NLBL), read=FEmail, write=SetEmail, stored = Email_Specified };
  __property WideString    IssueBy = { index=(IS_OPTN|IS_NLBL), read=FIssueBy, write=SetIssueBy, stored = IssueBy_Specified };
  __property WideString      Phone = { index=(IS_OPTN|IS_NLBL), read=FPhone, write=SetPhone, stored = Phone_Specified };
  __property WideString RegistrationAddress = { index=(IS_NLBL), read=FRegistrationAddress, write=FRegistrationAddress };
};




// ************************************************************************ //
// XML       : DocumentWithValidityDto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DocumentWithValidityDto : public Document {
private:
  WideString      FEndDate;
  bool            FEndDate_Specified;
  WideString      FStartDate;
  bool            FStartDate_Specified;
  void __fastcall SetEndDate(int Index, WideString _prop_val)
  {  FEndDate = _prop_val; FEndDate_Specified = true;  }
  bool __fastcall EndDate_Specified(int Index)
  {  return FEndDate_Specified;  } 
  void __fastcall SetStartDate(int Index, WideString _prop_val)
  {  FStartDate = _prop_val; FStartDate_Specified = true;  }
  bool __fastcall StartDate_Specified(int Index)
  {  return FStartDate_Specified;  } 
__published:
  __property WideString    EndDate = { index=(IS_OPTN|IS_NLBL), read=FEndDate, write=SetEndDate, stored = EndDate_Specified };
  __property WideString  StartDate = { index=(IS_OPTN|IS_NLBL), read=FStartDate, write=SetStartDate, stored = StartDate_Specified };
};




// ************************************************************************ //
// XML       : KaskoAutoProtectionRequestUL, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoAutoProtectionRequestUL : public KaskoPrintRequestDto {
private:
  ArrayOfAddEquipmentInfo FAddEquipmentsInfo;
  bool            FAddEquipmentsInfo_Specified;
  Insurant*       FBeneficiary;
  bool            FBeneficiary_Specified;
  WideString      FECTACardNumber;
  bool            FECTACardNumber_Specified;
  int             FEquipmentInsuranceType;
  bool            FEquipmentInsuranceType_Specified;
  TXSDecimal*     FFirstPayment;
  bool            FFirstPayment_Specified;
  Inspection*     FInspection;
  bool            FInspection_Specified;
  InsurantPrintDto* FInsurantAdditionalInfo;
  bool            FInsurantAdditionalInfo_Specified;
  bool            FInsurantIsCitizenOfRF;
  bool            FInsurantIsCitizenOfRF_Specified;
  RegistrationAgencyDto* FInsurantRegistrationAgency;
  bool            FInsurantRegistrationAgency_Specified;
  InsurerProxyDto* FInsurerProxy;
  bool            FInsurerProxy_Specified;
  bool            FIsPrefProlongation;
  bool            FIsPrefProlongation_Specified;
  WideString      FLeaseContract;
  bool            FLeaseContract_Specified;
  WideString      FLeaseContractDate;
  bool            FLeaseContractDate_Specified;
  Insurant*       FLessee;
  bool            FLessee_Specified;
  InsurantPrintDto* FLesseeAdditionalInfo;
  bool            FLesseeAdditionalInfo_Specified;
  bool            FLesseeIsCitizenOfRF;
  bool            FLesseeIsCitizenOfRF_Specified;
  RegistrationAgencyDto* FLesseeRegistrationAgency;
  bool            FLesseeRegistrationAgency_Specified;
  int             FLessorId;
  bool            FLessorId_Specified;
  WideString      FLiabilityStartDate;
  bool            FLiabilityStartDate_Specified;
  WideString      FPayer;
  bool            FPayer_Specified;
  bool            FPrintAddAgreement10;
  bool            FPrintAddAgreement10_Specified;
  bool            FPrintAddAgreement16;
  bool            FPrintAddAgreement16_Specified;
  bool            FPrintAddAgreement5;
  bool            FPrintAddAgreement5_Specified;
  ExtendedBankInfo* FSberbank;
  bool            FSberbank_Specified;
  ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u FVehicleData;
  bool            FVehicleData_Specified;
  void __fastcall SetAddEquipmentsInfo(int Index, ArrayOfAddEquipmentInfo _prop_val)
  {  FAddEquipmentsInfo = _prop_val; FAddEquipmentsInfo_Specified = true;  }
  bool __fastcall AddEquipmentsInfo_Specified(int Index)
  {  return FAddEquipmentsInfo_Specified;  } 
  void __fastcall SetBeneficiary(int Index, Insurant* _prop_val)
  {  FBeneficiary = _prop_val; FBeneficiary_Specified = true;  }
  bool __fastcall Beneficiary_Specified(int Index)
  {  return FBeneficiary_Specified;  } 
  void __fastcall SetECTACardNumber(int Index, WideString _prop_val)
  {  FECTACardNumber = _prop_val; FECTACardNumber_Specified = true;  }
  bool __fastcall ECTACardNumber_Specified(int Index)
  {  return FECTACardNumber_Specified;  } 
  void __fastcall SetEquipmentInsuranceType(int Index, int _prop_val)
  {  FEquipmentInsuranceType = _prop_val; FEquipmentInsuranceType_Specified = true;  }
  bool __fastcall EquipmentInsuranceType_Specified(int Index)
  {  return FEquipmentInsuranceType_Specified;  } 
  void __fastcall SetFirstPayment(int Index, TXSDecimal* _prop_val)
  {  FFirstPayment = _prop_val; FFirstPayment_Specified = true;  }
  bool __fastcall FirstPayment_Specified(int Index)
  {  return FFirstPayment_Specified;  } 
  void __fastcall SetInspection(int Index, Inspection* _prop_val)
  {  FInspection = _prop_val; FInspection_Specified = true;  }
  bool __fastcall Inspection_Specified(int Index)
  {  return FInspection_Specified;  } 
  void __fastcall SetInsurantAdditionalInfo(int Index, InsurantPrintDto* _prop_val)
  {  FInsurantAdditionalInfo = _prop_val; FInsurantAdditionalInfo_Specified = true;  }
  bool __fastcall InsurantAdditionalInfo_Specified(int Index)
  {  return FInsurantAdditionalInfo_Specified;  } 
  void __fastcall SetInsurantIsCitizenOfRF(int Index, bool _prop_val)
  {  FInsurantIsCitizenOfRF = _prop_val; FInsurantIsCitizenOfRF_Specified = true;  }
  bool __fastcall InsurantIsCitizenOfRF_Specified(int Index)
  {  return FInsurantIsCitizenOfRF_Specified;  } 
  void __fastcall SetInsurantRegistrationAgency(int Index, RegistrationAgencyDto* _prop_val)
  {  FInsurantRegistrationAgency = _prop_val; FInsurantRegistrationAgency_Specified = true;  }
  bool __fastcall InsurantRegistrationAgency_Specified(int Index)
  {  return FInsurantRegistrationAgency_Specified;  } 
  void __fastcall SetInsurerProxy(int Index, InsurerProxyDto* _prop_val)
  {  FInsurerProxy = _prop_val; FInsurerProxy_Specified = true;  }
  bool __fastcall InsurerProxy_Specified(int Index)
  {  return FInsurerProxy_Specified;  } 
  void __fastcall SetIsPrefProlongation(int Index, bool _prop_val)
  {  FIsPrefProlongation = _prop_val; FIsPrefProlongation_Specified = true;  }
  bool __fastcall IsPrefProlongation_Specified(int Index)
  {  return FIsPrefProlongation_Specified;  } 
  void __fastcall SetLeaseContract(int Index, WideString _prop_val)
  {  FLeaseContract = _prop_val; FLeaseContract_Specified = true;  }
  bool __fastcall LeaseContract_Specified(int Index)
  {  return FLeaseContract_Specified;  } 
  void __fastcall SetLeaseContractDate(int Index, WideString _prop_val)
  {  FLeaseContractDate = _prop_val; FLeaseContractDate_Specified = true;  }
  bool __fastcall LeaseContractDate_Specified(int Index)
  {  return FLeaseContractDate_Specified;  } 
  void __fastcall SetLessee(int Index, Insurant* _prop_val)
  {  FLessee = _prop_val; FLessee_Specified = true;  }
  bool __fastcall Lessee_Specified(int Index)
  {  return FLessee_Specified;  } 
  void __fastcall SetLesseeAdditionalInfo(int Index, InsurantPrintDto* _prop_val)
  {  FLesseeAdditionalInfo = _prop_val; FLesseeAdditionalInfo_Specified = true;  }
  bool __fastcall LesseeAdditionalInfo_Specified(int Index)
  {  return FLesseeAdditionalInfo_Specified;  } 
  void __fastcall SetLesseeIsCitizenOfRF(int Index, bool _prop_val)
  {  FLesseeIsCitizenOfRF = _prop_val; FLesseeIsCitizenOfRF_Specified = true;  }
  bool __fastcall LesseeIsCitizenOfRF_Specified(int Index)
  {  return FLesseeIsCitizenOfRF_Specified;  } 
  void __fastcall SetLesseeRegistrationAgency(int Index, RegistrationAgencyDto* _prop_val)
  {  FLesseeRegistrationAgency = _prop_val; FLesseeRegistrationAgency_Specified = true;  }
  bool __fastcall LesseeRegistrationAgency_Specified(int Index)
  {  return FLesseeRegistrationAgency_Specified;  } 
  void __fastcall SetLessorId(int Index, int _prop_val)
  {  FLessorId = _prop_val; FLessorId_Specified = true;  }
  bool __fastcall LessorId_Specified(int Index)
  {  return FLessorId_Specified;  } 
  void __fastcall SetLiabilityStartDate(int Index, WideString _prop_val)
  {  FLiabilityStartDate = _prop_val; FLiabilityStartDate_Specified = true;  }
  bool __fastcall LiabilityStartDate_Specified(int Index)
  {  return FLiabilityStartDate_Specified;  } 
  void __fastcall SetPayer(int Index, WideString _prop_val)
  {  FPayer = _prop_val; FPayer_Specified = true;  }
  bool __fastcall Payer_Specified(int Index)
  {  return FPayer_Specified;  } 
  void __fastcall SetPrintAddAgreement10(int Index, bool _prop_val)
  {  FPrintAddAgreement10 = _prop_val; FPrintAddAgreement10_Specified = true;  }
  bool __fastcall PrintAddAgreement10_Specified(int Index)
  {  return FPrintAddAgreement10_Specified;  } 
  void __fastcall SetPrintAddAgreement16(int Index, bool _prop_val)
  {  FPrintAddAgreement16 = _prop_val; FPrintAddAgreement16_Specified = true;  }
  bool __fastcall PrintAddAgreement16_Specified(int Index)
  {  return FPrintAddAgreement16_Specified;  } 
  void __fastcall SetPrintAddAgreement5(int Index, bool _prop_val)
  {  FPrintAddAgreement5 = _prop_val; FPrintAddAgreement5_Specified = true;  }
  bool __fastcall PrintAddAgreement5_Specified(int Index)
  {  return FPrintAddAgreement5_Specified;  } 
  void __fastcall SetSberbank(int Index, ExtendedBankInfo* _prop_val)
  {  FSberbank = _prop_val; FSberbank_Specified = true;  }
  bool __fastcall Sberbank_Specified(int Index)
  {  return FSberbank_Specified;  } 
  void __fastcall SetVehicleData(int Index, ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u _prop_val)
  {  FVehicleData = _prop_val; FVehicleData_Specified = true;  }
  bool __fastcall VehicleData_Specified(int Index)
  {  return FVehicleData_Specified;  } 

public:
  __fastcall ~KaskoAutoProtectionRequestUL();
__published:
  __property ArrayOfAddEquipmentInfo AddEquipmentsInfo = { index=(IS_OPTN|IS_NLBL), read=FAddEquipmentsInfo, write=SetAddEquipmentsInfo, stored = AddEquipmentsInfo_Specified };
  __property Insurant*  Beneficiary = { index=(IS_OPTN|IS_NLBL), read=FBeneficiary, write=SetBeneficiary, stored = Beneficiary_Specified };
  __property WideString ECTACardNumber = { index=(IS_OPTN|IS_NLBL), read=FECTACardNumber, write=SetECTACardNumber, stored = ECTACardNumber_Specified };
  __property int        EquipmentInsuranceType = { index=(IS_OPTN), read=FEquipmentInsuranceType, write=SetEquipmentInsuranceType, stored = EquipmentInsuranceType_Specified };
  __property TXSDecimal* FirstPayment = { index=(IS_OPTN|IS_NLBL), read=FFirstPayment, write=SetFirstPayment, stored = FirstPayment_Specified };
  __property Inspection* Inspection = { index=(IS_OPTN|IS_NLBL), read=FInspection, write=SetInspection, stored = Inspection_Specified };
  __property InsurantPrintDto* InsurantAdditionalInfo = { index=(IS_OPTN|IS_NLBL), read=FInsurantAdditionalInfo, write=SetInsurantAdditionalInfo, stored = InsurantAdditionalInfo_Specified };
  __property bool       InsurantIsCitizenOfRF = { index=(IS_OPTN), read=FInsurantIsCitizenOfRF, write=SetInsurantIsCitizenOfRF, stored = InsurantIsCitizenOfRF_Specified };
  __property RegistrationAgencyDto* InsurantRegistrationAgency = { index=(IS_OPTN|IS_NLBL), read=FInsurantRegistrationAgency, write=SetInsurantRegistrationAgency, stored = InsurantRegistrationAgency_Specified };
  __property InsurerProxyDto* InsurerProxy = { index=(IS_OPTN|IS_NLBL), read=FInsurerProxy, write=SetInsurerProxy, stored = InsurerProxy_Specified };
  __property bool       IsPrefProlongation = { index=(IS_OPTN), read=FIsPrefProlongation, write=SetIsPrefProlongation, stored = IsPrefProlongation_Specified };
  __property WideString LeaseContract = { index=(IS_OPTN|IS_NLBL), read=FLeaseContract, write=SetLeaseContract, stored = LeaseContract_Specified };
  __property WideString LeaseContractDate = { index=(IS_OPTN|IS_NLBL), read=FLeaseContractDate, write=SetLeaseContractDate, stored = LeaseContractDate_Specified };
  __property Insurant*      Lessee = { index=(IS_OPTN|IS_NLBL), read=FLessee, write=SetLessee, stored = Lessee_Specified };
  __property InsurantPrintDto* LesseeAdditionalInfo = { index=(IS_OPTN|IS_NLBL), read=FLesseeAdditionalInfo, write=SetLesseeAdditionalInfo, stored = LesseeAdditionalInfo_Specified };
  __property bool       LesseeIsCitizenOfRF = { index=(IS_OPTN), read=FLesseeIsCitizenOfRF, write=SetLesseeIsCitizenOfRF, stored = LesseeIsCitizenOfRF_Specified };
  __property RegistrationAgencyDto* LesseeRegistrationAgency = { index=(IS_OPTN|IS_NLBL), read=FLesseeRegistrationAgency, write=SetLesseeRegistrationAgency, stored = LesseeRegistrationAgency_Specified };
  __property int          LessorId = { index=(IS_OPTN|IS_NLBL), read=FLessorId, write=SetLessorId, stored = LessorId_Specified };
  __property WideString LiabilityStartDate = { index=(IS_OPTN|IS_NLBL), read=FLiabilityStartDate, write=SetLiabilityStartDate, stored = LiabilityStartDate_Specified };
  __property WideString      Payer = { index=(IS_OPTN|IS_NLBL), read=FPayer, write=SetPayer, stored = Payer_Specified };
  __property bool       PrintAddAgreement10 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement10, write=SetPrintAddAgreement10, stored = PrintAddAgreement10_Specified };
  __property bool       PrintAddAgreement16 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement16, write=SetPrintAddAgreement16, stored = PrintAddAgreement16_Specified };
  __property bool       PrintAddAgreement5 = { index=(IS_OPTN|IS_NLBL), read=FPrintAddAgreement5, write=SetPrintAddAgreement5, stored = PrintAddAgreement5_Specified };
  __property ExtendedBankInfo*   Sberbank = { index=(IS_OPTN|IS_NLBL), read=FSberbank, write=SetSberbank, stored = Sberbank_Specified };
  __property ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u VehicleData = { index=(IS_OPTN|IS_NLBL), read=FVehicleData, write=SetVehicleData, stored = VehicleData_Specified };
};




// ************************************************************************ //
// XML       : User, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class User2 : public User {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculationRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculationRequest2 : public CalculationRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : Insurant, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Insurant2 : public Insurant {
private:
__published:
};




// ************************************************************************ //
// XML       : InsurantDocument, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurantDocument2 : public InsurantDocument {
private:
__published:
};




// ************************************************************************ //
// XML       : Document, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Document2 : public Document {
private:
__published:
};




// ************************************************************************ //
// XML       : PersonName, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PersonName2 : public PersonName {
private:
__published:
};




// ************************************************************************ //
// XML       : LegalEntity, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class LegalEntity2 : public LegalEntity {
private:
__published:
};




// ************************************************************************ //
// XML       : Vehicle, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Vehicle2 : public Vehicle {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleBaseDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleBaseDto2 : public VehicleBaseDto {
private:
__published:
};




// ************************************************************************ //
// XML       : AddEquipmentRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddEquipmentRequest2 : public AddEquipmentRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : Driver, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Driver2 : public Driver {
private:
__published:
};




// ************************************************************************ //
// XML       : DriverLicense, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverLicense2 : public DriverLicense {
private:
__published:
};




// ************************************************************************ //
// XML       : Franchise, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Franchise2 : public Franchise {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoReCalculateRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoReCalculateRequest2 : public KaskoReCalculateRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoReCalculateVehicle, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoReCalculateVehicle2 : public KaskoReCalculateVehicle {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculationResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculationResult2 : public CalculationResult {
private:
__published:
};




// ************************************************************************ //
// XML       : UsagePeriod, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UsagePeriod2 : public UsagePeriod {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleCalculationResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleCalculationResult2 : public VehicleCalculationResult {
private:
__published:
};




// ************************************************************************ //
// XML       : AddEquipmentResponse, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddEquipmentResponse2 : public AddEquipmentResponse {
private:
__published:
};




// ************************************************************************ //
// XML       : AdmitResultsDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AdmitResultsDto2 : public AdmitResultsDto {
private:
__published:
};




// ************************************************************************ //
// XML       : DriverPrevContractDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverPrevContractDto2 : public DriverPrevContractDto {
private:
__published:
};




// ************************************************************************ //
// XML       : Coefficients, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Coefficients2 : public Coefficients {
private:
__published:
};




// ************************************************************************ //
// XML       : PaymentDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PaymentDto2 : public PaymentDto {
private:
__published:
};




// ************************************************************************ //
// XML       : PrevContractIdDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrevContractIdDto2 : public PrevContractIdDto {
private:
__published:
};




// ************************************************************************ //
// XML       : PrevPolicyDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrevPolicyDto2 : public PrevPolicyDto {
private:
__published:
};




// ************************************************************************ //
// XML       : ReservationCoefficient, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ReservationCoefficient2 : public ReservationCoefficient {
private:
__published:
};




// ************************************************************************ //
// XML       : RiskObject, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RiskObject2 : public RiskObject {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoUnderwritingRequirements, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoUnderwritingRequirements2 : public KaskoUnderwritingRequirements {
private:
__published:
};




// ************************************************************************ //
// XML       : UnderwritingRequirement, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UnderwritingRequirement2 : public UnderwritingRequirement {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintRequest2 : public PrintRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintCertificateRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintCertificateRequest2 : public PrintCertificateRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : ContractorName, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractorName2 : public ContractorName {
private:
__published:
};




// ************************************************************************ //
// XML       : BrandModel, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class BrandModel2 : public BrandModel {
private:
__published:
};




// ************************************************************************ //
// XML       : Address, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Address2 : public Address {
private:
__published:
};




// ************************************************************************ //
// XML       : Proxy, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Proxy2 : public Proxy {
private:
__published:
};




// ************************************************************************ //
// XML       : Pledgeholder, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Pledgeholder2 : public Pledgeholder {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintAppRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintAppRequest2 : public PrintAppRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : Signer, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Signer2 : public Signer {
private:
__published:
};




// ************************************************************************ //
// XML       : SignerDocument, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class SignerDocument2 : public SignerDocument {
private:
__published:
};




// ************************************************************************ //
// XML       : AppInsurer, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AppInsurer2 : public AppInsurer {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintAppVehicle, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintAppVehicle2 : public PrintAppVehicle {
private:
__published:
};




// ************************************************************************ //
// XML       : Inspection, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Inspection2 : public Inspection {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintAppRequestUl, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintAppRequestUl2 : public PrintAppRequestUl {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleAddInformation, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleAddInformation2 : public VehicleAddInformation {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintContractRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintContractRequest2 : public PrintContractRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : BeneficiaryPrintRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class BeneficiaryPrintRequest2 : public BeneficiaryPrintRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : ContractInsurant, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractInsurant2 : public ContractInsurant {
private:
__published:
};




// ************************************************************************ //
// XML       : Passport, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Passport2 : public Passport {
private:
__published:
};




// ************************************************************************ //
// XML       : ContractInsurer, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractInsurer2 : public ContractInsurer {
private:
__published:
};




// ************************************************************************ //
// XML       : Payments, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Payments2 : public Payments {
private:
__published:
};




// ************************************************************************ //
// XML       : Payment, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Payment2 : public Payment {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoPrintContractUlRequestDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoPrintContractUlRequestDto2 : public KaskoPrintContractUlRequestDto {
private:
__published:
};




// ************************************************************************ //
// XML       : LeasingContract, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class LeasingContract2 : public LeasingContract {
private:
__published:
};




// ************************************************************************ //
// XML       : UnderwritingAdditionalInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UnderwritingAdditionalInfo2 : public UnderwritingAdditionalInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : Beneficiary, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Beneficiary2 : public Beneficiary {
private:
__published:
};




// ************************************************************************ //
// XML       : CommonDocument, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CommonDocument2 : public CommonDocument {
private:
__published:
};




// ************************************************************************ //
// XML       : Group, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Group2 : public Group {
private:
__published:
};




// ************************************************************************ //
// XML       : LeaseHolder, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class LeaseHolder2 : public LeaseHolder {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleAdditionalInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleAdditionalInfo2 : public VehicleAdditionalInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleProlongation, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleProlongation2 : public VehicleProlongation {
private:
__published:
};




// ************************************************************************ //
// XML       : QuotationStateInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class QuotationStateInfo2 : public QuotationStateInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : Quotation, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Quotation2 : public Quotation {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleResult2 : public VehicleResult {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleStateInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleStateInfo2 : public VehicleStateInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleComment, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleComment2 : public VehicleComment {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculateVzdRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdRequest2 : public CalculateVzdRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculateVzdVehicleRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdVehicleRequest2 : public CalculateVzdVehicleRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculateVzdResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdResult2 : public CalculateVzdResult {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculateVzdVehicleResponse, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculateVzdVehicleResponse2 : public CalculateVzdVehicleResponse {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintULAddAgreementRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintULAddAgreementRequest2 : public PrintULAddAgreementRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : AddEquipmentInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddEquipmentInfo2 : public AddEquipmentInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : InsurerProxyDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurerProxyDto2 : public InsurerProxyDto {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintULBLAddAgreementRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintULBLAddAgreementRequest2 : public PrintULBLAddAgreementRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : EarlyApproveInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class EarlyApproveInfo2 : public EarlyApproveInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : EarlyApproveResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class EarlyApproveResult2 : public EarlyApproveResult {
private:
__published:
};




// ************************************************************************ //
// XML       : CalculationSheet, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalculationSheet2 : public CalculationSheet {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoFLSpecialRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoFLSpecialRequest2 : public KaskoFLSpecialRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : InsurantInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurantInfo2 : public InsurantInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : RegistrationAgencyDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RegistrationAgencyDto2 : public RegistrationAgencyDto {
private:
__published:
};




// ************************************************************************ //
// XML       : ExtendedBankInfo, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ExtendedBankInfo2 : public ExtendedBankInfo {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoAutoProtectionRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoAutoProtectionRequest2 : public KaskoAutoProtectionRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : InsurantPrintDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InsurantPrintDto2 : public InsurantPrintDto {
private:
__published:
};




// ************************************************************************ //
// XML       : DocumentWithValidityDto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DocumentWithValidityDto2 : public DocumentWithValidityDto {
private:
__published:
};




// ************************************************************************ //
// XML       : KaskoAutoProtectionRequestUL, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class KaskoAutoProtectionRequestUL2 : public KaskoAutoProtectionRequestUL {
private:
__published:
};




// ************************************************************************ //
// XML       : DateTimeOffset, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System
// ************************************************************************ //
class DateTimeOffset : public TRemotable {
private:
  TXSDateTime*    FDateTime;
  short           FOffsetMinutes;

public:
  __fastcall ~DateTimeOffset();
__published:
  __property TXSDateTime*   DateTime = { read=FDateTime, write=FDateTime };
  __property short      OffsetMinutes = { read=FOffsetMinutes, write=FOffsetMinutes };
};


typedef DynamicArray<KeyValuePairOfstringArrayOfstringty7Ep6D1*> ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */
typedef DynamicArray<KeyValuePairOfstringstring*> ArrayOfKeyValuePairOfstringstring; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */


// ************************************************************************ //
// XML       : OperationResultOfSelfTestResultBmLUPtsk, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfSelfTestResultBmLUPtsk : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  SelfTestResult* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, SelfTestResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfSelfTestResultBmLUPtsk();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property SelfTestResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfEarlyApproveResultoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfEarlyApproveResultoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  EarlyApproveResult* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, EarlyApproveResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfEarlyApproveResultoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property EarlyApproveResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfCalculateVzdResultoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfCalculateVzdResultoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  CalculateVzdResult* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, CalculateVzdResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfCalculateVzdResultoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property CalculateVzdResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfQuotationStateInfooTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfQuotationStateInfooTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  QuotationStateInfo* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, QuotationStateInfo* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfQuotationStateInfooTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property QuotationStateInfo*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfContractStatusNamesmxVaabBO, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfContractStatusNamesmxVaabBO : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  ContractStatusNames FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, ContractStatusNames _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfContractStatusNamesmxVaabBO();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property ContractStatusNames       Data = { index=(IS_OPTN), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfPrintResult1QqCV82X, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfPrintResult1QqCV82X : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  PrintResult*    FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, PrintResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfPrintResult1QqCV82X();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property PrintResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfCalculationResultoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfCalculationResultoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  CalculationResult* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, CalculationResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfCalculationResultoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property CalculationResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : PrintResult, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models
// ************************************************************************ //
class PrintResult : public TRemotable {
private:
  WideString      FCheckSum;
  bool            FCheckSum_Specified;
  WideString   FDocument;
  bool            FDocument_Specified;
  WideString      FName;
  bool            FName_Specified;
  void __fastcall SetCheckSum(int Index, WideString _prop_val)
  {  FCheckSum = _prop_val; FCheckSum_Specified = true;  }
  bool __fastcall CheckSum_Specified(int Index)
  {  return FCheckSum_Specified;  }
  void __fastcall SetDocument(int Index, WideString _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  }
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  }
__published:
  __property WideString   CheckSum = { index=(IS_OPTN|IS_NLBL), read=FCheckSum, write=SetCheckSum, stored = CheckSum_Specified };
  __property WideString   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
};


typedef DynamicArray<PrintResult*> ArrayOfPrintResult; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models"[GblCplx] */


// ************************************************************************ //
// XML       : OperationResultOfArrayOfPrintResult1QqCV82X, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfPrintResult1QqCV82X : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  ArrayOfPrintResult FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, ArrayOfPrintResult _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfArrayOfPrintResult1QqCV82X();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property ArrayOfPrintResult       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfCalculationResultoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfCalculationResultoTurZuT32 : public OperationResultOfCalculationResultoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfPrintResult1QqCV82X, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfPrintResult1QqCV82X2 : public OperationResultOfPrintResult1QqCV82X {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfContractStatusNamesmxVaabBO, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfContractStatusNamesmxVaabBO2 : public OperationResultOfContractStatusNamesmxVaabBO {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfQuotationStateInfooTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfQuotationStateInfooTurZuT32 : public OperationResultOfQuotationStateInfooTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfCalculateVzdResultoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfCalculateVzdResultoTurZuT32 : public OperationResultOfCalculateVzdResultoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfArrayOfPrintResult1QqCV82X, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfPrintResult1QqCV82X2 : public OperationResultOfArrayOfPrintResult1QqCV82X {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfEarlyApproveResultoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfEarlyApproveResultoTurZuT32 : public OperationResultOfEarlyApproveResultoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfSelfTestResultBmLUPtsk, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfSelfTestResultBmLUPtsk2 : public OperationResultOfSelfTestResultBmLUPtsk {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringArrayOfstringty7Ep6D1, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringArrayOfstringty7Ep6D1 : public TRemotable {
private:
  WideString      Fkey;
  ArrayOfstring   Fvalue;
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property ArrayOfstring      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringstring, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringstring : public TRemotable {
private:
  WideString      Fkey;
  WideString      Fvalue;
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property WideString      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringVehicleAddInformationo_S6zkk9u, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringVehicleAddInformationo_S6zkk9u : public TRemotable {
private:
  WideString      Fkey;
  VehicleAddInformation* Fvalue;

public:
  __fastcall ~KeyValuePairOfstringVehicleAddInformationo_S6zkk9u();
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property VehicleAddInformation*      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringArrayOfstringty7Ep6D1, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringArrayOfstringty7Ep6D12 : public KeyValuePairOfstringArrayOfstringty7Ep6D1 {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringstring, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringstring2 : public KeyValuePairOfstringstring {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringVehicleAddInformationo_S6zkk9u, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringVehicleAddInformationo_S6zkk9u2 : public KeyValuePairOfstringVehicleAddInformationo_S6zkk9u {
private:
__published:
};




// ************************************************************************ //
// XML       : BLTSInsRiskDto, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLTSInsRiskDto : public TRemotable {
private:
  TXSDecimal*     FAdditionalExpensesPrem;
  bool            FAdditionalExpensesPrem_Specified;
  TXSDecimal*     FAdditionalExpensesSum;
  bool            FAdditionalExpensesSum_Specified;
  WideString      FDateFrom;
  bool            FDateFrom_Specified;
  WideString      FDateTo;
  bool            FDateTo_Specified;
  TXSDecimal*     FFranchiseKASCO;
  bool            FFranchiseKASCO_Specified;
  bool            FHasTrailer;
  bool            FHasTrailer_Specified;
  TXSDecimal*     FInsPremiumDSAGO;
  bool            FInsPremiumDSAGO_Specified;
  TXSDecimal*     FInsPremiumNS;
  bool            FInsPremiumNS_Specified;
  TXSDecimal*     FInsSummDSAGO;
  bool            FInsSummDSAGO_Specified;
  TXSDecimal*     FInsSummNS;
  bool            FInsSummNS_Specified;
  TXSDecimal*     FMedicalCarePrem;
  bool            FMedicalCarePrem_Specified;
  TXSDecimal*     FMedicalCareSum;
  bool            FMedicalCareSum_Specified;
  int             FNumber2;
  bool            FNumber2_Specified;
  TXSDecimal*     FPremiumKASCO;
  bool            FPremiumKASCO_Specified;
  TXSDecimal*     FSummKASCO;
  bool            FSummKASCO_Specified;
  TXSDecimal*     FTSPremium;
  bool            FTSPremium_Specified;
  TXSDecimal*     FTSPremiumPeriod;
  bool            FTSPremiumPeriod_Specified;
  TXSDecimal*     FTechnicalAssistancePrem;
  bool            FTechnicalAssistancePrem_Specified;
  TXSDecimal*     FTechnicalAssistanceSum;
  bool            FTechnicalAssistanceSum_Specified;
  void __fastcall SetAdditionalExpensesPrem(int Index, TXSDecimal* _prop_val)
  {  FAdditionalExpensesPrem = _prop_val; FAdditionalExpensesPrem_Specified = true;  }
  bool __fastcall AdditionalExpensesPrem_Specified(int Index)
  {  return FAdditionalExpensesPrem_Specified;  } 
  void __fastcall SetAdditionalExpensesSum(int Index, TXSDecimal* _prop_val)
  {  FAdditionalExpensesSum = _prop_val; FAdditionalExpensesSum_Specified = true;  }
  bool __fastcall AdditionalExpensesSum_Specified(int Index)
  {  return FAdditionalExpensesSum_Specified;  } 
  void __fastcall SetDateFrom(int Index, WideString _prop_val)
  {  FDateFrom = _prop_val; FDateFrom_Specified = true;  }
  bool __fastcall DateFrom_Specified(int Index)
  {  return FDateFrom_Specified;  } 
  void __fastcall SetDateTo(int Index, WideString _prop_val)
  {  FDateTo = _prop_val; FDateTo_Specified = true;  }
  bool __fastcall DateTo_Specified(int Index)
  {  return FDateTo_Specified;  } 
  void __fastcall SetFranchiseKASCO(int Index, TXSDecimal* _prop_val)
  {  FFranchiseKASCO = _prop_val; FFranchiseKASCO_Specified = true;  }
  bool __fastcall FranchiseKASCO_Specified(int Index)
  {  return FFranchiseKASCO_Specified;  } 
  void __fastcall SetHasTrailer(int Index, bool _prop_val)
  {  FHasTrailer = _prop_val; FHasTrailer_Specified = true;  }
  bool __fastcall HasTrailer_Specified(int Index)
  {  return FHasTrailer_Specified;  } 
  void __fastcall SetInsPremiumDSAGO(int Index, TXSDecimal* _prop_val)
  {  FInsPremiumDSAGO = _prop_val; FInsPremiumDSAGO_Specified = true;  }
  bool __fastcall InsPremiumDSAGO_Specified(int Index)
  {  return FInsPremiumDSAGO_Specified;  } 
  void __fastcall SetInsPremiumNS(int Index, TXSDecimal* _prop_val)
  {  FInsPremiumNS = _prop_val; FInsPremiumNS_Specified = true;  }
  bool __fastcall InsPremiumNS_Specified(int Index)
  {  return FInsPremiumNS_Specified;  } 
  void __fastcall SetInsSummDSAGO(int Index, TXSDecimal* _prop_val)
  {  FInsSummDSAGO = _prop_val; FInsSummDSAGO_Specified = true;  }
  bool __fastcall InsSummDSAGO_Specified(int Index)
  {  return FInsSummDSAGO_Specified;  } 
  void __fastcall SetInsSummNS(int Index, TXSDecimal* _prop_val)
  {  FInsSummNS = _prop_val; FInsSummNS_Specified = true;  }
  bool __fastcall InsSummNS_Specified(int Index)
  {  return FInsSummNS_Specified;  } 
  void __fastcall SetMedicalCarePrem(int Index, TXSDecimal* _prop_val)
  {  FMedicalCarePrem = _prop_val; FMedicalCarePrem_Specified = true;  }
  bool __fastcall MedicalCarePrem_Specified(int Index)
  {  return FMedicalCarePrem_Specified;  } 
  void __fastcall SetMedicalCareSum(int Index, TXSDecimal* _prop_val)
  {  FMedicalCareSum = _prop_val; FMedicalCareSum_Specified = true;  }
  bool __fastcall MedicalCareSum_Specified(int Index)
  {  return FMedicalCareSum_Specified;  } 
  void __fastcall SetNumber2(int Index, int _prop_val)
  {  FNumber2 = _prop_val; FNumber2_Specified = true;  }
  bool __fastcall Number2_Specified(int Index)
  {  return FNumber2_Specified;  } 
  void __fastcall SetPremiumKASCO(int Index, TXSDecimal* _prop_val)
  {  FPremiumKASCO = _prop_val; FPremiumKASCO_Specified = true;  }
  bool __fastcall PremiumKASCO_Specified(int Index)
  {  return FPremiumKASCO_Specified;  } 
  void __fastcall SetSummKASCO(int Index, TXSDecimal* _prop_val)
  {  FSummKASCO = _prop_val; FSummKASCO_Specified = true;  }
  bool __fastcall SummKASCO_Specified(int Index)
  {  return FSummKASCO_Specified;  } 
  void __fastcall SetTSPremium(int Index, TXSDecimal* _prop_val)
  {  FTSPremium = _prop_val; FTSPremium_Specified = true;  }
  bool __fastcall TSPremium_Specified(int Index)
  {  return FTSPremium_Specified;  } 
  void __fastcall SetTSPremiumPeriod(int Index, TXSDecimal* _prop_val)
  {  FTSPremiumPeriod = _prop_val; FTSPremiumPeriod_Specified = true;  }
  bool __fastcall TSPremiumPeriod_Specified(int Index)
  {  return FTSPremiumPeriod_Specified;  } 
  void __fastcall SetTechnicalAssistancePrem(int Index, TXSDecimal* _prop_val)
  {  FTechnicalAssistancePrem = _prop_val; FTechnicalAssistancePrem_Specified = true;  }
  bool __fastcall TechnicalAssistancePrem_Specified(int Index)
  {  return FTechnicalAssistancePrem_Specified;  } 
  void __fastcall SetTechnicalAssistanceSum(int Index, TXSDecimal* _prop_val)
  {  FTechnicalAssistanceSum = _prop_val; FTechnicalAssistanceSum_Specified = true;  }
  bool __fastcall TechnicalAssistanceSum_Specified(int Index)
  {  return FTechnicalAssistanceSum_Specified;  } 

public:
  __fastcall ~BLTSInsRiskDto();
__published:
  __property TXSDecimal* AdditionalExpensesPrem = { index=(IS_OPTN|IS_NLBL), read=FAdditionalExpensesPrem, write=SetAdditionalExpensesPrem, stored = AdditionalExpensesPrem_Specified };
  __property TXSDecimal* AdditionalExpensesSum = { index=(IS_OPTN|IS_NLBL), read=FAdditionalExpensesSum, write=SetAdditionalExpensesSum, stored = AdditionalExpensesSum_Specified };
  __property WideString   DateFrom = { index=(IS_OPTN|IS_NLBL), read=FDateFrom, write=SetDateFrom, stored = DateFrom_Specified };
  __property WideString     DateTo = { index=(IS_OPTN|IS_NLBL), read=FDateTo, write=SetDateTo, stored = DateTo_Specified };
  __property TXSDecimal* FranchiseKASCO = { index=(IS_OPTN|IS_NLBL), read=FFranchiseKASCO, write=SetFranchiseKASCO, stored = FranchiseKASCO_Specified };
  __property bool       HasTrailer = { index=(IS_OPTN), read=FHasTrailer, write=SetHasTrailer, stored = HasTrailer_Specified };
  __property TXSDecimal* InsPremiumDSAGO = { index=(IS_OPTN|IS_NLBL), read=FInsPremiumDSAGO, write=SetInsPremiumDSAGO, stored = InsPremiumDSAGO_Specified };
  __property TXSDecimal* InsPremiumNS = { index=(IS_OPTN|IS_NLBL), read=FInsPremiumNS, write=SetInsPremiumNS, stored = InsPremiumNS_Specified };
  __property TXSDecimal* InsSummDSAGO = { index=(IS_OPTN|IS_NLBL), read=FInsSummDSAGO, write=SetInsSummDSAGO, stored = InsSummDSAGO_Specified };
  __property TXSDecimal*  InsSummNS = { index=(IS_OPTN|IS_NLBL), read=FInsSummNS, write=SetInsSummNS, stored = InsSummNS_Specified };
  __property TXSDecimal* MedicalCarePrem = { index=(IS_OPTN|IS_NLBL), read=FMedicalCarePrem, write=SetMedicalCarePrem, stored = MedicalCarePrem_Specified };
  __property TXSDecimal* MedicalCareSum = { index=(IS_OPTN|IS_NLBL), read=FMedicalCareSum, write=SetMedicalCareSum, stored = MedicalCareSum_Specified };
  __property int           Number2 = { index=(IS_OPTN), read=FNumber2, write=SetNumber2, stored = Number2_Specified };
  __property TXSDecimal* PremiumKASCO = { index=(IS_OPTN|IS_NLBL), read=FPremiumKASCO, write=SetPremiumKASCO, stored = PremiumKASCO_Specified };
  __property TXSDecimal*  SummKASCO = { index=(IS_OPTN|IS_NLBL), read=FSummKASCO, write=SetSummKASCO, stored = SummKASCO_Specified };
  __property TXSDecimal*  TSPremium = { index=(IS_OPTN|IS_NLBL), read=FTSPremium, write=SetTSPremium, stored = TSPremium_Specified };
  __property TXSDecimal* TSPremiumPeriod = { index=(IS_OPTN|IS_NLBL), read=FTSPremiumPeriod, write=SetTSPremiumPeriod, stored = TSPremiumPeriod_Specified };
  __property TXSDecimal* TechnicalAssistancePrem = { index=(IS_OPTN|IS_NLBL), read=FTechnicalAssistancePrem, write=SetTechnicalAssistancePrem, stored = TechnicalAssistancePrem_Specified };
  __property TXSDecimal* TechnicalAssistanceSum = { index=(IS_OPTN|IS_NLBL), read=FTechnicalAssistanceSum, write=SetTechnicalAssistanceSum, stored = TechnicalAssistanceSum_Specified };
};


typedef DynamicArray<BLPaymentDto*> ArrayOfBLPaymentDto; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print"[GblCplx] */


// ************************************************************************ //
// XML       : BLPeriodDto, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLPeriodDto : public TRemotable {
private:
  WideString      FDateFrom;
  bool            FDateFrom_Specified;
  WideString      FDateTo;
  bool            FDateTo_Specified;
  ArrayOfBLPaymentDto FHp;
  bool            FHp_Specified;
  TXSDecimal*     FPremium;
  bool            FPremium_Specified;
  void __fastcall SetDateFrom(int Index, WideString _prop_val)
  {  FDateFrom = _prop_val; FDateFrom_Specified = true;  }
  bool __fastcall DateFrom_Specified(int Index)
  {  return FDateFrom_Specified;  } 
  void __fastcall SetDateTo(int Index, WideString _prop_val)
  {  FDateTo = _prop_val; FDateTo_Specified = true;  }
  bool __fastcall DateTo_Specified(int Index)
  {  return FDateTo_Specified;  } 
  void __fastcall SetHp(int Index, ArrayOfBLPaymentDto _prop_val)
  {  FHp = _prop_val; FHp_Specified = true;  }
  bool __fastcall Hp_Specified(int Index)
  {  return FHp_Specified;  } 
  void __fastcall SetPremium(int Index, TXSDecimal* _prop_val)
  {  FPremium = _prop_val; FPremium_Specified = true;  }
  bool __fastcall Premium_Specified(int Index)
  {  return FPremium_Specified;  } 

public:
  __fastcall ~BLPeriodDto();
__published:
  __property WideString   DateFrom = { index=(IS_OPTN|IS_NLBL), read=FDateFrom, write=SetDateFrom, stored = DateFrom_Specified };
  __property WideString     DateTo = { index=(IS_OPTN|IS_NLBL), read=FDateTo, write=SetDateTo, stored = DateTo_Specified };
  __property ArrayOfBLPaymentDto         Hp = { index=(IS_OPTN|IS_NLBL), read=FHp, write=SetHp, stored = Hp_Specified };
  __property TXSDecimal*    Premium = { index=(IS_OPTN|IS_NLBL), read=FPremium, write=SetPremium, stored = Premium_Specified };
};




// ************************************************************************ //
// XML       : BLPaymentDto, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLPaymentDto : public TRemotable {
private:
  WideString      FDate;
  bool            FDate_Specified;
  TXSDecimal*     FValue;
  bool            FValue_Specified;
  void __fastcall SetDate(int Index, WideString _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetValue(int Index, TXSDecimal* _prop_val)
  {  FValue = _prop_val; FValue_Specified = true;  }
  bool __fastcall Value_Specified(int Index)
  {  return FValue_Specified;  } 

public:
  __fastcall ~BLPaymentDto();
__published:
  __property WideString       Date = { index=(IS_OPTN|IS_NLBL), read=FDate, write=SetDate, stored = Date_Specified };
  __property TXSDecimal*      Value = { index=(IS_OPTN|IS_NLBL), read=FValue, write=SetValue, stored = Value_Specified };
};




// ************************************************************************ //
// XML       : AddEquipmentByVehicle, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class AddEquipmentByVehicle : public TRemotable {
private:
  ArrayOfAddEquipmentInfo FAddEquipmentInfo;
  bool            FAddEquipmentInfo_Specified;
  WideString      FVehicleId;
  bool            FVehicleId_Specified;
  void __fastcall SetAddEquipmentInfo(int Index, ArrayOfAddEquipmentInfo _prop_val)
  {  FAddEquipmentInfo = _prop_val; FAddEquipmentInfo_Specified = true;  }
  bool __fastcall AddEquipmentInfo_Specified(int Index)
  {  return FAddEquipmentInfo_Specified;  } 
  void __fastcall SetVehicleId(int Index, WideString _prop_val)
  {  FVehicleId = _prop_val; FVehicleId_Specified = true;  }
  bool __fastcall VehicleId_Specified(int Index)
  {  return FVehicleId_Specified;  } 

public:
  __fastcall ~AddEquipmentByVehicle();
__published:
  __property ArrayOfAddEquipmentInfo AddEquipmentInfo = { index=(IS_OPTN|IS_NLBL), read=FAddEquipmentInfo, write=SetAddEquipmentInfo, stored = AddEquipmentInfo_Specified };
  __property WideString  VehicleId = { index=(IS_OPTN|IS_NLBL), read=FVehicleId, write=SetVehicleId, stored = VehicleId_Specified };
};




// ************************************************************************ //
// XML       : BLInsPeriod, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLInsPeriod : public TRemotable {
private:
  WideString      FDateEnd;
  bool            FDateEnd_Specified;
  WideString      FDateStart;
  bool            FDateStart_Specified;
  TXSDecimal*     FPremium1;
  bool            FPremium1_Specified;
  TXSDecimal*     FPremium2;
  bool            FPremium2_Specified;
  TXSDecimal*     FPremium3;
  bool            FPremium3_Specified;
  TXSDecimal*     FSum1;
  bool            FSum1_Specified;
  TXSDecimal*     FSum2;
  bool            FSum2_Specified;
  TXSDecimal*     FSum3;
  bool            FSum3_Specified;
  void __fastcall SetDateEnd(int Index, WideString _prop_val)
  {  FDateEnd = _prop_val; FDateEnd_Specified = true;  }
  bool __fastcall DateEnd_Specified(int Index)
  {  return FDateEnd_Specified;  } 
  void __fastcall SetDateStart(int Index, WideString _prop_val)
  {  FDateStart = _prop_val; FDateStart_Specified = true;  }
  bool __fastcall DateStart_Specified(int Index)
  {  return FDateStart_Specified;  } 
  void __fastcall SetPremium1(int Index, TXSDecimal* _prop_val)
  {  FPremium1 = _prop_val; FPremium1_Specified = true;  }
  bool __fastcall Premium1_Specified(int Index)
  {  return FPremium1_Specified;  } 
  void __fastcall SetPremium2(int Index, TXSDecimal* _prop_val)
  {  FPremium2 = _prop_val; FPremium2_Specified = true;  }
  bool __fastcall Premium2_Specified(int Index)
  {  return FPremium2_Specified;  } 
  void __fastcall SetPremium3(int Index, TXSDecimal* _prop_val)
  {  FPremium3 = _prop_val; FPremium3_Specified = true;  }
  bool __fastcall Premium3_Specified(int Index)
  {  return FPremium3_Specified;  } 
  void __fastcall SetSum1(int Index, TXSDecimal* _prop_val)
  {  FSum1 = _prop_val; FSum1_Specified = true;  }
  bool __fastcall Sum1_Specified(int Index)
  {  return FSum1_Specified;  } 
  void __fastcall SetSum2(int Index, TXSDecimal* _prop_val)
  {  FSum2 = _prop_val; FSum2_Specified = true;  }
  bool __fastcall Sum2_Specified(int Index)
  {  return FSum2_Specified;  } 
  void __fastcall SetSum3(int Index, TXSDecimal* _prop_val)
  {  FSum3 = _prop_val; FSum3_Specified = true;  }
  bool __fastcall Sum3_Specified(int Index)
  {  return FSum3_Specified;  } 

public:
  __fastcall ~BLInsPeriod();
__published:
  __property WideString    DateEnd = { index=(IS_OPTN|IS_NLBL), read=FDateEnd, write=SetDateEnd, stored = DateEnd_Specified };
  __property WideString  DateStart = { index=(IS_OPTN|IS_NLBL), read=FDateStart, write=SetDateStart, stored = DateStart_Specified };
  __property TXSDecimal*   Premium1 = { index=(IS_OPTN|IS_NLBL), read=FPremium1, write=SetPremium1, stored = Premium1_Specified };
  __property TXSDecimal*   Premium2 = { index=(IS_OPTN|IS_NLBL), read=FPremium2, write=SetPremium2, stored = Premium2_Specified };
  __property TXSDecimal*   Premium3 = { index=(IS_OPTN|IS_NLBL), read=FPremium3, write=SetPremium3, stored = Premium3_Specified };
  __property TXSDecimal*       Sum1 = { index=(IS_OPTN|IS_NLBL), read=FSum1, write=SetSum1, stored = Sum1_Specified };
  __property TXSDecimal*       Sum2 = { index=(IS_OPTN|IS_NLBL), read=FSum2, write=SetSum2, stored = Sum2_Specified };
  __property TXSDecimal*       Sum3 = { index=(IS_OPTN|IS_NLBL), read=FSum3, write=SetSum3, stored = Sum3_Specified };
};




// ************************************************************************ //
// XML       : KaskoPrintRequestDto, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class KaskoPrintRequestDto2 : public KaskoPrintRequestDto {
private:
__published:
};




// ************************************************************************ //
// XML       : BLTSInsRiskDto, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLTSInsRiskDto2 : public BLTSInsRiskDto {
private:
__published:
};




// ************************************************************************ //
// XML       : BLPeriodDto, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLPeriodDto2 : public BLPeriodDto {
private:
__published:
};




// ************************************************************************ //
// XML       : BLPaymentDto, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLPaymentDto2 : public BLPaymentDto {
private:
__published:
};




// ************************************************************************ //
// XML       : AddEquipmentByVehicle, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class AddEquipmentByVehicle2 : public AddEquipmentByVehicle {
private:
__published:
};




// ************************************************************************ //
// XML       : BLInsPeriod, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print
// ************************************************************************ //
class BLInsPeriod2 : public BLInsPeriod {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintResult, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models
// ************************************************************************ //
class PrintResult2 : public PrintResult {
private:
__published:
};




// ************************************************************************ //
// XML       : ProcessStateFault, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Underwriting.Faults
// ************************************************************************ //
class ProcessStateFault : public TRemotable {
private:
  Variant         FCurrentState;
  bool            FCurrentState_Specified;
  Variant         FNextState;
  bool            FNextState_Specified;
  void __fastcall SetCurrentState(int Index, Variant _prop_val)
  {  FCurrentState = _prop_val; FCurrentState_Specified = true;  }
  bool __fastcall CurrentState_Specified(int Index)
  {  return FCurrentState_Specified;  } 
  void __fastcall SetNextState(int Index, Variant _prop_val)
  {  FNextState = _prop_val; FNextState_Specified = true;  }
  bool __fastcall NextState_Specified(int Index)
  {  return FNextState_Specified;  } 
__published:
  __property Variant    CurrentState = { index=(IS_OPTN|IS_NLBL), read=FCurrentState, write=SetCurrentState, stored = CurrentState_Specified };
  __property Variant     NextState = { index=(IS_OPTN|IS_NLBL), read=FNextState, write=SetNextState, stored = NextState_Specified };
};




// ************************************************************************ //
// XML       : ProcessStateFault, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Underwriting.Faults
// Info      : Fault
// Base Types: ProcessStateFault
// ************************************************************************ //
class ProcessStateFault2 : public ERemotableException {
private:
  Variant         FCurrentState;
  bool            FCurrentState_Specified;
  Variant         FNextState;
  bool            FNextState_Specified;
  void __fastcall SetCurrentState(int Index, Variant _prop_val)
  {  FCurrentState = _prop_val; FCurrentState_Specified = true;  }
  bool __fastcall CurrentState_Specified(int Index)
  {  return FCurrentState_Specified;  } 
  void __fastcall SetNextState(int Index, Variant _prop_val)
  {  FNextState = _prop_val; FNextState_Specified = true;  }
  bool __fastcall NextState_Specified(int Index)
  {  return FNextState_Specified;  } 
__published:
  __property Variant    CurrentState = { index=(IS_OPTN|IS_NLBL), read=FCurrentState, write=SetCurrentState, stored = CurrentState_Specified };
  __property Variant     NextState = { index=(IS_OPTN|IS_NLBL), read=FNextState, write=SetNextState, stored = NextState_Specified };
};




// ************************************************************************ //
// XML       : DateTimeOffset, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System
// ************************************************************************ //
class DateTimeOffset2 : public DateTimeOffset {
private:
__published:
};


typedef DynamicArray<SelfTestResult*> ArrayOfSelfTestResult; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces"[GblCplx] */


// ************************************************************************ //
// XML       : SelfTestResult, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces
// ************************************************************************ //
class SelfTestResult : public TRemotable {
private:
  ArrayOfSelfTestResult FChildren;
  bool            FChildren_Specified;
  WideString      FError;
  bool            FError_Specified;
  WideString      FName;
  bool            FName_Specified;
  void __fastcall SetChildren(int Index, ArrayOfSelfTestResult _prop_val)
  {  FChildren = _prop_val; FChildren_Specified = true;  }
  bool __fastcall Children_Specified(int Index)
  {  return FChildren_Specified;  } 
  void __fastcall SetError(int Index, WideString _prop_val)
  {  FError = _prop_val; FError_Specified = true;  }
  bool __fastcall Error_Specified(int Index)
  {  return FError_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 

public:
  __fastcall ~SelfTestResult();
__published:
  __property ArrayOfSelfTestResult   Children = { index=(IS_OPTN|IS_NLBL), read=FChildren, write=SetChildren, stored = Children_Specified };
  __property WideString      Error = { index=(IS_OPTN|IS_NLBL), read=FError, write=SetError, stored = Error_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
};




// ************************************************************************ //
// XML       : SelfTestResult, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces
// ************************************************************************ //
class SelfTestResult2 : public SelfTestResult {
private:
__published:
};



// ************************************************************************ //
// Namespace : Rgs.Ufo
// soapAction: Rgs.Ufo/IKaskoProxyService/%operationName%
// transport : http://schemas.xmlsoap.org/soap/http
// style     : document
// binding   : BasicHttpsBinding_IKaskoProxyService
// service   : KaskoProxyService
// port      : BasicHttpsBinding_IKaskoProxyService
// URL       : https://ufot.rgs.ru:8443/KaskoProxyService.svc
// ************************************************************************ //
__interface INTERFACE_UUID("{5B0C80F8-36AC-CFE7-3E28-6E3729C01F95}") IKaskoProxyService : public IInvokable
{
public:
  virtual OperationResultOfCalculationResultoTurZuT3* Calculate(const User* user, const CalculationRequest* kaskoCalculationRequest) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintCertificate(const User* user, const PrintRequest* request) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintApplication(const User* user, const PrintAppRequest* request) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintApplicationUl(const User* user, const PrintAppRequestUl* request) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintContract(const User* user, const PrintContractRequest* request) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintContractUl(const User* user, const KaskoPrintContractUlRequestDto* request) = 0; 
  virtual OperationResultOfContractStatusNamesmxVaabBO* SendToApprove(const User* user, const UnderwritingAdditionalInfo* additionalInfo) = 0; 
  virtual OperationResultOfContractStatusNamesmxVaabBO* Withdraw(const User* user, const guid quotationId) = 0; 
  virtual OperationResultOfQuotationStateInfooTurZuT3* CheckStatus(const User* user, const guid quotationId) = 0; 
  virtual OperationResultOfCalculateVzdResultoTurZuT3* CalculateVzd(const User* user, const CalculateVzdRequest* request) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintULAddAgreement(const User* user, const PrintULAddAgreementRequest* request) = 0; 
  virtual OperationResultOfArrayOfPrintResult1QqCV82X* PrintULBLAddAgreement(const User* user, const PrintULBLAddAgreementRequest* request) = 0; 
  virtual OperationResultOfEarlyApproveResultoTurZuT3* EarlyApprove(const User* user, const EarlyApproveInfo* earlyApproveInfo) = 0; 
  virtual OperationResultOfPrintResult1QqCV82X* PrintCalculationSheet(const User* user, const CalculationSheet* request) = 0; 
  virtual OperationResultOfArrayOfPrintResult1QqCV82X* PrintKaskoFLSpecial(const User* user, const KaskoFLSpecialRequest* request) = 0; 
  virtual OperationResultOfArrayOfPrintResult1QqCV82X* PrintAutoProtectionPolicy(const User* user, const KaskoAutoProtectionRequest* request) = 0; 
  virtual OperationResultOfArrayOfPrintResult1QqCV82X* PrintAutoProtectionPolicyUL(const User* user, const KaskoAutoProtectionRequestUL* request) = 0; 
  virtual DateTimeOffset* Ping() = 0; 
  virtual OperationResultOfSelfTestResultBmLUPtsk* SelfTest(const User* user) = 0; 
};
typedef DelphiInterface<IKaskoProxyService> _di_IKaskoProxyService;

_di_IKaskoProxyService GetIKaskoProxyService(bool useWSDL=false, AnsiString addr="", THTTPRIO* HTTPRIO=0);


};     // NS_KaskoProxyService

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace NS_KaskoProxyService;
#endif



#endif // KaskoProxyServiceH
