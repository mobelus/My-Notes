//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UForm_FastRep_CalcId.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sComboBox"
#pragma resource "*.dfm"
TForm_CalcId *Form_CalcId;

//extern sqlHelper::sql _sql;
//---------------------------------------------------------------------------

__fastcall TForm_CalcId::TForm_CalcId(TComponent* Owner, mops_api_027 *api, const long id)
    : TForm(Owner),
        m_api(api),
       _calc_id(-1),
        list(NULL)
{
    list = new TStringList();

    AnsiString queryStr;

    long module_id = m_api->module_id;

//    queryStr = _sql.SELECT("*").FROM(_mops_calcs_).WHERE("id_module=%i", module_id).AND("NoErrors<>0").AND("deleted=0").ORDER_BY("id DESC");
// ����� �� ��-�� _sql ��� ��������... 

    queryStr = "SELECT * FROM _mops_calcs_ WHERE id_module=" + IntToStr(module_id) + " AND NoErrors<>0 AND deleted=0 ORDER_BY id DESC";

    m_api->Fill_ComboBox_Text(_res, cBox, list, queryStr, "id", "num_rash_rm_prod");

    if( list->Count > 0 )
    {
        cBox->ItemIndex = 0;
        cBoxSelect(NULL);
    }
}
//---------------------------------------------------------------------------

long TForm_CalcId::get_CalcId()
{
    return _calc_id;
}
//---------------------------------------------------------------------------

void __fastcall TForm_CalcId::Button1Click(TObject *Sender)
{
    ModalResult = mrOk;

    return;
}
//---------------------------------------------------------------------------

void __fastcall TForm_CalcId::FormClose(TObject *Sender, TCloseAction &Action)
{
    if( list )
        delete list;
}
//---------------------------------------------------------------------------

void __fastcall TForm_CalcId::cBoxSelect(TObject *Sender)
{
    int index = cBox->ItemIndex;

    AnsiString str = list->Strings[index];

   _calc_id = StrToInt(str);

    return;
}
//---------------------------------------------------------------------------

