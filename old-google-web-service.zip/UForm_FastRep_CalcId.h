//---------------------------------------------------------------------------

#ifndef UForm_FastRep_CalcIdH
#define UForm_FastRep_CalcIdH
//---------------------------------------------------------------------------

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <sComboBox.hpp>


#include "Globals.h"
#include "tools.h"
#include "Tmops_api.h"
#include "__sqlHelper.h"

//---------------------------------------------------------------------------

class TForm_CalcId : public TForm
{
__published:	// IDE-managed Components
    TsComboBox  *cBox;
    TButton     *Button1;
    TLabel      *Label1;
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall cBoxSelect(TObject *Sender);

private:	// User declarations
    mops_api_027    *m_api;
    TStringList     *list;    
    long            _calc_id;
    int             _res;

public:		// User declarations
    __fastcall TForm_CalcId(TComponent* Owner, mops_api_027 *, const long);

    long get_CalcId();     
};
//---------------------------------------------------------------------------
extern PACKAGE TForm_CalcId *Form_CalcId;
//---------------------------------------------------------------------------
#endif

