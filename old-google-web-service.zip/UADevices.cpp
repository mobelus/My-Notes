//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UADevices.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxControls"
#pragma link "cxDBEditRepository"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma resource "*.dfm"
TfrmADevices *frmADevices;
//---------------------------------------------------------------------------
__fastcall TfrmADevices::TfrmADevices(TComponent* Owner, mops_api_028 *_m_api, AddDevice *p_adevices) : TForm(Owner), m_api(_m_api), adevice(p_adevices)
{
   q_equip = m_api->dbGetCursor(res, "select * from type_equip order by equip_id");
   DataSource1->DataSet = q_equip;
   LookupComboBoxItem->Properties->ListSource = DataSource1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::FormDestroy(TObject *Sender)
{
   m_api->dbCloseCursor(res, q_equip);   
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::FormShow(TObject *Sender)
{
   if(btn) adevice_temp = adevice[Tag];
   if(adevice[Tag].id) vg_Position->Properties->Value = adevice[Tag].id;
   else{
      vg_Position->Properties->RepositoryItem = 0;
      vg_Position->Properties->RepositoryItem = LookupComboBoxItem;
      vg_Position->Properties->Value = variant_null;
   }
   vg_WhatIsIt->Properties->Value = adevice[Tag].name_detail;
   vg_Cost->Properties->Value = adevice[Tag].cost;

   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::btnCancelClick(TObject *Sender)
{
   ModalResult = IDCANCEL;
   Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties)
{
   labHint->Visible = false;
   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::CurrencyItemPropertiesChange(TObject *Sender)
{
   if(vg->FocusedRow && vg->InplaceEditor){
      labHint->Top = vg_Cost->ViewInfo->RowRect.Top + 2;
      labHint->Visible = true;
   }
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   Error = false;

   switch(vg->FocusedRow->Tag)
   {
      case 2:                                  
         AnsiString strDisplayValue = AnsiString(DisplayValue);
         //strDisplayValue = strDisplayValue.SubString(0, strDisplayValue.Length() - 2); // remove 2 symbols "p."
         strDisplayValue = NormalizeSummWithDotToNumberStr(strDisplayValue);
         adevice[Tag].cost = strDisplayValue.ToDouble(); //DisplayValue;
         Validate();
         DisplayValue = adevice[Tag].cost;
         break;
   }
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::LookupComboBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   if(vg_Position->Properties->Value.IsNull()){ adevice[Tag].id = 0; adevice[Tag].name_dict = empty_str; }
   else{
      adevice[Tag].id = vg_Position->Properties->Value;
      adevice[Tag].name_dict = LookupComboBoxItem->Properties->ListSource->DataSet->Lookup("equip_id", adevice[Tag].id , "equip_name");
   }

   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::TextItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();

   labHint->Top = vg_Cost->ViewInfo->RowRect.Top + 2;
   labHint->Visible = true;

   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   switch(r->Tag){
      case 1: adevice[Tag].name_detail = val.IsNull() ? empty_str : AnsiString(val); break;
   }

}
//---------------------------------------------------------------------------
void __fastcall TfrmADevices::btnOKClick(TObject *Sender)
{
   ModalResult = IDOK;  
}
//---------------------------------------------------------------------------
void TfrmADevices::Validate()
{
   btnCancel->Enabled = !btn || adevice[Tag] == adevice_temp;

   btnOK->Enabled = adevice[Tag].id > 0 && adevice[Tag].cost > 0;
}
//---------------------------------------------------------------------------

