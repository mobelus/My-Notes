//---------------------------------------------------------------------------


#ifndef itogiH
#define itogiH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TfrmItogi : public TFrame{
__published:	// IDE-managed Components
   TMemo *memoItogi;
   TListBox *lbNonStdText;
private:	// User declarations
public:		// User declarations
    __fastcall TfrmItogi(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmItogi *frmItogi;
//---------------------------------------------------------------------------
#endif
