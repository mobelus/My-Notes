//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UPayment.h"
#include "UReissCalc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma resource "*.dfm"
TfrmPayment *frmPayment;
//---------------------------------------------------------------------------
__fastcall TfrmPayment::TfrmPayment(TComponent* Owner, Dogovor_Info *p_di) : TForm(Owner), f_reiss((TFReissCalc*)Owner), di(p_di)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment::FormShow(TObject *Sender)
{
   vg_PaymentSum->Properties->Value = payment_sum = di->calc_info.payment_part[Tag];
   if(di->payment_date[Tag].Val) vg_PaymentDate->Properties->Value = payment_date = di->payment_date[Tag];
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment::btnOKClick(TObject *Sender)
{
   if(payment_sum && payment_date.Val){
      di->calc_info.payment_part[Tag] = payment_sum;
      di->payment_date[Tag] = payment_date;
      btn_row->Properties->Value  = IntToStr(Tag + 1) + "-� ��������� �����: ����� - " + FormatFloat(",0.00�'.';-,0.00�'.'", di->calc_info.payment_part[Tag]) + ", ���� - " + di->payment_date[Tag].DateString();
      f_reiss->vg->FocusRow(f_reiss->vg_Phone, f_reiss->vg_Phone->Index);
      f_reiss->Recalc();
   }
   Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment::btnCancelClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment::CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   Error = false;
   payment_sum = DisplayValue;
   DisplayValue = payment_sum;
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment::DateItemPropertiesEditValueChanged(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   Variant val = vg_PaymentDate->Properties->Value;
   if(!val.IsNull()){
      AnsiString dt_str = val;
      if(dt_str.Length() < 10 || !TryStrToDate(dt_str, payment_date)) payment_date.Val = 0;
   }
   else payment_date.Val = 0;
}
//---------------------------------------------------------------------------
