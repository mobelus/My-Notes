//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UViewHistory.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SHDocVw_OCX"
#pragma resource "*.dfm"
TfrmViewHistory *frmViewHistory;
//---------------------------------------------------------------------------
__fastcall TfrmViewHistory::TfrmViewHistory(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------


