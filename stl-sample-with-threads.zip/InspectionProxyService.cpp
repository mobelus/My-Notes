// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>0
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>1
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>2
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>3
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>4
// Encoding : utf-8
// Version  : 1.0
// (16.02.2017 17:51:45 - - $Rev: 16699 $)
// ************************************************************************ //

#include "UWriteSoap.h"
#pragma hdrstop

#if !defined(InspectionProxyServiceH)
#include "InspectionProxyService.h"
#endif



namespace NS_InspectionProxyService {

_di_IInspectionProxyService GetIInspectionProxyService(bool useWSDL, AnsiString addr, THTTPRIO* HTTPRIO)
{
  static const char* defWSDL= "https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl";
  static const char* defURL = "https://ufot.rgs.ru:8443/InspectionProxyService.svc";
  static const char* defSvc = "InspectionProxyService";
  static const char* defPrt = "BasicHttpsBinding_IInspectionProxyService";
  if (addr=="")
	 addr = useWSDL ? defWSDL : defURL;

  rio_be rbe;
  THTTPRIO *rio = HTTPRIO ? HTTPRIO : new THTTPRIO(0);

  rio->OnBeforeExecute = rbe.HTTPRIOBeforeExecute;
  rio->OnAfterExecute = rbe.HTTPRIOAfterExecute;

  if (useWSDL) {
    rio->WSDLLocation = addr;
    rio->Service = defSvc;
    rio->Port = defPrt;
  } else {
    rio->URL = addr;
  }
  _di_IInspectionProxyService service;
  rio->QueryInterface(service);
  if (!service && !HTTPRIO)
    delete rio;
  return service;
}


__fastcall Inspection::~Inspection()
{
  delete FCreationDate;
  for(int i=0; i<FDocuments.Length; i++)
    if (FDocuments[i])
      delete FDocuments[i];
  for(int i=0; i<FHistory.Length; i++)
    if (FHistory[i])
      delete FHistory[i];
}

__fastcall InspectionDocument::~InspectionDocument()
{
  delete FLoadDate;
  delete FMetaData;
  delete FModificationDate;
}

__fastcall HistoryItem::~HistoryItem()
{
  delete FDate;
}

__fastcall OperationResultOfInspectionDocumentoTurZuT3::~OperationResultOfInspectionDocumentoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfArrayOfInspectionoTurZuT3::~OperationResultOfArrayOfInspectionoTurZuT3()
{
  for(int i=0; i<FData.Length; i++)
    if (FData[i])
      delete FData[i];
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfboolean::~OperationResultOfboolean()
{
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfInspectionoTurZuT3::~OperationResultOfInspectionoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfguid::~OperationResultOfguid()
{
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfdateTime::~OperationResultOfdateTime()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

// ************************************************************************ //
// This routine registers the interfaces and types exposed by the WebService.
// ************************************************************************ //
static void RegTypes()
{
  /* IInspectionProxyService */
  InvRegistry()->RegisterInterface(__delphirtti(IInspectionProxyService), L"Rgs.Ufo", L"utf-8");
  InvRegistry()->RegisterDefaultSOAPAction(__delphirtti(IInspectionProxyService), L"Rgs.Ufo/IInspectionProxyService/%operationName%");
  InvRegistry()->RegisterInvokeOptions(__delphirtti(IInspectionProxyService), ioDocument);
  /* User */
  RemClassRegistry()->RegisterXSClass(__classid(User), L"Rgs.Ufo", L"User");
  /* ArrayOfInspectionDocument */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfInspectionDocument), L"Rgs.Ufo", L"ArrayOfInspectionDocument");
  /* ArrayOfHistoryItem */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfHistoryItem), L"Rgs.Ufo", L"ArrayOfHistoryItem");
  /* Inspection */
  RemClassRegistry()->RegisterXSClass(__classid(Inspection), L"Rgs.Ufo", L"Inspection");
  /* InspectionDocumentInput */
  RemClassRegistry()->RegisterXSClass(__classid(InspectionDocumentInput), L"Rgs.Ufo", L"InspectionDocumentInput");
  /* InspectionDocument */
  RemClassRegistry()->RegisterXSClass(__classid(InspectionDocument), L"Rgs.Ufo", L"InspectionDocument");
  /* ImgMetaData */
  RemClassRegistry()->RegisterXSClass(__classid(ImgMetaData), L"Rgs.Ufo", L"ImgMetaData");
  /* HistoryItem */
  RemClassRegistry()->RegisterXSClass(__classid(HistoryItem), L"Rgs.Ufo", L"HistoryItem");
  /* SearchParameters */
  RemClassRegistry()->RegisterXSClass(__classid(SearchParameters), L"Rgs.Ufo", L"SearchParameters");
  /* ArrayOfInspection */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfInspection), L"Rgs.Ufo", L"ArrayOfInspection");
  /* User */
  RemClassRegistry()->RegisterXSClass(__classid(User2), L"Rgs.Ufo", L"User2", L"User");
  /* Inspection */
  RemClassRegistry()->RegisterXSClass(__classid(Inspection2), L"Rgs.Ufo", L"Inspection2", L"Inspection");
  /* InspectionDocument */
  RemClassRegistry()->RegisterXSClass(__classid(InspectionDocument2), L"Rgs.Ufo", L"InspectionDocument2", L"InspectionDocument");
  /* InspectionDocumentInput */
  RemClassRegistry()->RegisterXSClass(__classid(InspectionDocumentInput2), L"Rgs.Ufo", L"InspectionDocumentInput2", L"InspectionDocumentInput");
  /* ImgMetaData */
  RemClassRegistry()->RegisterXSClass(__classid(ImgMetaData2), L"Rgs.Ufo", L"ImgMetaData2", L"ImgMetaData");
  /* HistoryItem */
  RemClassRegistry()->RegisterXSClass(__classid(HistoryItem2), L"Rgs.Ufo", L"HistoryItem2", L"HistoryItem");
  /* SearchParameters */
  RemClassRegistry()->RegisterXSClass(__classid(SearchParameters2), L"Rgs.Ufo", L"SearchParameters2", L"SearchParameters");
  /* ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* ArrayOfKeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringstring");
  /* ArrayOfstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfstring), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfstring");
  /* OperationResultOfInspectionDocumentoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfInspectionDocumentoTurZuT3), L"RGS.UFO", L"OperationResultOfInspectionDocumentoTurZuT3");
  /* OperationResultOfArrayOfInspectionoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfInspectionoTurZuT3), L"RGS.UFO", L"OperationResultOfArrayOfInspectionoTurZuT3");
  /* OperationResultOfboolean */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfboolean), L"RGS.UFO", L"OperationResultOfboolean");
  /* OperationResultOfInspectionoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfInspectionoTurZuT3), L"RGS.UFO", L"OperationResultOfInspectionoTurZuT3");
  /* OperationResultOfguid */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfguid), L"RGS.UFO", L"OperationResultOfguid");
  /* OperationResultOfdateTime */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfdateTime), L"RGS.UFO", L"OperationResultOfdateTime");
  /* OperationResultOfdateTime */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfdateTime2), L"RGS.UFO", L"OperationResultOfdateTime2", L"OperationResultOfdateTime");
  /* OperationResultOfguid */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfguid2), L"RGS.UFO", L"OperationResultOfguid2", L"OperationResultOfguid");
  /* OperationResultOfInspectionoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfInspectionoTurZuT32), L"RGS.UFO", L"OperationResultOfInspectionoTurZuT32", L"OperationResultOfInspectionoTurZuT3");
  /* OperationResultOfboolean */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfboolean2), L"RGS.UFO", L"OperationResultOfboolean2", L"OperationResultOfboolean");
  /* OperationResultOfArrayOfInspectionoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfInspectionoTurZuT32), L"RGS.UFO", L"OperationResultOfArrayOfInspectionoTurZuT32", L"OperationResultOfArrayOfInspectionoTurZuT3");
  /* OperationResultOfInspectionDocumentoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfInspectionDocumentoTurZuT32), L"RGS.UFO", L"OperationResultOfInspectionDocumentoTurZuT32", L"OperationResultOfInspectionDocumentoTurZuT3");
  /* KeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* KeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringstring");
  /* KeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringArrayOfstringty7Ep6D12), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringArrayOfstringty7Ep6D12", L"KeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* KeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringstring2), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringstring2", L"KeyValuePairOfstringstring");
  /* ArrayOfInspectionDocument */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfInspectionDocument), L"Rgs.Ufo", L"ArrayOfInspectionDocument");
  /* ArrayOfKeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringstring");
  /* ArrayOfHistoryItem */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfHistoryItem), L"Rgs.Ufo", L"ArrayOfHistoryItem");
  /* ArrayOfInspection */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfInspection), L"Rgs.Ufo", L"ArrayOfInspection");
  /* ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* ArrayOfstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfstring), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfstring");
}
#pragma startup RegTypes 32

};     // NS_InspectionProxyService

