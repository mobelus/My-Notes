//---------------------------------------------------------------------------
#ifndef UAddPermittedH
#define UAddPermittedH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <ToolWin.hpp>
#include <OleCtrls.hpp>
#include <DB.hpp>

#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "cxControls.hpp"
#include "cxDBEditRepository.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxTextEdit.hpp"
#include "cxVGrid.hpp"

#include "TMops_api.h"
#include "SHDocVw_OCX.h"
//#include "tools.h"
#include "structures.h"

//---------------------------------------------------------------------------
class TfrmAddPermitted : public TForm
{
__published:	// IDE-managed Components
   TcxButton *btnOK;
   TcxButton *btnCancel;
   TMainMenu *MainMenu1;
   TMenuItem *N1;
   TLabel *Label1;
   TDataSource *DataSource1;
   TcxEditRepository *cxEditRepository1;
   TcxEditRepositoryTextItem *TextItem;
   TcxEditRepositoryRadioGroupItem *RGItemSex;
   TcxEditRepositoryLookupComboBoxItem *LookupComboBoxItem;
   TcxEditRepositoryRadioGroupItem *RGItemDoc;
   TcxEditRepositoryMaskItem *MaskItemSeries;
   TcxEditRepositoryMaskItem *MaskItemNumber;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *cxStyle3;
   TcxEditRepositoryDateItem *DateItem;
   TcxVerticalGrid *vg;
   TcxEditorRow *rgPmSex;
   TcxEditorRow *editPmLastName;
   TcxEditorRow *editPmFirstName;
   TcxEditorRow *editPmSecondName;
   TcxEditorRow *deditPmBirthDate;
   TcxEditorRow *deditPmStartDriving;
   TcxEditorRow *rgPmDocType;
   TcxEditorRow *editPmDocSeria;
   TcxEditorRow *editPmDocNumber;
   TcxEditorRow *cboxPmRegion;
   TStaticText *labHint;
   TcxCategoryRow *vgInfoRow;
   TcxStyle *cxStyle4;
    TLabel *labHintSize;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall btnCancelClick(TObject *Sender);
   void __fastcall btnOKClick(TObject *Sender);
   void __fastcall btnCopyDataClick(TObject *Sender);
   void __fastcall RGItemSexPropertiesChange(TObject *Sender);
   void __fastcall RGItemDocPropertiesChange(TObject *Sender);
   void __fastcall LookupComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall TextItemPropertiesChange(TObject *Sender);
   void __fastcall DateItemPropertiesEditValueChanged(TObject *Sender);
   void __fastcall DateItemPropertiesChange(TObject *Sender);
   void __fastcall vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties);
   void __fastcall DateItemPropertiesValidate(TObject *Sender,
          Variant &DisplayValue, TCaption &ErrorText, bool &Error);
    void __fastcall vgEditValueChanged(TObject *Sender,
          TcxCustomEditorRowProperties *ARowProperties);
    void __fastcall editPmLastNameEditPropertiesChange(TObject *Sender);
    void __fastcall editPmLastNameEditPropertiesEditValueChanged(
          TObject *Sender);
    void __fastcall editPmLastNameEditPropertiesValidate(TObject *Sender,
          Variant &DisplayValue, TCaption &ErrorText, bool &Error);
private:	// User declarations
   enum BTN_CLICKED
   {
      BTN_EMPTY = -1,
      BTN_ADD   = 0,
      BTN_EDIT  = 1,
      //BTN_DEL   = 2
   };
   int res, pm_region_id, btn;
   char ds;
   AnsiString shdf;

   mops_api_028 *m_api;
   TADOQuery *q_regions, *q_bl;

   PersonInfo *pm, *pi, pm_temp;
   Dogovor_Info *di;
   //TSInfo *tsi;
   VehicleInfo *tsi;

   _di_IXMLDocument XMLDoc;
   _di_IXMLNode Root;

   std::map<int, OsagoInfo> oi_section_of_years;
private:
   void CalcK1();
   void CheckBlackList();
   void Validate();
   void setEnabledControls();
   void resizeLabHint(AnsiString str);    // ��� ���������� ��������� �� ���� ���������� ������� �������� ���� ����-����

   int defaultLabHintLeft;


public:		// User declarations
   //__fastcall TfrmAddPermitted(TComponent* Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di, TSInfo *p_tsi, TADOQuery *p_q_bl);
   __fastcall TfrmAddPermitted(TComponent* Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di, VehicleInfo *p_tsi, TADOQuery *p_q_bl);
   void SetButtonPress(const int who)
   {
     btn = who;
   }
   bool DataToXML();
   AnsiString GetXML(){ return XMLDoc->GetXML()->Text; }
   void CalcK6(const AnsiString& xml_text);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmAddPermitted *frmAddPermitted;
//---------------------------------------------------------------------------
#endif
