//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "UAddPermitted.h"
#include "DateUtils.hpp"
#include "UThreadK5.h"
//#include "newcalc.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "SHDocVw_OCX"
#pragma link "cxControls"
#pragma link "cxDBEditRepository"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxStyles"
#pragma link "cxTextEdit"
#pragma link "cxVGrid"
#pragma resource "*.dfm"
TfrmAddPermitted *frmAddPermitted;


void __fastcall TfrmAddPermitted::vgEditValueChanged(TObject *Sender,
      TcxCustomEditorRowProperties *ARowProperties)
{
   vg->InplaceEditor->PostEditValue();

   //Variant val = r->Properties->Value;
   //AnsiString s___(val.VOleStr);
   //AnsiString sTst;
   //VarToStrDef(val, sTst);

   //TcxEditorRow* row = static_cast<TcxEditorRow*>(ARowProperties->Row);
   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   AnsiString valStr = val.IsNull() ? empty_str : AnsiString(val);

   switch(r->Tag)
   {
      case 2: pm[Tag].lastname   = valStr; break; //editPmLastName
      case 3: pm[Tag].firstname  = valStr; break; //editPmFirstName
      case 4: pm[Tag].secondname = valStr; break; //editPmSecondName
      case 8: pm[Tag].doc_seria  = valStr; break; //editPmDocSeria
      case 9: pm[Tag].doc_number = valStr; break; //editPmDocNumber
   }

   Validate();
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//__fastcall TfrmAddPermitted::TfrmAddPermitted(TComponent *Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di, TSInfo *p_tsi, TADOQuery *p_q_bl) :
__fastcall TfrmAddPermitted::TfrmAddPermitted(TComponent *Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di, VehicleInfo *p_tsi, TADOQuery *p_q_bl) :
            TForm(Owner), m_api(_m_api), pm(p_pm), pi(p_pi), di(p_di), tsi(p_tsi), q_bl(p_q_bl), pm_region_id(0), btn(BTN_EMPTY), defaultLabHintLeft(labHint->Left)
{
   XMLDoc = NewXMLDocument();
   XMLDoc->Active = true;
   XMLDoc->Options.Clear();
   XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;
   XMLDoc->Version       = "1.0";
   XMLDoc->Encoding      = "WINDOWS-1251";
   XMLDoc->StandAlone    = "no";

   Root = XMLDoc->CreateNode("request");
   XMLDoc->DocumentElement = Root;
   Root = XMLDoc->DocumentElement;

   /*q_regions = m_api->dbGetCursor(res, "select [id],[subject_federation_name] from gl_dict_subject_rf where [id] < 100 order by [subject_federation_name]");
   DataSource1->DataSet = q_regions;
   LookupComboBoxItem->Properties->ListSource = DataSource1;*/
}


//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::FormShow(TObject *Sender)
{
   if(btn) pm_temp = pm[Tag];

   int iTag = Tag;
   AnsiString s_01 = pm[Tag].lastname;
   AnsiString s_02 = pm[Tag].firstname;
   AnsiString s_03 = pm[Tag].secondname;
   AnsiString s_04 = pm[Tag].birthdate;
   AnsiString s_05 = pm[Tag].doc_issue_date;
   AnsiString s_06 = pm[Tag].doc_seria;
   AnsiString s_07 = pm[Tag].doc_number;

   rgPmSex->Properties->Value = pm[Tag].sex > 0 ? RGItemSex->Properties->Items->Items[pm[Tag].sex - 1]->Caption : empty_str;
   editPmLastName->Properties->Value = pm[Tag].lastname;
   editPmFirstName->Properties->Value = pm[Tag].firstname;
   editPmSecondName->Properties->Value = pm[Tag].secondname;
   SetValueRowDateEdit(deditPmBirthDate, pm[Tag].birthdate);
   SetValueRowDateEdit(deditPmStartDriving, pm[Tag].doc_issue_date);
   rgPmDocType->Properties->Value = RGItemDoc->Properties->Items->Items[GetIndexItemByTag(RGItemDoc->Properties->Items, pm[Tag].doc_type)]->Caption;
   ////ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag, pm[Tag].doc_seria, pm[Tag].doc_number);

   AnsiString s_1 = StringReplace(pm[Tag].doc_seria, space_str, empty_str, rf);
   AnsiString s_2 = pm[Tag].doc_number;

   editPmDocSeria->Properties->Value = StringReplace(pm[Tag].doc_seria, space_str, empty_str, rf);
   editPmDocNumber->Properties->Value = pm[Tag].doc_number;
   /*if(!pm[Tag].address.IsEmpty()) cboxPmRegion->Properties->Value = pm_region_id = LookupComboBoxItem->Properties->ListSource->DataSet->Lookup("subject_federation_name", pm[Tag].address, "id");
   else{
      cboxPmRegion->Properties->RepositoryItem = 0;
      cboxPmRegion->Properties->RepositoryItem = LookupComboBoxItem;
      cboxPmRegion->Properties->Value = variant_null;

      pm_region_id = 0;
   } */

   //������� ����� ��� ������ ��� ����, ����� ���������� ������ ������ � ������� ����-��������, ��� ��� ������ ���� �� ������� ��������� ������
   labHintSize->Top = 2000;
   labHintSize->Left = 2000;

   setEnabledControls();

   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::FormDestroy(TObject *Sender)
{
   delete XMLDoc;
   //m_api->dbCloseCursor(res, q_regions);
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::btnCancelClick(TObject *Sender)
{
   Close();

   ModalResult = IDCANCEL;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::btnOKClick(TObject *Sender)
{
//   btnOK->Enabled     = false;
//   btnCancel->Enabled = false;

   DataToXML();

   CheckBlackList();

   CalcK1();
   //ShowMessage(XMLDoc->GetXML()->Text);
   //XMLDoc->SaveToFile("F:\\Dmitriev.xml");

   ModalResult = IDOK;

//   if(
///* // TSInfo
//   di->no_calc_k5
//*/
//   di->no_calc
///* //#include "newcalc.h"
//   || m_api->Err_Get_Shown_Error_Text(res, dynamic_cast<TFrameNew*>(Owner)) == "������ �� ������������ � �� ����������. ���������� ���� ��������� ������ � ���."
////*/
//   )
//   {
//      pm[Tag].k6 = 3;
//      pm[Tag].is_underwriting = 0;
//      ModalResult = mrOk;
//   }
//   else{
///*
//      AnsiString xml_result("");
//      Thread_APO2_ARM_READER *thr_k6 = new Thread_APO2_ARM_READER(true, 4, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"), XMLDoc->GetXML()->Text, &xml_result);
//      thr_k6->Resume();
//      while(WaitForSingleObject((HANDLE)thr_k6->Handle, 0) == WAIT_TIMEOUT){
//         vgInfoRow->Properties->Caption = "���� ������ � ���";
//         for(int i = 0; i < 3; ++i){
//           vgInfoRow->Properties->Caption = vgInfoRow->Properties->Caption + dot;
//            Application->ProcessMessages();
//            Sleep(333);
//         }
//      }
//      delete thr_k6;
//
//      CalcK6(xml_result);
//
//      //CalcK6(GetIAPO2_ARM_READER(false, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"))->GetK5K6(XMLDoc->GetXML()->Text));
//*/
//   }
//
//   vgInfoRow->Properties->Caption = "��� ���������� �������� ������ ���� ��������� ��������� ��� ����";
//   btnOK->Enabled     = true;
//   btnCancel->Enabled = true;
//   //PostQuitMessage(WM_QUIT);
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::btnCopyDataClick(TObject *Sender)
{
   editPmLastName->Properties->Value   = pm[Tag].lastname   = pi[0].lastname;
   editPmFirstName->Properties->Value  = pm[Tag].firstname  = pi[0].firstname;
   editPmSecondName->Properties->Value = pm[Tag].secondname = pi[0].secondname;
   pm[Tag].birthdate = pi[0].birthdate;
   SetValueRowDateEdit(deditPmBirthDate, pm[Tag].birthdate);
   if(pi[0].doc_type == 17 || pi[0].doc_type == 24){
      if(pi[0].doc_type != pm[Tag].doc_type){
         pm[Tag].doc_type = pi[0].doc_type;
         //ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag);
         rgPmDocType->Properties->Value = RGItemDoc->Properties->Items->Items[GetIndexItemByTag(RGItemDoc->Properties->Items, pm[Tag].doc_type)]->Caption;
      }
      pm[Tag].doc_seria = pi[0].doc_seria;
      editPmDocSeria->Properties->Value = StringReplace(pm[Tag].doc_seria, space_str, empty_str, rf);
      pm[Tag].doc_number = pi[0].doc_number;
      editPmDocNumber->Properties->Value = pm[Tag].doc_number;
      /*int r = pi[0].kladr_addr->Values["��� �����"].SubString(1, 2).ToIntDef(0);
      if(r > 0) cboxPmRegion->Properties->Value = pm_region_id = r;*/
   }
   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::RGItemSexPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   pm[Tag].sex = rgPmSex->Properties->Value.IsNull() ? -1 : RGItemSex->Properties->GetRadioGroupItemIndex(rgPmSex->Properties->Value) + 1;
   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::RGItemDocPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   pm[Tag].doc_type = rgPmDocType->Properties->Value.IsNull() ? -1 : RGItemDoc->Properties->Items->Items[RGItemDoc->Properties->GetRadioGroupItemIndex(rgPmDocType->Properties->Value)]->Tag;
   if(pm[Tag].doc_type > 0)
     ////ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag);
   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::LookupComboBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   if(cboxPmRegion->Properties->Value.IsNull())
   {
      pm_region_id = 0; pm[Tag].address = empty_str;
   }
   else
   {
      pm_region_id = cboxPmRegion->Properties->Value;
      pm[Tag].address = LookupComboBoxItem->Properties->ListSource->DataSet->Lookup("id", pm_region_id, "subject_federation_name");
   }

   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::TextItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();

   //Variant val = r->Properties->Value;
   //AnsiString s___(val.VOleStr);
   //AnsiString sTst;
   //VarToStrDef(val, sTst);

   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;

   AnsiString valStr = val.IsNull() ? empty_str : AnsiString(val);

   switch(r->Tag)
   {
      case 2: pm[Tag].lastname   = valStr; break; //editPmLastName
      case 3: pm[Tag].firstname  = valStr; break; //editPmFirstName
      case 4: pm[Tag].secondname = valStr; break; //editPmSecondName
      case 8: pm[Tag].doc_seria  = valStr; break; //editPmDocSeria
      case 9: pm[Tag].doc_number = valStr; break; //editPmDocNumber
   }

   resizeLabHint(valStr);

   labHint->Top = vg->InplaceEditor->Top + 16;
   labHint->Visible = true;

   Validate();
}


void TfrmAddPermitted::resizeLabHint(AnsiString str)
{
   labHintSize->Caption = str;

   int vgInplaceEditorWidth = vg->InplaceEditor->Width;
   int labHintWidth = labHint->Width;
   int distance = vgInplaceEditorWidth - labHintWidth;

   int textCurrentWidth  = labHintSize->Width;
   if(textCurrentWidth > distance)
   {
     //labHint->Width = vgInplaceEditorWidth - textCurrentWidth;
     //labHint->Left += ( textCurrentWidth - distance );
     labHint->Left =  defaultLabHintLeft + ( textCurrentWidth - distance );
   }
   else
   {
     labHint->Left = defaultLabHintLeft;
   }
}

//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DateItemPropertiesChange(TObject *Sender)
{
   labHint->Top = vg->InplaceEditor->Top + 16;
   labHint->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties)
{
   labHint->Visible = false;
   Validate();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DateItemPropertiesEditValueChanged(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   AnsiString dt_str("");
   switch(r->Tag){
      case 5: VariantToDate(val, pm[Tag].birthdate); break; //deditPmBirthDate
      case 6: VariantToDate(val, pm[Tag].doc_issue_date); break; //deditPmStartDriving
   }
   labHint->Visible = false;
   Validate();
}

//---------------------------------------------------------------------------
void  TfrmAddPermitted::setEnabledControls()
{
// ��������� �� ������������ � 8
// 
// ����� ������� ������� "������ ������������� �������������
// ����������� � ���������� �� � ����� � �������/�������" �
// ��� ���� � ����� �������������� ���������� � ���������� �������� ���.

/*// �� ��� ���������� �� �����
    switch(btn)
    {
      case BTN_EMPTY:
      editPmFirstName->Properties->Options->Editing = true;
      default:
      break;
      case BTN_ADD:
      rgPmSex->Properties->Options->Editing             = true;
      editPmLastName->Properties->Options->Editing      = true;
      editPmFirstName->Properties->Options->Editing     = true;
      editPmSecondName->Properties->Options->Editing    = true;
      deditPmBirthDate->Properties->Options->Editing    = true;
      deditPmStartDriving->Properties->Options->Editing = true;
      rgPmDocType->Properties->Options->Editing         = true;
      editPmDocSeria->Properties->Options->Editing      = true;
      editPmDocNumber->Properties->Options->Editing     = true;
      break;
      case BTN_EDIT:
      rgPmSex->Properties->Options->Editing             = false;
      editPmLastName->Properties->Options->Editing      = false;
      editPmFirstName->Properties->Options->Editing     = false;
      editPmSecondName->Properties->Options->Editing    = false;
      deditPmBirthDate->Properties->Options->Editing    = false;
      deditPmStartDriving->Properties->Options->Editing = false;
      rgPmDocType->Properties->Options->Editing         = true;
      editPmDocSeria->Properties->Options->Editing      = true;
      editPmDocNumber->Properties->Options->Editing     = true;
      break;
    }
 //*/
}


/* BTN_EMPTY = -1,
   BTN_ADD   = 0,
   BTN_EDIT  = 1,
   //BTN_DEL   = 2
*/

//---------------------------------------------------------------------------
bool TfrmAddPermitted::DataToXML()
{
   if(/*pm[Tag].sex < 1 ||*/ pm[Tag].lastname.IsEmpty() || pm[Tag].firstname.IsEmpty() /*|| pm[Tag].secondname.IsEmpty()*/ || !pm[Tag].birthdate.Val || /*pm[Tag].address.IsEmpty() ||*/ !pm[Tag].doc_issue_date.Val || pm[Tag].doc_seria.IsEmpty() || pm[Tag].doc_number.IsEmpty() || pm[Tag].age < 18 && (pm[Tag].age - pm[Tag].experience) < 18) return false;

   TDateTime dt;

   Root->ChildNodes->Clear();
   Root->AddChild("type")->Text = "2";
   Root->AddChild("system")->Text = "3";
   Root->AddChild("date_quotes")->Text = TDateTime(di->calc_date).FormatString("dd.mm.yyyy");
   Root->AddChild("casco_dogovor_type")->Text = IntToStr(di->contract_type + 1);
/* // TSInfo
   Root->AddChild("casco_k6_no_calc")->Text = IntToStr(di->no_calc_k6);
*/
   Root->AddChild("casco_k6_no_calc")->Text = IntToStr(di->no_calc);
   Root->AddChild("casco_territory_id")->Text = IntToStr(di->region_id);

   _di_IXMLNode person = Root->AddChild("persons")->AddChild("person");
   person->Attributes["id"] = pm[Tag].lastname + space_str + pm[Tag].firstname + space_str + pm[Tag].secondname; //IntToStr(Tag + 1);
   person->AddChild("first_name")->Text  = pm[Tag].firstname;
   person->AddChild("second_name")->Text = pm[Tag].secondname;
   person->AddChild("last_name")->Text   = pm[Tag].lastname;
   person->AddChild("birth_date")->Text  = pm[Tag].birthdate.FormatString("dd.mm.yyyy");
   person->AddChild("is_insurant")->Text = null_str;
   _di_IXMLNode document = person->AddChild("person_document");
   document->AddChild("document_series")->Text = StringReplace(pm[Tag].doc_seria, space_str, empty_str, rf);
   document->AddChild("document_number")->Text = pm[Tag].doc_number;
   _di_IXMLNode vehicle = Root->AddChild("vehicle");
/*// TSInfo
   vehicle->AddChild("age")->Text = IntToStr(tsi->ts_age);
-*/
   vehicle->AddChild("age")->Text = IntToStr(tsi->vehicle_age);

   return true;

   //XMLDoc->SaveToFile("D:\\test.xml");
}
//---------------------------------------------------------------------------
void TfrmAddPermitted::CalcK1()
{
   K1(m_api, Tag, pm, di);
}
//---------------------------------------------------------------------------
void TfrmAddPermitted::CalcK6(const AnsiString& xml_text)
{
   try{
       ModalResult = mrOk;

      _di_IXMLDocument XMLDoc_Resp = NewXMLDocument();

      XMLDoc_Resp->Active = true;
      XMLDoc_Resp->Options.Clear();
      XMLDoc_Resp->LoadFromXML(xml_text);
      //XMLDoc_Resp->SaveToFile("F:\\GetInfoForK6.xml");
      //XMLDoc_Resp->SaveToFile("C:\\Users\\Public\\GetInfoForK6.xml");

      _di_IXMLNode Root_Resp = XMLDoc_Resp->DocumentElement;
      _di_IXMLNode errors = Root_Resp->ChildNodes->FindNode("Errors");

      if(errors->ChildNodes->Count){
         MessageBox(Handle, AnsiString("������ �� ��� ��������� � �������. ���������� ������� ��������� ������!\r\n" + AnsiString(errors->GetXML())).c_str(), "������ �����", MB_OK | MB_ICONWARNING);
         ModalResult = mrCancel;
      }
      else{
         _di_IXMLNode person = Root_Resp->ChildNodes->FindNode("persons")->ChildNodes->FindNode("person");
         _di_IXMLNode contracts = person->ChildNodes->FindNode("contracts");
         pm[Tag].dogovors["k6"].clear();
         if(contracts){
            for(int c = 0, cnt_contracts = contracts->ChildNodes->Count; c < cnt_contracts; ++c){
               _di_IXMLNode contract = contracts->ChildNodes->Get(c);
               pm[Tag].dogovors["k6"].push_back(Dogovor(NodeToStr(contract->ChildNodes->FindNode("id")), NodeToStr(contract->ChildNodes->FindNode("system")).ToIntDef(0)));
            }
         }
         pm[Tag].k6 = StrToFloatStr(NodeToStr(person->ChildNodes->FindNode("K6"))).ToDouble();
         if(pm[Tag].k6 < 1.0 && di->programm_id == 1286) pm[Tag].k6 = 1.0;
         pm[Tag].is_underwriting = NodeToStr(person->ChildNodes->FindNode("IS_UNDERWRITING")).ToIntDef(0);
         pm[Tag].rsa_id = NodeToStr(person->ChildNodes->FindNode("IS_RSA"));
      }
      delete XMLDoc_Resp;

      /*pm[Tag].XMLDoc->Active = true;
      pm[Tag].XMLDoc->Options.Clear();
      pm[Tag].XMLDoc->LoadFromFile("D:\\bor.xml");

      _di_IXMLNode Root_Resp = pm[Tag].XMLDoc->DocumentElement;
      _di_IXMLNode errors = Root_Resp->ChildNodes->FindNode("Errors"), persons = Root_Resp->ChildNodes->FindNode("persons"), person, contracts, contract, accidents, child_node;

      if(errors && errors->ChildNodes->Count){
         MessageBox(Handle, AnsiString("������ �� ��� ��������� � �������. ���������� ������� ��������� ������!\r\n" + AnsiString(errors->GetXML())).c_str(), "������ �����", MB_OK | MB_ICONWARNING);
         ModalResult = mrCancel;
      }
      else{
         TDateTime quotes_date = TDateTime(di->calc_date);
         double d_val, claims, liability;
         AnsiString sql(""), quotes_date_str = quotes_date.DateString();

         oi_section_of_years[1].period_main = UsagePeriod(IncYear(quotes_date, -1) + 1, quotes_date);
         oi_section_of_years[2].period_main = UsagePeriod(IncYear(oi_section_of_years[1].period_main.start_period, -1), IncYear(oi_section_of_years[1].period_main.end_period, -1));
         oi_section_of_years[3].period_main = UsagePeriod(IncYear(oi_section_of_years[2].period_main.start_period, -1), IncYear(oi_section_of_years[2].period_main.end_period, -1));
         oi_section_of_years[4].period_main = UsagePeriod(IncYear(oi_section_of_years[3].period_main.start_period, -1), IncYear(oi_section_of_years[3].period_main.end_period, -1));

         for(int p = 0, cnt_persons = persons->ChildNodes->Count; p < cnt_persons; ++p){
            person = persons->ChildNodes->Get(p);
            contracts = person->ChildNodes->FindNode("contracts");

            TDateTime dt, policy_sd, policy_ed, policy_cd;
            int history_class_id(3), count_accidents, count_years_or_damage(0);

            for(int i = 1; i < 5; ++i){ oi_section_of_years[i].period_enter.clear(); oi_section_of_years[i].accidents = 0; }

            if(contracts){
               for(int c = 0, cnt_contracts = contracts->ChildNodes->Count; c < cnt_contracts; ++c){
                  contract = contracts->ChildNodes->Get(c);
                  accidents = contract->ChildNodes->FindNode("accidents");
                  count_accidents = AnsiString(accidents->Attributes["count"]).ToIntDef(0);
                  policy_sd = StrToDateTimeDef(NodeToStr(contract->ChildNodes->FindNode("POLICY_START_DATE")), 0.0);
                  policy_ed = StrToDateTimeDef(NodeToStr(contract->ChildNodes->FindNode("POLICY_END_DATE")),   0.0);
                  policy_cd = StrToDateTimeDef(NodeToStr(contract->ChildNodes->FindNode("CANCEL_DATE")),       0.0);
                  if(policy_cd.Val) policy_ed = policy_cd;
                  if(policy_sd.Val && policy_ed.Val){
                     UsagePeriod usage_pd[3];
                     usage_pd[0] = UsagePeriod(StrToDateTimeDef(NodeToStr(contract->ChildNodes->FindNode("USAGE_START_DATE")), policy_sd), StrToDateDef(NodeToStr(contract->ChildNodes->FindNode("USAGE_END_DATE")), policy_ed));
                     usage_pd[1] = UsagePeriod(StrToDateTimeDef(NodeToStr(contract->ChildNodes->FindNode("USAGE_START_DATE2")), 0.0), StrToDateDef(NodeToStr(contract->ChildNodes->FindNode("USAGE_END_DATE2")), 0.0));
                     usage_pd[2] = UsagePeriod(StrToDateTimeDef(NodeToStr(contract->ChildNodes->FindNode("USAGE_START_DATE3")), 0.0), StrToDateDef(NodeToStr(contract->ChildNodes->FindNode("USAGE_END_DATE3")), 0.0));
                     if(policy_cd.Val) for(int i = 0; i < 3; ++i) usage_pd[i].CheckAndCorrectCancelDate(policy_cd);

                     for(int i = 1; i < 5; ++i){
                        if(count_accidents) for(int a = 0; a < count_accidents; ++a){
                           child_node = accidents->ChildNodes->Get(a);
                           if(TryStrToDate(NodeToStr(child_node->ChildNodes->FindNode("ACCIDENT_DATE")), dt) && dt >= oi_section_of_years[i].period_main.start_period && dt <= oi_section_of_years[i].period_main.end_period) ++oi_section_of_years[i].accidents;
                        }
                        for(int j = 0; j < 3; ++j)
                           if(usage_pd[j].NotNull() && usage_pd[j].Between(oi_section_of_years[i].period_main)) oi_section_of_years[i].period_enter.push_back(usage_pd[j]);
                     }
                  }
               }
               TStringList *sl = new TStringList();
               for(int i = 1; i < 5; ++i){
                  sl->Add(IntToStr(i) + "MP:" + oi_section_of_years[i].period_main.start_period.DateString() + " - " + oi_section_of_years[i].period_main.end_period.DateString() + "; D=" + IntToStr(oi_section_of_years[i].DaysInPeriod()));
                  sl->Add("In P:");
                  for(int j = 0; j < oi_section_of_years[i].period_enter.size(); ++j)
                     sl->Add(oi_section_of_years[i].period_enter[j].start_period.DateString() + " - " + oi_section_of_years[i].period_enter[j].end_period.DateString());
               }
               sl->SaveToFile("D:\\periods.txt");
               delete sl;

               for(int i = 1; i < 5; ++i){
                  int dip = oi_section_of_years[i].DaysInPeriod();
                  if(i == 1){
                     if(dip < 329){ SendRequestToRSA(history_class_id, count_years_or_damage); i = 5; }
                     else{
                        count_accidents = oi_section_of_years[i].accidents;
                        if(!count_accidents){
                           if(di->contract_type){ history_class_id = 1; i = 5; }
                           else ++count_years_or_damage;
                        }
                        else{
                           count_years_or_damage = count_accidents;
                           history_class_id = (di->contract_type && count_accidents > 1) ? 1 : 2;
                           i = 5;
                        }
                     }
                  }
                  else{
                     if(dip < 329 || oi_section_of_years[i].accidents) i = 5;
                     else ++count_years_or_damage;
                  }
               }
            }
            else SendRequestToRSA(history_class_id, count_years_or_damage);

            pm[Tag].k6 = m_api->dbGetFloatFromQuery(res, sql.sprintf("select coeff_value from cascodictk6 where history_class_id=%i and limited_drivers=1 and count_min<=%i and count_max>=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", history_class_id, count_years_or_damage, count_years_or_damage, quotes_date_str, quotes_date_str));
         }
      }*/

   }
   catch(Exception& ex) { MessageBox(Handle, ("������ �6: " + ex.Message).c_str(), "������ �����", MB_OK | MB_ICONERROR); ModalResult = mrCancel; }
   catch(...) { MessageBox(Handle, "������ �6: FATAL ERROR", "������ �����", MB_OK | MB_ICONERROR); ModalResult = mrCancel; }
}
//---------------------------------------------------------------------------
void TfrmAddPermitted::CheckBlackList()
{
   //FilterDataSet(q_bl, "person_name='" + m_api->Normalization_String_RSA(res, pm[Tag].lastname + pm[Tag].firstname + pm[Tag].secondname) + "' and birthdate='" + pm[Tag].birthdate.DateString() + "' and region_id=" + IntToStr(pm_region_id));

   FilterDataSet(q_bl, "person_name='" + m_api->Normalization_String_RSA(res, pm[Tag].lastname + pm[Tag].firstname + pm[Tag].secondname) + "' and birthdate='" + pm[Tag].birthdate.DateString() + "'");
   pm[Tag].black_list = q_bl->IsEmpty() ? 0 : 1;
}
//---------------------------------------------------------------------------
void TfrmAddPermitted::Validate()
{
   pm[Tag].age        = CalcYears(pm[Tag].birthdate, TDateTime(di->calc_date));
   pm[Tag].experience = CalcYears(pm[Tag].doc_issue_date, TDateTime(di->calc_date));
   if(pm[Tag].experience < 0) pm[Tag].experience = 0;

   // ���� � ������������ ����, �� �� ������� ����� ����� ����� ...
   // ������� ����� "������" ��������� ������
   //btnCancel->Enabled = !btn || pm[Tag] == pm_temp;

//*
   bool b_ = false;
	        //btnOK->Enabled = 																										   ;
	b_ =    pm[Tag].sex > 0 																										   ;
	b_ =    !pm[Tag].lastname.IsEmpty()																								   ;
	b_ =    !pm[Tag].firstname.IsEmpty() 																							   ;
	b_ =    pm[Tag].birthdate.Val && pm[Tag].doc_issue_date.Val 																	   ;
	        //&& (																													   ;
	b_ =    !MaskItemSeries->Properties->EditMask.IsEmpty()																			   ;
	b_ =	!pm[Tag].doc_seria.IsEmpty()																							   ;
	b_ =	!pm[Tag].doc_seria.Pos(underline_str)																					   ;
	        //||																													   ;
	b_ =    MaskItemSeries->Properties->EditMask.IsEmpty() 																			   ;
	b_ =    !pm[Tag].doc_seria.IsEmpty()																							   ;
	b_ =    !MaskItemNumber->Properties->EditMask.IsEmpty()																			   ;
	b_ =    !pm[Tag].doc_number.IsEmpty()																							   ;
	b_ =    !pm[Tag].doc_number.Pos(underline_str)																					   ;
	        //|| 																													   ;
	b_ =    MaskItemNumber->Properties->EditMask.IsEmpty()																			   ;
	b_ =    !pm[Tag].doc_number.IsEmpty()																							   ;
                                                                                                                                       ;
	b_ =    pm[Tag].age > 17																										   ;
	b_ =    (pm[Tag].age - pm[Tag].experience) > 17;
    int n__ =(pm[Tag].age - pm[Tag].experience);
//*/

    int d_t = pm[Tag].doc_type;
    AnsiString d_s = pm[Tag].doc_seria;
    int d_len = pm[Tag].doc_seria.Length();

    int nAgeAndExperience = (pm[Tag].age - pm[Tag].experience);
    AnsiString strLastName = pm[Tag].lastname;

	if(!(pm[Tag].sex > 0))              { vgInfoRow->Properties->Caption = "������: ������������, �� ���������� ��������� ���!"; }
	//else if(pm[Tag].lastname.IsEmpty())	  vgInfoRow->Properties->Caption = "������: �����������, �� ����������� �������!";
	else if(strLastName.IsEmpty())	  vgInfoRow->Properties->Caption = "������: �����������, �� ����������� �������!";
	else if(pm[Tag].firstname.IsEmpty())  vgInfoRow->Properties->Caption = "������: �����������, �� ����������� ���!";

	else if(!(pm[Tag].birthdate.Val))     vgInfoRow->Properties->Caption = "������: ����������� ���� ��������!";
	else if(!(pm[Tag].doc_issue_date.Val))vgInfoRow->Properties->Caption = "������: ����������� ���� ������ �����!";
	//&& (																													   ;
	//else if(MaskItemSeries->Properties->EditMask.IsEmpty())	vgInfoRow->Properties->Caption = "��������������: ����� ��� ����� ��������� �����.";
	else if(pm[Tag].doc_seria.IsEmpty())  vgInfoRow->Properties->Caption = "������: �����������, �� ����������� ����� ���������!";
	else if(!CheckAreNumbersAndLetters(pm[Tag].doc_seria) ) vgInfoRow->Properties->Caption = "������: � ����� ��������� ������ ���� 4 �������!";
    //else if(pm[Tag].doc_seria.Pos(underline_str))	vgInfoRow->Properties->Caption = "������: ???";
	if(pm[Tag].doc_type != 17 && pm[Tag].doc_seria.Length() != 4  ) { vgInfoRow->Properties->Caption = "������: � ����� ��������� ������ ���� 4 �������!"; }
            //||																													   ;
	//else if(MaskItemNumber->Properties->EditMask.IsEmpty())	vgInfoRow->Properties->Caption = "��������������: ����� ��� ������ ��������� �����.";
	else if(pm[Tag].doc_number.IsEmpty()) vgInfoRow->Properties->Caption = "������: �����������, �� ���������� ����� ���������!";
	else if(!CheckAreAllNumbers(pm[Tag].doc_number)) vgInfoRow->Properties->Caption = "������: � ������ ��������� ������ ���� 6 ����!";
	//else if(pm[Tag].doc_number.Pos(underline_str))	vgInfoRow->Properties->Caption = "������: ???";
	//if(pm[Tag].doc_type != 17 && pm[Tag].doc_number.Length() != 6 ) { vgInfoRow->Properties->Caption = "������: � ������ ��������� ������ ���� 6 ����!"; }
	        //|| 																													   ;
	else if(!(pm[Tag].age > 17))          vgInfoRow->Properties->Caption = "������: ������� ������ ���� ������ 17-��, ���� �� ����������, �����������!";
    else if(!((pm[Tag].age - pm[Tag].experience) > 17))	vgInfoRow->Properties->Caption
    = "������: ������� - ���� ������ ���� > 17, ������ = " +IntToStr(nAgeAndExperience)+ ", ���� �� ����������, �����������!";

//*/

   btnOK->Enabled = pm[Tag].sex > 0 && !pm[Tag].lastname.IsEmpty() && !pm[Tag].firstname.IsEmpty() && /*!pm[Tag].secondname.IsEmpty() &&*/ pm[Tag].birthdate.Val && pm[Tag].doc_issue_date.Val /*&& !pm[Tag].address.IsEmpty()*/
                  && ((!MaskItemSeries->Properties->EditMask.IsEmpty() && !pm[Tag].doc_seria.IsEmpty() && !pm[Tag].doc_seria.Pos(underline_str)) || (MaskItemSeries->Properties->EditMask.IsEmpty() && !pm[Tag].doc_seria.IsEmpty()))
                  && ((!MaskItemNumber->Properties->EditMask.IsEmpty() && !pm[Tag].doc_number.IsEmpty() && !pm[Tag].doc_number.Pos(underline_str)) || (MaskItemNumber->Properties->EditMask.IsEmpty() && !pm[Tag].doc_number.IsEmpty()))
                  && pm[Tag].age > 17 && (pm[Tag].age - pm[Tag].experience) > 17 && CheckAreNumbersAndLetters(pm[Tag].doc_seria) && CheckAreAllNumbers(pm[Tag].doc_number);

   if(btnOK->Enabled)
     vgInfoRow->Properties->Caption = "��� ���� ������� �����.";
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DateItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   if(Error) DisplayValue = variant_null;
   Error = false;
}
//---------------------------------------------------------------------------


void __fastcall TfrmAddPermitted::editPmLastNameEditPropertiesChange(TObject *Sender)
{
  TcxCustomTextEdit *txtEditVal = dynamic_cast<TcxCustomTextEdit*>(Sender);
  AnsiString str_ = txtEditVal->EditingText;
  int u = 0;
}
//---------------------------------------------------------------------------

void __fastcall TfrmAddPermitted::editPmLastNameEditPropertiesEditValueChanged(TObject *Sender)
{
   //editPmLastName->
}
//---------------------------------------------------------------------------

void __fastcall TfrmAddPermitted::editPmLastNameEditPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
  AnsiString s___(DisplayValue.VOleStr);
  AnsiString sTst;
  VarToStrDef(DisplayValue, sTst);
}
//---------------------------------------------------------------------------

