//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "licard.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma link "cxBlobEdit"
#pragma link "cxButtonEdit"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma link "cxCalendar"
#pragma link "cxExtEditRepositoryItems"
#pragma link "cxCheckGroup"
#pragma link "cxDropDownEdit"
#pragma link "cxDBEditRepository"
#pragma link "cxDBLookupComboBox"
#pragma link "cxTextEdit"
#pragma resource "*.dfm"
TfrmLicard *frmLicard;
//---------------------------------------------------------------------------
__fastcall TfrmLicard::TfrmLicard(TComponent* Owner, mops_api_026* mops) : TFrame(Owner), m_api(mops)
{
}
//---------------------------------------------------------------------------
void TfrmLicard::SaveFrame(TADOQuery *q)
{
   q->FieldByName("likard_number")->Value = editNumberLikard->EditText.Trim();
   TDateTime dt;
   if(TryStrToDate(dateCardVidan->EditText, dt) && dt.Val) q->FieldByName("likard_date")->Value = dt;
}
//---------------------------------------------------------------------------
void TfrmLicard::LoadFrame(TADOQuery *q)
{
   editNumberLikard->EditText = q->FieldByName("likard_number")->AsString;
   SetValueRowDateEdit(dateCardVidan, q->FieldByName("likard_date")->AsDateTime);
}
//---------------------------------------------------------------------------

