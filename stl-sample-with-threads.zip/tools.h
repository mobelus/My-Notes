//---------------------------------------------------------------------------
#ifndef toolsH
#define toolsH
#include <Classes.hpp>
#include <StdCtrls.hpp>
#include <DBClient.hpp>
#include "sCurrEdit.hpp"
#include "sTooledit.hpp"
#include "dxInspRw.hpp"
#include "sCheckBox.hpp"
#include <ADODB.hpp>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <XMLIntf.hpp>
#include "Tmops_api.h"
#include "cxEditRepositoryItems.hpp"
#include "cxVGrid.hpp"
#include <Dialogs.hpp>

//---------------------------------------------------------------------------

#define err_prarm     "������ ����������|�������� � ���"
#define err_pr        "������ ����������"
#define err_agr       "������������ ��������"
#define err_armagr    "�������� � ���|������������ ��������"
#define err_arm       "�������� � ���"
#define err_prarmagr  "������ ����������|�������� � ���|������������ ��������"
#define err_canc      "���������� �����������"
#define err_reiss     "�������������� ��������"
#define err_calc      "��������������� ������ ������"
#define person_mask 1
#define vehicle_mask 2


typedef void __fastcall(__closure*ptr_onclick)(TObject*);
typedef void __fastcall(__closure*ptr_onchange)(TObject*);

typedef std::map<int, AnsiString> Map_Int_Str;

AnsiString S(const double& x);
AnsiString FormatDigits(const double& x);
void FloatToRubAndKopeik(const double& x, AnsiString& rub, AnsiString& kopeik);
AnsiString FloatToSQLStr(const double& f);
AnsiString FloatToSQLStr(AnsiString s);
AnsiString StrToFloatStr(const AnsiString& s, const AnsiString& def = "0");
AnsiString FloatToIntStr(const double& f);
int CalcYears(const TDateTime& dt1, const TDateTime& dt2);
int GetIndexObject(TStrings* lst, const int& val);
int GetIndexItemByTag(TcxRadioGroupItems*, const int t);
void ResetChk(TCheckBox* chk, ptr_onclick onclick = 0);
void ResetSChk(TsCheckBox* chk, ptr_onclick onclick = 0);

void SetValueCalcEdit(TsCalcEdit *cedit, const double& val, ptr_onchange onchange);
void SetValueDateEdit(TsDateEdit *dedit, const TDateTime& val, ptr_onchange onchange);
void SetValueRowDateEdit(TdxInspectorTextDateRow *dedit, const TDateTime& val);
void SetValueRowDateEdit(TcxEditorRow *dedit, const TDateTime& val);
TDateTime CalcEndDateInsur(const TDateTime& start_date, const int srok_month);
AnsiString FirstUpper(const AnsiString& str);
AnsiString AddNulls(const AnsiString& str);
AnsiString ClearPhoneNumber(const AnsiString& str);
void FilterDataSet(TADOQuery *qq, const AnsiString& filter);
bool TryStrToDate_my(const AnsiString& str, TDateTime& dt);
void SetHeightInspector1(TCustomdxInspectorControl *inspector);
void SetHeightInspector2(TCustomdxInspectorControl *inspector);
void SetHeightInspector_1(TdxInspector *inspector);
void SetHeightInspector_2(TdxInspector *inspector);
int GetToplabHint_1(TdxInspector *inspector);
int GetToplabHint_2(TdxInspector *inspector);
int GetToplabHint(TCustomdxInspectorControl *inspector);
bool CheckVIN(const AnsiString& vin);
bool CheckRegPlate(const AnsiString& rgpl);
AnsiString NodeToStr(_di_IXMLNode node);
AnsiString NodeAttributeToStr(_di_IXMLNode node, const AnsiString& name, const AnsiString& value);
AnsiString NormVIN_GN(mops_api_025 *m_api, const AnsiString& numb);
void SeparateFIO(const AnsiString& fio, const int status, AnsiString& lname, AnsiString& fname, AnsiString& sname);
void MakeKladrAddrFromARM(mops_api_028 *_m_api, _di_IXMLNode child_node, TStringList* addr, int& memo_id);
void MakeKladrAddrFromUXML(mops_api_028 *_m_api, _di_IXMLNode person, TStringList *addr, int& memo_id, AnsiString& exact_address);
bool CheckAddrList(TStringList* addrlist);
double GetKprSb(const double& val);
void GetPhones(_di_IXMLNode contacts, AnsiString& ph_mob, AnsiString& ph_home, AnsiString& ph_rab, int &sms);
AnsiString IntToBin(const int ANumber, int ABitCount = 32);
void FieldValueIDToVGEditor(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row);
void FieldValueIDToVGEditor_(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row);
int GetDrvCount(TADOQuery *qq);
int GetCountPermitted(TListView *gridDopush);
int MonthsCount(const TDateTime& ANow, const TDateTime& AThen);
void VariantToDate(Variant v, TDateTime& dt);
void SetValueCheckBox(TsCheckBox* chk, const int v, ptr_onclick onclick);
AnsiString MarkaId(const int model_id);
//---------------------------------------------------------------------------
const AnsiString fs("yyyy.mm.dd hh:nn:ss"), empty_str(""), dot_line("---"),  dot("."), null_str(0), one_str(1), space_str(" "), underline_str("_"), pdf("PDF"), not_filename("/\\:*?\"<>|.,'"), category[7] = {"B", "C", "D", "�����������", "E", "E", "E"}, damages[5] = {"������� ���", "1 ������", "2 ������", "3 ������", "4 ������ ��� �����"}, copy_persons("������������\r\n�������������������"), person[] = {"������������", "�������������������", "�����������"}, person_tp[] = {"������������", "�������������������", "������������"}, sex("�������\r\n�������"), mask("L000LL000;1;_"), russia("���������� ���������"), code_russia("643"), vB("������� \"B\""),
                 space_str_nonbreak('\xA0'), space_str_long('\x98'),
                 ts_age_str[13] = {" �.", " �., ������� �� - 1 ���", " �., ������� �� - 2 ����", " �., ������� �� - 3 ����", " �., ������� �� - 4 ����", " �., ������� �� - 5 ���", " �., ������� �� - 6 ���", " �., ������� �� - 7 ���", " �., ������� �� - 8 ���", " �., ������� �� - 9 ���", " �., ������� �� - 10 ���", " �., ������� �� - 11 ���", " �., ������� �� - 12 ���"},
                 head_grid("    �     ���                                  ���                                       ������� / ����       ����������� K1   ����������� K6"), reg_plate_possible("������������D������������d0123456789"),
                 programm_error_text("��� ������ ������� ������ ������� ��������� \"%s\", �.�. "), prefix[4] = {"", "B", "Ow", "Pm"}, combobox("TdxInspectorTextPickRow"), variant[] = {"�", "�", "�"},
                 credit_available("�������� ���������!"), porsche("298000000");

const TReplaceFlags rf(TReplaceFlags() << rfReplaceAll);
const TLocateOptions locate(TLocateOptions() << loCaseInsensitive);
const TColor clError(RGB(255,128,128));
const Variant variant_null = Variant().ChangeType(varNull);
//---------------------------------------------------------------------------
struct question{
   int number;
   std::vector<int> response;
};
struct Anketa : public std::vector<question>{
   Anketa() {};

   void Init();
};
//---------------------------------------------------------------------------
void GenerateResponseList(Anketa &ret_a, Anketa &a, const int discount);
//---------------------------------------------------------------------------
struct DataDict : public TObject{
   int id;
   double coeff_value, coeff_min, coeff_max;
   int field_val1, field_val2;
   AnsiString rg_pl;

   DataDict() {}
   DataDict(const int& v1, const double& v2, const int& v3) : id(v1), coeff_value(v2), field_val1(v3), coeff_min(0.0), coeff_max(0.0) { }
};
//---------------------------------------------------------------------------
struct FR_INFO{
   TADOQuery *q;
   AnsiString form_name;
   long calc_id;
};
//---------------------------------------------------------------------------
struct TblQue{
   AnsiString sql_skk, table_apo;
   bool transdekra;

   TblQue() {}
   TblQue(const AnsiString& v1, const AnsiString& v2, bool v3) : sql_skk(v1), table_apo(v2), transdekra(v3) {}
};
//---------------------------------------------------------------------------
struct SkkQuery : public std::map<AnsiString, TblQue>{
   SkkQuery();
};
//---------------------------------------------------------------------------
struct InputMask{
   AnsiString mask_series, mask_number;
   int max_length, position;

   InputMask() {}
   InputMask(const AnsiString& v1, const AnsiString& v2, const int v3 = 0, const int v4 = 0) : mask_series(v1), mask_number(v2), position(v3), max_length(v4) {}
};
//---------------------------------------------------------------------------
struct MaskDocType : public std::map<int, InputMask>{
   MaskDocType(const int type);
};
//---------------------------------------------------------------------------
static MaskDocType mask_doc_type(person_mask), mask_vehicle_doc_type(vehicle_mask);
//---------------------------------------------------------------------------
struct UsagePeriod{
   TDateTime start_period, end_period;

   UsagePeriod() {};
   UsagePeriod(const TDateTime& v1, const TDateTime& v2) : start_period(v1), end_period(v2) {};

   bool operator <  (const UsagePeriod& val) const { return start_period < val.start_period; }
   bool operator >  (const UsagePeriod& val) const{ return start_period > val.start_period; }
   bool operator == (const UsagePeriod& val) const { return start_period == val.start_period && end_period == val.end_period; }
   UsagePeriod& operator = (const UsagePeriod& val){ start_period = val.start_period; end_period = val.end_period; return *this; }

   bool Between(const UsagePeriod& val) const { return start_period < val.end_period && end_period > val.start_period; }
   bool NotNull() const { return start_period.Val && end_period.Val; }
   void CheckAndCorrectCancelDate(const TDateTime& policy_cd);
};
//---------------------------------------------------------------------------
struct OsagoInfo{
   UsagePeriod period_main;
   std::vector<UsagePeriod> period_enter;
   int accidents;

   OsagoInfo() : accidents(0) {};
   int DaysInPeriod();
};
//---------------------------------------------------------------------------
struct Dogovor{
   AnsiString id;
   int system;

   Dogovor() : id(""), system(0){};
   Dogovor(const AnsiString& v1, const int& v2) : id(v1), system(v2) {};
};
//---------------------------------------------------------------------------
struct PersonInfo{
   AnsiString lastname, firstname, secondname;
   AnsiString inn;
   int status;
   int sex, doc_type;
   int age, experience;
   int memo_id;
   int sms_sending;
   int black_list, is_underwriting;
   AnsiString doc_seria, doc_number, doc_issue_org, citizenship;
   TStringList *kladr_addr;
   AnsiString address, phone_mobil, phone_home, phone_work, email;
   AnsiString opf, organization, ogrn, depart_sb, number_sb, place_sb;
   AnsiString rsa_id;
   TDateTime birthdate, doc_issue_date;
   double k1, k6;
   _di_IXMLDocument XMLDoc;
   std::map<AnsiString, std::vector<Dogovor> > dogovors;

   PersonInfo() : status(0)
   {
      kladr_addr = new TStringList();

      XMLDoc = NewXMLDocument();
      XMLDoc->Active = true;
      XMLDoc->Options.Clear();

      Reset();
   }
   PersonInfo& operator = (const PersonInfo& val){
      lastname         = val.lastname;
      firstname        = val.firstname;
      secondname       = val.secondname;
      birthdate        = val.birthdate;
      inn              = val.inn;
      status           = val.status;
      sex              = val.sex;
      doc_type         = val.doc_type;
      age              = val.age;
      experience       = val.experience;
      doc_seria        = val.doc_seria;
      doc_number       = val.doc_number;
      doc_issue_date   = val.doc_issue_date;
      doc_issue_org    = val.doc_issue_org;
      address          = val.address;
      phone_mobil      = val.phone_mobil;
      phone_home       = val.phone_home;
      phone_work       = val.phone_work;
      email            = val.email;
      opf              = val.opf;
      organization     = val.organization;
      ogrn             = val.ogrn;
      kladr_addr->Text = val.kladr_addr->Text; 
      depart_sb        = val.depart_sb;
      number_sb        = val.number_sb;
      sms_sending      = val.sms_sending;
      place_sb         = val.place_sb;
      black_list       = val.black_list;
      citizenship      = val.citizenship;
      k1               = val.k1;
      k6               = val.k6;
      rsa_id           = val.rsa_id;
      return *this;
   }
   bool operator == (const PersonInfo& val){
      return lastname == val.lastname && firstname == val.firstname && secondname == val.secondname && birthdate == val.birthdate && status == val.status && sex == val.sex && doc_type == val.doc_type && doc_seria == val.doc_seria && doc_number == val.doc_number;
   }
   bool operator != (const PersonInfo& val){
      return lastname != val.lastname || firstname != val.firstname || secondname != val.secondname || birthdate != val.birthdate || status != val.status || sex != val.sex || doc_type != val.doc_type || doc_seria != val.doc_seria || doc_number != val.doc_number;
   }
   void Reset()
   {
      place_sb = opf = lastname = firstname = secondname = inn = doc_seria = doc_number = doc_issue_org = address = phone_mobil = phone_home = organization = ogrn = depart_sb = number_sb = rsa_id = empty_str;
      birthdate.Val = doc_issue_date.Val = 0;
      citizenship = "��������";
      switch(status){
         case 0: doc_type = 12; break;
         case 1: doc_type = 25; break;
         case 2: doc_type = 29; break;
      }
      is_underwriting = black_list = memo_id = age = experience = sex = 0;
      sms_sending = -1;
      k1 = k6 = 1.0;
      kladr_addr->Clear();
      XMLDoc->XML->Clear();
      XMLDoc->Options.Clear();
      dogovors.clear();
   }

   ~PersonInfo(){
      delete kladr_addr;
      delete XMLDoc;
   }
};
//---------------------------------------------------------------------------
struct TSInfo{
   AnsiString ts_marka, ts_model, ts_vin, ts_znak, volume;
   AnsiString pts_series, pts_number;
   double power;
   int tstype_id, marka_id, model_id, key_count, seat_count, type_doc_ts, ts_age, ts_ident_type, max_massa, group_ts, ts_year, is_agreed;
   TDateTime pts_date;

   TSInfo() { Reset(); }

   void Reset()
   {
      ts_marka = ts_model = ts_vin = volume = pts_series = pts_number = empty_str;
      pts_date.Val = 0;
      ts_znak  = "�/�";
      tstype_id = key_count = 2;
      type_doc_ts = 1;
      is_agreed = ts_year = model_id = max_massa = power = seat_count = ts_age = ts_ident_type = 0;
      group_ts = -1;
   }

   bool IsSpectech(){ return tstype_id == 7; }
   bool IsPricep(){ return tstype_id >= 8 && tstype_id <= 10; }
   bool IsCar(){ return (group_ts < 4 || group_ts == 6 || group_ts == 7); }
};
//---------------------------------------------------------------------------
struct CalcInfo{
   double kar, kr, kyu, bt, ns_bt, k1, k2, k3, k4, k5, k6, k7, ka, ks, krs, kpr, kb, kkv, kd, kfr, kbfprlg, kgap, kss_old, kss_new, kdiscount;
   double osn_risk_itog_tarif, coef_prop, old_itog_tarif, old_premium_paid;
   double premiya_osn_risk, premiya_dsago, premiya_all, premiya_ns, payed_sum, premiya_dms, premiya_gap;
   double premiya_osn_risk_for_bp, min_premiya_osn_risk, cost_tdr, cost_min, cost_max, cost_vehicle, old_cost_vehicle, cost_vehicle_new, str_summa, str_summa1, str_summa2, str_summa3, str_summa_ns, str_summa_dms, old_str_summa, old_premium, paid, payment1, payment_part[4], curr_limit, claims_damages, kss_sum_limit, kss_premium_limit;
   double anderr_summ_limit, anderr_ka_limit;
   double coeff_limit;
   int anderr_dsago, anderr_variant_b, risk_model, cross_error;
   std::map<int, double> min_premium_ekonom, kpr_dtp;

   CalcInfo()
   {
      min_premium_ekonom[1] = 10000;
      min_premium_ekonom[2] = 15000;
      min_premium_ekonom[3] = 33000;
      min_premium_ekonom[6] = 8000;
      min_premium_ekonom[7] = 8000;

      kpr_dtp[1] = 0.55;
      kpr_dtp[2] = 0.5;
      kpr_dtp[6] = 0.55;
      kpr_dtp[7] = 0.55;

      anderr_dsago = anderr_variant_b = risk_model = 0;

      Reset();
   }

   void Reset()
   {
      payment1 = old_premium_paid = claims_damages = min_premiya_osn_risk = old_cost_vehicle = old_itog_tarif = premiya_osn_risk_for_bp = cost_tdr = cost_min = cost_max = cost_vehicle = str_summa = str_summa_ns = payed_sum = premiya_osn_risk_for_bp = premiya_ns = old_str_summa = old_premium = kss_sum_limit = 0.0;
      curr_limit = 2500000;
      ns_bt = 0.3;
      coef_prop = bt = k1 = k2 = k3 = k4 = k5 = k6 = k7 = kar = kr = krs = ks = kpr = kb = kfr = kkv = kbfprlg = kss_old = kss_new = 1.0;
      str_summa_dms = premiya_dms = 0.0;
      coeff_limit = 1;
      cross_error = 0;
   }

   void SetPremiumNull(){ osn_risk_itog_tarif = premiya_all = premiya_osn_risk = premiya_dsago = premiya_ns = premiya_gap = 0; }
};
//---------------------------------------------------------------------------
struct Dogovor_Info{
   AnsiString polis_seria, polis_number, prev_seria, prev_number, credit_number, zalog_number, calc_date, last_contract_id;
   TDateTime polis_date, datesrok_s, datesrok_po, credit_date, zalog_date, statement_date, cancell_date, payment_date[4], last_polis_ed_incday;
   int region_id, status_dogovor, dogovor_type, monthcount, bank_id, type_money, contract_type, reiss_type, REGION_TYPE, count_accidents, no_calc_k5, no_calc_k6, ts_count, old_programm_id;
   int product_id, risk, type_multydrive, shedule_type_id, programm_id, project_id, pay_id, franshize_id, franshize_size, big_payment1, system, payment_status[4];
   TStringList *non_standart_str_calc, *non_standart_str_print;
   bool is_ander_login, is_new_dogovor, is_msoff, is_opoff;
   CalcInfo calc_info;

   Dogovor_Info() : is_ander_login(false)
   {
      non_standart_str_calc  = new TStringList();
      non_standart_str_print = new TStringList();

      CLSID cid;
      is_msoff = (CLSIDFromProgID(L"Excel.Application",           &cid) == S_OK);
      is_opoff = (CLSIDFromProgID(L"com.sun.star.ServiceManager", &cid) == S_OK);
   }

   void Reset()
   {
      calc_info.Reset();
      last_contract_id = polis_seria = polis_number = prev_seria = prev_number = credit_number = zalog_number = empty_str;
      no_calc_k5 = ts_count = REGION_TYPE = status_dogovor = dogovor_type = 1;
      monthcount = 12;
      big_payment1 = project_id = programm_id = old_programm_id = no_calc_k6 = count_accidents = bank_id = type_money = contract_type = reiss_type = 0;
      payment_date[0] = statement_date = polis_date = datesrok_s = Date();
      datesrok_po = CalcEndDateInsur(datesrok_s, monthcount);
      calc_date = polis_date.DateString();
      non_standart_str_calc->Clear();
      non_standart_str_print->Clear();
      last_polis_ed_incday.Val = 0.0;
      risk = 2;
      product_id = 301;
      //type_multydrive = 100;
	  type_multydrive = 1;
	  system = 3;
      payment_status[0] = 5;
      payment_status[1] = payment_status[2] = payment_status[3] = 2;
   }

   bool DtpInCrimea()
   {
      return (region_id == 91 || region_id == 92) && programm_id == 1286;
   }

   ~Dogovor_Info()
   {
      delete non_standart_str_calc;
      delete non_standart_str_print;
   }
};
//---------------------------------------------------------------------------
struct AddDevice{
   int id;
   AnsiString name_dict, name_detail;
   double cost;

   AddDevice& operator = (const AddDevice& val){
      id = val.id;
      name_dict = val.name_dict;
      name_detail = val.name_detail;
      cost = val.cost;

      return *this;
   }
   bool operator == (const AddDevice& val){
      return id == val.id && cost == val.cost;
   }
   bool operator != (const AddDevice& val){
      return id != val.id || cost != val.cost;
   }
};
//---------------------------------------------------------------------------
struct Reason_Surcharge{
   int surcharge_recalc, surcharge_constant, select;
   double surcharge_const_value;

   Reason_Surcharge() {}
   Reason_Surcharge(const int v1, const int v2) : surcharge_recalc(v1), surcharge_constant(v2), surcharge_const_value(0.0), select(0) {}
};
//---------------------------------------------------------------------------
void K1(mops_api_024 *m_api, const int index_pm, PersonInfo *pm, Dogovor_Info *di);
void ChangeMask(TdxInspectorTextMaskRow *DocSeria, TdxInspectorTextMaskRow *DocNumber, PersonInfo *p_pi, const int index,const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, TSInfo *p_tsi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
//---------------------------------------------------------------------------
void PmDataToRecord(TADOQuery* q_perm, PersonInfo *pm, const int calc_id, const int num, const int i, const int pm_status);
void Save_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm, TListView *gridDopush);
void Load_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm);
void MakeExportFilters(TSaveDialog *sd, Dogovor_Info *di, Map_Int_Str &filter);
//---------------------------------------------------------------------------
Boolean PasportInBadList(AnsiString DocSeria, AnsiString DocNumber, Integer DocType, AnsiString APO2_ARM_READER_ADR);

const AnsiString f171_sql = "select top 1 "
"'%s' as email_date,"
"'%s' as region,"
"'%s' as region_dep,"
"'%s' as saleplace,"
"'%s' as salechannel,"
"'%s' as type_insur,"
"'%s' as insured,"
"'%s' as type_benef,"
"'%s' as benefic,"
"'%s' as vehicle,"
"'%s' as veh_year,"
"'%s' as volume,"
"'%s' as power,"
"'%s' as vin,"
"'%s' as pts,"
"'%s' as variant,"
"'%s' as risk,"
"'%s' as sum_insured,"
"'%s' as veh_cost,"
"'%s' as source_cost,"
"'%s' as is_bfprlg,"
"'%s' as old_summa,"
"'%s' as old_premium,"
"'%s' as base_tariff,"
"'%s' as coeff_k1,"
"'%s' as coeff_k2,"
"'%s' as coeff_k3,"
"'%s' as coeff_k4,"
"'%s' as coeff_k5,"
"'%s' as coeff_k6,"
"'%s' as coeff_k7a,"
"'%s' as coeff_kr,"
"'%s' as coeff_ks,"
"'%s' as coeff_krs,"
"'%s' as coeff_kpr,"
"'%s' as coeff_ka,"
"'%s' as coeff_kar,"
"'%s' as coeff_kb,"
"'%s' as coeff_kd,"
"'%s' as coeff_k1r,"
"'%s' as ind_tariff,"
"'%s' as premium,"
"'%s' as permitteds,"
"'%s' as obosn_ka,"
"'%s' as franshise,"
"'%s' as franshise_k1,"
"'%s' as srok_month,"
"'%s' as prolongation,"
"'%s' as complekt,"
"'%s' as usage_purpose,"
"'%s' as base_kkv,"
"'%s' as fio_saler,"
"'%s' as fio_deiizb,"
"'%s' as fio_anderr "
"from casco_calc",

//"'%s' as comment,"

report_anderr_sql =
"t1.calc_id,"
"t1.email_date,"
"t4.terr_name,"
"t4.filial_name,"
"t1.sale_place,"
"t1.sale_channel,"
"IIf(t1.status_idx = 0, '��', IIf(t1.status_idx = 1, '��', '�����')) as type_insured,"
"IIf(t1.status_idx = 1, t2.last_name & ' ' & t2.inn, t2.last_name & ' ' & t2.first_name & ' ' & t2.second_name & ' ' & t2.phisical_birth_date) as insured,"
"IIf(t3.status = 0, '��', IIf(t3.status = 1, '��', '�����')) as type_benefic,"
"IIf(t3.status = 1, t3.last_name & ' ' & t3.inn, t3.last_name & ' ' & t3.first_name & ' ' & t3.second_name & ' ' & t3.phisical_birth_date) as benefic,"
"(t1.ts_marka & ' ' & t1.ts_model) as vehicle,"
"t1.ts_year,"
"t1.ts_volume,"
"t1.ts_power,"
"t1.ts_vin,"
"IIf(t1.ts_doc_type = 1, t1.pts_seria & ' ' & t1.pts_number & ' ' & t1.pts_date, '') as pts,"
"(IIf(t1.variant_idx = 0, '������� �', IIf(t1.variant_idx = 1, '������� �', '������� �')) & ' / �171') as variant,"
"(IIf(t1.risk_id = 2, '�����', '�����') & IIf(t1.select_dsago = True, '; �����', '') & IIf(t1.select_ns = True, '; ��', '')) as risks,"
"'���' as source_ts_cost,"
"t1.ts_cost,"
"t1.str_summa,"
"IIf(t1.benefit_prolong = 1,'��','���') as bfprlg,"
"IIf(t1.benefit_prolong = 1,t1.old_str_summa,0) as old_ss,"
"IIf(t1.benefit_prolong = 1,t1.old_premium_main_risk,0) as old_sp,"
"t1.bt,"
"t1.k1,"
"t1.kd,"
"IIf(t1.quotation_date < CDate('10.01.2014'),(select top 1 coeff_val from cascodictk02 where vehcnt_min<=t1.ts_count and vehcnt_max>=t1.ts_count and start_date<=t1.quotation_date and end_date>=t1.quotation_date), 1) as k2,"
"(select top 1 coeff_val from cascodictk03 where srok_min<=t1.srok_month and srok_max>=t1.srok_month  and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k3,"
"t1.k4,"
"IIf(t1.quotation_date < CDate('10.01.2014'),IIf(IsNull((select top 1 coeff_val from cascodictk05 where k5_name=CStr(t1.prev_ubitki_idx) and terr_type_id=2 and start_date<=t1.quotation_date and end_date>=t1.quotation_date)),1,(select top 1 coeff_val from cascodictk05 where k5_name=CStr(t1.prev_ubitki_idx) and terr_type_id=2 and start_date<=t1.quotation_date and end_date>=t1.quotation_date)),t1.k5) as k5,"
"IIf(t1.quotation_date < CDate('10.01.2014'),IIf(IsNull((select top 1 coeff_val from cascodictk06 where k6_id=t1.osago_idx)),1,(select top 1 coeff_val from cascodictk06 where k6_id=t1.osago_idx)),t1.k6_final) as k6,"
"(select top 1 coeff_val from cascodictk07 where pay_id=t1.pay_id and tertype_id=2 and vehage_min<(Year(Date())-t1.ts_year) and vehage_max>=(Year(Date())-t1.ts_year) and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k7,"
"t1.ks,"
"t1.kar,"
"t1.kr,"
"t1.ka,"
"t1.kb,"
"IIf(t1.full_insur = 3,IIf(t1.coeff_prop<=0.54,1.75, IIf(t1.coeff_prop<=0.59,1.6,IIf(t1.coeff_prop<=0.64,1.5,IIf(t1.coeff_prop<=0.69,1.4,IIf(t1.coeff_prop<=0.74,1.3,1.2))))),1) as kfr,"
"(select top 1 coeff_value from cascodictk08 where id_krs=t1.krs_idx) as krs,"
"IIf(t1.kpr <> 1, t1.kpr, (select top 1 ka_min from gl_dict_programm_project where project_id=t1.programm_id and start_date<=t1.quotation_date and end_date>=t1.quotation_date and start_date_coeff<=t1.quotation_date and end_date_coeff>=t1.quotation_date)) as kprg,"
"t1.kbfprlg,"
"t1.tariff,"
"t1.premium_main_risk,"
"t1.permitteds,"
"IIf(t1.ka < 1,t1.obosn_ka,t1.prg_prj_name) as obosn_ka_prg_prj_name,"
"IIf(t1.type_franshiza=6,'������������',IIf(t1.type_franshiza=3,t1.franshiza,'')) as franshize,"
"IIf(t1.fr_instead_k1=True, t1.franshiza,'') as frinsteadk1,"
"t1.srok_month,"
"t1.usage_purpose_text,"
"IIf(t1.prolong = True, '2 / ' & t1.prev_seria & ' ' & t1.prev_number,'1') as dgt,"
"t1.real_alarm,"
"t1.base_kkv,"
"t1.from_whom_sent,"
"t1.fio_deiizb,"
"t1.comm_anderr_mid,"
"t1.agent_comm,"
"t6.name"
" from (((((casco_calc t1"
" left join casco_persons t2 on (t1.calc_id=t2.calc_id and t2.type_person=1))"
" left join casco_persons t3 on (t1.calc_id=t3.calc_id and t3.type_person=2))"
" left join gl_dict_regions t4 on t1.region_id=t4.terr_id)"
" left join _mops_calcs_  t5 on t1.calc_id=t5.id)"
" left join _mops_polzovateli_ t6 on t5.id_polzovatelya=t6.id)"
" where t5.deleted=0",

sql_calc_form = "select "
"t1.polis_seria,"
"t1.polis_number,"
"t1.polis_date,"
"t1.prolong,"
"t1.variant_idx,"
"t1.prg_prj_name,"
"t1.prev_seria,"
"t1.prev_number,"
"t1.prev_ubitki_idx,"
"t1.claim_damages_sum,"
"t1.srok_month,"
"t1.ts_marka,"
"t1.ts_model,"
"t2.categories,"
"t1.group_str,"
"t1.ts_year,"
"t1.ts_novoe,"
"(select '(' & vehcnt_min & ' - ' & vehcnt_max & ')' from cascodictk02 where k2_id=t1.ts_count and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as ts_count,"
"t1.risk_id,"
"t1.status_idx,"
"t1.benefit_prolong,"
"t1.old_str_summa,"
"t1.old_premium_main_risk,"
"t1.bt,"
"t1.k1,"
"t1.kd,"
"IIf(t1.status_idx = 0, 1, (select top 1 coeff_val from cascodictk02 where k2_id=t1.ts_count and start_date<=t1.quotation_date and end_date>=t1.quotation_date)) as k2,"
"(select top 1 coeff_val from cascodictk03 where srok_min<=t1.srok_month and srok_max>=t1.srok_month  and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k3,"
"t1.k4,"
"t1.k5,"
"t1.k6_final as k6,"
"(select top 1 coeff_val from cascodictk07 where pay_id=t1.pay_id and tertype_id=2 and vehage_min<(Year(Date())-t1.ts_year) and vehage_max>=(Year(Date())-t1.ts_year) and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k7,"
"t1.ks,"
"t1.kyu,"
"t1.kar,"
"t1.kr,"
"t1.ka,"
"t1.bank_id,"
"t1.kb,"
"IIf(t1.full_insur = 3,IIf(t1.coeff_prop<=0.54,1.75, IIf(t1.coeff_prop<=0.59,1.6,IIf(t1.coeff_prop<=0.64,1.5,IIf(t1.coeff_prop<=0.69,1.4,IIf(t1.coeff_prop<=0.74,1.3,1.2))))),1) as kfr,"
"(select top 1 coeff_value from cascodictk08 where id_krs=t1.krs_idx) as krs,"
"IIf(t1.kpr <> 1, t1.kpr, (select top 1 ka_min from gl_dict_programm_project where project_id=t1.programm_id and start_date<=t1.quotation_date and end_date>=t1.quotation_date and start_date_coeff<=t1.quotation_date and end_date_coeff>=t1.quotation_date)) as kprg,"
"t1.kbfprlg,"
"t1.tariff,"
"t1.ts_cost,"
"t1.coeff_prop,"
"t1.str_summa,"
"t1.premium_main_risk,"
"t1.select_dsago,"
"t1.select_ns,"
"t1.ns_summa,"
"t1.premium_ns,"
"t1.select_dms,"
"t1.dms_summa,"
"t1.premium_dms,"
"t1.dsago_summa,"
"t1.premium_dsago,"
"t1.premiya_all,"
"t1.type_franshiza,"
"t1.fr_instead_k1,"
"t1.franshiza,"
"t1.sale_place,"
"t1.sale_channel,"
"t1.agent,"
"t3.bank_name_print,"
"t1.quotation_date,"
"t1.from_whom_sent,"
"t1.date_unload,"
"%i as is_anderr"
" from"
" ((casco_calc t1"
" left join gl_dict_banks as t3 on t1.bank_id=t3.bank_id) left join ts_type as t2 on t1.tstype_id=val(t2.code))"
" where t1.calc_id=",

message_for_agreed = "��� �������� �������� �� ������������ �.�. ��������� ��������� ���� � ������� ������ ��� ������:\r\n"
" - �����, ����� ����������� �������� (��� �������������);\r\n"
" - ������������ ��� ��, ����� �� ������ ��� ������������;\r\n"
" - ���, ���� ��������, ������������ ��� �� ��� �������������������;\r\n"
"������� � ���������� ���� ������?";
//---------------------------------------------------------------------------
#endif


/*
select 
t1.email_date, 
t4.terr_name,
t1.filial,
t1.sale_place,
t1.sale_channel,
IIf(t1.status_idx = 0, '��', IIf(t1.status_idx = 1, '��', '�����')) as type_insured,
IIf(t1.status_idx = 1, t2.last_name & ' ' & t2.inn, t2.last_name & ' ' & t2.first_name & ' ' & t2.second_name & ' ' & t2.phisical_birth_date) as insured,
IIf(t3.status = 0, '��', IIf(t3.status = 1, '��', '�����')) as type_benefic,
IIf(t3.status = 1, t3.last_name & ' ' & t3.inn, t3.last_name & ' ' & t3.first_name & ' ' & t3.second_name & ' ' & t3.phisical_birth_date) as benefic,
(t1.ts_marka & ' ' & t1.ts_model) as vehicle,
t1.ts_year,
t1.ts_volume,
t1.ts_power,
t1.ts_vin,
IIf(t1.ts_doc_type = 1, t1.pts_seria & ' ' & t1.pts_number & ' ' & t1.pts_date, '') as pts,
(IIf(t1.variant_idx = 0, '������� "�"', IIf(t1.variant_idx = 1, '������� "�"', '������� "�"')) & ' / �171') as variant,
(IIf(t1.risk_id = 2, '�����', '�����') & IIf(t1.select_dsago = True, '; �����', '') & IIf(t1.select_ns = True, '; ��', '')) as risks,
'���' as source_ts_cost,
t1.ts_cost,
t1.str_summa,
IIf(t1.benefit_prolong = 1,'��','���') as bfprlg,
IIf(t1.benefit_prolong = 1,t1.old_str_summa,0) as old_ss,
IIf(t1.benefit_prolong = 1,t1.old_premium_main_risk,0) as old_sp,
t1.bt,
t1.k1,
t1.kd,
(select coeff_val from cascodictk02_1 where vehcnt_min<=t1.ts_count and vehcnt_max>=t1.ts_count and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k2,
(select coeff_val from cascodictk03_1 where srok_min<=t1.srok_month and srok_max>=t1.srok_month  and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k3, 
t1.k4,
IIf(t1.prolong = True,select coeff_val from cascodictk05_1 where k5_name=CString(t1.prev_ubitki_idx) and terr_type_id=2 and start_date<=t1.quotation_date and end_date>=t1.quotation_date,0) as k5,
IIf(t1.prolong = False,select coeff_val from cascodictk06_1 where k6_id=t1.osago_idx,0) as k6,
(select coeff_val from cascodictk07_1 where pay_id=t1.pay_id and tertype_id=2 and vehage_min<(Year(Date)-t1.ts_year) and vehage_max>=(Year(Date)-t1.ts_year) and start_date<=t1.quotation_date and end_date>=t1.quotation_date) as k7,
t1.ks,
t1.kar,
t1.kr,
t1.ka,
t1.kb,
IIf(t1.full_insur = 3,IIf(t1.coeff_prop<=0.54,1.75, IIf(t1.coeff_prop<=0.59,1.6,IIf(t1.coeff_prop<=0.64,1.5,IIf(t1.coeff_prop<=0.69,1.4,IIf(t1.coeff_prop<=0.74,1.3,1.2))))),1) as kfr,
(select coeff_val from cascodictk08_1 where id_krs=t1.krs_idx) as krs,
IIf(t1.programm_id In(886,898,1027,1028,1045,1045),select ka_max from gl_dict_programm_project where project_id=t1.programm_id and start_date<=t1.quotation_date and end_date>=t1.quotation_date,t1.kpr) as kprg,
t1.tariff,
t1.premium_main_risk,
t1.permitteds,
IIf(t1.ka < 1, t1.obosn_ka,t1.prg_prj_name),
t1.franshiza,
IIf(t1.fr_instead_k1=True, t1.franshiza,'') as frinsteadk1,
t1.srok_month,
t1.usage_purpose_text,
IIf(t1.prolong = True, '2 / ' & t1.prev_seria & ' ' & t1.prev_number,'1') as dgt,
t1.real_alarm,
t1.base_kkv,
t1.from_whom_sent,
t1.fio_deiizb,
t1.agent_comm,
t5.name


from casco_calc t1
*/
