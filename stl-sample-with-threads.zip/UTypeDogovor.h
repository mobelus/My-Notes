//---------------------------------------------------------------------------

#ifndef UTypeDogovorH
#define UTypeDogovorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "TMops_api.h"
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TfrmTypeDogovor : public TForm
{
__published:	// IDE-managed Components
   TdxInspector *InsuredInfo;
   TdxInspectorTextRow *editLastName;
   TdxInspectorTextRow *editFirstName;
   TdxInspectorTextRow *editSecondName;
   TdxInspectorTextDateRow *editBirthDate;
   TdxInspectorTextRow *editHead;
   TdxInspectorTextRow *VehicleHead;
   TdxInspectorTextPickRow *cboxTSType;
   TdxInspectorTextPickRow *cboxTSMarka;
   TdxInspectorTextPickRow *cboxTSModel;
   TdxInspectorTextMaskRow *editRegPlate;
   TdxInspectorTextPickRow *cboxIdentificationType;
   TdxInspectorTextMaskRow *editTSVIN;
   TcxButton *btnOK;
   TcxButton *btnCancel;
   TcxButton *btnCreateNoPrint;
   
private:	// User declarations
   mops_api_024 *m_api;
   TADOQuery *q;
   int res;
public:		// User declarations
   __fastcall TfrmTypeDogovor(TComponent* Owner, mops_api_024 *_m_api);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmTypeDogovor *frmTypeDogovor;
//---------------------------------------------------------------------------
#endif
