//---------------------------------------------------------------------------
#ifndef structuresH
#define structuresH
#include "constants.h"
#include <StdCtrls.hpp>
#include <DBClient.hpp>
#include <ADODB.hpp>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <XMLIntf.hpp>
#include <DateUtils.hpp>
#include "Tmops_api.h"

//---------------------------------------------------------------------------
struct question {
	int number;
	std::vector<int> response;
};
struct Anketa : public std::vector<question> {
	Anketa() {};

	void Init();
};

//---------------------------------------------------------------------------
void Anketa::Init()
{
	for (int i = 0; i < 11; ++i) {
		question q;
		q.number = i;
		switch (i) {
		case 0: case 3: case 6: q.response.push_back(0); q.response.push_back(2); break;
		case 1: q.response.push_back(0); q.response.push_back(1); q.response.push_back(3); break;
		case 2: q.response.push_back(0); q.response.push_back(1); q.response.push_back(2); q.response.push_back(3); break;
		case 4: q.response.push_back(6); q.response.push_back(5); q.response.push_back(4); q.response.push_back(3); q.response.push_back(2); q.response.push_back(1); q.response.push_back(0); break;
		case 5: case 7: case 8: case 9:  q.response.push_back(0); q.response.push_back(1); q.response.push_back(2); break;
		case 10: q.response.push_back(4); q.response.push_back(3); q.response.push_back(2); q.response.push_back(1); q.response.push_back(0); break;
		}
		push_back(q);
	}
}
//---------------------------------------------------------------------------
//void GenerateResponseList(Anketa &ret_a, Anketa &a, const int discount);
//---------------------------------------------------------------------------
void GenerateResponseList(Anketa &ret_a, Anketa &a, const int discount)
{
m1:
	if (a.empty() || discount < 0) return;

	Anketa new_a = a, new_ret_a = ret_a;

	Randomize();
	int index_question = RandomRange(0, new_a.size());

	Randomize();
	int index_response = RandomRange(0, new_a[index_question].response.size());
	int ves = new_a[index_question].response[index_response], summ_max(0);

	question q = new_a[index_question];
	new_a.erase(&new_a[index_question]);

	for (Anketa::iterator it = new_a.begin(); it != new_a.end(); ++it) summ_max += *std::max_element((*it).response.begin(), (*it).response.end());

	if (summ_max >= discount - ves && discount - ves >= 0) {
		question qu = q;
		qu.response.clear();
		qu.response.push_back(q.response[index_response]);
		new_ret_a.push_back(qu);
		GenerateResponseList(new_ret_a, new_a, discount - ves);
		ret_a = new_ret_a;
		a = new_a;
	}
	else goto m1;
}

//---------------------------------------------------------------------------
struct UsagePeriod {
	TDateTime start_period, end_period;

	UsagePeriod() {};
	UsagePeriod(const TDateTime& v1, const TDateTime& v2) : start_period(v1), end_period(v2) {};

	bool operator <  (const UsagePeriod& val) const { return start_period < val.start_period; }
	bool operator >  (const UsagePeriod& val) const { return start_period > val.start_period; }
	bool operator == (const UsagePeriod& val) const { return start_period == val.start_period && end_period == val.end_period; }
	UsagePeriod& operator = (const UsagePeriod& val) { start_period = val.start_period; end_period = val.end_period; return *this; }

	bool Between(const UsagePeriod& val) const { return start_period < val.end_period && end_period > val.start_period; }
	bool NotNull() const { return start_period.Val && end_period.Val; }
	void CheckAndCorrectCancelDate(const TDateTime& policy_cd);
};

//---------------------------------------------------------------------------
void UsagePeriod::CheckAndCorrectCancelDate(const TDateTime& policy_cd)
{
	if (policy_cd < start_period) { start_period.Val = 0.0; end_period = 0.0; }
	if (policy_cd < end_period) end_period = policy_cd;
}

//---------------------------------------------------------------------------
struct OsagoInfo {
	UsagePeriod period_main;
	std::vector<UsagePeriod> period_enter;
	int accidents;

	OsagoInfo() : accidents(0) {};
	int DaysInPeriod();
};

//---------------------------------------------------------------------------
int OsagoInfo::DaysInPeriod()
{
	TDateTime dt_s(0.0), dt_e(0.0);
	int count_periods = period_enter.size(), dip(0);

	if (!count_periods) return 0;

	std::sort(period_enter.begin(), period_enter.end());

	TStringList *sl = new TStringList();

	for (int i = 0; i < count_periods; ++i) {
		AnsiString str = period_enter[i].start_period.DateString() + " - " + period_enter[i].end_period.DateString();
		if (period_enter[i].start_period > dt_s) dt_s = period_enter[i].start_period;
		dt_e = period_enter[i].end_period;
		if (dt_s < period_main.start_period) dt_s = period_main.start_period;
		if (dt_e > period_main.end_period)   dt_e = period_main.end_period;
		if (dt_e > dt_s) {
			str += ("                " + dt_s.DateString() + " - " + dt_e.DateString());
			dip += (DaysBetween(dt_s, dt_e) + 1);
			dt_s = IncDay(dt_e);
		}
		else str += ("                  minus");
		//}
		sl->Add(str);
	}

	sl->SaveToFile("D:\\periods_f.txt");

	delete sl;

	return dip;
}

//---------------------------------------------------------------------------

struct DataDict : public TObject{
   int id;
   double coeff_value, coeff_min, coeff_max;
   int field_val1, field_val2;
   AnsiString rg_pl;

   DataDict() {}
   DataDict(const int& v1, const double& v2, const int& v3) : id(v1), coeff_value(v2), field_val1(v3), coeff_min(0.0), coeff_max(0.0) { }
};
//---------------------------------------------------------------------------
struct FR_INFO{
   TADOQuery *q;
   AnsiString form_name;
   long calc_id;
};
//---------------------------------------------------------------------------
struct TblQue{
   AnsiString sql_skk, table_apo;
   bool transdekra;

   TblQue() {}
   TblQue(const AnsiString& v1, const AnsiString& v2, bool v3) : sql_skk(v1), table_apo(v2), transdekra(v3) {}
};
//---------------------------------------------------------------------------
struct SkkQuery : public std::map<AnsiString, TblQue>{
   SkkQuery();
};
//---------------------------------------------------------------------------
struct RussoFieldName : public std::map<AnsiString, AnsiString>{
   RussoFieldName();
};

struct InputMask{
   AnsiString mask_series, mask_number;
   int max_length, position;

   InputMask() {}
   InputMask(const AnsiString& v1, const AnsiString& v2, const int v3 = 0, const int v4 = 0) : mask_series(v1), mask_number(v2), position(v3), max_length(v4) {}
};
//---------------------------------------------------------------------------
struct MaskDocType : public std::map<int, InputMask>{
   MaskDocType(const int type);
};
//---------------------------------------------------------------------------
struct Dogovor{
   AnsiString id;
   int system;

   Dogovor() : id(""), system(0){};
   Dogovor(const AnsiString& v1, const int& v2) : id(v1), system(v2) {};
};
//---------------------------------------------------------------------------
struct PersonInfo{
   AnsiString lastname, firstname, secondname;
   AnsiString inn;
   int status, key_client;
   int sex, doc_type;
   int age, experience;
   int memo_id, memo_id_sberbank;
   int sms_sending;
   int black_list, is_underwriting;
   int opf_id;
   int permitted_check;
   AnsiString doc_seria, doc_number, doc_issue_org, registration_org, citizenship, code_org;
   TStringList *kladr_addr, *kladr_addr_sberbank;
   AnsiString address, address_sberbank, phone_mobil, phone_home, phone_work, email;
   AnsiString organization, ogrn, depart_sb, number_sb, place_sb;
   AnsiString sign_position, sign_name, sign_document, sign_name_normal;
   AnsiString rsa_id;
   TDateTime birthdate, doc_issue_date, registration_date;
   double k1, k6;
   _di_IXMLDocument XMLDoc;
   std::map<AnsiString, std::vector<Dogovor> > dogovors;

   PersonInfo() : status(1)
   {
      kladr_addr = new TStringList();
      kladr_addr_sberbank = new TStringList();

      XMLDoc = NewXMLDocument();
      XMLDoc->Active = true;
      XMLDoc->Options.Clear();

      Reset();
   }
   PersonInfo& operator = (const PersonInfo& val){
      lastname         = val.lastname;
      firstname        = val.firstname;
      secondname       = val.secondname;
      birthdate        = val.birthdate;
      inn              = val.inn;
      status           = val.status;
      sex              = val.sex;
      doc_type         = val.doc_type;
      age              = val.age;
      experience       = val.experience;
      doc_seria        = val.doc_seria;
      doc_number       = val.doc_number;
      doc_issue_date   = val.doc_issue_date;
      doc_issue_org    = val.doc_issue_org;
      address          = val.address;
      address_sberbank = val.address_sberbank;
      phone_mobil      = val.phone_mobil;
      phone_home       = val.phone_home;
      phone_work       = val.phone_work;
      email            = val.email;
      opf_id           = val.opf_id;
      organization     = val.organization;
      ogrn             = val.ogrn;
      kladr_addr->Text = val.kladr_addr->Text;
      kladr_addr_sberbank->Text = val.kladr_addr_sberbank->Text;
      depart_sb        = val.depart_sb;
      number_sb        = val.number_sb;
      sms_sending      = val.sms_sending;
      place_sb         = val.place_sb;
      black_list       = val.black_list;
      citizenship      = val.citizenship;
      k1               = val.k1;
      k6               = val.k6;
      rsa_id           = val.rsa_id;
      sign_position    = val.sign_position;
      sign_name        = val.sign_name;
      sign_document    = val.sign_document;
      sign_name_normal = val.sign_name_normal;
      registration_date = val.registration_date;
      registration_org = val.registration_org;
      code_org         = val.code_org;

      return *this;
   }
   bool operator == (const PersonInfo& val){
      return lastname == val.lastname && firstname == val.firstname && secondname == val.secondname && birthdate == val.birthdate && status == val.status && sex == val.sex && doc_type == val.doc_type && doc_seria == val.doc_seria && doc_number == val.doc_number;
   }
   bool operator != (const PersonInfo& val){
      return lastname != val.lastname || firstname != val.firstname || secondname != val.secondname || birthdate != val.birthdate || status != val.status || sex != val.sex || doc_type != val.doc_type || doc_seria != val.doc_seria || doc_number != val.doc_number;
   }
   void Reset()
   {
      place_sb = lastname = firstname = secondname = inn = doc_seria = doc_number = doc_issue_org = address = phone_mobil = phone_home = phone_work = organization = ogrn = depart_sb = number_sb = rsa_id = email = empty_str;
      birthdate.Val = doc_issue_date.Val = registration_date.Val = 0;
      sign_name_normal = sign_position = sign_name = sign_document = registration_org = code_org = empty_str;
      address = address_sberbank = empty_str;
      citizenship = "��������";
      switch(status){
         case 1: doc_type = 12; break;
         case 2: doc_type = 25; break;
         case 5: doc_type = 12; break;
      }
      opf_id = key_client = is_underwriting = black_list = memo_id = memo_id_sberbank = age = experience = sex = 0;
      sms_sending = -1;
      k1 = k6 = 0.0;
      permitted_check = 0;
      kladr_addr->Clear();
      kladr_addr_sberbank->Clear();
      XMLDoc->XML->Clear();
      XMLDoc->Options.Clear();
      dogovors.clear();
   }

   ~PersonInfo(){
      delete kladr_addr;
      delete kladr_addr_sberbank;
      delete XMLDoc;
   }
};
//---------------------------------------------------------------------------
/*////////////////// STRUCTURES DIFFERENCE //////////////////////////////////
	TSInfo									VehicleInfo
// from old TOOLS.H								model_id;
AnsiString	2  ts_marka				AnsiString	2  vehicle_brand_name
			3  ts_model							3  vehicle_model_name
			4  ts_vin							   vehicle_brand_name_print
			5  ts_znak							   vehicle_model_name_print;
			6  volume;				int			1  vehicle_type_id
AnsiString	7  pts_series						16 vehicle_group
			8  pts_number;						   is_registration_vehicle	
double		9  power;							17 construction_year
int			1  tstype_id						   is_new_vehicle
			X  marka_id							14 vehicle_age
			10 model_id							   res;
			11 key_count			AnsiString	10 rsa_code
			12 seat_count						4  vin
			13 type_doc_ts						   body_number		UREISCALC - DATABASE
			14 ts_age							   chassis_number	UREISCALC - DATABASE
			X  ts_ident_type					5  registration_mark
			15 max_massa						   transdekra_id
			16 group_ts							   inspection_id;
			17 ts_year				int			   required_alarm_scheme
			X  is_agreed;						   alarms[3]
TDateTime	18 pts_date							   alarms_default[3]
// from old TOOLS.H								   is_trailer
												   is_gap
												   inspection_needed
												   inspection_status;
									int			13 vehicle_registration_type_id;
									AnsiString	7  registration_series
												8  registration_number;
									TDateTime	18 registration_issue_date
												   inspection_date;
									int			15 allowed_mass
												12 number_of_seats
												9  engine_power_hp
												11 count_of_keys
												   usage_purpose_id
												   devices_state_id;
									double		6  engine_volume;

ts_marka	= vehicle_brand_name
ts_model	= vehicle_model_name
ts_vin		= vin
ts_znak		= registration_mark
volume		= engine_volume
pts_series	= registration_series
pts_number	= registration_number
power		= engine_power_hp
tstype_id	= vehicle_type_id
marka_id	= X
model_id	= rsa_code
key_count	= count_of_keys
seat_count	= number_of_seats
type_doc_ts	= vehicle_registration_type_id
ts_age		= vehicle_age
ts_ident_type = X
max_massa	= allowed_mass
group_ts	= vehicle_group
ts_year		= construction_year
is_agreed	= X
pts_date	= registration_issue_date
*/

//---------------------------------------------------------------------------

struct VehicleInfo{
   
   /* from old TOOLS.H
   AnsiString ts_marka, ts_model, ts_vin, ts_znak, volume;
   AnsiString pts_series, pts_number;
   double power;
   int tstype_id, marka_id, model_id, key_count, seat_count, type_doc_ts, ts_age, ts_ident_type, max_massa, group_ts, ts_year, is_agreed;
   TDateTime pts_date;
   //*/// from old TOOLS.H

   Variant brand_id, model_id;
   AnsiString vehicle_brand_name, vehicle_model_name, vehicle_brand_name_print, vehicle_model_name_print;
   int vehicle_type_id, vehicle_group, is_registration_vehicle, construction_year, is_new_vehicle, vehicle_age, res;
   AnsiString rsa_code, vin, body_number, chassis_number, registration_mark, transdekra_id, inspection_id;
   int required_alarm_scheme, alarms[3], alarms_default[3], is_trailer, is_gap, inspection_needed, inspection_status;

   // from old TOOLS.H
   //int big_payment1;

   int vehicle_registration_type_id;
   AnsiString registration_series, registration_number;
   TDateTime registration_issue_date, inspection_date;

   int allowed_mass, number_of_seats, engine_power_hp, count_of_keys, usage_purpose_id, devices_state_id;
   double engine_volume;

   TADOQuery *q_brands, *q_models;

   TStringList *alarms_terms, *sl_ad;

   //---------------------------------------------------------------------------

   VehicleInfo()
   {
      alarms_terms = new TStringList();
      sl_ad = new TStringList();
      sl_ad->Sorted = true;
      sl_ad->Duplicates = dupIgnore;

      Reset();
   }
   ~VehicleInfo() { delete alarms_terms; delete sl_ad; }

   void Reset()
   {
	   /*// from old TOOLS.H
	   ts_marka = ts_model = ts_vin = volume = pts_series = pts_number = empty_str;
	   pts_date.Val = 0;
	   ts_znak = "�/�";
	   tstype_id = key_count = 2;
	   type_doc_ts = 1;
	   is_agreed = ts_year = model_id = max_massa = power = seat_count = ts_age = ts_ident_type = 0;
	   group_ts = -1;
	   //*/// from old TOOLS.H

      inspection_id = transdekra_id = rsa_code = registration_mark = vehicle_brand_name = vehicle_model_name = vehicle_brand_name_print = vehicle_model_name_print = vin = body_number = chassis_number = registration_series = registration_number = empty_str;

      inspection_date.Val = registration_issue_date.Val = engine_volume = 0.0;
      vehicle_type_id = count_of_keys = 2;
      vehicle_registration_type_id = usage_purpose_id = 1;
      construction_year = allowed_mass = engine_power_hp = number_of_seats = is_new_vehicle = vehicle_age = is_trailer = is_gap = devices_state_id = inspection_needed = inspection_status = 0;
      is_registration_vehicle = vehicle_group = -1;
      required_alarm_scheme = 0;
      alarms[0] = alarms[1] = alarms[2] = 0;
      alarms_default[0] = alarms_default[1] = alarms_default[2] = 0;
      brand_id = model_id = variant_null;
      alarms_terms->Clear();
   }

   bool IsSpectech(){ return vehicle_type_id == 7; } // tstype_id
   bool IsPricep(){ return vehicle_type_id >= 8 && vehicle_type_id <= 10; }
   bool IsCar(){ return (vehicle_group < 4 || vehicle_group == 6 || vehicle_group == 7); } //group_ts

   void RecalcAge(const int curr_year, const TDateTime& calc_date)
   {
      if(curr_year - construction_year == 1 && DaysBetween(calc_date, registration_issue_date) <= 310 /*registration_issue_date > TDateTime(curr_year - 1, 7, 31) && calc_date < TDateTime(curr_year, 7, 1)*/){
         vehicle_age = 0;
      }
      else vehicle_age = curr_year - construction_year;
   }

   VehicleInfo& operator = (const VehicleInfo& val)
   {
      return *this;
   }
};
//---------------------------------------------------------------------------
struct UserInfo{
   AnsiString name, filial, osp, phone, email, post, post_normal, name_format, osp_address, filial_address, accrediting, lnr, skk, city, accrediting_number, agent_id;
   TStringList *kladr_addr_osp, *kladr_addr_filial;
   int memo_id_osp, memo_id_filial, sale_channel_id, user_id;
   TDateTime accrediting_date;

   UserInfo()
   {
      kladr_addr_filial = new TStringList();
      kladr_addr_osp = new TStringList();
      Reset();
   }

   void Reset()
   {
      post_normal = accrediting_number = name = name_format = filial = osp = phone = email = post = osp_address = filial_address = accrediting = lnr = skk = city = agent_id = empty_str;
      memo_id_osp = memo_id_filial = user_id = sale_channel_id = 0;
      kladr_addr_osp->Clear();
      kladr_addr_filial->Clear();
      accrediting_date.Val = 0.0;
   }

   ~UserInfo()
   {
      delete kladr_addr_osp;
      delete kladr_addr_filial;
   }
};
//---------------------------------------------------------------------------
struct AnderInfo{
   double summ_limit, ka_limit;
   TStringList *non_standart_str_id;
   int base_kv;

   AnderInfo()
   {
      non_standart_str_id = new TStringList();
   }

   ~AnderInfo()
   {
      delete non_standart_str_id;
   }

};

//---------------------------------------------------------------------------
/*////////////////// STRUCTURES DIFFERENCE //////////////////////////////////
/* // NEW														// OLD
struct CalcInfo{                                                  // from old TOOLS.H
double  kar, kr, kyu, bt, k1, k2, k3, k4, k5, k6, k7,                 double  kss_old
double  ka, ks, krs, kpr, kb, kkv, kd, kfr, kbfprlg, kgap;                    kss_new
double  osn_risk_itog_tarif                                                   kss_sum_limit
        coef_prop                                                             kss_premium_limit;
        old_premium_paid;                                                     kdiscount;
double  premiya_osn_risk                                                      payment1;
        premiya_dsago                                                         str_summa1
        premiya_all                                                           str_summa2
        premiya_ns                                                            cost_vehicle_new;
        payed_sum
        premiya_dms                                                   double  anderr_summ_limit
        premiya_gap                                                           anderr_ka_limit;
        pnd_premium_exp                                               double  coeff_limit;
        pnd_premium_tech;                                             int     anderr_dsago
double  premiya_osn_risk_for_bp                                               anderr_variant_b
        min_premiya_osn_risk                                                  risk_model
        cost_tdr                                                              cross_error;
        cost_min                                                      std::map<int, double=""> min_premium_ekonom, kpr_dtp;
        cost_max                                                  // from old TOOLS.H
        cost_vehicle
        old_cost_vehicle
        str_summa                                                    CalcInfo()
        str_summa_ns                                                 {
        old_str_summa                                             	   // from old TOOLS.H
        old_premium                                               		min_premium_ekonom[1] = 10000;
        paid                                                      		min_premium_ekonom[2] = 15000;
        payment_part[12]                                          		min_premium_ekonom[3] = 33000;
        curr_limit                                                		min_premium_ekonom[6] = 8000;
        claims_damages                                            		min_premium_ekonom[7] = 8000;
        pnd_liability_exp                                         		// from old TOOLS.H
        pnd_liability_tech;

std::map<AnsiString, int="">
  base_kv;
  std::map<int, AnsiString="">
    k1_fr;
    int liab_type, damage_limit, str_summa_dsago, str_summa_dms, type_of_calc;
*/

//---------------------------------------------------------------------------
struct CalcInfo{
   double kar, kr, kyu, bt, k1, k2, k3, k4, k5, k6, k7, ka, ks, krs, kpr, kb, kkv, kd, kfr, kbfprlg, kgap;
   double osn_risk_itog_tarif, coef_prop, old_premium_paid;
   double premiya_osn_risk_orig, premiya_osn_risk_ufo;
   double premiya_osn_risk, premiya_dsago, premiya_all, premiya_ns, payed_sum, premiya_dms, premiya_gap, pnd_premium_exp, pnd_premium_tech;
   double premiya_osn_risk_for_bp, min_premiya_osn_risk, cost_tdr, cost_min, cost_max, cost_vehicle, old_cost_vehicle, str_summa, str_summa_ns, old_str_summa, old_premium, paid, payment_part[12], curr_limit, claims_damages, pnd_liability_exp, pnd_liability_tech;

   std::map<AnsiString, int> base_kv;
   std::map<int, AnsiString> k1_fr;
   int liab_type, damage_limit, str_summa_dsago, str_summa_dms, type_of_calc;


   // from old TOOLS.H
   double kss_old, kss_new, kss_sum_limit, kss_premium_limit;
   double kdiscount;
   double payment1;
   double str_summa1, str_summa2, cost_vehicle_new;
   // from old TOOLS.H
   double anderr_summ_limit, anderr_ka_limit;
   double coeff_limit;
   int anderr_dsago, anderr_variant_b, risk_model, cross_error;
   std::map<int, double> min_premium_ekonom, kpr_dtp;
   // from old TOOLS.H

   CalcInfo()
   {
	   // from old TOOLS.H
		min_premium_ekonom[1] = 10000;
		min_premium_ekonom[2] = 15000;
		min_premium_ekonom[3] = 33000;
		min_premium_ekonom[6] = 8000;
		min_premium_ekonom[7] = 8000;
		// from old TOOLS.H

	   k1_fr[11] = "2"; k1_fr[12] = "2"; k1_fr[13] = "2"; k1_fr[14] = "3"; k1_fr[15] = "3"; k1_fr[16] = "3";
      
      Reset();
   }

   void Reset()
   {
      old_premium_paid = claims_damages = min_premiya_osn_risk = premiya_osn_risk_orig = premiya_osn_risk_ufo = old_cost_vehicle = premiya_osn_risk_for_bp = cost_tdr = cost_min = cost_max = cost_vehicle = str_summa  = str_summa_ns = payed_sum = premiya_osn_risk_for_bp = premiya_ns = old_str_summa = old_premium = premiya_gap = premiya_all = 0.0;
      curr_limit = 2500000;
      coef_prop = bt = k1 = k2 = k3 = k4 = k5 = k6 = k7 = kar = kr = krs = ks = kpr = kb = kfr = kkv = kbfprlg = ka = kgap = 1.0;
      liab_type = type_of_calc = 1;
      damage_limit = str_summa_dsago = str_summa_dms = premiya_dms = str_summa = str_summa_ns = 0;
   }

   void SetPremiumNull()
   {
      //str_summa = str_summa_dsago = str_summa_ns = str_summa_dms = pnd_liability_exp = pnd_liability_tech = 0;
      osn_risk_itog_tarif = premiya_all = premiya_osn_risk = premiya_osn_risk_orig = premiya_osn_risk_ufo = premiya_dsago = premiya_ns = premiya_dms = pnd_premium_exp = pnd_premium_tech = premiya_gap = 0;
   }
};
//---------------------------------------------------------------------------
/*////////////////// STRUCTURES DIFFERENCE //////////////////////////////////
/* // OLD								// NEW
struct Dogovor_Info {				struct Dogovor_Info {
AnsiString	X  last_contract_id				
TDateTime	1  payment_date[4]		TDateTime	1 payment_date[12]
int									int
			2  no_calc_k5						2 no_calc
			X  no_calc_k6						
			X	big_payment1								
			X	shedule_type_id								
			4X	system (INT)		AnsiString	4 system (STRING)				
			X	payment_status[4]							
TStringList X5 *non_standart_str_print;			5 *non_standart_str_id;		
//*/
//---------------------------------------------------------------------------
struct Dogovor_Info{
   AnsiString polis_seria, polis_number, atypical_number, prev_seria, prev_number, credit_number, zalog_number, calc_date, params[5], pd_series, pd_number, authorization_code, comments_sign[6], contract_id, bank_code, risk_object_forkv;
   TDateTime polis_date, datesrok_s, datesrok_po, credit_date, zalog_date, statement_date, cancell_date, payment_date[12], last_polis_ed_incday, pd_date, email_date;
   int region_id, status_dogovor, dogovor_type, monthcount, bank_id, type_money, contract_type, reiss_type, REGION_TYPE, count_accidents, no_calc, ts_count, old_programm_id, calc_type;
   int product_id, risk, type_multydrive, payments_count, programm_id, project_id, pay_id, franshize_id, franshize_unit, comments_mid[6], sale_channel_id, system_insur, variant, franshize_size;
   int mid_validation, mid_non_standart, mid_oi_errors, approvalstatus, vehcount, contract_type_precalc, k56precalc_parameter, index_max_k6, count_permitted;
   int no_calc_k5, no_calc_k6;
   double vzd, base_vzd;
   AnsiString system_error, time_s, product_name, last_contract, system, bp_error_text, calculation_id;
   TStringList *non_standart_str_calc, *validations_errors, *insbridge_errors, *what_change, *data_print, *non_standart_str_id;
   bool is_ander_login, is_new_dogovor, is_msoff, is_opoff, black_print;
   MapStrSetInt MR;
   std::map<AnsiString, MapIntDouble> MRCoeffs;
   std::map<int, AnsiString> statusname, form_apo_ufo;
   std::set<int> prg_comfort, partner_sale_channel, mop_sale_channel;
   CalcInfo calc_info;
   UserInfo user_info;
   AnderInfo ander_info;
   TADOQuery *q_banks, *q_regions;

   // from old TOOLS.H
   //int big_payment1;

   Dogovor_Info() : is_ander_login(false)
   {
      non_standart_str_calc = new TStringList();
      non_standart_str_id = new TStringList();
      validations_errors = new TStringList();
      insbridge_errors = new TStringList();
      what_change = new TStringList();
      data_print = new TStringList();

      statusname[10] = "�� ������������";
      statusname[11] = "�����������";
      statusname[12] = "�� �����������";
      statusname[13] = "������� ��������";
      statusname[14] = "������ ���. ������";

      CLSID cid;
      is_msoff = (CLSIDFromProgID(L"Excel.Application",           &cid) == S_OK);
      is_opoff = (CLSIDFromProgID(L"com.sun.star.ServiceManager", &cid) == S_OK);

      prg_comfort.insert(1261);
      prg_comfort.insert(1262);
      prg_comfort.insert(1263);
      prg_comfort.insert(1264);
      prg_comfort.insert(1276);

      partner_sale_channel.insert(141);
      partner_sale_channel.insert(144);
      partner_sale_channel.insert(145);
      partner_sale_channel.insert(310);
      partner_sale_channel.insert(340);
      partner_sale_channel.insert(360);
      partner_sale_channel.insert(390);

      mop_sale_channel.insert(131);
      mop_sale_channel.insert(132);
      mop_sale_channel.insert(133);
      mop_sale_channel.insert(135);

      form_apo_ufo[301] = "����� �����-���� ������";
      form_apo_ufo[302] = "����� �����-���� ������";
      form_apo_ufo[303] = "����� �����-���� ������";
      form_apo_ufo[304] = "����� �����-���� ������";
      form_apo_ufo[305] = "����� �����-���� ������";
      form_apo_ufo[306] = "����� �����-���� ������";
      form_apo_ufo[307] = "����������";
      form_apo_ufo[308] = "����������";
      form_apo_ufo[311] = "������ �������";
      form_apo_ufo[316] = "������ �� ���";
      form_apo_ufo[317] = "������ �� ���";
   }

   void Reset()
   {
      calc_info.Reset();
      user_info.Reset();
      contract_id = authorization_code = pd_series = pd_number = polis_seria = polis_number = prev_seria = prev_number = credit_number = zalog_number = bp_error_text = calculation_id = empty_str;
      vehcount = no_calc = ts_count = REGION_TYPE = status_dogovor = dogovor_type = contract_type_precalc = system_insur = 1;
      monthcount = 12;
	  no_calc_k5 = no_calc_k6 = 0; // ������ ������ ������ �������������� � ������� !!!!
	  franshize_unit = mid_oi_errors = mid_non_standart = mid_validation = calc_type = old_programm_id = count_accidents = bank_id = type_money = contract_type = reiss_type = sale_channel_id = variant = franshize_size = 0;
      ResetPayments();
      datesrok_s = payment_date[0] = statement_date = polis_date = pd_date = email_date = Date();
      datesrok_po = IncDay(IncYear(datesrok_s), -1);
      calc_date = polis_date.DateString();
      last_polis_ed_incday.Val = vzd = base_vzd = 0.0;
      risk = 2;
      product_id = 301;
      product_name = "����� �";
      type_multydrive = 1;
      pay_id = 3;
      payments_count = franshize_id = 1;
      last_contract = system = empty_str;
      for(int i = 0; i < 6; ++i){ comments_mid[i] = 0; comments_sign[i] = empty_str; }
      ResetErrors();
      MR.clear(); MRCoeffs.clear();
      risk_object_forkv = "_ROOT1000000KASKOA1024222";
      k56precalc_parameter = index_max_k6 = -1;
      count_permitted = 0;
      black_print = false;
      what_change->Clear();
      data_print->Clear();
   }

   void ResetPayments()
   {
      for(int i = 0; i < 12; ++i){
         calc_info.payment_part[i] = 0;
         payment_date[i].Val = 0;
      }
   }

   void ResetErrors()
   {
      non_standart_str_calc->Clear();
      non_standart_str_id->Clear();
      validations_errors->Clear();
      insbridge_errors->Clear();
      system_error = empty_str;
   }

   AnsiString ParamToStr()
   {
      AnsiString result("");
      for(int i = 0; i < 5; ++i) if(!params[i].IsEmpty()) result = result + params[i] + ";";
      return result.SubString(1, result.Length() - 1);
   }

   void StrToParams(const AnsiString& str)
   {
      TStringList *prm = new TStringList();
      prm->Text = StringReplace(str, ";", "\r\n", rf);
      for(int i = 0, cnt = prm->Count; i < cnt; ++i) params[i] = prm->Strings[i];
      delete prm;
   }

   bool IsZdtp()
   {
      return (product_id == 316 || product_id == 317); 
   }

   bool DtpInCrimea()
   {
	   return (region_id == 91 || region_id == 92) && programm_id == 1286;
   }

   ~Dogovor_Info()
   {
      delete non_standart_str_calc;
      delete validations_errors;
      delete insbridge_errors;
      delete what_change;
      delete data_print;
      delete non_standart_str_id;
   }
};
//---------------------------------------------------------------------------
struct AddDevice{
   int id;
   AnsiString name_dict, name_detail;
   double cost;

   AddDevice& operator = (const AddDevice& val){
      id = val.id;
      name_dict = val.name_dict;
      name_detail = val.name_detail;
      cost = val.cost;

      return *this;
   }
   bool operator == (const AddDevice& val){
      return id == val.id && cost == val.cost;
   }
   bool operator != (const AddDevice& val){
      return id != val.id || cost != val.cost;
   }
   void Reset()
   {
	   id = 0;
	   name_dict = "";
	   name_detail = "";
	   cost = 0.0;
   }
};
//---------------------------------------------------------------------------
struct Reason_Surcharge{
   int surcharge_recalc, surcharge_constant, select;
   double surcharge_const_value;

   Reason_Surcharge() {}
   Reason_Surcharge(const int v1, const int v2) : surcharge_recalc(v1), surcharge_constant(v2), surcharge_const_value(0.0), select(0) {}
};
//---------------------------------------------------------------------------
class DTimer: public TObject{
   public:
      TTimer *tm;
      __fastcall DTimer();
      __fastcall ~DTimer();
      void __fastcall OnTimerTM(TObject *Sender);
};
__fastcall DTimer::DTimer()
{
   tm = new TTimer(NULL);
   tm->Interval = 900000; // 15 �����
   tm->OnTimer = OnTimerTM;
   //tm->Enabled = true;
   tm->Enabled = false;
}
__fastcall DTimer::~DTimer()
{
   delete tm;
}


#endif
