// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>0
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>1
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>2
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>3
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>4
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>5
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>6
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>7
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>8
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>9
//  >Import : https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl>10
// Encoding : utf-8
// Codegen  : [wfMapStringsToWideStrings+, wfUseSerializerClassForAttrs-]
// Version  : 1.0
// (20.04.2017 15:46:43 - - $Rev: 16699 $)
// ************************************************************************ //

#include "UWriteSoap.h"
#pragma hdrstop

#if !defined(KaskoProxyServiceH)
#include "KaskoProxyService.h"
#endif



namespace NS_KaskoProxyService {

_di_IKaskoProxyService GetIKaskoProxyService(bool useWSDL, AnsiString addr, THTTPRIO* HTTPRIO)
{
  static const char* defWSDL= "https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl";
  static const char* defURL = "https://ufot.rgs.ru:8443/KaskoProxyService.svc";
  static const char* defSvc = "KaskoProxyService";
  static const char* defPrt = "BasicHttpsBinding_IKaskoProxyService";
  if (addr=="")
    addr = useWSDL ? defWSDL : defURL;

  rio_be rbe;
  THTTPRIO *rio = HTTPRIO ? HTTPRIO : new THTTPRIO(0);
  rio->OnBeforeExecute = rbe.HTTPRIOBeforeExecute;
  rio->OnAfterExecute = rbe.HTTPRIOAfterExecute;

  if (useWSDL) {
    rio->WSDLLocation = addr;
    rio->Service = defSvc;
    rio->Port = defPrt;
  } else {
    rio->URL = addr;
  }
  _di_IKaskoProxyService service;
  rio->QueryInterface(service);
  if (!service && !HTTPRIO)
    delete rio;
  return service;
}


__fastcall CalculationRequest::~CalculationRequest()
{
  delete FInsurant;
  delete FPlanVzd;
  for(int i=0; i<FVehicles.Length; i++)
    if (FVehicles[i])
      delete FVehicles[i];
}

__fastcall Insurant::~Insurant()
{
  delete FBirthDate;
  delete FDocument;
  delete FName;
  delete FOrganization;
}

__fastcall Vehicle::~Vehicle()
{
  delete FAccidentLiability;
  delete FCost;
  delete FDmsLiability;
  delete FDsagoLiability;
  delete FDsagoPremium;
  delete FFranchise;
  delete FKa;
  delete FKans;
  delete FKc;
  delete FLiability;
  delete FTransdekraPrice;
  delete FVehMileage;
  delete FVehicleDamageSumLimit;
  delete FVehiclePTSDate;
  for(int i=0; i<FAddEquipments.Length; i++)
    if (FAddEquipments[i])
      delete FAddEquipments[i];
  for(int i=0; i<FDrivers.Length; i++)
    if (FDrivers[i])
      delete FDrivers[i];
}

__fastcall Franchise::~Franchise()
{
  delete FValue;
}

__fastcall AddEquipmentRequest::~AddEquipmentRequest()
{
  delete FLiability;
}

__fastcall Driver::~Driver()
{
  delete FBirthDate;
  delete FDriverLicense;
  delete FDrivingStartDate;
  delete FFullName;
}

__fastcall KaskoReCalculateRequest::~KaskoReCalculateRequest()
{
  for(int i=0; i<FReCalculateVehicles.Length; i++)
    if (FReCalculateVehicles[i])
      delete FReCalculateVehicles[i];
}

__fastcall KaskoReCalculateVehicle::~KaskoReCalculateVehicle()
{
  delete FKpr;
  delete FVehiclePtsDate;
}

__fastcall CalculationResult::~CalculationResult()
{
  delete FCalculationDate;
  delete FInsurantK5;
  delete FInsurantK6;
  delete FPolicyPremium;
  for(int i=0; i<FUsagePeriods.Length; i++)
    if (FUsagePeriods[i])
      delete FUsagePeriods[i];
  for(int i=0; i<FVehicleResults.Length; i++)
    if (FVehicleResults[i])
      delete FVehicleResults[i];
}

__fastcall UsagePeriod::~UsagePeriod()
{
  delete FUsagePeriodEndDate;
  delete FUsagePeriodStartDate;
}

__fastcall Coefficients::~Coefficients()
{
  delete FK1;
  delete FK1D;
  delete FK2;
  delete FK3;
  delete FK4;
  delete FK5;
  delete FK6;
  delete FK7A;
  delete FKA;
  delete FKAR;
  delete FKAct;
  delete FKB;
  delete FKC;
  delete FKPR;
  delete FKPRisk;
  delete FKR;
  delete FKRS;
  delete FKReservation;
  delete FKSR;
  delete FKU;
  delete FKVozv;
  delete FKY;
  delete FKans;
  delete FTB;
  delete FTariff;
  delete FTariffPrefProlongation;
}

__fastcall PaymentDto::~PaymentDto()
{
  delete FValue;
}

__fastcall PrevPolicyDto::~PrevPolicyDto()
{
  delete FEndDate;
  delete FKaskoLiability;
  delete FKaskoPremium;
  delete FPaySumLoss;
  delete FVehicleCost;
}

__fastcall VehicleCalculationResult::~VehicleCalculationResult()
{
  delete FAccidentLiability;
  delete FAccidentPremium;
  delete FDmsPremium;
  delete FDsagoLiability;
  delete FDsagoVehiclePremium;
  delete FFranchiseJokerSum;
  delete FK;
  delete FKaskoTotal;
  delete FKaskoVehicleGapPremium;
  delete FLiabilityCostProportion;
  delete FPayment1;
  delete FPayment2;
  delete FPayment3;
  delete FPayment4;
  delete FPndLiabilityExp;
  delete FPndLiabilityTech;
  delete FPndPremiumExp;
  delete FPndPremiumTech;
  delete FPrevPolicy;
  delete FTransdekraMaxPrice;
  delete FTransdekraMinPrice;
  delete FTransdekraPrice;
  delete FUnderwritingRequirements;
  delete FVehicleGapCoeff;
  delete FVehiclePremium;
  delete FVehiclePremiumPrefProlCoeff;
  delete FVehiclePremiumPrefProlongation;
  for(int i=0; i<FAddEquipments.Length; i++)
    if (FAddEquipments[i])
      delete FAddEquipments[i];
  for(int i=0; i<FAdmitResults.Length; i++)
    if (FAdmitResults[i])
      delete FAdmitResults[i];
  for(int i=0; i<FPrevContractIds.Length; i++)
    if (FPrevContractIds[i])
      delete FPrevContractIds[i];
  for(int i=0; i<FReservations.Length; i++)
    if (FReservations[i])
      delete FReservations[i];
  for(int i=0; i<FRiskObjects.Length; i++)
    if (FRiskObjects[i])
      delete FRiskObjects[i];
}

__fastcall AddEquipmentResponse::~AddEquipmentResponse()
{
  delete FPremium;
}

__fastcall AdmitResultsDto::~AdmitResultsDto()
{
  delete FK1Driver;
  delete FK6Driver;
  for(int i=0; i<FDriverPrevContracts.Length; i++)
    if (FDriverPrevContracts[i])
      delete FDriverPrevContracts[i];
}

__fastcall ReservationCoefficient::~ReservationCoefficient()
{
  delete FValue;
}

__fastcall RiskObject::~RiskObject()
{
  delete FLiability;
  delete FPremium;
  delete FTariff;
}

__fastcall KaskoUnderwritingRequirements::~KaskoUnderwritingRequirements()
{
  delete FCO;
  delete FCSKA;
  delete FControllerPse;
  delete FCorpZam;
  delete FFilial;
  delete FPartnerZam;
  delete FSecurity;
  for(int i=0; i<FReasonIds.Length; i++)
    if (FReasonIds[i])
      delete FReasonIds[i];
}

__fastcall ContractorName::~ContractorName()
{
  delete FIndividualPerson;
  delete FLegalEntity;
}

__fastcall Pledgeholder::~Pledgeholder()
{
  delete FLegalEntity;
}

__fastcall PrintCertificateRequest::~PrintCertificateRequest()
{
  delete FPremiumTsDo;
}

__fastcall PrintRequest::~PrintRequest()
{
  delete FBeneficiary;
  delete FBrandModel;
  delete FInsurantAddress;
  delete FInsurer;
  delete FInsurerProxy;
  delete FPledgeholder;
}

__fastcall Signer::~Signer()
{
  delete FDocument;
  delete FName;
}

__fastcall AppInsurer::~AppInsurer()
{
  delete FName;
}

__fastcall PrintAppRequest::~PrintAppRequest()
{
  delete FInsurant;
  delete FInsurantRepresentative;
  delete FInsurer;
  delete FInsurerRepresentative;
  for(int i=0; i<FVehicles.Length; i++)
    if (FVehicles[i])
      delete FVehicles[i];
}

__fastcall PrintAppVehicle::~PrintAppVehicle()
{
  delete FBrandModel;
  delete FInspection;
}

__fastcall PrintAppRequestUl::~PrintAppRequestUl()
{
  delete FAdditionalExpensesPremKop;
  delete FAdditionalExpensesPremRub;
  delete FMedicalCarePremKop;
  delete FMedicalCarePremRub;
  delete FPayPeriod1;
  delete FPayPeriod2;
  delete FPayPeriod3;
  delete FPayPeriod4;
  delete FPayPeriod5;
  delete FPremiumDSAGOKop;
  delete FPremiumDSAGORub;
  delete FPremiumKASCOKop;
  delete FPremiumKASCORub;
  delete FPremiumNSKop;
  delete FPremiumNSRub;
  delete FTechnicalAssistancePremKop;
  delete FTechnicalAssistancePremRub;
  delete FTotalPremiumKop;
  delete FTotalPremiumRub;
  for(int i=0; i<FKascoAppInsRiskPeriod1.Length; i++)
    if (FKascoAppInsRiskPeriod1[i])
      delete FKascoAppInsRiskPeriod1[i];
  for(int i=0; i<FKascoAppInsRiskPeriod2.Length; i++)
    if (FKascoAppInsRiskPeriod2[i])
      delete FKascoAppInsRiskPeriod2[i];
  for(int i=0; i<FKascoAppInsRiskPeriod3.Length; i++)
    if (FKascoAppInsRiskPeriod3[i])
      delete FKascoAppInsRiskPeriod3[i];
  for(int i=0; i<FKascoAppInsRiskPeriod4.Length; i++)
    if (FKascoAppInsRiskPeriod4[i])
      delete FKascoAppInsRiskPeriod4[i];
  for(int i=0; i<FKascoAppInsRiskPeriod5.Length; i++)
    if (FKascoAppInsRiskPeriod5[i])
      delete FKascoAppInsRiskPeriod5[i];
  for(int i=0; i<FVehicleData.Length; i++)
    if (FVehicleData[i])
      delete FVehicleData[i];
}

__fastcall PrintContractRequest::~PrintContractRequest()
{
  delete FBeneficiary;
  delete FInsurant;
  delete FInsurer;
  delete FPayments;
}

__fastcall BeneficiaryPrintRequest::~BeneficiaryPrintRequest()
{
  delete FName;
  delete FOrganization;
}

__fastcall ContractInsurant::~ContractInsurant()
{
  delete FAddress;
  delete FPassport;
  delete FProxy;
  delete FSigner;
  delete FSignerGenitive;
}

__fastcall ContractInsurer::~ContractInsurer()
{
  delete FName;
  delete FNameGenitive;
  delete FProxy;
}

__fastcall Payments::~Payments()
{
  delete FFirstPayment;
  delete FFourthPayment;
  delete FNextPaymentSum;
  delete FSecondPayment;
  delete FThirdPayment;
}

__fastcall Passport::~Passport()
{
  delete FDate;
}

__fastcall Payment::~Payment()
{
  delete FSum;
}

__fastcall KaskoPrintContractUlRequestDto::~KaskoPrintContractUlRequestDto()
{
  delete FLeasingContract;
  delete FLessee;
  delete FPayer;
}

__fastcall Beneficiary::~Beneficiary()
{
  delete FBirthDate;
  delete FDocument;
  delete FOrganization;
  delete FPerson;
  delete FRegistrationAddressCompany;
}

__fastcall LeaseHolder::~LeaseHolder()
{
  delete FBirthDate;
  delete FDocument;
  delete FOrganization;
  delete FPerson;
  delete FRegistrationAddressCompany;
}

__fastcall UnderwritingAdditionalInfo::~UnderwritingAdditionalInfo()
{
  delete FBeneficiary;
  delete FInsurer;
  delete FLeaseHolder;
  delete FProlongTillDate;
  for(int i=0; i<FGroups.Length; i++)
    if (FGroups[i])
      delete FGroups[i];
  for(int i=0; i<FVehicleAdditionalInfos.Length; i++)
    if (FVehicleAdditionalInfos[i])
      delete FVehicleAdditionalInfos[i];
  for(int i=0; i<FVehicleProlongations.Length; i++)
    if (FVehicleProlongations[i])
      delete FVehicleProlongations[i];
}

__fastcall QuotationStateInfo::~QuotationStateInfo()
{
  delete FQuotation;
  for(int i=0; i<FVehicleStateInfos.Length; i++)
    if (FVehicleStateInfos[i])
      delete FVehicleStateInfos[i];
}

__fastcall Quotation::~Quotation()
{
  delete FBeneficiary;
  delete FInsurant;
  for(int i=0; i<FVehicles.Length; i++)
    if (FVehicles[i])
      delete FVehicles[i];
}

__fastcall VehicleResult::~VehicleResult()
{
  delete FCost;
  delete FFranchise;
  delete FLiability;
}

__fastcall VehicleStateInfo::~VehicleStateInfo()
{
  for(int i=0; i<FComments.Length; i++)
    if (FComments[i])
      delete FComments[i];
}

__fastcall CalculateVzdRequest::~CalculateVzdRequest()
{
  delete FCalculationDate;
  for(int i=0; i<FVehicles.Length; i++)
    if (FVehicles[i])
      delete FVehicles[i];
}

__fastcall CalculateVzdVehicleRequest::~CalculateVzdVehicleRequest()
{
  delete FChanchedVZD;
  delete FKc;
}

__fastcall CalculateVzdResult::~CalculateVzdResult()
{
  for(int i=0; i<FVehicles.Length; i++)
    if (FVehicles[i])
      delete FVehicles[i];
}

__fastcall CalculateVzdVehicleResponse::~CalculateVzdVehicleResponse()
{
  delete FChanchedVZD;
  delete FKaskoKC;
  delete FPlanVZD;
}

__fastcall PrintULAddAgreementRequest::~PrintULAddAgreementRequest()
{
  delete FInsurantRepresentative;
  delete FInsurerProxy;
  delete FInsurerRepresentative;
  for(int i=0; i<FAddEquipmentInfo.Length; i++)
    if (FAddEquipmentInfo[i])
      delete FAddEquipmentInfo[i];
}

__fastcall PrintULBLAddAgreementRequest::~PrintULBLAddAgreementRequest()
{
  for(int i=0; i<FAddEquipmentByVehicle.Length; i++)
    if (FAddEquipmentByVehicle[i])
      delete FAddEquipmentByVehicle[i];
  for(int i=0; i<FPeriodList.Length; i++)
    if (FPeriodList[i])
      delete FPeriodList[i];
}

__fastcall CalculationSheet::~CalculationSheet()
{
  delete FCalculatedBy;
}

__fastcall KaskoFLSpecialRequest::~KaskoFLSpecialRequest()
{
  delete FBeneficiary;
  delete FFirstPayment;
  delete FInspection;
  delete FInsurant;
  delete FInsurerProxy;
  delete FRegistrationAgency;
  delete FSberbank;
  delete FVehicleData;
  for(int i=0; i<FAddEquipmentsInfo.Length; i++)
    if (FAddEquipmentsInfo[i])
      delete FAddEquipmentsInfo[i];
}

__fastcall KaskoAutoProtectionRequest::~KaskoAutoProtectionRequest()
{
  delete FBeneficiary;
  delete FFirstPayment;
  delete FInspection;
  delete FInsurant;
  delete FInsurerProxy;
  delete FMigrationCard;
  delete FPermissionForStay;
  delete FRegistrationAgency;
  delete FSberbank;
  delete FVehicleData;
  for(int i=0; i<FAddEquipmentsInfo.Length; i++)
    if (FAddEquipmentsInfo[i])
      delete FAddEquipmentsInfo[i];
}

__fastcall KaskoAutoProtectionRequestUL::~KaskoAutoProtectionRequestUL()
{
  delete FBeneficiary;
  delete FFirstPayment;
  delete FInspection;
  delete FInsurantAdditionalInfo;
  delete FInsurantRegistrationAgency;
  delete FInsurerProxy;
  delete FLessee;
  delete FLesseeAdditionalInfo;
  delete FLesseeRegistrationAgency;
  delete FSberbank;
  for(int i=0; i<FAddEquipmentsInfo.Length; i++)
    if (FAddEquipmentsInfo[i])
      delete FAddEquipmentsInfo[i];
  for(int i=0; i<FVehicleData.Length; i++)
    if (FVehicleData[i])
      delete FVehicleData[i];
}

__fastcall DateTimeOffset::~DateTimeOffset()
{
  delete FDateTime;
}

__fastcall OperationResultOfSelfTestResultBmLUPtsk::~OperationResultOfSelfTestResultBmLUPtsk()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfEarlyApproveResultoTurZuT3::~OperationResultOfEarlyApproveResultoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfCalculateVzdResultoTurZuT3::~OperationResultOfCalculateVzdResultoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfQuotationStateInfooTurZuT3::~OperationResultOfQuotationStateInfooTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfContractStatusNamesmxVaabBO::~OperationResultOfContractStatusNamesmxVaabBO()
{
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfPrintResult1QqCV82X::~OperationResultOfPrintResult1QqCV82X()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfCalculationResultoTurZuT3::~OperationResultOfCalculationResultoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfArrayOfPrintResult1QqCV82X::~OperationResultOfArrayOfPrintResult1QqCV82X()
{
  for(int i=0; i<FData.Length; i++)
    if (FData[i])
      delete FData[i];
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall KeyValuePairOfstringVehicleAddInformationo_S6zkk9u::~KeyValuePairOfstringVehicleAddInformationo_S6zkk9u()
{
  delete Fvalue;
}

__fastcall BLTSInsRiskDto::~BLTSInsRiskDto()
{
  delete FAdditionalExpensesPrem;
  delete FAdditionalExpensesSum;
  delete FFranchiseKASCO;
  delete FInsPremiumDSAGO;
  delete FInsPremiumNS;
  delete FInsSummDSAGO;
  delete FInsSummNS;
  delete FMedicalCarePrem;
  delete FMedicalCareSum;
  delete FPremiumKASCO;
  delete FSummKASCO;
  delete FTSPremium;
  delete FTSPremiumPeriod;
  delete FTechnicalAssistancePrem;
  delete FTechnicalAssistanceSum;
}

__fastcall BLPeriodDto::~BLPeriodDto()
{
  delete FPremium;
  for(int i=0; i<FHp.Length; i++)
    if (FHp[i])
      delete FHp[i];
}

__fastcall BLPaymentDto::~BLPaymentDto()
{
  delete FValue;
}

__fastcall AddEquipmentByVehicle::~AddEquipmentByVehicle()
{
  for(int i=0; i<FAddEquipmentInfo.Length; i++)
    if (FAddEquipmentInfo[i])
      delete FAddEquipmentInfo[i];
}

__fastcall BLInsPeriod::~BLInsPeriod()
{
  delete FPremium1;
  delete FPremium2;
  delete FPremium3;
  delete FSum1;
  delete FSum2;
  delete FSum3;
}

__fastcall SelfTestResult::~SelfTestResult()
{
  for(int i=0; i<FChildren.Length; i++)
    if (FChildren[i])
      delete FChildren[i];
}

// ************************************************************************ //
// This routine registers the interfaces and types exposed by the WebService.
// ************************************************************************ //
static void RegTypes()
{
  /* IKaskoProxyService */
  InvRegistry()->RegisterInterface(__delphirtti(IKaskoProxyService), L"Rgs.Ufo", L"utf-8");
  InvRegistry()->RegisterDefaultSOAPAction(__delphirtti(IKaskoProxyService), L"Rgs.Ufo/IKaskoProxyService/%operationName%");
  InvRegistry()->RegisterInvokeOptions(__delphirtti(IKaskoProxyService), ioDocument);
  /* User */
  RemClassRegistry()->RegisterXSClass(__classid(User), L"Rgs.Ufo", L"User");
  /* ArrayOfVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicle), L"Rgs.Ufo", L"ArrayOfVehicle");
  /* CalculationRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalculationRequest), L"Rgs.Ufo", L"CalculationRequest");
  /* Insurant */
  RemClassRegistry()->RegisterXSClass(__classid(Insurant), L"Rgs.Ufo", L"Insurant");
  /* PersonName */
  RemClassRegistry()->RegisterXSClass(__classid(PersonName), L"Rgs.Ufo", L"PersonName");
  /* LegalEntity */
  RemClassRegistry()->RegisterXSClass(__classid(LegalEntity), L"Rgs.Ufo", L"LegalEntity");
  /* Document */
  RemClassRegistry()->RegisterXSClass(__classid(Document), L"Rgs.Ufo", L"Document");
  /* InsurantDocument */
  RemClassRegistry()->RegisterXSClass(__classid(InsurantDocument), L"Rgs.Ufo", L"InsurantDocument");
  /* ArrayOfAddEquipmentRequest */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentRequest), L"Rgs.Ufo", L"ArrayOfAddEquipmentRequest");
  /* ArrayOfstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfstring), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfstring");
  /* VehicleBaseDto */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleBaseDto), L"Rgs.Ufo", L"VehicleBaseDto");
  /* ArrayOfDriver */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriver), L"Rgs.Ufo", L"ArrayOfDriver");
  /* Vehicle */
  RemClassRegistry()->RegisterXSClass(__classid(Vehicle), L"Rgs.Ufo", L"Vehicle");
  /* Franchise */
  RemClassRegistry()->RegisterXSClass(__classid(Franchise), L"Rgs.Ufo", L"Franchise");
  /* AddEquipmentRequest */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentRequest), L"Rgs.Ufo", L"AddEquipmentRequest");
  /* Driver */
  RemClassRegistry()->RegisterXSClass(__classid(Driver), L"Rgs.Ufo", L"Driver");
  /* DriverLicense */
  RemClassRegistry()->RegisterXSClass(__classid(DriverLicense), L"Rgs.Ufo", L"DriverLicense");
  /* ArrayOfKaskoReCalculateVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKaskoReCalculateVehicle), L"Rgs.Ufo", L"ArrayOfKaskoReCalculateVehicle");
  /* KaskoReCalculateRequest */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoReCalculateRequest), L"Rgs.Ufo", L"KaskoReCalculateRequest");
  /* KaskoReCalculateVehicle */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoReCalculateVehicle), L"Rgs.Ufo", L"KaskoReCalculateVehicle");
  /* ArrayOfUsagePeriod */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfUsagePeriod), L"Rgs.Ufo", L"ArrayOfUsagePeriod");
  /* ArrayOfVehicleCalculationResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleCalculationResult), L"Rgs.Ufo", L"ArrayOfVehicleCalculationResult");
  /* CalculationResult */
  RemClassRegistry()->RegisterXSClass(__classid(CalculationResult), L"Rgs.Ufo", L"CalculationResult");
  /* UsagePeriod */
  RemClassRegistry()->RegisterXSClass(__classid(UsagePeriod), L"Rgs.Ufo", L"UsagePeriod");
  /* ArrayOfAddEquipmentResponse */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentResponse), L"Rgs.Ufo", L"ArrayOfAddEquipmentResponse");
  /* ArrayOfAdmitResultsDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAdmitResultsDto), L"Rgs.Ufo", L"ArrayOfAdmitResultsDto");
  /* Coefficients */
  RemClassRegistry()->RegisterXSClass(__classid(Coefficients), L"Rgs.Ufo", L"Coefficients");
  /* PaymentDto */
  RemClassRegistry()->RegisterXSClass(__classid(PaymentDto), L"Rgs.Ufo", L"PaymentDto");
  /* ArrayOfPrevContractIdDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrevContractIdDto), L"Rgs.Ufo", L"ArrayOfPrevContractIdDto");
  /* PrevPolicyDto */
  RemClassRegistry()->RegisterXSClass(__classid(PrevPolicyDto), L"Rgs.Ufo", L"PrevPolicyDto");
  /* ArrayOfReservationCoefficient */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfReservationCoefficient), L"Rgs.Ufo", L"ArrayOfReservationCoefficient");
  /* ArrayOfRiskObject */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfRiskObject), L"Rgs.Ufo", L"ArrayOfRiskObject");
  /* VehicleCalculationResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleCalculationResult), L"Rgs.Ufo", L"VehicleCalculationResult");
  /* AddEquipmentResponse */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentResponse), L"Rgs.Ufo", L"AddEquipmentResponse");
  /* ArrayOfDriverPrevContractDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriverPrevContractDto), L"Rgs.Ufo", L"ArrayOfDriverPrevContractDto");
  /* AdmitResultsDto */
  RemClassRegistry()->RegisterXSClass(__classid(AdmitResultsDto), L"Rgs.Ufo", L"AdmitResultsDto");
  /* DriverPrevContractDto */
  RemClassRegistry()->RegisterXSClass(__classid(DriverPrevContractDto), L"Rgs.Ufo", L"DriverPrevContractDto");
  /* PrevContractIdDto */
  RemClassRegistry()->RegisterXSClass(__classid(PrevContractIdDto), L"Rgs.Ufo", L"PrevContractIdDto");
  /* ReservationCoefficient */
  RemClassRegistry()->RegisterXSClass(__classid(ReservationCoefficient), L"Rgs.Ufo", L"ReservationCoefficient");
  /* RiskObject */
  RemClassRegistry()->RegisterXSClass(__classid(RiskObject), L"Rgs.Ufo", L"RiskObject");
  /* UnderwritingRequirement */
  RemClassRegistry()->RegisterXSClass(__classid(UnderwritingRequirement), L"Rgs.Ufo", L"UnderwritingRequirement");
  /* ArrayOfdecimal */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfdecimal), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfdecimal");
  /* KaskoUnderwritingRequirements */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoUnderwritingRequirements), L"Rgs.Ufo", L"KaskoUnderwritingRequirements");
  /* ContractorName */
  RemClassRegistry()->RegisterXSClass(__classid(ContractorName), L"Rgs.Ufo", L"ContractorName");
  /* BrandModel */
  RemClassRegistry()->RegisterXSClass(__classid(BrandModel), L"Rgs.Ufo", L"BrandModel");
  /* Address */
  RemClassRegistry()->RegisterXSClass(__classid(Address), L"Rgs.Ufo", L"Address");
  /* Proxy */
  RemClassRegistry()->RegisterXSClass(__classid(Proxy), L"Rgs.Ufo", L"Proxy");
  /* Pledgeholder */
  RemClassRegistry()->RegisterXSClass(__classid(Pledgeholder), L"Rgs.Ufo", L"Pledgeholder");
  /* KaskoPrintRequestDto */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoPrintRequestDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"KaskoPrintRequestDto");
  /* PrintCertificateRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintCertificateRequest), L"Rgs.Ufo", L"PrintCertificateRequest");
  /* PrintRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintRequest), L"Rgs.Ufo", L"PrintRequest");
  /* Signer */
  RemClassRegistry()->RegisterXSClass(__classid(Signer), L"Rgs.Ufo", L"Signer");
  /* AppInsurer */
  RemClassRegistry()->RegisterXSClass(__classid(AppInsurer), L"Rgs.Ufo", L"AppInsurer");
  /* ArrayOfPrintAppVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrintAppVehicle), L"Rgs.Ufo", L"ArrayOfPrintAppVehicle");
  /* PrintAppRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintAppRequest), L"Rgs.Ufo", L"PrintAppRequest");
  /* SignerDocument */
  RemClassRegistry()->RegisterXSClass(__classid(SignerDocument), L"Rgs.Ufo", L"SignerDocument");
  /* AntiTheftSystemRequirements */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(AntiTheftSystemRequirements_TypeInfoHolder)), L"Rgs.Ufo", L"AntiTheftSystemRequirements");
  /* Inspection */
  RemClassRegistry()->RegisterXSClass(__classid(Inspection), L"Rgs.Ufo", L"Inspection");
  /* RequirementsToAddEquipment */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(RequirementsToAddEquipment_TypeInfoHolder)), L"Rgs.Ufo", L"RequirementsToAddEquipment");
  /* PrintAppVehicle */
  RemClassRegistry()->RegisterXSClass(__classid(PrintAppVehicle), L"Rgs.Ufo", L"PrintAppVehicle");
  /* ArrayOfBLTSInsRiskDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfBLTSInsRiskDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfBLTSInsRiskDto");
  /* ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u");
  /* PrintAppRequestUl */
  RemClassRegistry()->RegisterXSClass(__classid(PrintAppRequestUl), L"Rgs.Ufo", L"PrintAppRequestUl");
  /* VehicleAddInformation */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleAddInformation), L"Rgs.Ufo", L"VehicleAddInformation");
  /* PrintContractRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintContractRequest), L"Rgs.Ufo", L"PrintContractRequest");
  /* BeneficiaryPrintRequest */
  RemClassRegistry()->RegisterXSClass(__classid(BeneficiaryPrintRequest), L"Rgs.Ufo", L"BeneficiaryPrintRequest");
  /* ContractInsurant */
  RemClassRegistry()->RegisterXSClass(__classid(ContractInsurant), L"Rgs.Ufo", L"ContractInsurant");
  /* ContractInsurer */
  RemClassRegistry()->RegisterXSClass(__classid(ContractInsurer), L"Rgs.Ufo", L"ContractInsurer");
  /* Payments */
  RemClassRegistry()->RegisterXSClass(__classid(Payments), L"Rgs.Ufo", L"Payments");
  /* Passport */
  RemClassRegistry()->RegisterXSClass(__classid(Passport), L"Rgs.Ufo", L"Passport");
  /* Payment */
  RemClassRegistry()->RegisterXSClass(__classid(Payment), L"Rgs.Ufo", L"Payment");
  /* KaskoPrintContractUlRequestDto */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoPrintContractUlRequestDto), L"Rgs.Ufo", L"KaskoPrintContractUlRequestDto");
  /* LeasingContract */
  RemClassRegistry()->RegisterXSClass(__classid(LeasingContract), L"Rgs.Ufo", L"LeasingContract");
  /* ApproveType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(ApproveType_TypeInfoHolder)), L"Rgs.Ufo", L"ApproveType");
  /* Beneficiary */
  RemClassRegistry()->RegisterXSClass(__classid(Beneficiary), L"Rgs.Ufo", L"Beneficiary");
  /* ArrayOfGroup */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfGroup), L"Rgs.Ufo", L"ArrayOfGroup");
  /* LeaseHolder */
  RemClassRegistry()->RegisterXSClass(__classid(LeaseHolder), L"Rgs.Ufo", L"LeaseHolder");
  /* ArrayOfVehicleAdditionalInfo */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleAdditionalInfo), L"Rgs.Ufo", L"ArrayOfVehicleAdditionalInfo");
  /* ArrayOfVehicleProlongation */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleProlongation), L"Rgs.Ufo", L"ArrayOfVehicleProlongation");
  /* UnderwritingAdditionalInfo */
  RemClassRegistry()->RegisterXSClass(__classid(UnderwritingAdditionalInfo), L"Rgs.Ufo", L"UnderwritingAdditionalInfo");
  /* CommonDocument */
  RemClassRegistry()->RegisterXSClass(__classid(CommonDocument), L"Rgs.Ufo", L"CommonDocument");
  /* Group */
  RemClassRegistry()->RegisterXSClass(__classid(Group), L"Rgs.Ufo", L"Group");
  /* VehicleAdditionalInfo */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleAdditionalInfo), L"Rgs.Ufo", L"VehicleAdditionalInfo");
  /* VehicleProlongation */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleProlongation), L"Rgs.Ufo", L"VehicleProlongation");
  /* ContractStatusNames */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(ContractStatusNames_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums", L"ContractStatusNames");
  /* ArrayOfVehicleStateInfo */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleStateInfo), L"Rgs.Ufo", L"ArrayOfVehicleStateInfo");
  /* QuotationStateInfo */
  RemClassRegistry()->RegisterXSClass(__classid(QuotationStateInfo), L"Rgs.Ufo", L"QuotationStateInfo");
  /* ArrayOfVehicleResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleResult), L"Rgs.Ufo", L"ArrayOfVehicleResult");
  /* Quotation */
  RemClassRegistry()->RegisterXSClass(__classid(Quotation), L"Rgs.Ufo", L"Quotation");
  /* VehicleResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleResult), L"Rgs.Ufo", L"VehicleResult");
  /* ArrayOfVehicleComment */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleComment), L"Rgs.Ufo", L"ArrayOfVehicleComment");
  /* VehicleStateInfo */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleStateInfo), L"Rgs.Ufo", L"VehicleStateInfo");
  /* GroupNames */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(GroupNames_TypeInfoHolder)), L"Rgs.Ufo", L"GroupNames");
  /* VehicleComment */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleComment), L"Rgs.Ufo", L"VehicleComment");
  /* ArrayOfCalculateVzdVehicleRequest */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfCalculateVzdVehicleRequest), L"Rgs.Ufo", L"ArrayOfCalculateVzdVehicleRequest");
  /* CalculateVzdRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdRequest), L"Rgs.Ufo", L"CalculateVzdRequest");
  /* CalculateVzdVehicleRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdVehicleRequest), L"Rgs.Ufo", L"CalculateVzdVehicleRequest");
  /* ArrayOfCalculateVzdVehicleResponse */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfCalculateVzdVehicleResponse), L"Rgs.Ufo", L"ArrayOfCalculateVzdVehicleResponse");
  /* CalculateVzdResult */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdResult), L"Rgs.Ufo", L"CalculateVzdResult");
  /* CalculateVzdVehicleResponse */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdVehicleResponse), L"Rgs.Ufo", L"CalculateVzdVehicleResponse");
  /* ArrayOfAddEquipmentInfo */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentInfo), L"Rgs.Ufo", L"ArrayOfAddEquipmentInfo");
  /* ULAddAgreementType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(ULAddAgreementType_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ULAddAgreementType");
  /* PrintULAddAgreementRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintULAddAgreementRequest), L"Rgs.Ufo", L"PrintULAddAgreementRequest");
  /* InsurerProxyDto */
  RemClassRegistry()->RegisterXSClass(__classid(InsurerProxyDto), L"Rgs.Ufo", L"InsurerProxyDto");
  /* AddEquipmentInfo */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentInfo), L"Rgs.Ufo", L"AddEquipmentInfo");
  /* ArrayOfAddEquipmentByVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentByVehicle), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfAddEquipmentByVehicle");
  /* ArrayOfBLInsPeriod */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfBLInsPeriod), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfBLInsPeriod");
  /* PrintULBLAddAgreementRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintULBLAddAgreementRequest), L"Rgs.Ufo", L"PrintULBLAddAgreementRequest");
  /* EarlyApproveInfo */
  RemClassRegistry()->RegisterXSClass(__classid(EarlyApproveInfo), L"Rgs.Ufo", L"EarlyApproveInfo");
  /* EarlyApproveResulState */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(EarlyApproveResulState_TypeInfoHolder)), L"Rgs.Ufo", L"EarlyApproveResulState");
  /* EarlyApproveResult */
  RemClassRegistry()->RegisterXSClass(__classid(EarlyApproveResult), L"Rgs.Ufo", L"EarlyApproveResult");
  /* CalculationSheet */
  RemClassRegistry()->RegisterXSClass(__classid(CalculationSheet), L"Rgs.Ufo", L"CalculationSheet");
  /* KaskoFLSpecialRequest */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoFLSpecialRequest), L"Rgs.Ufo", L"KaskoFLSpecialRequest");
  /* InsurantInfo */
  RemClassRegistry()->RegisterXSClass(__classid(InsurantInfo), L"Rgs.Ufo", L"InsurantInfo");
  /* RegistrationAgencyDto */
  RemClassRegistry()->RegisterXSClass(__classid(RegistrationAgencyDto), L"Rgs.Ufo", L"RegistrationAgencyDto");
  /* ExtendedBankInfo */
  RemClassRegistry()->RegisterXSClass(__classid(ExtendedBankInfo), L"Rgs.Ufo", L"ExtendedBankInfo");
  /* KaskoAutoProtectionRequest */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoAutoProtectionRequest), L"Rgs.Ufo", L"KaskoAutoProtectionRequest");
  /* InsurantPrintDto */
  RemClassRegistry()->RegisterXSClass(__classid(InsurantPrintDto), L"Rgs.Ufo", L"InsurantPrintDto");
  /* DocumentWithValidityDto */
  RemClassRegistry()->RegisterXSClass(__classid(DocumentWithValidityDto), L"Rgs.Ufo", L"DocumentWithValidityDto");
  /* KaskoAutoProtectionRequestUL */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoAutoProtectionRequestUL), L"Rgs.Ufo", L"KaskoAutoProtectionRequestUL");
  /* User */
  RemClassRegistry()->RegisterXSClass(__classid(User2), L"Rgs.Ufo", L"User2", L"User");
  /* CalculationRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalculationRequest2), L"Rgs.Ufo", L"CalculationRequest2", L"CalculationRequest");
  /* Insurant */
  RemClassRegistry()->RegisterXSClass(__classid(Insurant2), L"Rgs.Ufo", L"Insurant2", L"Insurant");
  /* InsurantDocument */
  RemClassRegistry()->RegisterXSClass(__classid(InsurantDocument2), L"Rgs.Ufo", L"InsurantDocument2", L"InsurantDocument");
  /* Document */
  RemClassRegistry()->RegisterXSClass(__classid(Document2), L"Rgs.Ufo", L"Document2", L"Document");
  /* PersonName */
  RemClassRegistry()->RegisterXSClass(__classid(PersonName2), L"Rgs.Ufo", L"PersonName2", L"PersonName");
  /* LegalEntity */
  RemClassRegistry()->RegisterXSClass(__classid(LegalEntity2), L"Rgs.Ufo", L"LegalEntity2", L"LegalEntity");
  /* Vehicle */
  RemClassRegistry()->RegisterXSClass(__classid(Vehicle2), L"Rgs.Ufo", L"Vehicle2", L"Vehicle");
  /* VehicleBaseDto */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleBaseDto2), L"Rgs.Ufo", L"VehicleBaseDto2", L"VehicleBaseDto");
  /* AddEquipmentRequest */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentRequest2), L"Rgs.Ufo", L"AddEquipmentRequest2", L"AddEquipmentRequest");
  /* Driver */
  RemClassRegistry()->RegisterXSClass(__classid(Driver2), L"Rgs.Ufo", L"Driver2", L"Driver");
  /* DriverLicense */
  RemClassRegistry()->RegisterXSClass(__classid(DriverLicense2), L"Rgs.Ufo", L"DriverLicense2", L"DriverLicense");
  /* Franchise */
  RemClassRegistry()->RegisterXSClass(__classid(Franchise2), L"Rgs.Ufo", L"Franchise2", L"Franchise");
  /* KaskoReCalculateRequest */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoReCalculateRequest2), L"Rgs.Ufo", L"KaskoReCalculateRequest2", L"KaskoReCalculateRequest");
  /* KaskoReCalculateVehicle */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoReCalculateVehicle2), L"Rgs.Ufo", L"KaskoReCalculateVehicle2", L"KaskoReCalculateVehicle");
  /* CalculationResult */
  RemClassRegistry()->RegisterXSClass(__classid(CalculationResult2), L"Rgs.Ufo", L"CalculationResult2", L"CalculationResult");
  /* UsagePeriod */
  RemClassRegistry()->RegisterXSClass(__classid(UsagePeriod2), L"Rgs.Ufo", L"UsagePeriod2", L"UsagePeriod");
  /* VehicleCalculationResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleCalculationResult2), L"Rgs.Ufo", L"VehicleCalculationResult2", L"VehicleCalculationResult");
  /* AddEquipmentResponse */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentResponse2), L"Rgs.Ufo", L"AddEquipmentResponse2", L"AddEquipmentResponse");
  /* AdmitResultsDto */
  RemClassRegistry()->RegisterXSClass(__classid(AdmitResultsDto2), L"Rgs.Ufo", L"AdmitResultsDto2", L"AdmitResultsDto");
  /* DriverPrevContractDto */
  RemClassRegistry()->RegisterXSClass(__classid(DriverPrevContractDto2), L"Rgs.Ufo", L"DriverPrevContractDto2", L"DriverPrevContractDto");
  /* Coefficients */
  RemClassRegistry()->RegisterXSClass(__classid(Coefficients2), L"Rgs.Ufo", L"Coefficients2", L"Coefficients");
  /* PaymentDto */
  RemClassRegistry()->RegisterXSClass(__classid(PaymentDto2), L"Rgs.Ufo", L"PaymentDto2", L"PaymentDto");
  /* PrevContractIdDto */
  RemClassRegistry()->RegisterXSClass(__classid(PrevContractIdDto2), L"Rgs.Ufo", L"PrevContractIdDto2", L"PrevContractIdDto");
  /* PrevPolicyDto */
  RemClassRegistry()->RegisterXSClass(__classid(PrevPolicyDto2), L"Rgs.Ufo", L"PrevPolicyDto2", L"PrevPolicyDto");
  /* ReservationCoefficient */
  RemClassRegistry()->RegisterXSClass(__classid(ReservationCoefficient2), L"Rgs.Ufo", L"ReservationCoefficient2", L"ReservationCoefficient");
  /* RiskObject */
  RemClassRegistry()->RegisterXSClass(__classid(RiskObject2), L"Rgs.Ufo", L"RiskObject2", L"RiskObject");
  /* KaskoUnderwritingRequirements */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoUnderwritingRequirements2), L"Rgs.Ufo", L"KaskoUnderwritingRequirements2", L"KaskoUnderwritingRequirements");
  /* UnderwritingRequirement */
  RemClassRegistry()->RegisterXSClass(__classid(UnderwritingRequirement2), L"Rgs.Ufo", L"UnderwritingRequirement2", L"UnderwritingRequirement");
  /* PrintRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintRequest2), L"Rgs.Ufo", L"PrintRequest2", L"PrintRequest");
  /* PrintCertificateRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintCertificateRequest2), L"Rgs.Ufo", L"PrintCertificateRequest2", L"PrintCertificateRequest");
  /* ContractorName */
  RemClassRegistry()->RegisterXSClass(__classid(ContractorName2), L"Rgs.Ufo", L"ContractorName2", L"ContractorName");
  /* BrandModel */
  RemClassRegistry()->RegisterXSClass(__classid(BrandModel2), L"Rgs.Ufo", L"BrandModel2", L"BrandModel");
  /* Address */
  RemClassRegistry()->RegisterXSClass(__classid(Address2), L"Rgs.Ufo", L"Address2", L"Address");
  /* Proxy */
  RemClassRegistry()->RegisterXSClass(__classid(Proxy2), L"Rgs.Ufo", L"Proxy2", L"Proxy");
  /* Pledgeholder */
  RemClassRegistry()->RegisterXSClass(__classid(Pledgeholder2), L"Rgs.Ufo", L"Pledgeholder2", L"Pledgeholder");
  /* PrintAppRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintAppRequest2), L"Rgs.Ufo", L"PrintAppRequest2", L"PrintAppRequest");
  /* Signer */
  RemClassRegistry()->RegisterXSClass(__classid(Signer2), L"Rgs.Ufo", L"Signer2", L"Signer");
  /* SignerDocument */
  RemClassRegistry()->RegisterXSClass(__classid(SignerDocument2), L"Rgs.Ufo", L"SignerDocument2", L"SignerDocument");
  /* AppInsurer */
  RemClassRegistry()->RegisterXSClass(__classid(AppInsurer2), L"Rgs.Ufo", L"AppInsurer2", L"AppInsurer");
  /* PrintAppVehicle */
  RemClassRegistry()->RegisterXSClass(__classid(PrintAppVehicle2), L"Rgs.Ufo", L"PrintAppVehicle2", L"PrintAppVehicle");
  /* Inspection */
  RemClassRegistry()->RegisterXSClass(__classid(Inspection2), L"Rgs.Ufo", L"Inspection2", L"Inspection");
  /* PrintAppRequestUl */
  RemClassRegistry()->RegisterXSClass(__classid(PrintAppRequestUl2), L"Rgs.Ufo", L"PrintAppRequestUl2", L"PrintAppRequestUl");
  /* VehicleAddInformation */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleAddInformation2), L"Rgs.Ufo", L"VehicleAddInformation2", L"VehicleAddInformation");
  /* PrintContractRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintContractRequest2), L"Rgs.Ufo", L"PrintContractRequest2", L"PrintContractRequest");
  /* BeneficiaryPrintRequest */
  RemClassRegistry()->RegisterXSClass(__classid(BeneficiaryPrintRequest2), L"Rgs.Ufo", L"BeneficiaryPrintRequest2", L"BeneficiaryPrintRequest");
  /* ContractInsurant */
  RemClassRegistry()->RegisterXSClass(__classid(ContractInsurant2), L"Rgs.Ufo", L"ContractInsurant2", L"ContractInsurant");
  /* Passport */
  RemClassRegistry()->RegisterXSClass(__classid(Passport2), L"Rgs.Ufo", L"Passport2", L"Passport");
  /* ContractInsurer */
  RemClassRegistry()->RegisterXSClass(__classid(ContractInsurer2), L"Rgs.Ufo", L"ContractInsurer2", L"ContractInsurer");
  /* Payments */
  RemClassRegistry()->RegisterXSClass(__classid(Payments2), L"Rgs.Ufo", L"Payments2", L"Payments");
  /* Payment */
  RemClassRegistry()->RegisterXSClass(__classid(Payment2), L"Rgs.Ufo", L"Payment2", L"Payment");
  /* KaskoPrintContractUlRequestDto */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoPrintContractUlRequestDto2), L"Rgs.Ufo", L"KaskoPrintContractUlRequestDto2", L"KaskoPrintContractUlRequestDto");
  /* LeasingContract */
  RemClassRegistry()->RegisterXSClass(__classid(LeasingContract2), L"Rgs.Ufo", L"LeasingContract2", L"LeasingContract");
  /* UnderwritingAdditionalInfo */
  RemClassRegistry()->RegisterXSClass(__classid(UnderwritingAdditionalInfo2), L"Rgs.Ufo", L"UnderwritingAdditionalInfo2", L"UnderwritingAdditionalInfo");
  /* Beneficiary */
  RemClassRegistry()->RegisterXSClass(__classid(Beneficiary2), L"Rgs.Ufo", L"Beneficiary2", L"Beneficiary");
  /* CommonDocument */
  RemClassRegistry()->RegisterXSClass(__classid(CommonDocument2), L"Rgs.Ufo", L"CommonDocument2", L"CommonDocument");
  /* Group */
  RemClassRegistry()->RegisterXSClass(__classid(Group2), L"Rgs.Ufo", L"Group2", L"Group");
  /* LeaseHolder */
  RemClassRegistry()->RegisterXSClass(__classid(LeaseHolder2), L"Rgs.Ufo", L"LeaseHolder2", L"LeaseHolder");
  /* VehicleAdditionalInfo */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleAdditionalInfo2), L"Rgs.Ufo", L"VehicleAdditionalInfo2", L"VehicleAdditionalInfo");
  /* VehicleProlongation */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleProlongation2), L"Rgs.Ufo", L"VehicleProlongation2", L"VehicleProlongation");
  /* QuotationStateInfo */
  RemClassRegistry()->RegisterXSClass(__classid(QuotationStateInfo2), L"Rgs.Ufo", L"QuotationStateInfo2", L"QuotationStateInfo");
  /* Quotation */
  RemClassRegistry()->RegisterXSClass(__classid(Quotation2), L"Rgs.Ufo", L"Quotation2", L"Quotation");
  /* VehicleResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleResult2), L"Rgs.Ufo", L"VehicleResult2", L"VehicleResult");
  /* VehicleStateInfo */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleStateInfo2), L"Rgs.Ufo", L"VehicleStateInfo2", L"VehicleStateInfo");
  /* VehicleComment */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleComment2), L"Rgs.Ufo", L"VehicleComment2", L"VehicleComment");
  /* CalculateVzdRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdRequest2), L"Rgs.Ufo", L"CalculateVzdRequest2", L"CalculateVzdRequest");
  /* CalculateVzdVehicleRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdVehicleRequest2), L"Rgs.Ufo", L"CalculateVzdVehicleRequest2", L"CalculateVzdVehicleRequest");
  /* CalculateVzdResult */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdResult2), L"Rgs.Ufo", L"CalculateVzdResult2", L"CalculateVzdResult");
  /* CalculateVzdVehicleResponse */
  RemClassRegistry()->RegisterXSClass(__classid(CalculateVzdVehicleResponse2), L"Rgs.Ufo", L"CalculateVzdVehicleResponse2", L"CalculateVzdVehicleResponse");
  /* PrintULAddAgreementRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintULAddAgreementRequest2), L"Rgs.Ufo", L"PrintULAddAgreementRequest2", L"PrintULAddAgreementRequest");
  /* AddEquipmentInfo */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentInfo2), L"Rgs.Ufo", L"AddEquipmentInfo2", L"AddEquipmentInfo");
  /* InsurerProxyDto */
  RemClassRegistry()->RegisterXSClass(__classid(InsurerProxyDto2), L"Rgs.Ufo", L"InsurerProxyDto2", L"InsurerProxyDto");
  /* PrintULBLAddAgreementRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintULBLAddAgreementRequest2), L"Rgs.Ufo", L"PrintULBLAddAgreementRequest2", L"PrintULBLAddAgreementRequest");
  /* EarlyApproveInfo */
  RemClassRegistry()->RegisterXSClass(__classid(EarlyApproveInfo2), L"Rgs.Ufo", L"EarlyApproveInfo2", L"EarlyApproveInfo");
  /* EarlyApproveResult */
  RemClassRegistry()->RegisterXSClass(__classid(EarlyApproveResult2), L"Rgs.Ufo", L"EarlyApproveResult2", L"EarlyApproveResult");
  /* CalculationSheet */
  RemClassRegistry()->RegisterXSClass(__classid(CalculationSheet2), L"Rgs.Ufo", L"CalculationSheet2", L"CalculationSheet");
  /* KaskoFLSpecialRequest */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoFLSpecialRequest2), L"Rgs.Ufo", L"KaskoFLSpecialRequest2", L"KaskoFLSpecialRequest");
  /* InsurantInfo */
  RemClassRegistry()->RegisterXSClass(__classid(InsurantInfo2), L"Rgs.Ufo", L"InsurantInfo2", L"InsurantInfo");
  /* RegistrationAgencyDto */
  RemClassRegistry()->RegisterXSClass(__classid(RegistrationAgencyDto2), L"Rgs.Ufo", L"RegistrationAgencyDto2", L"RegistrationAgencyDto");
  /* ExtendedBankInfo */
  RemClassRegistry()->RegisterXSClass(__classid(ExtendedBankInfo2), L"Rgs.Ufo", L"ExtendedBankInfo2", L"ExtendedBankInfo");
  /* KaskoAutoProtectionRequest */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoAutoProtectionRequest2), L"Rgs.Ufo", L"KaskoAutoProtectionRequest2", L"KaskoAutoProtectionRequest");
  /* InsurantPrintDto */
  RemClassRegistry()->RegisterXSClass(__classid(InsurantPrintDto2), L"Rgs.Ufo", L"InsurantPrintDto2", L"InsurantPrintDto");
  /* DocumentWithValidityDto */
  RemClassRegistry()->RegisterXSClass(__classid(DocumentWithValidityDto2), L"Rgs.Ufo", L"DocumentWithValidityDto2", L"DocumentWithValidityDto");
  /* KaskoAutoProtectionRequestUL */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoAutoProtectionRequestUL2), L"Rgs.Ufo", L"KaskoAutoProtectionRequestUL2", L"KaskoAutoProtectionRequestUL");
  /* DateTimeOffset */
  RemClassRegistry()->RegisterXSClass(__classid(DateTimeOffset), L"http://schemas.datacontract.org/2004/07/System", L"DateTimeOffset");
  /* ArrayOfdecimal */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfdecimal), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfdecimal");
  /* ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* ArrayOfKeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringstring");
  /* OperationResultOfSelfTestResultBmLUPtsk */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfSelfTestResultBmLUPtsk), L"RGS.UFO", L"OperationResultOfSelfTestResultBmLUPtsk");
  /* OperationResultOfEarlyApproveResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfEarlyApproveResultoTurZuT3), L"RGS.UFO", L"OperationResultOfEarlyApproveResultoTurZuT3");
  /* OperationResultOfCalculateVzdResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfCalculateVzdResultoTurZuT3), L"RGS.UFO", L"OperationResultOfCalculateVzdResultoTurZuT3");
  /* OperationResultOfQuotationStateInfooTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfQuotationStateInfooTurZuT3), L"RGS.UFO", L"OperationResultOfQuotationStateInfooTurZuT3");
  /* OperationResultOfContractStatusNamesmxVaabBO */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfContractStatusNamesmxVaabBO), L"RGS.UFO", L"OperationResultOfContractStatusNamesmxVaabBO");
  /* OperationResultOfPrintResult1QqCV82X */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfPrintResult1QqCV82X), L"RGS.UFO", L"OperationResultOfPrintResult1QqCV82X");
  /* OperationResultOfCalculationResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfCalculationResultoTurZuT3), L"RGS.UFO", L"OperationResultOfCalculationResultoTurZuT3");
  /* PrintResult */
  RemClassRegistry()->RegisterXSClass(__classid(PrintResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models", L"PrintResult");
  /* ArrayOfPrintResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrintResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models", L"ArrayOfPrintResult");
  /* OperationResultOfArrayOfPrintResult1QqCV82X */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfPrintResult1QqCV82X), L"RGS.UFO", L"OperationResultOfArrayOfPrintResult1QqCV82X");
  /* OperationResultOfCalculationResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfCalculationResultoTurZuT32), L"RGS.UFO", L"OperationResultOfCalculationResultoTurZuT32", L"OperationResultOfCalculationResultoTurZuT3");
  /* OperationResultOfPrintResult1QqCV82X */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfPrintResult1QqCV82X2), L"RGS.UFO", L"OperationResultOfPrintResult1QqCV82X2", L"OperationResultOfPrintResult1QqCV82X");
  /* OperationResultOfContractStatusNamesmxVaabBO */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfContractStatusNamesmxVaabBO2), L"RGS.UFO", L"OperationResultOfContractStatusNamesmxVaabBO2", L"OperationResultOfContractStatusNamesmxVaabBO");
  /* OperationResultOfQuotationStateInfooTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfQuotationStateInfooTurZuT32), L"RGS.UFO", L"OperationResultOfQuotationStateInfooTurZuT32", L"OperationResultOfQuotationStateInfooTurZuT3");
  /* OperationResultOfCalculateVzdResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfCalculateVzdResultoTurZuT32), L"RGS.UFO", L"OperationResultOfCalculateVzdResultoTurZuT32", L"OperationResultOfCalculateVzdResultoTurZuT3");
  /* OperationResultOfArrayOfPrintResult1QqCV82X */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfPrintResult1QqCV82X2), L"RGS.UFO", L"OperationResultOfArrayOfPrintResult1QqCV82X2", L"OperationResultOfArrayOfPrintResult1QqCV82X");
  /* OperationResultOfEarlyApproveResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfEarlyApproveResultoTurZuT32), L"RGS.UFO", L"OperationResultOfEarlyApproveResultoTurZuT32", L"OperationResultOfEarlyApproveResultoTurZuT3");
  /* OperationResultOfSelfTestResultBmLUPtsk */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfSelfTestResultBmLUPtsk2), L"RGS.UFO", L"OperationResultOfSelfTestResultBmLUPtsk2", L"OperationResultOfSelfTestResultBmLUPtsk");
  /* KeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* KeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringstring");
  /* KeyValuePairOfstringVehicleAddInformationo_S6zkk9u */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringVehicleAddInformationo_S6zkk9u), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringVehicleAddInformationo_S6zkk9u");
  /* KeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringArrayOfstringty7Ep6D12), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringArrayOfstringty7Ep6D12", L"KeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* KeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringstring2), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringstring2", L"KeyValuePairOfstringstring");
  /* KeyValuePairOfstringVehicleAddInformationo_S6zkk9u */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringVehicleAddInformationo_S6zkk9u2), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringVehicleAddInformationo_S6zkk9u2", L"KeyValuePairOfstringVehicleAddInformationo_S6zkk9u");
  /* BLTSInsRiskDto */
  RemClassRegistry()->RegisterXSClass(__classid(BLTSInsRiskDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLTSInsRiskDto");
  /* ArrayOfBLPaymentDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfBLPaymentDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfBLPaymentDto");
  /* BLPeriodDto */
  RemClassRegistry()->RegisterXSClass(__classid(BLPeriodDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLPeriodDto");
  /* BLPaymentDto */
  RemClassRegistry()->RegisterXSClass(__classid(BLPaymentDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLPaymentDto");
  /* AddEquipmentByVehicle */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentByVehicle), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"AddEquipmentByVehicle");
  /* BLInsPeriod */
  RemClassRegistry()->RegisterXSClass(__classid(BLInsPeriod), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLInsPeriod");
  /* KaskoPrintRequestDto */
  RemClassRegistry()->RegisterXSClass(__classid(KaskoPrintRequestDto2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"KaskoPrintRequestDto2", L"KaskoPrintRequestDto");
  /* BLTSInsRiskDto */
  RemClassRegistry()->RegisterXSClass(__classid(BLTSInsRiskDto2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLTSInsRiskDto2", L"BLTSInsRiskDto");
  /* BLPeriodDto */
  RemClassRegistry()->RegisterXSClass(__classid(BLPeriodDto2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLPeriodDto2", L"BLPeriodDto");
  /* BLPaymentDto */
  RemClassRegistry()->RegisterXSClass(__classid(BLPaymentDto2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLPaymentDto2", L"BLPaymentDto");
  /* ArrayOfAddEquipmentByVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentByVehicle), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfAddEquipmentByVehicle");
  /* AddEquipmentByVehicle */
  RemClassRegistry()->RegisterXSClass(__classid(AddEquipmentByVehicle2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"AddEquipmentByVehicle2", L"AddEquipmentByVehicle");
  /* BLInsPeriod */
  RemClassRegistry()->RegisterXSClass(__classid(BLInsPeriod2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"BLInsPeriod2", L"BLInsPeriod");
  /* PrintResult */
  RemClassRegistry()->RegisterXSClass(__classid(PrintResult2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models", L"PrintResult2", L"PrintResult");
  /* ContractStatusNames */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(ContractStatusNames_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums", L"ContractStatusNames");
  /* ProcessStateFault */
  RemClassRegistry()->RegisterXSClass(__classid(ProcessStateFault), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Underwriting.Faults", L"ProcessStateFault");
  /* ProcessStateFault */
  RemClassRegistry()->RegisterXSClass(__classid(ProcessStateFault2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Underwriting.Faults", L"ProcessStateFault2", L"ProcessStateFault");
  /* DateTimeOffset */
  RemClassRegistry()->RegisterXSClass(__classid(DateTimeOffset2), L"http://schemas.datacontract.org/2004/07/System", L"DateTimeOffset2", L"DateTimeOffset");
  /* ArrayOfSelfTestResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfSelfTestResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces", L"ArrayOfSelfTestResult");
  /* SelfTestResult */
  RemClassRegistry()->RegisterXSClass(__classid(SelfTestResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces", L"SelfTestResult");
  /* SelfTestResult */
  RemClassRegistry()->RegisterXSClass(__classid(SelfTestResult2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces", L"SelfTestResult2", L"SelfTestResult");
  /* ArrayOfAddEquipmentRequest */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentRequest), L"Rgs.Ufo", L"ArrayOfAddEquipmentRequest");
  /* ArrayOfKaskoReCalculateVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKaskoReCalculateVehicle), L"Rgs.Ufo", L"ArrayOfKaskoReCalculateVehicle");
  /* ArrayOfUsagePeriod */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfUsagePeriod), L"Rgs.Ufo", L"ArrayOfUsagePeriod");
  /* ArrayOfAddEquipmentResponse */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentResponse), L"Rgs.Ufo", L"ArrayOfAddEquipmentResponse");
  /* ArrayOfDriverPrevContractDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriverPrevContractDto), L"Rgs.Ufo", L"ArrayOfDriverPrevContractDto");
  /* ArrayOfReservationCoefficient */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfReservationCoefficient), L"Rgs.Ufo", L"ArrayOfReservationCoefficient");
  /* AntiTheftSystemRequirements */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(AntiTheftSystemRequirements_TypeInfoHolder)), L"Rgs.Ufo", L"AntiTheftSystemRequirements");
  /* ApproveType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(ApproveType_TypeInfoHolder)), L"Rgs.Ufo", L"ApproveType");
  /* ArrayOfVehicleAdditionalInfo */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleAdditionalInfo), L"Rgs.Ufo", L"ArrayOfVehicleAdditionalInfo");
  /* ArrayOfVehicleResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleResult), L"Rgs.Ufo", L"ArrayOfVehicleResult");
  /* ArrayOfVehicleComment */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleComment), L"Rgs.Ufo", L"ArrayOfVehicleComment");
  /* ArrayOfCalculateVzdVehicleRequest */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfCalculateVzdVehicleRequest), L"Rgs.Ufo", L"ArrayOfCalculateVzdVehicleRequest");
  /* ArrayOfCalculateVzdVehicleResponse */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfCalculateVzdVehicleResponse), L"Rgs.Ufo", L"ArrayOfCalculateVzdVehicleResponse");
  /* ArrayOfAddEquipmentInfo */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAddEquipmentInfo), L"Rgs.Ufo", L"ArrayOfAddEquipmentInfo");
  /* ArrayOfstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfstring), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfstring");
  /* ArrayOfKeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringstring");
  /* ArrayOfBLTSInsRiskDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfBLTSInsRiskDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfBLTSInsRiskDto");
  /* ULAddAgreementType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(ULAddAgreementType_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ULAddAgreementType");
  /* ArrayOfPrintResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrintResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models", L"ArrayOfPrintResult");
  /* ArrayOfVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicle), L"Rgs.Ufo", L"ArrayOfVehicle");
  /* ArrayOfAdmitResultsDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAdmitResultsDto), L"Rgs.Ufo", L"ArrayOfAdmitResultsDto");
  /* ArrayOfRiskObject */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfRiskObject), L"Rgs.Ufo", L"ArrayOfRiskObject");
  /* ArrayOfPrintAppVehicle */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrintAppVehicle), L"Rgs.Ufo", L"ArrayOfPrintAppVehicle");
  /* ArrayOfGroup */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfGroup), L"Rgs.Ufo", L"ArrayOfGroup");
  /* ArrayOfVehicleStateInfo */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleStateInfo), L"Rgs.Ufo", L"ArrayOfVehicleStateInfo");
  /* EarlyApproveResulState */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(EarlyApproveResulState_TypeInfoHolder)), L"Rgs.Ufo", L"EarlyApproveResulState");
  /* ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* ArrayOfBLPaymentDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfBLPaymentDto), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfBLPaymentDto");
  /* ArrayOfSelfTestResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfSelfTestResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Interfaces", L"ArrayOfSelfTestResult");
  /* ArrayOfVehicleCalculationResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleCalculationResult), L"Rgs.Ufo", L"ArrayOfVehicleCalculationResult");
  /* ArrayOfBLInsPeriod */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfBLInsPeriod), L"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print", L"ArrayOfBLInsPeriod");
  /* ArrayOfPrevContractIdDto */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrevContractIdDto), L"Rgs.Ufo", L"ArrayOfPrevContractIdDto");
  /* ArrayOfVehicleProlongation */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleProlongation), L"Rgs.Ufo", L"ArrayOfVehicleProlongation");
  /* ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringVehicleAddInformationo_S6zkk9u");
  /* RequirementsToAddEquipment */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(RequirementsToAddEquipment_TypeInfoHolder)), L"Rgs.Ufo", L"RequirementsToAddEquipment");
  /* ArrayOfDriver */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriver), L"Rgs.Ufo", L"ArrayOfDriver");
  /* GroupNames */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(GroupNames_TypeInfoHolder)), L"Rgs.Ufo", L"GroupNames");
}
#pragma startup RegTypes 32

};     // NS_KaskoProxyService

