//---------------------------------------------------------------------------

#ifndef XML_Progress_Form_cH
#define XML_Progress_Form_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sGauge.hpp"
#include "sLabel.hpp"
//---------------------------------------------------------------------------
class TXML_Progress_Form : public TForm
{
__published:	// IDE-managed Components
   TsGauge *sGauge1;
   TsLabel *sLabel1;
private:	// User declarations
public:		// User declarations
   __fastcall TXML_Progress_Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TXML_Progress_Form *XML_Progress_Form;
//---------------------------------------------------------------------------
#endif
