//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UTypeDogovor.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma resource "*.dfm"
TfrmTypeDogovor *frmTypeDogovor;
//---------------------------------------------------------------------------
__fastcall TfrmTypeDogovor::TfrmTypeDogovor(TComponent* Owner, mops_api_024 *_m_api)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------



