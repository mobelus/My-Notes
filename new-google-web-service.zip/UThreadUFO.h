//---------------------------------------------------------------------------

#ifndef UThreadUFOH
#define UThreadUFOH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//#include "IbProxyService.h"
#include "InspectionProxyService.h"
#include "KaskoProxyService.h"

#include "functions.h"

#define METHODS_FROM_KASKO_2UFO 0

//---------------------------------------------------------------------------
class ThreadUFO : public TThread{
private:
   __int64 err_code;
   int res, curr_year;
   AnsiString soap_server_address;
   TypeUfoFunction type_function;

   mops_api_028 *m_api;
   Dogovor_Info *di;
   VehicleInfo *vi;
   PersonInfo *pi, *pm;
   TADOQuery *q_main, *q_persons, *q_reservations, *q_vehicles, *q_payments, *q_insurer, *q_policy, *q_calc, *q_inspection_docs;
   TMemoryStream *pdf_file;
   RussoFieldName russo;
private:
   void FillCalculationRequest(CalculationRequest *CalcReq);
   void SelectionFromResultOfCalculation(OperationResultOfCalculationResultoTurZuT3 *ResultOfCalculation);

/*
#ifdef METHODS_FROM_KASKO_2UFO
   void FillPrintPolicyRequest(KaskoAutoProtectionRequest *PrintPolicyRequest);
   void FillPrintPolicySpecialRequest(KaskoFLSpecialRequest *PrintPolicySpecialRequest);
   void FillPrintCalculationSheet(CalculationSheet *PrintCalculationSheet);

   void GetPDF(OperationResultOfPrintResult1QqCV82X *resultOfPrint);
   void GetPDF(OperationResultOfArrayOfPrintResult1QqCV82X *ArrayResultOfPrint);

   void FillUnderwritingAdditionalInfo(UnderwritingAdditionalInfo *underInfo);

   void SelectionFromResultOfSendApprove(OperationResultOfContractStatusNamesmxVaabBO *resultOfSendApprove);
   void SelectionFromResultOfApprove(OperationResultOfQuotationStateInfooTurZuT3 *resultOfApprove);
   void SelectionStatus(OperationResultOfQuotationStateInfooTurZuT3 *resultOfApprove);

   void IsFieldVehicleChanged(const AnsiString& fieldname, const Variant& v, TStringList *what_change);
   void IsFieldCalcChanged(const AnsiString& fieldname, const Variant& v, TStringList *what_change);
   void IsFieldPolicyChanged(const AnsiString& fieldname, const Variant& v, TStringList *what_change);

   void SelectionFromResultOfguid(OperationResultOfguid *ResultOfguid);

   void FillInspectionDocumentInput(InspectionDocumentInput *document);
   void SelectFromOperationResultOfguid(OperationResultOfguid *ResultOfguid);

   void SelectionFromResultOfInspection(OperationResultOfArrayOfInspectionoTurZuT3 *resultOfInspection);

   void SelectionFromResultOfInspectionDocument(OperationResultOfInspectionDocumentoTurZuT3 *ResultOfInspectionDocument);

#endif //*/

   AnsiString KladrValueToStr(const AnsiString& kladrvalue){ if(kladrvalue.UpperCase() == no) return empty_str; return kladrvalue; }

   int GetOffsetMin();
protected:
   void __fastcall Execute();
public:
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, PersonInfo *p_pi, PersonInfo *p_pm);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi, TADOQuery *q_r, TADOQuery *q_v);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi);
   //__fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_m, TADOQuery *q_r, TADOQuery *q_v);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_pl, TADOQuery *q_p, TADOQuery *q_v, TADOQuery *q_ins, TMemoryStream *fs);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_c, TADOQuery *q_p, TADOQuery *q_v);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_pl, TADOQuery *q_p, TADOQuery *q_v, TADOQuery *q_ins);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, TADOQuery *q_insp);
   __fastcall ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, TADOQuery *q_insp, TMemoryStream *fs);

};
//---------------------------------------------------------------------------
#endif
