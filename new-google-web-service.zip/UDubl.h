//---------------------------------------------------------------------------

#ifndef UDublH
#define UDublH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
//---------------------------------------------------------------------------
class TfrmDubl : public TForm{
__published:	// IDE-managed Components
   TdxInspector *DublInfo;
   TdxInspectorTextRow *editPolisSeria;
   TdxInspectorTextRow *editPolisNumber;
   TdxInspectorTextMemoRow *editReason;
   TButton *btnOK;
   TButton *btnCancel;
   void __fastcall btnOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TfrmDubl(TComponent* Owner);
   bool IsAllData();
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmDubl *frmDubl;
//---------------------------------------------------------------------------
#endif
