#include "functions.h"
#include "FastStrReplaceUnit.hpp"
//---------------------------------------------------------------------------
AnsiString S(const double& x)
{
   AnsiString t, result;
   result = t.sprintf("%.4f", x);
   int len = result.Length();

   if(result[len] == '0'){
      if(result[len - 1] == '0') result = result.Delete(len - 1, 2);
      else                       result = result.Delete(len, 1);
   }

   return result;
}
//---------------------------------------------------------------------------
AnsiString FormatDigits(const double& x)
{
   AnsiString result = FormatFloat(",0.00;-,0.00", x);
   int len = result.Length();
   if(result[len - 1] == '0' && result[len] == '0') result = result.SubString(1, len - 3);

   return result;
}
//---------------------------------------------------------------------------
AnsiString FloatToSQLStr(const double& f)
{
   return StringReplace(FloatToStr(f), ",", ".", rf);
}
//---------------------------------------------------------------------------
AnsiString FloatToSQLStr(AnsiString s)
{
   if(s.IsEmpty()) return null_str;
   s = StringReplace(s, space_str, empty_str, rf);
   return StringReplace(s, ",", ".", rf);
}
//---------------------------------------------------------------------------
void FloatToRubAndKopeik(const double& x, AnsiString& rub, AnsiString& kopeik)
{
	AnsiString result = StringReplace(FormatFloat(",0.00;-,0.00", x), ",", ".", rf);
	int pos_t = result.Pos(".");
	rub = result.SubString(1, pos_t - 1);
	kopeik = result.SubString(pos_t + 1, 2);
}
//---------------------------------------------------------------------------
AnsiString StrToFloatStr(const AnsiString& s, const AnsiString& def)
{
   if(s.IsEmpty()) return def;
   
   AnsiString result = s;
   char c = DecimalSeparator;

   result = StringReplace(result, space_str, empty_str, rf);
   result = StringReplace(result, space_str_nonbreak, empty_str, rf);
   result = StringReplace(result, space_str_long, empty_str, rf);
   result = StringReplace(result, "�.", empty_str, rf);
   result = StringReplace(result, "�,", empty_str, rf);

   if(result.AnsiPos(".")){
      if(c != '.'){
         result = StringReplace(result, ".", ",", rf);
      }
   }
   else if(result.AnsiPos(",")){
      if(c != ','){
         result = StringReplace(result, ",", ".", rf);
      }
   }

   double d;
   if(!TryStrToFloat(result, d)) return def;

   return result;
}
//---------------------------------------------------------------------------
AnsiString FloatToIntStr(const double& f)
{
   AnsiString s = FloatToSQLStr(f);
   int pos = s.Pos(".");
   if(pos > 0) return s.Delete(pos, s.Length() - pos + 1);
   else return s;
}
//---------------------------------------------------------------------------
int CalcYears(const TDateTime& dt1, const TDateTime& dt2)
{
   if(!dt1.Val || !dt2.Val) return 0;                        

   int y1 = YearOf(dt1),  y2 = YearOf(dt2);
   int m1 = MonthOf(dt1), m2 = MonthOf(dt2);
   int d1 = DayOf(dt1),   d2 = DayOf(dt2);
   int ydif = y2 - y1;
   if(m2 < m1 || (m1 == m2 && d2 < d1)) ydif--;

   return ydif;
}
//---------------------------------------------------------------------------
void ResetChk(TCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void ResetCxChk(TcxCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void ResetSChk(TsCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void SetValueCheckBox(TsCheckBox* chk, const int v, ptr_onclick onclick)
{
	chk->OnClick = 0;
	chk->Checked = v ? true : false;
	chk->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueCheckBox(TCheckBox* chk, const int v, ptr_onclick onclick)
{
   chk->OnClick = 0;
   chk->Checked = v ? true : false;
   chk->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueCxCheckBox(TcxCheckBox* chk, const int v, ptr_onclick onclick)
{
   chk->OnClick = 0;
   chk->Checked = v ? true : false;
   chk->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueEdit(TEdit *edit, const AnsiString& val, ptr_onchange onchange)
{
   edit->OnChange = 0;
   edit->Text = val;
   edit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueCalcEdit(TsCalcEdit* cedit, const double& val, ptr_onchange onchange)
{
   cedit->OnChange = 0;
   cedit->Value = val;
   cedit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void ClearTcxComboBox(TcxComboBox *cbox, ptr_onchange onchange)
{
   cbox->Properties->OnChange = 0;
   cbox->Properties->Items->Clear();
   cbox->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetIndexTcxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange, const int type, const Variant& default_value)
{
   cbox->Properties->OnChange = 0;
   if(!value.IsNull()){
      cbox->ItemIndex = type ? cbox->Properties->Items->IndexOfObject((TObject*)value.intVal) : cbox->Properties->Items->IndexOf(value);
      if(cbox->ItemIndex == -1 && !default_value.IsNull()){
         cbox->ItemIndex = type ? cbox->Properties->Items->IndexOfObject((TObject*)default_value.intVal) : cbox->Properties->Items->IndexOf(default_value);
         if(cbox->ItemIndex > -1) value = default_value;
         else{
            if(cbox->Properties->Items->Count == 1){
               cbox->ItemIndex = 0;
               if(type) value.intVal = (int)cbox->Properties->Items->Objects[0];
               else value = cbox->Text;
            }
         }
      }
   }
   else cbox->ItemIndex = -1;
   cbox->Properties->OnChange = onchange;

   cbox->Enabled = !(cbox->Properties->Items->Count == 1 && cbox->ItemIndex == 0);
}
//---------------------------------------------------------------------------
void SetTextTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange)
{
   cbox->Properties->OnChange = 0;
   cbox->Text = value;
   cbox->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValuecxCurrencyEdit(TcxCurrencyEdit *cedit, const Variant& value, ptr_onchange onchange)
{
   cedit->Properties->OnChange = 0;
   cedit->Value =  (!value.IsNull() && !value.IsEmpty()) ? value : 0;
   cedit->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange)
{
   dedit->OnChange = 0;
   if(dt.Val) dedit->Date = dt;
   else dedit->Text = "  .  .    ";
   dedit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TcxEditorRow *dedit, const TDateTime& val)
{
   if(val.Val) dedit->Properties->Value = val;
   else dedit->Properties->Value = variant_null;
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TdxInspectorTextDateRow *dedit, const TDateTime& val)
{
	if (val.Val) dedit->EditText = val.DateString();
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TcxDateEdit *dedit, const TDateTime& val)
{
   if(val.Val) dedit->EditValue = val;
   else dedit->EditValue = variant_null;
}
//---------------------------------------------------------------------------
int GetIndexObject(TStrings* lst, const int& val)
{
   for(int i = 0, cnt = lst->Count; i < cnt; ++i)
      if(((DataDict*)lst->Objects[i])->id == val) return i;

   return -1;
}
//---------------------------------------------------------------------------
int GetIndexItemByTag(TcxRadioGroupItems* items, const int t)
{
   for(int i = 0, cnt = items->Count; i < cnt; ++i)
      if(items->Items[i]->Tag == t) return i;

   return -1;
}
//---------------------------------------------------------------------------
TDateTime CalcEndDateInsur(const TDateTime& start_date, const int srok_month)
{
   Word Year, Month, Day;
   DecodeDate(start_date, Year, Month, Day);
   IncAMonth(Year, Month, Day, srok_month);
   TDateTime dt = EncodeDate(Year, Month, Day);

   return IncDay(dt, -1);
}
//---------------------------------------------------------------------------
AnsiString FirstUpper(const AnsiString& str, const int is_end_to_lower)
{
   if(str.IsEmpty()) return empty_str;

   AnsiString f_up = AnsiString(str[1]).UpperCase();
   return f_up + (is_end_to_lower ? str.SubString(2, str.Length() - 1).LowerCase() : str.SubString(2, str.Length() - 1));
}
//---------------------------------------------------------------------------
AnsiString AddNulls(const AnsiString& str, const int count)
{
   AnsiString result = str;
   int len = str.Length();

   if(len < count) for(int i = 0, end = count - len; i < end; ++i) result = null_str + result;

   return result;
}
//---------------------------------------------------------------------------
AnsiString AddNulls(const AnsiString& str)
{
   AnsiString result = str;
   int len = str.Length();

   if(len < 9) for(int i = 0, end = 9 - len; i < end; ++i) result = null_str + result;

   return result;
}
//---------------------------------------------------------------------------
AnsiString ClearPhoneNumber(const AnsiString& str)
{
   AnsiString result(""), curr("");
   int i_val;

   for(int i = 1, l = str.Length(); i <= l; ++i){
      curr = AnsiString(str[i]);
      if(TryStrToInt(curr, i_val)) result += curr;
   }

   return result;
}
//---------------------------------------------------------------------------
void FilterDataSet(TADOQuery *qq, const AnsiString& filter)
{
   qq->Filtered = false;
   qq->Filter   = filter;
   qq->Filtered = true;
}
//---------------------------------------------------------------------------
void FilterDataSet(TClientDataSet *qq, const AnsiString& filter)
{
   qq->Filtered = false;
   qq->Filter   = filter;
   qq->Filtered = true;
}


//---------------------------------------------------------------------------
bool CheckAreNumbersAndLetters(const AnsiString& str) // check if the symbols in a Strring are ALL numberes
{
   if(str.IsEmpty())
     return false;

   //if( !(str[1] >= '0' && str[1] <= '9') ) return false;
   for(int i = str.Length(); i > 0; i--)
   {
     if( !( (str[i] >= '0' && str[i] <= '9') || (str[i] >= 'A' && str[i] <= 'Z') /*|| (str[i] >= 'a' && str[i] <= 'z')*/ )  )
     return false;
   }
   return true;
}
//---------------------------------------------------------------------------
bool CheckAreAllNumbers(const AnsiString& str) // check if the symbols in a Strring are ALL numberes
{
   if(str.IsEmpty())
     return false;

   //if( !(str[1] >= '0' && str[1] <= '9') ) return false;
   for(int i = str.Length(); i > 0; i--)
   {
     if( !(str[i] >= '0' && str[i] <= '9')  )
     return false;
   }
   return true;
}
//---------------------------------------------------------------------------
bool IsDigitOnly(AnsiString Str)
{
	bool res = true;
	for (int i = 1; i <= Str.Length(); ++i)
	{
		res = Str[i] >= '0' && Str[i] <= '9';
		if (!res)
			break;
	}
	return res;
}
//---------------------------------------------------------------------------
bool IsLetterOnly(AnsiString Str)
{
	bool res = true;
	for (int i = 1; i <= Str.Length(); ++i)
	{
		res = (Str[i] >= 'a' && Str[i] <= 'z') || (Str[i] >= '?' && Str[i] <= '?') || (Str[i] >= '0' && Str[i] <= '9');
		if (!res)
			break;
	}
	return res;
}
//---------------------------------------------------------------------------
AnsiString NormalizeNumberStr(AnsiString StrToNormalize)
{
    const int numSymbols = 17;
	AnsiString replace_Arr[numSymbols][2] =
	{
		{ "O", "0" }, //0
		{ "o", "0" }, //1
		{ "?", "0" }, //2
		{ "o", "0" }, //3
		{ "L", "1" }, //4
		{ "l", "1" }, //5
		{ "I", "1" }, //6
		{ "i", "1" }, //7
		{ "?", "3" }, //8
		{ "?", "3" }, //9
		{ "(", "" },  //0
		{ ")", "" },  //1
		{ ".", "" },  //2
		{ "-", "" },  //3
		{ "#", "" },  //4
		{ "?", "" },  //5
		{ " ", "" }   //6
	};

	for (int i = 0; i < numSymbols; ++i)
    {
	  StrToNormalize = StringReplace(StrToNormalize, replace_Arr[i][0], replace_Arr[i][1], TReplaceFlags() << rfReplaceAll); //TReplaceFlags()<< rfReplaceAll << rfIgnoreCase);
    }

	return StrToNormalize;
}

//---------------------------------------------------------------------------
bool IsCharANumber(char Char)
{ return (Char >= '0' && Char <= '9') ? true : false; }
//---------------------------------------------------------------------------
AnsiString DeleteLastSymbol(AnsiString str)
{
  if(str.Length()>0) str.Delete(str.Length(), 1);
  return str;
}
//---------------------------------------------------------------------------
AnsiString NormalizeSummNumberStr(AnsiString StrToNormalize)
{
    if(StrToNormalize.Length())
    {
	  for (int i = 1, j = 0, k = 0; i < (StrToNormalize.Length()+1); ++i)
      {
        // it means we found in a string with one of thwe folowing formats:
        // "23000���" / "23 000�" / "23000�." / "23000���" / "23 000�" and so on
          j = !IsCharANumber(StrToNormalize[i]) ? ++j : 0;
          if(j==1) {k = i;}
          if(i != StrToNormalize.Length())
          {
            if( (j > 0) && IsCharANumber(StrToNormalize[i+1]) )
            {
              StrToNormalize.Delete(k,j);
              i = i - j;
            }
          }
          else
          { // remove last part
            if(j > 0) { StrToNormalize.Delete(k,j); }
            break;
          }
      }

      // remove last nonNumber symbol
      //if(StrToNormalize.Length()>0) // no numbers were found, all string is deleted
      //  if(!IsCharANumber(StrToNormalize[StrToNormalize.Length()]))
      //    StrToNormalize.Delete(StrToNormalize.Length(), 1);

    }

	return StrToNormalize;
}

//---------------------------------------------------------------------------
AnsiString NormalizeSummWithDotToNumberStr(AnsiString StrToNormalize)
{
    if(StrToNormalize.Length())
    {
      bool foundCommaOrDot = false;
	  for (int i = 1, j = 0, k = 0; i < (StrToNormalize.Length()+1); ++i)
      {
        if( i>1 && i != StrToNormalize.Length() )
          if(StrToNormalize[i] == ',' || StrToNormalize[i] == '.')
            if(IsCharANumber(StrToNormalize[i-1]) && IsCharANumber(StrToNormalize[i+1]))
              foundCommaOrDot=true;

        // it means we found in a string with one of thwe folowing formats:
        // "23000.00���" / "23 000.00�" / "23000.00 �." / "23000,00���" / "23000,00�" and so on
        if(foundCommaOrDot)
        { //removew everything after dot
          StrToNormalize.Delete(i, (StrToNormalize.Length() - i) +1);
          break;
        }
        else
        {
          j = !IsCharANumber(StrToNormalize[i]) ? ++j : 0;
          if(j==1) {k = i;}
          if(i != StrToNormalize.Length())
          {
            if( (j > 0) && IsCharANumber(StrToNormalize[i+1]) )
            {
              StrToNormalize.Delete(k,j);
              i = i - j;
            }
          }
          else
          { // remove last part
            if(j > 0) { StrToNormalize.Delete(k,j); }
            break;
          }
        }
      }

      // remove last nonNumber symbol
      //if(StrToNormalize.Length()>0) // no numbers were found, all string is deleted
      //  if(!IsCharANumber(StrToNormalize[StrToNormalize.Length()]))
      //    StrToNormalize.Delete(StrToNormalize.Length(), 1);
    }

	return StrToNormalize;
}
//---------------------------------------------------------------------------

bool CheckVIN(const AnsiString& vin) // http://www.vinfax.ru/about.html
{
   if(vin.Length() != 17) return false;
   int i_val;
   if(!TryStrToInt(vin.SubString(14, 4), i_val)) return false;

   for(int i = 1; i < 14; i++){
      if(!((vin[i] >= '0' && vin[i] <= '9') || (vin[i] >= 'A' && vin[i] <= 'Z'))) return false;
      if(vin[i] == 'I' || vin[i] == 'O' || vin[i] == 'Q')                         return false;
   }

   return true;
}
//---------------------------------------------------------------------------
bool CheckRegPlate(const AnsiString& rgpl)
{
   if(rgpl.Length() < 8) return false;

   for(int i = 1; i < 7; i++) if(reg_plate_possible.AnsiPos(rgpl.SubString(i, 1)) == 0) return false;

   return true;
}
//---------------------------------------------------------------------------
AnsiString NodeToStr(_di_IXMLNode node)
{
   if(node) return AnsiString(node->Text);
   return empty_str;
}
//---------------------------------------------------------------------------
AnsiString NormVIN_GN(mops_api_025 *m_api, const AnsiString& numb)
{
   int res;
   AnsiString st = m_api->Normalization_String_RSA(res, numb), st_eng("ETYOPKHAXCBM"), st_rus("������������");

   for(int i = 1, l = st_rus.Length() + 1; i < l; i++) st = StringReplace(st, st_rus[i], st_eng[i], rf);

   return st;
}
//---------------------------------------------------------------------------
void SeparateFIO(const AnsiString& fio, const int status, AnsiString& lname, AnsiString& fname, AnsiString& sname)
{
   lname = fname = sname = empty_str;
   if(status > 0) { lname = fio; return; }

   int pos(0);
   pos = fio.Pos(space_str);
   if(pos){
      lname = fio.SubString(1, pos).Trim();
      AnsiString temp_str = fio.Delete(1, pos);
      pos = temp_str.Pos(space_str);
      if(pos){
         fname = temp_str.SubString(1, pos).Trim();
         sname = temp_str.Delete(1, pos).Trim();
      }
      else fname = temp_str.Delete(1, pos).Trim();
   }
}
//---------------------------------------------------------------------------
void MakeKladrAddrFromARM(mops_api_028 *_m_api, _di_IXMLNode child_node, TStringList *addr, int& memo_id)
{
   int res;

   addr->Clear();
   memo_id = 0;
   AnsiString code_kladr = NodeToStr(child_node->ChildNodes->FindNode("KLADR_STREET_CODE"));
   if(code_kladr.IsEmpty()) return;

   addr->Values["��� �����"] = code_kladr;
   addr->Values["������"] = NodeToStr(child_node->ChildNodes->FindNode("ZIP"));
   addr->Values["���"] = NodeToStr(child_node->ChildNodes->FindNode("HOUSE_NUMBER"));
   addr->Values["������/��������"] = "�";
   addr->Values["����� �������"] = NodeToStr(child_node->ChildNodes->FindNode("BUILDING"));
   addr->Values["��������"] = NodeToStr(child_node->ChildNodes->FindNode("FLAT"));

   _m_api->KLADR_Try_Address_to_KLADR(res, addr);

   AnsiString memo_text = addr->Text;
   _m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "casco_memo");
}
//---------------------------------------------------------------------------
void MakeKladrAddrFromUXML(mops_api_028 *_m_api, _di_IXMLNode person, TStringList *addr, int& memo_id, AnsiString& exact_address)
{
   int res;

   AnsiString code_kladr = NodeToStr(person->ChildNodes->FindNode("street_id"));
   if(code_kladr.IsEmpty()){
      code_kladr = NodeToStr(person->ChildNodes->FindNode("region_id"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("exact_address"));
      if(code_kladr.IsEmpty()) return;
      addr->Values["������"] = NodeToStr(person->ChildNodes->FindNode("region"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("area"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("place"));
   }

   addr->Values["��� �����"] = code_kladr;

   addr->Values["������"] = NodeToStr(person->ChildNodes->FindNode("zip"));
   addr->Values["���"] = NodeToStr(person->ChildNodes->FindNode("house"));
   addr->Values["������/��������"] = "�";
   addr->Values["����� �������"] = NodeToStr(person->ChildNodes->FindNode("building"));
   addr->Values["��������"] = NodeToStr(person->ChildNodes->FindNode("flat"));

   _m_api->KLADR_Try_Address_to_KLADR(res, addr);

   AnsiString memo_text = addr->Text;
   //_m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "kasko_memo");
   _m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "casco_memo");

   exact_address = _m_api->KLADR_Get_Print_Address_By_Separated(res, addr);
}
//---------------------------------------------------------------------------
bool CheckAddrList(TStringList* addrlist)
{
   if(addrlist->Text.IsEmpty()) return false;

   if(addrlist->Count == 1 && addrlist->IndexOfName("������") > -1) return false;

   return true;
}
//---------------------------------------------------------------------------
RussoFieldName::RussoFieldName()
{
   insert(std::make_pair("ts_cost", " - �������������� ���������."));
   insert(std::make_pair("str_summa", " - ��������� �����."));
   insert(std::make_pair("allowed_mass", " - ����������� max �����."));
   insert(std::make_pair("number_of_seats", " - ����� ������������ ����."));
   insert(std::make_pair("pay_id", " - ������ ���������� ������."));
   insert(std::make_pair("franshize_id", " - ��� ��������."));
   insert(std::make_pair("franshize_size", " - ������ ����������� ��������."));
   insert(std::make_pair("franshize_unit", " - �������� ����������� ��������."));
   insert(std::make_pair("usage_purpose", " - ���� �������������."));
   insert(std::make_pair("ka", " - �����-� ������������."));
   insert(std::make_pair("ks", " - �����-� ��������."));
   insert(std::make_pair("risk_id", " - �������� ���� �� ��������."));
   insert(std::make_pair("multidrive", " - ��� ������������."));
   insert(std::make_pair("payments_count", "�� ��������.\r\n - ���������� ��������."));

   //dsago_liability
   //ns_liability
}
//---------------------------------------------------------------------------
SkkQuery::SkkQuery()
{
   insert(std::make_pair("5.1.3",  TblQue("select * from apo.carrier_models", "gl_dict_carrier_models", false)));
   insert(std::make_pair("7.1.55", TblQue("select * from apo.limit_damage_7_1_55", "kasko_dict_damagelimit", false)));
   insert(std::make_pair("7.2.19", TblQue("select * from apo.rassrochka_7_2_19", "kasko_dict_payments_count", false)));
   insert(std::make_pair("7.2.26", TblQue("select * from apo.model_link_group_7_2_26", "gl_dict_model_po_gruppam", false)));
   insert(std::make_pair("7.2.27", TblQue("select * from apo.telematic_devices_7_2_27", "kasko_dict_telematic_devices", false)));
   insert(std::make_pair("7.2.43", TblQue("select * from apo.alarms_7_2_43", "gl_dict_alarm_schema", false)));
   insert(std::make_pair("7.2.49", TblQue("select * from apo.alarms_7_2_49", "kasko_dict_alarmguard", false)));
   insert(std::make_pair("7.2.55", TblQue("select * from apo.reidentif_product_7_2_55", "kasko_dict_reidentifproduct", false)));
   insert(std::make_pair("7.2.56", TblQue("select * from apo.alarms_7_2_56", "gl_dict_alarms", false)));
   insert(std::make_pair("7.3.21", TblQue("select * from apo.payment_method_7_4_29_7_3_21", "kasko_dict_paymentmethod", false)));
   insert(std::make_pair("7.3.53", TblQue("select * from apo.franshize_7_3_53", "gl_dict_franshize", false)));
   insert(std::make_pair("7.3.67", TblQue("select * from apo.limited_drivers_7_3_67_7_3_65", "kasko_dict_multidrive", false)));
   insert(std::make_pair("7.4.30", TblQue("select * from apo.prg_prj_7_4_8_7_4_30", "gl_dict_program_project", false)));
   insert(std::make_pair("7.4.40", TblQue("select * from apo.usage_purpose_7_4_40_7_4_41", "kasko_dict_usagepurpose", false)));
   insert(std::make_pair("7.6.37", TblQue("select * from apo.banki_7_6_37_7_7_56", "gl_dict_banks", false)));
   insert(std::make_pair("7.7.59", TblQue("select * from apo.bank_apk_nl_7_7_59", "gl_dict_banks_program", false)));

   //
   //����������
   insert(std::make_pair("5.3.1", TblQue("select * from apo.transdector_5_3_1", "td_531", true)));
   insert(std::make_pair("5.3.2", TblQue("select * from apo.transdector_5_3_2", "td_532", true)));
   insert(std::make_pair("5.3.3", TblQue("select * from apo.transdector_5_3_3", "td_533", true)));
}

//---------------------------------------------------------------------------
void K1(mops_api_024 *m_api, const int index_pm, PersonInfo *pm, Dogovor_Info *di)
{
	TADOQuery *q;
	int res;
	AnsiString sql("");

	if (pm[index_pm].age == 0 && pm[index_pm].experience == 0)
		q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK01 where tertype_id=%i and drvexp_min=0 and drvexp_max=0 and age_min=0 and age_max=0 and CDate('%s')>=start_date and CDate('%s')<=end_date", di->REGION_TYPE, di->calc_date, di->calc_date));
	else
		q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK01 where tertype_id=%i and drvexp_min<=%i and drvexp_max>%i and age_min<=%i and age_max>%i and CDate('%s')>=start_date and CDate('%s')<=end_date",
			di->REGION_TYPE, pm[index_pm].experience, pm[index_pm].experience, pm[index_pm].age, pm[index_pm].age, di->calc_date, di->calc_date));
	pm[index_pm].k1 = q->IsEmpty() ? 1 : q->FieldByName("coeff_val")->AsFloat;

	m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void ChangeMask(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}


/*
////////////////////////////////////////////////////////////////////////////////
// FROM HERE
//---------------------------------------------------------------------------
MaskDocType::MaskDocType(const int type)
{
   switch(type){
      case 1:
         insert(std::make_pair(2,  InputMask("[A-Za-z�-��-�]{2}", "[0-9]{6}")));
         insert(std::make_pair(5,  InputMask("[A-Za-z�-��-�]{2}", "[0-9]{7}", 1)));
         insert(std::make_pair(6,  InputMask("[0-9]{2}", "[0-9]{7}")));
         insert(std::make_pair(7,  InputMask("", "", 0, 25)));
         insert(std::make_pair(12, InputMask("[0-9]{2}' '[0-9]{2}", "[0-9]{6}"))); //[0-9]{2}\s[0-9]{2}
         insert(std::make_pair(13, InputMask("[0-9]{2}", "[0-9]{7}")));
         insert(std::make_pair(15, InputMask("[A-Za-z�-��-�]{2}", "[0-9]{7}", 1)));
         insert(std::make_pair(17, InputMask("[0-9]{2}' '[0-9]{2}|[0-9]{2}' '[ABCDEFGHJKLMNOPRSTUVWXYZabcdefghjklmnoprstuvwxyz]{2}", "[0-9]{6}")));
         insert(std::make_pair(21, InputMask("[0-9]{2}", "[0-9]{9}")));
         insert(std::make_pair(24, InputMask("", "", 0, 20)));
         insert(std::make_pair(25, InputMask("[0-9]{2}", "[0-9]{9}")));
         insert(std::make_pair(29, InputMask("[0-9]{2}", "[0-9]{9}")));
         break;
      case 2:
         insert(std::make_pair(1, InputMask("[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}", "[0-9]{6}")));
         insert(std::make_pair(2, InputMask("[0-9]{4}|[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{3}", "[0-9]{6}")));
         insert(std::make_pair(3, InputMask("", "")));
         insert(std::make_pair(4, InputMask("", "")));
         insert(std::make_pair(5, InputMask("", "")));
         insert(std::make_pair(6, InputMask("", "")));
         insert(std::make_pair(7, InputMask("", "")));
         insert(std::make_pair(8, InputMask("", "")));
         insert(std::make_pair(9, InputMask("", "")));
         insert(std::make_pair(10,InputMask("", "")));
         break;
   }
}

//---------------------------------------------------------------------------
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
#if 1
   // >99\ aa;0;_
   //  123456
   // >999999;0;_
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   //if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
   //else
   r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;

   //if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
   //else
   r_DocNumber->Properties->Value   = v2;

   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;

   //DocNumber->Properties->EditMask  = ">999;0;_";
   //DocNumber->Properties->MaxLength = 3;
#endif
}
//---------------------------------------------------------------------------
void ChangeMask(TdxInspectorTextMaskRow *DocSeria, TdxInspectorTextMaskRow *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
	p_pi[index].doc_seria = v1;
	p_pi[index].doc_number = v2;

	DocSeria->EditText = StringReplace(v1, space_str, empty_str, rf);
	DocSeria->EditMask = mask_doc_type[p_pi[index].doc_type].mask_series;
	DocSeria->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;

	DocNumber->EditText = v2;
	DocNumber->EditMask = mask_doc_type[p_pi[index].doc_type].mask_number;
	DocNumber->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
//void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, TSInfo *p_tsi, const int index, const AnsiString& v1, const AnsiString& v2)
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, VehicleInfo *p_tsi, const int index, const AnsiString& v1, const AnsiString& v2)
{
#if 0 // TSInfo //from old TOOLS.H
	p_tsi->pts_series = v1;
	p_tsi->pts_number = v2;

	//if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
	//else
     r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
	DocSeria->Properties->EditMask = mask_vehicle_doc_type[p_tsi->type_doc_ts].mask_series;
	DocSeria->Properties->MaxLength = mask_vehicle_doc_type[p_tsi->type_doc_ts].max_length;

	//if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
	//else
    r_DocNumber->Properties->Value = v2;
	DocNumber->Properties->EditMask = mask_vehicle_doc_type[p_tsi->type_doc_ts].mask_number;
	DocNumber->Properties->MaxLength = mask_vehicle_doc_type[p_tsi->type_doc_ts].max_length;
#endif

	p_tsi->registration_series = v1;
	p_tsi->registration_number = v2;

	//if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
	//else
     r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
	DocSeria->Properties->EditMask = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].mask_series;
	DocSeria->Properties->MaxLength = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].max_length;

	//if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
	//else
     r_DocNumber->Properties->Value = v2;
	DocNumber->Properties->EditMask = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].mask_number;
	DocNumber->Properties->MaxLength = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].max_length;
}
//*/



//---------------------------------------------------------------------------
// FROM OLD TOOLS
MaskDocType::MaskDocType(const int type)
{
   switch(type){
      case 1:
         insert(std::make_pair(2,  InputMask(">ll;0;_", ">999999;0;_")));
         insert(std::make_pair(5,  InputMask(">ll;0;_", ">9999999;0;_", 1)));
         insert(std::make_pair(6,  InputMask(">99;0;_", ">9999999;0;_")));
         insert(std::make_pair(7,  InputMask("", "", 0, 25)));
         insert(std::make_pair(9,  InputMask("", "", 0, 25)));
         insert(std::make_pair(12, InputMask(">99\ 99;0;_", ">999999;0;_")));
         insert(std::make_pair(13, InputMask(">99;0;_", ">9999999;0;_")));
         insert(std::make_pair(15, InputMask(">ll;0;_", ">9999999;0;_", 1)));
         insert(std::make_pair(17, InputMask(">99\ aa;0;_", ">999999;0;_")));
         insert(std::make_pair(21, InputMask(">99;0;_", ">999999999;0;_")));
         insert(std::make_pair(24, InputMask("", "", 0, 20)));
         insert(std::make_pair(25, InputMask(">99;0;_", ">999999999;0;_")));
         insert(std::make_pair(29, InputMask(">99;0;_", ">999999999;0;_")));
         break;
      case 2:
         insert(std::make_pair(1, InputMask("[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}", ">999999;0;_")));
         insert(std::make_pair(2, InputMask("[0-9]{4}|[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{3}", ">999999;0;_")));
         insert(std::make_pair(3, InputMask("", "")));
         insert(std::make_pair(4, InputMask("", "")));
         insert(std::make_pair(5, InputMask("", "")));
         insert(std::make_pair(6, InputMask("", "")));
         insert(std::make_pair(7, InputMask("", "")));
         insert(std::make_pair(8, InputMask("", "")));
         insert(std::make_pair(9, InputMask("", "")));
         insert(std::make_pair(10,InputMask("", "")));
         break;
   }
}

//---------------------------------------------------------------------------
// FROM OLD TOOLS
void ChangeMask(TdxInspectorTextMaskRow *DocSeria, TdxInspectorTextMaskRow *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   DocSeria->EditText   = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;

   DocNumber->EditText  = v2;
   DocNumber->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
// FROM OLD TOOLS
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   /*if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
   else*/ r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;

   /*if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
   else*/ r_DocNumber->Properties->Value   = v2;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
// FROM OLD TOOLS
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, VehicleInfo *p_tsi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_tsi->registration_series = v1;
   p_tsi->registration_number = v2;

   /*if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
   else*/ r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].mask_series;
   DocSeria->Properties->MaxLength  = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].max_length;

   /*if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
   else*/ r_DocNumber->Properties->Value   = v2;
   DocNumber->Properties->EditMask  = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].mask_number;
   DocNumber->Properties->MaxLength = mask_vehicle_doc_type[p_tsi->vehicle_registration_type_id].max_length;
}
//---------------------------------------------------------------------------








//---------------------------------------------------------------------------
double GetKprSb(const double& val)
{
	if (val <= 0.54) return 1.75;
	if (val <= 0.59) return 1.60;
	if (val <= 0.64) return 1.50;
	if (val <= 0.69) return 1.40;
	if (val <= 0.74) return 1.30;
	if (val <= 0.79) return 1.25;
	if (val <= 0.84) return 1.2;
	if (val <= 0.89) return 1.15;

	return 1.1;
}
//---------------------------------------------------------------------------
AnsiString MarkaId(const int model_id)
{
	return (model_id == -1 ? AnsiString(model_id) : AddNulls((model_id / 1000000) * 1000000));
}
//---------------------------------------------------------------------------

void GetPhones(_di_IXMLNode contacts, AnsiString& ph_mob, AnsiString& ph_home, AnsiString& ph_rab, int &sms)
{
   sms = -1;
   for(int i = 0, cnt = contacts->ChildNodes->Count, i_val = 0; i < cnt; ++i){
      _di_IXMLNode child_node = contacts->ChildNodes->Get(i);
      if(child_node->HasAttribute("contract_type_id") && TryStrToInt(child_node->Attributes["contact_type_id"], i_val)){
         switch(i_val){
            case 1:
               if(child_node->HasAttribute("contract_data")) ph_home = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data"))  ph_home = child_node->Attributes["contact_data"];
               break;
            case 2:
               if(child_node->HasAttribute("contract_data")) ph_rab = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data"))  ph_rab = child_node->Attributes["contact_data"];
               break;
            case 3:
               if(child_node->HasAttribute("contract_data")) ph_mob = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data")) ph_mob = child_node->Attributes["contact_data"];
               if(child_node->HasAttribute("spam")) sms = AnsiString(child_node->Attributes["contact_data"]).ToIntDef(-1);
               break;
         }
      }
   }
}
//---------------------------------------------------------------------------
AnsiString IntToBin(const int ANumber, int ABitCount)
{
   ABitCount = (ABitCount < 1) ? 1 : ((ABitCount > 32) ? 32 : ABitCount);

   AnsiString Result("", ABitCount);

   for(int i = ABitCount, Mask = 1; i >= 1; i--, Mask <<= 1) Result[i] = (ANumber & Mask) ? '1' : '0';

   return Result;
}
//---------------------------------------------------------------------------
void PmDataToRecord(TADOQuery* q_perm, PersonInfo *pm, const int calc_id, const int num, const int i, const int pm_status)
{
/*
   q_perm->FieldByName("calc_id")->Value = calc_id;
   q_perm->FieldByName("status")->Value = 0;
   q_perm->FieldByName("type_person")->Value = num + 4;
   q_perm->FieldByName("first_name")->Value = pm[i].firstname;
   q_perm->FieldByName("second_name")->Value = pm[i].secondname;
   q_perm->FieldByName("last_name")->Value = pm[i].lastname;
   q_perm->FieldByName("phisical_birth_date")->Value = pm[i].birthdate;
   q_perm->FieldByName("phisical_sex")->Value = pm[i].sex;
   q_perm->FieldByName("age")->Value = pm[i].age;
   q_perm->FieldByName("experience")->Value = pm[i].experience;
   q_perm->FieldByName("document_type_id")->Value = pm[i].doc_type;
   q_perm->FieldByName("document_series")->Value = pm[i].doc_seria;
   q_perm->FieldByName("document_number")->Value = pm[i].doc_number;
   q_perm->FieldByName("document_issue_date")->Value = pm[i].doc_issue_date;
   q_perm->FieldByName("k1")->Value = pm[i].k1;
   q_perm->FieldByName("k6")->Value = pm[i].k6;
   q_perm->FieldByName("rsa_id")->Value = pm[i].rsa_id;
*/
   q_perm->FieldByName("calc_id")->Value = calc_id;
   q_perm->FieldByName("status")->Value = 0;
   q_perm->FieldByName("type_person")->Value = num + 4;
   q_perm->FieldByName("first_name")->Value = pm[i].firstname;
   q_perm->FieldByName("second_name")->Value = pm[i].secondname;
   q_perm->FieldByName("last_name")->Value = pm[i].lastname;
   q_perm->FieldByName("phisical_birth_date")->Value = pm[i].birthdate;
   q_perm->FieldByName("phisical_sex")->Value = pm[i].sex;
   q_perm->FieldByName("age")->Value = pm[i].age;
   q_perm->FieldByName("experience")->Value = pm[i].experience;
   q_perm->FieldByName("document_type_id")->Value = pm[i].doc_type;
   q_perm->FieldByName("document_series")->Value = pm[i].doc_seria;
   q_perm->FieldByName("document_number")->Value = pm[i].doc_number;
   q_perm->FieldByName("document_issue_date")->Value = pm[i].doc_issue_date;
   q_perm->FieldByName("addr_mid")->Value = 0;
   q_perm->FieldByName("permitted_status")->Value = pm_status;
   q_perm->FieldByName("address")->Value = pm[i].address;
   q_perm->FieldByName("black_list")->Value = pm[i].black_list;
   q_perm->FieldByName("k6")->Value = pm[i].k6;
   q_perm->FieldByName("is_underwriting")->Value = pm[i].is_underwriting;
   q_perm->FieldByName("rsa_id")->Value = pm[i].rsa_id;
}
//---------------------------------------------------------------------------
void Save_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, PersonInfo *pi, PersonInfo *pm, TListView *gridDopush)
{
   int res;
   AnsiString calc_id_str = IntToStr(calc_id);
   m_api->dbExecuteQuery(res, "delete * from kasko_dogovors_k5_k6 where calc_id=" + calc_id_str);
   TADOQuery *q_d_k5_k6 = m_api->dbGetCursor(res, "select * from kasko_dogovors_k5_k6 where calc_id=" + calc_id_str, 0, 1);
   for(std::map<AnsiString, std::vector<Dogovor> >::iterator iter = pi[0].dogovors.begin(); iter != pi[0].dogovors.end(); ++iter)
   {
      AnsiString key = iter->first;
      for(int i = 0, cnt = pi[0].dogovors[key].size(); i < cnt; ++i)
	  {
         q_d_k5_k6->Insert();
         q_d_k5_k6->FieldByName("calc_id")->Value      = calc_id;
         q_d_k5_k6->FieldByName("type_person")->Value  = 1;
         q_d_k5_k6->FieldByName("type_dogovor")->Value = key;
         q_d_k5_k6->FieldByName("system")->Value       = pi[0].dogovors[key][i].system;
         q_d_k5_k6->FieldByName("dogovor_id")->Value   = pi[0].dogovors[key][i].id;
      }
   }

   for(int i = 0, j = 0, drv_count = gridDopush->Items->Count; i < drv_count; ++i)
   {
      if(gridDopush->Items->Item[i]->Checked)
	  {
         for(int d = 0, cnt = pm[i].dogovors["k6"].size(); d < cnt; ++d){
            q_d_k5_k6->Insert();
            q_d_k5_k6->FieldByName("calc_id")->Value      = calc_id;
            q_d_k5_k6->FieldByName("type_person")->Value  = j + 4;
            q_d_k5_k6->FieldByName("type_dogovor")->Value = "k6";
            q_d_k5_k6->FieldByName("system")->Value       = pm[i].dogovors["k6"][d].system;
            q_d_k5_k6->FieldByName("dogovor_id")->Value   = pm[i].dogovors["k6"][d].id;
         }
         ++j;
      }
   }
   q_d_k5_k6->UpdateBatch();
   m_api->dbCloseCursor(res, q_d_k5_k6);
}
//---------------------------------------------------------------------------
void Load_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, PersonInfo *pi, PersonInfo *pm)
{
   int res;
   TADOQuery *q_d_k5_k6 = m_api->dbGetCursor(res, "select * from kasko_dogovors_k5_k6 where calc_id=" + IntToStr(calc_id) + " order by type_person, type_dogovor");
   for(q_d_k5_k6->First(); !q_d_k5_k6->Eof; q_d_k5_k6->Next()){
      if(q_d_k5_k6->FieldByName("type_person")->AsInteger == 1) pi[0].dogovors[q_d_k5_k6->FieldByName("type_dogovor")->AsString].push_back(Dogovor(q_d_k5_k6->FieldByName("dogovor_id")->AsString, q_d_k5_k6->FieldByName("system")->AsInteger));
      else pm[q_d_k5_k6->FieldByName("type_person")->AsInteger - 4].dogovors[q_d_k5_k6->FieldByName("type_dogovor")->AsString].push_back(Dogovor(q_d_k5_k6->FieldByName("dogovor_id")->AsString, q_d_k5_k6->FieldByName("system")->AsInteger));
   }
   m_api->dbCloseCursor(res, q_d_k5_k6);
}
//---------------------------------------------------------------------------
void Save_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm, TListView *gridDopush)
{
	int res;
	AnsiString calc_id_str = IntToStr(calc_id);
	m_api->dbExecuteQuery(res, "delete * from casco_dogovors_k5_k6 where calc_id=" + calc_id_str);
	TADOQuery *q_d_k5_k6 = m_api->dbGetCursor(res, "select * from casco_dogovors_k5_k6 where calc_id=" + calc_id_str, 0, 1);
	for (std::map<AnsiString, std::vector<Dogovor> >::iterator iter = pi[0].dogovors.begin(); iter != pi[0].dogovors.end(); ++iter) {
		AnsiString key = iter->first;
		for (int i = 0, cnt = pi[0].dogovors[key].size(); i < cnt; ++i) {
			q_d_k5_k6->Insert();
			q_d_k5_k6->FieldByName("calc_id")->Value = calc_id;
			q_d_k5_k6->FieldByName("type_person")->Value = 1;
			q_d_k5_k6->FieldByName("type_dogovor")->Value = key;
			q_d_k5_k6->FieldByName("system")->Value = pi[0].dogovors[key][i].system;
			q_d_k5_k6->FieldByName("dogovor_id")->Value = pi[0].dogovors[key][i].id;
			q_d_k5_k6->FieldByName("is_last")->Value = (
/* // TSInfo
            pi[0].dogovors[key][i].id == di->last_contract_ido &&
*/             pi[0].dogovors[key][i].system == di->system) ? 1 : 0;
		}
	}

	for (int i = 0, j = 0, drv_count = gridDopush->Items->Count; i < drv_count; ++i) {
		if (gridDopush->Items->Item[i]->Checked) {
			for (int d = 0, cnt = pm[i].dogovors["k6"].size(); d < cnt; ++d) {
				q_d_k5_k6->Insert();
				q_d_k5_k6->FieldByName("calc_id")->Value = calc_id;
				q_d_k5_k6->FieldByName("type_person")->Value = j + 4;
				q_d_k5_k6->FieldByName("type_dogovor")->Value = "k6";
				q_d_k5_k6->FieldByName("system")->Value = pm[i].dogovors["k6"][d].system;
				q_d_k5_k6->FieldByName("dogovor_id")->Value = pm[i].dogovors["k6"][d].id;
				q_d_k5_k6->FieldByName("is_last")->Value = 0;
			}
			++j;
		}
	}
	q_d_k5_k6->UpdateBatch();
	m_api->dbCloseCursor(res, q_d_k5_k6);
}
//---------------------------------------------------------------------------
void Load_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm)
{
	int res;
	TADOQuery *q_d_k5_k6 = m_api->dbGetCursor(res, "select * from casco_dogovors_k5_k6 where calc_id=" + IntToStr(calc_id) + " order by type_person, type_dogovor");
	for (q_d_k5_k6->First(); !q_d_k5_k6->Eof; q_d_k5_k6->Next()) {
		if (q_d_k5_k6->FieldByName("type_person")->AsInteger == 1) {
			pi[0].dogovors[q_d_k5_k6->FieldByName("type_dogovor")->AsString].push_back(Dogovor(q_d_k5_k6->FieldByName("dogovor_id")->AsString, q_d_k5_k6->FieldByName("system")->AsInteger));
			if (q_d_k5_k6->FieldByName("is_last")->AsInteger) {
/* // TSInfo
				di->last_contract_id = q_d_k5_k6->FieldByName("dogovor_id")->AsString;
*/
				di->system = q_d_k5_k6->FieldByName("system")->AsInteger;
			}
		}
		else pm[q_d_k5_k6->FieldByName("type_person")->AsInteger - 4].dogovors[q_d_k5_k6->FieldByName("type_dogovor")->AsString].push_back(Dogovor(q_d_k5_k6->FieldByName("dogovor_id")->AsString, q_d_k5_k6->FieldByName("system")->AsInteger));
	}
	m_api->dbCloseCursor(res, q_d_k5_k6);
}
//---------------------------------------------------------------------------
void FieldValueIDToVGEditor(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row)
{
   int index = cboxitem->Properties->Items->IndexOfObject((TObject*)fv);
   if(index > -1) row->Properties->Value = cboxitem->Properties->Items->Strings[index];
   else row->Properties->Value = variant_null;
}
//---------------------------------------------------------------------------
void FieldValueIDToVGEditor_(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row)
{
   int index = GetIndexObject(cboxitem->Properties->Items, fv);
   if(index > -1) row->Properties->Value = cboxitem->Properties->Items->Strings[index];
   else row->Properties->Value = variant_null;
}
//---------------------------------------------------------------------------
int GetDrvCount(TADOQuery *qq)
{
   qq->Filtered = false;
   qq->Filter   = "[type_person] > 3";
   qq->Filtered = true;

   int drv_count = qq->RecordCount;

   qq->Filtered = false;

   return drv_count;
}
//---------------------------------------------------------------------------
int GetCountPermitted(TListView *gridDopush)
{
   int count_permitted(0);

   for(int i = 0, cnt = gridDopush->Items->Count; i < cnt; ++i) if(gridDopush->Items->Item[i]->Checked) ++count_permitted;

   return count_permitted;
}
//---------------------------------------------------------------------------
int MonthsCount(const TDateTime& ANow, const TDateTime& AThen)
{
   int ACount;
   for(ACount = 1; ACount < 13; ++ACount) if(IncMonth(ANow, ACount) > AThen) return ACount;
   return ACount;
}
//---------------------------------------------------------------------------
void VariantToDate(Variant v, TDateTime& dt)
{
   AnsiString dt_str("");

   if(!v.IsNull() && !v.IsEmpty()){
      dt_str = v;
      if(dt_str.Length() < 10 || !TryStrToDate(dt_str, dt)) dt.Val = 0;
   }
   else dt.Val = 0;
}
//---------------------------------------------------------------------------
void UpdateOneField(TADOQuery *qq, const AnsiString& fieldname, const Variant& value)
{
   for(qq->First(); !qq->Eof; qq->Next()){
      qq->Edit();
      qq->FieldByName(fieldname)->Value = value;
      qq->Post();
   }
}
//---------------------------------------------------------------------------
void UpdateOneField(TClientDataSet *qq, const AnsiString& fieldname, const Variant& value)
{
   for(qq->First(); !qq->Eof; qq->Next()){
      qq->Edit();
      qq->FieldByName(fieldname)->Value = value;
      qq->Post();
   }
}
//---------------------------------------------------------------------------
void SetEnterInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetValueEdit(edit, empty_str, onchange);
      edit->Font->Color = clBlack;
   }
}
//---------------------------------------------------------------------------
void ExitFromEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetValueEdit(edit, edit->Hint, onchange);
      edit->Font->Color = clSilver;
   }
}
//---------------------------------------------------------------------------
void SetEnterInComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetTextTocxComboBox(cbox, empty_str, onchange);
      cbox->Style->Font->Color = clBlack;
   }
}
//---------------------------------------------------------------------------
void ExitFromComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetTextTocxComboBox(cbox, cbox->Hint, onchange);
      cbox->Style->Font->Color = clSilver;
   }
}
//---------------------------------------------------------------------------
void SetEnterInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit)
{
   if(str.IsEmpty()){
      edit->Text = empty_str;
      edit->Style->TextColor = clBlack;
   }
}
//---------------------------------------------------------------------------
void ExitFromButtonEditBox(const AnsiString& str, TcxButtonEdit *edit)
{
   if(str.IsEmpty()){
      edit->Text = edit->Hint;
      edit->Style->TextColor = clSilver;
   }
}
//---------------------------------------------------------------------------
void SetTextAndColorInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange)
{
   SetValueEdit(edit, str.IsEmpty() ? edit->Hint : str, onchange);
   edit->Font->Color = str.IsEmpty() ? clSilver : clBlack;
}
//---------------------------------------------------------------------------
void SetTextAndColorInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit)
{
   edit->Text = str.IsEmpty() ? edit->Hint : str;
   edit->Style->TextColor = str.IsEmpty() ? clSilver : clBlack;
}
//---------------------------------------------------------------------------
void SetValueAndHintInDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange, TStaticText *hint)
{
   SetValueDateEdit(dedit, dt, onchange);
   hint->Visible = !dt.Val;
}
//---------------------------------------------------------------------------
void SetValueAndHintInMaskEdit(TcxMaskEdit* edit, const AnsiString& str, ptr_onchange onchange, TStaticText *hint)
{
   edit->Properties->OnChange = 0;
   edit->Text = str;
   edit->Properties->OnChange = onchange;
   hint->Visible = str.IsEmpty();
}
//---------------------------------------------------------------------------
void SetIndexAndHintIncxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange, const int type, TStaticText *hint)
{
   SetIndexTcxComboBox(cbox, value, onchange, type);
   hint->Visible = cbox->ItemIndex == -1;
}
//---------------------------------------------------------------------------
void SetIndexTocxRadioGroup(TcxRadioGroup *rg, const int index, ptr_onclick onclick)
{
   rg->OnClick = 0;
   rg->ItemIndex = index;
   rg->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueTocxLookupComboBox(TcxLookupComboBox *cbox, const Variant& value, ptr_oneditvaluechanged oneditvaluechanged)
{
   cbox->Properties->OnEditValueChanged = 0;
   cbox->EditValue = value;
   cbox->Properties->OnEditValueChanged = oneditvaluechanged;
}
//---------------------------------------------------------------------------
void SetHeightsToPcAndGb(TcxPageControl *pc, TglGroupBox *gb, Dogovor_Info *di)
{
   int index_x = pc->Tag, index_y = pc->ActivePage->PageIndex;
   if(index_x == 2 && index_y == 1 && di->type_money){
      gb->Height = di->bank_id == 47 ? 475 : 410;
      pc->Height = di->bank_id == 47 ? 390 : 325;
   }
   else{
      gb->Height = heights[index_x][index_y];
      pc->Height = heights[index_x + 1][index_y];
   }
}
//---------------------------------------------------------------------------
void SetHeightInspector1(TCustomdxInspectorControl *inspector)
{
	int h(0);
	for (int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i)
		if (inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node)) h += inspector->Rows[i]->RowHeight;
	inspector->Height = h;
}
//---------------------------------------------------------------------------
void SetHeightInspector2(TCustomdxInspectorControl *inspector)
{
	int h(0);
	for (int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i) h += inspector->Rows[i]->RowHeight;
	inspector->Height = h;
}
//---------------------------------------------------------------------------
void SetHeightInspector_1(TdxInspector *inspector)
{
	int h(0);

	for (int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i)
		if ((inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node)) || inspector->RowInComplexRow(inspector->Rows[i])) h += inspector->Rows[i]->RowHeight;
	inspector->Height = h;
}
//---------------------------------------------------------------------------
void SetHeightInspector_2(TdxInspector *inspector)
{
	int h(0);
	for (int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i) h += inspector->Rows[i]->RowHeight;
	inspector->Height = h;
}
//---------------------------------------------------------------------------
int GetToplabHint_1(TdxInspector *inspector)
{
	if (!inspector->FocusedNode) return -100;

	int t(0), a_i = inspector->FocusedNode->AbsoluteIndex;

	for (int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i) {
		if (inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node) && inspector->Rows[i]->Node->AbsoluteIndex < a_i) t += inspector->Rows[i]->RowHeight;
	}

	return inspector->Top + t + 3;
}
//---------------------------------------------------------------------------
int GetToplabHint_2(TdxInspector *inspector)
{
	if (!inspector->FocusedNode) return -100;

	int t(0), a_i = inspector->FocusedNode->AbsoluteIndex;
	for (int i = 0; i < a_i; ++i) t += inspector->Rows[i]->RowHeight;

	return inspector->Top + t + 2;
}
//---------------------------------------------------------------------------
int GetToplabHint(TCustomdxInspectorControl *inspector)
{
	if (!inspector->FocusedNode) return -100;
	int t(0), a_i = inspector->FocusedNode->AbsoluteIndex, i(0), cnt = inspector->VisibleTotalRowCount;
	switch (inspector->Tag) {
	case 0:
		for (int i = 0; i < a_i; ++i) t += inspector->Rows[i]->RowHeight;
		break;
	case 1:
		for (i = 0; i < cnt; ++i) {
			if (inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node) && inspector->Rows[i]->Node->AbsoluteIndex < a_i) t += inspector->Rows[i]->RowHeight;
		}
		break;
	}

	return inspector->Top + t + 2 + inspector->Tag;
}
//---------------------------------------------------------------------------
void SetActivePageTocxPageControl(TcxPageControl *pc, TcxTabSheet *sh, ptr_onchange onchange)
{
   pc->OnChange = 0;
   pc->ActivePage = sh;
   pc->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetTextAndColorTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange)
{
   SetTextTocxComboBox(cbox, value, onchange);
   if(!value.IsEmpty()) cbox->Style->Font->Color = clBlack;
}
//---------------------------------------------------------------------------
AnsiString ReservToStr(const std::set<int>& s)
{
   AnsiString result("");
   for(std::set<int>::iterator iter = s.begin(); iter != s.end(); ++iter)
      result = result + " and reservation_id_3<>" + IntToStr(*iter);

   return result;
}
//---------------------------------------------------------------------------
void SetValuecxSpinEdit(TcxSpinEdit *spinedit, const double& value, ptr_onchange onchange, ptr_onvalidate onvalidate)
{
   spinedit->Properties->OnChange = 0;
   spinedit->Properties->OnEditValueChanged = 0;
   spinedit->Value = value;
   spinedit->Properties->OnChange = onchange;
   spinedit->Properties->OnValidate = onvalidate;
}
//---------------------------------------------------------------------------
void LoadDataCurrentUser(mops_api_028 *m_api, Dogovor_Info *p_di)
{
   int res;
   
   TADOQuery *q = m_api->dbGetCursor(res, "select name,lnr,skk,mobile_phone,sale_channel_type2008_id,arm_agent_id from _mops_polzovateli_ where id=" + IntToStr(p_di->user_info.user_id));

   p_di->user_info.name     = q->FieldByName("name")->AsString;
   p_di->user_info.phone    = q->FieldByName("mobile_phone")->AsString;
   p_di->user_info.skk      = q->FieldByName("skk")->AsString;
   p_di->user_info.lnr      = q->FieldByName("lnr")->AsString;
   p_di->user_info.agent_id = q->FieldByName("arm_agent_id")->AsString;

   p_di->user_info.sale_channel_id = q->FieldByName("sale_channel_type2008_id")->AsInteger;

   if(!q->FieldByName("skk")->AsString.IsEmpty()){
      mops_api_028 *branch_api = (mops_api_028*)m_api->glDic_Get_API(res, "���������� �������������/������");
      TADOQuery *q_branches = branch_api->dbGetCursor(res, "select * from branches where branch_code='" + q->FieldByName("skk")->AsString + "'");
      p_di->user_info.osp = q_branches->FieldByName("full_name")->AsString;
      if(q_branches->FindField("address")) p_di->user_info.osp_address = q_branches->FieldByName("address")->AsString;
      branch_api->dbCloseCursor(res, q_branches);
      //select * from branches where branch_code='27802000'
      q_branches = branch_api->dbGetCursor(res, "select * from branches where branch_code='" + q->FieldByName("skk")->AsString.SubString(1, 3) +  "09000'");
      p_di->user_info.filial = q_branches->FieldByName("full_name")->AsString.Delete(1, 28);
      if(q_branches->FindField("address")) p_di->user_info.filial_address = q_branches->FieldByName("address")->AsString;
      branch_api->dbCloseCursor(res, q_branches);
   }
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void MakeExportFilters(TSaveDialog *sd, Dogovor_Info *di, Map_Int_Str &filter)
{
   if(di->is_msoff){
      sd->Filter = "Excel|*.xls";
      filter[1] = "XLS";
   }
   if(di->is_opoff){
      if(di->is_msoff){
         sd->Filter += "|";
         filter[2] = "ODS";
      }
      else filter[1] = "ODS";
      sd->Filter += "OpenOffice(LibreOffice)|*.ods";
      if(di->is_msoff) sd->FilterIndex = 2;
   }
}
//---------------------------------------------------------------------------
AnsiString Translit_Text(const AnsiString& source, const int rus_lat)
{
   AnsiString result = source;

   for(int i = 0; i < 12; ++i) result = FastStringReplace(result, rus_lat ? table_lat[i] : table_rus[i], rus_lat ? table_rus[i] : table_lat[i], rf);

   return result;
}
//---------------------------------------------------------------------------
void SetValueRadioButton(TRadioButton *rb, const int v, ptr_onclick onclick)
{
   rb->OnClick = 0;
   rb->Checked = v;
   rb->OnClick = onclick;
}
//---------------------------------------------------------------------------
void CreatePDF(AnsiString doc, TMemoryStream *pdf_file)
{
   int res;
   long buff_size = doc.Length();
   byte *buff;
   m_api->Internal_SetLastError("GetPDF Kasko2 before Internal_String2Buff buff_size=" + IntToStr(buff_size));
   m_api->Internal_String2Buff(res, &doc, &buff, &buff_size);
   m_api->Internal_SetLastError("GetPDF Kasko2 after Internal_String2Buff buff_size=" + IntToStr(buff_size));
   pdf_file->Clear();
   pdf_file->WriteBuffer(buff, buff_size);
   delete [] buff; buff = 0;
   pdf_file->Position = 0;
}
//---------------------------------------------------------------------------
AnsiString NodeAttributeToStr(_di_IXMLNode node, const AnsiString& name, const AnsiString& value)
{
   AnsiString result("");
   if(node->HasAttribute(name)) result = AnsiString(node->Attributes[value]);

   return result;
}
//---------------------------------------------------------------------------
AnsiString ClearStr(const AnsiString& str)
{
   AnsiString result("");

   for(int i = 1, l = str.Length(); i <= l; ++i)
      if(!str.IsDelimiter(not_filename, i)) result += str[i];

   //if(str.Length())
   return result;
}
//---------------------------------------------------------------------------
int GetVehicleGroup(mops_api_028 *m_api, const int vehicle_type_id, const AnsiString& rsa_code, const int allowed_mass, const int number_of_seats, const AnsiString& calc_date)
{
   int res;
   AnsiString sql("");

   if(vehicle_type_id < 5)
      return m_api->dbGetStringFromQueryDef(res, sql.sprintf("select top 1 gruppa_ts from gl_dict_model_po_gruppam where id_ts='%s' and ((min_massa<=%i and max_massa>=%i) or (min_massa=0 and max_massa=0)) and ((min_col_m<=%i and max_col_m>=%i) or (min_col_m=0 and max_col_m=0)) and CDate('%s')>=start_data and CDate('%s')<=end_data order by min_massa desc, min_col_m desc", rsa_code, allowed_mass, allowed_mass, number_of_seats, number_of_seats, calc_date, calc_date), "-1").ToInt();

   else{
      if(vehicle_type_id == 7) return 11; //�����������
      else if(vehicle_type_id >= 8 && vehicle_type_id <= 10) return 10; // �������
   }

   return -1;
}
//---------------------------------------------------------------------------
__int64 FileSize(const AnsiString& fn)
{
   TFileStream *fs = new TFileStream(fn, fmOpenRead);
   __int64 filesize = fs->Size;
   delete fs;

   return filesize;
}
//---------------------------------------------------------------------------
AnsiString ConvertDateTime(const TDateTime& date, AnsiString& time, const int offsethour)
{
    if(time.IsEmpty()) time = "00:00";
    return date.FormatString("yyyy-mm-dd") + "T" + time + ":00.0000000+" + AddNulls(offsethour, 2) + ":00";
}
//---------------------------------------------------------------------------
AnsiString ConvertDateTimeNoZeros(const TDateTime& date, AnsiString& time, const int offsethour)
{
    if(time.IsEmpty()) time = "00:00";
	return date.FormatString("yyyy-mm-dd") + "T" + time + ":00+" + AddNulls(offsethour, 2) + ":00";
}
//---------------------------------------------------------------------------
/*
Boolean PasportInBadList(AnsiString DocSeria, AnsiString DocNumber, Integer DocType, AnsiString APO2_ARM_READER_ADR)
{
	Boolean IsBadDoc = False;

	const int cBadDoc = 1;
	const int cPasportRF = 12;
	const AnsiString cWarningBadDoc = "��������! ������ �������� �������� ����� ���������������� (���������� (����������), ����������� �� ���������� (����������) ������� �������� ���������� ���������� ���������, �������� � ��������� �������������� �������, � ����� ���������� �����������������) ��������� ������� ���������� ���������, �������������� �������� ���������� ���������� ��������� �� ���������� ���������� ���������."
		"���������� �������� � ������ ������ ��������������� ������������� ����� ���� ������������ ��������, �.�. ������ �� �� ����� ���� ���������������� �� �������������� ���������";

	if (DocType != cPasportRF)
		return IsBadDoc;

	DocSeria = StringReplace(DocSeria, " ", "", TReplaceFlags() << rfReplaceAll);
	DocSeria = StringReplace(DocSeria, "_", "", TReplaceFlags() << rfReplaceAll);

	DocNumber = StringReplace(DocNumber, " ", "", TReplaceFlags() << rfReplaceAll);
	DocNumber = StringReplace(DocNumber, "_", "", TReplaceFlags() << rfReplaceAll);

	if (DocSeria.Length() > 3 && DocNumber.Length() > 5) //4 ����� ����� � 6 �����
	{
		try
		{
			RegTypes();
			IsBadDoc = (GetIAPO2_ARM_READER(false, APO2_ARM_READER_ADR)->PassportIsBad(DocSeria, DocNumber) == cBadDoc);
			UnRegTypes();

			if (IsBadDoc)
				ShowMessage(cWarningBadDoc);
		}
		catch (Exception& ex)
		{
			ShowMessage("��������� ������� �� �������.[" + APO2_ARM_READER_ADR + "] " + ex.Message);
		}
	}
	return IsBadDoc;
}
//*/
//---------------------------------------------------------------------------

