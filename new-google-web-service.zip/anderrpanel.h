//---------------------------------------------------------------------------
#ifndef anderrpanelH
#define anderrpanelH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "cxControls.hpp"
#include "cxDBEditRepository.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include "cxCurrencyEdit.hpp"

#include "TMops_api.h"
#include "UViewHistory.h"
//#include "tools.h"
#include "structures.h"


class TFrameNew;
class TFReissCalc;
//---------------------------------------------------------------------------
class TAnderrFrame : public TFrame
{
__published:	// IDE-managed Components
   TcxVerticalGrid *vg;
   TcxEditRepository *cxEditRepository1;
   TcxEditRepositoryTextItem *TextItem;
   TcxEditRepositoryDateItem *DateItem;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxCategoryRow *vgCategoryRow1;
   TcxEditorRow *vg_paVariant;
   TcxEditorRow *vg_paDogovor;
   TcxEditorRow *vg_paSaleChannel;
   TcxEditorRow *vg_paRegion;
   TcxStyle *cxStyle3;
   TcxCategoryRow *vgCategoryRow2;
   TcxEditorRow *vg_paVehicle1;
   TcxEditorRow *vg_paVehicleCostTdr;
   TcxEditorRow *vg_paVehicleStrSumma;
   TcxEditorRow *vg_paVehicleCost;
   TcxEditorRow *vg_paVehicle2;
   TStaticText *labHint;
   TcxEditRepositoryCurrencyItem *CurrencyItem;
   TcxEditRepositoryMemoItem *MemoItem;
   TcxEditorRow *vg_paPUSInfo;
   TcxEditorRow *vg_paPUS;
   TcxCategoryRow *vg_CalcSummaryInfoHead;
   TcxEditorRow *vg_paBaseTariff;
   TcxEditorRow *vg_paK1;
   TcxEditorRow *vg_paPremiumMain;
   TcxEditorRow *vg_paTT;
   TcxEditorRow *vg_paKfr;
   TcxEditorRow *vg_paKa;
   TcxEditorRow *vg_paKb;
   TcxEditorRow *vg_paKpr;
   TcxEditorRow *vg_paKpc;
   TcxEditorRow *vg_paKap;
   TcxEditorRow *vg_paKc;
   TcxEditorRow *vg_paKp;
   TcxEditorRow *vg_paK7A;
   TcxEditorRow *vg_paK6;
   TcxEditorRow *vg_paK5;
   TcxEditorRow *vg_paK4;
   TcxEditorRow *vg_paK3;
   TcxEditorRow *vg_paK2;
   TcxEditorRow *vg_paKd;
   TcxEditRepositoryButtonItem *ButtonItem;
   TcxEditRepositoryComboBoxItem *K4_ComboBoxItem;
   TcxEditRepositoryComboBoxItem *K7_ComboBoxItem;
   TcxEditorRow *vg_paObosnKa;
   TcxEditRepositoryComboBoxItem *Kc_ComboBoxItem;
   TcxEditRepositoryComboBoxItem *Ka_ComboBoxItem;
   TcxCategoryRow *vg_DopRisk;
   TcxCategoryRow *CalcTotal;
   TcxCategoryRow *vgCategoryRow3;
   TcxMultiEditorRow *vg_Permitted1;
   TcxEditRepositoryCheckBoxItem *CheckBoxItem;
   TcxMultiEditorRow *vg_Permitted2;
   TcxMultiEditorRow *vg_Permitted3;
   TcxMultiEditorRow *vg_Permitted4;
   TcxMultiEditorRow *vg_Permitted5;
   TcxMultiEditorRow *vg_Permitted6;
   TcxMultiEditorRow *vg_Permitted7;
   TcxMultiEditorRow *vg_Permitted16;
   TcxMultiEditorRow *vg_Permitted15;
   TcxMultiEditorRow *vg_Permitted14;
   TcxMultiEditorRow *vg_Permitted13;
   TcxMultiEditorRow *vg_Permitted12;
   TcxMultiEditorRow *vg_Permitted11;
   TcxMultiEditorRow *vg_Permitted10;
   TcxMultiEditorRow *vg_Permitted9;
   TcxMultiEditorRow *vg_Permitted8;
   TcxEditRepositoryRadioGroupItem *RadioGroupItem;
   TcxEditorRow *vg_dateQT;
   TcxEditorRow *vg_rgAgreed;
   TcxEditorRow *vg_editFIO_DEIIZB;
   TcxEditorRow *vg_paCommAnderr;
   TcxEditorRow *vg_paCommSale;
   TcxCategoryRow *vg_WhatChangeHead;
   TcxEditorRow *vg_paAnderrChange;
   TcxStyle *cxStyle4;
   TcxCategoryRow *labNonStandardDogovor_Down;
   TcxCategoryRow *labNonStandardDogovor_Up;
   TcxEditorRow *vg_rgNoAgreed;
   TcxStyle *cxStyle5;
   TTimer *ResizeTimer;
   void __fastcall vgDrawRowHeader(TObject *Sender, TcxCanvas *ACanvas, TcxvgPainter *APainter, TcxCustomRowHeaderInfo *AHeaderViewInfo, bool &Done);
   void __fastcall CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error);
   void __fastcall vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties);
   void __fastcall CurrencyItemPropertiesChange(TObject *Sender);
   void __fastcall ButtonItemPropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall K4_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall K7_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall Ka_ComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall CheckBoxItemPropertiesChange(TObject *Sender);
   void __fastcall DateItemPropertiesChange(TObject *Sender);
   void __fastcall DateItemPropertiesEditValueChanged(TObject *Sender);
   void __fastcall ResizeTimerTimer(TObject *Sender);
   void __fastcall DateItemPropertiesValidate(TObject *Sender,
          Variant &DisplayValue, TCaption &ErrorText, bool &Error);
private:	// User declarations
   mops_api_028 *m_api;
   int res;
   double b_kv;
   TDateTime date_qt;
   AnsiString row_old_str_summa_name, row_old_premium_name;

   _di_IXMLDocument XMLDoc;
   _di_IXMLNode Root;

   PersonInfo *pi, *pm;
   //TSInfo *tsi;
   VehicleInfo *tsi;
   Dogovor_Info *di;

   TfrmViewHistory *frmVH;
public:
   TFrameNew *f_calc;
   TFReissCalc *f_reiss;
public:		// User declarations
   //__fastcall TAnderrFrame(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, TSInfo *p_tsi, Dogovor_Info *p_di);
   __fastcall TAnderrFrame(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, VehicleInfo *p_tsi, Dogovor_Info *p_di);
   __fastcall ~TAnderrFrame() { delete frmVH;};
   void SaveFrame(TADOQuery *q);
   void LoadFrame(TADOQuery *q);
   void Calc();
   void SetName_OSS(const AnsiString& v){ row_old_str_summa_name = v; }
   void SetName_OPR(const AnsiString& v){ row_old_premium_name = v; }
};
//---------------------------------------------------------------------------
extern PACKAGE TAnderrFrame *AnderrFrame;
//---------------------------------------------------------------------------
#endif
