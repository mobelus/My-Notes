//---------------------------------------------------------------------------

#ifndef UPaymentH
#define UPaymentH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cxButtons.hpp"
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include <Menus.hpp>

//#include "tools.h"
#include "structures.h"

//---------------------------------------------------------------------------
class TFReissCalc;
class TfrmPayment : public TForm{
__published:	// IDE-managed Components
   TcxVerticalGrid *vg;
   TcxEditorRow *vg_PaymentSum;
   TcxButton *btnOK;
   TcxButton *btnCancel;
   TcxEditRepository *cxEditRepository1;
   TcxEditRepositoryCurrencyItem *CurrencyItem;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *cxStyle3;
   TcxStyle *cxStyle4;
   TcxEditorRow *vg_PaymentDate;
   TcxEditRepositoryDateItem *DateItem;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall btnOKClick(TObject *Sender);
   void __fastcall btnCancelClick(TObject *Sender);
   void __fastcall CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error);
   void __fastcall DateItemPropertiesEditValueChanged(TObject *Sender);
private:	// User declarations
   Dogovor_Info *di;
   double payment_sum;
   TDateTime payment_date;
   TFReissCalc *f_reiss;
   TcxEditorRow *btn_row;
public:		// User declarations
   __fastcall TfrmPayment(TComponent* Owner, Dogovor_Info *p_di);
   void SetCurrBtnRow(TcxEditorRow *r){ btn_row = r; }
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmPayment *frmPayment;
//---------------------------------------------------------------------------
#endif
