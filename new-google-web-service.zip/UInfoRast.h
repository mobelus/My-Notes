//---------------------------------------------------------------------------

#ifndef UInfoRastH
#define UInfoRastH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>

#include "acPNG.hpp"
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
//---------------------------------------------------------------------------
class TfrmInfoRast : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TImage *Image1;
   TcxButton *btnOK;
private:	// User declarations
public:		// User declarations
   __fastcall TfrmInfoRast(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInfoRast *frmInfoRast;
//---------------------------------------------------------------------------
#endif
