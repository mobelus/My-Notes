//---------------------------------------------------------------------------

#ifndef UInfoBSOH
#define UInfoBSOH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmInfoCheck : public TForm
{
__published:	// IDE-managed Components
   TPanel *Panel1;
private:	// User declarations
public:		// User declarations
   __fastcall TfrmInfoCheck(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInfoCheck *frmInfoCheck;
//---------------------------------------------------------------------------
#endif
