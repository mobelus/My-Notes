//---------------------------------------------------------------------------
#ifndef offerscustH
#define offerscustH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "frxClass.hpp"
#include "frxPreview.hpp"
#include "Tmops_api.h"
#include "frxDBSet.hpp"
#include <DB.hpp>
#include <DBClient.hpp>
#include "frxExportPDF.hpp"
#include <Dialogs.hpp>
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TframeOffCust : public TFrame
{
__published:	// IDE-managed Components
   TfrxPreview *frxPreview1;
   TfrxReport *frxForClient;
   TLabel *labInfo;
   TPanel *printPanel;
   TfrxPDFExport *PDFExport;
   TSaveDialog *sdPDF;
   TcxButton *btnPrint;
   TcxButton *btnExport;
   void __fastcall printButtonClick(TObject *Sender);
   void __fastcall btnExportClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TframeOffCust(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TframeOffCust *frameOffCust;
//---------------------------------------------------------------------------
#endif
