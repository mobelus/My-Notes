//---------------------------------------------------------------------------
#ifndef oldcalcH
#define oldcalcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "sBitBtn.hpp"
#include "sCheckBox.hpp"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include "frxClass.hpp"
#include "frxDesgn.hpp"
#include "Transdekra_funcs.h"
//#include "tools.h"
#include <Dialogs.hpp>
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include "cxCustomData.hpp"
#include "cxTextEdit.hpp"
#include "cxTL.hpp"
#include "cxDropDownEdit.hpp"
#include "cxDBEditRepository.hpp"
#include <DB.hpp>
#include <set>
#include <memory>

#define DEFAULT_CITY 77

class TFrameNew;
//---------------------------------------------------------------------------
class TFramePreCalc : public TFrame{
__published:	// IDE-managed Components
   TLabel *labNonStandardDogovor_Up;
   TdxInspector *CalcInfo;
   TdxInspectorTextRow *GeneralInfoHead;
   TdxInspectorTextPickRow *cboxSource;
   TdxInspectorTextPickRow *cboxBank;
   TdxInspectorTextMemoRow *MemoBank;
   TdxInspectorTextPickRow *cboxFullInsur;
   TdxInspectorTextPickRow *cboxRegion;
   TdxInspectorTextRow *VehicleHead;
   TdxInspectorTextPickRow *cboxTSType;
   TdxInspectorTextPickRow *rgStatus;
   TdxInspectorTextPickRow *cboxTSMarka;
   TdxInspectorTextPickRow *cboxTSModel;
   TdxInspectorTextPickRow *editTSYear;
   TdxInspectorTextDateRow *datePTS;
   TdxInspectorTextRow *PUSHead;
   TdxInspectorTextMemoRow *memoProtivougonki;
   TdxInspectorTextRow *TdrHead;
   TdxInspectorTextPickRow *Param1;
   TdxInspectorTextPickRow *Param2;
   TdxInspectorTextPickRow *Param3;
   TdxInspectorTextPickRow *Param4;
   TdxInspectorTextPickRow *Param5;
   TdxInspectorTextCurrencyRow *editTSRealCost;
   TdxInspectorTextCurrencyRow *editStrSumma;
   TdxInspectorTextRow *labCoefProp;
   TdxInspectorTextRow *DriversHead;
   TdxInspectorTextPickRow *cboxMultidrive;
   TsBitBtn *btnDopushPlus;
   TsBitBtn *btnDopushMinus;
   TsBitBtn *btnDopushEdit;
   TsCheckBox *chkFrInsteadK1;
   TListView *gridDopush;
   TdxInspector *TermsInfo;
   TdxInspectorTextRow *TermsHead;
   TdxInspectorTextPickRow *rgMainRisk;
   TdxInspectorTextPickRow *cboxVariant;
   TdxInspectorTextPickRow *cboxVozmType;
   TdxInspectorTextPickRow *cboxSrok;
   TdxInspectorTextPickRow *cboxCredit;
   TdxInspectorTextPickRow *cboxTypeFranshiza;
   TdxInspectorTextPickRow *cboxFranshiza;
   TdxInspectorTextPickRow *cboxProgramms;
   TdxInspectorTextPickRow *cboxDogovorType;
   TdxInspectorTextPickRow *cbox_K5_K6;
   TdxInspector *TotalInfo;
   TdxInspectorTextRow *labPremiaMain;
   TLabel *labNonStandardDogovor_Down;
   TStaticText *labHint;
   TdxInspectorTextCurrencyRow *editMaxMassa;
   TdxInspectorTextCurrencyRow *editSeatCount;
   TLabel *gridHead;
   TcxVerticalGrid *vg;
   TcxEditRepository *cxEditRepository1;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *styleSelection;
   TcxEditRepositoryPopupItem *PopupItem;
   TcxStyle *styleHotTrack;
   TcxTreeList *cxTreeList1;
   TcxTreeListColumn *colText1;
   TcxEditorRow *PopupEditorRow;
   TcxCategoryRow *vgCategoryRow1;
   TcxEditorRow *vgEditorRow1;
   TcxEditorRow *vgEditorRow2;
   TcxEditorRow *vgEditorRow4;
   TcxEditorRow *vgEditorRow3;
   TcxEditorRow *vgEditorRow5;
   TcxEditorRow *vgEditorRow6;
   TcxCategoryRow *vgCategoryRow2;
   TcxEditorRow *vgEditorRow7;
   TcxEditorRow *vgEditorRow8;
   TcxEditorRow *vgEditorRow9;
   TcxEditorRow *vgEditorRow10;
   TcxEditorRow *vgEditorRow11;
   TcxEditorRow *vgEditorRow12;
   TcxEditorRow *vgEditorRow13;
   TcxEditorRow *vgEditorRow14;
   TcxEditorRow *vgEditorRow15;
   TcxEditorRow *vgEditorRow16;
   TcxEditorRow *vgEditorRow17;
   TcxCategoryRow *vgCategoryRow3;
   TcxEditorRow *vgEditorRow18;
   TcxCategoryRow *vgCategoryRow4;
   TcxEditRepositoryLookupComboBoxItem *RegionComboBoxItem;
   TDataSource *ds_regions;
   TdxInspectorTextPickRow *cboxTSCount;
   void __fastcall ControlChange(TObject *Sender);
   void __fastcall btnDopushPlusClick(TObject *Sender);
   void __fastcall btnDopushMinusClick(TObject *Sender);
   void __fastcall btnDopushEditClick(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall cboxRegionCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall CalcInfoEditChange(TObject *Sender);
   void __fastcall Param1CloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall CalcInfoEdited(TObject *Sender, TdxInspectorNode *Node, TdxInspectorRow *Row);
   void __fastcall GeneralInfoHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall TermsHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall CalcInfoDrawValue(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall CalcInfoKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall TermsInfoKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall cxTreeList1MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
   void __fastcall cxTreeList1Click(TObject *Sender);
   void __fastcall cxTreeList1HotTrackNode(TObject *Sender, TcxTreeListNode *ANode, TShiftState AShift, TCursor &ACursor);
   void __fastcall PopupItemPropertiesInitPopup(TObject *Sender);
   void __fastcall RegionComboBoxItemPropertiesEditValueChanged(TObject *Sender);
private:	// User declarations
   mops_api_028 *m_api;
   Transdekra tdr;
   TADOQuery *q, *min_rate, *srok, *franshize, *region_bl, *dict_kb, *q_regions;
   TStringList *curr_rg_pl, *error;
   TcxTreeListNode *AOldHitNode;
   TcxPopupEdit *popup_edit;
   std::set<int> coeff_base, kv_enabled, prg_comfort, s_regnum;
   std::map<AnsiString, double> base_kv;
   std::map<int, double> min_premium_ekonom;
   std::vector<double> coeff_kd;

   PersonInfo *pi, *pm;
   TSInfo *tsi;
   Dogovor_Info *di;

   AnsiString last_err, curr_error, sql, risk_code[3], name_prod, last_str, params[5], anderr_fio, GROUP_TS_STR;
   AnsiString row_kpr_name;
   TDateTime payment_date[3], date_pts;
   int BS, FRANSHIZA, contract_type, status_dogovor;
   int res, group_ts, model_id, risk, region_id, region_isp_id, curr_year, ts_age_min, ts_age_max, code_prod, age_min, drv_exp_min, count_permit_after_load, type_multydrive, programm_id;
   bool in_event, is_trans, nf_bt, bank_multidrive, is_risk_ts, is_bl, enable_k1f, this_frame;
   double k1, kd, k5, k6, kar, osn_risk_itog_tarif, premiya_osn_risk, premiya_all, curr_limit;
private:
   void LoadRegions();
   void LoadTSMarkaList();
   void LoadTSModelList();
   void LoadVozmTypeList();
   void LoadRegionData();
   int ProductID();
   bool CheckCost(const double& val);
   void CalcPremium();
   void CalcPremiumOsnRisk();
   void Error(const AnsiString& text, const int unique, bool term, int warning = 0, const AnsiString& type_error = err_calc);
   double K1(const int tertype_id, const int age, const int stag);
   double K1Final(bool recalc = false);
   void GetApplyingKoeffs();
   void GetGroupTS();
   double Round(const double& val){ return m_api->Round(val); }
   void Calc_bt();
   void Calc_kar();
   void Calc_k3();
   void Calc_k7();
   void Calc_Kb();
   void Protivougon();
   void CalcAll(bool is_kr = true, bool is_k7 = true, bool is_protivougon = true);
   void GetRangeAge();
   void ChangeMultiDrive();
   void LoadData();
   void ChangeSource();
   void ChangeBank();
   void GetRiskCode(const int index, const int risk_id, const int prod_id);
   void cboxSrokChange();
   void ChangeListProject(const int pid);
   void ChangeFranshizeBox(TObject *Sender = 0);
   void IsPorsche27RF();
   double GetKprSb(const double& val);
   void DisableGBP();
   void DisableGBTS();
   void ChangeListFullInsur();
   void ChangeListCredits();
   void ChangeList_K5_K6();
   int GetDrvCount(TADOQuery *qq);
   double GetMinRate();
   void DisableAllControls();
   bool IsCar(){ return (group_ts < 4 || group_ts == 6 || group_ts == 7); }
   void RecalcCostTdr(bool all = true);
   void ResetTransdekra();
   void ResetTdrValues(const int index = 0);
   void ResetAllSumms();
   AnsiString GetParams();
   void SetParams(const AnsiString&);
   void SetFrInsteadK1(const double&);
   void SetStatePermitted();
   void SetRowKpr(const double& k_min, const double& k_max, const AnsiString& coeff = "");
   void ResetGridPermitted();
   void ShowGridOrChkPermitted(const int who);
   void ChangeControlOnAnotherFrame(TObject *Sender);
   TRect GetNodeRect(TcxTreeListNode *ANode);
   AnsiString __fastcall GetTSCountryFlag(AnsiString ts_marka, AnsiString ts_model);
public:
   TMemo *memo;
   TStringList *non_standart_str;
   TFrameNew *f_calc;
public:		// User declarations
   __fastcall TFramePreCalc(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, TSInfo *p_tsi, Dogovor_Info *p_di);
   __fastcall ~TFramePreCalc();
   void Init();
   void Calc(TObject* Sender = 0);
   void SaveFrame(TADOQuery *q);
   void LoadFrame(TADOQuery *q);
   void ChangeOrderPayments();
   bool GetCoeffEnabled(const int id_coeff){ return coeff_base.count(id_coeff); }
   bool IsNonStandartPolis();
   void RecalcOnTheDate(const TDateTime& dt);
   void SetFalseThisFrame() { this_frame = false; }
   void InvalidateAll(){ CalcInfo->Invalidate(); TermsInfo->Invalidate(); }
};
//---------------------------------------------------------------------------
extern PACKAGE TFramePreCalc *FramePreCalc;
//---------------------------------------------------------------------------
#endif
