//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UPayment1.h"
#include "MainWinFC.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma resource "*.dfm"
TfrmPayment1 *frmPayment1;
//---------------------------------------------------------------------------
__fastcall TfrmPayment1::TfrmPayment1(TComponent* Owner, Dogovor_Info *p_di) : TForm(Owner), f_print((TFrame1*)Owner), di(p_di)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment1::FormShow(TObject *Sender)
{
   vg_PaymentSum->Properties->Value = payment_sum = di->calc_info.payment1;
   if(di->payment_date[0].Val) vg_PaymentDate->Properties->Value = payment_date = di->payment_date[0];
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment1::btnOKClick(TObject *Sender)
{
   if(payment_sum && payment_sum < di->calc_info.premiya_osn_risk){ di->calc_info.payment1 = payment_sum; f_print->RecalcPayments(); }
   else di->calc_info.payment1 = 0;
   Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment1::btnCancelClick(TObject *Sender)
{
   Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmPayment1::CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   Error = false;
   payment_sum = StrToFloatStr(DisplayValue).ToDouble();
   DisplayValue = payment_sum;
}
//---------------------------------------------------------------------------
