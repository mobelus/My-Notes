//---------------------------------------------------------------------------

#ifndef UThreadK5H
#define UThreadK5H
//---------------------------------------------------------------------------
#include <Classes.hpp>

//#include "tools.h"

//---------------------------------------------------------------------------
class Thread_APO2_ARM_READER : public TThread
{
private:
   AnsiString xml_text_in, *xml_text_out, soap_server_address;
   int type_function;
protected:
   void __fastcall Execute();
public:
   __fastcall Thread_APO2_ARM_READER(bool CreateSuspended, const int tf, const AnsiString& ssa, const AnsiString& xml_in, AnsiString *xml_out);
};
//---------------------------------------------------------------------------
#endif
