//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UInfoRast.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "acPNG"
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma resource "*.dfm"
TfrmInfoRast *frmInfoRast;
//---------------------------------------------------------------------------
__fastcall TfrmInfoRast::TfrmInfoRast(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
