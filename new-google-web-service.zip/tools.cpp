#include "tools.h"
#include <DateUtils.hpp>
#include "IAPO2_ARM_READER.h"
//---------------------------------------------------------------------------
AnsiString S(const double& x)
{
   AnsiString t, result;
   result = t.sprintf("%.4f", x);
   int len = result.Length();

   if(result[len] == '0'){
      if(result[len - 1] == '0') result = result.Delete(len - 1, 2);
      else                       result = result.Delete(len, 1);
   }

   return result;
}
//---------------------------------------------------------------------------
AnsiString FormatDigits(const double& x)
{
   AnsiString result = FormatFloat(",0.00;-,0.00", x);
   int len = result.Length();
   if(result[len - 1] == '0' && result[len] == '0') result = result.SubString(1, len - 3);

   return result;
}
//---------------------------------------------------------------------------
AnsiString FloatToSQLStr(const double& f)
{
   return StringReplace(FloatToStr(f), ",", ".", rf);
}
//---------------------------------------------------------------------------
void FloatToRubAndKopeik(const double& x, AnsiString& rub, AnsiString& kopeik)
{
   AnsiString result = StringReplace(FormatFloat(",0.00;-,0.00", x), ",", ".", rf);
   int pos_t = result.Pos(".");
   rub = result.SubString(1, pos_t - 1);
   kopeik = result.SubString(pos_t + 1, 2);
}
//---------------------------------------------------------------------------
AnsiString FloatToSQLStr(AnsiString s)
{
   if(s.IsEmpty()) return null_str;
   s = StringReplace(s, space_str, empty_str, rf);
   return StringReplace(s, ",", ".", rf);
}
//---------------------------------------------------------------------------
AnsiString StrToFloatStr(const AnsiString& s, const AnsiString& def)
{
   if(s.IsEmpty()) return def;
   
   AnsiString result = s;
   char c = DecimalSeparator;

   result = StringReplace(result, space_str, empty_str, rf);
   result = StringReplace(result, space_str_nonbreak, empty_str, rf);
   result = StringReplace(result, space_str_long, empty_str, rf);
   result = StringReplace(result, "�.", empty_str, rf);
   result = StringReplace(result, "�,", empty_str, rf);

   if(result.AnsiPos(".")){
      if(c != '.'){
         result = StringReplace(result, ".", ",", rf);
      }
   }
   else if(result.AnsiPos(",")){
      if(c != ','){
         result = StringReplace(result, ",", ".", rf);
      }
   }

   double d;
   if(!TryStrToFloat(result, d)) return def;

   return result;
}
//---------------------------------------------------------------------------
AnsiString FloatToIntStr(const double& f)
{
   AnsiString s = FloatToSQLStr(f);
   int pos = s.Pos(".");
   if(pos > 0) return s.Delete(pos, s.Length() - pos + 1);
   else return s;
}
//---------------------------------------------------------------------------
int CalcYears(const TDateTime& dt1, const TDateTime& dt2)
{
   if(!dt1.Val || !dt2.Val) return 0;

   int y1 = YearOf(dt1),  y2 = YearOf(dt2);
   int m1 = MonthOf(dt1), m2 = MonthOf(dt2);
   int d1 = DayOf(dt1),   d2 = DayOf(dt2);
   int ydif = y2 - y1;
   if(m2 < m1 || (m1 == m2 && d2 < d1)) ydif--;

   return ydif;
}
//---------------------------------------------------------------------------
void ResetChk(TCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void ResetSChk(TsCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void SetValueCheckBox(TsCheckBox* chk, const int v, ptr_onclick onclick)
{
   chk->OnClick = 0;
   chk->Checked = v ? true : false;
   chk->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueCalcEdit(TsCalcEdit* cedit, const double& val, ptr_onchange onchange)
{
   cedit->OnChange = 0;
   cedit->Value = val;
   cedit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange)
{
   dedit->OnChange = 0;
   if(dt.Val) dedit->Date = dt;
   dedit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TdxInspectorTextDateRow *dedit, const TDateTime& val)
{
   if(val.Val) dedit->EditText = val.DateString();
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TcxEditorRow *dedit, const TDateTime& val)
{
   if(val.Val) dedit->Properties->Value = val;
   else dedit->Properties->Value = variant_null;
}
//---------------------------------------------------------------------------
int GetIndexObject(TStrings* lst, const int& val)
{
   for(int i = 0, cnt = lst->Count; i < cnt; ++i)
      if(((DataDict*)lst->Objects[i])->id == val) return i;

   return -1;
}
//---------------------------------------------------------------------------
int GetIndexItemByTag(TcxRadioGroupItems* items, const int t)
{
   for(int i = 0, cnt = items->Count; i < cnt; ++i)
      if(items->Items[i]->Tag == t) return i;

   return -1;
}
//---------------------------------------------------------------------------
TDateTime CalcEndDateInsur(const TDateTime& start_date, const int srok_month)
{
   Word Year, Month, Day;
   DecodeDate(start_date, Year, Month, Day);
   IncAMonth(Year, Month, Day, srok_month);
   TDateTime dt = EncodeDate(Year, Month, Day);

   return IncDay(dt, -1);
}
//---------------------------------------------------------------------------
AnsiString FirstUpper(const AnsiString& str)
{
   if(str.IsEmpty()) return empty_str;

   AnsiString f_up = AnsiString(str[1]).UpperCase();
   return f_up + str.SubString(2, str.Length() - 1).LowerCase();
}
//---------------------------------------------------------------------------
AnsiString AddNulls(const AnsiString& str)
{
   AnsiString result = str;
   int len = str.Length();

   if(len < 9) for(int i = 0, end = 9 - len; i < end; ++i) result = null_str + result;

   return result;
}
//---------------------------------------------------------------------------
AnsiString ClearPhoneNumber(const AnsiString& str)
{
   AnsiString result(""), curr("");
   int i_val;

   for(int i = 1, l = str.Length(); i <= l; ++i){
      curr = AnsiString(str[i]);
      if(TryStrToInt(curr, i_val)) result += curr;
   }

   return result;
}
//---------------------------------------------------------------------------
void FilterDataSet(TADOQuery *qq, const AnsiString& filter)
{
   qq->Filtered = false;
   qq->Filter   = filter;
   qq->Filtered = true;
}
//---------------------------------------------------------------------------
bool TryStrToDate_my(const AnsiString& str, TDateTime& dt)
{
   AnsiString str_after = StringReplace(StringReplace(StringReplace(str, underline_str, empty_str, rf), space_str, empty_str, rf), ".", AnsiString(DateSeparator), rf); 
   if(str_after.Length() < 10) return false;
   else return TryStrToDate(str_after, dt);
}
//---------------------------------------------------------------------------
void SetHeightInspector1(TCustomdxInspectorControl *inspector)
{
   int h(0);
   for(int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i)
      if(inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node)) h += inspector->Rows[i]->RowHeight;
   inspector->Height = h;
}
//---------------------------------------------------------------------------
void SetHeightInspector2(TCustomdxInspectorControl *inspector)
{
   int h(0);
   for(int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i) h += inspector->Rows[i]->RowHeight;
   inspector->Height = h;
}
//---------------------------------------------------------------------------
void SetHeightInspector_1(TdxInspector *inspector)
{
   int h(0);

   for(int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i)
      if((inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node)) || inspector->RowInComplexRow(inspector->Rows[i])) h += inspector->Rows[i]->RowHeight;
   inspector->Height = h;
}
//---------------------------------------------------------------------------
void SetHeightInspector_2(TdxInspector *inspector)
{
   int h(0);
   for(int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i) h += inspector->Rows[i]->RowHeight;
   inspector->Height = h;
}
//---------------------------------------------------------------------------
int GetToplabHint_1(TdxInspector *inspector)
{
   if(!inspector->FocusedNode) return -100;

   int t(0), a_i = inspector->FocusedNode->AbsoluteIndex;

   for(int i = 0, cnt = inspector->VisibleTotalRowCount; i < cnt; ++i){
      if(inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node) && inspector->Rows[i]->Node->AbsoluteIndex < a_i) t += inspector->Rows[i]->RowHeight;
   }

   return inspector->Top + t + 3;
}
//---------------------------------------------------------------------------
int GetToplabHint_2(TdxInspector *inspector)
{
   if(!inspector->FocusedNode) return -100;

   int t(0), a_i = inspector->FocusedNode->AbsoluteIndex;
   for(int i = 0; i < a_i; ++i) t += inspector->Rows[i]->RowHeight;

   return inspector->Top + t + 2;
}
//---------------------------------------------------------------------------
int GetToplabHint(TCustomdxInspectorControl *inspector)
{
   if(!inspector->FocusedNode) return -100;
   int t(0), a_i = inspector->FocusedNode->AbsoluteIndex, i(0), cnt = inspector->VisibleTotalRowCount;
   switch(inspector->Tag){
      case 0:
         for(int i = 0; i < a_i; ++i) t += inspector->Rows[i]->RowHeight;
         break;
      case 1:
         for(i = 0; i < cnt; ++i){
            if(inspector->Rows[i]->Node && inspector->IsNodeVisible(inspector->Rows[i]->Node) && inspector->Rows[i]->Node->AbsoluteIndex < a_i) t += inspector->Rows[i]->RowHeight;
         }
         break;
   }

   return inspector->Top + t + 2 + inspector->Tag;
}
//---------------------------------------------------------------------------
bool CheckVIN(const AnsiString& vin) // http://www.vinfax.ru/about.html
{
   if(vin.Length() != 17) return false;
   int i_val;
   //if(!TryStrToInt(vin.SubString(14, 4), i_val)) return false;

   for(int i = 1; i < 18; i++){
      if(!((vin[i] >= '0' && vin[i] <= '9') || (vin[i] >= 'A' && vin[i] <= 'Z'))) return false;
      if(vin[i] == 'I' || vin[i] == 'O' || vin[i] == 'Q')                         return false;
   }

   return true;
}
//---------------------------------------------------------------------------
bool CheckRegPlate(const AnsiString& rgpl)
{
   if(rgpl.Length() < 8) return false;

   for(int i = 1; i < 7; i++) if(reg_plate_possible.AnsiPos(rgpl.SubString(i, 1)) == 0) return false;

   return true;
}
//---------------------------------------------------------------------------
AnsiString NodeToStr(_di_IXMLNode node)
{
   if(node) return AnsiString(node->Text);
   return empty_str;
}
//---------------------------------------------------------------------------
AnsiString NodeAttributeToStr(_di_IXMLNode node, const AnsiString& name, const AnsiString& value)
{
   if(node->HasAttribute(name)) return AnsiString(node->Attributes[value]);
   return empty_str;
}
//---------------------------------------------------------------------------
AnsiString NormVIN_GN(mops_api_025 *m_api, const AnsiString& numb)
{
   int res;
   AnsiString st = m_api->Normalization_String_RSA(res, numb), st_eng("ETYOPKHAXCBM"), st_rus("������������");

   for(int i = 1, l = st_rus.Length() + 1; i < l; i++) st = StringReplace(st, st_rus[i], st_eng[i], rf);

   return st;
}
//---------------------------------------------------------------------------
void SeparateFIO(const AnsiString& fio, const int status, AnsiString& lname, AnsiString& fname, AnsiString& sname)
{
   lname = fname = sname = empty_str;
   if(status > 0) { lname = fio; return; }

   int pos(0);
   pos = fio.Pos(space_str);
   if(pos){
      lname = fio.SubString(1, pos).Trim();
      AnsiString temp_str = fio.Delete(1, pos);
      pos = temp_str.Pos(space_str);
      if(pos){
         fname = temp_str.SubString(1, pos).Trim();
         sname = temp_str.Delete(1, pos).Trim();
      }
      else fname = temp_str.Delete(1, pos).Trim();
   }
}
//---------------------------------------------------------------------------
void MakeKladrAddrFromARM(mops_api_028 *_m_api, _di_IXMLNode child_node, TStringList *addr, int& memo_id)
{
   int res;

   addr->Clear();
   memo_id = 0;
   AnsiString code_kladr = NodeToStr(child_node->ChildNodes->FindNode("KLADR_STREET_CODE"));
   if(code_kladr.IsEmpty()) return;

   addr->Values["��� �����"] = code_kladr;
   addr->Values["������"] = NodeToStr(child_node->ChildNodes->FindNode("ZIP"));
   addr->Values["���"] = NodeToStr(child_node->ChildNodes->FindNode("HOUSE_NUMBER"));
   addr->Values["������/��������"] = "�";
   addr->Values["����� �������"] = NodeToStr(child_node->ChildNodes->FindNode("BUILDING"));
   addr->Values["��������"] = NodeToStr(child_node->ChildNodes->FindNode("FLAT"));

   _m_api->KLADR_Try_Address_to_KLADR(res, addr);

   AnsiString memo_text = addr->Text;
   _m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "casco_memo");
}
//---------------------------------------------------------------------------
void MakeKladrAddrFromUXML(mops_api_028 *_m_api, _di_IXMLNode person, TStringList *addr, int& memo_id, AnsiString& exact_address)
{
   int res;

   AnsiString code_kladr = NodeToStr(person->ChildNodes->FindNode("street_id"));
   if(code_kladr.IsEmpty()){
      code_kladr = NodeToStr(person->ChildNodes->FindNode("region_id"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("exact_address"));
      if(code_kladr.IsEmpty()) return;
      addr->Values["������"] = NodeToStr(person->ChildNodes->FindNode("region"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("area"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("place"));
   }

   addr->Values["��� �����"] = code_kladr;

   addr->Values["������"] = NodeToStr(person->ChildNodes->FindNode("zip"));
   addr->Values["���"] = NodeToStr(person->ChildNodes->FindNode("house"));
   addr->Values["������/��������"] = "�";
   addr->Values["����� �������"] = NodeToStr(person->ChildNodes->FindNode("building"));
   addr->Values["��������"] = NodeToStr(person->ChildNodes->FindNode("flat"));

   _m_api->KLADR_Try_Address_to_KLADR(res, addr);

   AnsiString memo_text = addr->Text;
   _m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "casco_memo");

   exact_address = _m_api->KLADR_Get_Print_Address_By_Separated(res, addr);
}
//---------------------------------------------------------------------------
bool CheckAddrList(TStringList* addrlist)
{
   if(addrlist->Text.IsEmpty()) return false;

   if(addrlist->Count == 1 && addrlist->IndexOfName("������") > -1) return false;

   return true;
}
//---------------------------------------------------------------------------
SkkQuery::SkkQuery()
{
   insert(std::make_pair("4.1.4",  TblQue("select * from apo.subject_rf", "cascorefsubjectrf", false)));
   insert(std::make_pair("5.1.1",  TblQue("select code,full_name,short_name,note,'' as obobch_cod from rgsscc.ref_carrier_type where sysdate<date_to", "ts_type", false)));
   insert(std::make_pair("5.1.3",  TblQue("select * from apo.carrier_models", "gl_dict_carrier_models", false)));
   insert(std::make_pair("5.4.15", TblQue("", "", false)));
   insert(std::make_pair("7.1.39", TblQue("select distinct t1.inn, t1.name_inn,t2.partner_type,decode(length(t1.inn), 10, '��', decode(length(t1.inn), 12, '��','��� �� 10 � �� 12 ������')) as status, 1 as skk, nvl(t6.subject_federation_code,'0')"
                                          " from rgsscc.ref_dict_le_inn_level1 t1"
                                          " left join rgsscc.ref_dict_partner_type1 t2 on (t1.partner_type_fk=t2.id and t2.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_dict_le_kpp_level1 t3 on (t1.id=t3.inn_fk and t3.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_dict_le_agent_contr1 t4 on (t3.id=t4.partner_id_fk  and t4.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_dict_le_branch_net1 t5 on (t4.id=t5.region_contract_fk  and t5.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_subject_rf t6 on (t5.region_number_fk=t6.id and t6.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and t6.active_entry='Y')"
                                          " where t1.date_to=to_date('01.01.3000', 'dd.mm.yyyy')", "gl_dict_7_1_39", false)));
   insert(std::make_pair("7.1.17", TblQue("select asl.auto_sum_limit_id,terr.casco_territory_id,br.branch_code,prod.product_id,asl.filial_sum_limit,asl.branch_sum_limit,asl.start_date,asl.end_date from rgsscc.ref_auto_sum_limit asl left join rgsscc.ref_autodictcascoterritory terr on asl.to_728_fk=terr.id and terr.active_entry='Y' and terr.date_to=to_date('01.01.3000', 'dd.mm.yyyy') left join rgsscc.ref_product prod on asl.to_732_fk=prod.id and prod.date_to=to_date('01.01.3000', 'dd.mm.yyyy')  left join rgsscc.ref_branches br on asl.to_424_fk=br.id and br.date_to=to_date('01.01.3000', 'dd.mm.yyyy') where asl.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and prod.product_id in(301,302,303,304,305,306,307,308,311) order by to_number(asl.auto_sum_limit_id)", "gl_dict_limit_branches", false)));
   insert(std::make_pair("7.1.57", TblQue("select t1.add_sum_kss_id,nvl(t2.code,0) as model_id,t1.vehicle_age,t1.add_sum_kss,t1.sum_limit,t1.premium_limit,t1.start_date,t1.end_date from rgsscc.ref_add_sum_kss t1 left join apo.carrier_models t2 on (t1.to_513_fk=t2.id and t2.active_entry='Y') where t1.date_to=to_date('01.01.3000', 'dd.mm.yyyy')", "cascodictkss", false)));
   insert(std::make_pair("7.2.8",  TblQue("select casco_territory_id,casco_territory_name,NVL(reg_id,0),'' as start_date, '01.01.3000' as end_date from rgsscc.ref_autodictcascoterritory where active_entry='Y' and sysdate<date_to", "gl_dict_regions", false)));
   insert(std::make_pair("7.2.9",  TblQue("select vehicle_group_id,vehicle_group_name from rgsscc.ref_autodictvehiclegroup where sysdate<date_to", "tar_gr", false)));
   insert(std::make_pair("7.2.19", TblQue("select t1.id_krs,t1.credit_name,t1.payment_count_min,t1.payment_count_max,t1.credit_month_min,t1.credit_month_max,t1.credit_type,t1.link_to_7_3_63_fk,t1.coeff_value,t1.start_date,t1.end_date,t2.product_id from rgsscc.ref_autodictcascok8 t1 left join rgsscc.ref_product t2 on t1.product_id_lnk_fk=t2.id and t2.date_to=to_date('01.01.3000', 'dd.mm.yyyy') where t1.date_to=to_date('01.01.3000', 'dd.mm.yyyy')", "cascodictk08", false)));
   insert(std::make_pair("7.2.26", TblQue("select t1.id_26,t1.vehicle_group_id_fk,t1.carrier_type_code_fk,t2.code,NVL(t1.bus_seats_quantity_min,0),NVL(t1.bus_seats_quantity_max,0),NVL(t1.truck_allowed_mass_min,0),NVL(t1.truck_allowed_mass_max,0),t1.start_date,NVL(t1.end_date,'01.01.3000') from rgsscc.ref_autodictcascovg t1 left join rgsscc.ref_carrier_models t2 on (t1.tabl_5_1_3_fk=t2.id  and t2.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and t2.active_entry='Y') where t1.date_to=to_date('01.01.3000', 'dd.mm.yyyy')", "gl_dict_model_po_gruppam", false)));
   insert(std::make_pair("7.2.37", TblQue("select t3.coefficient_id,t2.tariff_id,t1.start_date,t1.end_date from rgsscc.ref_tariffcoeff t1 left join rgsscc.ref_dictcoefficient t3 on t1.coeff_id_fk=t3.id left join rgsscc.ref_dicttariff t2 on t1.tariff_id_fk=t2.id where sysdate<t1.date_to and sysdate<t2.date_to and sysdate<t3.date_to","cascotariffcoeff", false)));
   insert(std::make_pair("7.2.43", TblQue("", "", false)));
   insert(std::make_pair("7.3.21", TblQue("select payment_method_id,payment_method_name,sort_order from rgsscc.ref_autodictpaymentmethod where sysdate<date_to", "cascopayment", false)));
   insert(std::make_pair("7.3.50", TblQue("select k1_id,rf_7_3_63_fk,cast(NVL(driving_experience_min,0) as int),NVL(driving_experience_max,0),NVL(age_min,0),NVL(age_max,0),coeff_value,start_date,NVL(end_date,'01.01.3000') from rgsscc.ref_cascodictk01 where sysdate<date_to and nvl(to_732_fk,0)=0","cascodictk01", false)));
   insert(std::make_pair("7.3.51", TblQue("select k2_id,vehicle_count_min,vehicle_count_max,coeff_value,start_date,NVL(end_date,'01.01.3000') from rgsscc.ref_cascodictk02 where sysdate<date_to", "cascodictk02", false)));
   insert(std::make_pair("7.3.52", TblQue("select k3_id,term_of_insurance_min,term_of_insurance_max,coeff_value,start_date,NVL(end_date,'01.01.3000') from rgsscc.ref_cascodictk03 where sysdate<date_to", "cascodictk03", false)));
   insert(std::make_pair("7.3.53", TblQue("select fr.k4_id,fr.code_t_fr_lnk_fk,tfr.code_t_fr,tfr.name_t_fr,eifr.code_ed_izm_fr,eifr.name_ed_izm_fr,fr.franchise_percent,gr.vehicle_group_id,gr.vehicle_group_name,prod.product_id,prod.product_name,terr.casco_territory_id,terr.casco_territory_name,fr.vehicle_code_fk,mm.code,mm.brand_name,mm.model_name,fr.project_id_fk,prjg.project_id,prjg.project_name,fr.coeff_value,fr.start_date,fr.end_date"
                                          " from rgsscc.ref_cascodictk04 fr"
                                          " left join rgsscc.ref_autodictvehiclegroup gr on (fr.vehicle_group_id_lnk_fk=gr.id and gr.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_ed_izm_franshiza eifr on (fr.to_4235_fk=eifr.id and eifr.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_product prod on (fr.to_732_fk=prod.id and prod.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_autodictcascoterritory terr on (fr.link_7353_to_728_fk=terr.id and terr.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and terr.active_entry='Y')"
                                          " left join apo.carrier_models mm on fr.vehicle_code_fk=mm.id"
                                          " left join rgsscc.ref_dictproject prjg on (fr.project_id_fk=prjg.id and prjg.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " left join rgsscc.ref_t_franshiza tfr on (fr.code_t_fr_lnk_fk=tfr.id and tfr.date_to=to_date('01.01.3000', 'dd.mm.yyyy'))"
                                          " where fr.date_to=to_date('01.01.3000', 'dd.mm.yyyy')  and fr.franchise_percent <> '0'"
                                          " order by fr.franchise_percent, to_number(gr.vehicle_group_id), to_number(eifr.code_ed_izm_fr)", "gl_dict_franshize", false)));
   insert(std::make_pair("7.3.54", TblQue("select k5_id,payout_num as k5_name,payout_num,cast(payout_count_min as int),payout_count_max,link_to_7_3_63_fk,NVL(link_to_7_2_9_fk,0),coeff_value,start_date,NVL(end_date,'01.01.3000') from rgsscc.ref_cascodictk05 where sysdate<date_to", "cascodictk05", false)));
   insert(std::make_pair("7.3.56", TblQue("select k7_id,tabl_7_3_21_fk,tabl_7_3_63_fk,cast(vehicle_age_min as int),vehicle_age_max,coeff_value,start_date,NVL(end_date,'01.01.3000') from rgsscc.ref_cascodictk07 where sysdate<date_to", "cascodictk07", false)));
   insert(std::make_pair("7.3.58", TblQue("select * from apo.kr_7_3_58", "gl_dict_cascokr", false)));
   insert(std::make_pair("7.3.59", TblQue("select * from apo.base_rate_kasko_7_3_59", "gl_dict_cascobaserate", false)));
   insert(std::make_pair("7.3.60", TblQue("select * from apo.kar_7_3_60", "gl_dict_cascokar", false)));
   insert(std::make_pair("7.3.69", TblQue("select t1.kb_id,t1.coeff_value,t1.link_to_7_3_63_fk,t2.bank_code,0 as bank_id,t1.start_date,t1.end_date from rgsscc.ref_cascodictkb t1 left join rgsscc.ref_dict_cbrf_bank t2 on t1.link_7369_to_7637_fk=t2.id and t2.date_to=to_date('01.01.3000', 'dd.mm.yyyy') where t1.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and t1.credit=1 order by t1.kb_id", "cascodictkb", false)));

   insert(std::make_pair("7.3.73", TblQue("select kd_id,casco_territory_id,driver_count,coeff_value,start_date,end_date from rgsscc.ref_cascodictkd where sysdate<=NVL(date_to,sysdate)", "cascodictkd", false)));
   insert(std::make_pair("7.3.76", TblQue("select t1.id_scc,t1.k5_code,t1.claims_count_min,t1.claims_count_max,t1.claims_sum_min,t1.claims_sum_max,t1.new_k5_code,t1.start_date,t1.end_date,t2.coeff_value,nvl(t2.link_to_7363_fk,0),t2.start_date as start_date_coeff,t2.end_date as end_date_coeff from rgsscc.ref_cascodictk05_2013_clas t1 left join rgsscc.ref_cascodictk05_2013 t2 on (t1.k5_code=t2.k5_code and t2.date_to=to_date('01.01.3000', 'dd.mm.yyyy')) where t1.date_to=to_date('01.01.3000', 'dd.mm.yyyy')", "cascodictk5", false)));

   insert(std::make_pair("7.4.9",  TblQue("select blank_type_id,blank_type_name from rgsscc.ref_dictblanktype where contract_class_id in (1,5) and sysdate<date_to and active_entry='Y'", "bso", false)));
   insert(std::make_pair("7.4.11", TblQue("select t1.sale_channel_type2008_id,NVL(t2.sale_channel_type2008_id, 0),t1.sale_channel_type2008_name,t1.sort_order,t1.start_date,NVL(t1.end_date,'01.01.3000'),t1.referable,NVL(t1.reserves,0) from rgsscc.ref_dictsalechanneltype200 t1 left join rgsscc.ref_dictsalechanneltype200 t2 on t1.sale_channel_type2008_id_fk=t2.id where sysdate<=NVL(t1.date_to,sysdate) and sysdate<=NVL(t2.date_to,sysdate)", "gl_dict_kanal_prodag", false)));
   insert(std::make_pair("7.4.26", TblQue("select t1.k6_id,t1.k6_name,t2.casco_territory_id,t1.coeff_value,t1.start_date,NVL(t1.end_date,'01.01.3000'),t1.sort_order from rgsscc.ref_cascodict2008k06 t1,rgsscc.ref_autodictcascoterritory t2 where t1.link_to_7_2_8_fk=t2.id and sysdate<t1.date_to and sysdate<t2.date_to","cascodictk06", false)));
   insert(std::make_pair("7.4.27", TblQue("select t1.liability_id,t1.value,t1.start_date,NVL(t1.end_date,'01.01.3000'),t1.premum,t2.letter_currency_code,t1.casco_territory_type_id_fk,t1.is_used_trailer,t4.territory_id,t1.link_to_7_2_47_fk,t1.was_accident,t3.product_id from rgsscc.ref_dictliability t1,rgsscc.ref_currencies t2,rgsscc.ref_product t3, rgsscc.ref_atdosagoterritory t4 where t1.currency_id_fk=t2.id(+) and NVL(t1.product_product_id_fk,64)=t3.id(+) and NVL(t1.link_to_7_3_47_fk,1116)=t4.id(+) and sysdate<t1.date_to and sysdate<NVL(t2.date_to,sysdate) and sysdate<NVL(t3.date_to,sysdate) and sysdate<NVL(t4.date_to,sysdate)", "gl_dict_dsago_tarifs", false)));
   insert(std::make_pair("7.4.28", TblQue("select t2.casco_territory_id,t1.casco_territory_type_id_fk,t1.start_date,NVL(t1.end_date,'01.01.3000'),t3.federal_district_code from rgsscc.ref_adcascoterr_terrtype t1 left join rgsscc.ref_autodictcascoterritory t2 on t1.adcterritory_casco_terr_id_fk=t2.id left join rgsscc.ref_dictcontractclass t3 on t1.link_7_3_1_fk=t3.id where sysdate<t1.date_to and sysdate<t2.date_to and sysdate<t3.date_to", "gl_dict_dsago_contract", false)));
   insert(std::make_pair("7.4.29", TblQue("select t1.autodictpaymentmethod_fk,t2.product_id,t1.start_date,NVL(t1.end_date,'01.01.3000') from rgsscc.ref_cascodictpaymentmethod t1 left join rgsscc.ref_product t2 on t1.product_id_fk=t2.id where sysdate<t1.date_to and sysdate<t2.date_to", "cascopaymentprod", false)));
   /*insert(std::make_pair("7.4.30", TblQue("select to_number(dp.project_id) project_id,dp.project_name,to_number(dpt.project_type_id) project_type_id,to_number(pr.product_id) product_id,to_number(decode(sub.subject_federation_code,'0','116',sub.subject_federation_code)) region_id,1 ka_min,1 ka_max,trunc(dpp.start_date, 'DD') start_date, nvl(trunc(dpp.end_date_, 'DD'), to_date('01.01.3000', 'dd.mm.yyyy')) end_date"
                                          " from rgsscc.ref_dictprojectproduct dpp"
                                          " join rgsscc.ref_dictproject dp on dp.id=dpp.dictproject_project_id_fk and dp.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_dictprojecttype dpt on dpt.id=dp.project_type_id_lnk_fk and dpt.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_product pr on pr.id=dpp.product_product_id_fk and pr.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_subject_rf sub on sub.id=dpp.link_4_1_4_fk and sub.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " left join rgsscc.ref_gvs gvs on gvs.id=dpp.gvs_lnk_fk and gvs.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " where dpp.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and (to_number(pr.product_id) in (0,1,2,3,304,305,306,310,320,401,402) or (to_number(pr.product_id) in (301,302,303) and dpt.project_type_id=1)) and nvl(gvs.insuarance_type_code, 0) in (0, 102, 106, 109, 114, 122)"
                                          " union all "
                                          "select to_number(dp.project_id) project_id,dp.project_name,to_number(dpt.project_type_id) project_type_id,to_number(pr.product_id) product_id,to_number(decode(sub.subject_federation_code,'0','116',sub.subject_federation_code)) region_id,kpr.min_coeff_value ka_min,kpr.max_coeff_value ka_max,kpr.start_date,kpr.end_date"
                                          " from rgsscc.ref_cascodictkpr kpr"
                                          " join rgsscc.ref_dictproject dp on dp.id=kpr.project_id_lnk_fk and dp.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_dictprojecttype dpt on dpt.id=dp.project_type_id_lnk_fk and dpt.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_product pr on pr.id=kpr.product_id_lnk_fk and pr.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_subject_rf sub on sub.id=kpr.subject_federation_code_lnk_fk and sub.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " where kpr.date_to=to_date('01.01.3000', 'dd.mm.yyyy')", "gl_dict_programm_project", false)));
   */
   insert(std::make_pair("7.4.30", TblQue("select to_number(dp.project_id) project_id, dp.project_name,to_number(dpt.project_type_id) project_type_id,to_number(pr.product_id) product_id,to_number(decode(sub.subject_federation_code,'0','116',sub.subject_federation_code)) subject_federation_code,nvl(kpr.min_coeff_value, 1) min_cv,nvl(kpr.max_coeff_value, 1) max_cv,trunc(dpp.start_date, 'DD') start_date,nvl(trunc(dpp.end_date_, 'DD'),to_date('01.01.3000', 'dd.mm.yyyy')) end_date,nvl(kpr.start_date, '01.01.1900') start_date_coeff,nvl(kpr.end_date, '01.01.3000') end_date_coeff"
                                          " from rgsscc.ref_dictprojectproduct dpp"
                                          " join rgsscc.ref_dictproject dp on dp.scc_id = dpp.project_id   and dp.date_to = to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_dictprojecttype dpt on dpt.scc_id = dp.project_type_id_lnk_fk_ and dpt.date_to = to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_product pr on pr.scc_id = dpp.product_id and pr.date_to = to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " join rgsscc.ref_subject_rf sub on sub.scc_id = dpp.country_subject_id and sub.date_to = to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " left join rgsscc.ref_gvs gvs on gvs.scc_id = dpp.insurance_type_code and gvs.date_to = to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " left join rgsscc.ref_cascodictkpr kpr on dpp.project_id = kpr.project_id_lnk_fk_ and  dpp.product_id = kpr.product_id_lnk_fk_ and  dpp.country_subject_id = kpr.subject_federation_code_lnk_f_ and kpr.date_to = to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " where dpp.date_to = to_date('01.01.3000', 'dd.mm.yyyy') and (dpp.partnership is null or to_number(dpp.partnership)=0) and pr.product_id in ('0', '1', '2', '3', '301', '302', '303', '304', '305', '306', '310', '320', '401', '402') and nvl(gvs.insuarance_type_code, 0) in (0, 102, 106, 109, 114, 122)  order by to_number(dp.project_id)", "gl_dict_programm_project", false)));

   insert(std::make_pair("7.6.36", TblQue("select t2.casco_territory_id,t1.commentar,t1.start_date,t1.end_date from rgsscc.ref_pndregions t1,rgsscc.ref_autodictcascoterritory t2 where t1.link_7636_to_728_fk=t2.id(+) and sysdate<t1.date_to and sysdate<t2.date_to order by t2.casco_territory_id", "cascopnd", false)));

   insert(std::make_pair("7.6.37", TblQue("select bn.bank_code, bn.bank_name,"
                                          "replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(bn.bank_name_full,'�������� ','�'), '�������� ','�'),'����������� ','�'),'����������� ','�'),'�������� ','�'),'�������� ','�'),'��������','�'),'��������','�'), ' � ������������ ����������������','��'),'�������� ����������� ��������','���'),'�������� ����������� ��������','���'),'�������� � ������������ ����������������','���'), ' � ������������ ����������������','��'), '��������� ','�'), '��������� ','�'), '��������� ����������� ��������','���') as bank_name_print,"
                                          "cpm.beneficiary_bank as benefic,replace(cpm.others,'\"') as requirements,bn.bank_adress as bank_address,cpm.rules_redaction,"
                                          "replace(case when substr(cpm.beneficiary, 1, 1)='\"' then substr(cpm.beneficiary, 2, length(cpm.beneficiary) - 2) when substr(cpm.beneficiary, 1, 1)<>'\"' then cpm.beneficiary end, '\"\"', '\"') as beneficiary,"
                                          "replace(case when substr(cpm.mortgagee, 1, 1)='\"' then substr(cpm.mortgagee, 2, length(cpm.mortgagee) - 2) when substr(cpm.mortgagee, 1, 1)<>'\"' then cpm.mortgagee end, '\"\"', '\"') as mortgagee,"
                                          "cpm.compensation_type,cpm.policy_mask,dp.project_id,bn.start_date,nvl(bn.end_date,'01.01.3000') as end_date from rgsscc.ref_dict_cbrf_bank bn join rgsscc.ref_credit_policy_mask cpm on bn.id=cpm.to_7637_fk and cpm.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and cpm.end_date > sysdate "
                                          "left join rgsscc.ref_bank_program bnprg on bn.id=bnprg.to_7637_fk and bnprg.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and bnprg.to_748_fk in (701) "
                                          "left join rgsscc.ref_dictproject dp on bnprg.to_748_fk=dp.id and dp.date_to=to_date('01.01.3000', 'dd.mm.yyyy')"
                                          " where bn.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and (lower(bn.bank_name_full) not like '%������������%' or bn.bank_name_full is null) order by bn.bank_code",
                                          "gl_dict_banks", false)));
   //insert(std::make_pair("7.7.57", TblQue("select 0 as bank_id,bn.bank_code,br.sort_order,br.others_item,br.signature_required,br.start_date,nvl(br.end_date,to_date('01.01.3000','dd.mm.yyyy')) as end_date from rgsscc.ref_bank_requirements br left join rgsscc.ref_dict_cbrf_bank bn on br.to_7637_fk=bn.id and bn.date_to=to_date('01.01.3000', 'dd.mm.yyyy') where br.date_to=to_date('01.01.3000', 'dd.mm.yyyy') and br.to_732_fk is null order by bn.bank_code, br.sort_order", "cascobanksrequirements", false)));

   insert(std::make_pair("7.7.57", TblQue("select 0 as bank_id,bn.bank_code,bn.bank_name,br.is_credit,nvl(pr.product_id,0),pr.product_name,br.sort_order,replace(br.others_item,chr(34)) others_item,br.signature_required,br.start_date,nvl(br.end_date,to_date('01.01.3000','dd.mm.yyyy')) as end_date from rgsscc.ref_bank_requirements br left join rgsscc.ref_dict_cbrf_bank bn on br.to_7637_fk_=bn.scc_id and bn.scc_status=0 left join rgsscc.ref_product pr on br.to_732_fk_=pr.scc_id and pr.scc_status=0 where br.scc_status=0 order by pr.product_id, bn.bank_code, br.sort_order", "gl_dict_banksrequirements", false)));
   //
   //����������
   insert(std::make_pair("5.3.1", TblQue("select t2.code,t1.td_id,t1.car_type,t1.car_maker,t1.car_model,t1.car_case_type,t1.car_case_1,t1.car_case_2,t1.car_modif,t1.car_doors,t1.car_engine,t1.car_engvol,t1.car_engpwr,t1.car_kpp,t1.car_kppmod,t1.car_fuel,t1.car_prod_start,t1.car_prod_end,t1.car_options from rgsscc.ref_transdekra_cars t1,rgsscc.ref_carrier_models t2 where t1.link_531_to_513_fk=t2.id(+) and sysdate<t1.date_to and sysdate<t2.date_to", "td_531", true)));
   insert(std::make_pair("5.3.2", TblQue("select opt_id,opt_name from rgsscc.ref_transdekra_options where sysdate<date_to", "td_532", true)));
   insert(std::make_pair("5.3.3", TblQue("select t2.td_id,t1.date_prod,NVL(t1.used_price_reg1,0),NVL(t1.used_price_reg2,0),NVL(t1.used_price_reg3,0),NVL(t1.used_price_reg4,0),NVL(t1.used_price_reg5,0),NVL(t1.used_price_reg6,0),NVL(t1.used_price_reg7,0),NVL(t1.used_price_reg8,0),NVL(t1.used_price_reg9,0),NVL(t1.used_price_reg10,0),NVL(t1.used_price_reg11,0),NVL(t1.used_price_reg12,0),NVL(t1.used_price_reg13,0),NVL(t1.used_price_reg14,0),NVL(t1.used_price_reg15,0),NVL(t1.used_price_reg16,0),NVL(t1.used_price_reg17,0),NVL(t1.used_price_reg18,0),NVL(t1.used_price_reg19,0),NVL(t1.used_price_reg20,0),NVL(t1.used_price_reg21,0),NVL(t1.used_price_reg22,0),NVL(t1.used_price_reg23,0),NVL(t1.used_price_reg24,0),NVL(t1.used_price_reg25,0),NVL(t1.used_price_reg26,0),NVL(t1.used_price_reg27,0),NVL(t1.used_price_reg28,0),NVL(t1.used_price_reg29,0),NVL(t1.used_price_reg30,0),"
                                         "NVL(t1.used_price_reg31,0),NVL(t1.used_price_reg32,0),NVL(t1.used_price_reg33,0),NVL(t1.used_price_reg34,0),NVL(t1.used_price_reg35,0),NVL(t1.used_price_reg36,0),NVL(t1.used_price_reg37,0),NVL(t1.used_price_reg38,0),NVL(t1.used_price_reg39,0),NVL(t1.used_price_reg40,0),NVL(t1.used_price_reg41,0),NVL(t1.used_price_reg42,0),NVL(t1.used_price_reg43,0),NVL(t1.used_price_reg44,0),NVL(t1.used_price_reg45,0),NVL(t1.used_price_reg46,0),NVL(t1.used_price_reg47,0),NVL(t1.used_price_reg48,0),NVL(t1.used_price_reg49,0),NVL(t1.used_price_reg50,0),NVL(t1.used_price_reg51,0),NVL(t1.used_price_reg52,0),NVL(t1.used_price_reg53,0),NVL(t1.used_price_reg54,0),NVL(t1.used_price_reg55,0),NVL(t1.used_price_reg56,0),NVL(t1.used_price_reg57,0),NVL(t1.used_price_reg58,0),NVL(t1.used_price_reg59,0),NVL(t1.used_price_reg60,0),NVL(t1.used_price_reg61,0),NVL(t1.used_price_reg62,0),NVL(t1.used_price_reg63,0),NVL(t1.used_price_reg64,0),NVL(t1.used_price_reg65,0),"
                                         "NVL(t1.used_price_reg66,0),NVL(t1.used_price_reg67,0),NVL(t1.used_price_reg68,0),NVL(t1.used_price_reg69,0),NVL(t1.used_price_reg70,0),NVL(t1.used_price_reg71,0),NVL(t1.used_price_reg72,0),NVL(t1.used_price_reg73,0),NVL(t1.used_price_reg74,0),NVL(t1.used_price_reg75,0),NVL(t1.used_price_reg76,0),NVL(t1.used_price_reg77,0),NVL(t1.used_price_reg78,0),NVL(t1.used_price_reg79,0),NVL(t1.used_price_reg80,0),NVL(t1.used_price_reg81,0),NVL(t1.used_price_reg82,0),NVL(t1.used_price_reg83,0),NVL(t1.used_price_reg84,0),NVL(t1.used_price_reg85,0),NVL(t1.used_price_reg86,0),NVL(t1.used_price_reg87,0),NVL(t1.used_price_reg88,0),NVL(t1.used_price_reg89,0),NVL(t1.used_price_reg90,0),NVL(t1.used_price_reg91,0),NVL(t1.used_price_reg92,0),NVL(t1.used_price_reg93,0),NVL(t1.used_price_reg94,0),NVL(t1.used_price_reg95,0),NVL(t1.used_price_reg96,0),NVL(t1.used_price_reg97,0),NVL(t1.used_price_reg98,0),NVL(t1.used_price_reg99,0),NVL(t1.used_price_reg100,0) "
                                         "from rgsscc.ref_transdekra_prices t1,rgsscc.ref_transdekra_cars t2 where t1.td_id_new=t2.td_id(+) and sysdate<t1.date_to and sysdate<t2.date_to", "td_533", true)));
}
//---------------------------------------------------------------------------
void Anketa::Init()
{
   for(int i = 0; i < 11; ++i){
      question q;
      q.number = i;
      switch(i){
         case 0: case 3: case 6: q.response.push_back(0); q.response.push_back(2); break;
         case 1: q.response.push_back(0); q.response.push_back(1); q.response.push_back(3); break;
         case 2: q.response.push_back(0); q.response.push_back(1); q.response.push_back(2); q.response.push_back(3); break;
         case 4: q.response.push_back(6); q.response.push_back(5); q.response.push_back(4); q.response.push_back(3); q.response.push_back(2); q.response.push_back(1); q.response.push_back(0); break;
         case 5: case 7: case 8: case 9:  q.response.push_back(0); q.response.push_back(1); q.response.push_back(2); break;
         case 10: q.response.push_back(4); q.response.push_back(3); q.response.push_back(2); q.response.push_back(1); q.response.push_back(0); break;
      }
      push_back(q);
   }
}
//---------------------------------------------------------------------------
void GenerateResponseList(Anketa &ret_a, Anketa &a, const int discount)
{
m1:
   if(a.empty() || discount < 0) return;

   Anketa new_a = a, new_ret_a = ret_a;

   Randomize();
   int index_question = RandomRange(0, new_a.size());

   Randomize();
   int index_response = RandomRange(0, new_a[index_question].response.size());
   int ves = new_a[index_question].response[index_response], summ_max(0);

   question q = new_a[index_question];
   new_a.erase(&new_a[index_question]);

   for(Anketa::iterator it = new_a.begin(); it != new_a.end(); ++it) summ_max += *std::max_element((*it).response.begin(),(*it).response.end());

   if(summ_max >= discount - ves && discount - ves >= 0){
      question qu = q;
      qu.response.clear();
      qu.response.push_back(q.response[index_response]);
      new_ret_a.push_back(qu);
      GenerateResponseList(new_ret_a, new_a, discount - ves);
      ret_a = new_ret_a;
      a = new_a;
   }
   else goto m1;
}
//---------------------------------------------------------------------------
MaskDocType::MaskDocType(const int type)
{
   switch(type){
      case 1:
         insert(std::make_pair(2,  InputMask(">ll;0;_", ">999999;0;_")));
         insert(std::make_pair(5,  InputMask(">ll;0;_", ">9999999;0;_", 1)));
         insert(std::make_pair(6,  InputMask(">99;0;_", ">9999999;0;_")));
         insert(std::make_pair(7,  InputMask("", "", 0, 25)));
         insert(std::make_pair(9,  InputMask("", "", 0, 25)));
         insert(std::make_pair(12, InputMask(">99\ 99;0;_", ">999999;0;_")));
         insert(std::make_pair(13, InputMask(">99;0;_", ">9999999;0;_")));
         insert(std::make_pair(15, InputMask(">ll;0;_", ">9999999;0;_", 1)));
         insert(std::make_pair(17, InputMask(">99\ aa;0;_", ">999999;0;_")));
         insert(std::make_pair(21, InputMask(">99;0;_", ">999999999;0;_")));
         insert(std::make_pair(24, InputMask("", "", 0, 20)));
         insert(std::make_pair(25, InputMask(">99;0;_", ">999999999;0;_")));
         insert(std::make_pair(29, InputMask(">99;0;_", ">999999999;0;_")));
         break;
      case 2:
         insert(std::make_pair(1, InputMask("[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}", ">999999;0;_")));
         insert(std::make_pair(2, InputMask("[0-9]{4}|[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{3}", ">999999;0;_")));
         insert(std::make_pair(3, InputMask("", "")));
         insert(std::make_pair(4, InputMask("", "")));
         insert(std::make_pair(5, InputMask("", "")));
         insert(std::make_pair(6, InputMask("", "")));
         insert(std::make_pair(7, InputMask("", "")));
         insert(std::make_pair(8, InputMask("", "")));
         insert(std::make_pair(9, InputMask("", "")));
         insert(std::make_pair(10,InputMask("", "")));
         break;
   }
}
//---------------------------------------------------------------------------
void UsagePeriod::CheckAndCorrectCancelDate(const TDateTime& policy_cd)
{
   if(policy_cd < start_period){ start_period.Val = 0.0; end_period = 0.0; }
   if(policy_cd < end_period) end_period = policy_cd;
}
//---------------------------------------------------------------------------
int OsagoInfo::DaysInPeriod()
{
   TDateTime dt_s(0.0), dt_e(0.0);
   int count_periods = period_enter.size(), dip(0);

   if(!count_periods) return 0;

   std::sort(period_enter.begin(), period_enter.end());

   TStringList *sl = new TStringList();

   for(int i = 0; i < count_periods; ++i){
      AnsiString str = period_enter[i].start_period.DateString() + " - " + period_enter[i].end_period.DateString();
      if(period_enter[i].start_period > dt_s) dt_s = period_enter[i].start_period;
      dt_e = period_enter[i].end_period;
      if(dt_s < period_main.start_period) dt_s = period_main.start_period;
      if(dt_e > period_main.end_period)   dt_e = period_main.end_period;
      if(dt_e > dt_s){
         str += ("                " + dt_s.DateString() + " - " + dt_e.DateString());
         dip += (DaysBetween(dt_s, dt_e) + 1);
         dt_s = IncDay(dt_e);
      }
      else str += ("                  minus");
      //}
      sl->Add(str);
   }

   sl->SaveToFile("D:\\periods_f.txt");

   delete sl;

   return dip;
}
//---------------------------------------------------------------------------
void K1(mops_api_024 *m_api, const int index_pm, PersonInfo *pm, Dogovor_Info *di)
{
   TADOQuery *q;
   int res;
   AnsiString sql("");

   if(pm[index_pm].age == 0 && pm[index_pm].experience == 0)
      q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK01 where tertype_id=%i and drvexp_min=0 and drvexp_max=0 and age_min=0 and age_max=0 and CDate('%s')>=start_date and CDate('%s')<=end_date", di->REGION_TYPE, di->calc_date, di->calc_date));
   else
      q = m_api->dbGetCursor(res, sql.sprintf("select coeff_val from CascoDictK01 where tertype_id=%i and drvexp_min<=%i and drvexp_max>%i and age_min<=%i and age_max>%i and CDate('%s')>=start_date and CDate('%s')<=end_date",
                             di->REGION_TYPE, pm[index_pm].experience, pm[index_pm].experience, pm[index_pm].age, pm[index_pm].age, di->calc_date, di->calc_date));
   pm[index_pm].k1 = q->IsEmpty() ? 1 : q->FieldByName("coeff_val")->AsFloat;

   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void ChangeMask(TdxInspectorTextMaskRow *DocSeria, TdxInspectorTextMaskRow *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   DocSeria->EditText   = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;

   DocNumber->EditText  = v2;
   DocNumber->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   /*if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
   else*/ r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;

   /*if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
   else*/ r_DocNumber->Properties->Value   = v2;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, TSInfo *p_tsi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_tsi->pts_series = v1;
   p_tsi->pts_number = v2;

   /*if(v1.IsEmpty()) r_DocSeria->Properties->Value.Clear();
   else*/ r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_vehicle_doc_type[p_tsi->type_doc_ts].mask_series;
   DocSeria->Properties->MaxLength  = mask_vehicle_doc_type[p_tsi->type_doc_ts].max_length;

   /*if(v2.IsEmpty()) r_DocNumber->Properties->Value.Clear();
   else*/ r_DocNumber->Properties->Value   = v2;
   DocNumber->Properties->EditMask  = mask_vehicle_doc_type[p_tsi->type_doc_ts].mask_number;
   DocNumber->Properties->MaxLength = mask_vehicle_doc_type[p_tsi->type_doc_ts].max_length;
}
//---------------------------------------------------------------------------
double GetKprSb(const double& val)
{
   if(val <= 0.54) return 1.75;
   if(val <= 0.59) return 1.60;
   if(val <= 0.64) return 1.50;
   if(val <= 0.69) return 1.40;
   if(val <= 0.74) return 1.30;
   if(val <= 0.79) return 1.25;
   if(val <= 0.84) return 1.2;
   if(val <= 0.89) return 1.15;

   return 1.1;
}
//---------------------------------------------------------------------------
void GetPhones(_di_IXMLNode contacts, AnsiString& ph_mob, AnsiString& ph_home, AnsiString& ph_rab, int &sms)
{
   sms = -1;
   for(int i = 0, cnt = contacts->ChildNodes->Count, i_val = 0; i < cnt; ++i){
      _di_IXMLNode child_node = contacts->ChildNodes->Get(i);
      if(child_node->HasAttribute("contract_type_id") && TryStrToInt(child_node->Attributes["contact_type_id"], i_val)){
         switch(i_val){
            case 1:
               if(child_node->HasAttribute("contract_data")) ph_home = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data"))  ph_home = child_node->Attributes["contact_data"];
               break;
            case 2:
               if(child_node->HasAttribute("contract_data")) ph_rab = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data"))  ph_rab = child_node->Attributes["contact_data"];
               break;
            case 3:
               if(child_node->HasAttribute("contract_data")) ph_mob = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data")) ph_mob = child_node->Attributes["contact_data"];
               if(child_node->HasAttribute("spam")) sms = AnsiString(child_node->Attributes["contact_data"]).ToIntDef(-1);
               break;
         }
      }
   }
}
//---------------------------------------------------------------------------
AnsiString IntToBin(const int ANumber, int ABitCount)
{
   ABitCount = (ABitCount < 1) ? 1 : ((ABitCount > 32) ? 32 : ABitCount);

   AnsiString Result("", ABitCount);

   for(int i = ABitCount, Mask = 1; i >= 1; i--, Mask <<= 1) Result[i] = (ANumber & Mask) ? '1' : '0';

   return Result;
}
//---------------------------------------------------------------------------
void PmDataToRecord(TADOQuery* q_perm, PersonInfo *pm, const int calc_id, const int num, const int i, const int pm_status)
{
   q_perm->FieldByName("calc_id")->Value = calc_id;
   q_perm->FieldByName("status")->Value = 0;
   q_perm->FieldByName("type_person")->Value = num + 4;
   q_perm->FieldByName("first_name")->Value = pm[i].firstname;
   q_perm->FieldByName("second_name")->Value = pm[i].secondname;
   q_perm->FieldByName("last_name")->Value = pm[i].lastname;
   q_perm->FieldByName("phisical_birth_date")->Value = pm[i].birthdate;
   q_perm->FieldByName("phisical_sex")->Value = pm[i].sex;
   q_perm->FieldByName("age")->Value = pm[i].age;
   q_perm->FieldByName("experience")->Value = pm[i].experience;
   q_perm->FieldByName("document_type_id")->Value = pm[i].doc_type;
   q_perm->FieldByName("document_series")->Value = pm[i].doc_seria;
   q_perm->FieldByName("document_number")->Value = pm[i].doc_number;
   q_perm->FieldByName("document_issue_date")->Value = pm[i].doc_issue_date;
   q_perm->FieldByName("addr_mid")->Value = 0;
   q_perm->FieldByName("permitted_status")->Value = pm_status;
   q_perm->FieldByName("address")->Value = pm[i].address;
   q_perm->FieldByName("black_list")->Value = pm[i].black_list;
   q_perm->FieldByName("k6")->Value = pm[i].k6;
   q_perm->FieldByName("is_underwriting")->Value = pm[i].is_underwriting;
   q_perm->FieldByName("rsa_id")->Value = pm[i].rsa_id;
}
//---------------------------------------------------------------------------
void Save_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm, TListView *gridDopush)
{
   int res;
   AnsiString calc_id_str = IntToStr(calc_id);
   m_api->dbExecuteQuery(res, "delete * from casco_dogovors_k5_k6 where calc_id=" + calc_id_str);
   TADOQuery *q_d_k5_k6 = m_api->dbGetCursor(res, "select * from casco_dogovors_k5_k6 where calc_id=" + calc_id_str, 0, 1);
   for(std::map<AnsiString, std::vector<Dogovor> >::iterator iter = pi[0].dogovors.begin(); iter != pi[0].dogovors.end(); ++iter){
      AnsiString key = iter->first;
      for(int i = 0, cnt = pi[0].dogovors[key].size(); i < cnt; ++i){
         q_d_k5_k6->Insert();
         q_d_k5_k6->FieldByName("calc_id")->Value      = calc_id;
         q_d_k5_k6->FieldByName("type_person")->Value  = 1;
         q_d_k5_k6->FieldByName("type_dogovor")->Value = key;
         q_d_k5_k6->FieldByName("system")->Value       = pi[0].dogovors[key][i].system;
         q_d_k5_k6->FieldByName("dogovor_id")->Value   = pi[0].dogovors[key][i].id;
         q_d_k5_k6->FieldByName("is_last")->Value      = (pi[0].dogovors[key][i].id == di->last_contract_id && pi[0].dogovors[key][i].system == di->system) ? 1 : 0;
      }
   }

   for(int i = 0, j = 0, drv_count = gridDopush->Items->Count; i < drv_count; ++i){
      if(gridDopush->Items->Item[i]->Checked){
         for(int d = 0, cnt = pm[i].dogovors["k6"].size(); d < cnt; ++d){
            q_d_k5_k6->Insert();
            q_d_k5_k6->FieldByName("calc_id")->Value      = calc_id;
            q_d_k5_k6->FieldByName("type_person")->Value  = j + 4;
            q_d_k5_k6->FieldByName("type_dogovor")->Value = "k6";
            q_d_k5_k6->FieldByName("system")->Value       = pm[i].dogovors["k6"][d].system;
            q_d_k5_k6->FieldByName("dogovor_id")->Value   = pm[i].dogovors["k6"][d].id;
            q_d_k5_k6->FieldByName("is_last")->Value      = 0;
         }
         ++j;
      }
   }
   q_d_k5_k6->UpdateBatch();
   m_api->dbCloseCursor(res, q_d_k5_k6);
}
//---------------------------------------------------------------------------
void Load_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm)
{
   int res;
   TADOQuery *q_d_k5_k6 = m_api->dbGetCursor(res, "select * from casco_dogovors_k5_k6 where calc_id=" + IntToStr(calc_id) + " order by type_person, type_dogovor");
   for(q_d_k5_k6->First(); !q_d_k5_k6->Eof; q_d_k5_k6->Next()){
      if(q_d_k5_k6->FieldByName("type_person")->AsInteger == 1){
         pi[0].dogovors[q_d_k5_k6->FieldByName("type_dogovor")->AsString].push_back(Dogovor(q_d_k5_k6->FieldByName("dogovor_id")->AsString, q_d_k5_k6->FieldByName("system")->AsInteger));
         if(q_d_k5_k6->FieldByName("is_last")->AsInteger){
            di->last_contract_id = q_d_k5_k6->FieldByName("dogovor_id")->AsString;
            di->system = q_d_k5_k6->FieldByName("system")->AsInteger;
         }
      }
      else pm[q_d_k5_k6->FieldByName("type_person")->AsInteger - 4].dogovors[q_d_k5_k6->FieldByName("type_dogovor")->AsString].push_back(Dogovor(q_d_k5_k6->FieldByName("dogovor_id")->AsString, q_d_k5_k6->FieldByName("system")->AsInteger));
   }
   m_api->dbCloseCursor(res, q_d_k5_k6);
}
//---------------------------------------------------------------------------
void FieldValueIDToVGEditor(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row)
{
   int index = cboxitem->Properties->Items->IndexOfObject((TObject*)fv);
   if(index > -1) row->Properties->Value = cboxitem->Properties->Items->Strings[index];
}
//---------------------------------------------------------------------------
void FieldValueIDToVGEditor_(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row)
{
   int index = GetIndexObject(cboxitem->Properties->Items, fv);
   if(index > -1) row->Properties->Value = cboxitem->Properties->Items->Strings[index];
}
//---------------------------------------------------------------------------

int GetDrvCount(TADOQuery *qq)
{
   qq->Filtered = false;
   qq->Filter   = "[type_person] > 3";
   qq->Filtered = true;

   int drv_count = qq->RecordCount;

   qq->Filtered = false;

   return drv_count;
}
//---------------------------------------------------------------------------
int GetCountPermitted(TListView *gridDopush)
{
   int count_permitted(0);

   for(int i = 0, cnt = gridDopush->Items->Count; i < cnt; ++i) if(gridDopush->Items->Item[i]->Checked) ++count_permitted;

   return count_permitted;
}
//---------------------------------------------------------------------------
int MonthsCount(const TDateTime& ANow, const TDateTime& AThen)
{
   int ACount;
   for(ACount = 1; ACount < 13; ++ACount) if(IncMonth(ANow, ACount) > AThen) return ACount;
   return ACount;
}
//---------------------------------------------------------------------------
void VariantToDate(Variant v, TDateTime& dt)
{
   AnsiString dt_str("");

   if(!v.IsNull()){
      dt_str = v;
      if(dt_str.Length() < 10 || !TryStrToDate(dt_str, dt)) dt.Val = 0;
   }
   else dt.Val = 0;
}
//---------------------------------------------------------------------------
void MakeExportFilters(TSaveDialog *sd, Dogovor_Info *di, Map_Int_Str &filter)
{
   if(di->is_msoff){
      sd->Filter = "Excel|*.xls";
      filter[1] = "XLS";
   }
   if(di->is_opoff){
      if(di->is_msoff){
         sd->Filter += "|";
         filter[2] = "ODS";
      }
      else filter[1] = "ODS";
      sd->Filter += "OpenOffice(LibreOffice)|*.ods";
      if(di->is_msoff) sd->FilterIndex = 2;
   }
}
//---------------------------------------------------------------------------
AnsiString MarkaId(const int model_id)
{
   return (model_id == -1 ? AnsiString(model_id) : AddNulls((model_id / 1000000) * 1000000));
}
//---------------------------------------------------------------------------


Boolean PasportInBadList(AnsiString DocSeria, AnsiString DocNumber, Integer DocType, AnsiString APO2_ARM_READER_ADR)
{
  Boolean IsBadDoc = False;
  
  const int cBadDoc = 1;
  const int cPasportRF = 12;
  const AnsiString cWarningBadDoc = "��������! ������ �������� �������� ����� ���������������� (���������� (����������), ����������� �� ���������� (����������) ������� �������� ���������� ���������� ���������, �������� � ��������� �������������� �������, � ����� ���������� �����������������) ��������� ������� ���������� ���������, �������������� �������� ���������� ���������� ��������� �� ���������� ���������� ���������."
    "���������� �������� � ������ ������ ��������������� ������������� ����� ���� ������������ ��������, �.�. ������ �� �� ����� ���� ���������������� �� �������������� ���������";

  if (DocType != cPasportRF)
    return IsBadDoc;

  DocSeria = StringReplace(DocSeria, " ", "", TReplaceFlags()<<rfReplaceAll);
  DocSeria = StringReplace(DocSeria, "_", "", TReplaceFlags()<<rfReplaceAll);

  DocNumber = StringReplace(DocNumber, " ", "", TReplaceFlags()<<rfReplaceAll);
  DocNumber = StringReplace(DocNumber, "_", "", TReplaceFlags()<<rfReplaceAll);

  if(DocSeria.Length() > 3 && DocNumber.Length() > 5) //4 ����� ����� � 6 �����
  {
    try
    {
      RegTypes();
      IsBadDoc = (GetIAPO2_ARM_READER(false, APO2_ARM_READER_ADR)->PassportIsBad(DocSeria, DocNumber) == cBadDoc);
      UnRegTypes();
      
      if (IsBadDoc)
        ShowMessage(cWarningBadDoc);
    }
    catch(Exception& ex)
    {
      ShowMessage("��������� ������� �� �������.["+APO2_ARM_READER_ADR+"] " + ex.Message);
    }
  }
  return IsBadDoc;
}
//---------------------------------------------------------------------------

