// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>0
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>1
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>2
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>3
//  >Import : https://ufot.rgs.ru:8443/InspectionProxyService.svc?singleWsdl>4
// Encoding : utf-8
// Version  : 1.0
// (16.02.2017 17:51:45 - - $Rev: 16699 $)
// ************************************************************************ //

#ifndef   InspectionProxyServiceH
#define   InspectionProxyServiceH

#include <System.hpp>
#include <InvokeRegistry.hpp>
#include <XSBuiltIns.hpp>
#include <SOAPHTTPClient.hpp>

#if !defined(SOAP_REMOTABLE_CLASS)
#define SOAP_REMOTABLE_CLASS __declspec(delphiclass)
#endif
#if !defined(IS_OPTN)
#define IS_OPTN 0x0001
#endif
#if !defined(IS_UNBD)
#define IS_UNBD 0x0002
#endif
#if !defined(IS_NLBL)
#define IS_NLBL 0x0004
#endif
#if !defined(IS_REF)
#define IS_REF 0x0080
#endif


namespace NS_InspectionProxyService {

// ************************************************************************ //
// The following types, referred to in the WSDL document are not being represented
// in this file. They are either aliases[@] of other types represented or were referred
// to but never[!] declared in the document. The types from the latter category
// typically map to predefined/known XML or Borland types; however, they could also 
// indicate incorrect WSDL documents that failed to declare or import a schema type.
// ************************************************************************ //
// !:string          - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:dateTime        - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:int             - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:double          - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:boolean         - "http://www.w3.org/2001/XMLSchema"[Gbl]

class SOAP_REMOTABLE_CLASS User;
class SOAP_REMOTABLE_CLASS Inspection;
class SOAP_REMOTABLE_CLASS InspectionDocumentInput;
class SOAP_REMOTABLE_CLASS InspectionDocument;
class SOAP_REMOTABLE_CLASS ImgMetaData;
class SOAP_REMOTABLE_CLASS HistoryItem;
class SOAP_REMOTABLE_CLASS SearchParameters;
class SOAP_REMOTABLE_CLASS User2;
class SOAP_REMOTABLE_CLASS Inspection2;
class SOAP_REMOTABLE_CLASS InspectionDocument2;
class SOAP_REMOTABLE_CLASS InspectionDocumentInput2;
class SOAP_REMOTABLE_CLASS ImgMetaData2;
class SOAP_REMOTABLE_CLASS HistoryItem2;
class SOAP_REMOTABLE_CLASS SearchParameters2;
class SOAP_REMOTABLE_CLASS OperationResultOfInspectionDocumentoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfInspectionoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfboolean;
class SOAP_REMOTABLE_CLASS OperationResultOfInspectionoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfguid;
class SOAP_REMOTABLE_CLASS OperationResultOfdateTime;
class SOAP_REMOTABLE_CLASS OperationResultOfdateTime2;
class SOAP_REMOTABLE_CLASS OperationResultOfguid2;
class SOAP_REMOTABLE_CLASS OperationResultOfInspectionoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfboolean2;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfInspectionoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfInspectionDocumentoTurZuT32;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringArrayOfstringty7Ep6D1;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringstring;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringArrayOfstringty7Ep6D12;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringstring2;



// ************************************************************************ //
// XML       : User, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class User : public TRemotable {
private:
  WideString   FPassword;
  WideString   FUserName;
__published:
  __property WideString   Password = { index=(IS_NLBL), read=FPassword, write=FPassword };
  __property WideString   UserName = { index=(IS_NLBL), read=FUserName, write=FUserName };
};


typedef WideString guid; /* "http://schemas.microsoft.com/2003/10/Serialization/"[GblSmpl] */
typedef DynamicArray<InspectionDocument*> ArrayOfInspectionDocument; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<HistoryItem*> ArrayOfHistoryItem; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : Inspection, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Inspection : public TRemotable {
private:
  WideString   FAutoId;
  bool            FAutoId_Specified;
  guid            FContractId;
  bool            FContractId_Specified;
  TXSDateTime*    FCreationDate;
  bool            FCreationDate_Specified;
  ArrayOfInspectionDocument FDocuments;
  bool            FDocuments_Specified;
  ArrayOfHistoryItem FHistory;
  bool            FHistory_Specified;
  guid            FId;
  bool            FId_Specified;
  int             FStatusId;
  bool            FStatusId_Specified;
  void __fastcall SetAutoId(int Index, WideString _prop_val)
  {  FAutoId = _prop_val; FAutoId_Specified = true;  }
  bool __fastcall AutoId_Specified(int Index)
  {  return FAutoId_Specified;  } 
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
  void __fastcall SetCreationDate(int Index, TXSDateTime* _prop_val)
  {  FCreationDate = _prop_val; FCreationDate_Specified = true;  }
  bool __fastcall CreationDate_Specified(int Index)
  {  return FCreationDate_Specified;  } 
  void __fastcall SetDocuments(int Index, ArrayOfInspectionDocument _prop_val)
  {  FDocuments = _prop_val; FDocuments_Specified = true;  }
  bool __fastcall Documents_Specified(int Index)
  {  return FDocuments_Specified;  } 
  void __fastcall SetHistory(int Index, ArrayOfHistoryItem _prop_val)
  {  FHistory = _prop_val; FHistory_Specified = true;  }
  bool __fastcall History_Specified(int Index)
  {  return FHistory_Specified;  } 
  void __fastcall SetId(int Index, guid _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetStatusId(int Index, int _prop_val)
  {  FStatusId = _prop_val; FStatusId_Specified = true;  }
  bool __fastcall StatusId_Specified(int Index)
  {  return FStatusId_Specified;  } 

public:
  __fastcall ~Inspection();
__published:
  __property WideString     AutoId = { index=(IS_OPTN|IS_NLBL), read=FAutoId, write=SetAutoId, stored = AutoId_Specified };
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
  __property TXSDateTime* CreationDate = { index=(IS_OPTN), read=FCreationDate, write=SetCreationDate, stored = CreationDate_Specified };
  __property ArrayOfInspectionDocument  Documents = { index=(IS_OPTN|IS_NLBL), read=FDocuments, write=SetDocuments, stored = Documents_Specified };
  __property ArrayOfHistoryItem    History = { index=(IS_OPTN|IS_NLBL), read=FHistory, write=SetHistory, stored = History_Specified };
  __property guid               Id = { index=(IS_OPTN), read=FId, write=SetId, stored = Id_Specified };
  __property int          StatusId = { index=(IS_OPTN), read=FStatusId, write=SetStatusId, stored = StatusId_Specified };
};




// ************************************************************************ //
// XML       : InspectionDocumentInput, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InspectionDocumentInput : public TRemotable {
private:
  WideString   FDataBase64;
  bool            FDataBase64_Specified;
  WideString   FName;
  bool            FName_Specified;
  void __fastcall SetDataBase64(int Index, WideString _prop_val)
  {  FDataBase64 = _prop_val; FDataBase64_Specified = true;  }
  bool __fastcall DataBase64_Specified(int Index)
  {  return FDataBase64_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
__published:
  __property WideString DataBase64 = { index=(IS_OPTN|IS_NLBL), read=FDataBase64, write=SetDataBase64, stored = DataBase64_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
};




// ************************************************************************ //
// XML       : InspectionDocument, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InspectionDocument : public InspectionDocumentInput {
private:
  WideString   FFileKey;
  bool            FFileKey_Specified;
  int             FFileSize;
  bool            FFileSize_Specified;
  guid            FId;
  bool            FId_Specified;
  TXSDateTime*    FLoadDate;
  bool            FLoadDate_Specified;
  ImgMetaData*    FMetaData;
  bool            FMetaData_Specified;
  TXSDateTime*    FModificationDate;
  bool            FModificationDate_Specified;
  void __fastcall SetFileKey(int Index, WideString _prop_val)
  {  FFileKey = _prop_val; FFileKey_Specified = true;  }
  bool __fastcall FileKey_Specified(int Index)
  {  return FFileKey_Specified;  } 
  void __fastcall SetFileSize(int Index, int _prop_val)
  {  FFileSize = _prop_val; FFileSize_Specified = true;  }
  bool __fastcall FileSize_Specified(int Index)
  {  return FFileSize_Specified;  } 
  void __fastcall SetId(int Index, guid _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetLoadDate(int Index, TXSDateTime* _prop_val)
  {  FLoadDate = _prop_val; FLoadDate_Specified = true;  }
  bool __fastcall LoadDate_Specified(int Index)
  {  return FLoadDate_Specified;  } 
  void __fastcall SetMetaData(int Index, ImgMetaData* _prop_val)
  {  FMetaData = _prop_val; FMetaData_Specified = true;  }
  bool __fastcall MetaData_Specified(int Index)
  {  return FMetaData_Specified;  } 
  void __fastcall SetModificationDate(int Index, TXSDateTime* _prop_val)
  {  FModificationDate = _prop_val; FModificationDate_Specified = true;  }
  bool __fastcall ModificationDate_Specified(int Index)
  {  return FModificationDate_Specified;  } 

public:
  __fastcall ~InspectionDocument();
__published:
  __property WideString    FileKey = { index=(IS_OPTN|IS_NLBL), read=FFileKey, write=SetFileKey, stored = FileKey_Specified };
  __property int          FileSize = { index=(IS_OPTN), read=FFileSize, write=SetFileSize, stored = FileSize_Specified };
  __property guid               Id = { index=(IS_OPTN), read=FId, write=SetId, stored = Id_Specified };
  __property TXSDateTime*   LoadDate = { index=(IS_OPTN), read=FLoadDate, write=SetLoadDate, stored = LoadDate_Specified };
  __property ImgMetaData*   MetaData = { index=(IS_OPTN|IS_NLBL), read=FMetaData, write=SetMetaData, stored = MetaData_Specified };
  __property TXSDateTime* ModificationDate = { index=(IS_OPTN), read=FModificationDate, write=SetModificationDate, stored = ModificationDate_Specified };
};




// ************************************************************************ //
// XML       : ImgMetaData, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ImgMetaData : public TRemotable {
private:
  WideString   FDeviceName;
  bool            FDeviceName_Specified;
  int             FHeight;
  bool            FHeight_Specified;
  double          FLatitude;
  bool            FLatitude_Specified;
  double          FLongtitude;
  bool            FLongtitude_Specified;
  int             FWidth;
  bool            FWidth_Specified;
  void __fastcall SetDeviceName(int Index, WideString _prop_val)
  {  FDeviceName = _prop_val; FDeviceName_Specified = true;  }
  bool __fastcall DeviceName_Specified(int Index)
  {  return FDeviceName_Specified;  } 
  void __fastcall SetHeight(int Index, int _prop_val)
  {  FHeight = _prop_val; FHeight_Specified = true;  }
  bool __fastcall Height_Specified(int Index)
  {  return FHeight_Specified;  } 
  void __fastcall SetLatitude(int Index, double _prop_val)
  {  FLatitude = _prop_val; FLatitude_Specified = true;  }
  bool __fastcall Latitude_Specified(int Index)
  {  return FLatitude_Specified;  } 
  void __fastcall SetLongtitude(int Index, double _prop_val)
  {  FLongtitude = _prop_val; FLongtitude_Specified = true;  }
  bool __fastcall Longtitude_Specified(int Index)
  {  return FLongtitude_Specified;  } 
  void __fastcall SetWidth(int Index, int _prop_val)
  {  FWidth = _prop_val; FWidth_Specified = true;  }
  bool __fastcall Width_Specified(int Index)
  {  return FWidth_Specified;  } 
__published:
  __property WideString DeviceName = { index=(IS_OPTN|IS_NLBL), read=FDeviceName, write=SetDeviceName, stored = DeviceName_Specified };
  __property int            Height = { index=(IS_OPTN|IS_NLBL), read=FHeight, write=SetHeight, stored = Height_Specified };
  __property double       Latitude = { index=(IS_OPTN|IS_NLBL), read=FLatitude, write=SetLatitude, stored = Latitude_Specified };
  __property double     Longtitude = { index=(IS_OPTN|IS_NLBL), read=FLongtitude, write=SetLongtitude, stored = Longtitude_Specified };
  __property int             Width = { index=(IS_OPTN|IS_NLBL), read=FWidth, write=SetWidth, stored = Width_Specified };
};




// ************************************************************************ //
// XML       : HistoryItem, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class HistoryItem : public TRemotable {
private:
  TXSDateTime*    FDate;
  bool            FDate_Specified;
  WideString   FText;
  bool            FText_Specified;
  void __fastcall SetDate(int Index, TXSDateTime* _prop_val)
  {  FDate = _prop_val; FDate_Specified = true;  }
  bool __fastcall Date_Specified(int Index)
  {  return FDate_Specified;  } 
  void __fastcall SetText(int Index, WideString _prop_val)
  {  FText = _prop_val; FText_Specified = true;  }
  bool __fastcall Text_Specified(int Index)
  {  return FText_Specified;  } 

public:
  __fastcall ~HistoryItem();
__published:
  __property TXSDateTime*       Date = { index=(IS_OPTN), read=FDate, write=SetDate, stored = Date_Specified };
  __property WideString       Text = { index=(IS_OPTN|IS_NLBL), read=FText, write=SetText, stored = Text_Specified };
};




// ************************************************************************ //
// XML       : SearchParameters, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class SearchParameters : public TRemotable {
private:
  guid            FContractId;
__published:
  __property guid       ContractId = { read=FContractId, write=FContractId };
};


typedef DynamicArray<Inspection*> ArrayOfInspection; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : User, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class User2 : public User {
private:
__published:
};




// ************************************************************************ //
// XML       : Inspection, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Inspection2 : public Inspection {
private:
__published:
};




// ************************************************************************ //
// XML       : InspectionDocument, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InspectionDocument2 : public InspectionDocument {
private:
__published:
};




// ************************************************************************ //
// XML       : InspectionDocumentInput, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class InspectionDocumentInput2 : public InspectionDocumentInput {
private:
__published:
};




// ************************************************************************ //
// XML       : ImgMetaData, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ImgMetaData2 : public ImgMetaData {
private:
__published:
};




// ************************************************************************ //
// XML       : HistoryItem, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class HistoryItem2 : public HistoryItem {
private:
__published:
};




// ************************************************************************ //
// XML       : SearchParameters, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class SearchParameters2 : public SearchParameters {
private:
__published:
};


typedef DynamicArray<KeyValuePairOfstringArrayOfstringty7Ep6D1*> ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */
typedef DynamicArray<KeyValuePairOfstringstring*> ArrayOfKeyValuePairOfstringstring; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */
typedef DynamicArray<WideString> ArrayOfstring;  /* "http://schemas.microsoft.com/2003/10/Serialization/Arrays"[GblCplx] */


// ************************************************************************ //
// XML       : OperationResultOfInspectionDocumentoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfInspectionDocumentoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  InspectionDocument* FData;
  bool            FData_Specified;
  WideString   FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString   FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, InspectionDocument* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfInspectionDocumentoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property InspectionDocument*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfArrayOfInspectionoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfInspectionoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  ArrayOfInspection FData;
  bool            FData_Specified;
  WideString   FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString   FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, ArrayOfInspection _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfArrayOfInspectionoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property ArrayOfInspection       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfboolean, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfboolean : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  bool            FData;
  bool            FData_Specified;
  WideString   FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString   FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, bool _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfboolean();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property bool             Data = { index=(IS_OPTN), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfInspectionoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfInspectionoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  Inspection*     FData;
  bool            FData_Specified;
  WideString   FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString   FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, Inspection* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfInspectionoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property Inspection*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfguid, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfguid : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  guid            FData;
  bool            FData_Specified;
  WideString   FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString   FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, guid _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfguid();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property guid             Data = { index=(IS_OPTN), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfdateTime, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfdateTime : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  TXSDateTime*    FData;
  bool            FData_Specified;
  WideString   FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString   FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, TXSDateTime* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 

public:
  __fastcall ~OperationResultOfdateTime();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property TXSDateTime*       Data = { index=(IS_OPTN), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfdateTime, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfdateTime2 : public OperationResultOfdateTime {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfguid, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfguid2 : public OperationResultOfguid {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfInspectionoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfInspectionoTurZuT32 : public OperationResultOfInspectionoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfboolean, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfboolean2 : public OperationResultOfboolean {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfArrayOfInspectionoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfInspectionoTurZuT32 : public OperationResultOfArrayOfInspectionoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfInspectionDocumentoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfInspectionDocumentoTurZuT32 : public OperationResultOfInspectionDocumentoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringArrayOfstringty7Ep6D1, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringArrayOfstringty7Ep6D1 : public TRemotable {
private:
  WideString   Fkey;
  ArrayOfstring   Fvalue;
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property ArrayOfstring      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringstring, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringstring : public TRemotable {
private:
  WideString   Fkey;
  WideString   Fvalue;
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property WideString      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringArrayOfstringty7Ep6D1, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringArrayOfstringty7Ep6D12 : public KeyValuePairOfstringArrayOfstringty7Ep6D1 {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringstring, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringstring2 : public KeyValuePairOfstringstring {
private:
__published:
};



// ************************************************************************ //
// Namespace : Rgs.Ufo
// soapAction: Rgs.Ufo/IInspectionProxyService/%operationName%
// transport : http://schemas.xmlsoap.org/soap/http
// style     : document
// binding   : BasicHttpsBinding_IInspectionProxyService
// service   : InspectionProxyService
// port      : BasicHttpsBinding_IInspectionProxyService
// URL       : https://ufot.rgs.ru:8443/InspectionProxyService.svc
// ************************************************************************ //
__interface INTERFACE_UUID("{7A454E6E-91CB-0A06-4BD1-521CF4F8B42B}") IInspectionProxyService : public IInvokable
{
public:
  virtual OperationResultOfdateTime* Ping(const User* user) = 0; 
  virtual OperationResultOfguid* Create(const User* user, const guid contractId, const WideString autoId) = 0;
  virtual OperationResultOfInspectionoTurZuT3* Get(const User* user, const guid inspectionId) = 0; 
  virtual OperationResultOfboolean* ChangeStatus(const User* user, const guid inspectionId, const int statusId) = 0; 
  virtual OperationResultOfArrayOfInspectionoTurZuT3* Search(const User* user, const SearchParameters* searchParameters) = 0; 
  virtual OperationResultOfguid* AddDocument(const User* user, const guid inspectionId, const InspectionDocumentInput* document) = 0; 
  virtual OperationResultOfInspectionDocumentoTurZuT3* GetDocument(const User* user, const guid documentId) = 0; 
};
typedef DelphiInterface<IInspectionProxyService> _di_IInspectionProxyService;

_di_IInspectionProxyService GetIInspectionProxyService(bool useWSDL=false, AnsiString addr="", THTTPRIO* HTTPRIO=0);


};     // NS_InspectionProxyService

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace NS_InspectionProxyService;
#endif



#endif // InspectionProxyServiceH
