// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sAlphaListBox.pas' rev: 6.00

#ifndef sAlphaListBoxHPP
#define sAlphaListBoxHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <Types.hpp>	// Pascal unit
#include <acSBUtils.hpp>	// Pascal unit
#include <CommCtrl.hpp>	// Pascal unit
#include <sDefaults.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <sCommonData.hpp>	// Pascal unit
#include <Consts.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Salphalistbox
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsAlphaListBox;
class PASCALIMPLEMENTATION TsAlphaListBox : public Controls::TWinControl 
{
	typedef Controls::TWinControl inherited;
	
private:
	int FCount;
	int FOldCount;
	AnsiString FFilter;
	unsigned FLastTime;
	Classes::TStrings* FItems;
	Forms::TFormBorderStyle FBorderStyle;
	Graphics::TCanvas* FCanvas;
	int FColumns;
	int FItemHeight;
	Stdctrls::TListBoxStyle FStyle;
	bool FIntegralHeight;
	bool FMultiSelect;
	bool FSorted;
	bool FExtendedSelect;
	int FTabWidth;
	Classes::TStringList* FSaveItems;
	int FSaveTopIndex;
	int FSaveItemIndex;
	Stdctrls::TDrawItemEvent FOnDrawItem;
	Stdctrls::TMeasureItemEvent FOnMeasureItem;
	Scommondata::TsCommonData* FCommonData;
	Classes::TNotifyEvent FOnVScroll;
	Sconst::TsDisabledKind FDisabledKind;
	Scommondata::TsBoundLabel* FBoundLabel;
	Stdctrls::TLBFindDataEvent FOnDataFind;
	Stdctrls::TLBGetDataEvent FOnData;
	Stdctrls::TLBGetDataObjectEvent FOnDataObject;
	bool FAutoComplete;
	bool FAutoHideScroll;
	Word FAutoCompleteDelay;
	int __fastcall GetItemHeight(void);
	int __fastcall GetItemIndex(void);
	int __fastcall GetSelCount(void);
	bool __fastcall GetSelected(int Index);
	int __fastcall GetTopIndex(void);
	void __fastcall SetBorderStyle(Forms::TBorderStyle Value);
	void __fastcall SetColumnWidth(void);
	void __fastcall SetColumns(int Value);
	void __fastcall SetExtendedSelect(bool Value);
	void __fastcall SetIntegralHeight(bool Value);
	void __fastcall SetItemHeight(int Value);
	void __fastcall SetItems(Classes::TStrings* Value);
	void __fastcall SetItemIndex(int Value);
	void __fastcall SetMultiSelect(bool Value);
	void __fastcall SetSelected(int Index, bool Value);
	void __fastcall SetSorted(bool Value);
	void __fastcall SetStyle(Stdctrls::TListBoxStyle Value);
	void __fastcall SetTabWidth(int Value);
	void __fastcall SetTopIndex(int Value);
	MESSAGE void __fastcall CNCommand(Messages::TWMCommand &Message);
	MESSAGE void __fastcall CNDrawItem(Messages::TWMDrawItem &Message);
	MESSAGE void __fastcall CNMeasureItem(Messages::TWMMeasureItem &Message);
	HIDESBASE MESSAGE void __fastcall CMCtl3DChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMNCCalcSize(Messages::TWMNCCalcSize &Message);
	HIDESBASE MESSAGE void __fastcall WMEraseBkgnd(Messages::TWMPaint &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDown(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonUp(Messages::TMessage &Message);
	void __fastcall SetDisabledKind(const Sconst::TsDisabledKind Value);
	MESSAGE void __fastcall WMPrint(Messages::TWMPaint &Message);
	MESSAGE void __fastcall LBGetText(Messages::TMessage &Message);
	MESSAGE void __fastcall LBGetTextLen(Messages::TMessage &Message);
	int __fastcall GetCount(void);
	void __fastcall SetCount(const int Value);
	void __fastcall SetAutoHideScroll(const bool Value);
	int __fastcall GetScrollWidth(void);
	void __fastcall SetScrollWidth(const int Value);
	
protected:
	bool FMoving;
	int FTopIndex;
	Acsbutils::TacScrollWnd* ListSW;
	AnsiString __fastcall DoGetData(const int Index);
	System::TObject* __fastcall DoGetDataObject(const int Index);
	int __fastcall DoFindData(const AnsiString Data);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall PrepareCache(void);
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	virtual void __fastcall CreateWnd(void);
	virtual void __fastcall DestroyWnd(void);
	DYNAMIC void __fastcall DragCanceled(void);
	virtual void __fastcall MeasureItem(int Index, int &Height);
	DYNAMIC int __fastcall InternalGetItemData(int Index);
	DYNAMIC void __fastcall InternalSetItemData(int Index, int AData);
	DYNAMIC int __fastcall GetItemData(int Index);
	int __fastcall VisibleRows(void);
	DYNAMIC void __fastcall SetItemData(int Index, int AData);
	DYNAMIC void __fastcall ResetContent(void);
	DYNAMIC void __fastcall DeleteString(int Index);
	__property bool ExtendedSelect = {read=FExtendedSelect, write=SetExtendedSelect, default=1};
	virtual void __fastcall DrawItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	
public:
	virtual void __fastcall AfterConstruction(void);
	virtual void __fastcall AddItem(AnsiString Item, System::TObject* AObject);
	void __fastcall DeleteSelected(void);
	void __fastcall ClearSelection(void);
	virtual void __fastcall Loaded(void);
	__fastcall virtual TsAlphaListBox(Classes::TComponent* AOwner);
	__fastcall virtual ~TsAlphaListBox(void);
	void __fastcall Clear(void);
	int __fastcall ItemAtPos(const Types::TPoint &Pos, bool Existing);
	Types::TRect __fastcall ItemRect(int Index);
	void __fastcall RepaintItem(int Index);
	__property Graphics::TCanvas* Canvas = {read=FCanvas};
	__property int ItemIndex = {read=GetItemIndex, write=SetItemIndex, nodefault};
	__property int SelCount = {read=GetSelCount, nodefault};
	__property bool Selected[int Index] = {read=GetSelected, write=SetSelected};
	__property int TopIndex = {read=GetTopIndex, write=SetTopIndex, nodefault};
	__property bool MultiSelect = {read=FMultiSelect, write=SetMultiSelect, default=0};
	__property int ScrollWidth = {read=GetScrollWidth, write=SetScrollWidth, default=0};
	__property int Count = {read=GetCount, write=SetCount, nodefault};
	
__published:
	__property Word AutoCompleteDelay = {read=FAutoCompleteDelay, write=FAutoCompleteDelay, nodefault};
	__property bool AutoComplete = {read=FAutoComplete, write=FAutoComplete, default=1};
	__property Forms::TBorderStyle BorderStyle = {read=FBorderStyle, write=SetBorderStyle, default=1};
	__property Scommondata::TsBoundLabel* BoundLabel = {read=FBoundLabel, write=FBoundLabel};
	__property int Columns = {read=FColumns, write=SetColumns, default=0};
	__property Scommondata::TsCommonData* SkinData = {read=FCommonData, write=FCommonData};
	__property Sconst::TsDisabledKind DisabledKind = {read=FDisabledKind, write=SetDisabledKind, default=1};
	__property bool IntegralHeight = {read=FIntegralHeight, write=SetIntegralHeight, default=0};
	__property int ItemHeight = {read=GetItemHeight, write=SetItemHeight, nodefault};
	__property Classes::TStrings* Items = {read=FItems, write=SetItems};
	__property bool Sorted = {read=FSorted, write=SetSorted, default=0};
	__property Stdctrls::TListBoxStyle Style = {read=FStyle, write=SetStyle, default=0};
	__property int TabWidth = {read=FTabWidth, write=SetTabWidth, default=0};
	__property bool AutoHideScroll = {read=FAutoHideScroll, write=SetAutoHideScroll, default=1};
	__property Stdctrls::TLBGetDataEvent OnData = {read=FOnData, write=FOnData};
	__property Stdctrls::TLBGetDataObjectEvent OnDataObject = {read=FOnDataObject, write=FOnDataObject};
	__property Stdctrls::TLBFindDataEvent OnDataFind = {read=FOnDataFind, write=FOnDataFind};
	__property Stdctrls::TDrawItemEvent OnDrawItem = {read=FOnDrawItem, write=FOnDrawItem};
	__property Stdctrls::TMeasureItemEvent OnMeasureItem = {read=FOnMeasureItem, write=FOnMeasureItem};
	__property Classes::TNotifyEvent OnVScroll = {read=FOnVScroll, write=FOnVScroll};
	__property Align  = {default=0};
	__property Anchors  = {default=3};
	__property BiDiMode ;
	__property Color  = {default=-2147483643};
	__property Constraints ;
	__property Ctl3D ;
	__property DragCursor  = {default=-12};
	__property DragKind  = {default=0};
	__property DragMode  = {default=0};
	__property Enabled  = {default=1};
	__property Font ;
	__property ImeMode  = {default=3};
	__property ImeName ;
	__property ParentBiDiMode  = {default=1};
	__property ParentColor  = {default=0};
	__property ParentCtl3D  = {default=1};
	__property ParentFont  = {default=1};
	__property ParentShowHint  = {default=1};
	__property PopupMenu ;
	__property ShowHint ;
	__property TabOrder  = {default=-1};
	__property TabStop  = {default=1};
	__property Visible  = {default=1};
	__property OnClick ;
	__property OnContextPopup ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDock ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDock ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsAlphaListBox(HWND ParentWindow) : Controls::TWinControl(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TsListBox;
class PASCALIMPLEMENTATION TsListBox : public TsAlphaListBox 
{
	typedef TsAlphaListBox inherited;
	
__published:
	__property MultiSelect  = {default=0};
	__property ExtendedSelect  = {default=1};
public:
	#pragma option push -w-inl
	/* TsAlphaListBox.Create */ inline __fastcall virtual TsListBox(Classes::TComponent* AOwner) : TsAlphaListBox(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsAlphaListBox.Destroy */ inline __fastcall virtual ~TsListBox(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsListBox(HWND ParentWindow) : TsAlphaListBox(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool mPressed;
extern PACKAGE bool ScrollsUpdating;

}	/* namespace Salphalistbox */
using namespace Salphalistbox;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// sAlphaListBox
