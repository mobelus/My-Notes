// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sComboBoxes.pas' rev: 6.00

#ifndef sComboBoxesHPP
#define sComboBoxesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <sDialogs.hpp>	// Pascal unit
#include <acSBUtils.hpp>	// Pascal unit
#include <sComboBox.hpp>	// Pascal unit
#include <sDefaults.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <sCommonData.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <Types.hpp>	// Pascal unit
#include <sGraphUtils.hpp>	// Pascal unit
#include <acntUtils.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <ToolWin.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Scomboboxes
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TsCustomComboBoxStrings;
class DELPHICLASS TsCommonCombo;
class DELPHICLASS TsCustomListControl;
class PASCALIMPLEMENTATION TsCustomListControl : public Controls::TWinControl 
{
	typedef Controls::TWinControl inherited;
	
private:
	Scommondata::TsBoundLabel* FBoundLabel;
	
protected:
	Scommondata::TsCommonData* FCommonData;
	virtual int __fastcall GetCount(void) = 0 ;
	virtual int __fastcall GetItemIndex(void) = 0 ;
	virtual void __fastcall SetItemIndex(const int Value) = 0 /* overload */;
	virtual void __fastcall Loaded(void);
	
public:
	virtual void __fastcall AfterConstruction(void);
	virtual void __fastcall AddItem(AnsiString Item, System::TObject* AObject) = 0 ;
	virtual void __fastcall Clear(void) = 0 ;
	virtual void __fastcall ClearSelection(void) = 0 ;
	__fastcall virtual TsCustomListControl(Classes::TComponent* AOwner);
	__fastcall virtual ~TsCustomListControl(void);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	virtual void __fastcall CopySelection(TsCustomListControl* Destination) = 0 ;
	virtual void __fastcall DeleteSelected(void) = 0 ;
	virtual void __fastcall MoveSelection(TsCustomListControl* Destination);
	virtual void __fastcall SelectAll(void) = 0 ;
	__property Scommondata::TsCommonData* SkinData = {read=FCommonData, write=FCommonData};
	__property int ItemIndex = {read=GetItemIndex, write=SetItemIndex, nodefault};
	
__published:
	__property Scommondata::TsBoundLabel* BoundLabel = {read=FBoundLabel, write=FBoundLabel};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsCustomListControl(HWND ParentWindow) : Controls::TWinControl(ParentWindow) { }
	#pragma option pop
	
};


typedef TMetaClass*TsCustomComboBoxStringsClass;

class PASCALIMPLEMENTATION TsCommonCombo : public TsCustomListControl 
{
	typedef TsCustomListControl inherited;
	
private:
	Graphics::TCanvas* FCanvas;
	int FMaxLength;
	int FDropDownCount;
	int FItemIndex;
	Classes::TNotifyEvent FOnChange;
	Classes::TNotifyEvent FOnSelect;
	Classes::TNotifyEvent FOnDropDown;
	Classes::TNotifyEvent FOnCloseUp;
	int FItemHeight;
	Classes::TStrings* FItems;
	Stdctrls::TMeasureItemEvent FOnMeasureItem;
	bool FShowButton;
	MESSAGE void __fastcall WMCreate(Messages::TWMCreate &Message);
	MESSAGE void __fastcall CMCancelMode(Controls::TCMCancelMode &Message);
	HIDESBASE MESSAGE void __fastcall CMCtl3DChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CNCommand(Messages::TWMCommand &Message);
	HIDESBASE MESSAGE void __fastcall WMDrawItem(Messages::TWMDrawItem &Message);
	HIDESBASE MESSAGE void __fastcall WMDeleteItem(Messages::TWMDeleteItem &Message);
	MESSAGE void __fastcall WMGetDlgCode(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall CNMeasureItem(Messages::TWMMeasureItem &Message);
	virtual void __fastcall MeasureItem(int Index, int &Height);
	void __fastcall SetShowButton(const bool Value);
	
protected:
	HWND lboxhandle;
	Acsbutils::TacScrollWnd* ListSW;
	HWND FListHandle;
	HWND FDropHandle;
	void *FEditInstance;
	void *FDefEditProc;
	void *FListInstance;
	void *FDefListProc;
	bool FDroppingDown;
	bool FFocusChanged;
	bool FIsFocused;
	int FSaveIndex;
	virtual void __fastcall AdjustDropDown(void);
	virtual void __fastcall ComboWndProc(Messages::TMessage &Message, HWND ComboWnd, void * ComboProc);
	void __fastcall EditWndProc(Messages::TMessage &Message);
	virtual TMetaClass* __fastcall GetItemsClass(void) = 0 ;
	virtual int __fastcall GetItemHt(void) = 0 ;
	virtual void __fastcall SetItemHeight(int Value);
	virtual int __fastcall GetCount(void);
	virtual int __fastcall GetItemCount(void) = 0 ;
	virtual int __fastcall GetItemIndex(void);
	bool __fastcall GetDroppedDown(void);
	int __fastcall GetSelLength(void);
	int __fastcall GetSelStart(void);
	virtual void __fastcall CreateWnd(void);
	void __fastcall ListWndProc(Messages::TMessage &Message);
	DYNAMIC void __fastcall Change(void);
	DYNAMIC void __fastcall Select(void);
	DYNAMIC void __fastcall DropDown(void);
	DYNAMIC void __fastcall CloseUp(void);
	virtual void __fastcall DestroyWindowHandle(void);
	void __fastcall SetDroppedDown(bool Value);
	void __fastcall SetSelLength(int Value);
	void __fastcall SetSelStart(int Value);
	void __fastcall SetMaxLength(int Value);
	virtual void __fastcall SetDropDownCount(const int Value);
	virtual void __fastcall SetItemIndex(const int Value)/* overload */;
	virtual void __fastcall SetItems(const Classes::TStrings* Value);
	virtual void __fastcall UpdateMargins(void);
	virtual void __fastcall Loaded(void);
	__property int DropDownCount = {read=FDropDownCount, write=SetDropDownCount, default=14};
	__property int ItemCount = {read=GetItemCount, nodefault};
	__property int ItemHeight = {read=GetItemHt, write=SetItemHeight, default=16};
	__property HWND ListHandle = {read=FListHandle, nodefault};
	__property int MaxLength = {read=FMaxLength, write=SetMaxLength, default=0};
	__property ParentColor  = {default=0};
	__property Classes::TNotifyEvent OnChange = {read=FOnChange, write=FOnChange};
	__property Classes::TNotifyEvent OnDropDown = {read=FOnDropDown, write=FOnDropDown};
	__property Classes::TNotifyEvent OnSelect = {read=FOnSelect, write=FOnSelect};
	__property Classes::TNotifyEvent OnCloseUp = {read=FOnCloseUp, write=FOnCloseUp};
	__property Stdctrls::TMeasureItemEvent OnMeasureItem = {read=FOnMeasureItem, write=FOnMeasureItem};
	
public:
	HWND FEditHandle;
	__fastcall virtual TsCommonCombo(Classes::TComponent* AOwner);
	__fastcall virtual ~TsCommonCombo(void);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	virtual void __fastcall AddItem(AnsiString Item, System::TObject* AObject);
	virtual void __fastcall Clear(void);
	virtual void __fastcall ClearSelection(void);
	virtual void __fastcall CopySelection(TsCustomListControl* Destination);
	virtual void __fastcall DeleteSelected(void);
	DYNAMIC bool __fastcall Focused(void);
	virtual void __fastcall PaintButton(void);
	Types::TRect __fastcall ButtonRect();
	virtual void __fastcall SelectAll(void);
	__property HWND EditHandle = {read=FEditHandle, nodefault};
	__property Graphics::TCanvas* Canvas = {read=FCanvas};
	__property bool DroppedDown = {read=GetDroppedDown, write=SetDroppedDown, nodefault};
	__property Classes::TStrings* Items = {read=FItems, write=SetItems};
	__property int SelLength = {read=GetSelLength, write=SetSelLength, nodefault};
	__property int SelStart = {read=GetSelStart, write=SetSelStart, nodefault};
	__property TabStop  = {default=1};
	__property Height  = {default=22};
	__property bool ShowButton = {read=FShowButton, write=SetShowButton, default=1};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsCommonCombo(HWND ParentWindow) : TsCustomListControl(ParentWindow) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TsCustomComboBoxStrings : public Classes::TStrings 
{
	typedef Classes::TStrings inherited;
	
private:
	TsCommonCombo* FComboBox;
	
protected:
	virtual int __fastcall GetCount(void);
	virtual AnsiString __fastcall Get(int Index);
	virtual System::TObject* __fastcall GetObject(int Index);
	virtual void __fastcall PutObject(int Index, System::TObject* AObject);
	virtual void __fastcall SetUpdateState(bool Updating);
	__property TsCommonCombo* ComboBox = {read=FComboBox, write=FComboBox};
	
public:
	virtual void __fastcall Clear(void);
	virtual void __fastcall Delete(int Index);
	virtual int __fastcall IndexOf(const AnsiString S);
public:
	#pragma option push -w-inl
	/* TStrings.Destroy */ inline __fastcall virtual ~TsCustomComboBoxStrings(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TsCustomComboBoxStrings(void) : Classes::TStrings() { }
	#pragma option pop
	
};


class DELPHICLASS TsComboBoxStrings;
class PASCALIMPLEMENTATION TsComboBoxStrings : public TsCustomComboBoxStrings 
{
	typedef TsCustomComboBoxStrings inherited;
	
public:
	virtual int __fastcall Add(const AnsiString S);
	virtual void __fastcall Insert(int Index, const AnsiString S);
public:
	#pragma option push -w-inl
	/* TStrings.Destroy */ inline __fastcall virtual ~TsComboBoxStrings(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TsComboBoxStrings(void) : TsCustomComboBoxStrings() { }
	#pragma option pop
	
};


class DELPHICLASS TsCommonComboBox;
class PASCALIMPLEMENTATION TsCommonComboBox : public TsCommonCombo 
{
	typedef TsCommonCombo inherited;
	
private:
	bool FAutoComplete;
	bool FAutoDropDown;
	unsigned FLastTime;
	AnsiString FFilter;
	Stdctrls::TEditCharCase FCharCase;
	bool FSorted;
	Stdctrls::TComboBoxStyle FStyle;
	Classes::TStringList* FSaveItems;
	Stdctrls::TDrawItemEvent FOnDrawItem;
	Stdctrls::TMeasureItemEvent FOnMeasureItem;
	Sconst::TsDisabledKind FDisabledKind;
	bool FReadOnly;
	void __fastcall SetCharCase(Stdctrls::TEditCharCase Value);
	void __fastcall SetSelText(const AnsiString Value);
	void __fastcall SetSorted(bool Value);
	HIDESBASE MESSAGE void __fastcall WMEraseBkgnd(Messages::TWMEraseBkgnd &Message);
	HIDESBASE MESSAGE void __fastcall CMParentColorChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CNDrawItem(Messages::TWMDrawItem &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDown(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMPaint(Messages::TWMPaint &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TMessage &Message);
	virtual void __fastcall SkinPaint(HDC DC);
	void __fastcall SetDisabledKind(const Sconst::TsDisabledKind Value);
	
protected:
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	virtual void __fastcall CreateWnd(void);
	virtual void __fastcall DestroyWnd(void);
	virtual void __fastcall DrawItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	virtual void __fastcall DrawSkinItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	virtual int __fastcall GetItemHt(void);
	virtual TMetaClass* __fastcall GetItemsClass(void);
	AnsiString __fastcall GetSelText();
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall MeasureItem(int Index, int &Height);
	bool __fastcall SelectItem(const AnsiString AnItem);
	virtual void __fastcall SetStyle(Stdctrls::TComboBoxStyle Value);
	__property bool Sorted = {read=FSorted, write=SetSorted, default=0};
	__property Stdctrls::TDrawItemEvent OnDrawItem = {read=FOnDrawItem, write=FOnDrawItem};
	__property Stdctrls::TMeasureItemEvent OnMeasureItem = {read=FOnMeasureItem, write=FOnMeasureItem};
	virtual int __fastcall GetItemCount(void);
	
public:
	__property Align  = {default=0};
	__fastcall virtual TsCommonComboBox(Classes::TComponent* AOwner);
	__fastcall virtual ~TsCommonComboBox(void);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	__property Stdctrls::TComboBoxStyle Style = {read=FStyle, write=SetStyle, default=0};
	__property bool AutoComplete = {read=FAutoComplete, write=FAutoComplete, default=1};
	__property bool AutoDropDown = {read=FAutoDropDown, write=FAutoDropDown, default=0};
	__property Stdctrls::TEditCharCase CharCase = {read=FCharCase, write=SetCharCase, default=0};
	__property AnsiString SelText = {read=GetSelText, write=SetSelText};
	__property Sconst::TsDisabledKind DisabledKind = {read=FDisabledKind, write=SetDisabledKind, default=1};
	
__published:
	__property bool ReadOnly = {read=FReadOnly, write=FReadOnly, default=0};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsCommonComboBox(HWND ParentWindow) : TsCommonCombo(ParentWindow) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TsColorBoxStyles { cbStandardColors, cbExtendedColors, cbSystemColors, cbIncludeNone, cbIncludeDefault, cbCustomColor, cbPrettyNames, cbCustomColors };
#pragma option pop

typedef Set<TsColorBoxStyles, cbStandardColors, cbCustomColors>  TsColorBoxStyle;

class DELPHICLASS TsCustomColorBox;
typedef void __fastcall (__closure *TGetColorsEvent)(TsCustomColorBox* Sender, Classes::TStrings* Items);

class PASCALIMPLEMENTATION TsCustomColorBox : public TsCommonComboBox 
{
	typedef TsCommonComboBox inherited;
	
private:
	TsColorBoxStyle FStyle;
	bool FNeedToPopulate;
	bool FListSelected;
	Graphics::TColor FDefaultColorColor;
	Graphics::TColor FNoneColorColor;
	Graphics::TColor FSelectedColor;
	bool FShowColorName;
	int FMargin;
	TGetColorsEvent FOnGetColors;
	Graphics::TColor __fastcall GetColor(int Index);
	AnsiString __fastcall GetColorName(int Index);
	Graphics::TColor __fastcall GetSelected(void);
	void __fastcall SetSelected(const Graphics::TColor AColor);
	void __fastcall ColorCallBack(const AnsiString AName);
	void __fastcall SetDefaultColorColor(const Graphics::TColor Value);
	void __fastcall SetNoneColorColor(const Graphics::TColor Value);
	void __fastcall SetShowColorName(const bool Value);
	void __fastcall SetMargin(const int Value);
	
protected:
	DYNAMIC void __fastcall CloseUp(void);
	Types::TRect __fastcall ColorRect(const Types::TRect &SourceRect, Windows::TOwnerDrawState State);
	virtual void __fastcall CreateWnd(void);
	virtual void __fastcall DrawItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	virtual void __fastcall DrawSkinItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual bool __fastcall PickCustomColor(void);
	void __fastcall PopulateList(void);
	DYNAMIC void __fastcall Select(void);
	HIDESBASE void __fastcall SetStyle(TsColorBoxStyle AStyle);
	
public:
	__fastcall virtual TsCustomColorBox(Classes::TComponent* AOwner);
	__property AnsiString ColorNames[int Index] = {read=GetColorName};
	__property Graphics::TColor Colors[int Index] = {read=GetColor};
	
__published:
	__property TsColorBoxStyle Style = {read=FStyle, write=SetStyle, default=7};
	__property int Margin = {read=FMargin, write=SetMargin, default=0};
	__property Graphics::TColor Selected = {read=GetSelected, write=SetSelected, default=0};
	__property bool ShowColorName = {read=FShowColorName, write=SetShowColorName, default=1};
	__property Graphics::TColor DefaultColorColor = {read=FDefaultColorColor, write=SetDefaultColorColor, default=0};
	__property Graphics::TColor NoneColorColor = {read=FNoneColorColor, write=SetNoneColorColor, default=0};
	__property TGetColorsEvent OnGetColors = {read=FOnGetColors, write=FOnGetColors};
public:
	#pragma option push -w-inl
	/* TsCommonComboBox.Destroy */ inline __fastcall virtual ~TsCustomColorBox(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsCustomColorBox(HWND ParentWindow) : TsCommonComboBox(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TsColorBox;
class PASCALIMPLEMENTATION TsColorBox : public TsCustomColorBox 
{
	typedef TsCustomColorBox inherited;
	
__published:
	__property AutoComplete  = {default=1};
	__property AutoDropDown  = {default=0};
	__property DisabledKind  = {default=1};
	__property Anchors  = {default=3};
	__property BevelEdges  = {default=15};
	__property BevelInner  = {index=0, default=2};
	__property BevelKind  = {default=0};
	__property BevelOuter  = {index=1, default=1};
	__property BiDiMode ;
	__property Color  = {default=-2147483643};
	__property Constraints ;
	__property Ctl3D ;
	__property DropDownCount  = {default=14};
	__property Enabled  = {default=1};
	__property Font ;
	__property ItemHeight  = {default=16};
	__property ParentBiDiMode  = {default=1};
	__property ParentColor  = {default=0};
	__property ParentCtl3D  = {default=1};
	__property ParentFont  = {default=1};
	__property ParentShowHint  = {default=1};
	__property PopupMenu ;
	__property ShowHint ;
	__property TabOrder  = {default=-1};
	__property TabStop  = {default=1};
	__property Visible  = {default=1};
	__property OnChange ;
	__property OnCloseUp ;
	__property OnClick ;
	__property OnContextPopup ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnDropDown ;
	__property OnEndDock ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseUp ;
	__property OnSelect ;
	__property OnStartDock ;
	__property OnStartDrag ;
	__property Style  = {default=7};
	__property Margin  = {default=0};
	__property Selected  = {default=0};
	__property ShowColorName  = {default=1};
	__property DefaultColorColor  = {default=0};
	__property NoneColorColor  = {default=0};
	__property SkinData ;
public:
	#pragma option push -w-inl
	/* TsCustomColorBox.Create */ inline __fastcall virtual TsColorBox(Classes::TComponent* AOwner) : TsCustomColorBox(AOwner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TsCommonComboBox.Destroy */ inline __fastcall virtual ~TsColorBox(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsColorBox(HWND ParentWindow) : TsCustomColorBox(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TsComboItems;
class DELPHICLASS TsCustomComboBoxEx;
class DELPHICLASS TsComboItem;
class PASCALIMPLEMENTATION TsCustomComboBoxEx : public TsCommonComboBox 
{
	typedef TsCommonComboBox inherited;
	
private:
	Imglist::TChangeLink* FImageChangeLink;
	Imglist::TCustomImageList* FImages;
	TsComboItems* FItemsEx;
	bool NeedToUpdate;
	void __fastcall ImageListChange(System::TObject* Sender);
	void __fastcall SetImages(const Imglist::TCustomImageList* Value);
	void __fastcall SetItemsEx(const TsComboItems* Value);
	TsComboItem* __fastcall GetSelectedItem(void);
	
protected:
	virtual void __fastcall DrawItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	virtual void __fastcall DrawSkinItem(int Index, const Types::TRect &Rect, Windows::TOwnerDrawState State);
	Types::TRect __fastcall ImgRect(TsComboItem* Item, Windows::TOwnerDrawState State);
	int __fastcall CurrentImage(TsComboItem* Item, Windows::TOwnerDrawState State);
	
public:
	virtual void __fastcall Clear(void);
	void __fastcall UpdateList(void);
	__fastcall virtual TsCustomComboBoxEx(Classes::TComponent* AOwner);
	__fastcall virtual ~TsCustomComboBoxEx(void);
	virtual void __fastcall CreateWnd(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall UpdateMargins(void);
	__property Imglist::TCustomImageList* Images = {read=FImages, write=SetImages};
	__property TsComboItems* ItemsEx = {read=FItemsEx, write=SetItemsEx};
	__property TsComboItem* SelectedItem = {read=GetSelectedItem};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsCustomComboBoxEx(HWND ParentWindow) : TsCommonComboBox(ParentWindow) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TsComboItems : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TsComboItem* operator[](int Index) { return Items[Index]; }
	
private:
	TsCustomComboBoxEx* FOwner;
	HIDESBASE TsComboItem* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsComboItem* Value);
	
protected:
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	
public:
	HIDESBASE TsComboItem* __fastcall Add(void);
	TsComboItem* __fastcall AddItem(const AnsiString Caption, const int ImageIndex, const int SelectedImageIndex, const int OverlayImageIndex, const int Indent, void * Data);
	__fastcall TsComboItems(TsCustomComboBoxEx* AOwner);
	__fastcall virtual ~TsComboItems(void);
	__property TsComboItem* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
};


class PASCALIMPLEMENTATION TsComboItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FCaption;
	Imglist::TImageIndex FSelectedImageIndex;
	Imglist::TImageIndex FImageIndex;
	Imglist::TImageIndex FOverlayImageIndex;
	int FIndend;
	void *FData;
	void __fastcall SetCaption(const AnsiString Value);
	void __fastcall SetData(const void * Value);
	
public:
	__property void * Data = {read=FData, write=SetData};
	__fastcall virtual TsComboItem(Classes::TCollection* Collection);
	__fastcall virtual ~TsComboItem(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual AnsiString __fastcall GetDisplayName();
	
__published:
	__property AnsiString Caption = {read=FCaption, write=SetCaption};
	__property Imglist::TImageIndex ImageIndex = {read=FImageIndex, write=FImageIndex, default=-1};
	__property int Indend = {read=FIndend, write=FIndend, default=-1};
	__property Imglist::TImageIndex OverlayImageIndex = {read=FOverlayImageIndex, write=FOverlayImageIndex, default=-1};
	__property Imglist::TImageIndex SelectedImageIndex = {read=FSelectedImageIndex, write=FSelectedImageIndex, default=-1};
};


class DELPHICLASS TsComboBoxEx;
class PASCALIMPLEMENTATION TsComboBoxEx : public TsCustomComboBoxEx 
{
	typedef TsCustomComboBoxEx inherited;
	
public:
	__property SelectedItem ;
	
__published:
	__property Action ;
	__property Anchors  = {default=3};
	__property BiDiMode ;
	__property Color  = {default=-2147483643};
	__property Constraints ;
	__property Ctl3D ;
	__property DisabledKind  = {default=1};
	__property DragCursor  = {default=-12};
	__property DragKind  = {default=0};
	__property DragMode  = {default=0};
	__property Enabled  = {default=1};
	__property Font ;
	__property ImeMode  = {default=3};
	__property ImeName ;
	__property ItemHeight  = {default=16};
	__property ParentBiDiMode  = {default=1};
	__property ParentColor  = {default=0};
	__property ParentCtl3D  = {default=1};
	__property ParentFont  = {default=1};
	__property ParentShowHint  = {default=1};
	__property PopupMenu ;
	__property ShowHint ;
	__property TabOrder  = {default=-1};
	__property TabStop  = {default=1};
	__property Visible  = {default=1};
	__property BevelEdges  = {default=15};
	__property BevelInner  = {index=0, default=2};
	__property BevelKind  = {default=0};
	__property BevelOuter  = {index=1, default=1};
	__property DropDownCount  = {default=14};
	__property OnChange ;
	__property OnCloseUp ;
	__property OnClick ;
	__property OnContextPopup ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnDrawItem ;
	__property OnDropDown ;
	__property OnEndDock ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnSelect ;
	__property OnStartDock ;
	__property OnStartDrag ;
	__property MaxLength  = {default=0};
	__property Images ;
	__property ItemsEx ;
	__property SkinData ;
	__property Text ;
public:
	#pragma option push -w-inl
	/* TsCustomComboBoxEx.Create */ inline __fastcall virtual TsComboBoxEx(Classes::TComponent* AOwner) : TsCustomComboBoxEx(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TsCustomComboBoxEx.Destroy */ inline __fastcall virtual ~TsComboBoxEx(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TsComboBoxEx(HWND ParentWindow) : TsCustomComboBoxEx(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Dialogs::TColorDialog* ColDlg;

}	/* namespace Scomboboxes */
using namespace Scomboboxes;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// sComboBoxes
