// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sSkinManager.pas' rev: 6.00

#ifndef sSkinManagerHPP
#define sSkinManagerHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <acntUtils.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <acSkinPack.hpp>	// Pascal unit
#include <sStyleSimply.hpp>	// Pascal unit
#include <jpeg.hpp>	// Pascal unit
#include <sSkinMenus.hpp>	// Pascal unit
#include <sMaskData.hpp>	// Pascal unit
#include <IniFiles.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <sDefaults.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sskinmanager
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TacSkinTypes { stUnpacked, stPacked, stAllSkins };
#pragma option pop

typedef void __fastcall (__closure *TacGetExtraLineData)(Menus::TMenuItem* FirstItem, AnsiString &SkinSection, AnsiString &Caption, Graphics::TBitmap* &Glyph, bool &LineVisible);

typedef AnsiString TacSkinInfo;

class DELPHICLASS TacBtnEffects;
class DELPHICLASS TsSkinManager;
class DELPHICLASS TsStoredSkins;
class DELPHICLASS TsStoredSkin;
class PASCALIMPLEMENTATION TsStoredSkins : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TsStoredSkin* operator[](int Index) { return Items[Index]; }
	
private:
	TsSkinManager* FOwner;
	HIDESBASE TsStoredSkin* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsStoredSkin* Value);
	
protected:
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TsStoredSkins(TsSkinManager* AOwner);
	__fastcall virtual ~TsStoredSkins(void);
	__property TsStoredSkin* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
	int __fastcall IndexOf(const AnsiString SkinName);
};


class DELPHICLASS TacAnimEffects;
class DELPHICLASS TacDialogShow;
class DELPHICLASS TacFormAnimation;
class PASCALIMPLEMENTATION TacFormAnimation : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	Word FTime;
	bool FActive;
	
public:
	__fastcall virtual TacFormAnimation(void);
	
__published:
	__property bool Active = {read=FActive, write=FActive, default=1};
	__property Word Time = {read=FTime, write=FTime, default=0};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TacFormAnimation(void) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TacDialogShow : public TacFormAnimation 
{
	typedef TacFormAnimation inherited;
	
public:
	__fastcall virtual TacDialogShow(void);
	
__published:
	__property Time  = {default=0};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TacDialogShow(void) { }
	#pragma option pop
	
};


class DELPHICLASS TacFormShow;
class PASCALIMPLEMENTATION TacFormShow : public TacFormAnimation 
{
	typedef TacFormAnimation inherited;
	
public:
	#pragma option push -w-inl
	/* TacFormAnimation.Create */ inline __fastcall virtual TacFormShow(void) : TacFormAnimation() { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TacFormShow(void) { }
	#pragma option pop
	
};


class DELPHICLASS TacSkinChanging;
class PASCALIMPLEMENTATION TacSkinChanging : public TacFormAnimation 
{
	typedef TacFormAnimation inherited;
	
public:
	__fastcall virtual TacSkinChanging(void);
	
__published:
	__property Time  = {default=100};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TacSkinChanging(void) { }
	#pragma option pop
	
};


class DELPHICLASS TacPageChange;
class PASCALIMPLEMENTATION TacPageChange : public TacFormAnimation 
{
	typedef TacFormAnimation inherited;
	
public:
	#pragma option push -w-inl
	/* TacFormAnimation.Create */ inline __fastcall virtual TacPageChange(void) : TacFormAnimation() { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TacPageChange(void) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TacAnimEffects : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	TacBtnEffects* FButtons;
	TacDialogShow* FDialogShow;
	TacFormShow* FFormShow;
	TacSkinChanging* FSkinChanging;
	TacPageChange* FPageChange;
	
public:
	TsSkinManager* Manager;
	__fastcall TacAnimEffects(void);
	__fastcall virtual ~TacAnimEffects(void);
	
__published:
	__property TacBtnEffects* Buttons = {read=FButtons, write=FButtons};
	__property TacDialogShow* DialogShow = {read=FDialogShow, write=FDialogShow};
	__property TacFormShow* FormShow = {read=FFormShow, write=FFormShow};
	__property TacPageChange* PageChange = {read=FPageChange, write=FPageChange};
	__property TacSkinChanging* SkinChanging = {read=FSkinChanging, write=FSkinChanging};
};


#pragma option push -b-
enum TacSkinningRule { srStdForms, srStdDialogs, srThirdParty };
#pragma option pop

typedef Set<TacSkinningRule, srStdForms, srThirdParty>  TacSkinningRules;

class DELPHICLASS ThirdPartyList;
class PASCALIMPLEMENTATION ThirdPartyList : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	AnsiString FThirdEdits;
	AnsiString FThirdButtons;
	AnsiString FThirdBitBtns;
	AnsiString FThirdCheckBoxes;
	AnsiString FThirdGroupBoxes;
	AnsiString FThirdListViews;
	AnsiString FThirdPanels;
	AnsiString FThirdGrids;
	AnsiString FThirdTreeViews;
	AnsiString FThirdComboBoxes;
	AnsiString FThirdWWEdits;
	AnsiString FThirdVirtualTrees;
	AnsiString FThirdGridEh;
	AnsiString FThirdPageControl;
	AnsiString FThirdTabControl;
	AnsiString FThirdToolBar;
	AnsiString FThirdStatusBar;
	AnsiString __fastcall GetString(const int Index);
	void __fastcall SetString(const int Index, const AnsiString Value);
	
__published:
	__property AnsiString ThirdEdits = {read=GetString, write=SetString, stored=true, index=0};
	__property AnsiString ThirdButtons = {read=GetString, write=SetString, stored=true, index=1};
	__property AnsiString ThirdBitBtns = {read=GetString, write=SetString, stored=true, index=2};
	__property AnsiString ThirdCheckBoxes = {read=GetString, write=SetString, stored=true, index=3};
	__property AnsiString ThirdGroupBoxes = {read=GetString, write=SetString, stored=true, index=6};
	__property AnsiString ThirdListViews = {read=GetString, write=SetString, stored=true, index=7};
	__property AnsiString ThirdPanels = {read=GetString, write=SetString, stored=true, index=8};
	__property AnsiString ThirdGrids = {read=GetString, write=SetString, stored=true, index=5};
	__property AnsiString ThirdTreeViews = {read=GetString, write=SetString, stored=true, index=9};
	__property AnsiString ThirdComboBoxes = {read=GetString, write=SetString, stored=true, index=4};
	__property AnsiString ThirdWWEdits = {read=GetString, write=SetString, stored=true, index=10};
	__property AnsiString ThirdVirtualTrees = {read=GetString, write=SetString, stored=true, index=12};
	__property AnsiString ThirdGridEh = {read=GetString, write=SetString, stored=true, index=11};
	__property AnsiString ThirdPageControl = {read=GetString, write=SetString, stored=true, index=13};
	__property AnsiString ThirdTabControl = {read=GetString, write=SetString, stored=true, index=14};
	__property AnsiString ThirdToolBar = {read=GetString, write=SetString, stored=true, index=15};
	__property AnsiString ThirdStatusBar = {read=GetString, write=SetString, stored=true, index=16};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~ThirdPartyList(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall ThirdPartyList(void) : Classes::TPersistent() { }
	#pragma option pop
	
};


typedef DynamicArray<Classes::TStringList* >  sSkinManager__81;

class PASCALIMPLEMENTATION TsSkinManager : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	int FGroupIndex;
	AnsiString FSkinName;
	AnsiString FSkinDirectory;
	bool FActive;
	TsStoredSkins* FBuiltInSkins;
	Sskinmenus::TsSkinableMenus* FSkinableMenus;
	Classes::TNotifyEvent FOnAfterChange;
	Classes::TNotifyEvent FOnBeforeChange;
	bool FSkinnedPopups;
	Classes::TStringList* FCommonSections;
	bool FIsDefault;
	TacGetExtraLineData FOnGetPopupLineData;
	Sskinmenus::TacMenuSupport* FMenuSupport;
	TacAnimEffects* FAnimEffects;
	HWND FActiveControl;
	bool GlobalHookInstalled;
	TacSkinningRules FSkinningRules;
	ThirdPartyList* FThirdParty;
	bool FAllowGlowing;
	bool FExtendedBorders;
	void __fastcall SetSkinName(const AnsiString Value);
	void __fastcall SetSkinDirectory(const AnsiString Value);
	void __fastcall SetActive(const bool Value);
	void __fastcall SetBuiltInSkins(const TsStoredSkins* Value);
	void __fastcall SetSkinnedPopups(const bool Value);
	AnsiString __fastcall GetVersion();
	void __fastcall SetVersion(const AnsiString Value);
	AnsiString __fastcall GetSkinInfo();
	void __fastcall SetSkinInfo(const AnsiString Value);
	void __fastcall SetHueOffset(const int Value);
	void __fastcall SetSaturation(const int Value);
	void __fastcall SetIsDefault(const bool Value);
	bool __fastcall GetIsDefault(void);
	bool __fastcall MainWindowHook(Messages::TMessage &Message);
	void __fastcall SetActiveControl(const HWND Value);
	void __fastcall SetFSkinningRules(const TacSkinningRules Value);
	void __fastcall SetExtendedBorders(const bool Value);
	
protected:
	void __fastcall SendNewSkin(bool AllowAnimation = true);
	void __fastcall SendRemoveSkin(void);
	void __fastcall LoadAllMasks(void);
	void __fastcall LoadAllPatterns(void);
	void __fastcall FreeBitmaps(void);
	void __fastcall FreeJpegs(void);
	
public:
	Sstylesimply::TsSkinData* SkinData;
	DynamicArray<Smaskdata::TsMaskData >  ma;
	DynamicArray<Smaskdata::TsPatternData >  pa;
	DynamicArray<Smaskdata::TsGeneralData >  gd;
	Sstylesimply::TConstantSkinData ConstData;
	Graphics::TBitmap* MasterBitmap;
	bool SkinIsPacked;
	Graphics::TBitmap* ShdaTemplate;
	Graphics::TBitmap* ShdiTemplate;
	#pragma pack(push, 1)
	Types::TRect FormShadowSize;
	#pragma pack(pop)
	
	int FHueOffset;
	int FSaturation;
	DynamicArray<Classes::TStringList* >  ThirdLists;
	void __fastcall InitConstantIndexes(void);
	void __fastcall CheckShadows(void);
	void __fastcall LoadAllGeneralData(void);
	void __fastcall InitMaskIndexes(void);
	void __fastcall SetCommonSections(const Classes::TStringList* Value);
	__fastcall virtual TsSkinManager(Classes::TComponent* AOwner);
	__fastcall virtual ~TsSkinManager(void);
	virtual void __fastcall AfterConstruction(void);
	virtual void __fastcall Loaded(void);
	void __fastcall SaveToIni(int Index, Inifiles::TMemIniFile* sf);
	void __fastcall ReloadSkin(void);
	void __fastcall ReloadPackedSkin(void);
	void __fastcall InstallHook(void);
	void __fastcall UnInstallHook(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	void __fastcall UpdateSkinSection(const AnsiString SectionName);
	__property int GroupIndex = {read=FGroupIndex, write=FGroupIndex, nodefault};
	__property Sskinmenus::TsSkinableMenus* SkinableMenus = {read=FSkinableMenus, write=FSkinableMenus};
	__property HWND ActiveControl = {read=FActiveControl, write=SetActiveControl, nodefault};
	void __fastcall RepaintForms(void);
	tagSIZE __fastcall MaskSize(int MaskIndex);
	int __fastcall GetSkinIndex(const AnsiString SkinSection);
	int __fastcall GetMaskIndex(int SkinIndex, const AnsiString SkinSection, const AnsiString mask)/* overload */;
	int __fastcall GetMaskIndex(const AnsiString SkinSection, const AnsiString mask)/* overload */;
	int __fastcall GetTextureIndex(int SkinIndex, const AnsiString SkinSection, const AnsiString PropName);
	int __fastcall GetPatternIndex(int SkinIndex, const AnsiString SkinSection, const AnsiString pattern);
	AnsiString __fastcall GetFullSkinDirectory();
	AnsiString __fastcall GetSkinNames(Classes::TStrings* sl, TacSkinTypes SkinType = (TacSkinTypes)(0x2));
	AnsiString __fastcall GetExternalSkinNames(Classes::TStrings* sl, TacSkinTypes SkinType = (TacSkinTypes)(0x2));
	void __fastcall GetSkinSections(Classes::TStrings* sl);
	void __fastcall ExtractInternalSkin(const AnsiString NameOfSkin, const AnsiString DestDir);
	void __fastcall ExtractByIndex(int Index, const AnsiString DestDir);
	void __fastcall UpdateSkin(void);
	Graphics::TColor __fastcall GetGlobalColor(void);
	Graphics::TColor __fastcall GetGlobalFontColor(void);
	Graphics::TColor __fastcall GetActiveEditColor(void);
	Graphics::TColor __fastcall GetActiveEditFontColor(void);
	Graphics::TColor __fastcall GetHighLightColor(void);
	Graphics::TColor __fastcall GetHighLightFontColor(void);
	int __fastcall MaskWidthTop(int MaskIndex);
	int __fastcall MaskWidthLeft(int MaskIndex);
	int __fastcall MaskWidthBottom(int MaskIndex);
	int __fastcall MaskWidthRight(int MaskIndex);
	bool __fastcall IsValidImgIndex(int ImageIndex);
	bool __fastcall IsValidSkinIndex(int SkinIndex);
	
__published:
	__property bool ExtendedBorders = {read=FExtendedBorders, write=SetExtendedBorders, default=0};
	__property bool SkinnedPopups = {read=FSkinnedPopups, write=SetSkinnedPopups, default=1};
	__property bool AllowGlowing = {read=FAllowGlowing, write=FAllowGlowing, default=1};
	__property TacAnimEffects* AnimEffects = {read=FAnimEffects, write=FAnimEffects};
	__property bool IsDefault = {read=GetIsDefault, write=SetIsDefault, default=1};
	__property bool Active = {read=FActive, write=SetActive, default=1};
	__property Classes::TStringList* CommonSections = {read=FCommonSections, write=SetCommonSections};
	__property int Saturation = {read=FSaturation, write=SetSaturation, default=0};
	__property int HueOffset = {read=FHueOffset, write=SetHueOffset, default=0};
	__property TsStoredSkins* InternalSkins = {read=FBuiltInSkins, write=SetBuiltInSkins};
	__property Sskinmenus::TacMenuSupport* MenuSupport = {read=FMenuSupport, write=FMenuSupport};
	__property AnsiString SkinDirectory = {read=FSkinDirectory, write=SetSkinDirectory};
	__property AnsiString SkinName = {read=FSkinName, write=SetSkinName};
	__property AnsiString SkinInfo = {read=GetSkinInfo, write=SetSkinInfo};
	__property TacSkinningRules SkinningRules = {read=FSkinningRules, write=SetFSkinningRules, default=7};
	__property ThirdPartyList* ThirdParty = {read=FThirdParty, write=FThirdParty};
	__property AnsiString Version = {read=GetVersion, write=SetVersion, stored=false};
	__property Classes::TNotifyEvent OnAfterChange = {read=FOnAfterChange, write=FOnAfterChange};
	__property Classes::TNotifyEvent OnBeforeChange = {read=FOnBeforeChange, write=FOnBeforeChange};
	__property TacGetExtraLineData OnGetMenuExtraLineData = {read=FOnGetPopupLineData, write=FOnGetPopupLineData};
};


class PASCALIMPLEMENTATION TacBtnEffects : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	Sconst::TacBtnEvents FEvents;
	
public:
	TsSkinManager* Manager;
	__fastcall TacBtnEffects(void);
	
__published:
	__property Sconst::TacBtnEvents Events = {read=FEvents, write=FEvents, default=15};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TacBtnEffects(void) { }
	#pragma option pop
	
};


class DELPHICLASS TsSkinGeneral;
class PASCALIMPLEMENTATION TsSkinGeneral : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FName;
	bool FShowFocus;
	bool FFadingEnabled;
	int FHotImagePercent;
	int FTransparency;
	int FHotTransparency;
	int FFadingIterations;
	AnsiString FHotFontColor;
	int FHotGradientPercent;
	int FGradientPercent;
	int FImagePercent;
	AnsiString FHotGradientData;
	AnsiString FGradientData;
	AnsiString FParentClass;
	Graphics::TColor FHotColor;
	Graphics::TColor FColor;
	AnsiString FSectionName;
	AnsiString FFontColor;
	bool FReservedBoolean;
	bool FGiveOwnFont;
	int FGlowCount;
	int FGlowMargin;
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetFadingEnabled(const bool Value);
	void __fastcall SetFadingIterations(const int Value);
	void __fastcall SetGradientData(const AnsiString Value);
	void __fastcall SetGradientPercent(const int Value);
	void __fastcall SetHotGradientData(const AnsiString Value);
	void __fastcall SetHotGradientPercent(const int Value);
	void __fastcall SetHotImagePercent(const int Value);
	void __fastcall SetHotColor(const Graphics::TColor Value);
	void __fastcall SetHotTransparency(const int Value);
	void __fastcall SetImagePercent(const int Value);
	void __fastcall SetColor(const Graphics::TColor Value);
	void __fastcall SetTransparency(const int Value);
	void __fastcall SetParentClass(const AnsiString Value);
	void __fastcall SetShowFocus(const bool Value);
	void __fastcall SetSectionName(const AnsiString Value);
	void __fastcall SetHotFontColor(const AnsiString Value);
	void __fastcall SetFontColor(const AnsiString Value);
	void __fastcall SetReservedBoolean(const bool Value);
	void __fastcall SetGiveOwnFont(const bool Value);
	void __fastcall SetGlowCount(const int Value);
	void __fastcall SetGlowMargin(const int Value);
	
public:
	__fastcall virtual TsSkinGeneral(Classes::TCollection* Collection);
	__fastcall virtual ~TsSkinGeneral(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property AnsiString SectionName = {read=FSectionName, write=SetSectionName};
	__property AnsiString ParentClass = {read=FParentClass, write=SetParentClass};
	__property Graphics::TColor Color = {read=FColor, write=SetColor, nodefault};
	__property bool ReservedBoolean = {read=FReservedBoolean, write=SetReservedBoolean, nodefault};
	__property AnsiString FontColor = {read=FFontColor, write=SetFontColor};
	__property AnsiString HotFontColor = {read=FHotFontColor, write=SetHotFontColor};
	__property int Transparency = {read=FTransparency, write=SetTransparency, nodefault};
	__property int GlowCount = {read=FGlowCount, write=SetGlowCount, nodefault};
	__property int GlowMargin = {read=FGlowMargin, write=SetGlowMargin, nodefault};
	__property int GradientPercent = {read=FGradientPercent, write=SetGradientPercent, nodefault};
	__property AnsiString GradientData = {read=FGradientData, write=SetGradientData};
	__property int ImagePercent = {read=FImagePercent, write=SetImagePercent, nodefault};
	__property bool ShowFocus = {read=FShowFocus, write=SetShowFocus, nodefault};
	__property bool FadingEnabled = {read=FFadingEnabled, write=SetFadingEnabled, nodefault};
	__property int FadingIterations = {read=FFadingIterations, write=SetFadingIterations, nodefault};
	__property Graphics::TColor HotColor = {read=FHotColor, write=SetHotColor, nodefault};
	__property int HotTransparency = {read=FHotTransparency, write=SetHotTransparency, nodefault};
	__property int HotGradientPercent = {read=FHotGradientPercent, write=SetHotGradientPercent, nodefault};
	__property AnsiString HotGradientData = {read=FHotGradientData, write=SetHotGradientData};
	__property int HotImagePercent = {read=FHotImagePercent, write=SetHotImagePercent, nodefault};
	__property AnsiString Name = {read=FName, write=SetName};
	__property bool GiveOwnFont = {read=FGiveOwnFont, write=SetGiveOwnFont, nodefault};
};


class DELPHICLASS TsSkinGenerals;
class PASCALIMPLEMENTATION TsSkinGenerals : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TsSkinGeneral* operator[](int Index) { return Items[Index]; }
	
private:
	TsStoredSkin* FOwner;
	HIDESBASE TsSkinGeneral* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsSkinGeneral* Value);
	
protected:
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	
public:
	__fastcall TsSkinGenerals(TsStoredSkin* AOwner);
	__fastcall virtual ~TsSkinGenerals(void);
	__property TsSkinGeneral* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
};


class DELPHICLASS TsSkinImage;
class PASCALIMPLEMENTATION TsSkinImage : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FName;
	Graphics::TBitmap* FImage;
	AnsiString FClassName;
	AnsiString FPropertyName;
	int FMaskType;
	int FImageCount;
	int FTop;
	int FLeft;
	int FRight;
	int FBottom;
	int FBorderWidth;
	int FStretchMode;
	Sconst::TacImgType FImgType;
	int FWR;
	int FWT;
	int FWL;
	int FWB;
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetImage(const Graphics::TBitmap* Value);
	void __fastcall SetClassName(const AnsiString Value);
	void __fastcall SetPropertyName(const AnsiString Value);
	
public:
	__fastcall virtual TsSkinImage(Classes::TCollection* Collection);
	__fastcall virtual ~TsSkinImage(void);
	
__published:
	__property AnsiString SectionName = {read=FClassName, write=SetClassName};
	__property Graphics::TBitmap* Image = {read=FImage, write=SetImage};
	__property AnsiString Name = {read=FName, write=SetName};
	__property AnsiString PropertyName = {read=FPropertyName, write=SetPropertyName};
	__property int Left = {read=FLeft, write=FLeft, nodefault};
	__property int Top = {read=FTop, write=FTop, nodefault};
	__property int Right = {read=FRight, write=FRight, nodefault};
	__property int Bottom = {read=FBottom, write=FBottom, nodefault};
	__property int ImageCount = {read=FImageCount, write=FImageCount, nodefault};
	__property int MaskType = {read=FMaskType, write=FMaskType, nodefault};
	__property int BorderWidth = {read=FBorderWidth, write=FBorderWidth, nodefault};
	__property int StretchMode = {read=FStretchMode, write=FStretchMode, nodefault};
	__property Sconst::TacImgType ImgType = {read=FImgType, write=FImgType, nodefault};
	__property int WL = {read=FWL, write=FWL, nodefault};
	__property int WR = {read=FWR, write=FWR, nodefault};
	__property int WT = {read=FWT, write=FWT, nodefault};
	__property int WB = {read=FWB, write=FWB, nodefault};
};


class DELPHICLASS TsSkinPattern;
class PASCALIMPLEMENTATION TsSkinPattern : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FName;
	Jpeg::TJPEGImage* FImage;
	AnsiString FClassName;
	AnsiString FPropertyName;
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetImage(const Jpeg::TJPEGImage* Value);
	void __fastcall SetClassName(const AnsiString Value);
	void __fastcall SetPropertyName(const AnsiString Value);
	
public:
	__fastcall virtual TsSkinPattern(Classes::TCollection* Collection);
	__fastcall virtual ~TsSkinPattern(void);
	
__published:
	__property AnsiString SectionName = {read=FClassName, write=SetClassName};
	__property Jpeg::TJPEGImage* Image = {read=FImage, write=SetImage};
	__property AnsiString Name = {read=FName, write=SetName};
	__property AnsiString PropertyName = {read=FPropertyName, write=SetPropertyName};
};


class DELPHICLASS TsSkinImages;
class PASCALIMPLEMENTATION TsSkinImages : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TsSkinImage* operator[](int Index) { return Items[Index]; }
	
private:
	TsStoredSkin* FOwner;
	HIDESBASE TsSkinImage* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsSkinImage* Value);
	
protected:
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	
public:
	__fastcall TsSkinImages(TsStoredSkin* AOwner);
	__fastcall virtual ~TsSkinImages(void);
	__property TsSkinImage* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
};


class DELPHICLASS TsSkinPatterns;
class PASCALIMPLEMENTATION TsSkinPatterns : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TsSkinPattern* operator[](int Index) { return Items[Index]; }
	
private:
	TsStoredSkin* FOwner;
	HIDESBASE TsSkinPattern* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TsSkinPattern* Value);
	
protected:
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	
public:
	__fastcall TsSkinPatterns(TsStoredSkin* AOwner);
	__fastcall virtual ~TsSkinPatterns(void);
	__property TsSkinPattern* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
};


class PASCALIMPLEMENTATION TsStoredSkin : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	TsSkinImages* FImages;
	AnsiString FName;
	TsSkinGenerals* FGeneralData;
	TsSkinPatterns* FPatterns;
	Graphics::TBitmap* FMasterBitmap;
	double FVersion;
	AnsiString FDescription;
	AnsiString FAuthor;
	int FShadow1Offset;
	Graphics::TColor FShadow1Color;
	int FShadow1Blur;
	int FShadow1Transparency;
	Graphics::TColor FBorderColor;
	void __fastcall SetImages(const TsSkinImages* Value);
	void __fastcall SetName(const AnsiString Value);
	void __fastcall SetGeneralData(const TsSkinGenerals* Value);
	void __fastcall SetPatterns(const TsSkinPatterns* Value);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadData(Classes::TStream* Reader);
	void __fastcall WriteData(Classes::TStream* Writer);
	
public:
	Classes::TMemoryStream* PackedData;
	__fastcall virtual TsStoredSkin(Classes::TCollection* Collection);
	__fastcall virtual ~TsStoredSkin(void);
	void __fastcall LoadSkin(Inifiles::TMemIniFile* sf);
	void __fastcall LoadFromIni(TsSkinGenerals* gd, Inifiles::TMemIniFile* sf);
	
__published:
	__property AnsiString Name = {read=FName, write=SetName};
	__property TsSkinGenerals* GeneralData = {read=FGeneralData, write=SetGeneralData};
	__property TsSkinImages* Images = {read=FImages, write=SetImages};
	__property TsSkinPatterns* Patterns = {read=FPatterns, write=SetPatterns};
	__property Graphics::TBitmap* MasterBitmap = {read=FMasterBitmap, write=FMasterBitmap};
	__property Graphics::TColor Shadow1Color = {read=FShadow1Color, write=FShadow1Color, nodefault};
	__property int Shadow1Offset = {read=FShadow1Offset, write=FShadow1Offset, nodefault};
	__property int Shadow1Blur = {read=FShadow1Blur, write=FShadow1Blur, default=-1};
	__property int Shadow1Transparency = {read=FShadow1Transparency, write=FShadow1Transparency, nodefault};
	__property Graphics::TColor BorderColor = {read=FBorderColor, write=FBorderColor, default=16711935};
	__property double Version = {read=FVersion, write=FVersion};
	__property AnsiString Author = {read=FAuthor, write=FAuthor};
	__property AnsiString Description = {read=FDescription, write=FDescription};
};


//-- var, const, procedure ---------------------------------------------------
#define CurrentVersion "6.30"
extern PACKAGE bool NonAutoUpdate;
extern PACKAGE TsSkinManager* DefaultManager;
extern PACKAGE Inifiles::TMemIniFile* SkinFile;
extern PACKAGE _OSVERSIONINFOA OSVersionInfo;
extern PACKAGE bool IsNT;
extern PACKAGE Acskinpack::TacSkinConvertor* sc;
extern PACKAGE bool UnPackedFirst;
extern PACKAGE void __fastcall UpdateCommonDlgs(TsSkinManager* sManager);
extern PACKAGE bool __fastcall ChangeImageInSkin(const AnsiString SkinSection, const AnsiString PropName, const AnsiString FileName, TsSkinManager* sm);
extern PACKAGE void __fastcall ChangeSkinSaturation(TsSkinManager* sManager, int Value);
extern PACKAGE void __fastcall ChangeSkinBrightness(TsSkinManager* sManager, int Value);
extern PACKAGE void __fastcall ChangeSkinHue(TsSkinManager* sManager, int Value);
extern PACKAGE void __fastcall LoadThirdNames(TsSkinManager* sm, bool Overwrite = false);
extern PACKAGE void __fastcall UpdateThirdNames(TsSkinManager* sm);

}	/* namespace Sskinmanager */
using namespace Sskinmanager;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// sSkinManager
