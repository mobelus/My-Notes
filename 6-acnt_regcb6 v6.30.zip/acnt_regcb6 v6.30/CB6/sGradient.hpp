// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sGradient.pas' rev: 6.00

#ifndef sGradientHPP
#define sGradientHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <IniFiles.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Math.hpp>	// Pascal unit
#include <sConst.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sgradient
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TsGradFillMode { fmSolid, fmTransparent };
#pragma option pop

#pragma pack(push, 4)
struct TsGradPie
{
	Graphics::TColor Color1;
	Graphics::TColor Color2;
	Sconst::TPercent Percent;
	int Mode1;
	int Mode2;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct TRIVERTEX
{
	unsigned X;
	unsigned Y;
	Word Red;
	Word Green;
	Word Blue;
	Word Alpha;
} ;
#pragma pack(pop)

typedef DynamicArray<TsGradPie >  TsGradArray;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall PaintGrad(Graphics::TBitmap* Bmp, const Types::TRect &aRect, const AnsiString Gradient)/* overload */;
extern PACKAGE void __fastcall PaintGrad(Graphics::TBitmap* Bmp, const Types::TRect &aRect, const TsGradArray Data, int OffsetX = 0x0, int OffsetY = 0x0)/* overload */;
extern PACKAGE void __fastcall PrepareGradArray(const AnsiString GradientStr, TsGradArray &GradArray);

}	/* namespace Sgradient */
using namespace Sgradient;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// sGradient
