// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'sRegisterIt.pas' rev: 6.00

#ifndef sRegisterItHPP
#define sRegisterItHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <sCheckListBox.hpp>	// Pascal unit
#include <sMemo.hpp>	// Pascal unit
#include <acAlphaImageList.hpp>	// Pascal unit
#include <sCheckBox.hpp>	// Pascal unit
#include <sComboBox.hpp>	// Pascal unit
#include <sSkinProvider.hpp>	// Pascal unit
#include <sSkinManager.hpp>	// Pascal unit
#include <sEdit.hpp>	// Pascal unit
#include <sGauge.hpp>	// Pascal unit
#include <sListView.hpp>	// Pascal unit
#include <acMagn.hpp>	// Pascal unit
#include <acHeaderControl.hpp>	// Pascal unit
#include <acAlphaHints.hpp>	// Pascal unit
#include <acNoteBook.hpp>	// Pascal unit
#include <acProgressBar.hpp>	// Pascal unit
#include <acCoolBar.hpp>	// Pascal unit
#include <acShellCtrls.hpp>	// Pascal unit
#include <sFrameBar.hpp>	// Pascal unit
#include <sUpDown.hpp>	// Pascal unit
#include <sFrameAdapter.hpp>	// Pascal unit
#include <sTreeView.hpp>	// Pascal unit
#include <sFileCtrl.hpp>	// Pascal unit
#include <sRichEdit.hpp>	// Pascal unit
#include <sScrollBox.hpp>	// Pascal unit
#include <sFontCtrls.hpp>	// Pascal unit
#include <sTabControl.hpp>	// Pascal unit
#include <sSplitter.hpp>	// Pascal unit
#include <sComboBoxes.hpp>	// Pascal unit
#include <sMaskEdit.hpp>	// Pascal unit
#include <sCalculator.hpp>	// Pascal unit
#include <sTrackBar.hpp>	// Pascal unit
#include <sStatusBar.hpp>	// Pascal unit
#include <sGroupBox.hpp>	// Pascal unit
#include <sBevel.hpp>	// Pascal unit
#include <sMonthCalendar.hpp>	// Pascal unit
#include <sTooledit.hpp>	// Pascal unit
#include <sCurrEdit.hpp>	// Pascal unit
#include <sPageControl.hpp>	// Pascal unit
#include <sComboEdit.hpp>	// Pascal unit
#include <sRadioButton.hpp>	// Pascal unit
#include <sSpinEdit.hpp>	// Pascal unit
#include <sCurrencyEdit.hpp>	// Pascal unit
#include <sDialogs.hpp>	// Pascal unit
#include <sColorSelect.hpp>	// Pascal unit
#include <sToolBar.hpp>	// Pascal unit
#include <sHintManager.hpp>	// Pascal unit
#include <sAlphaListBox.hpp>	// Pascal unit
#include <sPanel.hpp>	// Pascal unit
#include <sSpeedButton.hpp>	// Pascal unit
#include <sBitBtn.hpp>	// Pascal unit
#include <sButton.hpp>	// Pascal unit
#include <sLabel.hpp>	// Pascal unit
#include <sScrollBar.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sregisterit
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Sregisterit */
using namespace Sregisterit;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// sRegisterIt
