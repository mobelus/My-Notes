// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'acThumbForm.pas' rev: 6.00

#ifndef acThumbFormHPP
#define acThumbFormHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ExtCtrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Acthumbform
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TThumbForm;
class PASCALIMPLEMENTATION TThumbForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	void __fastcall FormHide(System::TObject* Sender);
	
private:
	HWND FScaledWnd;
	unsigned Thumbnail;
	void __fastcall SetScaledWnd(const HWND Value);
	__property HWND ScaledWnd = {read=FScaledWnd, write=SetScaledWnd, nodefault};
	Types::TRect __fastcall ScaledRect();
	Types::TPoint __fastcall CenterPoint();
	MESSAGE void __fastcall OnColorChanged(Messages::TMessage &Message);
	
public:
	int ScaleFactor;
	__fastcall virtual TThumbForm(Classes::TComponent* AOwner);
	void __fastcall UpdateScaledWnd(void);
	void __fastcall UpdateThumbnail(void);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
public:
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TThumbForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TThumbForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TThumbForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


#pragma pack(push, 1)
struct TDWMThumbnailProperties
{
	unsigned dwFlags;
	Types::TRect rcDestination;
	Types::TRect rcSource;
	Byte opacity;
	BOOL fVisible;
	BOOL fSourceClientAreaOnly;
} ;
#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE HRESULT __fastcall DwmUnregisterThumbnail(unsigned hThumbnailId);
extern PACKAGE HRESULT __fastcall DwmGetColorizationColor(/* out */ unsigned &pcrColorization, /* out */ BOOL &pfOpaqueBlend);
extern PACKAGE HRESULT __fastcall DwmRegisterThumbnail(HWND hwndDestination, HWND hwndSource, /* out */ unsigned &phThumbnailId);
extern PACKAGE HRESULT __fastcall DwmUpdateThumbnailProperties(unsigned hThumbnailId, const TDWMThumbnailProperties &ptnProperties);

}	/* namespace Acthumbform */
using namespace Acthumbform;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// acThumbForm
