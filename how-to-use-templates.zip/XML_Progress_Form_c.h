//---------------------------------------------------------------------------

#ifndef XML_Progress_Form_cH
#define XML_Progress_Form_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CGAUGES.h"
//---------------------------------------------------------------------------
class TProgress_Form : public TForm
{
__published:	// IDE-managed Components
   TCGauge *progressGauge;
private:	// User declarations
public:		// User declarations
   __fastcall TProgress_Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TProgress_Form *Progress_Form;
//---------------------------------------------------------------------------
#endif
