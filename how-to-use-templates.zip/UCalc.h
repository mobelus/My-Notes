//---------------------------------------------------------------------------
#ifndef UCalcH
#define UCalcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cxControls.hpp"
#include "cxDBEditRepository.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include <DB.hpp>
#include "structures.h"
#include "cxContainer.hpp"
#include "cxGroupBox.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "glGrBox.hpp"
#include <ExtCtrls.hpp>
#include "cxTextEdit.hpp"
#include "dxCntner.hpp"
#include "dxDBEdtr.hpp"
#include "dxDBELib.hpp"
#include "dxEditor.hpp"
#include "dxEdLib.hpp"
#include "dxExEdtr.hpp"
#include <DBCtrls.hpp>
#include "cxDBExtLookupComboBox.hpp"
#include "cxDBLookupComboBox.hpp"
#include "cxDBLookupEdit.hpp"
#include "cxDropDownEdit.hpp"
#include "cxLookupEdit.hpp"
#include "cxMaskEdit.hpp"
#include "cxRadioGroup.hpp"
#include "cxCalendar.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "sCurrEdit.hpp"
#include "cxCheckGroup.hpp"
#include "cxButtons.hpp"
#include "cxClasses.hpp"
#include "cxCustomData.hpp"
#include "cxData.hpp"
#include "cxDataStorage.hpp"
#include "cxDBData.hpp"
#include "cxFilter.hpp"
#include "cxGrid.hpp"
#include "cxGridCustomTableView.hpp"
#include "cxGridCustomView.hpp"
#include "cxGridDBTableView.hpp"
#include "cxGridLevel.hpp"
#include "cxGridTableView.hpp"
#include <Menus.hpp>
#include <ADODB.hpp>
#include <Dialogs.hpp>
#include "cxCurrencyEdit.hpp"
#include "RxMenus.hpp"
#include "UErrors.h"
#include "cxPC.hpp"
#include "cxButtonEdit.hpp"
#include <Rio.hpp>
#include <SOAPHTTPClient.hpp>
#include "cxMCListBox.hpp"
#include <ComCtrls.hpp>
#include "cxCheckBox.hpp"
#include <DBClient.hpp>
#include "cxSpinEdit.hpp"
#include "XML_Progress_Form_c.h"
#include "cxCalc.hpp"
#include "ParamF.h"
#include "ULoadDict.h"
#include "sCheckBox.hpp"
#include "cxListView.hpp"
#include "sButton.hpp"
#include <Grids.hpp>
#include <IdBaseComponent.hpp>
#include <IdCoder.hpp>
#include <IdCoder3To4.hpp>
#include "cxHyperLinkEdit.hpp"

class TfrmInfoRsa;
class kbm_of_rsa;
//---------------------------------------------------------------------------
class TframeCalc : public TFrame{
__published:	// IDE-managed Components
   TglGroupBox *gbVehicle;
   TglGroupBox *gbInsured;
   TcxPageControl *pcInsuredType;
   TcxTabSheet *shJur;
   TcxTabSheet *shIP;
   TLabel *Label41;
   TBevel *Bevel18;
   TLabel *Label45;
   TLabel *Label50;
   TLabel *Label51;
   TEdit *editLastNameIP;
   TcxButtonEdit *editAddressRegIP;
   TEdit *editEmailIP;
   TEdit *editFirstNameIP;
   TEdit *editSecondNameIP;
   TglGroupBox *gbPermitted;
   TcxComboBox *cboxMultydrive;
   TglGroupBox *gbOwner;
   TBevel *Bevel19;
   TcxButton *btnCalc;
   TcxComboBox *cboxDocTypeIP;
   TLabel *Label42;
   TcxMaskEdit *editDocSeriesIP;
   TStaticText *hintDocSeriesIP;
   TcxMaskEdit *editDocNumberIP;
   TStaticText *hintDocNumberIP;
   TsDateEdit *editDocIssueDateIP;
   TStaticText *hintDocIssueDateIP;
   TEdit *editDocIssueOrgIP;
   TLabel *Label46;
   TEdit *editCodeIP;
   TsDateEdit *editBirthDateIP;
   TStaticText *hintBirthDateIP;
   TLabel *Label48;
   TcxPageControl *pcOwnerType;
   TcxTabSheet *shJur_Ow;
   TcxTabSheet *shIP_Ow;
   TcxTabSheet *shPhys_Ow;
   TcxButton *btnCopy;
   TglGroupBox *gbPayments;
   TglGroupBox *gbTotal;
   TglGroupBox *gbBSO;
   TEdit *editPolicyNumber;
   TcxButton *btnCheckBSO;
   TcxComboBox *cboxBSOType;
   TLabel *Label83;
   TglGroupBox *gbInsurer;
   TglGroupBox *gbCalcType;
   TcxRadioGroup *rgCalcType;
   TLabel *Label104;
   TcxComboBox *cboxSalerPositionNormal;
   TcxComboBox *cboxSalerSignDocument;
   TLabel *Label106;
   TLabel *Label107;
   TLabel *Label110;
   TEdit *editCity;
   TcxMaskEdit *editINNIP;
   TStaticText *hintINNIP;
   TcxMaskEdit *editOGRNIP;
   TStaticText *hintOGRNIP;
   TEdit *editSalerNameNormal;
   TEdit *editSalerName;
   TcxComboBox *cboxSalerPosition;
   TEdit *editDocumentNumber;
   TsDateEdit *editDateSignDocument;
   TStaticText *hintDateSignDocument;
   TglGroupBox *gbVariant;
   TLabel *labInfoNoStandart;
   TDataSource *ds_brands;
   TDataSource *ds_models;
   TTimer *Timer2;
   TcxTabSheet *shPhys;
   TBevel *Bevel16;
   TLabel *Label29;
   TLabel *Label33;
   TLabel *Label35;
   TLabel *Label36;
   TLabel *Label37;
   TLabel *Label123;
   TEdit *editLastNamePh;
   TcxButtonEdit *editAddressRegPh;
   TEdit *editEmailPh;
   TEdit *editFirstNamePh;
   TEdit *editSecondNamePh;
   TcxComboBox *cboxDocTypePh;
   TcxMaskEdit *editDocSeriesPh;
   TStaticText *hintDocSeriesPh;
   TcxMaskEdit *editDocNumberPh;
   TStaticText *hintDocNumberPh;
   TsDateEdit *editDocIssueDatePh;
   TStaticText *hintDocIssueDatePh;
   TEdit *editDocIssueOrgPh;
   TEdit *editCodePh;
   TsDateEdit *editBirthDatePh;
   TStaticText *hintBirthDatePh;
   TLabel *Label38;
   TcxComboBox *cboxCitizenship;
   TRadioButton *rbVarA;
   TRadioButton *rbVarB;
   TRadioButton *rbVarV;
   TRadioButton *rbVarAPK;
   TRadioButton *rbVarNL;
   TcxButton *btnAddPermitted;
   TcxButton *btnEditPermitted;
   TListView *gridDopush;
   TLabel *gridHead;
   TBevel *Bevel46;
   TEdit *editPhoneHomePh;
   TEdit *editPhoneWorkPh;
   TcxMaskEdit *editPhoneMobilPh;
   TStaticText *hintPhoneMobilPh;
   TcxMaskEdit *editPhoneMobilIP;
   TEdit *editPhoneHomeIP;
   TEdit *editPhoneWorkIP;
   TStaticText *hintPhoneMobilIP;
   TglGroupBox *gbTerms;
   TglGroupBox *gbPrjPrg;
   TLabel *Label5;
   TcxComboBox *cboxProjects;
   TcxComboBox *cboxProgramms;
   TLabel *Label10;
   TRadioButton *rbVarZDTP;
   TTimer *Timer3;
   TLabel *labDown;
   TTreeView *tvSaleChannel;
   TLabel *Label60;
   TcxPopupEdit *popeditSaleChannel;
   TPanel *Panel1;
   TBevel *Bevel42;
   TLabel *Label11;
   TLabel *Label105;
   TLabel *Label108;
   TLabel *Label109;
   TLabel *lablMassOrSeats;
   TcxComboBox *cboxVehicleType;
   TcxLookupComboBox *cboxBrands;
   TcxLookupComboBox *cboxModels;
   TcxComboBox *cboxYears;
   TEdit *editBrand;
   TEdit *editModel;
   TcxCurrencyEdit *editMassOrSeats;
   TCheckBox *chkTrailer;
   TPanel *Panel2;
   TBevel *Bevel15;
   TLabel *labIdentNumbers;
   TBevel *Bevel5;
   TLabel *Label13;
   TcxMaskEdit *editRegPlate;
   TcxMaskEdit *editVIN;
   TEdit *editBodyNumber;
   TStaticText *hintVIN;
   TEdit *editChassisNumber;
   TcxComboBox *cboxUsage;
   TLabel *labPeriod;
   TBevel *Bevel3;
   TShape *errShape;
   TcxComboBox *cboxSrok;
   TCheckBox *chkForeignReg;
   TLabel *Label1;
   TcxPopupEdit *popeditRegion;
   TBevel *Bevel1;
   TCheckBox *chkTransit;
   TsDateEdit *dateSrokS;
   TsDateEdit *dateSrokPo;
   TCheckBox *chkViolations;
   TPanel *panRegion;
   TcxVerticalGrid *vg;
   TcxEditorRow *vg_cboxRegion;
   TcxEditorRow *vg_cboxArea;
   TcxEditorRow *vg_cboxCity;
   TcxEditorRow *vg_cboxPlace;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *cxStyle3;
   TcxStyle *cxStyle4;
   TcxEditRepository *cxEditRepository1;
   TcxButton *btnOK;
   TcxEditRepositoryComboBoxItem *RegionComboBoxItem;
   TcxEditRepositoryComboBoxItem *AreaComboBoxItem;
   TcxEditRepositoryComboBoxItem *CityComboBoxItem;
   TcxEditRepositoryComboBoxItem *PlaceComboBoxItem;
   TPanel *panInsuredJurDown;
   TLabel *Label31;
   TLabel *Label34;
   TLabel *Label39;
   TLabel *Label40;
   TLabel *Label43;
   TcxButtonEdit *editAddressReg;
   TEdit *editPhone;
   TEdit *editEmail;
   TcxMaskEdit *editOGRN;
   TStaticText *hintOGRN;
   TglGroupBox *gbInsured_Calc;
   TcxPageControl *pcInsuredType_Calc;
   TcxTabSheet *shPhys_Calc;
   TcxTabSheet *shJur_Calc;
   TcxTabSheet *shIP_Calc;
   TPanel *panInsuredJurTop;
   TLabel *Label30;
   TLabel *Label44;
   TBevel *Bevel17;
   TcxComboBox *cboxOPF;
   TcxMaskEdit *editINN;
   TEdit *editOrganization;
   TStaticText *hintINN;
   TStaticText *hintOPF;
   TCheckBox *chkInsuredResident;
   TglGroupBox *gbOwner_Calc;
   TcxPageControl *pcOwnerType_Calc;
   TcxTabSheet *shPhys_Ow_Calc;
   TcxTabSheet *shJur_Ow_Calc;
   TcxTabSheet *shIP_Ow_Calc;
   TPanel *panOwnerJurDown;
   TcxButtonEdit *editOwAddressRegJ;
   TLabel *Label54;
   TLabel *Label4;
   TcxComboBox *cboxOwDocTypeJ;
   TcxMaskEdit *editOwDocSeriesJ;
   TcxMaskEdit *editOwDocNumberJ;
   TBevel *Bevel4;
   TStaticText *hintOwDocNumberJ;
   TStaticText *hintOwDocSeriesJ;
   TBevel *Bevel6;
   TPanel *panOwnerPhysDown;
   TPanel *panOwnerIPDown;
   TLabel *Label56;
   TcxButtonEdit *editOwAddressRegF;
   TLabel *Label64;
   TLabel *Label70;
   TcxButtonEdit *editOwAddressRegIP;
   TglGroupBox *gbVehiclePrint;
   TLabel *Label114;
   TcxComboBox *cboxVehicleDoc;
   TcxMaskEdit *editVehDocSeries;
   TcxMaskEdit *editVehDocNumber;
   TsDateEdit *editVehDocDate;
   TStaticText *hintVehDocSeries;
   TStaticText *hintVehDocNumber;
   TStaticText *hintVehDocDate;
   TBevel *Bevel13;
   TcxComboBox *cboxLsKvt;
   TcxMaskEdit *editKPP;
   TStaticText *hintKPP;
   TLabel *Label6;
   TcxComboBox *cboxDocType;
   TcxMaskEdit *editDocNumber;
   TcxMaskEdit *editDocSeries;
   TStaticText *hintDocSeries;
   TStaticText *hintDocNumber;
   TcxMaskEdit *editKPPIP;
   TStaticText *hintKPPIP;
   TcxMaskEdit *editOwOGRNJ;
   TLabel *Label9;
   TcxMaskEdit *editOwOGRNIP;
   TcxMaskEdit *editOwINNIP;
   TStaticText *hintOwINNIP;
   TBevel *Bevel7;
   TStaticText *hintOwOGRNJ;
   TStaticText *hintOwOGRNIP;
   TPanel *panOwnerPhysTop;
   TBevel *Bevel22;
   TLabel *Label55;
   TLabel *Label65;
   TLabel *Label76;
   TEdit *editOwLastNameF;
   TEdit *editOwFirstNameF;
   TEdit *editOwSecondNameF;
   TcxComboBox *cboxOwDocTypeF;
   TcxMaskEdit *editOwDocSeriesF;
   TStaticText *hintOwDocSeriesF;
   TcxMaskEdit *editOwDocNumberF;
   TStaticText *hintOwDocNumberF;
   TsDateEdit *editOwBirthDateF;
   TStaticText *hintOwBirthDateF;
   TPanel *panOwnerIPTop;
   TLabel *Label63;
   TBevel *Bevel21;
   TLabel *Label68;
   TLabel *Label73;
   TEdit *editOwLastNameIP;
   TEdit *editOwFirstNameIP;
   TEdit *editOwSecondNameIP;
   TcxComboBox *cboxOwDocTypeIP;
   TcxMaskEdit *editOwDocSeriesIP;
   TStaticText *hintOwDocSeriesIP;
   TcxMaskEdit *editOwDocNumberIP;
   TStaticText *hintOwDocNumberIP;
   TsDateEdit *editOwBirthDateIP;
   TStaticText *hintOwBirthDateIP;
   TPanel *panOwnerJurTop;
   TLabel *Label2;
   TLabel *Label3;
   TBevel *Bevel2;
   TcxComboBox *cboxOwOPF;
   TcxMaskEdit *editOwINN;
   TEdit *editOwOrganization;
   TStaticText *hintOwINN;
   TStaticText *hintOwOPF;
   TCheckBox *chkOwResident;
   TcxVerticalGrid *vgTotal;
   TcxEditorRow *editTb;
   TcxEditorRow *editKt;
   TcxEditorRow *editKbm;
   TcxEditRepositoryTextItem *TextItem;
   TcxEditorRow *editKO;
   TcxEditorRow *editKVS;
   TcxEditorRow *editKc;
   TcxEditorRow *editKp;
   TcxEditorRow *editKm;
   TcxEditorRow *editKn;
   TcxEditorRow *editKpr;
   TcxCategoryRow *vgTotalCategoryRow1;
   TcxEditorRow *editPremAll;
   TcxEditRepositoryButtonItem *KbmInfo_ButtonItem;
   TglGroupBox *gbPeriods;
   TCheckBox *chkPeriod2;
   TsDateEdit *datePeriodS1;
   TsDateEdit *datePeriodE1;
   TCheckBox *chkPeriod3;
   TPanel *Panel3;
   TcxVerticalGrid *cxVerticalGrid1;
   TcxEditorRow *cxEditorRow1;
   TcxEditorRow *cxEditorRow2;
   TcxEditorRow *cxEditorRow3;
   TcxEditorRow *cxEditorRow4;
   TcxButton *cxButton1;
   TCheckBox *chkPeriod1;
   TBevel *Bevel10;
   TLabel *Label14;
   TBevel *Bevel11;
   TcxButton *btnSegmentation;
   TglGroupBox *gbTehOsmotr;
   TLabel *Label12;
   TLabel *Label15;
   TcxComboBox *cboxOperatorTO;
   TBevel *Bevel8;
   TBevel *Bevel9;
   TBevel *Bevel12;
   TsDateEdit *datePeriodS2;
   TsDateEdit *datePeriodE2;
   TsDateEdit *datePeriodS3;
   TsDateEdit *datePeriodE3;
   TBevel *Bevel14;
   TcxMaskEdit *editSeriesTO;
   TStaticText *hintSeriesTO;
   TcxMaskEdit *editNumberTO;
   TStaticText *hintNumberTO;
   TCheckBox *chkNoTehOsmotr;
   TcxComboBox *cboxMonthTO;
   TcxComboBox *cboxYearTO;
   TStaticText *hintMonthTO;
   TStaticText *hintYearTO;
   TBevel *Bevel20;
   TStaticText *hintRegPlate;
   TEdit *editPrevPolicyNumber;
   TEdit *editPrevPolicySeries;
   TBevel *Bevel23;
   TBevel *Bevel26;
   TLabel *Label16;
   TMemo *memSpecialNotes;
   TLabel *Label74;
   TLabel *Label59;
   TEdit *editPDSeries;
   TEdit *editPDNumber;
   TEdit *editAutorizationCode;
   TcxComboBox *cboxPaymentType;
   TcxComboBox *cboxPaymentSposob;
   TcxComboBox *cboxPaymentDoc;
   TBevel *Bevel25;
   TsDateEdit *editPDDate;
   TStaticText *hintPDDate;
   TLabel *Label17;
   TcxComboBox *cboxPolicySeries;
   TcxButton *btnCheckTO;
   TLabel *Label7;
   TcxComboBox *cboxOwLicenseTypeF;
   TCheckBox *chkOwNoLicenseF;
   TcxMaskEdit *editOwLicenseNumberF;
   TcxMaskEdit *editOwLicenseSeriesF;
   TStaticText *hintOwLicenseSeriesF;
   TStaticText *hintOwLicenseNumberF;
   TLabel *Label8;
   TcxComboBox *cboxOwLicenseTypeIP;
   TCheckBox *chkOwNoLicenseIP;
   TcxMaskEdit *editOwLicenseSeriesIP;
   TcxMaskEdit *editOwLicenseNumberIP;
   TStaticText *hintOwLicenseSeriesIP;
   TStaticText *hintOwLicenseNumberIP;
   TBevel *Bevel24;
   TLabel *Label18;
   TcxCurrencyEdit *editUnladenMass;
   TglGroupBox *gbScanDocs;
   TLabel *labStatusScan;
   TcxGrid *gridInspectionDoc;
   TcxGridDBTableView *gridInspectionDocDBTableView;
   TcxGridDBColumn *gridColumn_DocNumber;
   TcxGridDBColumn *gridColumn_DocName;
   TcxGridDBColumn *gridColumn_DocFile;
   TcxGridDBColumn *gridColumn_StatusLoad;
   TcxGridLevel *gridInspectionDocLevel;
   TcxButton *btnSendDoc;
   TDataSource *ds_documents;
   TOpenDialog *SelectScanDoc;
   TLabel *labVehDoc2;
   TBevel *Bevel27;
   TcxComboBox *cboxVehicleDoc2;
   TcxMaskEdit *editVehDocSeries2;
   TcxMaskEdit *editVehDocNumber2;
   TsDateEdit *editVehDocDate2;
   TStaticText *hintVehDocSeries2;
   TStaticText *hintVehDocNumber2;
   TStaticText *hintVehDocDate2;
   TCheckBox *chkNoDate;
   TcxButton *btnCheckPayment;
   TglGroupBox *gbCK1CK2;
   TLabel *labCK2;
   TcxHyperLinkEdit *editLinkInsuranceCompany;
   TglGroupBox *gbStoa;
   TLabel *Label19;
   TcxComboBox *cboxStoa;
   TBevel *Bevel28;
   TcxButton *btnAddStoa;
   TcxButton *btnDelStoa;
   TcxGrid *gridStoa;
   TcxGridDBTableView *gridStoaDBTableView;
   TcxGridLevel *gridStoaLevel;
   TcxGridDBColumn *gridColumnStoaNumber;
   TcxGridDBColumn *gridColumnStoaChecked;
   TcxGridDBColumn *gridColumnStoaName;
   TcxGridDBColumn *gridColumnStoaAddress;
   TDataSource *ds_stoa;
   TcxButton *btnGetStoaList;
   TglGroupBox *gbCheckMobilePhone;
   TLabel *Label20;
   TLabel *Label21;
   TcxButtonEdit *editbtnCheckCode;
   TcxButtonEdit *editbtnCheckMobileNumber;
   TcxButton *btnPrintStoaList;
   TcxButton *btnCheckA7;
   TLabel *Label22;
   TglGroupBox *gbPaymentMethod;
   TLabel *Label75;
   TcxComboBox *cboxPaymentMethod;
   TcxButton *btnPrint;
   TcxButton *btnErrorsScan;
   TBevel *Bevel29;
   TLabel *Label23;
   TcxComboBox *cboxPTSDouble;
   TglGroupBox *gbSoglasen;
   TCheckBox *chkIsPersonalData;
   TPanel *panPrevDataOwner;
   TLabel *Label24;
   TLabel *Label25;
   TEdit *editPrevOwLastName;
   TEdit *editPrevOwFirstName;
   TEdit *editPrevOwSecondName;
   TcxComboBox *cboxPrevOwDocType;
   TcxMaskEdit *editPrevOwDocSeries;
   TStaticText *hintPrevOwDocSeries;
   TcxMaskEdit *editPrevOwDocNumber;
   TStaticText *hintPrevOwDocNumber;
   TsDateEdit *editTtoDate;
   TStaticText *hintTtoDate;
   TLabel *Label26;
   TLabel *Label27;
   TCheckBox *chkInsuredFullOPF;
   TCheckBox *chkOwFullOPF;
   void __fastcall editPolicySeriesEnter(TObject *Sender);
   void __fastcall editPolicySeriesChange(TObject *Sender);
   void __fastcall editPolicySeriesExit(TObject *Sender);
   void __fastcall cboxRegionEnter(TObject *Sender);
   void __fastcall cboxRegionExit(TObject *Sender);
   void __fastcall hintRegionClick(TObject *Sender);
   void __fastcall cboxSrokPropertiesChange(TObject *Sender);
   void __fastcall dateSrokSChange(TObject *Sender);
   void __fastcall editDocIssueDateIPExit(TObject *Sender);
   void __fastcall hintDocIssueDateIPClick(TObject *Sender);
   void __fastcall editAddressRegPropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall cboxSignPositionEnter(TObject *Sender);
   void __fastcall cboxSignPositionExit(TObject *Sender);
   void __fastcall cboxSignPositionPropertiesChange(TObject *Sender);
   void __fastcall editAddressRegEnter(TObject *Sender);
   void __fastcall editAddressRegExit(TObject *Sender);
   void __fastcall pcInsuredTypeChange(TObject *Sender);
   void __fastcall hintDocSeriesIPClick(TObject *Sender);
   void __fastcall editDocNumberPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error);
   void __fastcall editDocIssueDateIPChange(TObject *Sender);
   void __fastcall editDocSeriesPropertiesChange(TObject *Sender);
   void __fastcall pcOwnerTypeChange(TObject *Sender);
   void __fastcall cboxMultydrivePropertiesChange(TObject *Sender);
   void __fastcall btnCopyClick(TObject *Sender);
   void __fastcall cboxPaymentTypePropertiesChange(TObject *Sender);
   void __fastcall cboxPaymentDocPropertiesChange(TObject *Sender);
   void __fastcall btnCalcClick(TObject *Sender);
   void __fastcall cboxUsagePropertiesChange(TObject *Sender);
   void __fastcall cboxBSOTypePropertiesChange(TObject *Sender);
   void __fastcall ceditNsLiabPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error);
   void __fastcall btnCheckBSOClick(TObject *Sender);
   void __fastcall cboxVehicleTypePropertiesChange(TObject *Sender);
   void __fastcall cboxVehicleDocPropertiesChange(TObject *Sender);
   void __fastcall cboxBrandsPropertiesEditValueChanged(TObject *Sender);
   void __fastcall cboxModelsPropertiesEditValueChanged(TObject *Sender);
   void __fastcall cboxYearsPropertiesChange(TObject *Sender);
   void __fastcall Panel1Resize(TObject *Sender);
   void __fastcall editCostPropertiesChange(TObject *Sender);
   void __fastcall Timer2Timer(TObject *Sender);
   void __fastcall cboxDocTypePhPropertiesChange(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall chkTrailerClick(TObject *Sender);
   void __fastcall btnAddPermittedClick(TObject *Sender);
   void __fastcall btnEditPermittedClick(TObject *Sender);
   void __fastcall gridDopushClick(TObject *Sender);
   void __fastcall cboxCitizenshipPropertiesChange(TObject *Sender);
   void __fastcall Timer3Timer(TObject *Sender);
   void __fastcall tvSaleChannelDblClick(TObject *Sender);
   void __fastcall cboxPaymentSposobPropertiesChange(TObject *Sender);
   void __fastcall RegionComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall popeditRegionPropertiesCloseUp(TObject *Sender);
   void __fastcall btnOKClick(TObject *Sender);
   void __fastcall pcInsuredType_CalcChange(TObject *Sender);
   void __fastcall chkForeignRegClick(TObject *Sender);
   void __fastcall pcOwnerType_CalcChange(TObject *Sender);
   void __fastcall cboxLsKvtPropertiesChange(TObject *Sender);
   void __fastcall chkViolationsClick(TObject *Sender);
   void __fastcall chkTransitClick(TObject *Sender);
   void __fastcall chkOwResidentClick(TObject *Sender);
   void __fastcall cboxOwLicenseTypeFPropertiesChange(TObject *Sender);
   void __fastcall chkOwNoLicenseFClick(TObject *Sender);
   void __fastcall chkPeriod3Click(TObject *Sender);
   void __fastcall chkPeriod2Click(TObject *Sender);
   void __fastcall cboxDocTypePropertiesChange(TObject *Sender);
   void __fastcall cboxMonthTOPropertiesChange(TObject *Sender);
   void __fastcall cboxYearTOPropertiesChange(TObject *Sender);
   void __fastcall cboxOperatorTOPropertiesChange(TObject *Sender);
   void __fastcall chkNoTehOsmotrClick(TObject *Sender);
   void __fastcall cboxPolicySeriesPropertiesChange(TObject *Sender);
   void __fastcall KbmInfo_ButtonItemPropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall btnCheckTOClick(TObject *Sender);
   void __fastcall gridInspectionDocDBTableViewEditValueChanged(TcxCustomGridTableView *Sender, TcxCustomGridTableItem *AItem);
   void __fastcall gridColumn_DocFilePropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall btnSendDocClick(TObject *Sender);
   void __fastcall btnCheckPaymentClick(TObject *Sender);
   void __fastcall cboxStoaPropertiesChange(TObject *Sender);
   void __fastcall btnAddStoaClick(TObject *Sender);
   void __fastcall btnDelStoaClick(TObject *Sender);
   void __fastcall gridStoaDBTableViewEditValueChanged(TcxCustomGridTableView *Sender, TcxCustomGridTableItem *AItem);
   void __fastcall gridStoaDBTableViewEditKeyDown(TcxCustomGridTableView *Sender, TcxCustomGridTableItem *AItem, TcxCustomEdit *AEdit, WORD &Key, TShiftState Shift);
   void __fastcall btnGetStoaListClick(TObject *Sender);
   void __fastcall editbtnCheckCodePropertiesChange(TObject *Sender);
   void __fastcall editbtnCheckCodePropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall editbtnCheckMobileNumberPropertiesButtonClick(TObject *Sender, int AButtonIndex);
   void __fastcall btnPrintStoaListClick(TObject *Sender);
   void __fastcall cboxPaymentMethodPropertiesChange(TObject *Sender);
   void __fastcall btnCheckA7Click(TObject *Sender);
   void __fastcall btnPrintClick(TObject *Sender);
   void __fastcall btnErrorsScanClick(TObject *Sender);
   void __fastcall editLinkInsuranceCompanyClick(TObject *Sender);
   void __fastcall chkIsPersonalDataClick(TObject *Sender);
   void __fastcall cboxPrevOwDocTypePropertiesChange(TObject *Sender);
   void __fastcall chkOwFullOPFClick(TObject *Sender);
private:	// User declarations
   mops_api_028 *m_api;
   TADOQuery *q, *territory, *q_scan_docs, *q_stoa;
   TStringList *error, *sl;

   TfrmErrReport *frmErrPeport;

   TfrmInfoRsa *frmInfoRsa;

   PersonInfo *pi, pi_temp, *pm;
   Dogovor_Info *di;
   VehicleInfo *vi;

   LoadDictionary<TframeCalc> load_dict;
   SetOfDict Dicts;

   _di_IXMLDocument XMLDoc;
   _di_IXMLNode Root;

   kbm_of_rsa *kbm_rsa;

   AnsiString sql, old_policy_blank, old_policy_series, old_policy_number;
   int res, curr_year, result_check_bso, result_check_bso_a7, mid_obosn_ka, mid_alarms_terms, mid_bp_error_text, memo_id_wch;
   double kt; 
public:
   TRichEdit *TotalInfo;
private:
   bool Error(const AnsiString& text, const int unique, bool term, int warning = 0, const AnsiString& type_error = err_all);

   void ResetVehicleInfo(TObject *Sender);

   void ClearControls(TWinControl *wc);
   void ClearPageControl(TcxPageControl *pc);
   void ClearPaymentControls();
   void SetOwnerDataInControls(bool copy = true);

   void SetPosAndParentRedFrame(const TRect& r, TWinControl *parent);

   void CalcText();

   void SaveToMemoTable(AnsiString memo_text, TADOQuery *qq, const AnsiString& fieldname, int& mid);

   void SetupGrid(const AnsiString& table_name, const AnsiString& sortfield_name, const int calc_id, TADOQuery **qq, TDataSource **ds);
   void SetupGrids(const int calc_id);

   void SetSaleChannel();

   AnsiString GetTextFromPanRegion();

   void PeretrubationOwnerControls();
   void SetHeightsOwnerControls(const int h1, const int h2, const int h, const int h4);

   void SetcboxLsKvt(const AnsiString& text);
   void SetPropertieseditMassOrSeats();

   bool CheckPeriods();

   void SetStateControlsForeignOrTransit(bool state, const AnsiString& text_region);

   void SetCoeffsToControls();

   void SetStatePeriods(const AnsiString& period, bool state);

   void SetStateControlsTehOcmotr();

   AnsiString CheckErrorPermitted();

   int CheckListScanDocs();
   void SetVisiblegbScanDoc(const int what_the_fuck_button = 1);
   void InsertScanDoc(const int number, const AnsiString& name_doc);
   void SetListScanDocs();

   void SetEnDisControlsVehDoc2();

   void SetInterfaceOnGbStoa();
   int CheckListStoa();

   void SetEnDisControlsPayments();

   void PrintStrInLog();

   void SetPinVin();
public:		// User declarations
   __fastcall TframeCalc(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, Dogovor_Info *p_di, VehicleInfo *p_vi, PersonInfo *p_pm);
   __fastcall ~TframeCalc();
   void SaveFrame(TADOQuery *q_save);
   void LoadFrame(TADOQuery *q_load);
   void Recalc(TObject *Sender);
};
//---------------------------------------------------------------------------
extern PACKAGE TframeCalc *frameCalc;
//---------------------------------------------------------------------------
#endif
