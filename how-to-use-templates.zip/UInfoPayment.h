//---------------------------------------------------------------------------

#ifndef UInfoPaymentH
#define UInfoPaymentH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TfrmInfoPayment : public TForm
{
__published:	// IDE-managed Components
   TcxButton *btnOK;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *labXXX;
   TLabel *labEEE;
   TLabel *Label3;
   TImage *imgEEE;
   TImage *imgXXX;
   void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TfrmInfoPayment(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInfoPayment *frmInfoPayment;
//---------------------------------------------------------------------------
#endif
