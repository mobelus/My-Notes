//---------------------------------------------------------------------------

#ifndef UApproveH
#define UApproveH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
#include "structures.h"
#include <DB.hpp>
#include <DBClient.hpp>
//---------------------------------------------------------------------------
class TfrmApproveList : public TForm
{
__published:	// IDE-managed Components
   TMemo *memApprove;
   TcxButton *btnClose;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall btnCloseClick(TObject *Sender);
private:	// User declarations
   Dogovor_Info *di;
   VehicleInfo *vi;
public:		// User declarations
   __fastcall TfrmApproveList(TComponent* Owner, Dogovor_Info *p_di, VehicleInfo *p_vi);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmApproveList *frmApproveList;
//---------------------------------------------------------------------------
#endif
