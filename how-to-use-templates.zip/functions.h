//---------------------------------------------------------------------------
#ifndef functionsH
#define functionsH
#include "sCurrEdit.hpp"
#include "sTooledit.hpp"
#include "dxInspRw.hpp"
#include "sCheckBox.hpp"
#include "Tmops_api.h"
#include "cxEditRepositoryItems.hpp"
#include "cxVGrid.hpp"
#include "structures.h"
#include "cxDBLookupComboBox.hpp"
#include "cxPC.hpp"
#include "glGrBox.hpp"

static MaskDocType mask_doc_type(person_mask), mask_vehicle_doc_type(vehicle_mask);
extern mops_api_028 *m_api;

//---------------------------------------------------------------------------

AnsiString S(const double& x);
AnsiString FormatDigits(const double& x);
AnsiString FloatToSQLStr(const double& f);
AnsiString FloatToSQLStr(AnsiString s);
AnsiString StrToFloatStr(const AnsiString& s, const AnsiString& def = "0");
AnsiString FloatToIntStr(const double& f);
int CalcYears(const TDateTime& dt1, const TDateTime& dt2);
int GetIndexObject(TStrings* lst, const int& val);
int GetIndexItemByTag(TcxRadioGroupItems*, const int t);
void ResetChk(TCheckBox* chk, ptr_onclick onclick = 0);
void ResetCxChk(TcxCheckBox* chk, ptr_onclick onclick = 0);
void ResetSChk(TsCheckBox* chk, ptr_onclick onclick = 0);
void SetValueCheckBox(TCheckBox* chk, const int v, ptr_onclick onclick);
void SetValueCxCheckBox(TcxCheckBox* chk, const int v, ptr_onclick onclick);
void SetValueEdit(TEdit *cedit, const AnsiString& val, ptr_onchange onchange);
void SetValueCalcEdit(TsCalcEdit *cedit, const double& val, ptr_onchange onchange);
void SetValueDateEdit(TsDateEdit *dedit, const TDateTime& val, ptr_onchange onchange);
void SetValueRowDateEdit(TcxEditorRow *dedit, const TDateTime& val);
void SetValueRowDateEdit(TcxDateEdit *dedit, const TDateTime& val);
TDateTime CalcEndDateInsur(const TDateTime& start_date, const int srok_month);
AnsiString FirstUpper(const AnsiString& str, const int is_end_to_lower = 0);
AnsiString AddNulls(const AnsiString& str, const int count);
AnsiString ClearPhoneNumber(const AnsiString& str);
void FilterDataSet(TADOQuery *qq, const AnsiString& filter);
void FilterDataSet(TClientDataSet *qq, const AnsiString& filter);
bool CheckVIN(const AnsiString& vin);
bool CheckIdentNumber(const AnsiString& indent_number);
bool CheckRegPlate(const AnsiString& rgpl);
AnsiString NodeToStr(_di_IXMLNode node);
AnsiString NormVIN_GN(mops_api_025 *m_api, const AnsiString& numb);
void SeparateFIO(const AnsiString& fio, const int status, AnsiString& lname, AnsiString& fname, AnsiString& sname);
void MakeKladrAddrFromARM(mops_api_028 *_m_api, _di_IXMLNode child_node, TStringList* addr, int& memo_id);
void MakeKladrAddrFromUXML(mops_api_028 *_m_api, _di_IXMLNode person, TStringList *addr, int& memo_id, AnsiString& exact_address);
bool CheckAddrList(TStringList* addrlist);
AnsiString MobileToMask(const AnsiString& ph_mob);
void GetPhones(_di_IXMLNode contacts, AnsiString& ph_mob, AnsiString& ph_home, AnsiString& ph_rab, AnsiString& email, int &sms);
AnsiString IntToBin(const int ANumber, int ABitCount = 32);
bool FieldValueIDToVGEditor(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row);
bool FieldValueIDToVGEditor_(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row);
void ChangeMask(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMaskPrev(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMaskLicense(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMaskLicense(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");

int GetDrvCount(TADOQuery *qq);
int GetCountPermitted(TListView *gridDopush);
int MonthsCount(const TDateTime& ANow, const TDateTime& AThen);
int DaysCount(const TDateTime& ANow, const TDateTime& AThen);
void VariantToDate(Variant v, TDateTime& dt);
void PmDataToRecord(TADOQuery* q_perm, PersonInfo *pm, const int calc_id, const int num, const int i, const int pm_status);
void SetTextTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange = 0);
void ClearTcxComboBox(TcxComboBox *cbox, ptr_onchange onchange);
void SetIndexTcxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange = 0, const int type = 1/* 0 - ��������, 1 - object*/, const Variant& default_value = variant_null, const int en_dis = 1);
void SetValuecxCurrencyEdit(TcxCurrencyEdit *cedit, const Variant& value, ptr_onchange onchange = 0);
void SetEnterInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange);
void ExitFromEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange);
void SetEnterInComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange);
void ExitFromComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange);
void SetEnterInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit);
void ExitFromButtonEditBox(const AnsiString& str, TcxButtonEdit *edit);
void SetTextAndColorInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange);
void SetTextAndColorInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit);
void SetValueAndHintInDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange, TStaticText *hint);
void SetValueAndHintInMaskEdit(TcxMaskEdit* edit, const AnsiString& str, ptr_onchange onchange, TStaticText *hint);
void SetIndexAndHintIncxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange, const int type, TStaticText *hint);
void SetIndexTocxRadioGroup(TcxRadioGroup *rg, const int index, ptr_onclick onclick);
void SetValueTocxLookupComboBox(TcxLookupComboBox *cbox, const Variant& value, ptr_oneditvaluechanged oneditvaluechanged);
void SetHeightsToPcAndGb(TcxPageControl *pc, TglGroupBox *gb, Dogovor_Info *di = 0);
void SetActivePageTocxPageControl(TcxPageControl *pc, TcxTabSheet *sh, ptr_onchange onchange);
void SetPageControls(TcxPageControl *pc_calc, TcxPageControl *pc, const int no_change = 0, ptr_onchange onchange = 0);
void SetTextAndColorTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange);
AnsiString ReservToStr(const std::set<int>& s);
void SetValuecxSpinEdit(TcxSpinEdit *spinedit, const double& value, ptr_onchange onchange, ptr_onvalidate onvalidate);
void LoadDataCurrentUser(mops_api_028 *m_api, Dogovor_Info *p_di);
void MakeExportFilters(TSaveDialog *sd, Dogovor_Info *di, Map_Int_Str &filter);
AnsiString Translit_Text(const AnsiString& source, const int rus_lat = 0);
void SetValueRadioButton(TRadioButton *rb, const int v, ptr_onclick onclick);
bool VariantIsBad(const Variant& v){ return v.IsNull() || v.IsEmpty() || !v.intVal || AnsiString(v) == "+7("; };
void CreatePDF(mops_api_028 *m_api, AnsiString doc, TMemoryStream *pdf);
AnsiString NodeAttributeToStr(_di_IXMLNode node, const AnsiString& name, const AnsiString& value);
AnsiString ClearStr(const AnsiString& str);
int GetVehicleGroup(mops_api_028 *m_api, const int vehicle_type_id, const AnsiString& rsa_code, const int allowed_mass, const int number_of_seats, const AnsiString& calc_date);
__int64 FileSize(const AnsiString& fn);
AnsiString VariantToStr(const Variant& v);
void SetPosAndParentToPanel(TWinControl *parent, TPanel *panTop, TPanel *panDown);
void SetValuecxButtonEdit(TcxButtonEdit *cbtnedit, const AnsiString& str, ptr_onchange onchange = 0);
AnsiString CreateCorrelationId();
bool Is8Symbols(const AnsiString& str);
void SetAlignAndTop(TControl *cntrl, const TAlign& algn, const int t);
//---------------------------------------------------------------------------

#endif



