//---------------------------------------------------------------------------

#ifndef UErrorsH
#define UErrorsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TfrmErrReport : public TForm
{
__published:	// IDE-managed Components
   TMemo *memErrors;
   TcxButton *btnClose;
   void __fastcall btnCloseClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TfrmErrReport(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmErrReport *frmErrReport;
//---------------------------------------------------------------------------
#endif
