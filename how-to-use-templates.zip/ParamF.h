//---------------------------------------------------------------------------

#ifndef ParamFH
#define ParamFH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include "sComboBox.hpp"
#include "sCurrEdit.hpp"
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "Transdekra_funcs.h"
#include <Buttons.hpp>
#include <jpeg.hpp>
#include "cxControls.hpp"
#include "cxDBEditRepository.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"
#include "structures.h"
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include <Menus.hpp>
#include "cxContainer.hpp"
#include "cxDropDownEdit.hpp"
#include "cxMaskEdit.hpp"
#include "cxTextEdit.hpp"
//---------------------------------------------------------------------------

class TfrmInfoRsa : public TForm{
__published:	// IDE-managed Components
   TPanel *PanBtn;
   TcxEditRepository *cxEditRepository1;
   TcxButton *btnCancel;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *cxStyle3;
   TcxStyle *cxStyleGreen;
   TcxVerticalGrid *vg;
   TcxCategoryRow *vgHeaderResponse;
   TcxCategoryRow *vgStateResponse;
   TcxEditRepositoryTextItem *TextItem;
   TcxEditorRow *vgRequestId;
   TcxStyle *cxStyleRed;
   TcxCategoryRow *vgHeaderResponseKbm;
   TcxCategoryRow *vgStateResponseKbm;
   TcxEditorRow *vgKbmClass;
   TcxEditorRow *vgKbmValue;
   TcxEditorRow *vgLossAmount;
   TcxCategoryRow *vgHeaderPolicy;
   TcxEditorRow *vgPolicySeries;
   TcxEditorRow *vgPolicyNumber;
   TcxEditorRow *vgCompany;
   TPanel *Panel1;
   TLabel *Label37;
   TcxComboBox *cboxRsaResponseType;
   void __fastcall btnCancelClick(TObject *Sender);
   void __fastcall cboxRsaResponseTypePropertiesChange(TObject *Sender);
private:	// User declarations
   mops_api_028 *m_api;
   Dogovor_Info *di;
   PersonInfo *pm;
public:		// User declarations
   __fastcall TfrmInfoRsa(TComponent* Owner, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pm);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInfoRsa *frmInfoRsa;
//---------------------------------------------------------------------------
#endif
