//---------------------------------------------------------------------------
#define NO_WIN32_LEAN_AND_MEAN
#include "UCalc.h"
#include "itogi.h"
#include <SysUtils.hpp>
#include <shlobj.h>
#include "functions.h"
#include <math.h>
#include <DateUtils.hpp>
#include "UThreadUFO.h"
#include "XML_progress_form_c.h"
#include "GhostScriptManager.h"
#include "UInfoPayment.h"
#include "UErrors.h"
#include "UModifyReasonSelect.h"
#include "UModifyPreparePrintData.h"
#include "UReissCalc.h"
#include "IAPO2_ARM_READER.h"

#include "frxDesgn.hpp"
#include "frxClass.hpp"
#include "frxDBSet.hpp"


//---------------------------------------------------------------------------
#pragma hdrstop
//---------------------------------------------------------------------------
extern "C" void __declspec(dllexport) Create_Frames(TList *frames, TStringList *frames_names);
extern "C" int  __declspec(dllexport) Save_Frame(void *Frame, long id_calc);
extern "C" int  __declspec(dllexport) Save_Frames(TList *frames, long id_calc);
extern "C" int  __declspec(dllexport) Load_Frame(void *Frame, long id_calc);
extern "C" int  __declspec(dllexport) Load_Frames(TList *frames, long id_calc);
extern "C" void __declspec(dllexport) Get_Main_Grid_Tables(TStringList *Tables);
extern "C" void __declspec(dllexport) Get_Module_Print_Forms_Names(TStringList *form_names);
extern "C" int  __declspec(dllexport) Print_Form(AnsiString form_name, long id_calc);
extern "C" int  __declspec(dllexport) Universal_Func(AnsiString command, void *lparam, void *hparam);
extern "C" void __declspec(dllexport) Init_API(void *_Mops_Api);
extern "C" void __declspec(dllexport) Get_Main_Menu(TMainMenu **M_Menu);
extern "C" void __declspec(dllexport) OnMenuClick(TObject *Sender);
extern "C" int  __declspec(dllexport) On_User_Copy_Paste(AnsiString &XML, bool Copy_Flag);
extern "C" int  __declspec(dllexport) OnFastReport(AnsiString Form_Name, int form_type/*0 - ����� 1 - �����*/, long calc_id, int action/*0 - ������, 1 - ������, 2 - ��������*/, TList *data_sets);
//---------------------------------------------------------------------------

mops_api_028 *m_api;

TfrmErrReport *frmPeport(0);

SkkQuery skkq;

int res;
bool PreViewFlag, is_message(true);

TMenuItem *mp_2(0), *mp_1(0), *mp_2_1(0), *mp_3(0), *mp_4_1(0), *mp_7(0), *md_22(0), *mp_4_2(0), *mo_1(0), *mo_2(0);
AnsiString desktop_folder, ander_fio, ander_email, File_Osago_Instruction;

PersonInfo pi[2], pm[50];
VehicleInfo vi;
Dogovor_Info di;

//---------------------------------------------------------------------------
void ResetData()
{
   for(int i = 0; i < 2;  ++i){ pi[i].status = 1; pi[i].Reset(); pm[i].prev_doc_type = 12; }
   for(int i = 0; i < 50;  ++i){ pm[i].status = 1; pm[i].Reset(); pm[i].prev_doc_type = 17; }
   vi.Reset(); di.Reset();
}
//---------------------------------------------------------------------------
void PrintStrInLog()
{
   int index = frmPeport->memErrors->Lines->Count - 1;
   for(int i = 0; i < 3; ++i){
      frmPeport->memErrors->Lines->Strings[index] = frmPeport->memErrors->Lines->Strings[index] + dot;
      Application->ProcessMessages();
      Sleep(333);
   }
}
//------------------------------------------------------------------------------
void InsertCurrentUser(const AnsiString& calc_id_str)
{
   TADOQuery *q_insurer = m_api->dbGetCursor(res, "select * from osago_insurer where calc_id=" + calc_id_str, 0, 0);
   di.user_info.Reset();
   di.user_info.user_id = m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0);
   LoadDataCurrentUser(m_api, &di);

   q_insurer->CursorLocation = clUseServer;
   q_insurer->Open();

   if(q_insurer->IsEmpty()) q_insurer->Insert();
   else                     q_insurer->Edit();

   q_insurer->FieldByName("calc_id")->Value = calc_id_str;
   q_insurer->FieldByName("saler_name_normal")->Value = di.user_info.name;
   q_insurer->FieldByName("saler_name")->Value = di.user_info.name_format;
   q_insurer->FieldByName("filial_short")->Value = di.user_info.filial;
   q_insurer->FieldByName("sign_position_normal")->Value = di.user_info.post_normal;
   q_insurer->FieldByName("sign_position")->Value = di.user_info.post;
   q_insurer->FieldByName("sign_document")->Value = di.user_info.accrediting;
   q_insurer->FieldByName("sign_document_number")->Value = di.user_info.accrediting_number;
   q_insurer->FieldByName("sign_document_date")->Value = di.user_info.accrediting_date;
   q_insurer->FieldByName("city")->Value = di.user_info.city;
   q_insurer->FieldByName("osp")->Value = di.user_info.osp;
   q_insurer->FieldByName("skk")->Value = di.user_info.skk;
   q_insurer->FieldByName("lnr")->Value = di.user_info.lnr;
   q_insurer->FieldByName("phone")->Value = di.user_info.phone;
   q_insurer->FieldByName("sale_channel_id")->Value = di.user_info.sale_channel_id;
   q_insurer->FieldByName("user_id_lnk")->Value = di.user_info.user_id;
   q_insurer->FieldByName("arm_agent_id")->Value = di.user_info.agent_id;
   q_insurer->FieldByName("office_id")->Value = di.user_info.office_id;
   q_insurer->FieldByName("office_type")->Value = di.user_info.office_type;

   q_insurer->Post();
   m_api->dbCloseCursor(res, q_insurer);
}
//------------------------------------------------------------------------------
void GetPathDesktopUser()
{
   LPITEMIDLIST pidl;
   LPMALLOC pShellMalloc;
   char szDir[MAX_PATH];

   if(SUCCEEDED(SHGetMalloc(&pShellMalloc))){
      if(SUCCEEDED(SHGetSpecialFolderLocation(0, CSIDL_DESKTOPDIRECTORY, &pidl))){
         if(SHGetPathFromIDList(pidl, szDir)) desktop_folder = IncludeTrailingBackslash(szDir);
         pShellMalloc->Free(pidl);
      }
      pShellMalloc->Release();
   }
}
//---------------------------------------------------------------------------
void SaveMemoToNode(const int m_id, _di_IXMLNode node)
{
   int memo_id = m_id;
   AnsiString memo_text("");
   m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, true, "osago_memo");
   node->Text = StringReplace(memo_text, "\r\n", ";", rf);
}
//---------------------------------------------------------------------------
void SaveNodeToMemo(_di_IXMLNode node, TADOQuery* q, const AnsiString& fieldname)
{
   int memo_id(0);
   AnsiString st = StringReplace(NodeToStr(node), ";", "\r\n", rf);
   if(!st.IsEmpty()) m_api->dbReadWriteInternalMemo(res, st, memo_id, false, "osago_memo");
   q->FieldByName(fieldname)->Value = memo_id;
}
//---------------------------------------------------------------------------
void FillNode(_di_IXMLNode node, const AnsiString& attrib_text, const AnsiString& text)
{
   node->Text = text;
   node->Attributes["code"] = attrib_text;
}
//---------------------------------------------------------------------------
void XML_Save_Query_Row(_di_IXMLNode node, TADOQuery *q, TStringList *sl_fields_no_save)
{
   for(int j = 0, fcnt = q->FieldCount; j < fcnt; ++j){
      TFieldType ft = q->Fields->Fields[j]->DataType;
      AnsiString fname = q->Fields->Fields[j]->DisplayName;
      if(sl_fields_no_save->IndexOf(fname) == -1) node->AddChild(fname)->Text = (ft != ftDateTime) ? q->Fields->Fields[j]->AsString : IntToStr((int)q->Fields->Fields[j]->AsDateTime.Val);
   }
}
//---------------------------------------------------------------------------
void XML_Save_Query_Row_APO(_di_IXMLNode node, TADOQuery *q)
{
   _di_IXMLNode calc = node->AddChild("osago_calcs")->AddChild("osago_calc"),
               person = node->AddChild("osago_persons"),
               vehicle = node->AddChild("osago_vehicles"),
               policy = node->AddChild("osago_policys"),
               insurer = node->AddChild("osago_insurers");
   AnsiString memo_text;
   int memo_id;

   TStringList *sl_fields_no_save = new TStringList();
   sl_fields_no_save->Text = "calc_id\r\naddr_mid\r\nmemo_id_lnk\r\nmid_validation\r\nmid_oi_errors\r\nmid_non_standart\r\nmemo_id_whatchange";

   XML_Save_Query_Row(calc, q, sl_fields_no_save);
   SaveMemoToNode(q->FieldByName("mid_validation")->AsInteger,   calc->AddChild("validation"));
   SaveMemoToNode(q->FieldByName("mid_oi_errors")->AsInteger,    calc->AddChild("oi_errors"));
   SaveMemoToNode(q->FieldByName("mid_non_standart")->AsInteger, calc->AddChild("non_standart"));

   TADOQuery *q_persons = m_api->dbGetCursor(res, "select * from osago_persons where calc_id=" + q->FieldByName("calc_id")->AsString + " order by type_person");
   if(!q_persons->IsEmpty()){
      for(q_persons->First(); !q_persons->Eof; q_persons->Next()){
         _di_IXMLNode child_node = person->AddChild("osago_person");
         XML_Save_Query_Row(child_node, q_persons, sl_fields_no_save);
         SaveMemoToNode(q_persons->FieldByName("addr_mid")->AsInteger, child_node->AddChild("kladr_address"));
      }
   }
   m_api->dbCloseCursor(res, q_persons);

   TADOQuery *q_vehicles = m_api->dbGetCursor(res, "select * from osago_vehicle where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_vehicles->IsEmpty()){
      for(q_vehicles->First(); !q_vehicles->Eof; q_vehicles->Next()){
         _di_IXMLNode child_node = vehicle->AddChild("osago_vehicle");
         XML_Save_Query_Row(child_node, q_vehicles, sl_fields_no_save);
      }
   }
   m_api->dbCloseCursor(res, q_vehicles);

   TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_policy->IsEmpty()){
      for(q_policy->First(); !q_policy->Eof; q_policy->Next()){
         _di_IXMLNode child_node = policy->AddChild("osago_policy");
         XML_Save_Query_Row(child_node, q_policy, sl_fields_no_save);
      }
   }
   m_api->dbCloseCursor(res, q_policy);

   TADOQuery *q_insurer = m_api->dbGetCursor(res, "select * from osago_insurer where calc_id=" + q->FieldByName("calc_id")->AsString);
   if(!q_insurer->IsEmpty()){
      for(q_insurer->First(); !q_insurer->Eof; q_insurer->Next()) XML_Save_Query_Row(insurer->AddChild("osago_insurer"), q_insurer, sl_fields_no_save);
   }
   m_api->dbCloseCursor(res, q_insurer);

   delete sl_fields_no_save;
}
//---------------------------------------------------------------------------
void MakeHead(_di_IXMLDocument& XMLDoc, _di_IXMLNode& node)
{
   XMLDoc->Active = false;
   XMLDoc->XML->Clear();
   XMLDoc->Active = true;
   XMLDoc->Options.Clear();
   XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;
   XMLDoc->Version       = "1.0";
   XMLDoc->Encoding      = "WINDOWS-1251";
   XMLDoc->StandAlone    = "no";
   XMLDoc->NodeIndentStr = "    ";

   _di_IXMLNode Root = XMLDoc->CreateNode("ROOT");
   XMLDoc->DocumentElement = Root;
   Root->Attributes["export_date"]    = Now().DateTimeString();
   Root->Attributes["export_date_d"]  = IntToStr((int)(Date().Val));
   Root->Attributes["Module"]         = AnsiString("OSAGO2");
   Root->Attributes["partner"]        = AnsiString("APO2");
   Root->Attributes["export_version"] = AnsiString("01");

   Root = XMLDoc->DocumentElement;
   node = Root->AddChild("policys");
}
//---------------------------------------------------------------------------
int XMLSave(int save_type, const AnsiString& init_dir = empty_str, AnsiString& filename = AnsiString("")) // 1 - ���; 2 - ����� � ������������; 3 - ������� ������
{
   int result(0);

   TSaveDialog *sd = new TSaveDialog(0);
   sd->Filter = "XML|*.xml";
   sd->DefaultExt = "xml";
   sd->InitialDir = init_dir;
   sd->FileName = filename;

   if(sd->Execute()){
      filename = sd->FileName;
      AnsiString sql = "select t.*,mc.GUID_Str as guid_str,mc.status_id from osago_calc t, _mops_calcs_ mc where t.calc_id=mc.[id] and mc.deleted=0";
      switch(save_type){
         case 2: sql = sql + " and t.date_unload is NULL"; break;
         case 3: sql = sql + " and t.calc_id=" + IntToStr(m_api->dbGet_Main_Grid_Current_CalcID(res)); break;
      }
      TADOQuery *q = m_api->dbGetCursor(res, sql);

      _di_IXMLDocument XMLDoc = NewXMLDocument();
      _di_IXMLNode node;
      MakeHead(XMLDoc, node);

      TProgress_Form *pr = new TProgress_Form(0);
      pr->progressGauge->MinValue = 0;
      pr->progressGauge->MaxValue = q->RecordCount;
      pr->Show();
      for(q->First(); !q->Eof; q->Next(), Application->ProcessMessages()){
         m_api->dbExecuteQuery(res, "update osago_calc set date_unload=Now() where calc_id=" + q->FieldByName("calc_id")->AsString);
         XML_Save_Query_Row_APO(node->AddChild("policy"), q);
         pr->progressGauge->Progress = q->RecNo;
      }
      m_api->dbCloseCursor(res, q);
      delete pr;

      XMLDoc->SaveToFile(filename);
      delete XMLDoc;
      result = 1;
   }
   delete sd;

   return result;
}
//---------------------------------------------------------------------------
void LoadXMLToTable(_di_IXMLNode node, const AnsiString& table_name, const int calc_id, TStringList *sl_fields, TStringList *sl_tags)
{
   m_api->dbExecuteQuery(res, "delete * from " + table_name + " where [calc_id]=" + IntToStr(calc_id));
   TADOQuery *q = m_api->dbGetCursor(res, "select * from " + table_name + " where calc_id=" + IntToStr(calc_id), 0, 0);

   q->CursorLocation = clUseServer;
   q->Open();

   for(int i = 0, cnt = node->ChildNodes->Count; i < cnt; ++i){
      _di_IXMLNode child_node = node->ChildNodes->Get(i);
      q->Insert();
      for(int j = 0, fcnt = q->FieldCount; j < fcnt; ++j){
         AnsiString fname = q->Fields->Fields[j]->DisplayName;
         TFieldType ft = q->Fields->Fields[j]->DataType;
         if(ft == ftFloat) q->Fields->Fields[j]->Value = StrToFloatStr(NodeToStr(child_node->ChildNodes->FindNode(q->Fields->Fields[j]->DisplayName))).ToDouble();
         else if(ft == ftDateTime || ft == ftDate || ft == ftTime) q->Fields->Fields[j]->Value = TDateTime(NodeToStr(child_node->ChildNodes->FindNode(q->Fields->Fields[j]->DisplayName)).ToIntDef(0));
         else q->Fields->Fields[j]->AsString = NodeToStr(child_node->ChildNodes->FindNode(q->Fields->Fields[j]->DisplayName));
      }
      q->FieldByName("calc_id")->Value = calc_id;
      for(int j = 0, sl_cnt = sl_fields->Count; j < sl_cnt; ++j) SaveNodeToMemo(child_node->ChildNodes->FindNode(sl_tags->Strings[j]), q, sl_fields->Strings[j]);
      q->Post();
   }
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
int XMLLoad(const AnsiString& xml_text, const int anderr = 0)
{
   TStringList *sl_fields = new TStringList(), *sl_tags = new TStringList();

   _di_IXMLDocument XMLDoc = NewXMLDocument();

   try{

      XMLDoc->Active = true;
      XMLDoc->Options.Clear();
      XMLDoc->LoadFromXML(xml_text);

      _di_IXMLNode Root = XMLDoc->DocumentElement, policy = Root->ChildNodes->FindNode("policys");
      int calc_id(0), cnt_pol = policy->ChildNodes->Count;
      for(int p = 0; p < cnt_pol; ++p){
         _di_IXMLNode calc_node = policy->ChildNodes->Get(p)->ChildNodes->FindNode("osago_calcs")->ChildNodes->FindNode("osago_calc");
         calc_id = m_api->dbInsert_Empty_Calc(res);

         // calc
         sl_fields->Text = "mid_validation\r\nmid_oi_errors\r\nmid_non_standart";
         sl_tags->Text = "validation\r\noi_errors\r\nnon_standart";
         LoadXMLToTable(policy->ChildNodes->Get(p)->ChildNodes->FindNode("osago_calcs"), "osago_calc", calc_id, sl_fields, sl_tags);
         if(!anderr) m_api->dbExecuteQuery(res, "update osago_calc set no_calc=1 where calc_id=" + IntToStr(calc_id));

         // �������
         sl_fields->Text = "addr_mid"; sl_tags->Text = "kladr_address";
         LoadXMLToTable(policy->ChildNodes->Get(p)->ChildNodes->FindNode("osago_persons"), "osago_persons", calc_id, sl_fields, sl_tags);

         sl_fields->Clear(); sl_tags->Clear();
         // ����������
         LoadXMLToTable(policy->ChildNodes->Get(p)->ChildNodes->FindNode("osago_vehicles"), "osago_vehicle", calc_id, sl_fields, sl_tags);

         // �������
         LoadXMLToTable(policy->ChildNodes->Get(p)->ChildNodes->FindNode("osago_policys"), "osago_policy", calc_id, sl_fields, sl_tags);
         m_api->dbExecuteQuery(res, "update osago_policy set contract_id=null,no_check_payment=1,stoa_request_id=null,stoa_result_status=0,result_check_bso=888,send_code=0,confirm_code=0,result_check_bso_a7=888 where calc_id=" + IntToStr(calc_id));

         // ������������� �����������
         InsertCurrentUser(IntToStr(calc_id));
      }
      delete XMLDoc;

      m_api->Module_Refresh_Main_Grid(res);

      if(cnt_pol == 1){ delete XMLDoc; delete sl_fields; delete sl_tags; return calc_id; }
   }
   catch(Exception& ex) { ShowMessage("�������� XML APO2: " + ex.Message + "\r\n��������, �������� ������ XML");}
   catch(...) { ShowMessage("�������� XML APO2: FATAL ERROR"); }

   delete sl_fields; delete sl_tags;
   delete XMLDoc;

   return 0;
}
//---------------------------------------------------------------------------
void XMLLoadOIB(const AnsiString& xml_text)
{
   try{
      AnsiString sql(""), m("m"), c("c"), attr_i("i"), attr_v("v");
      int drv_i(4), i_val;
      TDateTime quotes_date = Date();

      _di_IXMLDocument XMLDoc = NewXMLDocument();
      XMLDoc->LoadFromXML(xml_text);
      XMLDoc->Active = true;

      _di_IXMLNode root_rate = XMLDoc->DocumentElement, rate_node_c(0), curr_node(0), curr_node2(0), curr_node3(0);

      int calc_id = m_api->dbInsert_Empty_Calc(res);
      di.user_info.user_id = m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0);
      m_api->dbExecuteQuery(res, sql.sprintf("update _mops_calcs_ set id_polzovatelya=%i where [id]=%i", di.user_info.user_id, calc_id));
      m_api->dbExecuteQuery(res, sql.sprintf("insert into osago_persons (calc_id,type_person,status) values(%i,1,1)", calc_id));
      m_api->dbExecuteQuery(res, sql.sprintf("insert into osago_persons (calc_id,type_person,status) values(%i,2,1)", calc_id));
      InsertCurrentUser(IntToStr(calc_id));

      TADOQuery *q_temp,
                *q_calc = m_api->dbGetCursor(res, sql.sprintf("select * from osago_calc where calc_id=%i", calc_id), 0, 1),
                *q_policy = m_api->dbGetCursor(res, sql.sprintf("select * from osago_policy where calc_id=%i", calc_id), 0, 1),
                *q_vehicle = m_api->dbGetCursor(res, sql.sprintf("select * from osago_vehicle where calc_id=%i", calc_id), 0, 1),
                *q_ins = m_api->dbGetCursor(res, sql.sprintf("select * from osago_persons where type_person=1 and calc_id=%i", calc_id), 0, 1),
                *q_bnf = m_api->dbGetCursor(res, sql.sprintf("select * from osago_persons where type_person=2 and calc_id=%i", calc_id), 0, 1),
                *q_drv = m_api->dbGetCursor(res, sql.sprintf("select * from osago_persons where type_person>2 and calc_id=%i", calc_id), 0, 1);

      rate_node_c = root_rate->ChildNodes->FindNode("c");
      if(rate_node_c){
         q_ins->Edit(); q_bnf->Edit(); q_calc->Insert(); q_vehicle->Insert(); q_policy->Insert();

         q_policy->FieldByName("calc_id")->Value = calc_id;
         q_vehicle->FieldByName("calc_id")->Value = calc_id;
         q_calc->FieldByName("calc_id")->Value = calc_id;

         for(int i = 0, cnt = rate_node_c->ChildNodes->Count; i < cnt; ++i){
            curr_node = rate_node_c->ChildNodes->Get(i);
            if(curr_node->HasAttribute(attr_i)){
               if(curr_node->NodeName == m){
                  AnsiString curr_value = NodeAttributeToStr(curr_node, attr_v, attr_v).Trim();
                  switch(AnsiString(curr_node->Attributes[attr_i]).ToIntDef(0)){
                     case 2:  q_policy->FieldByName("srok_date_s")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                     case 3:  q_policy->FieldByName("srok_date_po")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                     case 41: q_policy->FieldByName("bank_id")->AsInteger = m_api->dbGetIntFromQueryDef(res, "select bank_id from gl_dict_banks where bank_code=" + QuotedStr(curr_value)); break;
                     case 45: q_policy->FieldByName("region_id")->AsInteger = curr_value.ToIntDef(77); break;
                     case 47:
                        q_policy->FieldByName("product_id")->AsInteger = curr_value.ToIntDef(301);
                        q_temp = m_api->dbGetCursor(res, sql.sprintf("select * from osago_dict_product where product_id=%i", q_policy->FieldByName("product_id")->AsInteger));
                        q_policy->FieldByName("variant")->AsInteger = q_temp->FieldByName("variant")->AsInteger;
                        q_policy->FieldByName("product_name")->AsString = q_temp->FieldByName("product_name")->AsString;
                        m_api->dbCloseCursor(res, q_temp);
                        break;
                     case 73: q_policy->FieldByName("payments_count")->AsInteger = curr_value.ToIntDef(1); break;
                     // ������������
                     case 36:
                        i_val = curr_value.ToIntDef(1);
                        q_ins->FieldByName("status")->AsInteger = i_val;
                        q_bnf->FieldByName("status")->AsInteger = i_val;
                        break;
                     case 54:
                        q_ins->FieldByName("first_name")->AsString = curr_value;
                        q_bnf->FieldByName("first_name")->AsString = curr_value;
                        break;
                     case 55:
                        q_ins->FieldByName("second_name")->AsString = curr_value;
                        q_bnf->FieldByName("second_name")->AsString = curr_value;
                        break;
                     case 56:
                        q_ins->FieldByName("last_name")->AsString = curr_value;
                        q_bnf->FieldByName("last_name")->AsString = curr_value;
                        break;
                     case 57:
                        q_ins->FieldByName("phisical_birth_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0));
                        q_bnf->FieldByName("phisical_birth_date")->AsDateTime = q_ins->FieldByName("phisical_birth_date")->AsDateTime;
                        break;
                     case 60:
                        q_ins->FieldByName("document_type_id")->AsInteger = curr_value.ToIntDef(12);
                        q_bnf->FieldByName("document_type_id")->AsInteger = curr_value.ToIntDef(12);
                        break;
                     case 61:
                        q_ins->FieldByName("document_series")->AsString = curr_value;
                        q_bnf->FieldByName("document_series")->AsString = curr_value;
                        break;
                     case 62:
                        q_ins->FieldByName("document_number")->AsString = curr_value;
                        q_bnf->FieldByName("document_number")->AsString = curr_value;
                        break;
                  }
               }
               else if(curr_node->NodeName == c && AnsiString(curr_node->Attributes[attr_i]).ToIntDef(0) == 3){
                  for(int j = 0, cnt_j = curr_node->ChildNodes->Count; j < cnt_j; ++j){
                     curr_node2 = curr_node->ChildNodes->Get(j);
                     if(curr_node2->HasAttribute(attr_i)){
                        if(curr_node2->NodeName == m){
                           AnsiString curr_value = NodeAttributeToStr(curr_node2, attr_v, attr_v).Trim();
                           switch(AnsiString(curr_node2->Attributes[attr_i]).ToIntDef(0)){
                              case 5:   q_vehicle->FieldByName("rsa_code")->AsString = curr_value; break;
                              case 7:   q_vehicle->FieldByName("allowed_mass")->AsInteger = curr_value.ToIntDef(0); break;
                              case 8:   q_vehicle->FieldByName("usage_purpose")->AsInteger = curr_value.ToIntDef(1); break;
                              case 9:   q_vehicle->FieldByName("number_of_seats")->AsInteger = curr_value.ToIntDef(0); break;
                              case 51:  q_vehicle->FieldByName("construction_year")->AsInteger = curr_value.ToIntDef(0); break;
                              case 87:  q_vehicle->FieldByName("is_new_vehicle")->AsInteger = curr_value.ToIntDef(0); break;
                              case 100: q_vehicle->FieldByName("registration_issue_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                              case 28:  q_vehicle->FieldByName("vin")->AsString = curr_value.UpperCase(); break;
                              case 29:  q_vehicle->FieldByName("chassis_number")->AsString = curr_value.UpperCase(); break;
                              case 30:  q_vehicle->FieldByName("body_number")->AsString = curr_value.UpperCase(); break;
                              case 59:  q_vehicle->FieldByName("registration_mark")->AsString = Translit_Text(curr_value).UpperCase(); break;
                              case 48:  q_calc->FieldByName("ts_cost")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 89:  q_calc->FieldByName("str_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 78:  q_policy->FieldByName("multidrive")->AsInteger = curr_value.ToIntDef(1); break;
                              case 76:  q_policy->FieldByName("pay_id")->AsInteger = curr_value.ToIntDef(0); break;
                              case 77:  q_policy->FieldByName("risk_id")->AsInteger = curr_value.ToIntDef(0); break;
                              case 86:  q_policy->FieldByName("system_insur")->AsInteger = curr_value.ToIntDef(0) ? 3 : 1; break;
                              case 82:  q_policy->FieldByName("franshize_id")->AsInteger = curr_value.ToIntDef(1); break;
                              case 80:  q_policy->FieldByName("franshize_unit")->AsInteger = curr_value.ToIntDef(0); break;
                              case 81:  q_policy->FieldByName("franshize_size")->AsInteger = curr_value.ToIntDef(0); break;
                              case 90:  q_calc->FieldByName("dsago_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 91:  q_vehicle->FieldByName("trailer")->AsInteger = curr_value.ToIntDef(0); break;
                              case 92:  q_calc->FieldByName("ns_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 93:  q_calc->FieldByName("dms_summa")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 103: q_calc->FieldByName("limit_damage_sum")->AsFloat = StrToFloatStr(curr_value).ToDouble(); break;
                              case 104: q_calc->FieldByName("liab_type")->AsInteger = curr_value.ToIntDef(1); break;
                           }
                        }
                        else if(curr_node2->NodeName == c && AnsiString(curr_node2->Attributes[attr_i]).ToIntDef(0) == 1){
                           q_drv->Insert();
                           q_drv->FieldByName("calc_id")->AsInteger = calc_id;
                           q_drv->FieldByName("status")->AsInteger = 1;
                           q_drv->FieldByName("type_person")->AsInteger = drv_i;
                           q_drv->FieldByName("document_type_id")->AsInteger = 17;
                           q_drv->FieldByName("k1")->AsFloat = 0;
                           q_drv->FieldByName("k6")->AsFloat = 0;
                           q_drv->FieldByName("phisical_sex")->AsInteger = 1;

                           // ����� ��������� ��������� ����
                           for(int k = 0, cnt_k = curr_node2->ChildNodes->Count; k < cnt_k; ++k){
                              curr_node3 = curr_node2->ChildNodes->Get(k);
                              if(curr_node3->HasAttribute(attr_i)){
                                 if(curr_node3->NodeName == m){
                                    AnsiString curr_value = NodeAttributeToStr(curr_node3, attr_v, attr_v).Trim();
                                    switch(AnsiString(curr_node3->Attributes[attr_i]).ToIntDef(0)){
                                       case 14: q_drv->FieldByName("phisical_birth_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                                       case 15: q_drv->FieldByName("document_issue_date")->AsDateTime = TDateTime(curr_value.SubString(7, 4).ToIntDef(0), curr_value.SubString(4, 2).ToIntDef(0), curr_value.SubString(1, 2).ToIntDef(0)); break;
                                       case 19:
                                          if(curr_value.Length() == 4) curr_value = curr_value.Insert(space_str, 3);
                                          q_drv->FieldByName("document_series")->AsString = curr_value;
                                          break;
                                       case 20: q_drv->FieldByName("document_number")->AsString = curr_value; break;
                                       case 63: q_drv->FieldByName("first_name")->AsString = curr_value; break;
                                       case 64: q_drv->FieldByName("second_name")->AsString = curr_value; break;
                                       case 65: q_drv->FieldByName("last_name")->AsString = curr_value; break;
                                    }
                                 }
                              }
                           }
                           q_drv->FieldByName("age")->AsInteger = CalcYears(q_drv->FieldByName("phisical_birth_date")->AsDateTime, Date());
                           q_drv->FieldByName("experience")->AsInteger = CalcYears(q_drv->FieldByName("document_issue_date")->AsDateTime, Date());
                           q_drv->Post();  drv_i++;
                        }
                     }
                  }
               }
            }
         }

         if(q_ins->FieldByName("document_type_id")->AsInteger == 12 && q_ins->FieldByName("document_series")->AsString.Length() == 4){
            q_ins->FieldByName("document_series")->AsString = q_ins->FieldByName("document_series")->AsString.Insert(space_str, 3);
            q_bnf->FieldByName("document_series")->AsString = q_ins->FieldByName("document_series")->AsString;
         }

         q_calc->FieldByName("quotation_date")->AsDateTime = quotes_date;
         q_policy->FieldByName("srok_month")->AsInteger = MonthsCount(q_policy->FieldByName("srok_date_s")->AsDateTime, q_policy->FieldByName("srok_date_po")->AsDateTime);

         TADOQuery *q_v = m_api->dbGetCursor(res, "select * from gl_dict_carrier_models where code=" + QuotedStr(q_vehicle->FieldByName("rsa_code")->AsString));
         q_vehicle->FieldByName("vehicle_type_id")->Value = q_v->FieldByName("carrier_type_fk")->Value;
         q_vehicle->FieldByName("vehicle_brand_id")->Value = q_v->FieldByName("carrier_models_fkl")->Value;
         q_vehicle->FieldByName("vehicle_model_id")->Value = q_v->FieldByName("id")->Value;
         q_vehicle->FieldByName("vehicle_brand_name")->Value = q_v->FieldByName("brand_name")->Value;
         q_vehicle->FieldByName("vehicle_model_name")->Value = q_v->FieldByName("model_name")->Value;
         q_vehicle->FieldByName("vehicle_group")->Value = GetVehicleGroup(m_api, q_vehicle->FieldByName("vehicle_type_id")->AsInteger, q_vehicle->FieldByName("rsa_code")->AsString, q_vehicle->FieldByName("allowed_mass")->AsInteger, q_vehicle->FieldByName("number_of_seats")->AsInteger, quotes_date.DateString());
         m_api->dbCloseCursor(res, q_v);

         q_vehicle->FieldByName("is_registration_vehicle")->AsInteger = q_vehicle->FieldByName("registration_mark")->AsString.Length() > 7 ? 1 : -1;
         q_vehicle->FieldByName("vehicle_registration_type_id")->Value = 1;
         q_vehicle->FieldByName("vehicle_registration_type_id_2")->Value = 2;

         q_calc->FieldByName("ks")->Value = 1;
         q_calc->FieldByName("ka")->Value = 1;
         q_calc->FieldByName("base_kv")->Value = 0;
         q_calc->FieldByName("current_kv")->Value = 0;
         q_calc->FieldByName("no_calc")->Value = 1;
         q_policy->FieldByName("no_check_payment")->Value = 1;

         q_policy->FieldByName("project_id")->Value = 0;
         q_policy->FieldByName("programm_id")->Value = 0;
         q_policy->FieldByName("fio")->Value = Trim(q_ins->FieldByName("last_name")->AsString + space_str + q_ins->FieldByName("first_name")->AsString + space_str + q_ins->FieldByName("second_name")->AsString);
         q_policy->FieldByName("polis_date")->Value = quotes_date;
         q_policy->FieldByName("date_vznos1")->Value = quotes_date;
         q_policy->FieldByName("srok_date_s")->Value = quotes_date;
         q_policy->FieldByName("srok_date_po")->Value = CalcEndDateInsur(quotes_date, q_policy->FieldByName("srok_month")->AsInteger);
         q_policy->FieldByName("srok_time_s")->Value = "00:00";
         q_policy->FieldByName("srok_time_po")->Value = "23:59";
         q_policy->FieldByName("result_check_bso")->Value = 888;
         q_policy->FieldByName("result_check_bso_a7")->Value = 888;
         q_policy->FieldByName("is_personal_data")->Value = 1;

         q_calc->Post(); q_policy->Post(); q_vehicle->Post(); q_ins->Post(); q_bnf->Post();
      }

      m_api->dbCloseCursor(res, q_calc); m_api->dbCloseCursor(res, q_policy); m_api->dbCloseCursor(res, q_vehicle); m_api->dbCloseCursor(res, q_ins); m_api->dbCloseCursor(res, q_bnf); m_api->dbCloseCursor(res, q_drv);
      delete XMLDoc;
   }
   catch(Exception& ex){ ShowMessage("�������� XML Oracle Insbridge: " + ex.Message); }
   catch(...){ ShowMessage("�������� XML Oracle Insbridge: FATAL ERROR"); }

   m_api->Module_Refresh_Main_Grid(res);
}
//---------------------------------------------------------------------------
void LoadPerson(TADOQuery *q_p, _di_IXMLNode person, const int type_person, const int calc_id, const TDateTime& q_dt)
{
   bool is_perm = type_person > 3;
   AnsiString ph_mob(""), ph_home(""), ph_rab(""), email(""), exact_address("");
   TDateTime dt;
   int memo_id(0), sms(0), doc_type_id, i_val;
   TStringList *kladr_addr = new TStringList();

   MakeKladrAddrFromUXML(m_api, person, kladr_addr, memo_id, exact_address);
   GetPhones(person->ChildNodes->FindNode("contacts"), ph_mob, ph_home, ph_rab, email, sms);

   q_p->FieldByName("calc_id")->Value = calc_id;
   switch(NodeToStr(person->ChildNodes->FindNode("is_juridical")).ToIntDef(0)){
      case 0: q_p->FieldByName("status")->Value = 1; break;
      case 1: q_p->FieldByName("status")->Value = 2; break;
      case 2: q_p->FieldByName("status")->Value = type_person == 2 ? 5 : 1; break;
   }
   q_p->FieldByName("type_person")->Value = type_person;

   q_p->FieldByName("first_name")->Value = NodeToStr(person->ChildNodes->FindNode("first_name"));
   q_p->FieldByName("second_name")->Value = NodeToStr(person->ChildNodes->FindNode("second_name"));
   q_p->FieldByName("last_name")->Value = NodeToStr(person->ChildNodes->FindNode("last_name"));

   if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("physical_bitrh_date")), dt)){
      q_p->FieldByName("phisical_birth_date")->Value = dt;
      q_p->FieldByName("age")->Value = CalcYears(dt, q_dt);
   }
   q_p->FieldByName("phisical_sex")->Value = NodeToStr(person->ChildNodes->FindNode("physical_sex")).ToIntDef(-1) + 1;
   q_p->FieldByName("addr_mid")->Value = memo_id;

   switch(q_p->FieldByName("status")->AsInteger){
      case 1: doc_type_id = TryStrToInt(NodeToStr(person->ChildNodes->FindNode("document_type_id")), i_val) ? i_val : 12; break;
      case 2: doc_type_id = TryStrToInt(NodeToStr(person->ChildNodes->FindNode("document_type_id")), i_val) ? i_val : 25; break;
      case 5: doc_type_id = TryStrToInt(NodeToStr(person->ChildNodes->FindNode("document_type_id")), i_val) ? i_val : 12; break;
   }
   q_p->FieldByName("document_type_id")->Value = is_perm ? 17 : doc_type_id;
   q_p->FieldByName("document_series")->Value  = is_perm ? Translit_Text(NodeToStr(person->ChildNodes->FindNode("license_series"))) : NodeToStr(person->ChildNodes->FindNode("document_series"));
   if((q_p->FieldByName("document_type_id")->AsInteger == 12 || q_p->FieldByName("document_type_id")->AsInteger == 17) && q_p->FieldByName("document_series")->AsString.Length() == 4) q_p->FieldByName("document_series")->AsString = q_p->FieldByName("document_series")->AsString.Insert(space_str, 3);

   if(is_perm){
      q_p->FieldByName("document_number")->Value = NodeToStr(person->ChildNodes->FindNode("license_number")).SubString(1, 6);
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("driving_start_date")), dt)){
         q_p->FieldByName("document_issue_date")->Value = dt;
         q_p->FieldByName("experience")->Value = CalcYears(dt, q_dt);
      }
      
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("permitted_start_date")), dt)) q_p->FieldByName("permitted_added_date")->Value = dt;
      else if(TryStrToDateTime(NodeToStr(person->ParentNode->ParentNode->ChildNodes->FindNode("policy_start_date")), dt)) q_p->FieldByName("permitted_added_date")->Value = dt;
   }
   else{
      AnsiString doc_number = NodeToStr(person->ChildNodes->FindNode("document_number"));
      q_p->FieldByName("document_number")->Value = q_p->FieldByName("document_type_id")->AsInteger == 12 ? doc_number.SubString(1, 6) : doc_number; 
      if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("document_issue_date")), dt)) q_p->FieldByName("document_issue_date")->Value = dt;
      q_p->FieldByName("address")->Value = exact_address;
   }
   q_p->FieldByName("document_issue_org")->Value = NodeToStr(person->ChildNodes->FindNode("document_issue_organization"));

   if(!is_perm && m_api->dbGetIntFromQuery(res, "select count(*) from osago_dict_doc_type where id_doc_type=" + IntToStr(doc_type_id)) == 0){
      q_p->FieldByName("document_type_id")->Value = 12;
      q_p->FieldByName("document_series")->Value = variant_null;
      q_p->FieldByName("document_number")->Value = variant_null;
      q_p->FieldByName("document_issue_date")->Value = variant_null;
      q_p->FieldByName("document_issue_org")->Value = variant_null;
   }

   q_p->FieldByName("phone_mobil")->AsString = MobileToMask(ph_mob);
   q_p->FieldByName("phone_home")->AsString = ph_home;
   q_p->FieldByName("phone_work")->AsString = ph_rab;
   q_p->FieldByName("email")->AsString = email;

   q_p->FieldByName("inn")->Value = NodeToStr(person->ChildNodes->FindNode("inn"));
   q_p->FieldByName("ogrn")->Value = NodeToStr(person->ChildNodes->FindNode("ogrn"));

   q_p->FieldByName("kvs")->Value = -1;
   q_p->FieldByName("kbm")->Value = -1;
   q_p->FieldByName("license_type")->Value = 17;
   q_p->FieldByName("resident_yur")->Value = 1;

   delete kladr_addr;
}
//---------------------------------------------------------------------------
bool LoadDataFromCBD(const AnsiString& text_xml = empty_str)
{
   AnsiString xml = text_xml.IsEmpty() ? m_api->Get_Data_From_ARM_Form(res) : text_xml, str(""), st(""), sql(""), territory_kt("");
   TDateTime dt = Date(), dt1 = IncDay(IncYear(dt), -1), dt_po = dt1, quotes_date, dt_s, dt_e, dt_tto;
   UsagePeriod usage_period[3];
   double d_val;
   int i_val, srok_month(0);
   bool result(false);

   if(xml.IsEmpty()) return result;

   try{
      _di_IXMLDocument XMLDoc = NewXMLDocument();

      XMLDoc->Active = true;
      XMLDoc->LoadFromXML(xml);
      if(m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\test_load_cbd_osago.xml");

      _di_IXMLNode root_response = XMLDoc->DocumentElement, policy, person, vehicle, risks, casco_coeffs, paymentshedules, child_node, error_node, bank, blank, paymentdata, blank_pd;

      error_node = root_response->ChildNodes->FindNode("Error");
      if(error_node){
         delete XMLDoc;
         Application->MessageBox("������� �� ��� �������� � �������. ��������� ������� �������.", "�������� �������� �� ���!", MB_OK | MB_ICONEXCLAMATION);
         return false;
      }
      else{
         policy = root_response->ChildNodes->FindNode("policys")->ChildNodes->FindNode("policy");
         person = policy->ChildNodes->FindNode("persons");
         vehicle = policy->ChildNodes->FindNode("autovehicles")->ChildNodes->FindNode("autovehicle");
         risks = vehicle->ChildNodes->FindNode("riskobjects");
         casco_coeffs = vehicle->ChildNodes->FindNode("casco_coefficients");
         paymentshedules = policy->ChildNodes->FindNode("paymentshedules");
         blank = policy->ChildNodes->FindNode("blanks")->ChildNodes->FindNode("blank");
         paymentdata = policy->ChildNodes->FindNode("paymentdatas")->ChildNodes->FindNode("paymentdata");
         if(paymentdata) blank_pd = paymentdata->ChildNodes->FindNode("blank");

         AnsiString branch_code = NodeToStr(policy->ChildNodes->FindNode("branch_code"));
         if(branch_code == ea_rsa){
            delete XMLDoc;
            Application->MessageBox("�������� ���������, ����������� ����� ������� ������ ���, � ���2 �� ��������!", "�������� �������� �� ���!", MB_OK | MB_ICONEXCLAMATION);
            return false;
         }

         TStringList *errors_load = new TStringList();

         int id = m_api->dbInsert_Empty_Calc(res);

         di.user_info.Reset();
         di.user_info.user_id = m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0);
         LoadDataCurrentUser(m_api, &di);
         TADOQuery *q_insurer = m_api->dbGetCursor(res, "select * from osago_insurer where calc_id=" + IntToStr(id), 0, 0);
         q_insurer->Open();
         q_insurer->Insert();
         q_insurer->FieldByName("calc_id")->Value = id;
         q_insurer->FieldByName("saler_name_normal")->Value = di.user_info.name;
         q_insurer->FieldByName("saler_name")->Value = di.user_info.name_format;
         q_insurer->FieldByName("filial_short")->Value = di.user_info.filial;
         q_insurer->FieldByName("sign_position_normal")->Value = di.user_info.post_normal;
         q_insurer->FieldByName("sign_position")->Value = di.user_info.post;
         q_insurer->FieldByName("sign_document")->Value = di.user_info.accrediting;
         q_insurer->FieldByName("sign_document_number")->Value = di.user_info.accrediting_number;
         q_insurer->FieldByName("sign_document_date")->Value = di.user_info.accrediting_date;
         q_insurer->FieldByName("city")->Value = di.user_info.city;
         q_insurer->FieldByName("osp")->Value = di.user_info.osp;
         q_insurer->FieldByName("skk")->Value = di.user_info.skk;
         q_insurer->FieldByName("lnr")->Value = di.user_info.lnr;
         q_insurer->FieldByName("phone")->Value = di.user_info.phone;
         int old_sale_channel_id = NodeToStr(policy->ChildNodes->FindNode("sale_channel_type2008_name")).ToIntDef(0);
         q_insurer->FieldByName("sale_channel_id")->Value = (di.mop_sale_channel.count(di.user_info.sale_channel_id) && di.partner_sale_channel.count(old_sale_channel_id)) ? 139 : di.user_info.sale_channel_id;
         q_insurer->FieldByName("user_id_lnk")->Value = di.user_info.user_id;
         q_insurer->FieldByName("arm_agent_id")->Value = di.user_info.agent_id;
         q_insurer->FieldByName("office_id")->Value = di.user_info.office_id;
         q_insurer->FieldByName("office_type")->Value = di.user_info.office_type;
         q_insurer->FieldByName("prev_branch_code")->AsString = NodeToStr(policy->ChildNodes->FindNode("branch_code"));

         q_insurer->Post();
         m_api->dbCloseCursor(res, q_insurer);
         m_api->dbExecuteQuery(res, str.sprintf("update _mops_calcs_ set id_polzovatelya=%i where [id]=%i", di.user_info.user_id, id));

         ShortDateFormat = "yyyy.MM.dd";

         TADOQuery *q_calc    = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + IntToStr(id), 0, 0),
                   *q_policy  = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + IntToStr(id), 0, 0),
                   *q_vehicle = m_api->dbGetCursor(res, "select * from osago_vehicle where calc_id=" + IntToStr(id), 0, 0);

         q_calc->CursorLocation = clUseServer; q_policy->CursorLocation = clUseServer; q_vehicle->CursorLocation = clUseServer;
         q_calc->Open(); q_policy->Open(); q_vehicle->Open();
         q_calc->Insert(); q_policy->Insert(); q_vehicle->Insert();

         q_calc->FieldByName("calc_id")->Value    = id;
         q_calc->FieldByName("no_calc")->Value    = 0;
         q_policy->FieldByName("no_segmentation")->Value = 0;
         q_policy->FieldByName("calc_id")->Value  = id;
         q_vehicle->FieldByName("calc_id")->Value = id;

         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_date")), dt)){
            q_policy->FieldByName("polis_date")->Value = dt;
            q_calc->FieldByName("quotation_date")->Value = quotes_date = dt;
         }
         else errors_load->Add("policy->policy_date");

         q_vehicle->FieldByName("is_foreign_registration")->Value = NodeToStr(vehicle->ChildNodes->FindNode("foreign_registration")).ToIntDef(0);
         q_vehicle->FieldByName("is_transit")->Value = NodeToStr(vehicle->ChildNodes->FindNode("transit")).ToIntDef(0);
         if(q_vehicle->FieldByName("is_foreign_registration")->AsInteger) q_policy->FieldByName("territory_text")->Value = foreign_text;
         territory_kt = NodeToStr(vehicle->ChildNodes->FindNode("territory_kt"));
         if(!q_vehicle->FieldByName("is_foreign_registration")->AsInteger && !q_vehicle->FieldByName("is_transit")->AsInteger && !territory_kt.IsEmpty()){
            q_policy->FieldByName("kladr_region_id")->AsInteger = territory_kt.SubString(1, 2).ToIntDef(0);
            q_policy->FieldByName("kladr_area_id")->AsInteger = territory_kt.SubString(3, 3).ToIntDef(0);
            q_policy->FieldByName("kladr_city_id")->AsInteger = territory_kt.SubString(6, 3).ToIntDef(0);
            q_policy->FieldByName("kladr_place_id")->AsInteger = territory_kt.SubString(9, 3).ToIntDef(0);
            q_calc->FieldByName("kt_my")->Value = m_api->dbGetFloatFromQuery(res, "select kt1 from gl_dict_kt_kladr where kladr=" + QuotedStr(territory_kt));
         /*
         FormatFloat("00", kladr_region_id) +
         FormatFloat("000", kladr_area_id) +
         FormatFloat("000", kladr_city_id) +
         FormatFloat("000", kladr_place_id) + "00";
         */
         }
         else errors_load->Add("vehicle->territory_kt");

         if(person){
            TADOQuery *q_p = m_api->dbGetCursor(res, "select * from osago_persons where calc_id=" + IntToStr(id), 0, 1);
            int index_perm(0);
            for(int i = 0, cnt = person->ChildNodes->Count; i < cnt; ++i){
               child_node = person->ChildNodes->Get(i);
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_insured")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, 1, id, quotes_date);
                     q_policy->FieldByName("fio")->Value = Trim(q_p->FieldByName("last_name")->AsString + space_str + q_p->FieldByName("first_name")->AsString + space_str + q_p->FieldByName("second_name")->AsString);
                  }
               }
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_owner")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, 2, id, quotes_date);
                  }
               }
               if(TryStrToInt(NodeToStr(child_node->ChildNodes->FindNode("is_permitted")), i_val)){
                  if(i_val){
                     q_p->Insert();
                     LoadPerson(q_p, child_node, index_perm + 4, id, quotes_date);
                     ++index_perm;
                  }
               }
            }
            q_p->UpdateBatch();
            m_api->dbCloseCursor(res, q_p);
         }

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("vehicle_type_id")), i_val)) q_vehicle->FieldByName("vehicle_type_id")->Value = i_val;
         else errors_load->Add("vehicle->vehicle_type_id");
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("allowed_mass")), i_val)) q_vehicle->FieldByName("allowed_mass")->Value = i_val;
         else errors_load->Add("vehicle->allowed_mass");
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("number_of_seats")), i_val)) q_vehicle->FieldByName("number_of_seats")->Value = i_val;
         else errors_load->Add("vehicle->number_of_seats");
         q_vehicle->FieldByName("vehicle_brand_name_print")->Value = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_brand_name"));
         q_vehicle->FieldByName("vehicle_model_name_print")->Value = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_model_name"));
         q_vehicle->FieldByName("rsa_code")->Value = NodeToStr(vehicle->ChildNodes->FindNode("rsa_code"));
         if(!q_vehicle->FieldByName("rsa_code")->AsString.IsEmpty()){
            TADOQuery *q_v = m_api->dbGetCursor(res, "select * from gl_dict_carrier_models where code=" + QuotedStr(q_vehicle->FieldByName("rsa_code")->AsString));
            if(!q_v->IsEmpty()){
               q_vehicle->FieldByName("vehicle_brand_id")->Value = q_v->FieldByName("carrier_models_fkl")->Value;
               q_vehicle->FieldByName("vehicle_model_id")->Value = q_v->FieldByName("id")->Value;
               q_vehicle->FieldByName("vehicle_brand_name")->Value = q_v->FieldByName("brand_name")->Value;
               if(q_vehicle->FieldByName("vehicle_brand_name_print")->AsString == q_vehicle->FieldByName("vehicle_brand_name")->AsString) q_vehicle->FieldByName("vehicle_brand_name_print")->AsString = empty_str;
               q_vehicle->FieldByName("vehicle_model_name")->Value = q_v->FieldByName("model_name")->Value;
               if(q_vehicle->FieldByName("vehicle_model_name_print")->AsString == q_vehicle->FieldByName("vehicle_model_name")->AsString) q_vehicle->FieldByName("vehicle_model_name_print")->AsString = empty_str;
            }
            m_api->dbCloseCursor(res, q_v);
         }
         else errors_load->Add("vehicle->rsa_code");

         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("construction_date")), dt)) q_vehicle->FieldByName("construction_year")->Value = YearOf(dt);
         else errors_load->Add("vehicle->construction_date");

         q_vehicle->FieldByName("engine_power_type")->Value = 0;
         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("engine_power_hp")), i_val)) q_vehicle->FieldByName("engine_power")->Value = i_val;
         else errors_load->Add("vehicle->engine_power_hp");

         AnsiString rgpl = Translit_Text(NodeToStr(vehicle->ChildNodes->FindNode("registration_mark")), 1);
         if(rgpl.Length() > 7) q_vehicle->FieldByName("registration_mark")->Value = rgpl.UpperCase();

         AnsiString vin = Translit_Text(NodeToStr(vehicle->ChildNodes->FindNode("vin")));
         if(CheckVIN(vin)) q_vehicle->FieldByName("vin")->Value = vin;

         q_vehicle->FieldByName("chassis_number")->Value = NodeToStr(vehicle->ChildNodes->FindNode("chassis_number"));
         q_vehicle->FieldByName("body_number")->Value = NodeToStr(vehicle->ChildNodes->FindNode("body_number"));
         if(q_vehicle->FieldByName("vin")->AsString.IsEmpty() || q_vehicle->FieldByName("chassis_number")->AsString.IsEmpty() || q_vehicle->FieldByName("body_number")->AsString.IsEmpty()) errors_load->Add("vehicle: ����������������� ������");

         q_vehicle->FieldByName("vehicle_registration_type_id")->Value = NodeToStr(vehicle->ChildNodes->FindNode("vehicle_registration_type_id")).ToIntDef(1);
         q_vehicle->FieldByName("registration_series")->Value = NodeToStr(vehicle->ChildNodes->FindNode("registration_series"));
         q_vehicle->FieldByName("registration_number")->Value = NodeToStr(vehicle->ChildNodes->FindNode("registration_number"));
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("registration_issue_date")), dt)) q_vehicle->FieldByName("registration_issue_date")->Value = dt;
         q_vehicle->FieldByName("vehicle_registration_type_id_2")->Value = 2;

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("trailer")), i_val)) q_vehicle->FieldByName("trailer")->Value = i_val;

         if(TryStrToInt(NodeToStr(vehicle->ChildNodes->FindNode("usage_purpose")), i_val)) q_vehicle->FieldByName("usage_purpose")->Value = i_val;

         if(TryStrToInt(NodeToStr(policy->ChildNodes->FindNode("limited_drivers")), i_val)) q_policy->FieldByName("multidrive")->Value = i_val;
         else errors_load->Add("policy->limited_drivers");

         q_policy->FieldByName("contract_type")->Value = 0;

         if(TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_start_date")), dt_s) && TryStrToDateTime(NodeToStr(policy->ChildNodes->FindNode("policy_end_date")), dt_e)){
            q_policy->FieldByName("srok_date_s")->Value  = (int)dt_s;
            q_policy->FieldByName("srok_date_po")->Value = (int)dt_e;
            q_policy->FieldByName("srok_time_s")->Value  = dt_s.FormatString("hh:nn");
            q_policy->FieldByName("srok_time_po")->Value = "23:59";
            q_policy->FieldByName("up1_start_date")->Value = q_policy->FieldByName("srok_date_s")->Value;
            q_policy->FieldByName("up1_end_date")->Value   = q_policy->FieldByName("srok_date_po")->Value;
         }

         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("usage_start_date")), usage_period[0].start_date) && TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("usage_end_date")), usage_period[0].end_date)){
            q_policy->FieldByName("up1_start_date")->Value = (int)usage_period[0].start_date;
            q_policy->FieldByName("up1_end_date")->Value   = (int)usage_period[0].end_date;
         }
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("usage_start_date2")), usage_period[1].start_date) && TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("usage_end_date2")), usage_period[1].end_date)){
            q_policy->FieldByName("up2_start_date")->Value = (int)usage_period[1].start_date;
            q_policy->FieldByName("up2_end_date")->Value   = (int)usage_period[1].end_date;
         }
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("usage_start_date3")), usage_period[2].start_date) && TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("usage_end_date3")), usage_period[2].end_date)){
            q_policy->FieldByName("up3_start_date")->Value = (int)usage_period[2].start_date;
            q_policy->FieldByName("up3_end_date")->Value   = (int)usage_period[2].end_date;
         }


         if(q_vehicle->FieldByName("is_foreign_registration")->AsInteger){
            int dc = DaysCount(dt_s, dt_e);
            if(dc <= 15) q_policy->FieldByName("srok_month")->Value = 15;
            else{
               int mc = MonthsCount(dt_s, dt_e);
               if(!mc && dc) q_policy->FieldByName("srok_month")->Value = 1;
               else q_policy->FieldByName("srok_month")->Value = mc;
            }
         }
         else if(q_vehicle->FieldByName("is_transit")->AsInteger) q_policy->FieldByName("srok_month")->Value = 20;
         else{
            for(int i = 0; i < 3; ++i)
               if(usage_period[i].start_date.Val && usage_period[i].end_date.Val) srok_month += MonthsCount(usage_period[i].start_date, usage_period[i].end_date);

            if(!srok_month || srok_month > 9 || srok_month > 12) srok_month = 12;
            q_policy->FieldByName("srok_month")->Value = srok_month;
         }

         q_policy->FieldByName("polis_name")->Value = "����� ����� �����������";
         q_policy->FieldByName("polis_id")->Value = 1001;
         q_policy->FieldByName("polis_seria")->Value  = NodeToStr(policy->ChildNodes->FindNode("policy_series"));
         q_policy->FieldByName("polis_number")->Value = NodeToStr(policy->ChildNodes->FindNode("policy_number"));
         q_policy->FieldByName("prev_seria")->Value   = NodeToStr(policy->ChildNodes->FindNode("prev_contract_series"));
         q_policy->FieldByName("prev_number")->Value  = NodeToStr(policy->ChildNodes->FindNode("prev_contract_number"));
         q_policy->FieldByName("no_check_payment")->Value = 1;

         if(paymentdata){
            if(paymentdata->HasAttribute("payment_type_id") && TryStrToInt(AnsiString(paymentdata->Attributes["payment_type_id"]), i_val)) q_policy->FieldByName("payment_id")->Value = i_val;
            if(paymentdata->HasAttribute("payment_document_type_id") && TryStrToInt(AnsiString(paymentdata->Attributes["payment_document_type_id"]), i_val)) q_policy->FieldByName("payment_doc_id")->Value = i_val;
            if(i_val == 10){
               q_policy->FieldByName("pp_seria")->Value = AnsiString(blank_pd->Attributes["blank_series"]);
               q_policy->FieldByName("pp_number")->Value = AnsiString(blank_pd->Attributes["blank_number"]);
            }
            else q_policy->FieldByName("pp_number")->Value = AnsiString(paymentdata->Attributes["payment_document_number"]);
         }

         q_policy->FieldByName("product_id")->Value = NodeToStr(policy->ChildNodes->FindNode("product_class_id")).ToIntDef(2);
         q_policy->FieldByName("product_name")->Value = m_api->dbGetStringFromQuery(res, "select product_name from osago_dict_product where product_id=" + q_policy->FieldByName("product_id")->AsString);
         q_policy->FieldByName("is_violations")->Value = NodeToStr(vehicle->ChildNodes->FindNode("infraction_40fz")).ToIntDef(0);

         q_policy->FieldByName("tto_number")->Value = NodeToStr(vehicle->ChildNodes->FindNode("tto_number"));
         if(TryStrToDateTime(NodeToStr(vehicle->ChildNodes->FindNode("tto_next_date")), dt_tto)){
            q_policy->FieldByName("tto_month")->Value = MonthOf(dt_tto);
            q_policy->FieldByName("tto_year")->Value = YearOf(dt_tto);
         }

         for(int i = 0, cnt = risks->ChildNodes->Count; i < cnt; ++i){
            child_node = risks->ChildNodes->Get(i);
            st = m_api->dbGetStringFromQuery(res, "select risk_object_name from osago_dict_riskobjects where risk_object_type_id=" + QuotedStr(child_node->Attributes["risk_object_type_id"]));
            if(!st.IsEmpty()) q_calc->FieldByName("premiya_all")->AsFloat = q_calc->FieldByName("premiya_all")->AsFloat + StrToFloatStr(child_node->Attributes["premium"]).ToDouble();
         }


         //������������
         for(map<AnsiString,double>::const_iterator i=CoeffsDefMap.begin() ;i!=CoeffsDefMap.end();++i) q_calc->FieldByName(i->first)->AsFloat=i->second;
         map<int,AnsiString>::const_iterator it;
         child_node=casco_coeffs->ChildNodes->FindNode("casco_coefficient");
         while(child_node){
                it =  CoeffsMap.find(StrToIntDef(child_node->Attributes["coefficient_id"],-1));
                if(it!=CoeffsMap.end())q_calc->FieldByName(it->second)->AsFloat=StrToFloatStr(child_node->Attributes["value"]).ToDouble();
                child_node=child_node->NextSibling();
         }

         q_calc->Post(); q_policy->Post(); q_vehicle->Post();
         m_api->dbCloseCursor(res, q_calc);  m_api->dbCloseCursor(res, q_policy); m_api->dbCloseCursor(res, q_vehicle);

         m_api->Raschet_Set_Status_id(res, id, 11);
         result = true;
      }
      delete XMLDoc;
   }
   catch(Exception& ex) { result = false; }

   m_api->Module_Refresh_Main_Grid(res);

   ShortDateFormat = "dd.MM.yyyy";

   return result;
}
//------------------------------------------------------------------------------
void Modify()
{
   int prev_calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
   AnsiString prev_calc_id_str = IntToStr(prev_calc_id);

   TADOQuery *q_p = m_api->dbGetCursor(res, "select product_id,polis_seria,polis_number,multidrive,is_foreign_registration,srok_time_s from osago_policy p, osago_vehicle v where p.calc_id=" + prev_calc_id_str + " and v.calc_id=" + prev_calc_id_str);
   int product_id = q_p->FieldByName("product_id")->AsInteger;
   int multidrive = q_p->FieldByName("multidrive")->AsInteger;
   int is_foreign_registration = q_p->FieldByName("is_foreign_registration")->AsInteger;

   AnsiString pser = q_p->FieldByName("polis_seria")->AsString, pnum = q_p->FieldByName("polis_number")->AsString, srok_time_s = q_p->FieldByName("srok_time_s")->AsString;
   m_api->dbCloseCursor(res, q_p);

   bool is_allowed = GetIAPO2_ARM_READER(false, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"))->IsAllowedModify(pser, pnum);
   if(!is_allowed){
      ShowMessage("������, ��� ����� � ����� ������ � ����� ������� ��� ������������.");
      return;
   } 

   bool koeffsExists = m_api->dbGetIntFromQuery(res,"select count(*) from osago_calc where calc_id=" + prev_calc_id_str + " and bt>-1")==1; //�������, ��� ������������ ����, ���� ��������� ������� ������

   TList *reasonsId = new TList();

   if(!koeffsExists) reasonsId->Add((void*)(product_id == 2 ? 10 : 28)); //��� ���������� ������������� ��������� ������ ������ ���������

   TFModifyReasonSelect *mrs = new  TFModifyReasonSelect(0, m_api, product_id, is_foreign_registration, multidrive, reasonsId);
   int r = mrs->ShowModal();
   delete mrs;
   if(r != mrOk) { delete reasonsId; return; }

   m_api->Application_Press_Button(res, "����������� ������");
   m_api->Application_Press_Button(res, "�������� ������");
   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);

   TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + IntToStr(calc_id), 0, 1),
             *q_calc = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + IntToStr(calc_id), 0, 1);

   q_policy->Edit(); q_calc->Edit();

   pser = q_policy->FieldByName("polis_seria")->AsString; pnum = q_policy->FieldByName("polis_number")->AsString;

   if(reasonsId->IndexOf((int*)10) == -1 && reasonsId->IndexOf((int*)28) == -1){
      q_calc->FieldByName("bt")->Value = -1;
      q_calc->FieldByName("kt")->Value = -1;
      q_calc->FieldByName("kvs")->Value = -1;
      q_calc->FieldByName("ko")->Value = -1;
      q_calc->FieldByName("kbm")->Value = -1;
      q_calc->FieldByName("kbm_discount")->Value = 0;
      q_calc->FieldByName("km")->Value = -1;
      q_calc->FieldByName("kn")->Value = -1;
      q_calc->FieldByName("kc")->Value = -1;
      q_calc->FieldByName("kp")->Value = -1;
      q_calc->FieldByName("kpr")->Value = -1;
      q_calc->FieldByName("premiya_all")->Value = 0;
   }
   q_calc->FieldByName("prev_calc_id")->Value = prev_calc_id;

   q_policy->FieldByName("polis_seria")->Value = "���";
   q_policy->FieldByName("polis_number")->Value = empty_str;
   q_policy->FieldByName("srok_time_s")->Value = srok_time_s;
   q_policy->FieldByName("polis_date")->Value = (int)Date();
   q_policy->FieldByName("no_check_payment")->Value = 1;
   q_policy->FieldByName("payment_id")->Value = variant_null;
   q_policy->FieldByName("payment_method_id")->Value = variant_null;
   q_policy->FieldByName("payment_doc_id")->Value = variant_null;
   q_policy->FieldByName("pp_seria")->Value = empty_str;
   q_policy->FieldByName("pp_number")->Value = empty_str;
   q_policy->FieldByName("payment_authorization_code")->Value = variant_null;
   q_policy->FieldByName("prev_seria")->Value = pser;
   q_policy->FieldByName("prev_number")->Value = pnum;
   q_policy->FieldByName("result_check_bso")->Value = 888;
   q_policy->FieldByName("result_check_bso_a7")->Value = 888;
   q_policy->FieldByName("is_personal_data")->Value = 1;

   q_policy->Post(); q_calc->Post();
   m_api->dbCloseCursor(res, q_policy); m_api->dbCloseCursor(res, q_calc); 

   TADOQuery *qModifyReasons = m_api->dbGetCursor(res, "select * from osago_modify_reasons where calc_id=" + IntToStr(calc_id), 0, 1);
   for(int i = 0; i < reasonsId->Count; i++){
      qModifyReasons->Insert();
      qModifyReasons->FieldByName("calc_id")->AsInteger = calc_id;
      qModifyReasons->FieldByName("reason_id")->AsInteger = (int)reasonsId->Items[i];
   }
   qModifyReasons->Post();
   delete reasonsId;

   m_api-> Raschet_Set_Status_id(res, calc_id, 0);
   m_api->dbSet_Main_Grid_Current_CalcID(res, 0);
   m_api->Module_Refresh_Main_Grid(res);
   m_api->Application_Press_Button(res, "��������");
}
//------------------------------------------------------------------------------
void Prolongation()
{
   m_api->Application_Press_Button(res, "����������� ������");
   m_api->Application_Press_Button(res, "�������� ������");

   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);

   TDateTime dt = Date(), dt_start, dt_end, delta(0.0);
   TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + IntToStr(calc_id), 0, 1),
             *q_vehicle = m_api->dbGetCursor(res, "select * from osago_vehicle where calc_id=" + IntToStr(calc_id), 0, 1),
             *q_calc = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + IntToStr(calc_id), 0, 1),
             *q_perm = m_api->dbGetCursor(res, "select * from osago_persons where type_person > 3 and calc_id=" + IntToStr(calc_id), 0, 1);

   q_policy->Edit(); q_vehicle->Edit(); q_calc->Edit();

   AnsiString pser = q_policy->FieldByName("polis_seria")->AsString, pnum = q_policy->FieldByName("polis_number")->AsString;

   dt_start = (int)IncDay(q_policy->FieldByName("srok_date_po")->AsDateTime);

   if(int(dt_start) < int(dt)){
      delta = dt - dt_start;
      dt_start = dt;
   }
   dt_end = CalcEndDateInsur(dt_start, q_policy->FieldByName("srok_month")->AsInteger);

   q_calc->FieldByName("bt")->Value = -1;
   q_calc->FieldByName("kt")->Value = -1;
   q_calc->FieldByName("kvs")->Value = -1;
   q_calc->FieldByName("ko")->Value = -1;
   q_calc->FieldByName("kbm")->Value = -1;
   q_calc->FieldByName("kbm_discount")->Value = 0;
   q_calc->FieldByName("km")->Value = -1;
   q_calc->FieldByName("kn")->Value = -1;
   q_calc->FieldByName("kc")->Value = -1;
   q_calc->FieldByName("kp")->Value = -1;
   q_calc->FieldByName("kpr")->Value = -1;
   q_calc->FieldByName("premiya_all")->Value = 0;

   //q_policy->FieldByName("srok_month")->Value = 12;
   q_policy->FieldByName("srok_time_s")->Value = dt.FormatString("hh:nn");
   q_policy->FieldByName("srok_date_s")->Value = dt_start;
   q_policy->FieldByName("srok_time_po")->Value = "23:59";
   q_policy->FieldByName("srok_date_po")->Value = dt_end;

   if(q_vehicle->FieldByName("is_transit")->AsInteger && q_vehicle->FieldByName("is_foreign_registration")->AsInteger){
      q_policy->FieldByName("up1_start_date")->AsDateTime = dt_start;
      q_policy->FieldByName("up1_end_date")->AsDateTime = dt_end;
   }
   else{
      q_policy->FieldByName("up1_start_date")->AsDateTime = IncYear(q_policy->FieldByName("up1_start_date")->AsDateTime) + delta;
      q_policy->FieldByName("up1_end_date")->AsDateTime = IncYear(q_policy->FieldByName("up1_end_date")->AsDateTime) + delta;
      if(q_policy->FieldByName("up2_start_date")->AsDateTime.Val && q_policy->FieldByName("up2_end_date")->AsDateTime.Val){
         q_policy->FieldByName("up2_start_date")->AsDateTime = IncYear(q_policy->FieldByName("up1_start_date")->AsDateTime) + delta;
         q_policy->FieldByName("up2_end_date")->AsDateTime = IncYear(q_policy->FieldByName("up1_end_date")->AsDateTime) + delta;
      }
      if(q_policy->FieldByName("up3_start_date")->AsDateTime.Val && q_policy->FieldByName("up3_end_date")->AsDateTime.Val){
         q_policy->FieldByName("up3_start_date")->AsDateTime = IncYear(q_policy->FieldByName("up1_start_date")->AsDateTime) + delta;
         q_policy->FieldByName("up3_end_date")->AsDateTime = IncYear(q_policy->FieldByName("up1_end_date")->AsDateTime) + delta;
      }
   }

   q_policy->FieldByName("polis_seria")->Value = "���";
   q_policy->FieldByName("polis_number")->Value = empty_str;
   q_policy->FieldByName("polis_date")->Value = (int)dt;
   q_policy->FieldByName("no_check_payment")->Value = 1;
   q_policy->FieldByName("payment_id")->Value = variant_null;
   q_policy->FieldByName("payment_method_id")->Value = variant_null;
   q_policy->FieldByName("payment_doc_id")->Value = variant_null;
   q_policy->FieldByName("pp_seria")->Value = empty_str;
   q_policy->FieldByName("pp_number")->Value = empty_str;
   q_policy->FieldByName("payment_authorization_code")->Value = variant_null;
   q_policy->FieldByName("contract_type")->Value = 0;
   q_policy->FieldByName("prev_seria")->Value = pser;
   q_policy->FieldByName("prev_number")->Value = pnum;
   q_policy->FieldByName("result_check_bso")->Value = 888;
   q_policy->FieldByName("result_check_bso_a7")->Value = 888;
   q_policy->FieldByName("is_personal_data")->Value = 1;

   for(q_perm->First(); !q_perm->Eof; q_perm->Next()){
      q_perm->Edit();
      q_perm->FieldByName("age")->Value = CalcYears(q_perm->FieldByName("phisical_birth_date")->AsDateTime, dt);
      q_perm->FieldByName("experience")->Value = CalcYears(q_perm->FieldByName("document_issue_date")->AsDateTime, dt);
   }
   q_perm->UpdateBatch();

   q_policy->Post(); q_vehicle->Post(); q_calc->Post();
   m_api->dbCloseCursor(res, q_policy); m_api->dbCloseCursor(res, q_calc); m_api->dbCloseCursor(res, q_vehicle);
   m_api->dbCloseCursor(res, q_perm);

   m_api->Raschet_Set_Status_id(res, calc_id, 0);
   m_api->dbSet_Main_Grid_Current_CalcID(res, 0);
   m_api->Module_Refresh_Main_Grid(res);
   m_api->Application_Press_Button(res, "��������");
}
//---------------------------------------------------------------------------
void SendToCancelation()
{
   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
   AnsiString calc_id_str = IntToStr(calc_id);

   TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + calc_id_str);

   frmPeport->memErrors->Lines->Clear();
   frmPeport->Show();
   ThreadUFO *thr_send_cancel = new ThreadUFO(true, ufo_send_cancel, m_api->vrGetVariable(res, "_mops_global_ufo_osago_server_address_"), m_api, &di, q_policy, q_policy, q_policy);
   try{
      thr_send_cancel->Resume();
      frmPeport->memErrors->Lines->Add("�������� ��������� ������� �� ����� � ���");
      while(WaitForSingleObject((HANDLE)thr_send_cancel->Handle, 0) == WAIT_TIMEOUT) PrintStrInLog();
   }
   catch(Exception& ex){
      di.system_error = di.system_error + "\r\n" + ex.Message;
      frmPeport->memErrors->Lines->Add("Exception: " + di.system_error);
   }
   catch(...){
      di.system_error = di.system_error + "\r\n FATAL ERROR.";
      frmPeport->memErrors->Lines->Add("Exception: " + di.system_error);
   }

   delete thr_send_cancel;

   m_api->dbCloseCursor(res, q_policy);

   if(!di.system_error.IsEmpty() || di.validations_errors->Count){
      frmPeport->memErrors->Lines->Add("������� �� ����� �� ���������");
      if(!di.system_error.IsEmpty()) frmPeport->memErrors->Lines->Add("������ �������� ������ ��������� ������: " + di.system_error);
      if(di.validations_errors->Count) frmPeport->memErrors->Lines->Add("������ �������� ������ ������ ���������: " + di.validations_errors->Text);
   }
   else{
      frmPeport->memErrors->Lines->Add("������� �� ����� ���������");
      m_api->Raschet_Set_Status_id(res, calc_id, 16);
      m_api->Module_Refresh_Main_Grid(res);
   }
}
//---------------------------------------------------------------------------
void CheckStatusCancelation()
{
   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
   AnsiString calc_id_str = IntToStr(calc_id);

   TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + calc_id_str);

   frmPeport->memErrors->Lines->Clear();
   frmPeport->Show();
   ThreadUFO *thr_check_cancel = new ThreadUFO(true, ufo_check_cancel, m_api->vrGetVariable(res, "_mops_global_ufo_osago_server_address_"), m_api, &di, q_policy, q_policy, q_policy);
   try{
      thr_check_cancel->Resume();
      frmPeport->memErrors->Lines->Add("�������� ��������� ������ ������ � ���");
      while(WaitForSingleObject((HANDLE)thr_check_cancel->Handle, 0) == WAIT_TIMEOUT) PrintStrInLog();
   }
   catch(Exception& ex){
      di.system_error = di.system_error + "\r\n" + ex.Message;
      frmPeport->memErrors->Lines->Add("Exception: " + di.system_error);
   }
   catch(...){
      di.system_error = di.system_error + "\r\n FATAL ERROR.";
      frmPeport->memErrors->Lines->Add("Exception: " + di.system_error);
   }

   delete thr_check_cancel;

   m_api->dbCloseCursor(res, q_policy);

   if(!di.system_error.IsEmpty() || di.validations_errors->Count){
      frmPeport->memErrors->Lines->Add("�������� ������� �� ������");
      if(!di.system_error.IsEmpty()) frmPeport->memErrors->Lines->Add("������ �������� ������ ��������� ������: " + di.system_error);
      if(di.validations_errors->Count) frmPeport->memErrors->Lines->Add("������ �������� ������ ������ ���������: " + di.validations_errors->Text);
   }
   else{
      switch(di.status_cancel){
         case 1:
            frmPeport->memErrors->Lines->Add("������� ������� �� ���");
            m_api->Raschet_Set_Status_id(res, calc_id, 17);
            break;
         case 0:
            frmPeport->memErrors->Lines->Add("������� � ������� �� ���������");
            break;
         case -1:
            frmPeport->memErrors->Lines->Add("��� ��������� �������� � ��� ��������� ������");
            break;
      }
      m_api->Module_Refresh_Main_Grid(res);
   }
}
//---------------------------------------------------------------------------
void Get_Main_Menu(TMainMenu** M_Menu)
{
   if(*M_Menu) delete *M_Menu;
   *M_Menu = 0;
   *M_Menu = new TMainMenu(0);

   TMenuItem *mp = new TMenuItem(*M_Menu);
   mp->Caption = "�������";
   mp->Name = "dog";
   mp->Tag  = 100;
   (*M_Menu)->Items->Add(mp);

   TMenuItem *md = new TMenuItem(*M_Menu);
   md->Caption = "��������";
   md->Name = "d1";
   (*M_Menu)->Items->Add(md);

   TMenuItem *mi = new TMenuItem(*M_Menu);
   mi->Caption = "����������";
   mi->Name = "inf";
   (*M_Menu)->Items->Add(mi);

/**/

   TMenuItem *md_11 = new TMenuItem(mp);
   md_11->Caption = "��������";
   md_11->Name    = "d1_11";
   md_11->Tag     = 20;
   mp->Add(md_11);
   md_11->Enabled = !di.is_ander_login;

   md_22 = new TMenuItem(mp);
   md_22->Caption = "��������";
   md_22->Name    = "d1_22";
   md_22->Tag     = 21;
   mp->Add(md_22);

   TMenuItem *md_33 = new TMenuItem(mp);
   md_33->Caption = "�������";
   md_33->Name    = "d1_33";
   md_33->Tag     = 22;
   mp->Add(md_33);

   TMenuItem *lne1 = new TMenuItem(mp);
   lne1->Caption = "-";
   lne1->Name    = "lne1";
   mp->Add(lne1);

   TMenuItem *md_1_2 = new TMenuItem(mp);
   md_1_2->Caption = "��������� �� ������� �������";
   md_1_2->Name    = "d1_1_2";
   md_1_2->Tag     = 11;
   mp->Add(md_1_2);

   mp_1 = new TMenuItem(mp);
   mp_1->Caption = "��������������";
   mp_1->Name    = "prolong";
   mp_1->Tag     = 12;
   mp->Add(mp_1);

   mp_2 = new TMenuItem(mp);
   mp_2->Caption = "������������";
   mp_2->Name = "modify";
   mp_2->Tag = 13;
   //mp_2->Visible = false;
   mp->Add(mp_2);

   TMenuItem *lne2 = new TMenuItem(mp);
   lne2->Caption = "-";
   lne2->Name    = "lne2";
   mp->Add(lne2);

   mo_1 = new TMenuItem(mp);
   mo_1->Caption = "����� �������� �� ������� �������";
   mo_1->Name    = "otz1";
   mo_1->Tag     = 30;
   mo_1->Visible = false;
   mp->Add(mo_1);

   mo_2 = new TMenuItem(mp);
   mo_2->Caption = "��������� ������ ������";
   mo_2->Name    = "otz2";
   mo_2->Tag     = 31;
   mo_2->Visible = false;
   mp->Add(mo_2);

/**/

   TMenuItem *md_1 = new TMenuItem(md);
   md_1->Caption = "��������� XML";
   md_1->Name    = "d1_1";
   md_1->Tag     = 1;
   md->Add(md_1);

   TMenuItem *md_2 = new TMenuItem(md);
   md_2->Caption = "��������� (������ ���2)";
   md_2->Name    = "d1_2";
   md->Add(md_2);

   TMenuItem *md_2_1_1 = new TMenuItem(md_2);
   md_2_1_1->Caption = "���";
   md_2_1_1->Name    = "d1_2_1_1";
   md_2_1_1->Tag     = 2;
   md_2->Add(md_2_1_1);

   TMenuItem *md_2_1_2 = new TMenuItem(md_2);
   md_2_1_2->Caption = "����� � ����������";
   md_2_1_2->Name    = "d1_2_1_2";
   md_2_1_2->Tag     = 3;
   md_2->Add(md_2_1_2);

   TMenuItem *md_2_1_3 = new TMenuItem(md_2);
   md_2_1_3->Caption = "��������� � �������";
   md_2_1_3->Name    = "d1_2_1_3";
   md_2_1_3->Tag     = 4;
   md_2->Add(md_2_1_3);

/**/

   TMenuItem *mi_1 = new TMenuItem(mi);
   mi_1->Caption = "���� ���������� ������ � �����";
   mi_1->Name    = "miii_1";
   mi_1->Tag     = 25;
   mi->Add(mi_1);
}
//---------------------------------------------------------------------------
void SetDisableEnable(int md22, int m0_1, int m0_2, int m_p_1)
{
   if(md_22) md_22->Enabled = md22;  // ��������
   if(mo_1)  mo_1->Enabled  = m0_1;  // ��������� �� �����
   if(mo_2)  mo_2->Enabled  = m0_2;  // ������ ������
   if(mp_1)  mp_1->Enabled  = m_p_1; // ��������������
   if(mp_2)  mp_2->Enabled  = m_p_1; // �������������� ���������� �����������
}
//---------------------------------------------------------------------------
void DisableMenuItems()
{
   int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
   switch(m_api->Raschet_Get_Status_id(res, calc_id)){
      case 0: case 1: case 2: case 13: case 14: SetDisableEnable(1, 0, 0, 0); break;
      case 5: case 10: SetDisableEnable(1, 1, 0, 0); break;
      case 11: SetDisableEnable(1, 0, 0, 1); break;
      case 16: SetDisableEnable(0, 0, 1, 0); break;
      case 17: SetDisableEnable(0, 0, 0, 0); break;
   }
}
//---------------------------------------------------------------------------
void OnMenuClick(TObject *Sender)
{
   TMenuItem *mi = dynamic_cast<TMenuItem*>(Sender);
   TOpenDialog *od;

   switch(mi->Tag){
      case 1:
         od = new TOpenDialog(0);
         if(od->Execute()) m_api->Analyse_and_Load_XML_f(res, od->FileName);
         delete od;
         break;
      case 2:
         XMLSave(1);
         break;
      case 3:
         XMLSave(2);
         break;
      case 4:
         XMLSave(3);
         break;
      case 11:
         LoadDataFromCBD();
         break;
      case 12:
         Prolongation();
         break;
      case 13:
         Modify();
          break;
      case 20:
         m_api->Application_Press_Button(res, "��������");
         break;
      case 21:
         m_api->Application_Press_Button(res, "��������");
         break;
      case 22:
         m_api->Application_Press_Button(res, "�������");
         break;
      case 25:
         if(FileExists(File_Osago_Instruction)) ShellExecute(GetDesktopWindow(), "", File_Osago_Instruction.c_str(), "", "", SW_RESTORE);
         else ShowMessage("���� � ����������� �� ����� ���������� ������ ��������� � ������������ �� ������.");
         break;
      case 30:
         SendToCancelation();
         break;
      case 31:
         CheckStatusCancelation();
         break;
      case 100: DisableMenuItems();
   }
}
//---------------------------------------------------------------------------
void NewNode(_di_IXMLNode child_node, const AnsiString& attr, const AnsiString& text)
{
   child_node->Attributes["code"] = attr == -1 ? empty_str : attr;
   child_node->Text = text;
}
//---------------------------------------------------------------------------
AnsiString GetCode(TADOQuery *q)
{
   int code(0);

   if(q->FieldByName("status")->AsInteger == 2) code = 2;
   switch(q->FieldByName("type_person")->AsInteger){
      case 1:  code += 4;  break;
      case 2:  code += 8; break;
      //case 3:  code += 8;  break;
      default: code += 32; break;
   }

   return IntToStr(code);
}
//---------------------------------------------------------------------------
bool Copy(AnsiString &XMLData)
{
   int i_val;
   TDateTime dt;
   try{
      AnsiString calc_id_str = IntToStr(m_api->dbGet_Main_Grid_Current_CalcID(res));

      TStringList* sl = new TStringList();

      _di_IXMLDocument XMLDoc = NewXMLDocument();

      XMLDoc->Active = true;
      XMLDoc->LoadFromXML(XMLData);

      _di_IXMLNode Root, ts, persons, child_node, temp_node, contacts;

      Root    = XMLDoc->DocumentElement;
      ts      = Root->ChildNodes->FindNode("ts");
      persons = Root->ChildNodes->FindNode("persons");

      TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + calc_id_str),
                *q_vehicle = m_api->dbGetCursor(res, "select t1.*,t2.full_name,t3.usage_purpose_name from ((osago_vehicle t1 left join osago_dict_veh_type t2 on t1.vehicle_type_id=CInt(t2.code)) left join osago_dict_usagepurpose t3 on t1.usage_purpose=t3.usage_purpose_id)  where t1.calc_id=" + calc_id_str),
                *q_persons = m_api->dbGetCursor(res, "select * from osago_persons where calc_id=" + calc_id_str),
                *q_insurer = m_api->dbGetCursor(res, "select t1.*,t2.name_kanal from osago_insurer t1 left join gl_dict_kanal_prodag t2 on t1.sale_channel_id=t2.id where t1.calc_id=" + calc_id_str);

      FillNode(Root->ChildNodes->FindNode("region"), q_insurer->FieldByName("skk")->AsString.SubString(2, 2), empty_str);
      FillNode(Root->ChildNodes->FindNode("sale_channel"), q_insurer->FieldByName("sale_channel_id")->AsString, q_insurer->FieldByName("name_kanal")->AsString);

      // ����� ������������� ��������
      AnsiString rsa_code = q_vehicle->FieldByName("rsa_code")->AsString;
      FillNode(ts->ChildNodes->FindNode("type_ts"), q_vehicle->FieldByName("vehicle_type_id")->AsString, q_vehicle->FieldByName("full_name")->AsString);
      FillNode(ts->ChildNodes->FindNode("marka"), rsa_code.SubString(1, 3) + "000000", q_vehicle->FieldByName("vehicle_brand_name")->AsString);
      FillNode(ts->ChildNodes->FindNode("model"), rsa_code, q_vehicle->FieldByName("vehicle_model_name")->AsString);
      ts->ChildNodes->FindNode("VIN")->Text = q_vehicle->FieldByName("vin")->AsString;
      ts->ChildNodes->FindNode("chassis")->Text = q_vehicle->FieldByName("chassis_number")->AsString;
      ts->ChildNodes->FindNode("body")->Text = q_vehicle->FieldByName("body_number")->AsString;
      ts->ChildNodes->FindNode("engine_number")->Text = empty_str;
      ts->ChildNodes->FindNode("year")->Text = q_vehicle->FieldByName("construction_year")->AsString;
      ts->ChildNodes->FindNode("power")->Text = q_vehicle->FieldByName("engine_power")->AsString;
      ts->ChildNodes->FindNode("state_reg_sign")->Text = q_vehicle->FieldByName("registration_mark")->AsString;
      ts->ChildNodes->FindNode("max_mass")->Text = q_vehicle->FieldByName("allowed_mass")->AsString;
      ts->ChildNodes->FindNode("passengers_quantity")->Text = q_vehicle->FieldByName("number_of_seats")->AsString;
		FillNode(ts->ChildNodes->FindNode("use_purpose"), q_vehicle->FieldByName("usage_purpose")->AsString, q_vehicle->FieldByName("usage_purpose_name")->AsString);

      dt = q_vehicle->FieldByName("registration_issue_date")->AsDateTime;
      i_val = q_vehicle->FieldByName("vehicle_registration_type_id")->AsInteger;
      temp_node = ts->ChildNodes->FindNode("ts_document");
      temp_node->Attributes["code"]       = IntToStr(i_val);
      temp_node->Attributes["series"]     = q_vehicle->FieldByName("registration_series")->AsString;
      temp_node->Attributes["number"]     = q_vehicle->FieldByName("registration_number")->AsString;
      temp_node->Attributes["issue_date"] = dt.Val ? dt.DateString() : empty_str;
      temp_node->Text = m_api->dbGetStringFromQuery(res, "select [vehicle_registr_type_name] from osago_dict_veh_doc_type where vehicle_registr_type_id=" + IntToStr(i_val));

      //����� ����������, ���������� � �������� �����������
      persons = Root->ChildNodes->FindNode("persons");
      for(q_persons->First(); !q_persons->Eof; q_persons->Next()){
         child_node = persons->AddChild("person");
         child_node->Attributes["code"] = GetCode(q_persons);
         child_node->AddChild("first_name")->Text          = q_persons->FieldByName("first_name")->AsString;
         child_node->AddChild("second_name")->Text         = q_persons->FieldByName("second_name")->AsString;
         child_node->AddChild("last_name")->Text           = q_persons->FieldByName("last_name")->AsString;
         child_node->AddChild("inn")->Text                 = q_persons->FieldByName("inn")->AsString;
         child_node->AddChild("opf_id")->Text              = q_persons->FieldByName("opf_id")->AsString;
         child_node->AddChild("ogrn")->Text                = q_persons->FieldByName("ogrn")->AsString;
         dt = q_persons->FieldByName("phisical_birth_date")->AsDateTime;
         child_node->AddChild("physical_bitrh_date")->Text = dt.Val ? dt.DateString() : empty_str;
         child_node->AddChild("physical_sex")->Text        = IntToStr(q_persons->FieldByName("phisical_sex")->AsInteger - 1);
         child_node->AddChild("citizenship")->Text         = q_persons->FieldByName("citizenship")->AsString;
         i_val = q_persons->FieldByName("addr_mid")->AsInteger;
         temp_node = child_node->AddChild("addresses");
         AnsiString memo_text("��� �����=\r\n������ ������\r\n�����������=\r\n������=\r\n�����=\r\n�����=\r\n�������=\r\n�����=\r\n���=\r\n����� �������=\r\n��������=\r\n������=");
         if(i_val) m_api->dbReadWriteInternalMemo(res, memo_text, i_val, true, "osago_memo");
         sl->Text = memo_text;
         temp_node->AddChild("code_kladr")->Text   = sl->Values["��� �����"];
         temp_node->AddChild("filter_kladr")->Text = sl->Values["������ ������"];
         temp_node->AddChild("country")->Text      = sl->Values["�����������"];
         temp_node->AddChild("region")->Text       = sl->Values["������"];
         temp_node->AddChild("place")->Text        = sl->Values["�����"];
         temp_node->AddChild("area")->Text         = sl->Values["�����"];
         temp_node->AddChild("zip")->Text          = sl->Values["������"];
         temp_node->AddChild("street")->Text       = sl->Values["�����"];
         temp_node->AddChild("house")->Text        = sl->Values["���"];
         temp_node->AddChild("building")->Text     = sl->Values["����� �������"];
         temp_node->AddChild("flat")->Text         = sl->Values["��������"];
         temp_node->AddChild("exact_address")->Text= q_persons->FieldByName("address")->AsString;
         temp_node = child_node->AddChild("documents");
         NewNode(temp_node->AddChild("document"), q_persons->FieldByName("document_type_id")->AsString, m_api->dbGetStringFromQuery(res, "select doc_type from osago_dict_doc_type where id_doc_type=" + q_persons->FieldByName("document_type_id")->AsString));
         temp_node->AddChild("document_series")->Text             = q_persons->FieldByName("document_series")->AsString;
         temp_node->AddChild("document_number")->Text             = q_persons->FieldByName("document_number")->AsString;
         dt = q_persons->FieldByName("document_issue_date")->AsDateTime;
         temp_node->AddChild("document_issue_date")->Text         = dt.Val ? dt.DateString() : empty_str;
         temp_node->AddChild("document_issue_organization")->Text = q_persons->FieldByName("document_issue_org")->AsString;
         temp_node = child_node->AddChild("contacts")->AddChild("contact");
         temp_node->Attributes["contact_type_id"] = AnsiString(3);
         temp_node->Attributes["contact_data"] = q_persons->FieldByName("phone_mobil")->AsString;
         temp_node->Attributes["spam"] = null_str;
      }

      m_api->dbCloseCursor(res, q_policy);
      m_api->dbCloseCursor(res, q_vehicle);
      m_api->dbCloseCursor(res, q_persons);
      m_api->dbCloseCursor(res, q_insurer);

      XMLDoc->SaveToXML(XMLData);
      if(m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\osago20_copy.xml");
      delete XMLDoc; delete sl;
   }
   catch(...){ return false; }

   return true;
}
//---------------------------------------------------------------------------
void MakeKladrAddr(_di_IXMLNode child_node, TStringList* addr, int& memo_id)
{
   addr->Clear();
   memo_id = 0;
   AnsiString code_kladr = Trim(child_node->ChildNodes->FindNode("code_kladr")->Text);

   addr->Values["��� �����"]          = code_kladr;
   addr->Values["��������"]           = code_kladr.IsEmpty() ? "���" :"��";
   addr->Values["������������ �����"] = code_kladr.IsEmpty() ? "���" : "��";
   addr->Values["������"]             = "��";
   addr->Values["������ ������"]      = child_node->ChildNodes->FindNode("filter_kladr")->Text;
   addr->Values["�����������"]        = child_node->ChildNodes->FindNode("country")->Text;
   addr->Values["������"]             = child_node->ChildNodes->FindNode("region")->Text;
   addr->Values["�����"]              = child_node->ChildNodes->FindNode("area")->Text;
   addr->Values["�����"]              = child_node->ChildNodes->FindNode("place")->Text;
   addr->Values["������"]             = child_node->ChildNodes->FindNode("zip")->Text;
   addr->Values["�����"]              = child_node->ChildNodes->FindNode("street")->Text;
   addr->Values["���"]                = child_node->ChildNodes->FindNode("house")->Text;
   addr->Values["������/��������"]    = "�";
   addr->Values["����� �������"]      = child_node->ChildNodes->FindNode("building")->Text;
   addr->Values["��������"]           = child_node->ChildNodes->FindNode("flat")->Text;

   AnsiString memo_text = addr->Text;
   m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "osago_memo");
}
//---------------------------------------------------------------------------
void LoadPersonProdFormat(TADOQuery *q_p, _di_IXMLNode person, const int type_person, const int status, const int calc_id, const TDateTime& q_dt)
{
   bool is_perm = type_person > 3;
   AnsiString ph_mob(""), ph_home(""), ph_rab(""), email(""), exact_address("");
   TDateTime dt;
   int memo_id(0), sms(0), doc_type_id, i_val;
   TStringList *kladr_addr = new TStringList();

   MakeKladrAddr(person->ChildNodes->FindNode("addresses"), kladr_addr, memo_id);
   GetPhones(person->ChildNodes->FindNode("contacts"), ph_mob, ph_home, ph_rab, email, sms);

   q_p->FieldByName("calc_id")->Value = calc_id;
   q_p->FieldByName("status")->Value = status;
   q_p->FieldByName("type_person")->Value = type_person;

   q_p->FieldByName("first_name")->Value = NodeToStr(person->ChildNodes->FindNode("first_name"));
   q_p->FieldByName("second_name")->Value = NodeToStr(person->ChildNodes->FindNode("second_name"));
   q_p->FieldByName("last_name")->Value = NodeToStr(person->ChildNodes->FindNode("last_name"));

   if(TryStrToDateTime(NodeToStr(person->ChildNodes->FindNode("physical_bitrh_date")), dt)){
      q_p->FieldByName("phisical_birth_date")->Value = dt;
      q_p->FieldByName("age")->Value = CalcYears(dt, q_dt);
   }

   q_p->FieldByName("phisical_sex")->Value = NodeToStr(person->ChildNodes->FindNode("physical_sex")).ToIntDef(-1) + 1;

   q_p->FieldByName("addr_mid")->Value = memo_id;
   q_p->FieldByName("address")->Value = NodeToStr(person->ChildNodes->FindNode("addresses")->ChildNodes->FindNode("exact_address"));

   q_p->FieldByName("phone_mobil")->Value = ph_mob;
   q_p->FieldByName("phone_home")->Value = ph_home;
   q_p->FieldByName("phone_work")->Value = ph_rab;

   q_p->FieldByName("inn")->Value = NodeToStr(person->ChildNodes->FindNode("inn"));
   q_p->FieldByName("ogrn")->Value = NodeToStr(person->ChildNodes->FindNode("ogrn"));

   q_p->FieldByName("kvs")->Value = -1;
   q_p->FieldByName("kbm")->Value = -1;
   q_p->FieldByName("license_type")->Value = 17;
   q_p->FieldByName("resident_yur")->Value = 1;


   _di_IXMLNode document = person->ChildNodes->FindNode("documents");
   AnsiString code = document->ChildNodes->FindNode("document")->Attributes["code"];

   switch(q_p->FieldByName("status")->AsInteger){
      case 1: doc_type_id = TryStrToInt(code, i_val) ? i_val : 12; break;
      case 2: doc_type_id = TryStrToInt(code, i_val) ? i_val : 25; break;
   }
   q_p->FieldByName("document_type_id")->Value = is_perm ? 17 : doc_type_id;
   q_p->FieldByName("document_series")->Value  = Translit_Text(NodeToStr(document->ChildNodes->FindNode("document_series")));
   if((q_p->FieldByName("document_type_id")->AsInteger == 12 || q_p->FieldByName("document_type_id")->AsInteger == 17) && q_p->FieldByName("document_series")->AsString.Length() == 4) q_p->FieldByName("document_series")->AsString = q_p->FieldByName("document_series")->AsString.Insert(space_str, 3);
   q_p->FieldByName("document_number")->Value = NodeToStr(document->ChildNodes->FindNode("document_number"));
   if(TryStrToDateTime(NodeToStr(document->ChildNodes->FindNode("document_issue_date")), dt)){
      q_p->FieldByName("document_issue_date")->Value = dt;
      q_p->FieldByName("experience")->Value = CalcYears(dt, q_dt);
   }
   q_p->FieldByName("document_issue_org")->Value = NodeToStr(document->ChildNodes->FindNode("document_issue_organization"));

   delete kladr_addr;
}
//---------------------------------------------------------------------------
bool Paste(const AnsiString& XMLData)
{
   TDateTime dt, dt_s = Date(), dt_po = IncDay(IncYear(dt_s), -1);
   double d_val;
   int i_val, status(1), type(4), curr_year = YearOf(dt_s), kladr_region_id = m_api->vrGetVariable(res, "Osago_Kladr_Region").Trim().ToIntDef(0);

   if(XMLData.IsEmpty()) return false;

   AnsiString str("");

   di.user_info.Reset();
   long id = m_api->dbInsert_Empty_Calc(res);
   di.user_info.user_id = m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_").ToIntDef(0);

   m_api->dbExecuteQuery(res, str.sprintf("insert into osago_calc (calc_id,no_calc,calc_type) values (%i,1,0)", id));
   m_api->dbExecuteQuery(res, str.sprintf("update _mops_calcs_ set id_polzovatelya=%i where [id]=%i", di.user_info.user_id, id));
   TADOQuery *q_insurer = m_api->dbGetCursor(res, str.sprintf("select * from osago_insurer where calc_id=%i", id), 0, 1),
             *q_policy = m_api->dbGetCursor(res, str.sprintf("select * from osago_policy where [calc_id]=%i", id), 0, 1),
             *q_vehicle = m_api->dbGetCursor(res, str.sprintf("select * from osago_vehicle where [calc_id]=%i", id), 0, 1),
             *q_persons = m_api->dbGetCursor(res, str.sprintf("select * from osago_persons where [calc_id]=%i", id), 0, 1);

   LoadDataCurrentUser(m_api, &di);

   q_insurer->Insert(); q_policy->Insert(); q_vehicle->Insert();

   q_insurer->FieldByName("calc_id")->Value = id;
   q_policy->FieldByName("calc_id")->Value = id;
   q_vehicle->FieldByName("calc_id")->Value = id;

   q_insurer->FieldByName("saler_name_normal")->Value = di.user_info.name;
   q_insurer->FieldByName("saler_name")->Value = di.user_info.name_format;
   q_insurer->FieldByName("filial_short")->Value = di.user_info.filial;
   q_insurer->FieldByName("sign_position_normal")->Value = di.user_info.post_normal;
   q_insurer->FieldByName("sign_position")->Value = di.user_info.post;
   q_insurer->FieldByName("sign_document")->Value = di.user_info.accrediting;
   q_insurer->FieldByName("sign_document_number")->Value = di.user_info.accrediting_number;
   q_insurer->FieldByName("sign_document_date")->Value = di.user_info.accrediting_date;
   q_insurer->FieldByName("city")->Value = di.user_info.city;
   q_insurer->FieldByName("osp")->Value = di.user_info.osp;
   q_insurer->FieldByName("skk")->Value = di.user_info.skk;
   q_insurer->FieldByName("lnr")->Value = di.user_info.lnr;
   q_insurer->FieldByName("phone")->Value = di.user_info.phone;
   q_insurer->FieldByName("sale_channel_id")->Value = di.user_info.sale_channel_id;
   q_insurer->FieldByName("user_id_lnk")->Value = di.user_info.user_id;
   q_insurer->FieldByName("arm_agent_id")->Value = di.user_info.agent_id;
   q_insurer->FieldByName("office_id")->Value = di.user_info.office_id;
   q_insurer->FieldByName("office_type")->Value = di.user_info.office_type;

   q_policy->FieldByName("product_id")->Value = 2;
   q_policy->FieldByName("product_name")->Value = "����� ���������� ���";
   q_policy->FieldByName("srok_month")->Value = 12;
   q_policy->FieldByName("multidrive")->Value = 1;
   q_policy->FieldByName("polis_date")->Value = dt_s;
   q_policy->FieldByName("srok_time_s")->Value = "00:00";
   q_policy->FieldByName("srok_date_s")->Value = dt_s;
   q_policy->FieldByName("srok_time_po")->Value = "23:59";
   q_policy->FieldByName("srok_date_po")->Value = dt_po;
   q_policy->FieldByName("up1_start_date")->Value = dt_s;
   q_policy->FieldByName("up1_end_date")->Value = dt_po;
   q_policy->FieldByName("kladr_region_id")->Value = kladr_region_id;
   q_policy->FieldByName("result_check_bso")->Value = 888;
   q_policy->FieldByName("result_check_bso_a7")->Value = 888;
   q_policy->FieldByName("no_check_payment")->Value = 1;
   q_policy->FieldByName("is_personal_data")->Value = 1;

   q_vehicle->FieldByName("vehicle_type_id")->Value = 2;
   q_vehicle->FieldByName("vehicle_registration_type_id")->Value = 1;
   q_vehicle->FieldByName("vehicle_registration_type_id_2")->Value = 2;
   q_vehicle->FieldByName("usage_purpose")->Value = 1;

   _di_IXMLDocument XMLDoc = NewXMLDocument();

   try{
      XMLDoc->Active = true;
      //XMLDoc->LoadFromFile("F:\\osago.xml");
      XMLDoc->LoadFromXML(XMLData);
      if(m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\osago20_paste.xml");

      _di_IXMLNode Root = XMLDoc->DocumentElement, ts, persons, child_node;

      ts      = Root->ChildNodes->FindNode("ts");
      persons = Root->ChildNodes->FindNode("persons");

      /*i_val = m_api->dbGetIntFromQuery(res, str.sprintf("select terr_id from gl_dict_regions where terr_name='%s'", NodeToStr(Root->ChildNodes->FindNode("region"))));
      if(i_val) q_policy->FieldByName("region_id")->Value = i_val;*/

      if(TryStrToInt(NodeAttributeToStr(ts->ChildNodes->FindNode("type_ts"), "code", "code"), i_val)){
         if(i_val && m_api->dbGetIntFromQuery(res, str.sprintf("select count(*) from osago_dict_veh_type where code='%s'", AddNulls(i_val, 3))) > 0) q_vehicle->FieldByName("vehicle_type_id")->Value = i_val;
      }
      else{
         i_val = m_api->dbGetIntFromQuery(res, str.sprintf("select code from osago_dict_veh_type where full_name='%s'", NodeToStr(ts->ChildNodes->FindNode("type_ts"))));
         if(i_val) q_vehicle->FieldByName("vehicle_type_id")->Value = i_val;
      }

      q_vehicle->FieldByName("vehicle_brand_name_print")->Value = NodeToStr(ts->ChildNodes->FindNode("marka"));
      child_node = ts->ChildNodes->FindNode("model");
      if(child_node){
         q_vehicle->FieldByName("vehicle_model_name_print")->Value = child_node->Text;
         q_vehicle->FieldByName("rsa_code")->AsString = NodeAttributeToStr(child_node, "code", "code");
         if(!q_vehicle->FieldByName("rsa_code")->AsString.IsEmpty()){
            TADOQuery *q_v = m_api->dbGetCursor(res, str.sprintf("select * from gl_dict_carrier_models where code='%s'", q_vehicle->FieldByName("rsa_code")->AsString));
            if(!q_v->IsEmpty()){
               q_vehicle->FieldByName("vehicle_brand_id")->Value = q_v->FieldByName("carrier_models_fkl")->Value;
               q_vehicle->FieldByName("vehicle_model_id")->Value = q_v->FieldByName("id")->Value;
               q_vehicle->FieldByName("vehicle_brand_name")->Value = q_v->FieldByName("brand_name")->Value;
               if(q_vehicle->FieldByName("vehicle_brand_name_print")->AsString == q_vehicle->FieldByName("vehicle_brand_name")->AsString) q_vehicle->FieldByName("vehicle_brand_name_print")->AsString = empty_str;
               q_vehicle->FieldByName("vehicle_model_name")->Value = q_v->FieldByName("model_name")->Value;
               if(q_vehicle->FieldByName("vehicle_model_name_print")->AsString == q_vehicle->FieldByName("vehicle_model_name")->AsString) q_vehicle->FieldByName("vehicle_model_name_print")->AsString = empty_str;
            }
            m_api->dbCloseCursor(res, q_v);
         }
      }

      if(TryStrToInt(NodeToStr(ts->ChildNodes->FindNode("max_mass")), i_val)) q_vehicle->FieldByName("allowed_mass")->Value = i_val;
      if(TryStrToInt(NodeToStr(ts->ChildNodes->FindNode("passengers_quantity")), i_val)) q_vehicle->FieldByName("number_of_seats")->Value = i_val;

      q_vehicle->FieldByName("vin")->Value = NodeToStr(ts->ChildNodes->FindNode("VIN"));
      q_vehicle->FieldByName("chassis_number")->Value = NodeToStr(ts->ChildNodes->FindNode("chassis"));
      q_vehicle->FieldByName("body_number")->Value = NodeToStr(ts->ChildNodes->FindNode("body"));

      //AnsiString rgpl = Translit_Text(NodeToStr(ts->ChildNodes->FindNode("state_reg_sign")));
      AnsiString rgpl = NodeToStr(ts->ChildNodes->FindNode("state_reg_sign"));
      if(rgpl.Length() > 7) q_vehicle->FieldByName("registration_mark")->Value = rgpl.UpperCase();

      if(TryStrToInt(ts->ChildNodes->FindNode("year")->Text, i_val)) q_vehicle->FieldByName("construction_year")->Value = i_val;
      if(TryStrToInt(ts->ChildNodes->FindNode("power")->Text, i_val)) q_vehicle->FieldByName("engine_power")->Value = i_val;

      child_node = ts->ChildNodes->FindNode("ts_document");
      q_vehicle->FieldByName("vehicle_registration_type_id")->Value = AnsiString(child_node->Attributes["code"]).ToIntDef(1);
      q_vehicle->FieldByName("registration_series")->Value  = AnsiString(child_node->Attributes["series"]);
      q_vehicle->FieldByName("registration_number")->Value = AnsiString(child_node->Attributes["number"]);
      if(TryStrToDate(child_node->Attributes["issue_date"], dt)) q_vehicle->FieldByName("registration_issue_date")->Value = dt;

      child_node = ts->ChildNodes->FindNode("use_purpose");
      if(child_node){
         if(TryStrToInt(NodeAttributeToStr(child_node, "code", "code"), i_val)){
            if(m_api->dbGetIntFromQuery(res, str.sprintf("select count(*) from osago_dict_usagepurpose where usage_purpose_id=%i", i_val)) > 0) q_vehicle->FieldByName("usage_purpose")->Value = i_val;
         }
         else{
            i_val = m_api->dbGetIntFromQuery(res, str.sprintf("select usage_purpose_id from osago_dict_usagepurpose where usage_purpose_name='%s'", AnsiString(child_node->Text)));
            if(i_val) q_vehicle->FieldByName("usage_purpose")->Value = i_val;
         }
      }

      for(int i = 0, cnt = persons->ChildNodes->GetCount(); i < cnt; ++i){
         child_node = persons->ChildNodes->Nodes[i];
         if(TryStrToInt(NodeAttributeToStr(child_node, "code", "code"), i_val)){
            status = ((i_val & 2) == 2 ? 2 : 1);

            if((i_val & 4) == 4){
               q_persons->Insert();
               LoadPersonProdFormat(q_persons, child_node, 1, status, id, dt_s);
               q_policy->FieldByName("fio")->Value = Trim(q_persons->FieldByName("last_name")->AsString + space_str + q_persons->FieldByName("first_name")->AsString + space_str + q_persons->FieldByName("second_name")->AsString);
               q_persons->Post();

               if(status == 2){
                  q_policy->FieldByName("multidrive")->Value = 0;
                  q_policy->FieldByName("product_id")->Value = 3;
                  q_policy->FieldByName("product_name")->Value = "����� ����������� ���";
               }

               q_persons->Insert();
               LoadPersonProdFormat(q_persons, child_node, 2, status, id, dt_s);
               q_persons->Post();
            }
            if((i_val & 32) == 32){
               q_persons->Insert();
               LoadPersonProdFormat(q_persons, child_node, type, status, id, dt_s);
               q_persons->Post();
               ++type;
            }
         }
      }
      

   }
   catch(Exception& ex){}

   q_policy->Post(); q_vehicle->Post(); q_insurer->Post(); q_persons->UpdateBatch();
   m_api->dbCloseCursor(res, q_policy); m_api->dbCloseCursor(res, q_vehicle); m_api->dbCloseCursor(res, q_insurer); m_api->dbCloseCursor(res, q_persons);

   m_api->Module_Refresh_Main_Grid(res);

   return true;
}
//---------------------------------------------------------------------------
int On_User_Copy_Paste(AnsiString &XML, bool Copy_Flag)
{
   int result(0);

   if(Copy_Flag) result = Copy(XML);
   else          result = Paste(XML);

   return result;
}
//---------------------------------------------------------------------------
void Init_API(void* _Mops_Api)
{
   m_api = (mops_api_028*)_Mops_Api;
   if(frmPeport){ delete frmPeport; frmPeport = 0; }

   frmPeport = new TfrmErrReport(0);
   frmPeport->Caption = "��� ����������";

   GetPathDesktopUser();

   File_Osago_Instruction = ExtractFilePath(Application->ExeName) + "system\\docs\\����������_�����.docx";

   di.login = m_api->vrGetVariable(res, "_mops_global_ufo_login_");
   AnsiString pwd = m_api->vrGetVariable(res, "_mops_global_ufo_pwd_");
   unsigned long X[8];
   m_api->Shifr_Init_Internal_API_Key(X);
   di.pwd = m_api->Shifr_Text(res, X, pwd, false);
}
//---------------------------------------------------------------------------
void Create_Frames(TList* frames, TStringList* frames_names)
{
   ResetData();

   frames->Clear();
   frames_names->Clear();

   int is_modify = !di.is_new_dogovor && m_api->dbGetIntFromQuery(res, "select count(*) from osago_modify_reasons where calc_id=" + IntToStr(m_api->dbGet_Main_Grid_Current_CalcID(res)));
   TframeCalc *f_calc;
   TframeReissCalc *f_reiss;

   if(!is_modify) f_calc = new TframeCalc(0, m_api, pi, &di, &vi, pm);
   else f_reiss = new TframeReissCalc(0, m_api, pi, &di, &vi, pm);
   TfrmItogi *fi = new TfrmItogi(0);

   if(!is_modify){
      frames->Add(f_calc);
      frames_names->Add("������");
      f_calc->TotalInfo = fi->TotalInfo;

   }
   else{
      frames->Add(f_reiss);
      frames_names->Add("��������������");
      f_reiss->TotalInfo = fi->TotalInfo;

   }

   frames->Add(fi);
   frames_names->Add("������� �������� �������");
}
//-----------------------------------------------------------------------------
int Save_Frames(TList* frames, long id_calc)
{
   TADOQuery *q = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + IntToStr(id_calc), 0, 0);

   q->CursorLocation = clUseServer;
   q->Open();

   if(q->IsEmpty()) q->Insert();
   else             q->Edit();

   q->FieldByName("calc_id")->Value = id_calc;

   int is_modify = m_api->dbGetIntFromQuery(res, "select count(*) from osago_modify_reasons where calc_id=" + IntToStr(id_calc));

   if(!is_modify) ((TframeCalc*)(frames->Items[0]))->SaveFrame(q);
   else ((TframeReissCalc*)(frames->Items[0]))->SaveFrame(q);

   q->Post();
   m_api->dbCloseCursor(res, q);

   return 1;
}
//------------------------------------------------------------------------------
int Load_Frames(TList *frames, long calc_id)
{
   TADOQuery *q = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + IntToStr(calc_id));

   int is_modify = m_api->dbGetIntFromQuery(res, "select count(*) from osago_modify_reasons where calc_id=" + IntToStr(calc_id));

   if(!is_modify) ((TframeCalc*)(frames->Items[0]))->LoadFrame(q);
   else ((TframeReissCalc*)(frames->Items[0]))->LoadFrame(q);

   m_api->dbCloseCursor(res, q);

   return 1;
}
//------------------------------------------------------------------------------
void Get_Main_Grid_Tables(TStringList *Tables){}
//------------------------------------------------------------------------------
int Save_Frame(void* Frame, long id_calc){ return 1; }
//------------------------------------------------------------------------------
int Load_Frame(void* Frame, long id_calc){ return 1; }
//------------------------------------------------------------------------------
void Get_Module_Print_Forms_Names(TStringList *form_names)
{
   form_names->Add("���������");
   form_names->Add("�����");
   form_names->Add("�����(��������� �����������)");
   form_names->Add("�����(�������� + ��������� �����������)");
   form_names->Add("����� ������ �-�����");
   form_names->Add("����� �� ���� �����������");
   form_names->Add("���������� � ������������ ������");
}
//------------------------------------------------------------------------------
void PrintPDF(const AnsiString& pdf_filename)
{
   if(PreViewFlag) ShellExecute(GetDesktopWindow(), "", pdf_filename.c_str(), "", "", SW_RESTORE);
   else{
      GhostScriptPrinter ghp(pdf_filename, m_api->vrGetVariable(res, "_mops_global_last_used_apo_printer_"));
      ghp.Print();
   }
}
//------------------------------------------------------------------------------
int Print_Form(AnsiString form_name, long calc_id)
{
   AnsiString calc_id_str = IntToStr(calc_id), save_dir = ExtractFilePath(Application->ExeName) + "system\\osago\\pdf\\" + IntToStr(m_api->dbGetIntFromQuery(res, "select num_rash_rm_prod from _mops_calcs_ where [id]=" + calc_id_str));
   bool is_ok_create;
   if(!DirectoryExists(save_dir)) is_ok_create = ForceDirectories(save_dir);
   else is_ok_create = true;
   if(!is_ok_create) save_dir = desktop_folder;
   AnsiString sql(""), pdf_filename(""), ufo_address = m_api->vrGetVariable(res, "_mops_global_ufo_osago_server_address_");
   int result(1);

   frmPeport->Show();
   TADOQuery *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + calc_id_str, 0, 1),
             *q_persons = m_api->dbGetCursor(res, "select t1.*,t2.opf,t2.opf_full from osago_persons t1 left join gl_dict_opf_for_auto t2 on t1.opf_id=t2.id where t1.type_person<3 and t1.calc_id=" + calc_id_str),
             *q_vehicle = m_api->dbGetCursor(res, "select * from osago_vehicle where calc_id=" + calc_id_str),
             *q_insurer = m_api->dbGetCursor(res, "select * from osago_insurer where calc_id=" + calc_id_str);

   /*if(!PreViewFlag && form_name == "�����"){
      TfrmInfoPayment *fip = new TfrmInfoPayment(0);
      if(q_policy->FieldByName("polis_seria")->AsString == xxx) fip->Tag = 1;
      fip->ShowModal();
      delete fip;
   } */

   std::vector<AnsiString> form_names;
   if(form_name == "�����(�������� + ��������� �����������)"){ form_names.push_back("�����(��������� �����������)"); form_names.push_back("�����"); }
   else form_names.push_back(form_name);

   for(int i = 0, cnt = form_names.size(); i < cnt; ++i){
      TMemoryStream *pdf = new TMemoryStream();

      di.black_print = (PreViewFlag && form_names[i] != "�����(��������� �����������)" && form_names[i] != "����� ������ �-�����" && form_names[i] != "����� �� ���� �����������" && form_names[i] != "���������� � ������������ ������") ? true : false;
      di.form_name = form_names[i];
      AnsiString key = form_names[i] + (di.black_print ? underline_str : empty_str);

      frmPeport->memErrors->Lines->Add(AnsiString(PreViewFlag ? "������������" : "������") + " ����� \"" + form_names[i] + "\".");

      ThreadUFO *thr_print_policy = new ThreadUFO(true, ufo_print_policy, ufo_address, m_api, &di, q_policy, q_persons, q_vehicle, q_insurer);
      try{
         thr_print_policy->Resume();
         frmPeport->memErrors->Lines->Add("�������� �������� pdf ����� \"" + form_names[i] + "\".");
         while(WaitForSingleObject((HANDLE)thr_print_policy->Handle, 0) == WAIT_TIMEOUT) PrintStrInLog();
      }
      catch(Exception& ex){
         di.system_error = di.system_error + "\r\n" + ex.Message;
         frmPeport->memErrors->Lines->Add("Exception: " + di.system_error);
      }
      catch(...){
         di.system_error = di.system_error + "\r\n FATAL ERROR.";
         frmPeport->memErrors->Lines->Add("Exception: " + di.system_error);
      }

      delete thr_print_policy;

      if(!di.system_error.IsEmpty() || di.validations_errors->Count){
         delete pdf;
         frmPeport->memErrors->Lines->Add("PDF ���� \"" + form_names[i] + "\" �� �������.");
         if(!di.system_error.IsEmpty()) frmPeport->memErrors->Lines->Add("������ ������ ��� ������ ��������� ������: " + di.system_error);
         if(di.validations_errors->Count) frmPeport->memErrors->Lines->Add("������ ������ ��� ������ ������ ���������: " + di.validations_errors->Text);
         result = 0;
      }
      else{
         AnsiString doc_name = di.data_print->Names[0];

         if(!PreViewFlag && form_names[i] == "�����" && !doc_name.IsEmpty()){
            m_api->Raschet_Set_Status_id(res, calc_id, 5);
            q_policy->Edit();
            q_policy->FieldByName("srok_time_s")->Value = ((int)q_policy->FieldByName("srok_date_s")->AsDateTime == (int)Date()) ? di.time_s : AnsiString("00:00");
            q_policy->Post();
         }

         CreatePDF(m_api, di.data_print->Values[doc_name], pdf);
         pdf_filename = IncludeTrailingBackslash(save_dir) + doc_name ;
         try{
            pdf->SaveToFile(pdf_filename);
            frmPeport->memErrors->Lines->Add("PDF ���� \"" + form_names[i] + "\" ������� � �������� � " + pdf_filename);
            PrintPDF(pdf_filename);
         }
         catch(Exception&){
            frmPeport->memErrors->Lines->Add("������. PDF ���� \"" + form_names[i] + "\" �� �������� � " + pdf_filename + ". ���������� ������� ��� ���������� ��� ��������� pdf � ��������� �������.");
         }

         delete pdf;
      }
   }

   m_api->dbCloseCursor(res, q_policy); m_api->dbCloseCursor(res, q_persons); m_api->dbCloseCursor(res, q_insurer); m_api->dbCloseCursor(res, q_vehicle);

   m_api->Module_Refresh_Main_Grid(res);

   return result;
}
//------------------------------------------------------------------------------
int OnFastReport(AnsiString Form_Name, int form_type, long calc_id, int action, TList *data_sets)
{
   if(action == 0) calc_id = m_api->dbGetIntFromQuery(res, "select max(calc_id) from osago_policy");
   ModifyPreparePrintData::PreparePrintData(m_api, calc_id, Form_Name, data_sets);

   if(action == 1 && !PreViewFlag && Form_Name == "����� ���"){
      TADOQuery *q_p = m_api->dbGetCursor(res, "select op.prev_seria, op.prev_number, oi.lnr from osago_policy as op, osago_insurer oi where op.calc_id=oi.calc_id and op.calc_id=" + IntToStr(calc_id));
      AnsiString ps = q_p->FieldByName("prev_seria")->AsString, pn = q_p->FieldByName("prev_number")->AsString, lnr = q_p->FieldByName("lnr")->AsString;
      m_api->dbCloseCursor(res, q_p);
      bool is_confirm;
      try{
         is_confirm = GetIAPO2_ARM_READER(false, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"))->ConfirmModify(ps, pn, lnr);
      }
      catch(Exception& ex){ ShowMessage(ex.Message); is_confirm = false; }

      if(!is_confirm){
         data_sets->Clear();
         ShowMessage("������, ��� ����� � ����� ������ � ����� ������� ��� ������������.");
         return 0;
      }
      else{
         m_api->Raschet_Set_Status_id(res, calc_id, 10);
         m_api->Module_Refresh_Main_Grid(res);
      }
   }

   return 1;
}
//------------------------------------------------------------------------------
int Universal_Func(AnsiString command, void* lparam, void* hparam)
{
   if(command == "� ����� ���, ����� ���� ������ ����� ���������? (������ �������� - ���� ���� bool*, ������ - ������ ���������� �� ������ ���� TList*)"){
   }

   else if(command == "������ �����������, ������ ������� ��� ���� �������������� �����"){
      if(frmPeport){ delete frmPeport; frmPeport = 0; }
   }
   else if(command == "� ����� ���, ���������� �� MessageBox � ������� ��� ����������? (������ �������� - ���� ���� bool*, ������ - ������ ���������� �� ������ ���� TList*)" && di.is_new_dogovor)
      *((bool*)lparam) = is_message;

   else if(command == "��������� ����� ������������� (������ � ������������ �������� - ���� ���� bool*)")
      PreViewFlag = *((bool*)lparam);

   else if(command == "���� ������ ������ ��������") di.is_new_dogovor = true;
   else if(command == "���� ������ ������ ��������") di.is_new_dogovor = false;
   else if(command == "�������� ��������� ��� �������� ���� out->Values[<��� �����>]=[0 ��� 1] (������ �������� TStringList* out,������ int* calc_id)"){

      frmPeport->memErrors->Lines->Clear();

      TStringList *out = (TStringList *)lparam;
      int calc_id = *(int*)hparam;
      AnsiString sql(""), calc_id_str = IntToStr(calc_id);
      int sd = m_api->Raschet_Get_Status_id(res, calc_id);

      TADOQuery *q_calc = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + calc_id_str), *q_policy = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + calc_id_str);
      int is_visible = !q_calc->FieldByName("no_calc")->AsInteger && !(m_api->Err_Is_Calc_Error_By_Type(res, err_print, calc_id)) && ((sd == 1 && (int)q_policy->FieldByName("srok_date_s")->AsDateTime >= Date()) || sd == 5);
      int is_xxx = sd == 11 && (q_policy->FieldByName("polis_seria")->AsString == "���" || q_policy->FieldByName("polis_seria")->AsString == "XXX");
      int is_visible_eee = is_visible && (q_policy->FieldByName("polis_seria")->AsString == "���" || q_policy->FieldByName("polis_seria")->AsString == "EEE");
      int is_visible_xxx = is_visible && (q_policy->FieldByName("polis_seria")->AsString == "���" || q_policy->FieldByName("polis_seria")->AsString == "XXX");
      int is_stoa_otkaz = is_visible && q_policy->FieldByName("stoa_id")->AsInteger == 2;
      int is_personal_data = is_visible && q_policy->FieldByName("is_personal_data")->AsInteger == 1 && q_policy->FieldByName("product_id")->AsInteger == 2;

      int is_date_return_ok = q_policy->FieldByName("is_mop_911")->AsInteger ? DaysBetween((int)q_policy->FieldByName("return_date")->AsDateTime, Date()) > 1 : true;

      int is_visible_modify_statement = (sd == 10 || sd == 13) && !(m_api->Err_Is_Calc_Error_By_Type(res, err_modify, calc_id));
      int is_visible_modify_policy = sd == 13 && !(m_api->Err_Is_Calc_Error_By_Type(res, err_modify, calc_id)) && !(m_api->Err_Is_Calc_Error_By_Type(res, err_print, calc_id)) && is_date_return_ok;
      int is_visible_modify_other = is_visible_modify_statement && !(m_api->Err_Is_Calc_Error_By_Type(res, err_print, calc_id)) && is_date_return_ok;
      int is_list_drivers = is_visible_modify_other && m_api->dbGetIntFromQuery(res, "select count(*) as cnt from osago_persons where type_person > 3 and is_removed=0 and calc_id=" + q_calc->FieldByName("calc_id")->AsString) > 4;

      m_api->dbCloseCursor(res, q_calc); m_api->dbCloseCursor(res, q_policy);

      out->Values["���������"] = is_visible;
      out->Values["�����(�������� + ��������� �����������)"] = is_visible_xxx;
      out->Values["�����"] = is_visible_eee;
      out->Values["�����(��������� �����������)"] = is_visible_eee;
      out->Values["����� ������ �-�����"] = is_xxx;
      out->Values["����� �� ���� �����������"] = is_stoa_otkaz;
      out->Values["���������� � ������������ ������"] = is_personal_data;

      /*��������������*/
      out->Values["��������� �� ��������������"] = is_visible_modify_statement;
      out->Values["����� ���(��������)"] = is_visible_modify_other;
      out->Values["����� ��� 2-� ���������"] = is_visible_modify_other;
      out->Values["����� ���"] = is_visible_modify_policy;
      out->Values["������ ����������"] = is_list_drivers;
   }

   else if(command == "��������� ���������� �� ��� (������ �������� - ��� ����������� AnsiString*, api ��� ����� �������� �������� glDic_Get_SKK_API)"){
      AnsiString key = *((AnsiString*)lparam);
      mops_api_008 *skk_api = dynamic_cast<mops_api_008*>(m_api)->glDic_Get_SKK_API(res);
      TblQue val = skkq[key];
      mops_api_007* api = val.transdekra ? (mops_api_007*)m_api->glDic_Get_API(res, "����������, ���������") : m_api;
      api->dbExecuteQuery(res, "delete * from " + val.table_apo);
      TADOQuery *q_source = skk_api->dbGetCursor(res, val.sql_skk), *q_dest = api->dbGetCursor(res, "select * from " + val.table_apo, 0);
      for(q_source->First(); !q_source->Eof; q_source->Next()){
         q_dest->Insert();
         for(int i = 0, fcnt = q_source->FieldCount; i < fcnt; ++i) q_dest->Fields->Fields[i]->AsString = q_source->Fields->Fields[i]->AsString;
      }
      q_dest->UpdateBatch();
      api->dbCloseCursor(res, q_dest); skk_api->dbCloseCursor(res, q_source);
   }

   else if(command == "������������ ��������� xml ���� (������ �������� ��� ����� AnsiString*,���� ���������; ������ XML - AnsiString*)"){
      AnsiString type_xml = *(AnsiString*)lparam, xml = *(AnsiString*)hparam;
      if(type_xml == "���2"){
         int calc_id = XMLLoad(xml);
         if(calc_id) *(AnsiString*)lparam = "Calc_Id=" + IntToStr(calc_id);
      }
      else if(type_xml == "OIB") XMLLoadOIB(xml);
   }

   else if(command == "���� ������������ ������� (������ �������� - �������� ����� TFrame*, ������ ������ ���� ������� TList *)"){
   }
   else if(command == "������������ ������� ��������? (������ �������� bool*)") *((bool*)lparam) = true;

   else if(command == "�������� ������ �� ����� �� �������� (������ �������� int* calc_id)" || command == "�������� ���������� ������ ��� ����� (������ � ������������ �������� - calc_id ���� long*)"){
      AnsiString calc_id_str = IntToStr(*(int*)lparam), sql("");

      m_api->dbExecuteQuery(res, sql.sprintf("update osago_calc set quotation_date=Date(),no_calc=1 where calc_id=%s", calc_id_str));
      m_api->dbExecuteQuery(res, sql.sprintf("update osago_policy set contract_id=null,no_check_payment=1,stoa_request_id=null,result_check_bso=888,stoa_result_status=0,send_code=0,confirm_code=0,result_check_bso_a7=888 where calc_id=%s", calc_id_str));
      m_api->dbExecuteQuery(res, sql.sprintf("delete from osago_stoa where calc_id=%s", calc_id_str));
      
      InsertCurrentUser(calc_id_str);

      m_api->Raschet_Set_Status_id(res, *(int*)lparam, 0);
   }

   else if(command == "����� � ����� ������� ����� ������ �������� (������ �������� TStringList*, ����������� �������� �������� � ->Values[<������>])"){
      TStringList *out = (TStringList *)lparam;
      for(int i = 0, cnt = out->Count; i < cnt; ++i) out->Values[out->Names[i]] = 0;
   }

   else if(command == "����� ��� ������ XML ��� SOAP ������� �������� � ��� (������ �������� AnsiString*)") *(AnsiString*)lparam = AnsiString("0.0.2.0");

   else if(command == "��� ��� ������ ��������� ��������� ����� ������ ��� ������� �� ��� (������ �������� TStringList* out)"){
      TStringList * sl = (TStringList*)lparam;

      sl->Add("���");
      sl->Add("���");
      sl->Add("���");
      sl->Add("���");
      sl->Add("���");
   }

   else if(command == "���� ������ � ������ (������ �������� - CorrelationId AnsiString*; ������ - ������ ���� ���� TStringList*))"){
      di.corellation_id = *(AnsiString*)lparam;
   }

   return 1;
}
//------------------------------------------------------------------------------
#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
   return 1;
}
//---------------------------------------------------------------------------



