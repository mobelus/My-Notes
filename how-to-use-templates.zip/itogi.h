//---------------------------------------------------------------------------


#ifndef itogiH
#define itogiH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmItogi : public TFrame{
__published:	// IDE-managed Components
   TRichEdit *TotalInfo;
private:	// User declarations
public:		// User declarations
    __fastcall TfrmItogi(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmItogi *frmItogi;
//---------------------------------------------------------------------------
#endif
