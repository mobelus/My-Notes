//---------------------------------------------------------------------------


#pragma hdrstop

#include "UWriteSoap.h"

#pragma package(smart_init)
