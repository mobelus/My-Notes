//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "XML_Progress_Form_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGAUGES"
#pragma resource "*.dfm"
TProgress_Form *Progress_Form;
//---------------------------------------------------------------------------
__fastcall TProgress_Form::TProgress_Form(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
