//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "UAddPermitted.h"
#include "DateUtils.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "SHDocVw_OCX"
#pragma link "cxControls"
#pragma link "cxDBEditRepository"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxStyles"
#pragma link "cxTextEdit"
#pragma link "cxVGrid"
#pragma resource "*.dfm"
TfrmAddPermitted *frmAddPermitted;
//---------------------------------------------------------------------------
__fastcall TfrmAddPermitted::TfrmAddPermitted(TComponent *Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, Dogovor_Info *p_di)
: TForm(Owner), m_api(_m_api), pm(p_pm), pi(p_pi), di(p_di)
{
   DocComboBoxItem->Properties->Items->AddObject("��", (TObject*)17);
   DocComboBoxItem->Properties->Items->AddObject("������������ �����������", (TObject*)24);
   DocComboBoxItem->Properties->Items->AddObject("������������� �����������-���������", (TObject*)39);
   DocComboBoxItem->Properties->Items->AddObject("������������� �����������-��������� ������� �������", (TObject*)40);
   DocComboBoxItem->Properties->Items->AddObject("���� ������������� �� ���������� ��", (TObject*)23);

   PrevDocComboBoxItem->Properties->Items->AddObject("���", (TObject*)0);
   PrevDocComboBoxItem->Properties->Items->AddObject("��", (TObject*)17);
   PrevDocComboBoxItem->Properties->Items->AddObject("������������ �����������", (TObject*)24);
   PrevDocComboBoxItem->Properties->Items->AddObject("������������� �����������-���������", (TObject*)39);
   PrevDocComboBoxItem->Properties->Items->AddObject("������������� �����������-��������� ������� �������", (TObject*)40);
   PrevDocComboBoxItem->Properties->Items->AddObject("���� ������������� �� ���������� ��", (TObject*)23);
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::FormShow(TObject *Sender)
{
   if(btn) pm_temp = pm[Tag];

   //rgPmSex->Properties->Value = pm[Tag].sex > 0 ? RGItemSex->Properties->Items->Items[pm[Tag].sex - 1]->Caption : empty_str;
   editPmLastName->Properties->Value = pm[Tag].lastname;
   editPmPrevLastName->Properties->Value = pm[Tag].prev_lastname;
   editPmFirstName->Properties->Value = pm[Tag].firstname;
   editPmPrevFirstName->Properties->Value = pm[Tag].prev_firstname;
   editPmSecondName->Properties->Value = pm[Tag].secondname;
   SetValueRowDateEdit(deditPmBirthDate, pm[Tag].birthdate);
   SetValueRowDateEdit(deditPmStartDriving, pm[Tag].doc_issue_date);
   //rgPmDocType->Properties->Value = RGItemDoc->Properties->Items->Items[GetIndexItemByTag(RGItemDoc->Properties->Items, pm[Tag].doc_type)]->Caption;
   FieldValueIDToVGEditor(pm[Tag].doc_type, DocComboBoxItem, rgPmDocType);
   ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag, pm[Tag].doc_seria, pm[Tag].doc_number);
   editPmDocSeria->Properties->Value = pm[Tag].doc_seria; //StringReplace(pm[Tag].doc_seria, space_str, empty_str, rf);
   editPmDocNumber->Properties->Value = pm[Tag].doc_number;
   //rgPmPrevDocType->Properties->Value = RGItemPrevDoc->Properties->Items->Items[GetIndexItemByTag(RGItemPrevDoc->Properties->Items, pm[Tag].license_type)]->Caption;
   FieldValueIDToVGEditor(pm[Tag].prev_doc_type, PrevDocComboBoxItem, rgPmPrevDocType);
   ChangeMaskLicense(MaskItemPrevSeries, MaskItemPrevNumber, editPmPrevDocSeria, editPmPrevDocNumber, pm, Tag, pm[Tag].prev_doc_seria, pm[Tag].prev_doc_number);
   editPmPrevDocSeria->Properties->Value = pm[Tag].prev_doc_seria; //StringReplace(pm[Tag].doc_seria, space_str, empty_str, rf);
   editPmPrevDocNumber->Properties->Value = pm[Tag].prev_doc_number;
   SetValueRowDateEdit(deditPmPrevStartDate, pm[Tag].prev_doc_issue_date);
   SetValueRowDateEdit(deditPmPrevEndDate, pm[Tag].prev_doc_end_date);

   labHint->Visible = false;

   btnCancel->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::btnCopyDataClick(TObject *Sender)
{
   editPmLastName->Properties->Value   = pm[Tag].lastname   = pi[0].lastname;
   editPmFirstName->Properties->Value  = pm[Tag].firstname  = pi[0].firstname;
   editPmSecondName->Properties->Value = pm[Tag].secondname = pi[0].secondname;
   pm[Tag].birthdate = pi[0].birthdate;
   SetValueRowDateEdit(deditPmBirthDate, pm[Tag].birthdate);
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::RGItemSexPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   pm[Tag].sex = rgPmSex->Properties->Value.IsNull() ? -1 : RGItemSex->Properties->GetRadioGroupItemIndex(rgPmSex->Properties->Value) + 1;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::RGItemDocPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   pm[Tag].doc_type = rgPmDocType->Properties->Value.IsNull() ? -1 : RGItemDoc->Properties->Items->Items[RGItemDoc->Properties->GetRadioGroupItemIndex(rgPmDocType->Properties->Value)]->Tag;
   if(pm[Tag].doc_type > 0) ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag);
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::RGItemPrevDocPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   pm[Tag].license_type = rgPmPrevDocType->Properties->Value.IsNull() ? -1 : RGItemPrevDoc->Properties->Items->Items[RGItemPrevDoc->Properties->GetRadioGroupItemIndex(rgPmPrevDocType->Properties->Value)]->Tag;
   if(pm[Tag].license_type > -1) ChangeMaskLicense(MaskItemPrevSeries, MaskItemPrevNumber, editPmPrevDocSeria, editPmPrevDocNumber, pm, Tag);
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::TextItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();

   labHint->Top = vg->InplaceEditor->Top + 1;
   labHint->Visible = true;

   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   switch(r->Tag){
      case  2: pm[Tag].lastname       = val.IsNull() ? empty_str : AnsiString(val); break; //editPmLastName
      case  3: pm[Tag].firstname      = val.IsNull() ? empty_str : AnsiString(val); break; //editPmFirstName
      case  4: pm[Tag].secondname     = val.IsNull() ? empty_str : AnsiString(val); break; //editPmSecondName
      case 12: pm[Tag].prev_lastname  = val.IsNull() ? empty_str : AnsiString(val); break; //editPmPrevLastName
      case 15: pm[Tag].prev_firstname = val.IsNull() ? empty_str : AnsiString(val); break; //editPmPrevFirstName
   }
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DateItemPropertiesChange(TObject *Sender)
{
   labHint->Top = vg->InplaceEditor->Top + 1;
   labHint->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties)
{
   labHint->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DateItemPropertiesEditValueChanged(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   Variant val = r->Properties->Value;
   AnsiString dt_str("");
   switch(r->Tag){
      case  5: VariantToDate(val, pm[Tag].birthdate); break; //deditPmBirthDate
      case  6: VariantToDate(val, pm[Tag].doc_issue_date); break; //deditPmStartDriving
      case  8: pm[Tag].doc_seria  = val.IsNull() ? empty_str : AnsiString(val); break; //editPmDocSeria
      case  9: pm[Tag].doc_number = val.IsNull() ? empty_str : AnsiString(val); break; //editPmDocNumber
      case 10: pm[Tag].prev_doc_seria  = val.IsNull() ? empty_str : AnsiString(val); break; //editPmDocSeria
      case 11: pm[Tag].prev_doc_number = val.IsNull() ? empty_str : AnsiString(val); break; //editPmDocNumber
      case 13: VariantToDate(val, pm[Tag].prev_doc_issue_date); break; //deditPmPrevStartDate
      case 14: VariantToDate(val, pm[Tag].prev_doc_end_date); break; //deditPmPrevEndDate
   }
   labHint->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DateItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   if(Error) DisplayValue = variant_null;
   Error = false;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::btnCancelClick(TObject *Sender)
{
   if(vg->InplaceEditor){
      vg->InplaceEditor->Clear();
      vg->InplaceEditor->PostEditValue();
   }
   if(btn) pm[Tag] = pm_temp;

   Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::btnOKClick(TObject *Sender)
{
   pm[Tag].age        = CalcYears(pm[Tag].birthdate, di->today);
   pm[Tag].experience = CalcYears(pm[Tag].doc_issue_date, di->today);
   if(pm[Tag].experience < 0) pm[Tag].experience = 0;
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::DocComboBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   Variant v = rgPmDocType->Properties->Value;
   if(v.IsNull() || v.IsEmpty()) return;

   int index = DocComboBoxItem->Properties->Items->IndexOf(v);
   if(index > -1){
      pm[Tag].doc_type = (int)DocComboBoxItem->Properties->Items->Objects[index];
      ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag);
   }
}
//---------------------------------------------------------------------------
void __fastcall TfrmAddPermitted::PrevDocComboBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   Variant v = rgPmPrevDocType->Properties->Value;
   if(v.IsNull() || v.IsEmpty()) return;

   int index = PrevDocComboBoxItem->Properties->Items->IndexOf(v);
   if(index > -1){
      pm[Tag].prev_doc_type = (int)PrevDocComboBoxItem->Properties->Items->Objects[index];
      if(pm[Tag].prev_doc_type > 0) ChangeMaskLicense(MaskItemPrevSeries, MaskItemPrevNumber, editPmPrevDocSeria, editPmPrevDocNumber, pm, Tag);
   }
}
//---------------------------------------------------------------------------

