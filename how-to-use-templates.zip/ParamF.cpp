//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "ParamF.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma link "cxControls"
#pragma link "cxDBEditRepository"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxContainer"
#pragma link "cxDropDownEdit"
#pragma link "cxMaskEdit"
#pragma link "cxTextEdit"
#pragma resource "*.dfm"
TfrmInfoRsa *frmInfoRsa;
//---------------------------------------------------------------------------
__fastcall TfrmInfoRsa::TfrmInfoRsa(TComponent* Owner, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pm)
   : TForm(Owner), m_api(mops), di(p_di), pm(p_pm)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmInfoRsa::btnCancelClick(TObject *Sender)
{
   Hide();
}
//---------------------------------------------------------------------------
void __fastcall TfrmInfoRsa::cboxRsaResponseTypePropertiesChange(TObject *Sender)
{
   //di->calc_info.kbm_info.kbm_message_code;
   int index = cboxRsaResponseType->ItemIndex;
   KbmInfo kbm_info = index > 0 ? pm[index - 1].kbm_info : di->calc_info.kbm_info;
   vgLossAmount->Visible = index > 0;

   vgStateResponse->Properties->Caption = /*kbm_info.kbm_message + */kbm_info.kbm_error;
   vgStateResponse->Styles->Header = kbm_info.kbm_error_code ? cxStyleRed : cxStyleGreen;
   vgRequestId->Properties->Value = kbm_info.rsa_id;
   vgKbmClass->Properties->Value = kbm_info.kbm_class;
   vgKbmValue->Properties->Value = FloatToStr(index > 0 ? pm[Tag - 1].kbm : di->calc_info.kbm);
   vgLossAmount->Properties->Value = IntToStr(kbm_info.loss_amount);
   vgPolicySeries->Properties->Value = kbm_info.prev_policy_series.IsEmpty() ? not_found : kbm_info.prev_policy_series;
   vgPolicyNumber->Properties->Value = kbm_info.prev_policy_number.IsEmpty() ? not_found : kbm_info.prev_policy_number;
   vgCompany->Properties->Value = kbm_info.prev_policy_company.IsEmpty() ? not_found : kbm_info.prev_policy_company;

   vgPolicySeries->Styles->Content = kbm_info.prev_policy_series.IsEmpty() ? cxStyleRed : cxStyleGreen;
   vgPolicyNumber->Styles->Content = kbm_info.prev_policy_number.IsEmpty() ? cxStyleRed : cxStyleGreen;
   vgCompany->Styles->Content = kbm_info.prev_policy_company.IsEmpty() ? cxStyleRed : cxStyleGreen;
}
//---------------------------------------------------------------------------

