//---------------------------------------------------------------------------

#ifndef ULoadDictH
#define ULoadDictH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include "functions.h"

//---------------------------------------------------------------------------
template <class T> class LoadDictionary{
private:

   AnsiString sql;
   int res;
   TADOQuery *q;
                                                                       
   T *f_calc;
   mops_api_028 *m_api;
   Dogovor_Info *di;
   PersonInfo *pi;
   VehicleInfo *vi;

   typedef pair<int, AnsiString> Kanal;
   typedef multimap<int, Kanal> Kanals;
   Kanals mmap;

   std::set<int> office_salechannel;
private:
   /*****/
   void ClearBrandsModels()
   {
      f_calc->cboxBrands->Properties->ListSource = 0;
      f_calc->cboxBrands->EditValue = vi->brand_id = variant_null;
      vi->vehicle_brand_name = vi->vehicle_brand_name_print = vi->transdekra_id = empty_str;
      SetTextAndColorInEditBox(vi->vehicle_brand_name_print, f_calc->editBrand, f_calc->editPolicySeriesChange);
      if(vi->q_brands){ m_api->dbCloseCursor(res, vi->q_brands); vi->q_brands = 0; }

      ClearModels();
   }
   //---------------------------------------------------------------------------

   /*****/
   void ClearModels()
   {
      f_calc->cboxModels->Properties->ListSource = 0;
      f_calc->cboxModels->EditValue = vi->model_id = variant_null;
      vi->vehicle_model_name = vi->vehicle_model_name_print = vi->rsa_code = vi->transdekra_id = empty_str;
      SetTextAndColorInEditBox(vi->vehicle_model_name_print, f_calc->editModel, f_calc->editPolicySeriesChange);
      if(vi->q_models){ m_api->dbCloseCursor(res, vi->q_models); vi->q_models = 0; }
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadBrands()
   {
      vi->q_brands = m_api->dbGetCursor(res, "select distinct brand_name, carrier_models_fkl as id from gl_dict_carrier_models where carrier_type_fk=" + IntToStr(vi->vehicle_type_id));
      f_calc->ds_brands->DataSet = vi->q_brands;
      f_calc->cboxBrands->Properties->ListSource = f_calc->ds_brands;
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadModels()
   {
      if(VarType(vi->brand_id) == varInteger){
         vi->q_models = m_api->dbGetCursor(res, "select id, code, model_name, rf_dev_type_fk from gl_dict_carrier_models where carrier_type_fk=" + IntToStr(vi->vehicle_type_id) + " and carrier_models_fkl=" + IntToStr(vi->brand_id.intVal) + " order by model_name");
         f_calc->ds_models->DataSet = vi->q_models;
         f_calc->cboxModels->Properties->ListSource = f_calc->ds_models;
      }
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadMultidrive()
   {
      ClearTcxComboBox(f_calc->cboxMultydrive, f_calc->cboxMultydrivePropertiesChange);
      q = m_api->dbGetCursor(res, sql.sprintf("select * from osago_dict_multidrive where is_juridical=%i and CDate('%s')>=start_date and CDate('%s')<=end_date order by [limited_drivers]", (pi[0].status == 2 || pi[1].status == 2 || vi->is_foreign_registration) ? 1 : 0, di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next())
         f_calc->cboxMultydrive->Properties->Items->AddObject(q->FieldByName("name_limited_drivers")->AsString, (TObject*)q->FieldByName("limited_drivers")->AsInteger);
      m_api->dbCloseCursor(res, q);

      int default_value = (pi[0].status != 2 && pi[1].status != 2 && !vi->is_foreign_registration) ? 1 : 0;
      Variant tm = di->type_multydrive;
      SetIndexTcxComboBox(f_calc->cboxMultydrive, tm, f_calc->cboxMultydrivePropertiesChange, 1, default_value);
      di->type_multydrive = tm;
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadPeriod()
   {
      ClearTcxComboBox(f_calc->cboxSrok, f_calc->cboxSrokPropertiesChange);
      int is_juridical(-1);
      if(!vi->is_transit && !vi->is_foreign_registration) is_juridical = (pi[0].status == 2 || pi[1].status == 2) ? 1 : 0;
      q = m_api->dbGetCursor(res, sql.sprintf("select * from osago_dict_usageperiod where is_juridical=%i and is_transit=%i and is_foreign_registration=%i and (vehicle_type_id=0 or vehicle_type_id=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by sort_order", is_juridical, vi->is_transit, vi->is_foreign_registration, vi->vehicle_type_id, di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next())
         f_calc->cboxSrok->Properties->Items->AddObject(q->FieldByName("period_name")->AsString, (TObject*)q->FieldByName("period_month")->AsInteger);

      f_calc->labPeriod->Caption = q->FieldByName("caption_name")->AsString;
      m_api->dbCloseCursor(res, q);

      Variant mc = di->monthcount;
      SetIndexTcxComboBox(f_calc->cboxSrok, mc, f_calc->cboxSrokPropertiesChange, 1, 12);
      di->monthcount = mc;

      f_calc->cboxSrokPropertiesChange(0);
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadUsagePurpose()
   {
      ClearTcxComboBox(f_calc->cboxUsage, f_calc->cboxUsagePropertiesChange);
      int is_juridical = (pi[0].status == 2 && pi[1].status == 2) ? 1 : 0;
      q = m_api->dbGetCursor(res, sql.sprintf("select * from osago_dict_usagepurpose where (is_juridical=-1 or is_juridical=%i) and CDate('%s')>=start_date and CDate('%s')<=end_date order by usage_purpose_id", is_juridical, di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next())
         f_calc->cboxUsage->Properties->Items->AddObject(q->FieldByName("usage_purpose_name")->AsString, (TObject*)q->FieldByName("usage_purpose_id")->AsInteger);

      m_api->dbCloseCursor(res, q);

      Variant up = vi->usage_purpose_id;
      SetIndexTcxComboBox(f_calc->cboxUsage, up, f_calc->cboxUsagePropertiesChange, 1, is_juridical ? 9 : 1);
      vi->usage_purpose_id = up;
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadPaymentDoc()
   {
      ClearTcxComboBox(f_calc->cboxPaymentDoc, f_calc->cboxPaymentDocPropertiesChange);
      q = m_api->dbGetCursor(res, "select doc_id, doc_name from osago_dict_pay_doc where parent_id=" + IntToStr(di->payment_id));
      for(q->First(); !q->Eof; q->Next())
         f_calc->cboxPaymentDoc->Properties->Items->AddObject(q->FieldByName("doc_name")->AsString.Trim(), (TObject*)q->FieldByName("doc_id")->AsInteger);
      m_api->dbCloseCursor(res, q);
   }
   //---------------------------------------------------------------------------

   /*****/
   void LoadTree(TTreeView *tree, TTreeNode *node, int parent_id)
   {
      if(parent_id == 0){
         AnsiString sql("");
         q = m_api->dbGetCursor(res, sql.sprintf("select id,parent_id,name_kanal,[input] from gl_dict_kanal_prodag where id not in (900, 901, 902, 903, 904) and CDate('%s')>=start_date and CDate('%s')<=end_date order by parent_id, sort_order", di->calc_date, di->calc_date));
         for(mmap.clear(), q->First(); !q->Eof; q->Next())
            mmap.insert(std::make_pair(q->FieldByName("parent_id")->AsInteger, std::make_pair(q->FieldByName("id")->AsInteger, q->FieldByName("name_kanal")->AsString.Trim())));
         m_api->dbCloseCursor(res, q);
      }
      Kanals::iterator i = mmap.find(parent_id);
      while(i != mmap.end() && i->first == parent_id){
         TTreeNode *nd = tree->Items->AddChildObject(node, i->second.second, (TObject*)i->second.first);
         LoadTree(tree, nd, i->second.first);
         i++;
      }
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadControlAfterChangeRegion(TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row, const AnsiString& filter, const AnsiString& fieldname_text, const AnsiString& fieldname_id)
   {
      if(!filter.IsEmpty()){
         FilterDataSet(q, filter);
         q->Sort = "nam ASC";
      }
      for(cboxitem->Properties->Items->Clear(), q->First(); !q->Eof; q->Next())
         cboxitem->Properties->Items->AddObject(q->FieldByName(fieldname_text)->AsString, (TObject*)q->FieldByName(fieldname_id)->AsInteger);
      if(q->RecordCount) cboxitem->Properties->Items->InsertObject(0, "���", (TObject*)0);
      row->Visible = q->RecordCount;
      row->Properties->Value = variant_null;
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadCityAreaPlace()
   {
      di->kladr_city_id = di->kladr_area_id = di->kladr_place_id = 0;

      q = m_api->dbGetCursor(res, sql.sprintf("select nam,(nam + ' ' + socr + '.') as nam_raion,(socr + '. ' + nam) as nam_cityplace,raion,gorod,punkt from gl_dict_kt_kladr where act=0 and reg=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->kladr_region_id, di->calc_date, di->calc_date));

      ReloadControlAfterChangeRegion(f_calc->AreaComboBoxItem, f_calc->vg_cboxArea, "raion > 0 and gorod=0 and punkt=0", "nam_raion", "raion");

      ReloadControlAfterChangeRegion(f_calc->CityComboBoxItem, f_calc->vg_cboxCity, "gorod > 0 and raion=0 and punkt=0", "nam_cityplace", "gorod");

      ReloadControlAfterChangeRegion(f_calc->PlaceComboBoxItem, f_calc->vg_cboxPlace, "punkt > 0 and raion=0 and gorod=0", "nam_cityplace", "punkt");

      m_api->dbCloseCursor(res, q);
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadCityPlace()
   {
      di->kladr_city_id = di->kladr_place_id = 0;

      q = m_api->dbGetCursor(res, sql.sprintf("select nam,(socr + '. ' + nam) as nam_cityplace,raion,gorod,punkt from gl_dict_kt_kladr where act=0 and reg=%i and raion=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->kladr_region_id, di->kladr_area_id, di->calc_date, di->calc_date));

      ReloadControlAfterChangeRegion(f_calc->CityComboBoxItem, f_calc->vg_cboxCity, "gorod > 0 and punkt=0", "nam_cityplace", "gorod");

      ReloadControlAfterChangeRegion(f_calc->PlaceComboBoxItem, f_calc->vg_cboxPlace, "punkt > 0 and gorod=0", "nam_cityplace", "punkt");

      m_api->dbCloseCursor(res, q);
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadPlace()
   {
      di->kladr_place_id = 0;

      q = m_api->dbGetCursor(res, sql.sprintf("select nam,(socr + '. ' + nam) as nam_cityplace,punkt from gl_dict_kt_kladr where act=0 and punkt > 0 and reg=%i and raion=%i and gorod=%i and CDate('%s')>=start_date and CDate('%s')<=end_date order by nam", di->kladr_region_id, di->kladr_area_id, di->kladr_city_id, di->calc_date, di->calc_date));

      ReloadControlAfterChangeRegion(f_calc->PlaceComboBoxItem, f_calc->vg_cboxPlace, empty_str, "nam_cityplace", "punkt");

      m_api->dbCloseCursor(res, q);
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadVehicleDocs()
   {
      ClearTcxComboBox(f_calc->cboxVehicleDoc,  f_calc->cboxVehicleDocPropertiesChange);
      ClearTcxComboBox(f_calc->cboxVehicleDoc2, f_calc->cboxVehicleDocPropertiesChange);
      vi->not_main_vehicle_docs.clear();

      q = m_api->dbGetCursor(res, "select * from osago_dict_veh_doc_type where is_foreign_registration=" + IntToStr(vi->is_foreign_registration) + " order by vehicle_registr_type_id");
      for(q->First(); !q->Eof; q->Next()){
         if(q->FieldByName("vehicle_registr_order_type")->AsInteger == 1) f_calc->cboxVehicleDoc->Properties->Items->AddObject(q->FieldByName("vehicle_registr_type_name")->AsString, (TObject*)q->FieldByName("vehicle_registr_type_id")->AsInteger);
         if(q->FieldByName("vehicle_registr_type_id")->AsInteger == 1 || q->FieldByName("vehicle_registr_type_id")->AsInteger == 3) f_calc->cboxVehicleDoc2->Properties->Items->AddObject(q->FieldByName("vehicle_registr_type_name")->AsString, (TObject*)(TObject*)q->FieldByName("vehicle_registr_type_id")->AsInteger);
         if(!q->FieldByName("is_main")->AsInteger) vi->not_main_vehicle_docs.insert(q->FieldByName("vehicle_registr_type_id")->AsInteger);
      }
      m_api->dbCloseCursor(res, q);

      Variant veh_doc = vi->vehicle_registration_type_id;
      SetIndexTcxComboBox(f_calc->cboxVehicleDoc, veh_doc, f_calc->cboxVehicleDocPropertiesChange, 1, vi->is_foreign_registration ? 7 : 1);
      vi->vehicle_registration_type_id = veh_doc;

      vi->vehicle_registration_type_id_2 = 0;
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadPaymentMethod()
   {
      AnsiString sql("select * from osago_dict_pay_method_ui where CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date");

      if(di->is_e_policy){
         int sale_channel_id = office_salechannel.count(di->user_info.sale_channel_id) ? 130 : di->user_info.sale_channel_id;
         sql = "select * from osago_dict_pay_method_ui where sale_channel_id=" + IntToStr(sale_channel_id) + " and office_type=" + IntToStr(di->user_info.office_type) + " and is_special_saler=" + IntToStr(di->user_info.is_special_saler) + " and CDate('" + di->calc_date + "')>=start_date and CDate('" + di->calc_date + "')<=end_date";
      }
      ClearTcxComboBox(f_calc->cboxPaymentMethod, f_calc->cboxPaymentMethodPropertiesChange);
      q = m_api->dbGetCursor(res, sql);
      for(q->First(); !q->Eof; q->Next())
         f_calc->cboxPaymentMethod->Properties->Items->AddObject(q->FieldByName("payment_method_name")->AsString, (TObject*)q->FieldByName("payment_method_id")->AsInteger);
      m_api->dbCloseCursor(res, q);

      Variant pm = di->payment_method_id;
      SetIndexTcxComboBox(f_calc->cboxPaymentMethod, pm, f_calc->cboxPaymentMethodPropertiesChange, 1, 0);
      di->payment_method_id = pm;
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadPaymentScheme()
   {
      TADOQuery *q_sch = m_api->dbGetCursor(res, "select * from osago_dict_pay_scheme where payment_method_id=" + IntToStr(di->payment_method_id));

      Variant pm = q_sch->FieldByName("payment_type_id")->Value;
      SetIndexTcxComboBox(f_calc->cboxPaymentType, pm, f_calc->cboxPaymentTypePropertiesChange, 1, 0);
      di->payment_id = pm;

      ReloadPaymentDoc();
      pm = q_sch->FieldByName("payment_doc_id")->Value;
      SetIndexTcxComboBox(f_calc->cboxPaymentDoc, pm, f_calc->cboxPaymentDocPropertiesChange);
      di->payment_doc_id = pm;
      f_calc->cboxPaymentDocPropertiesChange(0);

      m_api->dbCloseCursor(res, q_sch);
   }
   //---------------------------------------------------------------------------

public:

   __fastcall LoadDictionary(T *p_fcalc, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi, VehicleInfo *p_vi) : f_calc(p_fcalc), m_api(mops), di(p_di), pi(p_pi), vi(p_vi)
   {
      office_salechannel.insert(131);
      office_salechannel.insert(132);
      office_salechannel.insert(133);
      office_salechannel.insert(135);
      office_salechannel.insert(139);
   }
   //---------------------------------------------------------------------------

   /*****/
   void LoadStaticDicts()
   {
      // ���� ��
      q = m_api->dbGetCursor(res, "select * from osago_dict_veh_type order by code");
      for(q->First(); !q->Eof; q->Next())
         f_calc->cboxVehicleType->Properties->Items->AddObject(q->FieldByName("full_name")->AsString.Trim(), (TObject*)q->FieldByName("code")->AsString.ToIntDef(0));
      m_api->dbCloseCursor(res, q);

      // ����
      int year = YearOf(Date());
      for(int i = year; i >= 1900; --i) f_calc->cboxYears->Properties->Items->Add(i);
      for(int i = year; i <= 2100; ++i) f_calc->cboxYearTO->Properties->Items->Add(i);

      // ���
      q = m_api->dbGetCursor(res, "select * from osago_dict_doc_type where deleted=0 order by 1");
      for(q->First(); !q->Eof; q->Next()){
         if(q->FieldByName("is_juridical")->AsInteger){
            f_calc->cboxOwDocTypeJ->Properties->Items->AddObject(q->FieldByName("doc_type")->AsString, (TObject*)q->FieldByName("id_doc_type")->AsInteger);
            f_calc->cboxDocType->Properties->Items->AddObject(q->FieldByName("doc_type")->AsString, (TObject*)q->FieldByName("id_doc_type")->AsInteger);
         }
         else{
            f_calc->cboxDocTypePh->Properties->Items->AddObject(q->FieldByName("doc_type")->AsString, (TObject*)q->FieldByName("id_doc_type")->AsInteger);
            f_calc->cboxOwDocTypeF->Properties->Items->AddObject(q->FieldByName("doc_type")->AsString, (TObject*)q->FieldByName("id_doc_type")->AsInteger);
            f_calc->cboxPrevOwDocType->Properties->Items->AddObject(q->FieldByName("doc_type")->AsString, (TObject*)q->FieldByName("id_doc_type")->AsInteger);
         }
      }
      m_api->dbCloseCursor(res, q);

      f_calc->cboxOwLicenseTypeF->Properties->Items->AddObject("��", (TObject*)17);
      f_calc->cboxOwLicenseTypeF->Properties->Items->AddObject("������������ �����������", (TObject*)24);
      f_calc->cboxOwLicenseTypeF->Properties->Items->AddObject("������������� �����������-���������", (TObject*)39);
      f_calc->cboxOwLicenseTypeF->Properties->Items->AddObject("������������� �����������-��������� ������� �������", (TObject*)40);
      f_calc->cboxOwLicenseTypeF->Properties->Items->AddObject("���� ������������� �� ���������� ��", (TObject*)23);

      f_calc->cboxOwLicenseTypeIP->Properties->Items->AddObject("��", (TObject*)17);
      f_calc->cboxOwLicenseTypeIP->Properties->Items->AddObject("������������ �����������", (TObject*)24);
      f_calc->cboxOwLicenseTypeIP->Properties->Items->AddObject("������������� �����������-���������", (TObject*)39);
      f_calc->cboxOwLicenseTypeIP->Properties->Items->AddObject("������������� �����������-��������� ������� �������", (TObject*)40);
      f_calc->cboxOwLicenseTypeIP->Properties->Items->AddObject("���� ������������� �� ���������� ��", (TObject*)23);

      // ���
      q = m_api->dbGetCursor(res, "select [id], opf from gl_dict_opf_for_auto order by opf");
      for(q->First(); !q->Eof; q->Next()){
         f_calc->cboxOPF->Properties->Items->AddObject(q->FieldByName("opf")->AsString, (TObject*)q->FieldByName("id")->AsInteger);
         f_calc->cboxOwOPF->Properties->Items->AddObject(q->FieldByName("opf")->AsString, (TObject*)q->FieldByName("id")->AsInteger);
      }
      m_api->dbCloseCursor(res, q);

      // ���� ������
      q = m_api->dbGetCursor(res, "select type_id,type_name from osago_dict_pay_type");
      for(q->First(); !q->Eof; q->Next()) f_calc->cboxPaymentType->Properties->Items->AddObject(q->FieldByName("type_name")->AsString, (TObject*)q->FieldByName("type_id")->AsInteger);
      m_api->dbCloseCursor(res, q);
   }
   //---------------------------------------------------------------------------

   /*****/
   void LoadDictsOnlyQuotesDate()
   {
      // ������ ������
      LoadTree(f_calc->tvSaleChannel, 0, 0);

      // ������� �� ��������
      q = m_api->dbGetCursor(res, sql.sprintf("select reg, (nam + ' ' + socr + '.') as reg_name from gl_dict_kt_kladr where act=0 and raion=0 and gorod=0 and punkt=0 and CDate('%s')>=start_date and CDate('%s')<=end_date order by nam", di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next())
         f_calc->RegionComboBoxItem->Properties->Items->AddObject(q->FieldByName("reg_name")->AsString, (TObject*)q->FieldByName("reg")->AsInteger);
      m_api->dbCloseCursor(res, q);

      // ��������� ���
      q = m_api->dbGetCursor(res, sql.sprintf("select * from osago_dict_valid_rsa where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next())
         di->valid_rsa_range.insert(std::make_pair(q->FieldByName("object_name")->AsString, Range(q->FieldByName("min_value")->AsInteger, q->FieldByName("max_value")->AsInteger)));
      m_api->dbCloseCursor(res, q);

      // ���
      q = m_api->dbGetCursor(res, sql.sprintf("select * from osago_dict_bso where CDate('%s')>=start_date and CDate('%s')<=end_date", di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next()){
         if(!q->FieldByName("bso_name")->AsString.IsEmpty()) f_calc->cboxBSOType->Properties->Items->AddObject(q->FieldByName("bso_name")->AsString, (TObject*)q->FieldByName("bso_id")->AsInteger);
         if(!q->FieldByName("bso_series")->AsString.IsEmpty()) f_calc->cboxPolicySeries->Properties->Items->Add(q->FieldByName("bso_series")->AsString);
      }
      m_api->dbCloseCursor(res, q);

      // ��������� ��
      q = m_api->dbGetCursor(res, sql.sprintf("select * from gl_dict_5_4_11 where region_id=%i and CDate('%s')>=start_date and CDate('%s')<=end_date", di->region_id, di->calc_date, di->calc_date));
      for(q->First(); !q->Eof; q->Next()){
         AnsiString address = !q->FieldByName("address")->AsString.IsEmpty() && q->FieldByName("address")->AsString != "������ ����������," ? (" ("  + q->FieldByName("address")->AsString + ")") : empty_str;
         f_calc->cboxOperatorTO->Properties->Items->AddObject(q->FieldByName("oto_pik_name")->AsString + address, (TObject*)q->FieldByName("oto_pik_id")->AsInteger);
      }
      m_api->dbCloseCursor(res, q);
   }
   //---------------------------------------------------------------------------

   /*****/
   void ReloadDictionaries(const SetOfDict& sd, bool reload = true)
   {
      if(sd.Contains(brands)){
         if(reload) ClearBrandsModels();
         ReloadBrands();
      }

      if(sd.Contains(models)){
         if(reload) ClearModels();
         ReloadModels();
      }

      if(sd.Contains(multidrive)) ReloadMultidrive();

      if(sd.Contains(period)) ReloadPeriod();

      if(sd.Contains(payment_doc)) ReloadPaymentDoc();

      if(sd.Contains(area_city_place)) ReloadCityAreaPlace();

      if(sd.Contains(city_place)) ReloadCityPlace();

      if(sd.Contains(place)) ReloadPlace();

      if(sd.Contains(usage_purpose)) ReloadUsagePurpose();

      if(sd.Contains(vehicle_docs)) ReloadVehicleDocs();

      if(sd.Contains(payment_method)) ReloadPaymentMethod();

      if(sd.Contains(payment_scheme)) ReloadPaymentScheme();
   }
   //---------------------------------------------------------------------------
};
//---------------------------------------------------------------------------



#endif
