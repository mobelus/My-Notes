#include "functions.h"
#include "FastStrReplaceUnit.hpp"
//---------------------------------------------------------------------------
AnsiString S(const double& x)
{
   AnsiString t, result;
   result = t.sprintf("%.4f", x);
   int len = result.Length();

   if(result[len] == '0'){
      if(result[len - 1] == '0') result = result.Delete(len - 1, 2);
      else                       result = result.Delete(len, 1);
   }

   return result;
}
//---------------------------------------------------------------------------
AnsiString FormatDigits(const double& x)
{
   AnsiString result = FormatFloat(",0.00;-,0.00", x);
   int len = result.Length();
   if(result[len - 1] == '0' && result[len] == '0') result = result.SubString(1, len - 3);

   return result;
}
//---------------------------------------------------------------------------
AnsiString FloatToSQLStr(const double& f)
{
   return StringReplace(FloatToStr(f), ",", ".", rf);
}
//---------------------------------------------------------------------------
AnsiString FloatToSQLStr(AnsiString s)
{
   if(s.IsEmpty()) return null_str;
   s = StringReplace(s, space_str, empty_str, rf);
   return StringReplace(s, ",", ".", rf);
}
//---------------------------------------------------------------------------
AnsiString StrToFloatStr(const AnsiString& s, const AnsiString& def)
{
   if(s.IsEmpty()) return def;

   AnsiString result = s;
   char c = DecimalSeparator;

   result = StringReplace(result, space_str, empty_str, rf);
   result = StringReplace(result, space_str_nonbreak, empty_str, rf);
   result = StringReplace(result, space_str_long, empty_str, rf);
   result = StringReplace(result, "�.", empty_str, rf);
   result = StringReplace(result, "�,", empty_str, rf);

   if(result.AnsiPos(".")){
      if(c != '.'){
         result = StringReplace(result, ".", ",", rf);
      }
   }
   else if(result.AnsiPos(",")){
      if(c != ','){
         result = StringReplace(result, ",", ".", rf);
      }
   }

   double d;
   if(!TryStrToFloat(result, d)) return def;

   return result;
}
//---------------------------------------------------------------------------
AnsiString FloatToIntStr(const double& f)
{
   AnsiString s = FloatToSQLStr(f);
   int pos = s.Pos(".");
   if(pos > 0) return s.Delete(pos, s.Length() - pos + 1);
   else return s;
}
//---------------------------------------------------------------------------
int CalcYears(const TDateTime& dt1, const TDateTime& dt2)
{
   if(!dt1.Val || !dt2.Val) return 0;

   int y1 = YearOf(dt1),  y2 = YearOf(dt2);
   int m1 = MonthOf(dt1), m2 = MonthOf(dt2);
   int d1 = DayOf(dt1),   d2 = DayOf(dt2);
   int ydif = y2 - y1;
   if(m2 < m1 || (m1 == m2 && d2 < d1)) ydif--;

   return ydif;
}
//---------------------------------------------------------------------------
void ResetChk(TCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void ResetCxChk(TcxCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;

}
//---------------------------------------------------------------------------
void ResetSChk(TsCheckBox* chk, ptr_onclick onclick)
{
   ptr_onclick curr_click;

   if(!onclick) curr_click = chk->OnClick;
   chk->OnClick = 0;
   chk->Checked = false;
   chk->OnClick = !onclick ? curr_click : onclick;
}
//---------------------------------------------------------------------------
void SetValueCheckBox(TCheckBox* chk, const int v, ptr_onclick onclick)
{
   chk->OnClick = 0;
   chk->Checked = v ? true : false;
   chk->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueCxCheckBox(TcxCheckBox* chk, const int v, ptr_onclick onclick)
{
   chk->OnClick = 0;
   chk->Checked = v ? true : false;
   chk->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueEdit(TEdit *edit, const AnsiString& val, ptr_onchange onchange)
{
   edit->OnChange = 0;
   edit->Text = val;
   edit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueCalcEdit(TsCalcEdit* cedit, const double& val, ptr_onchange onchange)
{
   cedit->OnChange = 0;
   cedit->Value = val;
   cedit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void ClearTcxComboBox(TcxComboBox *cbox, ptr_onchange onchange)
{
   cbox->Properties->OnChange = 0;
   cbox->Properties->Items->Clear();
   cbox->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetIndexTcxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange, const int type, const Variant& default_value, const int en_dis)
{
   cbox->Properties->OnChange = 0;
   if(!value.IsNull()){
      cbox->ItemIndex = type ? cbox->Properties->Items->IndexOfObject((TObject*)value.intVal) : cbox->Properties->Items->IndexOf(value);
      if(cbox->ItemIndex == -1 && !default_value.IsNull()){
         cbox->ItemIndex = type ? cbox->Properties->Items->IndexOfObject((TObject*)default_value.intVal) : cbox->Properties->Items->IndexOf(default_value);
         if(cbox->ItemIndex > -1) value = default_value;
         else{
            if(cbox->Properties->Items->Count == 1){
               cbox->ItemIndex = 0;
               if(type) value.intVal = (int)cbox->Properties->Items->Objects[0];
               else value = cbox->Text;
            }
         }
      }
   }
   else cbox->ItemIndex = -1;
   cbox->Properties->OnChange = onchange;

   if(en_dis) cbox->Enabled = !(cbox->Properties->Items->Count == 1 && cbox->ItemIndex == 0);
}
//---------------------------------------------------------------------------
void SetTextTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange)
{
   cbox->Properties->OnChange = 0;
   cbox->Text = value;
   cbox->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValuecxCurrencyEdit(TcxCurrencyEdit *cedit, const Variant& value, ptr_onchange onchange)
{
   cedit->Properties->OnChange = 0;
   cedit->Value =  (!value.IsNull() && !value.IsEmpty()) ? value : 0;
   cedit->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange)
{
   dedit->OnChange = 0;
   if(dt.Val) dedit->Date = dt;
   else dedit->Text = "  .  .    ";
   dedit->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TcxEditorRow *dedit, const TDateTime& val)
{
   if(val.Val) dedit->Properties->Value = val;
   else dedit->Properties->Value = variant_null;
}
//---------------------------------------------------------------------------
void SetValueRowDateEdit(TcxDateEdit *dedit, const TDateTime& val)
{
   if(val.Val) dedit->EditValue = val;
   else dedit->EditValue = variant_null;
}
//---------------------------------------------------------------------------
int GetIndexObject(TStrings* lst, const int& val)
{
   for(int i = 0, cnt = lst->Count; i < cnt; ++i)
      if(((DataDict*)lst->Objects[i])->id == val) return i;

   return -1;
}
//---------------------------------------------------------------------------
int GetIndexItemByTag(TcxRadioGroupItems* items, const int t)
{
   for(int i = 0, cnt = items->Count; i < cnt; ++i)
      if(items->Items[i]->Tag == t) return i;

   return -1;
}
//---------------------------------------------------------------------------
TDateTime CalcEndDateInsur(const TDateTime& start_date, const int srok_month)
{
   if(srok_month > 12) return IncDay(start_date, srok_month - 1);

   Word Year, Month, Day;
   DecodeDate(start_date, Year, Month, Day);
   IncAMonth(Year, Month, Day, srok_month);

   TDateTime dt = EncodeDate(Year, Month, Day);

   return IncDay(dt, -1);
}
//---------------------------------------------------------------------------
AnsiString FirstUpper(const AnsiString& str, const int is_end_to_lower)
{
   if(str.IsEmpty()) return empty_str;

   AnsiString f_up = AnsiString(str[1]).UpperCase();
   return f_up + (is_end_to_lower ? str.SubString(2, str.Length() - 1).LowerCase() : str.SubString(2, str.Length() - 1));
}
//---------------------------------------------------------------------------
AnsiString AddNulls(const AnsiString& str, const int count)
{
   AnsiString result = str;
   int len = str.Length();

   if(len < count) for(int i = 0, end = count - len; i < end; ++i) result = null_str + result;

   return result;
}
//---------------------------------------------------------------------------
AnsiString ClearPhoneNumber(const AnsiString& str)
{
   AnsiString result(""), curr("");
   int i_val;

   for(int i = 1, l = str.Length(); i <= l; ++i){
      curr = AnsiString(str[i]);
      if(TryStrToInt(curr, i_val)) result += curr;
   }

   return result;
}
//---------------------------------------------------------------------------
void FilterDataSet(TADOQuery *qq, const AnsiString& filter)
{
   qq->Filtered = false;
   qq->Filter   = filter;
   qq->Filtered = true;
}
//---------------------------------------------------------------------------
void FilterDataSet(TClientDataSet *qq, const AnsiString& filter)
{
   qq->Filtered = false;
   qq->Filter   = filter;
   qq->Filtered = true;
}
//---------------------------------------------------------------------------
bool CheckIdentNumber(const AnsiString& ident_number)
{
   if(ident_number.Length()){
      if(ident_number.Pos("E")) return true;

      double d(0.0);
      if(TryStrToFloat(ident_number, d)){
         if((int)d == 0) return false;
         else return true;
      }
      else return true;
   }

   return false;
}
//---------------------------------------------------------------------------
bool CheckVIN(const AnsiString& vin) // http://www.vinfax.ru/about.html
{
   if(vin.Length() != 17) return false;
   int i_val;
   if(!TryStrToInt(vin.SubString(14, 4), i_val)) return false;

   for(int i = 1; i < 14; i++){
      if(!((vin[i] >= '0' && vin[i] <= '9') || (vin[i] >= 'A' && vin[i] <= 'Z'))) return false;
      if(vin[i] == 'I' || vin[i] == 'O' || vin[i] == 'Q')                         return false;
   }

   return true;
}
//---------------------------------------------------------------------------
bool CheckRegPlate(const AnsiString& rgpl)
{
   if(rgpl.Length() < 8) return false;

   for(int i = 1; i < 7; i++) if(reg_plate_possible.AnsiPos(rgpl.SubString(i, 1)) == 0) return false;

   return true;
}
//---------------------------------------------------------------------------
AnsiString NodeToStr(_di_IXMLNode node)
{
   if(node) return AnsiString(node->Text).Trim();
   return empty_str;
}
//---------------------------------------------------------------------------
AnsiString NormVIN_GN(mops_api_025 *m_api, const AnsiString& numb)
{
   int res;
   AnsiString st = m_api->Normalization_String_RSA(res, numb), st_eng("ETYOPKHAXCBM"), st_rus("������������");

   for(int i = 1, l = st_rus.Length() + 1; i < l; i++) st = StringReplace(st, st_rus[i], st_eng[i], rf);

   return st;
}
//---------------------------------------------------------------------------
void SeparateFIO(const AnsiString& fio, const int status, AnsiString& lname, AnsiString& fname, AnsiString& sname)
{
   lname = fname = sname = empty_str;
   if(status > 0) { lname = fio; return; }

   int pos(0);
   pos = fio.Pos(space_str);
   if(pos){
      lname = fio.SubString(1, pos).Trim();
      AnsiString temp_str = fio.Delete(1, pos);
      pos = temp_str.Pos(space_str);
      if(pos){
         fname = temp_str.SubString(1, pos).Trim();
         sname = temp_str.Delete(1, pos).Trim();
      }
      else fname = temp_str.Delete(1, pos).Trim();
   }
}
//---------------------------------------------------------------------------
void MakeKladrAddrFromARM(mops_api_028 *_m_api, _di_IXMLNode child_node, TStringList *addr, int& memo_id)
{
   int res;

   addr->Clear();
   memo_id = 0;
   AnsiString code_kladr = NodeToStr(child_node->ChildNodes->FindNode("KLADR_STREET_CODE"));
   if(code_kladr.IsEmpty()) return;

   addr->Values["��� �����"] = code_kladr;
   addr->Values["������"] = NodeToStr(child_node->ChildNodes->FindNode("ZIP"));
   addr->Values["���"] = NodeToStr(child_node->ChildNodes->FindNode("HOUSE_NUMBER"));
   addr->Values["������/��������"] = "�";
   addr->Values["����� �������"] = NodeToStr(child_node->ChildNodes->FindNode("BUILDING"));
   addr->Values["��������"] = NodeToStr(child_node->ChildNodes->FindNode("FLAT"));

   _m_api->KLADR_Try_Address_to_KLADR(res, addr);

   AnsiString memo_text = addr->Text;
   _m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "casco_memo");
}
//---------------------------------------------------------------------------
void MakeKladrAddrFromUXML(mops_api_028 *_m_api, _di_IXMLNode person, TStringList *addr, int& memo_id, AnsiString& exact_address)
{
   int res;

   AnsiString code_kladr = NodeToStr(person->ChildNodes->FindNode("street_id"));
   if(code_kladr.IsEmpty()){

      code_kladr = NodeToStr(person->ChildNodes->FindNode("place_id"));
      if(code_kladr.IsEmpty()) code_kladr = NodeToStr(person->ChildNodes->FindNode("city_id"));
      if(code_kladr.IsEmpty()) code_kladr = NodeToStr(person->ChildNodes->FindNode("area_id"));
      if(code_kladr.IsEmpty()) code_kladr = NodeToStr(person->ChildNodes->FindNode("region_id"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("exact_address"));

      if(code_kladr.IsEmpty()) return;
      addr->Values["������"] = NodeToStr(person->ChildNodes->FindNode("region"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("area"));
      addr->Values["�����"] = NodeToStr(person->ChildNodes->FindNode("place"));
   }

   addr->Values["��� �����"] = code_kladr;

   addr->Values["������"] = NodeToStr(person->ChildNodes->FindNode("zip"));
   addr->Values["���"] = NodeToStr(person->ChildNodes->FindNode("house"));
   addr->Values["������/��������"] = "�";
   addr->Values["����� �������"] = NodeToStr(person->ChildNodes->FindNode("building"));
   addr->Values["��������"] = NodeToStr(person->ChildNodes->FindNode("flat"));

   _m_api->KLADR_Try_Address_to_KLADR(res, addr);

   AnsiString memo_text = addr->Text;
   _m_api->dbReadWriteInternalMemo(res, memo_text, memo_id, false, "osago_memo");

   exact_address = _m_api->KLADR_Get_Print_Address_By_Separated(res, addr);
}
//---------------------------------------------------------------------------
bool CheckAddrList(TStringList* addrlist)
{
   if(addrlist->Text.IsEmpty()) return false;

   if(addrlist->Count == 1 && addrlist->IndexOfName("������") > -1) return false;

   return true;
}
//---------------------------------------------------------------------------
RussoFieldName::RussoFieldName()
{
   insert(std::make_pair("ts_cost", " - �������������� ���������."));
   insert(std::make_pair("str_summa", " - ��������� �����."));
   insert(std::make_pair("allowed_mass", " - ����������� max �����."));
   insert(std::make_pair("number_of_seats", " - ����� ������������ ����."));
   insert(std::make_pair("pay_id", " - ������ ���������� ������."));
   insert(std::make_pair("franshize_id", " - ��� ��������."));
   insert(std::make_pair("franshize_size", " - ������ ����������� ��������."));
   insert(std::make_pair("franshize_unit", " - �������� ����������� ��������."));
   insert(std::make_pair("usage_purpose", " - ���� �������������."));
   insert(std::make_pair("ka", " - �����-� ������������."));
   insert(std::make_pair("ks", " - �����-� ��������."));
   insert(std::make_pair("risk_id", " - �������� ���� �� ��������."));
   insert(std::make_pair("multidrive", " - ��� ������������."));
   insert(std::make_pair("payments_count", "�� ��������.\r\n - ���������� ��������."));

   //dsago_liability
   //ns_liability
}
//---------------------------------------------------------------------------
SkkQuery::SkkQuery()
{
   insert(std::make_pair("5.4.11", TblQue("select * from apo.oto_5_4_11_for_osago", "gl_dict_5_4_11", false)));
   insert(std::make_pair("7.6.40", TblQue("select * from apo.kt_kladr_7_6_40", "gl_dict_kt_kladr", false)));
   insert(std::make_pair("7.10.17", TblQue("select * from apo.eosago_buyers_7_10_17", "gl_dict_eosago_buyers", false)));
}
//---------------------------------------------------------------------------
MaskDocType::MaskDocType(const int type)
{
   switch(type){
      case 1:
         insert(std::make_pair(2,  InputMask("[A-Za-z�-��-�]{2}", "[0-9]{6}")));
         insert(std::make_pair(5,  InputMask("[A-Za-z�-��-�]{2}", "[0-9]{7}", 1)));
         insert(std::make_pair(6,  InputMask("[0-9]{2}", "[0-9]{7}")));
         insert(std::make_pair(7,  InputMask("", "", 0, 25)));
         insert(std::make_pair(12, InputMask("[0-9]{2}' '[0-9]{2}", "[0-9]{6}"))); //[0-9]{2}\s[0-9]{2}
         insert(std::make_pair(13, InputMask("[0-9]{2}", "[0-9]{7}")));
         insert(std::make_pair(15, InputMask("[A-Za-z�-��-�]{2}", "[0-9]{7}", 1)));
         insert(std::make_pair(17, InputMask("[0-9]{2}' '[0-9]{2}|[0-9]{2}' '[ABCDEHKMOPTXYabcdehkmnoptxy��������������������������]{2}", "[0-9]{6}")));
         insert(std::make_pair(21, InputMask("[0-9]{2}", "[0-9]{9}")));
         insert(std::make_pair(23, InputMask("", "", 0, 20)));
         insert(std::make_pair(24, InputMask("", "", 0, 20)));
         insert(std::make_pair(25, InputMask("[0-9]{2}", "[0-9]{9}")));
         insert(std::make_pair(29, InputMask("[0-9]{2}", "[0-9]{9}")));
         insert(std::make_pair(39, InputMask("", "", 0, 20)));
         insert(std::make_pair(40, InputMask("", "", 0, 20)));
         break;
      case 2:
         insert(std::make_pair(1, InputMask("[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}", "[0-9]{6}")));
         insert(std::make_pair(2, InputMask("[0-9]{4}|[0-9]{2}[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{2}|[ABCDEFGHJKLMNPRSTUVWXYZabcdefghjklmnprstuvwxyz�-��-���]{3}", "[0-9]{6}")));
         insert(std::make_pair(3, InputMask("", "")));
         insert(std::make_pair(4, InputMask("", "")));
         insert(std::make_pair(5, InputMask("", "")));
         insert(std::make_pair(6, InputMask("", "")));
         insert(std::make_pair(7, InputMask("", "")));
         insert(std::make_pair(8, InputMask("", "")));
         insert(std::make_pair(9, InputMask("", "")));
         insert(std::make_pair(10,InputMask("", "")));
         insert(std::make_pair(11,InputMask("", "")));
         break;
   }
}
//---------------------------------------------------------------------------
void ChangeMask(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
void ChangeMaskLicense(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].license_series = v1;
   p_pi[index].license_number = v2;

   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].license_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].license_type].max_length;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].license_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].license_type].max_length;
}
//---------------------------------------------------------------------------
void ChangeMaskPrev(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].prev_doc_seria  = v1;
   p_pi[index].prev_doc_number = v2;

   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].prev_doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].prev_doc_type].max_length;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].prev_doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].prev_doc_type].max_length;
}
//---------------------------------------------------------------------------
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].doc_seria  = v1;
   p_pi[index].doc_number = v2;

   r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].doc_type].max_length;

   r_DocNumber->Properties->Value   = v2;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].doc_type].max_length;
}
//---------------------------------------------------------------------------
void ChangeMaskLicense(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1, const AnsiString& v2)
{
   p_pi[index].prev_doc_seria  = v1;
   p_pi[index].prev_doc_number = v2;

   r_DocSeria->Properties->Value = StringReplace(v1, space_str, empty_str, rf);
   DocSeria->Properties->EditMask   = mask_doc_type[p_pi[index].prev_doc_type].mask_series;
   DocSeria->Properties->MaxLength  = mask_doc_type[p_pi[index].prev_doc_type].max_length;

   r_DocNumber->Properties->Value   = v2;
   DocNumber->Properties->EditMask  = mask_doc_type[p_pi[index].prev_doc_type].mask_number;
   DocNumber->Properties->MaxLength = mask_doc_type[p_pi[index].prev_doc_type].max_length;

   r_DocSeria->Properties->Options->Editing = p_pi[index].prev_doc_type > 0;
   r_DocNumber->Properties->Options->Editing = p_pi[index].prev_doc_type > 0;
}
//---------------------------------------------------------------------------
AnsiString MobileToMask(const AnsiString& ph_mob)
{
//"9268692304"
//"89268692304"
// 123456789
//"+79600022762"

//"+7(920)601-69-79"

   if(ph_mob.IsEmpty()) return empty_str;

   AnsiString result("");
   int len = ph_mob.Length();

   if(len == 12 && ph_mob.SubString(1, 2) == "+7"){
      result = ph_mob.Insert("-", 11);
      result = result.Insert("-", 9);
      result = result.Insert(")", 6);
      result = result.Insert("(", 3);
      return result;
   }

   if(len == 10 && ph_mob.SubString(1, 1) == "9"){
      result = ph_mob.Insert("-", 9);
      result = result.Insert("-", 7);
      result = result.Insert(")", 4);
      result = result.Insert("+7(", 1);
      return result;
   }

   if(len == 11 && (ph_mob.SubString(1, 1) == "8" || ph_mob.SubString(1, 1) == "7")){
      result = ph_mob.Insert("-", 10);
      result = result.Insert("-", 8);
      result = result.Insert(")", 5);
      result = result.Delete(1, 1);
      result = result.Insert("+7(", 1);
      return result;
   }

   return result;
}
//---------------------------------------------------------------------------
void GetPhones(_di_IXMLNode contacts, AnsiString& ph_mob, AnsiString& ph_home, AnsiString& ph_rab, AnsiString& email, int &sms)
{
   sms = -1;
   for(int i = 0, cnt = contacts->ChildNodes->Count, i_val = 0; i < cnt; ++i){
      _di_IXMLNode child_node = contacts->ChildNodes->Get(i);
      if(child_node->HasAttribute("contact_type_id") && TryStrToInt(child_node->Attributes["contact_type_id"], i_val)){
         switch(i_val){
            case 1:
               if(child_node->HasAttribute("contract_data")) ph_home = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data"))  ph_home = child_node->Attributes["contact_data"];
               break;
            case 2:
               if(child_node->HasAttribute("contract_data")) ph_rab = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data"))  ph_rab = child_node->Attributes["contact_data"];
               break;
            case 3:
               if(child_node->HasAttribute("contract_data")) ph_mob = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data")) ph_mob = child_node->Attributes["contact_data"];
               if(child_node->HasAttribute("spam")) sms = AnsiString(child_node->Attributes["contact_data"]).ToIntDef(-1);
               break;
            case 5:
               if(child_node->HasAttribute("contract_data")) email = child_node->Attributes["contract_data"];
               else if(child_node->HasAttribute("contact_data")) email = child_node->Attributes["contact_data"];
               break;
         }
      }
   }
}
//---------------------------------------------------------------------------
AnsiString IntToBin(const int ANumber, int ABitCount)
{
   ABitCount = (ABitCount < 1) ? 1 : ((ABitCount > 32) ? 32 : ABitCount);

   AnsiString Result("", ABitCount);

   for(int i = ABitCount, Mask = 1; i >= 1; i--, Mask <<= 1) Result[i] = (ANumber & Mask) ? '1' : '0';

   return Result;
}
//---------------------------------------------------------------------------
void PmDataToRecord(TADOQuery* q_perm, PersonInfo *pm, const int calc_id, const int num, const int i, const int pm_status)
{
   q_perm->FieldByName("calc_id")->Value = calc_id;
   q_perm->FieldByName("status")->Value = 0;
   q_perm->FieldByName("type_person")->Value = num + 4;
   q_perm->FieldByName("first_name")->Value = pm[i].firstname;
   q_perm->FieldByName("prev_first_name")->Value = pm[i].prev_firstname;
   q_perm->FieldByName("second_name")->Value = pm[i].secondname;
   q_perm->FieldByName("last_name")->Value = pm[i].lastname;
   q_perm->FieldByName("prev_last_name")->Value = pm[i].prev_lastname;
   q_perm->FieldByName("phisical_birth_date")->Value = pm[i].birthdate;
   q_perm->FieldByName("phisical_sex")->Value = pm[i].sex;
   q_perm->FieldByName("age")->Value = pm[i].age;
   q_perm->FieldByName("experience")->Value = pm[i].experience;
   q_perm->FieldByName("document_type_id")->Value = pm[i].doc_type;
   q_perm->FieldByName("document_series")->Value = pm[i].doc_seria;
   q_perm->FieldByName("document_number")->Value = pm[i].doc_number;
   q_perm->FieldByName("document_issue_date")->Value = pm[i].doc_issue_date;
   q_perm->FieldByName("kvs")->Value = pm[i].kvs;
   q_perm->FieldByName("kbm")->Value = pm[i].kbm;
   q_perm->FieldByName("rsa_id")->Value = pm[i].kbm_info.rsa_id;
   q_perm->FieldByName("prev_document_type_id")->Value = pm[i].prev_doc_type;
   q_perm->FieldByName("prev_document_series")->Value = pm[i].prev_doc_seria;
   q_perm->FieldByName("prev_document_number")->Value = pm[i].prev_doc_number;
   q_perm->FieldByName("prev_document_issue_date")->Value = pm[i].prev_doc_issue_date;
   q_perm->FieldByName("prev_document_end_date")->Value = pm[i].prev_doc_end_date;
   q_perm->FieldByName("kbm_class")->Value = pm[i].kbm_info.kbm_class;
   q_perm->FieldByName("kbm_error")->Value = pm[i].kbm_info.kbm_error;
   q_perm->FieldByName("kbm_message")->Value = pm[i].kbm_info.kbm_message;
   q_perm->FieldByName("kbm_error_code")->Value = pm[i].kbm_info.kbm_error_code;
   q_perm->FieldByName("kbm_message_code")->Value = pm[i].kbm_info.kbm_message_code;
   q_perm->FieldByName("prev_policy_company")->Value = pm[i].kbm_info.prev_policy_company;
   q_perm->FieldByName("prev_policy_series")->Value = pm[i].kbm_info.prev_policy_series;
   q_perm->FieldByName("prev_policy_number")->Value = pm[i].kbm_info.prev_policy_number;
   q_perm->FieldByName("loss_amount")->Value = pm[i].kbm_info.loss_amount;
   q_perm->FieldByName("person_bad")->Value = pm[i].person_bad;
   q_perm->FieldByName("is_added")->Value = pm[i].is_added;
   q_perm->FieldByName("is_removed")->Value = pm[i].is_removed;
   q_perm->FieldByName("permitted_added_date")->Value = pm[i].permitted_added_date;
}
//---------------------------------------------------------------------------
bool FieldValueIDToVGEditor(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row)
{
   int index = cboxitem->Properties->Items->IndexOfObject((TObject*)fv);
   if(index > -1) row->Properties->Value = cboxitem->Properties->Items->Strings[index];
   else row->Properties->Value = variant_null;

   return index > -1;
}
//---------------------------------------------------------------------------
bool FieldValueIDToVGEditor_(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row)
{
   int index = GetIndexObject(cboxitem->Properties->Items, fv);
   if(index > -1) row->Properties->Value = cboxitem->Properties->Items->Strings[index];
   else row->Properties->Value = variant_null;

   return index > -1;
}
//---------------------------------------------------------------------------
int GetDrvCount(TADOQuery *qq)
{
   qq->Filtered = false;
   qq->Filter   = "[type_person] > 3";
   qq->Filtered = true;

   int drv_count = qq->RecordCount;

   qq->Filtered = false;

   return drv_count;
}
//---------------------------------------------------------------------------
int GetCountPermitted(TListView *gridDopush)
{
   int count_permitted(0);

   for(int i = 0, cnt = gridDopush->Items->Count; i < cnt; ++i) if(gridDopush->Items->Item[i]->Checked) ++count_permitted;

   return count_permitted;
}
//---------------------------------------------------------------------------
int MonthsCount(const TDateTime& ANow, const TDateTime& AThen)
{
   int ACount;
   for(ACount = 1; ACount < 13; ++ACount) if(IncMonth(ANow, ACount) > AThen) return ACount;
   return ACount;
}
//---------------------------------------------------------------------------
int DaysCount(const TDateTime& ANow, const TDateTime& AThen)
{
   int ACount;
   for(ACount = 1; ACount < 27; ++ACount) if(IncDay(ANow, ACount) > AThen) return ACount;

   return 0;
}
//---------------------------------------------------------------------------
void VariantToDate(Variant v, TDateTime& dt)
{
   AnsiString dt_str("");

   if(!v.IsNull()){
      dt_str = v;
      if(dt_str.Length() < 10 || !TryStrToDate(dt_str, dt)) dt.Val = 0;
   }
   else dt.Val = 0;
}
//---------------------------------------------------------------------------
void UpdateOneField(TADOQuery *qq, const AnsiString& fieldname, const Variant& value)
{
   for(qq->First(); !qq->Eof; qq->Next()){
      qq->Edit();
      qq->FieldByName(fieldname)->Value = value;
      qq->Post();
   }
}
//---------------------------------------------------------------------------
void UpdateOneField(TClientDataSet *qq, const AnsiString& fieldname, const Variant& value)
{
   for(qq->First(); !qq->Eof; qq->Next()){
      qq->Edit();
      qq->FieldByName(fieldname)->Value = value;
      qq->Post();
   }
}
//---------------------------------------------------------------------------
void SetEnterInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetValueEdit(edit, empty_str, onchange);
      edit->Font->Color = clBlack;
   }
}
//---------------------------------------------------------------------------
void ExitFromEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetValueEdit(edit, edit->Hint, onchange);
      edit->Font->Color = clSilver;
   }
}
//---------------------------------------------------------------------------
void SetEnterInComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetTextTocxComboBox(cbox, empty_str, onchange);
      cbox->Style->Font->Color = clBlack;
   }
}
//---------------------------------------------------------------------------
void ExitFromComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange)
{
   if(str.IsEmpty()){
      SetTextTocxComboBox(cbox, cbox->Hint, onchange);
      cbox->Style->Font->Color = clSilver;
   }
}
//---------------------------------------------------------------------------
void SetEnterInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit)
{
   if(str.IsEmpty()){
      edit->Text = empty_str;
      edit->Style->TextColor = clBlack;
   }
}
//---------------------------------------------------------------------------
void ExitFromButtonEditBox(const AnsiString& str, TcxButtonEdit *edit)
{
   if(str.IsEmpty()){
      edit->Text = edit->Hint;
      edit->Style->TextColor = clSilver;
   }
}
//---------------------------------------------------------------------------
void SetTextAndColorInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange)
{
   SetValueEdit(edit, str.IsEmpty() ? edit->Hint : str, onchange);
   edit->Font->Color = str.IsEmpty() ? clSilver : clBlack;
}
//---------------------------------------------------------------------------
void SetTextAndColorInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit)
{
   edit->Text = str.IsEmpty() ? edit->Hint : str;
   edit->Style->TextColor = str.IsEmpty() ? clSilver : clBlack;
}
//---------------------------------------------------------------------------
void SetValueAndHintInDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange, TStaticText *hint)
{
   SetValueDateEdit(dedit, dt, onchange);
   hint->Visible = !dt.Val;
}
//---------------------------------------------------------------------------
void SetValueAndHintInMaskEdit(TcxMaskEdit* edit, const AnsiString& str, ptr_onchange onchange, TStaticText *hint)
{
   edit->Properties->OnChange = 0;
   edit->Text = str;
   edit->Properties->OnChange = onchange;
   if(hint) hint->Visible = str.IsEmpty();
}
//---------------------------------------------------------------------------
void SetIndexAndHintIncxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange, const int type, TStaticText *hint)
{
   SetIndexTcxComboBox(cbox, value, onchange, type);
   hint->Visible = cbox->ItemIndex == -1;
}
//---------------------------------------------------------------------------
void SetIndexTocxRadioGroup(TcxRadioGroup *rg, const int index, ptr_onclick onclick)
{
   rg->OnClick = 0;
   rg->ItemIndex = index;
   rg->OnClick = onclick;
}
//---------------------------------------------------------------------------
void SetValueTocxLookupComboBox(TcxLookupComboBox *cbox, const Variant& value, ptr_oneditvaluechanged oneditvaluechanged)
{
   cbox->Properties->OnEditValueChanged = 0;
   cbox->EditValue = value;
   cbox->Properties->OnEditValueChanged = oneditvaluechanged;
}
//---------------------------------------------------------------------------
void SetHeightsToPcAndGb(TcxPageControl *pc, TglGroupBox *gb, Dogovor_Info *di)
{
   int index_x = pc->Tag, index_y = pc->ActivePage->PageIndex;
   gb->Height = heights[index_x][index_y];
   pc->Height = heights[index_x + 1][index_y];
}
//---------------------------------------------------------------------------
void SetActivePageTocxPageControl(TcxPageControl *pc, TcxTabSheet *sh, ptr_onchange onchange)
{
   pc->OnChange = 0;
   pc->ActivePage = sh;
   pc->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetPageControls(TcxPageControl *pc_calc, TcxPageControl *pc, const int no_change, ptr_onchange onchange)
{
   int pi = pc_calc->ActivePage->PageIndex;
   if(no_change) pc->OnChange = 0;
   pc->Pages[pi]->TabVisible = true;
   for(int i = 0; i < 3; ++i) if (i != pi) pc->Pages[i]->TabVisible = false;
   if(no_change) pc->OnChange = onchange;
}
//---------------------------------------------------------------------------
void SetTextAndColorTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange)
{
   SetTextTocxComboBox(cbox, value, onchange);
   if(!value.IsEmpty()) cbox->Style->Font->Color = clBlack;
}
//---------------------------------------------------------------------------
AnsiString ReservToStr(const std::set<int>& s)
{
   AnsiString result("");
   for(std::set<int>::iterator iter = s.begin(); iter != s.end(); ++iter)
      result = result + " and reservation_id_3<>" + IntToStr(*iter);

   return result;
}
//---------------------------------------------------------------------------
void SetValuecxSpinEdit(TcxSpinEdit *spinedit, const double& value, ptr_onchange onchange, ptr_onvalidate onvalidate)
{
   spinedit->Properties->OnChange = 0;
   spinedit->Properties->OnEditValueChanged = 0;
   spinedit->Value = value;
   spinedit->Properties->OnChange = onchange;
   spinedit->Properties->OnValidate = onvalidate;
}
//---------------------------------------------------------------------------
void LoadDataCurrentUser(mops_api_028 *m_api, Dogovor_Info *p_di)
{
   int res;
   
   TADOQuery *q = m_api->dbGetCursor(res, "select name,lnr,skk,mobile_phone,sale_channel_type2008_id,arm_agent_id,office_id from _mops_polzovateli_ where id=" + IntToStr(p_di->user_info.user_id));

   p_di->user_info.name      = q->FieldByName("name")->AsString;
   p_di->user_info.phone     = q->FieldByName("mobile_phone")->AsString;
   p_di->user_info.skk       = q->FieldByName("skk")->AsString;
   p_di->user_info.lnr       = q->FieldByName("lnr")->AsString;
   p_di->user_info.agent_id  = q->FieldByName("arm_agent_id")->AsString;
   p_di->user_info.office_id = q->FieldByName("office_id")->AsInteger;

   p_di->user_info.sale_channel_id = q->FieldByName("sale_channel_type2008_id")->AsInteger;

   if(!q->FieldByName("skk")->AsString.IsEmpty()){
      mops_api_028 *branch_api = (mops_api_028*)m_api->glDic_Get_API(res, "���������� �������������/������");
      TADOQuery *q_branches = branch_api->dbGetCursor(res, "select * from branches where branch_code='" + q->FieldByName("skk")->AsString + "'");
      p_di->user_info.osp = q_branches->FieldByName("full_name")->AsString;
      if(q_branches->FindField("address")) p_di->user_info.osp_address = q_branches->FieldByName("address")->AsString;
      branch_api->dbCloseCursor(res, q_branches);
      //select * from branches where branch_code='27802000'
      q_branches = branch_api->dbGetCursor(res, "select * from branches where branch_code='" + q->FieldByName("skk")->AsString.SubString(1, 3) +  "09000'");
      p_di->user_info.filial = q_branches->FieldByName("full_name")->AsString.Delete(1, 25);
      if(q_branches->FindField("address")) p_di->user_info.filial_address = q_branches->FieldByName("address")->AsString;
      branch_api->dbCloseCursor(res, q_branches);

      p_di->user_info.office_type = branch_api->dbGetStringFromQuery(res, "select officetype from offices where officeid=" + IntToStr(p_di->user_info.office_id)) == office_sa ? 1 : 0;
   }
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void MakeExportFilters(TSaveDialog *sd, Dogovor_Info *di, Map_Int_Str &filter)
{
   if(di->is_msoff){
      sd->Filter = "Excel|*.xls";
      filter[1] = "XLS";
   }
   if(di->is_opoff){
      if(di->is_msoff){
         sd->Filter += "|";
         filter[2] = "ODS";
      }
      else filter[1] = "ODS";
      sd->Filter += "OpenOffice(LibreOffice)|*.ods";
      if(di->is_msoff) sd->FilterIndex = 2;
   }
}
//---------------------------------------------------------------------------
AnsiString Translit_Text(const AnsiString& source, const int rus_lat)
{
   AnsiString result = source;

   for(int i = 0; i < 12; ++i) result = FastStringReplace(result, rus_lat ? table_lat[i] : table_rus[i], rus_lat ? table_rus[i] : table_lat[i], rf);

   return result;
}
//---------------------------------------------------------------------------
void SetValueRadioButton(TRadioButton *rb, const int v, ptr_onclick onclick)
{
   rb->OnClick = 0;
   rb->Checked = v;
   rb->OnClick = onclick;
}
//---------------------------------------------------------------------------
void CreatePDF(mops_api_028 *m_api, AnsiString doc, TMemoryStream *pdf_file)
{
   int res;
   long buff_size = doc.Length();
   byte *buff;
   m_api->Internal_String2Buff(res, &doc, &buff, &buff_size);
   pdf_file->Clear();
   pdf_file->WriteBuffer(buff, buff_size);
   delete [] buff; buff = 0;
   pdf_file->Position = 0;
}
//---------------------------------------------------------------------------
AnsiString NodeAttributeToStr(_di_IXMLNode node, const AnsiString& name, const AnsiString& value)
{
   if(node->HasAttribute(name)) return AnsiString(node->Attributes[value]);
   return empty_str;
}
//---------------------------------------------------------------------------
AnsiString ClearStr(const AnsiString& str)
{
   AnsiString result("");

   for(int i = 1, l = str.Length(); i <= l; ++i)
      if(!str.IsDelimiter(not_filename, i)) result += str[i];

   //if(str.Length())
   return result;
}
//---------------------------------------------------------------------------
int GetVehicleGroup(mops_api_028 *m_api, const int vehicle_type_id, const AnsiString& rsa_code, const int allowed_mass, const int number_of_seats, const AnsiString& calc_date)
{
   int res;
   AnsiString sql("");

   if(vehicle_type_id < 5)
      return m_api->dbGetStringFromQueryDef(res, sql.sprintf("select top 1 gruppa_ts from gl_dict_model_po_gruppam where id_ts='%s' and ((min_massa<=%i and max_massa>=%i) or (min_massa=0 and max_massa=0)) and ((min_col_m<=%i and max_col_m>=%i) or (min_col_m=0 and max_col_m=0)) and CDate('%s')>=start_data and CDate('%s')<=end_data order by min_massa desc, min_col_m desc", rsa_code, allowed_mass, allowed_mass, number_of_seats, number_of_seats, calc_date, calc_date), "-1").ToInt();

   else{
      if(vehicle_type_id == 7) return 11; //�����������
      else if(vehicle_type_id >= 8 && vehicle_type_id <= 10) return 10; // �������
   }

   return -1;
}
//---------------------------------------------------------------------------
__int64 FileSize(const AnsiString& fn)
{
   TFileStream *fs = new TFileStream(fn, fmOpenRead);
   __int64 filesize = fs->Size;
   delete fs;

   return filesize;
}
//---------------------------------------------------------------------------
AnsiString VariantToStr(const Variant& v)
{
   if(v.IsEmpty() || v.IsNull()) return empty_str;

   return AnsiString(v).Trim();
}
//---------------------------------------------------------------------------
void SetPosAndParentToPanel(TWinControl *parent, TPanel *panTop, TPanel *panDown)
{
   panDown->Align = alNone;
   panDown->Top = 1000;
   panTop->Parent = parent;
   panDown->Align = alTop;
}
//---------------------------------------------------------------------------
void SetValuecxButtonEdit(TcxButtonEdit *cbtnedit, const AnsiString& str, ptr_onchange onchange)
{
   cbtnedit->Properties->OnChange = 0;
   cbtnedit->Text = str;
   cbtnedit->Properties->OnChange = onchange;
}
//---------------------------------------------------------------------------
AnsiString CreateCorrelationId()
{
   GUID guid;
   CreateGUID(guid);

   return /*"synthetic_" + */GUIDToString(guid).LowerCase().SubString(2, 36);
}
//---------------------------------------------------------------------------
bool Is8Symbols(const AnsiString& str)
{
   if(str.IsEmpty()) return false;

   int count8(1);

   for(int i = 1, l = str.Length(); i <= l; ++i){
      if(count8 == 8) return true;
      if(i < l){
         if(str[i] == str[i + 1]) ++count8;
         else count8 = 1;
      }
   }
   return false;
}
//---------------------------------------------------------------------------
void SetAlignAndTop(TControl *cntrl, const TAlign& algn, const int t)
{
   cntrl->Align = algn;
   cntrl->Top = t;
}
//---------------------------------------------------------------------------

