   /*error->Text = m_api->Err_Get_Calc_Errors_By_Type_RT(res, err_all, this);
   int is_error = error->Count;

   if(is_error) SetRedFrameOnCurrentError();
   else{
      errShape->Visible = false;
   } */

   //AnsiString s = m_api->Err_Get_Calc_Errors_By_Type_RT(res, err_calc, this);

   
   void TframeCalc::SetRedFrameOnCurrentError()
{
   AnsiString curr_error = m_api->Err_Get_Shown_Error_Text(res, this);

   if(curr_error == "Необходимо произвести расчет(перерасчет премии)" || curr_error == "Тариф действителен только в течении 14 дней." || curr_error == "Текущая дата на вашем компьютере лежит вне интервала даты серверов системы РОСГОССТРАХ!" || curr_error.Pos("Сервис расчета UFO вернул следующие ошибки валидации:") || curr_error.Pos("Oracle Insbridge вернул следующие ошибки расчета:") || curr_error.Pos("Сервис расчета UFO вернул системную ошибку:")){
      errShape->Visible = false;
      return;
   }

   if(curr_error == "Не указан регион заключения договора") SetPosAndParentRedFrame(TRect(248, 6, 739, 35), panHead);
   if(curr_error.Pos("Расширение территории")) SetPosAndParentRedFrame(TRect(249, 34, 547, 53), panHead);
   if(curr_error == "Не указан банк") SetPosAndParentRedFrame(TRect(248, 101, 739, 130), panHead);

   if(curr_error == "Не указана фамилия страхователя") SetPosAndParentRedFrame(TRect(150, 26, 344, 52), pcInsuredType->ActivePage);
   if(curr_error == "Не указано имя страхователя") SetPosAndParentRedFrame(TRect(342, 26, 536, 52), pcInsuredType->ActivePage);
   //if(curr_error == "Не указано отчество страхователя") SetPosAndParentRedFrame(TRect(534, 26, 728, 52), pcInsuredType->ActivePage);
   if(curr_error == "Не указана дата рождения страхователя") SetPosAndParentRedFrame(TRect(150, 60, 726, 86), pcInsuredType->ActivePage);
   if(curr_error == "Не указано наименование организации-страхователя") SetPosAndParentRedFrame(TRect(280, 26, 727, 52), pcInsuredType->ActivePage);
   if(curr_error == "Не указана серия документа страхователя") SetPosAndParentRedFrame(TRect(150, 124, 211, 150), pcInsuredType->ActivePage);
   if(curr_error == "Не указан номер документа страхователя") SetPosAndParentRedFrame(TRect(214, 124, 318, 150), pcInsuredType->ActivePage);
   if(curr_error == "Не указана дата выдачи документа страхователя") SetPosAndParentRedFrame(TRect(321, 124, 507, 150), pcInsuredType->ActivePage);
   if(curr_error == "Не указан код подразделения документа страхователя") SetPosAndParentRedFrame(TRect(512, 124, 727, 150), pcInsuredType->ActivePage);
   if(curr_error == "Не указано кем выдан документ страхователю") SetPosAndParentRedFrame(TRect(150, 151, 728, 177), pcInsuredType->ActivePage);
   if(curr_error == "Не указан адрес регистрации страхователя") SetPosAndParentRedFrame(TRect(150, 190, 728, 220), pcInsuredType->ActivePage);
   if(curr_error == "Не указано гражданство страхователя") SetPosAndParentRedFrame(TRect(150, 230, 728, 259), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ИНН страхователя") SetPosAndParentRedFrame(TRect(150, 62, 728, 90), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ОГРН страхователя") SetPosAndParentRedFrame(TRect(150, 104, 434, 132), pcInsuredType->ActivePage);
   if(curr_error == "Не указана дата гос. регистрации") SetPosAndParentRedFrame(TRect(439, 105, 727, 131), pcInsuredType->ActivePage);
   if(curr_error == "Не указано наименование регистрирующего органа") SetPosAndParentRedFrame(TRect(150, 148, 728, 174), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ИНН  страхователя") SetPosAndParentRedFrame(TRect(150, 231, 728, 259), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ОГРНИП страхователя") SetPosAndParentRedFrame(TRect(150, 273, 434, 301), pcInsuredType->ActivePage);
   if(curr_error == "Не указана дата гос.  регистрации") SetPosAndParentRedFrame(TRect(439, 274, 727, 300), pcInsuredType->ActivePage);
   if(curr_error == "Не указано наименование  регистрирующего органа") SetPosAndParentRedFrame(TRect(150, 317, 728, 343), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ни один из видов связи со страхователем") SetPosAndParentRedFrame(TRect(150, 271, 728, 338), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ни один из видов связи со  страхователем") SetPosAndParentRedFrame(TRect(150, 232, 728, 297), pcInsuredType->ActivePage);
   if(curr_error == "Не указан ни один из видов связи  со  страхователем") SetPosAndParentRedFrame(TRect(150, 359, 728, 425), pcInsuredType->ActivePage);

   if(curr_error == "Не указан тип ТС") SetPosAndParentRedFrame(TRect(248, 19, 739, 48), Panel1);
   if(curr_error == "Не указана марка ТС") SetPosAndParentRedFrame(TRect(248,	48, 454, 77), Panel1);
   if(curr_error == "Не указана модель ТС") SetPosAndParentRedFrame(TRect(248, 78, 454, 107), Panel1);
   if(curr_error == "Неверно указан год выпуска ТС") SetPosAndParentRedFrame(TRect(248, 106, 739, 135), Panel1);
   if(curr_error == "Неверно указана разрешенная максимальная масса" || curr_error == "Неверно указано число мест транспортного средства") SetPosAndParentRedFrame(TRect(248, 135, 739, 164), Panel1);
   if(curr_error == "Необходимо указать, поставлено ли ТС на учёт в РФ") SetPosAndParentRedFrame(TRect(248, 14, 454, 43), Panel2);
   if(curr_error == "Неверно указан код региона гос. номера ТС" || curr_error == "Неверно указан гос. номер ТС (должен содержать только цифры и русские буквы 'А','В','Е','К','М','Н','О','Р','С','Т','Х','У', 'D')") SetPosAndParentRedFrame(TRect(452, 14, 738, 43), Panel2);
   if(curr_error == "Должен быть указан хотя бы один идентификационный номер ТС (VIN / № шасси / № рамы / № кузова / № прицепа)") SetPosAndParentRedFrame(TRect(248, 42, 739, 94), Panel2);
   if(curr_error == "Неверно указана действительная стоимость ТС") SetPosAndParentRedFrame(TRect(248, 112, 454, 141), Panel2);
   if(curr_error.Pos("Неверно указана страховая сумма")) SetPosAndParentRedFrame(TRect(248, 140, 454, 169), Panel2);
   if(curr_error == "Для ТС, приобретенных за счет заемных средств, при неполном страховании по первому риску отношение страховой суммы к действительной стоимости должно должен быть меньше 0.8" || curr_error == "Отношение страховой суммы к действительной стоимости должно находиться в пределах от 0,5 до 1") SetPosAndParentRedFrame(TRect(248, 112, 454, 169), Panel2);
   if(curr_error == "Не указан лимит по риску \"Ущерб\"") SetPosAndParentRedFrame(TRect(452, 140, 739, 169), Panel2);
   if(curr_error == "Применить неиндексируемую СС в договоре с ТС возрастом более 5 лет нельзя") SetPosAndParentRedFrame(TRect(452, 170, 731, 191), Panel2);
   if(curr_error == "Необходимо указать состояние ПУС на данном ТС") SetPosAndParentRedFrame(TRect(248, 209, 739, 238), Panel2);
   if(curr_error == "Необходимо указать хотя бы одну ПУС") SetPosAndParentRedFrame(TRect(248, 264, 739, 346), Panel2);
   if(curr_error == "Не указана серия документа ТС") SetPosAndParentRedFrame(TRect(248, 41, 357, 68), Panel3);
   if(curr_error == "Не указан номер документа ТС") SetPosAndParentRedFrame(TRect(359, 41, 552, 68), Panel3);
   if(curr_error == "Не указана дата выдачи документа ТС" || curr_error == "Год выдачи ПТС должен совпадать с годом выпуска ТС") SetPosAndParentRedFrame(TRect(552, 41, 738, 67), Panel3);
   if(curr_error == "Не указано проводился ли осмотр") SetPosAndParentRedFrame(TRect(248, 77, 454, 106), Panel3);
   if(curr_error == "Не указана дата проведения осмотра" || curr_error == "Дата проведения осмотра ТС не может быть раньше текущей даты" || curr_error == "Дата проведения осмотра ТС не может быть позже даты начала срока страхования") SetPosAndParentRedFrame(TRect(454, 78, 737, 105), Panel3);
   if(curr_error == "Не указана мощность двигателя ТС") SetPosAndParentRedFrame(TRect(248, 116, 739, 145), Panel3);
   if(curr_error == "Не указано количество комплектов ключей ТС") SetPosAndParentRedFrame(TRect(248, 175, 739, 204), Panel3);
   if(curr_error == "Не указана цель использования ТС") SetPosAndParentRedFrame(TRect(248, 217, 739, 246), Panel3);
   if(curr_error == "Не указано телематическое оборудование для программы \"Комфорт на дороге\"") SetPosAndParentRedFrame(TRect(248, 302, 739, 331), Panel3);

   if(curr_error == "Отсутствуют допущенные к управлению ТС") SetPosAndParentRedFrame(TRect(8, 27, 470, 56), gbPermitted);
   if(curr_error.Pos("водителя №")) SetPosAndParentRedFrame(TRect(8, 68, 743, 237), gbPermitted);

   if(curr_error.Pos("начала срока страхования")) SetPosAndParentRedFrame(TRect(248, 6, 384, 35), panXxxx0);
   if(curr_error == "Не указан процент безусловной франшизы") SetPosAndParentRedFrame(TRect(544, 147, 739, 176), panXxxx0);
   if(curr_error == "Не указана величина безусловной франшизы в рублях") SetPosAndParentRedFrame(TRect(544, 178, 739, 207), panXxxx0);
   if(curr_error == "Не указан порядок оплаты страховой премии") SetPosAndParentRedFrame(TRect(248, 223, 739, 252), panXxxx0);
   //if(curr_error == "Не указано обоснование применения коэффициента андеррайтера") SetPosAndParentRedFrame(TRect(), panXxxx0);
   if(curr_error == "Не указана информация по ОСАГО страхователя" || curr_error == "Не указано число убытков по предыдущему договору") SetPosAndParentRedFrame(TRect(248, 398, 739, 427), panXxxx0);

   if(curr_error.Pos("риск мед. помощь")) SetPosAndParentRedFrame(TRect(7, 114, 456, 143), gbDopRisk);

   if(curr_error == "Не указано наименование организации-выгодоприобретателя") SetPosAndParentRedFrame(TRect(280, 26, 727,	52), pcBeneficType->ActivePage);
   if(curr_error == "Не указана фамилия выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 26, 344, 52), pcBeneficType->ActivePage);
   if(curr_error == "Не указано имя выгодоприобретателя") SetPosAndParentRedFrame(TRect(341, 26, 535, 52), pcBeneficType->ActivePage);
   if(curr_error == "Не указана дата рождения выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 60, 726, 86), pcBeneficType->ActivePage);
   if(curr_error == "Не указана серия документа выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 120, 211, 146), pcBeneficType->ActivePage);
   if(curr_error == "Не указан номер документа выгодоприобретателя") SetPosAndParentRedFrame(TRect(214, 120, 318, 146), pcBeneficType->ActivePage);
   if(curr_error == "Не указан ИНН выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 63, 727, 89), pcBeneficType->ActivePage);
   if(curr_error == "Не указан ОГРН выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 101, 434, 127), pcBeneficType->ActivePage);
   if(curr_error == "Не указан адрес регистрации выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 180, 728, 210), pcBeneficType->ActivePage);
   if(curr_error == "Не указан ИНН  выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 224, 727, 250), pcBeneficType->ActivePage);
   if(curr_error == "Не указан ОГРНИП выгодоприобретателя") SetPosAndParentRedFrame(TRect(150, 263, 434, 289), pcBeneficType->ActivePage);
   if(curr_error == "Не указано отделение ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(151, 221, 435, 247), pcBeneficType->ActivePage);
   if(curr_error == "Не указан № отделения ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(432, 221, 520, 247), pcBeneficType->ActivePage);
   if(curr_error == "Не указано месторасположение отделения ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(517, 221, 730, 247), pcBeneficType->ActivePage);
   if(curr_error == "Не указан почтовый адрес отделения ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(150, 244, 731, 274), pcBeneficType->ActivePage);
   if(curr_error == "Не указан номер кредитного договора с ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(150, 291, 434, 317), pcBeneficType->ActivePage);
   if(curr_error == "Не указана дата кредитного договора с  ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(437, 291, 725, 317), pcBeneficType->ActivePage);
   if(curr_error == "Не указан номер договора залога с ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(150, 329, 434, 355), pcBeneficType->ActivePage);
   if(curr_error == "Не указана дата договора залога с ПАО \"Сбербанк России\"") SetPosAndParentRedFrame(TRect(437, 329, 725, 355), pcBeneficType->ActivePage);

   if(curr_error == "Не указан тип оплаты страховой премии") SetPosAndParentRedFrame(TRect(150, 19, 728, 48), panXxxx1);
   if(curr_error == "Не указан тип платежного документа") SetPosAndParentRedFrame(TRect(150, 99, 728, 128), panXxxx1);
   if(curr_error == "Не указана серия платежного документа") SetPosAndParentRedFrame(TRect(150, 127, 251, 152), panXxxx1);
   if(curr_error == "Не указан номер платежного документа") SetPosAndParentRedFrame(TRect(250, 127, 451, 152), panXxxx1);
   //if(curr_error == "Неверно указана дата оплаты / дата 1-го взноса") SetPosAndParentRedFrame(TRect(521, 127, 727, 152), panXxxx1);
   if(curr_error == "Не указан код авторизации с чека терминала") SetPosAndParentRedFrame(TRect(450, 127, 728, 152), panXxxx1);

   if(curr_error == "Не указан тип БСО") SetPosAndParentRedFrame(TRect(8, 26, 491, 55), gbBSO);
   if(curr_error == "Не указана серия договора(серия БСО)") SetPosAndParentRedFrame(TRect(8, 59, 139, 85), gbBSO);
   if(curr_error == "Не указан номер договора(номер БСО)") SetPosAndParentRedFrame(TRect(141, 59, 490, 85), gbBSO);
   if(curr_error == "Не выполнена проверка БСО" || curr_error == "БСО не найдено, либо возникла ошибка при запросе данных, проверьте серию/номер и повторите запрос") SetPosAndParentRedFrame(TRect(491, 24, 744, 55), gbBSO);

   if(curr_error == "Не указана должность представителя страховщика") SetPosAndParentRedFrame(TRect(150, 58, 730, 87), gbInsurer);
   if(curr_error == "Не указан номер документа, на основании которого действует представитель страховщика") SetPosAndParentRedFrame(TRect(150, 117, 435, 143), gbInsurer);
   if(curr_error == "Не указана дата документа, на основании которого действует представитель страховщика") SetPosAndParentRedFrame(TRect(440, 117, 728, 143), gbInsurer);
}
//---------------------------------------------------------------------------
