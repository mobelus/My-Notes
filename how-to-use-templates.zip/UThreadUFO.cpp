//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "UThreadUFO.h"
#pragma package(smart_init)


//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, PersonInfo *p_pi, PersonInfo *p_pm)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), vi(p_vi), pi(p_pi), pm(p_pm)
{
   int_to_station_type[0] = None;
   int_to_station_type[1] = FromList;
   int_to_station_type[2] = Other;
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi, TADOQuery *q_r, TADOQuery *q_v)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), pi(p_pi), q_reservations(q_r), q_vehicles(q_v)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), pi(p_pi)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_pl, TADOQuery *q_p, TADOQuery *q_v, TADOQuery *q_ins, TMemoryStream *fs)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_policy(q_pl), q_persons(q_p), q_vehicles(q_v), q_insurer(q_ins), pdf_file(fs)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_pl, TADOQuery *q_p, TADOQuery *q_v, TADOQuery *q_ins)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_policy(q_pl), q_persons(q_p), q_vehicles(q_v), q_insurer(q_ins)
{
   form_apo_print_ufo["�����"] = Policy;
   form_apo_print_ufo["���������"] = Claim;
   form_apo_print_ufo["�����(��������� �����������)"] = PolicyForInsurer;
   form_apo_print_ufo["����� ������ �-�����"] = EOsagoCopy;
   form_apo_print_ufo["����� �� ���� �����������"] = RejectionServiceStation;
   form_apo_print_ufo["���������� � ������������ ������"] = ClientAccept;
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_c, TADOQuery *q_p, TADOQuery *q_v)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_calc(q_c), q_policy(q_p), q_vehicles(q_v)
{
}
//---------------------------------------------------------------------------
void __fastcall ThreadUFO::Execute()
{
   curr_year = YearOf(Date());

   char ds = DecimalSeparator;
   DecimalSeparator = '.';
   User *user_osagoproxy = new User();

   user_osagoproxy->UserName = di->login; user_osagoproxy->Password = di->pwd;

   CalcRequest *CalculationRequest = new CalcRequest();
   OperationResultOfCalcResultoTurZuT3 *ResultOfCalculation = new OperationResultOfCalcResultoTurZuT3();

   PrintRequest *PrintPolicyRequest = new PrintRequest();
   OperationResultOfArrayOfPrintResultgx6iBzRq *ArrayResultOfPrint = new OperationResultOfArrayOfPrintResultgx6iBzRq();

   AttachFileRequest *AttachFileReq = new AttachFileRequest();
   OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7 *ResultOfAttachFiles = new OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7();

   CheckPaymentRequest *CheckPaymentReq = new CheckPaymentRequest();
   OperationResultOfboolean *ResultOfCheckPayment = new OperationResultOfboolean();

   FindServiceStationsRequest *findStoaRequest = new FindServiceStationsRequest();
   OperationResultOfstring *ResultOfFindStoaRequest = new OperationResultOfstring();

   OperationResultOfFindResultoTurZuT3 *ResultOfFindStoaResult = new OperationResultOfFindResultoTurZuT3();

   SendVerificationCodeRequest *sendVerificationCodeRequest = new SendVerificationCodeRequest();
   ConfirmVerificationCodeRequest *confirmVerificationCodeRequest = new ConfirmVerificationCodeRequest();
   OperationResultOfboolean *ResultOfboolean = new OperationResultOfboolean();

   CancelContractRequest *cancelContractRequest = new CancelContractRequest();
   OperationResultOfguid *ResultOfGuid = new OperationResultOfguid();
   OperationResultOfStatusOfCancelContractResultoTurZuT3 *ResultOfCancelContract = new OperationResultOfStatusOfCancelContractResultoTurZuT3();

   try{
      switch(type_function){
         case ufo_calc:
         case ufo_segmentation:
         case ufo_modify:
            FillCalculationRequest(CalculationRequest);
            ResultOfCalculation = GetIOsago2ProxyService(false, soap_server_address)->Calculate(user_osagoproxy, CalculationRequest);
            SelectionFromResultOfCalculation(ResultOfCalculation);
            break;
         case ufo_print_policy:
            FillPrintPolicyRequest(PrintPolicyRequest);
            ArrayResultOfPrint = GetIOsago2ProxyService(false, soap_server_address)->Print(user_osagoproxy, PrintPolicyRequest);
            GetPDF(ArrayResultOfPrint);
            break;
         case ufo_print_claim:
            FillPrintClaimRequest(PrintPolicyRequest);
            ArrayResultOfPrint = GetIOsago2ProxyService(false, soap_server_address)->Print(user_osagoproxy, PrintPolicyRequest);
            GetPDF(ArrayResultOfPrint);
            break;
         case ufo_attachfile:
            FillAttachFileRequest(AttachFileReq);
            ResultOfAttachFiles = GetIOsago2ProxyService(false, soap_server_address)->AttachFile(user_osagoproxy, AttachFileReq);
            SelectionFromResultOfAttachFile(ResultOfAttachFiles);
            break;
         case ufo_check_payment:
            FillCheckPaymentRequest(CheckPaymentReq);
            ResultOfCheckPayment = GetIOsago2ProxyService(false, soap_server_address)->CheckPayment(user_osagoproxy, CheckPaymentReq);
            SelectionFromResultOfCheckPaymentRequest(ResultOfCheckPayment);
            break;
         case ufo_stoa_request:
            FillFindStoaRequest(findStoaRequest);
            ResultOfFindStoaRequest = GetIOsago2ProxyService(false, soap_server_address)->FindServiceStations(user_osagoproxy, findStoaRequest);
            SelectionFromResultOfFindStoaRequest(ResultOfFindStoaRequest);
            break;
         case ufo_stoa_result:
            ResultOfFindStoaResult = GetIOsago2ProxyService(false, soap_server_address)->FindServiceStationsResult(user_osagoproxy, di->stoa_request_id, true);
            SelectionFromResultOfFindStoaResult(ResultOfFindStoaResult);
            break;
         case ufo_send_code:
            FillVerificationCodeRequest(sendVerificationCodeRequest);
            ResultOfboolean = GetIOsago2ProxyService(false, soap_server_address)->SendVerificationCode(user_osagoproxy, sendVerificationCodeRequest);
            SelectionFromResultOfSendVerificationCodeRequest(ResultOfboolean);
            break;
         case ufo_verify_code:
            FillConfirmVerificationCode(confirmVerificationCodeRequest);
            ResultOfboolean = GetIOsago2ProxyService(false, soap_server_address)->ConfirmVerificationCode(user_osagoproxy, confirmVerificationCodeRequest);
            SelectionFromResultOfConfirmVerificationCode(ResultOfboolean);
            break;
         case ufo_send_cancel:
            FillCancelContractRequest(cancelContractRequest);
            ResultOfGuid = GetIOsago2ProxyService(false, soap_server_address)->CancelContract(user_osagoproxy, cancelContractRequest);
            SelectionFromCancelContractResponse(ResultOfGuid);
            break;
         case ufo_check_cancel:
            ResultOfCancelContract = GetIOsago2ProxyService(false, soap_server_address)->StatusOfCancelContract(user_osagoproxy, q_policy->FieldByName("contract_id")->AsString);
            SelectionFromCheckStatusOfCancelContractResponse(ResultOfCancelContract);
            break;
      }
   }
   catch(Exception& ex){}

   delete CalculationRequest;
   delete ResultOfCalculation;

   delete PrintPolicyRequest;

   delete ArrayResultOfPrint;

   delete AttachFileReq;
   delete ResultOfAttachFiles;

   delete CheckPaymentReq;
   delete ResultOfCheckPayment;

   delete findStoaRequest;
   delete ResultOfFindStoaRequest;

   delete ResultOfFindStoaResult;

   delete sendVerificationCodeRequest;
   delete confirmVerificationCodeRequest;
   delete ResultOfboolean;

   delete cancelContractRequest;
   delete ResultOfGuid;
   delete ResultOfCancelContract;

   delete user_osagoproxy;

   DecimalSeparator = ds;
}
//---------------------------------------------------------------------------
void ThreadUFO::FillCalculationRequest(CalcRequest *CalcReq)
{
   AnsiString region_skk = AddNulls(di->region_id, 2);
   //int offsetmin = m_api->dbGetIntFromQueryDef(res, "select time_utc_offset from gl_dict_time_zone where Date()>=start_date and Date()<=end_date and region_skk=" + QuotedStr(region_skk)) * 60;

   TIME_ZONE_INFORMATION tzi;
   GetTimeZoneInformation(&tzi);
   int offsetmin = abs(tzi.Bias);

   CalcReq->CorellationId = di->corellation_id;
   CalcReq->Logging = new Logging();
   CalcReq->Logging->QuotationId = di->calc_info.quotation_id;
   if(!di->contract_id.IsEmpty()) CalcReq->Logging->SessionId = di->contract_id;

   if(type_function == ufo_modify) CalcReq->IsRsaChecked = true;

   CalcReq->BranchCode = WideString(di->user_info.skk);
   CalcReq->IsPreCalculation = (type_function == ufo_segmentation || type_function == ufo_modify) ? false : true;
   CalcReq->NeedKbmRequest = true;
   if(!di->contract_id.IsEmpty()) CalcReq->CalculationId = di->contract_id;
   CalcReq->PolicyRegion = region_skk;
   if(di->user_info.sale_channel_id) CalcReq->SaleChannelType2008Id = AnsiString(di->user_info.sale_channel_id);
   CalcReq->StartDate = new DateTimeOffset();
   CalcReq->StartDate->DateTime = new TXSDateTime();
   CalcReq->StartDate->DateTime->AsDateTime = di->datesrok_s;
   CalcReq->StartDate->OffsetMinutes = offsetmin;
   if((int)di->datesrok_s == (int)Date()){
      AnsiString time_s = Time().FormatString("hh:nn");
      CalcReq->StartDate->DateTime->Hour = time_s.SubString(1, 2).ToIntDef(0);
      CalcReq->StartDate->DateTime->Minute = time_s.SubString(4, 2).ToIntDef(0);
   }
   CalcReq->EndDate = new DateTimeOffset();
   CalcReq->EndDate->DateTime = new TXSDateTime();
   CalcReq->EndDate->DateTime->AsDateTime = di->datesrok_po;
   CalcReq->EndDate->DateTime->Hour = 23;
   CalcReq->EndDate->DateTime->Minute = 59;
   CalcReq->EndDate->DateTime->Second = 59;
   CalcReq->EndDate->OffsetMinutes = offsetmin;
   CalcReq->RegistrationPlace = Rf;
   if(vi->is_foreign_registration) CalcReq->RegistrationPlace = Foreign;
   if(vi->is_transit) CalcReq->RegistrationPlace = Following;
   CalcReq->IsGrossViolationsOfInsurance = di->is_violations;
   if(!vi->is_foreign_registration && !vi->is_transit) CalcReq->PrimaryUseKladr = di->RsaKtTerritoryId();
   CalcReq->IsAnyone = di->type_multydrive ? false : true;

   if(!vi->is_foreign_registration && !vi->is_transit && type_function != ufo_modify){
      int len_period(1);
      if(di->usage_period[2].start_date.Val && di->usage_period[2].end_date.Val) len_period = 3;
      else{
         if(di->usage_period[1].start_date.Val && di->usage_period[1].end_date.Val) len_period = 2;
      }
      CalcReq->Periods.Length = len_period;
      for(int i = 0; i < len_period; ++i) AddPeriod(CalcReq->Periods, i, di->usage_period[i].start_date, di->usage_period[i].end_date);
   }

   CalcReq->Auto = new Auto;
   if(type_function == ufo_segmentation || type_function == ufo_modify) CalcReq->Auto->KbmClassForPreCalc = null_str;
   CalcReq->Auto->ClassifierVehicleModelCode = vi->rsa_code;
   if(!vi->vehicle_brand_name_print.IsEmpty()) CalcReq->Auto->PtsBrand = vi->vehicle_brand_name_print.Trim();
   if(!vi->vehicle_model_name_print.IsEmpty()) CalcReq->Auto->PtsModel = vi->vehicle_model_name_print.Trim();
   CalcReq->Auto->HasTrailer = vi->is_trailer;
   CalcReq->Auto->ManufactureYear = vi->construction_year;

   switch(vi->vehicle_type_id){
      case 2:
         CalcReq->Auto->Power = new TXSDecimal();
         CalcReq->Auto->Power->DecimalString = FloatToSQLStr(!vi->engine_power_type ? vi->engine_power : (m_api->Round(vi->engine_power * 0.0135962) * 100));
         break;
      case 3:
         CalcReq->Auto->AllowWeight = new TXSDecimal();
         CalcReq->Auto->AllowWeight->DecimalString = FloatToSQLStr(vi->allowed_mass);
         break;
      case 4:
         CalcReq->Auto->SeatCount = vi->number_of_seats;
         break;
   }

   CalcReq->Auto->Vin = vi->vin.Trim();
   AnsiString ident_number = vi->chassis_number.Trim();
   CalcReq->Auto->ChassisNumber = CheckIdentNumber(ident_number) ? ident_number : empty_str;
   ident_number = vi->body_number.Trim();
   CalcReq->Auto->FrameNumber = CheckIdentNumber(ident_number) ? ident_number : empty_str;
   CalcReq->Auto->LicensePlate = vi->registration_mark.Trim();

   CalcReq->Auto->PurposeUseCode = IntToStr(vi->usage_purpose_id);

   if(di->type_multydrive == 1){
      CalcReq->Auto->Drivers.Length = di->count_permitted;
      for(int i = 0, j = 0; i < 50; ++i){
         if(pm[i].permitted_check || (type_function == ufo_modify && pm[i].is_removed)){
            CalcReq->Auto->Drivers[j] = new Driver();
            CalcReq->Auto->Drivers[j]->DriverId = i + 1;
            CalcReq->Auto->Drivers[j]->BirthDate = new TXSDateTime();
            CalcReq->Auto->Drivers[j]->BirthDate->AsDateTime = pm[i].birthdate;
            CalcReq->Auto->Drivers[j]->DrivingStartExperienceDate = new TXSDateTime();
            CalcReq->Auto->Drivers[j]->DrivingStartExperienceDate->AsDateTime = pm[i].doc_issue_date;
            CalcReq->Auto->Drivers[j]->Name = new PersonName();
            CalcReq->Auto->Drivers[j]->Name->LastName = pm[i].lastname.Trim();
            CalcReq->Auto->Drivers[j]->Name->FirstName = pm[i].firstname.Trim();
            CalcReq->Auto->Drivers[j]->Name->SecondName = pm[i].secondname.Trim();
            CalcReq->Auto->Drivers[j]->License = new Document;
            CalcReq->Auto->Drivers[j]->License->TypeCode = AddNulls(pm[i].doc_type, 3);
            CalcReq->Auto->Drivers[j]->License->Series = StringReplace(pm[i].doc_seria, space_str, empty_str, rf);
            CalcReq->Auto->Drivers[j]->License->Number = pm[i].doc_number.Trim();

            // ���������� �����
            if(pm[i].prev_doc_type){
               CalcReq->Auto->Drivers[j]->PrevLicense = new Document;
               CalcReq->Auto->Drivers[j]->PrevLicense->TypeCode = AddNulls(pm[i].prev_doc_type, 3);
               CalcReq->Auto->Drivers[j]->PrevLicense->Series = StringReplace(pm[i].prev_doc_seria, space_str, empty_str, rf);
               CalcReq->Auto->Drivers[j]->PrevLicense->Number = pm[i].prev_doc_number.Trim();
               CalcReq->Auto->Drivers[j]->PrevLicense->IssueDate = new TXSDateTime();
               CalcReq->Auto->Drivers[j]->PrevLicense->IssueDate->AsDateTime = pm[i].prev_doc_issue_date;
            }

            // ���������� ���
            if(!pm[i].prev_firstname.Trim().IsEmpty() || !pm[i].prev_lastname.Trim().IsEmpty()){
               CalcReq->Auto->Drivers[j]->PrevName = new PersonName();
               if(!pm[i].prev_firstname.IsEmpty()) CalcReq->Auto->Drivers[j]->PrevName->FirstName = pm[i].prev_firstname;
               if(!pm[i].prev_lastname.IsEmpty())  CalcReq->Auto->Drivers[j]->PrevName->LastName  = pm[i].prev_lastname;
            }

            // ��� ��������������
            if(type_function == ufo_modify){
               CalcReq->Auto->Drivers[j]->IsDriverAdded   = pm[i].is_added;
               CalcReq->Auto->Drivers[j]->IsDriverRemoved = pm[i].is_removed;
               CalcReq->Auto->Drivers[j]->DriverAddedDate = new DateTimeOffset();
               CalcReq->Auto->Drivers[j]->DriverAddedDate->DateTime = new TXSDateTime();
               CalcReq->Auto->Drivers[j]->DriverAddedDate->DateTime->AsDateTime = pm[i].permitted_added_date;
               CalcReq->Auto->Drivers[j]->DriverAddedDate->OffsetMinutes = offsetmin;
            }

            ++j;
         }
      }
   }

   CalcReq->Owner = new Counteragent();
   CalcReq->Owner->SubjectTypeId = pi[1].status;
   if(type_function == ufo_calc){
      if(pi[1].status != 2) CalcReq->Owner->IsResident = true;
      else CalcReq->Owner->IsResident = pi[1].resident_yur;
   }

   CalcReq->ClientAccept = di->is_personal_data;
   CalcReq->Insurant = new Counteragent();
   CalcReq->Insurant->SubjectTypeId = pi[0].status;
   if(type_function == ufo_calc) CalcReq->Insurant->IsResident = true;

   // ��������
   CalcReq->Agent = new Agent();
   switch(di->user_info.lnr.Length()){
      case 10:
         CalcReq->Agent->SubjectTypeId = IntToStr(2);
         CalcReq->Agent->INN = di->user_info.lnr;
         break;
      case 12:
         CalcReq->Agent->SubjectTypeId = IntToStr(5);
         CalcReq->Agent->INN = di->user_info.lnr;
         break;
      default:
         CalcReq->Agent->SubjectTypeId = one_str;
         CalcReq->Agent->LNR = AddNulls(di->user_info.lnr, 8);
         break;
   }
   
   if(di->user_info.office_id) CalcReq->Agent->OfficeId = di->user_info.office_id;

   CalcReq->AddServiceStations = int_to_station_type[di->stoa_id];
   TADOQuery *q_stoa = m_api->dbGetCursor(res, "select * from osago_stoa_temp where stoa_checked=True order by stoa_number");
   if(di->stoa_id > 0){
      CalcReq->ServiceStations.Length = q_stoa->RecordCount;
      for(q_stoa->First(); !q_stoa->Eof; q_stoa->Next()){
         int index = q_stoa->RecNo - 1;
         CalcReq->ServiceStations[index] = new ServiceStation();
         if(di->stoa_id == 1) CalcReq->ServiceStations[index]->Id = q_stoa->FieldByName("stoa_id")->AsString;
         CalcReq->ServiceStations[index]->Name = q_stoa->FieldByName("stoa_name")->AsString;
         CalcReq->ServiceStations[index]->Address = q_stoa->FieldByName("stoa_address")->AsString;
      }
   }
   m_api->dbCloseCursor(res, q_stoa);

   if((type_function == ufo_calc && !di->type_multydrive && !vi->is_foreign_registration) || type_function == ufo_segmentation || type_function == ufo_modify){

      // �����������
      if(pi[1].status != 2 || (type_function == ufo_segmentation || type_function == ufo_modify)){
         CalcReq->Owner->Document_ = new Document();
         CalcReq->Owner->Document_->TypeCode = AddNulls(pi[1].doc_type, 3);
         CalcReq->Owner->Document_->Series = StringReplace(pi[1].doc_seria, space_str, empty_str, rf);;
         CalcReq->Owner->Document_->Number = pi[1].doc_number.Trim();
      }

      if(pi[1].status == 2){
         CalcReq->Owner->OrganizationName = m_api->dbGetStringFromQuery(res, AnsiString("select ") + (pi[1].is_opf_full ? "opf_full" : "opf") + " from gl_dict_opf_for_auto where id=" + IntToStr(pi[1].opf_id)) + space_str + pi[1].organization.Trim();
         CalcReq->Owner->Inn = pi[1].inn;
         CalcReq->Owner->IsResident = pi[1].resident_yur;
         if(type_function == ufo_segmentation || type_function == ufo_modify) CalcReq->Owner->OGRN = pi[1].ogrn.Trim();
      }
      else{
         CalcReq->Owner->Name = new PersonName();
         CalcReq->Owner->Name->LastName = pi[1].lastname.Trim();
         CalcReq->Owner->Name->FirstName = pi[1].firstname.Trim();
         CalcReq->Owner->Name->SecondName = pi[1].secondname.Trim();
         CalcReq->Owner->BirthDate = new TXSDateTime();
         CalcReq->Owner->BirthDate->AsDateTime = pi[1].birthdate;
         if(pi[1].status == 5 && (type_function == ufo_segmentation || type_function == ufo_modify)) CalcReq->Owner->OGRN = pi[1].ogrn.Trim();
         CalcReq->Owner->IsResident = (pi[1].kladr_addr->Values["��������"].UpperCase() == yes);

         if(!pi[1].prev_firstname.Trim().IsEmpty() || !pi[1].prev_lastname.Trim().IsEmpty()){
            CalcReq->Owner->PrevName = new PersonName();
            if(!pi[1].prev_firstname.IsEmpty()) CalcReq->Owner->PrevName->FirstName = pi[1].prev_firstname;
            if(!pi[1].prev_lastname.IsEmpty())  CalcReq->Owner->PrevName->LastName  = pi[1].prev_lastname;
         }

         if(pi[1].prev_doc_type > 0 && !pi[1].prev_doc_seria.Trim().IsEmpty() && !pi[1].prev_doc_number.Trim().IsEmpty()){
            CalcReq->Owner->PrevDocument = new Document();
            CalcReq->Owner->PrevDocument->TypeCode = AddNulls(pi[1].prev_doc_type, 3);
            CalcReq->Owner->PrevDocument->Series = StringReplace(pi[1].prev_doc_seria, space_str, empty_str, rf);;
            CalcReq->Owner->PrevDocument->Number = pi[1].prev_doc_number.Trim();
         }

         // ����� ������������
         if(pi[1].person_bad && pi[1].license_type){
            CalcReq->OwnerLicense = new Document();
            CalcReq->OwnerLicense->TypeCode = AddNulls(pi[1].license_type, 3);
            CalcReq->OwnerLicense->Series = StringReplace(pi[1].license_series, space_str, empty_str, rf);
            CalcReq->OwnerLicense->Number = pi[1].license_number.Trim();
         }
      }

      if(type_function == ufo_segmentation || type_function == ufo_modify){
         if(pi[1].status == 5) CalcReq->Owner->Inn = pi[1].inn;

         CalcReq->Owner->Address = new AddressEntry();
         CalcReq->Owner->Address->CountryCode = KladrValueToStr(pi[1].kladr_addr->Values["����������� ID"]).ToIntDef(643);
         CalcReq->Owner->Address->KladrCode = KladrValueToStr(pi[1].kladr_addr->Values["��� �����"].SubString(1, 11) + two_nulls);
         CalcReq->Owner->Address->PostCode = KladrValueToStr(pi[1].kladr_addr->Values["������"]);
         CalcReq->Owner->Address->Region = KladrValueToStr(pi[1].kladr_addr->Values["������"]);

         CalcReq->Owner->Address->Area = KladrValueToStr(pi[1].kladr_addr->Values["�����"]);
         CalcReq->Owner->Address->City = KladrValueToStr(pi[1].kladr_addr->Values["�����"]);
         CalcReq->Owner->Address->Place = KladrValueToStr(pi[1].kladr_addr->Values["�������"]);

         CalcReq->Owner->Address->Street = KladrValueToStr(pi[1].kladr_addr->Values["�����"]);
         CalcReq->Owner->Address->House = KladrValueToStr(pi[1].kladr_addr->Values["���"]);
         CalcReq->Owner->Address->Building = KladrValueToStr(pi[1].kladr_addr->Values["����� �������"]);
         CalcReq->Owner->Address->Flat = KladrValueToStr(pi[1].kladr_addr->Values["��������"]);
         CalcReq->Owner->Address->FullAddress = pi[1].address;

         // ������������
         CalcReq->Insurant->Document_ = new Document();
         CalcReq->Insurant->Document_->TypeCode = AddNulls(pi[0].doc_type, 3);
         CalcReq->Insurant->Document_->Series = StringReplace(pi[0].doc_seria, space_str, empty_str, rf);
         CalcReq->Insurant->Document_->Number = pi[0].doc_number.Trim();

         if(pi[0].status == 2){
            CalcReq->Insurant->OrganizationName = m_api->dbGetStringFromQuery(res, AnsiString("select ") + (pi[0].is_opf_full ? "opf_full" : "opf") + " from gl_dict_opf_for_auto where id=" + IntToStr(pi[0].opf_id)) + space_str + pi[0].organization.Trim();
            CalcReq->Insurant->Inn = pi[0].inn.Trim();
            CalcReq->Insurant->IsResident = pi[0].resident_yur;
            CalcReq->Insurant->OGRN = pi[0].ogrn.Trim();
            CalcReq->Insurant->KPP = pi[0].kpp.Trim();
         }
         else{
            CalcReq->Insurant->Name = new PersonName();
            CalcReq->Insurant->Name->LastName = pi[0].lastname.Trim();
            CalcReq->Insurant->Name->FirstName = pi[0].firstname.Trim();
            CalcReq->Insurant->Name->SecondName = pi[0].secondname.Trim();
            CalcReq->Insurant->BirthDate = new TXSDateTime();
            CalcReq->Insurant->BirthDate->AsDateTime = pi[0].birthdate;
            if(pi[0].status == 5) CalcReq->Insurant->OGRN = pi[0].ogrn;
            CalcReq->Insurant->IsResident = (pi[0].kladr_addr->Values["��������"].UpperCase() == yes);
         }

         CalcReq->Insurant->Address = new AddressEntry();
         CalcReq->Insurant->Address->CountryCode = KladrValueToStr(pi[0].kladr_addr->Values["����������� ID"]).ToIntDef(643);
         CalcReq->Insurant->Address->KladrCode = KladrValueToStr(pi[0].kladr_addr->Values["��� �����"].SubString(1, 11) + two_nulls);
         CalcReq->Insurant->Address->PostCode = KladrValueToStr(pi[0].kladr_addr->Values["������"]);
         CalcReq->Insurant->Address->Region = KladrValueToStr(pi[0].kladr_addr->Values["������"]);
         CalcReq->Insurant->Address->Area = KladrValueToStr(pi[0].kladr_addr->Values["�����"]);
         CalcReq->Insurant->Address->City = KladrValueToStr(pi[0].kladr_addr->Values["�����"]);
         CalcReq->Insurant->Address->Place = KladrValueToStr(pi[0].kladr_addr->Values["�������"]);
         CalcReq->Insurant->Address->Street = KladrValueToStr(pi[0].kladr_addr->Values["�����"]);
         CalcReq->Insurant->Address->House = KladrValueToStr(pi[0].kladr_addr->Values["���"]);
         CalcReq->Insurant->Address->Building = KladrValueToStr(pi[0].kladr_addr->Values["����� �������"]);
         CalcReq->Insurant->Address->Flat = KladrValueToStr(pi[0].kladr_addr->Values["��������"]);
         CalcReq->Insurant->Address->FullAddress = pi[0].address;

         CalcReq->Insurant->Contacts = new Contacts();
         CalcReq->Insurant->Contacts->HomePhone   = pi[0].phone_home;
         CalcReq->Insurant->Contacts->MobilePhone = pi[0].phone_mobil;
         CalcReq->Insurant->Contacts->WorkPhone   = pi[0].phone_work;
         CalcReq->Insurant->Contacts->Email       = !pi[0].email.IsEmpty() ? pi[0].email : AnsiString("eosago@rgs.ru");

         // ����
         CalcReq->Auto->Document = new Document();
         CalcReq->Auto->Document->TypeCode = m_api->dbGetStringFromQuery(res, "select vehicle_registr_type_name_print from osago_dict_veh_doc_type where vehicle_registr_type_id=" + IntToStr(vi->vehicle_registration_type_id));
         CalcReq->Auto->Document->Series = vi->registration_series.Trim();
         CalcReq->Auto->Document->Number = vi->registration_number.Trim();
         if(vi->registration_issue_date.Val != 0.0){
            CalcReq->Auto->Document->IssueDate = new TXSDateTime();
            CalcReq->Auto->Document->IssueDate->AsDateTime = vi->registration_issue_date;
         }

         bool is_2_vehicle_doc = !vi->is_foreign_registration && !vi->registration_series_2.IsEmpty() && !vi->registration_number_2.IsEmpty() && vi->vehicle_registration_type_id == 2;
         CalcReq->Auto->Documents.Length = 1 + (is_2_vehicle_doc ? 1 : 0);

         CalcReq->Auto->Documents[0] = new Document();
         CalcReq->Auto->Documents[0]->TypeCode = m_api->dbGetStringFromQuery(res, "select vehicle_registr_type_name_print from osago_dict_veh_doc_type where vehicle_registr_type_id=" + IntToStr(vi->vehicle_registration_type_id));
         CalcReq->Auto->Documents[0]->Series = vi->registration_series.Trim();
         CalcReq->Auto->Documents[0]->Number = vi->registration_number.Trim();
         if(vi->registration_issue_date.Val != 0.0){
            CalcReq->Auto->Documents[0]->IssueDate = new TXSDateTime();
            CalcReq->Auto->Documents[0]->IssueDate->AsDateTime = vi->registration_issue_date;
         }
         if(is_2_vehicle_doc){
            CalcReq->Auto->Documents[1] = new Document();
            CalcReq->Auto->Documents[1]->TypeCode = m_api->dbGetStringFromQuery(res, "select vehicle_registr_type_name_print from osago_dict_veh_doc_type where vehicle_registr_type_id=" + IntToStr(vi->vehicle_registration_type_id_2));
            CalcReq->Auto->Documents[1]->Series = vi->registration_series_2.Trim();
            CalcReq->Auto->Documents[1]->Number = vi->registration_number_2.Trim();
            if(vi->registration_issue_date_2.Val!=0.0){
                CalcReq->Auto->Documents[1]->IssueDate = new TXSDateTime();
                CalcReq->Auto->Documents[1]->IssueDate->AsDateTime = vi->registration_issue_date_2;
            }
         }
      }
   }

   if(type_function == ufo_modify){
      AnsiString old_calc_id_str = IntToStr(di->prev_calc_id);
      TADOQuery *q_c = m_api->dbGetCursor(res, "select * from osago_calc where calc_id=" + old_calc_id_str),
                *q_pol = m_api->dbGetCursor(res, "select * from osago_policy where calc_id=" + old_calc_id_str),
                *q_veh = m_api->dbGetCursor(res, "select * from osago_vehicle where calc_id=" + old_calc_id_str);

      CalcReq->IsUpdate = true;
      CalcReq->UpdateRequest = new UpdateRequest();

      CalcReq->UpdateRequest->ModifyReasonIds.Length = di->modify_reasons.size();
      int i(0);
      for(std::set<int>::iterator iter = di->modify_reasons.begin(); iter != di->modify_reasons.end(); ++iter) CalcReq->UpdateRequest->ModifyReasonIds[i++] = (*iter);

      CalcReq->UpdateRequest->StartDate = new DateTimeOffset();
      CalcReq->UpdateRequest->StartDate->DateTime = new TXSDateTime();
      CalcReq->UpdateRequest->StartDate->DateTime->AsDateTime = q_pol->FieldByName("srok_date_s")->AsDateTime;
      CalcReq->UpdateRequest->StartDate->OffsetMinutes = offsetmin;
      AnsiString time_s = q_pol->FieldByName("srok_time_s")->AsString;
      CalcReq->UpdateRequest->StartDate->DateTime->Hour = time_s.SubString(1, 2).ToIntDef(0);
      CalcReq->UpdateRequest->StartDate->DateTime->Minute = time_s.SubString(4, 2).ToIntDef(0);

      CalcReq->UpdateRequest->EndDate = new DateTimeOffset();
      CalcReq->UpdateRequest->EndDate->DateTime = new TXSDateTime();
      CalcReq->UpdateRequest->EndDate->DateTime->AsDateTime = q_pol->FieldByName("srok_date_po")->AsDateTime;
      CalcReq->UpdateRequest->EndDate->DateTime->Hour = 23;
      CalcReq->UpdateRequest->EndDate->DateTime->Minute = 59;
      CalcReq->UpdateRequest->EndDate->DateTime->Second = 59;
      CalcReq->UpdateRequest->EndDate->OffsetMinutes = offsetmin;

      CalcReq->UpdateRequest->IsGrossViolationsOfInsurance = false;

      CalcReq->UpdateRequest->RegistrationPlace = Rf;
      if(q_veh->FieldByName("is_foreign_registration")->AsInteger) CalcReq->UpdateRequest->RegistrationPlace = Foreign;
      if(q_veh->FieldByName("is_transit")->AsInteger) CalcReq->UpdateRequest->RegistrationPlace = Following;

      CalcReq->UpdateRequest->PrimaryUseKladr = (!q_veh->FieldByName("is_foreign_registration")->AsInteger && !q_veh->FieldByName("is_transit")->AsInteger) ? (FormatFloat("00", q_pol->FieldByName("kladr_region_id")->AsInteger) +  FormatFloat("000", q_pol->FieldByName("kladr_area_id")->AsInteger) + FormatFloat("000", q_pol->FieldByName("kladr_city_id")->AsInteger) +  FormatFloat("000", q_pol->FieldByName("kladr_place_id")->AsInteger) + "00") : empty_str;

      CalcReq->UpdateRequest->Auto = new Auto;
      switch(q_veh->FieldByName("vehicle_type_id")->AsInteger){
         case 2:
            CalcReq->UpdateRequest->Auto->Power = new TXSDecimal();
            CalcReq->UpdateRequest->Auto->Power->DecimalString = FloatToSQLStr(q_veh->FieldByName("engine_power")->AsFloat);
            break;
         case 3:
            CalcReq->UpdateRequest->Auto->AllowWeight = new TXSDecimal();
            CalcReq->UpdateRequest->Auto->AllowWeight->DecimalString = FloatToSQLStr(q_veh->FieldByName("allowed_mass")->AsFloat);
            break;
         case 4:
            CalcReq->UpdateRequest->Auto->SeatCount = q_veh->FieldByName("number_of_seats")->AsInteger;
            break;
      }

      CalcReq->UpdateRequest->Auto->HasTrailer = q_veh->FieldByName("trailer")->AsInteger;

      CalcReq->UpdateRequest->Auto->ClassifierVehicleModelCode = q_veh->FieldByName("rsa_code")->AsString;

      CalcReq->UpdateRequest->Auto->ManufactureYear = q_veh->FieldByName("construction_year")->AsInteger;

      CalcReq->UpdateRequest->Auto->ChassisNumber = q_veh->FieldByName("chassis_number")->AsString;
      CalcReq->UpdateRequest->Auto->FrameNumber = q_veh->FieldByName("body_number")->AsString;
      CalcReq->UpdateRequest->Auto->Vin = q_veh->FieldByName("vin")->AsString;
      CalcReq->UpdateRequest->Auto->LicensePlate = q_veh->FieldByName("registration_mark")->AsString;

      CalcReq->UpdateRequest->Auto->PurposeUseCode = q_veh->FieldByName("usage_purpose")->AsString;

      CalcReq->UpdateRequest->Auto->Document = new Document();
      CalcReq->UpdateRequest->Auto->Document->TypeCode = m_api->dbGetStringFromQuery(res, "select vehicle_registr_type_name_print from osago_dict_veh_doc_type where vehicle_registr_type_id=" + q_veh->FieldByName("vehicle_registration_type_id")->AsString);
      CalcReq->UpdateRequest->Auto->Document->Series = q_veh->FieldByName("registration_series")->AsString;
      CalcReq->UpdateRequest->Auto->Document->Number = q_veh->FieldByName("registration_number")->AsString;
      if(q_veh->FieldByName("registration_issue_date")->AsDateTime.Val != 0.0){
         CalcReq->UpdateRequest->Auto->Document->IssueDate = new TXSDateTime();
         CalcReq->UpdateRequest->Auto->Document->IssueDate->AsDateTime = q_veh->FieldByName("registration_issue_date")->AsDateTime;
      }

      CalcReq->UpdateRequest->Auto->Documents.Length = 1;
      CalcReq->UpdateRequest->Auto->Documents[0] = new Document();
      CalcReq->UpdateRequest->Auto->Documents[0]->TypeCode = CalcReq->UpdateRequest->Auto->Document->TypeCode;
      CalcReq->UpdateRequest->Auto->Documents[0]->Series = q_veh->FieldByName("registration_series")->AsString;
      CalcReq->UpdateRequest->Auto->Documents[0]->Number = q_veh->FieldByName("registration_number")->AsString;
      if(q_veh->FieldByName("registration_issue_date")->AsDateTime.Val != 0.0){
         CalcReq->UpdateRequest->Auto->Documents[0]->IssueDate = new TXSDateTime();
         CalcReq->UpdateRequest->Auto->Documents[0]->IssueDate->AsDateTime = q_veh->FieldByName("registration_issue_date")->AsDateTime;
      }

      CalcReq->UpdateRequest->Coefficients = new Coefficients();

      CalcReq->UpdateRequest->Coefficients->Tb = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Tb->DecimalString = FloatToSQLStr(q_c->FieldByName("bt")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kt = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kt->DecimalString = FloatToSQLStr(q_c->FieldByName("kt")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kpr = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kpr->DecimalString = FloatToSQLStr(q_c->FieldByName("kpr")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kp = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kp->DecimalString = FloatToSQLStr(q_c->FieldByName("kp")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Ko = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Ko->DecimalString = FloatToSQLStr(q_c->FieldByName("ko")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kn = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kn->DecimalString = FloatToSQLStr(q_c->FieldByName("kn")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Km = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Km->DecimalString = FloatToSQLStr(q_c->FieldByName("km")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kc = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kc->DecimalString = FloatToSQLStr(q_c->FieldByName("kc")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kbm = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kbm->DecimalString = FloatToSQLStr(q_c->FieldByName("kbm")->AsFloat);

      CalcReq->UpdateRequest->Coefficients->Kbc = new TXSDecimal();
      CalcReq->UpdateRequest->Coefficients->Kbc->DecimalString = FloatToSQLStr(q_c->FieldByName("kvs")->AsFloat);

      CalcReq->UpdateRequest->ReturnsSum = new TXSDecimal();
      CalcReq->UpdateRequest->ReturnsSum->DecimalString = null_str;
      CalcReq->UpdateRequest->Premium = new TXSDecimal();
      CalcReq->UpdateRequest->Premium->DecimalString = FloatToSQLStr(q_c->FieldByName("premiya_all")->AsFloat);

      if(!vi->is_foreign_registration && !vi->is_transit){
         int len_period(1);
         if(di->usage_period[2].start_date.Val && di->usage_period[2].end_date.Val) len_period = 3;
         else{
            if(di->usage_period[1].start_date.Val && di->usage_period[1].end_date.Val) len_period = 2;
         }
         CalcReq->Periods.Length = len_period;
         for(int i = 0; i < len_period; ++i) AddPeriod(CalcReq->Periods, i, di->usage_period[i].start_date, di->usage_period[i].end_date);

         for(int i = 0; i < 3; ++i){
            AnsiString num(i + 1);
            if((int)di->usage_period[i].start_date != (int)q_pol->FieldByName("up" + num + "_start_date")->AsDateTime || (int)di->usage_period[i].end_date != (int)q_pol->FieldByName("up" + num + "_end_date")->AsDateTime){
               if(di->usage_period[i].start_date.Val && di->usage_period[i].end_date.Val) CalcReq->Periods[i]->IsUsagePeriodAdded = true;
               if(q_pol->FieldByName("up" + num + "_start_date")->AsDateTime.Val && q_pol->FieldByName("up" + num + "_end_date")->AsDateTime.Val){
                  CalcReq->Periods.Length = ++len_period;
                  AddPeriod(CalcReq->Periods, len_period - 1, q_pol->FieldByName("up" + num + "_start_date")->AsDateTime, q_pol->FieldByName("up" + num + "_end_date")->AsDateTime);
                  CalcReq->Periods[len_period - 1]->IsUsagePeriodRemoved = true;
               }
            }
         }

         /*if((int)di->usage_period[0].start_date != (int)q_pol->FieldByName("up1_start_date")->AsDateTime || (int)di->usage_period[0].end_date != (int)q_pol->FieldByName("up1_end_date")->AsDateTime){
            CalcReq->Periods[0]->IsUsagePeriodAdded = true;
            CalcReq->Periods.Length = ++len_period;
            AddPeriod(CalcReq->Periods, len_period - 1, q_pol->FieldByName("up1_start_date")->AsDateTime, q_pol->FieldByName("up1_end_date")->AsDateTime);
            CalcReq->Periods[len_period - 1]->IsUsagePeriodRemoved = true;
         }
         if((int)di->usage_period[1].start_date != (int)q_pol->FieldByName("up2_start_date")->AsDateTime || (int)di->usage_period[1].end_date != (int)q_pol->FieldByName("up2_end_date")->AsDateTime){
            if(di->usage_period[1].start_date.Val && di->usage_period[1].end_date.Val) CalcReq->Periods[1]->IsUsagePeriodAdded = true;
            if(q_pol->FieldByName("up2_start_date")->AsDateTime.Val && q_pol->FieldByName("up2_end_date")->AsDateTime.Val){
               CalcReq->Periods.Length = ++len_period;
               AddPeriod(CalcReq->Periods, len_period - 1, q_pol->FieldByName("up2_start_date")->AsDateTime, q_pol->FieldByName("up2_end_date")->AsDateTime);
               CalcReq->Periods[len_period - 1]->IsUsagePeriodRemoved = true;
            }
         } */
      }

      m_api->dbCloseCursor(res, q_c); m_api->dbCloseCursor(res, q_pol); m_api->dbCloseCursor(res, q_veh);
   }
}
//---------------------------------------------------------------------------
void ThreadUFO::AddPeriod(ArrayOfPeriodOfUse Periods, const int index, const TDateTime& sd, const TDateTime& ed)
{
   Periods[index] = new PeriodOfUse();
   Periods[index]->Id = index + 1;
   Periods[index]->StartDate = new DateTimeOffset();
   Periods[index]->StartDate->DateTime = new TXSDateTime();
   Periods[index]->StartDate->DateTime->AsDateTime = sd;
   Periods[index]->EndDate = new DateTimeOffset();
   Periods[index]->EndDate->DateTime = new TXSDateTime();
   Periods[index]->EndDate->DateTime->AsDateTime = ed;
   Periods[index]->IsUsagePeriodAdded = false;
   Periods[index]->IsUsagePeriodRemoved = false;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfCalculation(OperationResultOfCalcResultoTurZuT3 *ResultOfCalc)
{
   /*for(int i = 0, cnt = ResultOfCalc->ValidationCodeErrors.Length; i < cnt; ++i)
      if(di->block_validations_code.count(ResultOfCalc->ValidationCodeErrors[i]->key)){ di->is_blocked_dogovor = 1; return; }*/
    // � ��� ���� �������������

   //��������� ��1-��2
   di->ResetCK1CK2();

   for(int i = 0, cnt = ResultOfCalc->ValidationCodeErrors.Length; i < cnt; ++i){
      if(di->ck1_ck2_code.count(ResultOfCalc->ValidationCodeErrors[i]->key)){
         di->is_ck1_ck2 = 1;
         TStringList *sl_ck1_ck2 = new TStringList();
         sl_ck1_ck2->Text = ResultOfCalc->ValidationCodeErrors[i]->value;
         if(sl_ck1_ck2->Count > 2){
            //di->insurance_company = sl_ck1_ck2->Strings[0];
            di->insurance_company = "�������������� ��������� ��������";
            di->url_company = sl_ck1_ck2->Strings[1];
            di->url_dogovor = (sl_ck1_ck2->Count == 6 && !sl_ck1_ck2->Strings[5].IsEmpty()) ? sl_ck1_ck2->Strings[5] : sl_ck1_ck2->Strings[2];
         }
         delete sl_ck1_ck2;
         return;
      }
      else if(di->block_validations_code.count(ResultOfCalc->ValidationCodeErrors[i]->key)){
         di->is_blocked_dogovor = 1;
         return;
      }
   }

   //��������� ��1-��2

   di->system_error = ResultOfCalc->ErrorMessage;

   for(int i = 0, cnt = ResultOfCalc->ValidationErrors.Length; i < cnt; ++i) di->validations_errors->Add(ResultOfCalc->ValidationErrors[i]);

   if(!ResultOfCalc->IsSuccess) return;

   di->contract_id = ResultOfCalc->Data->CalculationId;

   di->is_mop_911 = ResultOfCalc->Data->IsNeedScans;

   di->is_scan = di->is_blocked_dogovor = di->is_opora = 0;
   for(int i = 0, cnt = ResultOfCalc->Data->ClientReasons.Length; i < cnt; ++i){
      if(di->scan_code.count(ResultOfCalc->Data->ClientReasons[i]->Code)) di->is_scan = 1;
      if(di->block_reasons_code.count(ResultOfCalc->Data->ClientReasons[i]->Code)) di->is_blocked_dogovor = 1;
      if(di->limit_code.count(ResultOfCalc->Data->ClientReasons[i]->Code)) di->system_error = di->limit_text_error[ResultOfCalc->Data->ClientReasons[i]->Code];
      if(ResultOfCalc->Data->ClientReasons[i]->Code == AnsiString("OSAGO_BR_6406_1")){
         di->is_opora = 1;
         di->insurance_company = "�������������� ��������� ��������";
         di->url_dogovor = "https://eosago.opora-ins.ru/WebCustomer/Auth.jasp";
      }
   }
  
   di->calc_info.bt  = StrToFloatStr(ResultOfCalc->Data->K->Tb->DecimalString).ToDouble();
   di->calc_info.kt  = StrToFloatStr(ResultOfCalc->Data->K->Kt->DecimalString).ToDouble();
   di->calc_info.kvs = StrToFloatStr(ResultOfCalc->Data->K->Kbc->DecimalString).ToDouble();
   di->calc_info.kbm = StrToFloatStr(ResultOfCalc->Data->K->Kbm->DecimalString).ToDouble();
   di->calc_info.kc  = StrToFloatStr(ResultOfCalc->Data->K->Kc->DecimalString).ToDouble();
   di->calc_info.km  = StrToFloatStr(ResultOfCalc->Data->K->Km->DecimalString).ToDouble();
   di->calc_info.kn  = StrToFloatStr(ResultOfCalc->Data->K->Kn->DecimalString).ToDouble();
   di->calc_info.ko  = StrToFloatStr(ResultOfCalc->Data->K->Ko->DecimalString).ToDouble();
   di->calc_info.kp  = StrToFloatStr(ResultOfCalc->Data->K->Kp->DecimalString).ToDouble();
   di->calc_info.kpr = StrToFloatStr(ResultOfCalc->Data->K->Kpr->DecimalString).ToDouble();

   di->calc_info.premiya_all = StrToFloatStr(ResultOfCalc->Data->Premium->DecimalString).ToDouble();
   di->calc_info.premium_modify = StrToFloatStr(ResultOfCalc->Data->PremiumModify->DecimalString).ToDouble();
   if(di->calc_info.premium_modify < 0){ di->calc_info.return_or_surcharge = 1; di->calc_info.premium_modify = fabs(di->calc_info.premium_modify); }
	else di->calc_info.return_or_surcharge = 0;

   pi[1].person_bad = ResultOfCalc->Data->IsOwnerNotExistsInRsa ? 1 : 0;
   di->policy_sign = ResultOfCalc->Data->CheckSum;

   if(type_function != ufo_modify){
      di->is_e_policy = ResultOfCalc->Data->IsEOsago;
      di->polis_seria = di->is_e_policy ? "���" : "���";
      if(di->is_e_policy) di->polis_number = ResultOfCalc->Data->Number;
   }

   di->calc_info.kbm_info.rsa_id = ResultOfCalc->Data->VehicleKbmRsa->RsaRequestId;
   di->calc_info.kbm_info.kbm_class = ResultOfCalc->Data->VehicleKbmRsa->Class;
   di->calc_info.kbm_info.kbm_error = ResultOfCalc->Data->VehicleKbmRsa->RsaRequestError;
   di->calc_info.kbm_info.kbm_message_code = AnsiString(ResultOfCalc->Data->VehicleKbmRsa->MessageCode).ToIntDef(0);
   di->calc_info.kbm_info.kbm_message = ResultOfCalc->Data->VehicleKbmRsa->Message;
   di->calc_info.kbm_info.prev_policy_company = ResultOfCalc->Data->VehicleKbmRsa->PrevPolicyCompany;
   di->calc_info.kbm_info.prev_policy_series = ResultOfCalc->Data->VehicleKbmRsa->PrevPolicySeries;
   di->calc_info.kbm_info.prev_policy_number = ResultOfCalc->Data->VehicleKbmRsa->PrevPolicyNumber;

   if(di->type_multydrive == 1){
      for(int i = 0, prm_count = ResultOfCalc->Data->Drivers.Length; i < prm_count; ++i){
         int index = ResultOfCalc->Data->Drivers[i]->DriverId - 1;
         pm[index].kvs = StrToFloatStr(ResultOfCalc->Data->Drivers[i]->Kbc->DecimalString).ToDouble();
         pm[index].person_bad = ResultOfCalc->Data->Drivers[i]->KbmRsa->IsDriverNotExistsInRsa ? 1 : 0;
         pm[index].kbm_info.rsa_id = ResultOfCalc->Data->Drivers[i]->KbmRsa->RequestId;
         pm[index].kbm = StrToFloatStr(ResultOfCalc->Data->Drivers[i]->KbmRsa->Value->DecimalString).ToDouble();
         pm[index].kbm_info.kbm_class = ResultOfCalc->Data->Drivers[i]->KbmRsa->Class;
         pm[index].kbm_info.kbm_error = ResultOfCalc->Data->Drivers[i]->KbmRsa->Error;
         pm[index].kbm_info.kbm_message = ResultOfCalc->Data->Drivers[i]->KbmRsa->Message;
         pm[index].kbm_info.kbm_message_code = AnsiString(ResultOfCalc->Data->Drivers[i]->KbmRsa->MessageCode).ToIntDef(0);
         pm[index].kbm_info.prev_policy_series = ResultOfCalc->Data->Drivers[i]->KbmRsa->PrevPolicySeries;
         pm[index].kbm_info.prev_policy_number = ResultOfCalc->Data->Drivers[i]->KbmRsa->PrevPolicyNumber;
         pm[index].kbm_info.prev_policy_company = ResultOfCalc->Data->Drivers[i]->KbmRsa->PrevPolicyCompany;
      }
   }

   vi->vehicle_registration_doc_rsa = 1;
   for(int i = 0, cnt = ResultOfCalc->Data->VehicleKbmRsa->RsaCheck.Length; i < cnt; ++i){
      if(ResultOfCalc->Data->VehicleKbmRsa->RsaCheck[i]->IsSubjectChecked){
         int veh_doc_id = m_api->dbGetIntFromQuery(res, "select vehicle_registr_type_id from osago_dict_veh_doc_type where vehicle_registr_type_name_print=" + QuotedStr(ResultOfCalc->Data->VehicleKbmRsa->RsaCheck[i]->DocumentType));
         if(veh_doc_id != 1 && veh_doc_id != 3){ vi->vehicle_registration_doc_rsa = 2; break; }
      }
   }
}
//---------------------------------------------------------------------------
void ThreadUFO::FillPrintPolicyRequest(PrintRequest *PrintRequest)
{
   PrintRequest->CorellationId = di->corellation_id;

   PrintRequest->PrintOnlyDocumentType = form_apo_print_ufo[di->form_name];

   PrintRequest->Series = q_policy->FieldByName("polis_seria")->AsString;
   PrintRequest->Number = q_policy->FieldByName("polis_number")->AsString;
   PrintRequest->ContractDate = new TXSDateTime();
   PrintRequest->ContractDate->AsDateTime = Date();

   if(PrintRequest->PrintOnlyDocumentType != EOsagoCopy){
      PrintRequest->Draft = di->black_print;
      PrintRequest->CalculationId = q_policy->FieldByName("contract_id")->AsString;
      if(!q_policy->FieldByName("prev_seria")->AsString.IsEmpty() && !q_policy->FieldByName("prev_number")->AsString.IsEmpty()){
         PrintRequest->PreviousPolicy = new PreviousPolicy();
         PrintRequest->PreviousPolicy->Series = q_policy->FieldByName("prev_seria")->AsString;
         PrintRequest->PreviousPolicy->Number = q_policy->FieldByName("prev_number")->AsString;
      }

      PrintRequest->SpecialNotes = q_policy->FieldByName("special_notes")->AsString;

      FilterDataSet(q_persons, "type_person=1");
      TStringList *kladr_addr = new TStringList();
      int mid = q_persons->FieldByName("addr_mid")->AsInteger;
      if(mid){
         AnsiString memo_text("");
         m_api->dbReadWriteInternalMemo(res, memo_text, mid, true, "osago_memo");
         kladr_addr->Text = memo_text;
      }
      PrintRequest->InsurantAddress = new AddressEntry();
      PrintRequest->InsurantAddress->FullAddress = q_persons->FieldByName("address")->AsString;
      PrintRequest->InsurantAddress->CountryCode = KladrValueToStr(kladr_addr->Values["����������� ID"]).ToIntDef(643);
      PrintRequest->InsurantAddress->KladrCode = KladrValueToStr(kladr_addr->Values["��� �����"].SubString(1, 11) + two_nulls);
      PrintRequest->InsurantAddress->PostCode = KladrValueToStr(kladr_addr->Values["������"]);
      PrintRequest->InsurantAddress->Region = KladrValueToStr(kladr_addr->Values["������"]);
      PrintRequest->InsurantAddress->Area = KladrValueToStr(kladr_addr->Values["�����"]);
      PrintRequest->InsurantAddress->City = KladrValueToStr(kladr_addr->Values["�����"]);
      PrintRequest->InsurantAddress->Place = KladrValueToStr(kladr_addr->Values["�������"]);
      PrintRequest->InsurantAddress->Street = KladrValueToStr(kladr_addr->Values["�����"]);
      PrintRequest->InsurantAddress->House = KladrValueToStr(kladr_addr->Values["���"]);
      PrintRequest->InsurantAddress->Building = KladrValueToStr(kladr_addr->Values["����� �������"]);
      PrintRequest->InsurantAddress->Flat = KladrValueToStr(kladr_addr->Values["��������"]);

      if(!q_persons->FieldByName("phone_mobil")->AsString.IsEmpty() || !q_persons->FieldByName("phone_work")->AsString.IsEmpty() || !q_persons->FieldByName("phone_home")->AsString.IsEmpty()){
         PrintRequest->InsurantContacts = new Contacts();
         PrintRequest->InsurantContacts->MobilePhone = q_persons->FieldByName("phone_mobil")->AsString;
         PrintRequest->InsurantContacts->HomePhone = q_persons->FieldByName("phone_home")->AsString;
         PrintRequest->InsurantContacts->WorkPhone = q_persons->FieldByName("phone_work")->AsString;
      }

      FilterDataSet(q_persons, "type_person=2");

      mid = q_persons->FieldByName("addr_mid")->AsInteger;
      if(mid){
         AnsiString memo_text("");
         m_api->dbReadWriteInternalMemo(res, memo_text, mid, true, "osago_memo");
         kladr_addr->Text = memo_text;
      }
      PrintRequest->OwnerAddress = new AddressEntry();
      PrintRequest->OwnerAddress->FullAddress = q_persons->FieldByName("address")->AsString;
      PrintRequest->OwnerAddress->CountryCode = KladrValueToStr(kladr_addr->Values["����������� ID"]).ToIntDef(643);
      PrintRequest->OwnerAddress->KladrCode = KladrValueToStr(kladr_addr->Values["��� �����"].SubString(1, 11) + two_nulls);
      PrintRequest->OwnerAddress->PostCode = KladrValueToStr(kladr_addr->Values["������"]);
      PrintRequest->OwnerAddress->Region = KladrValueToStr(kladr_addr->Values["������"]);
      PrintRequest->OwnerAddress->Area = KladrValueToStr(kladr_addr->Values["�����"]);
      PrintRequest->OwnerAddress->City = KladrValueToStr(kladr_addr->Values["�����"]);
      PrintRequest->OwnerAddress->Place = KladrValueToStr(kladr_addr->Values["�������"]);
      PrintRequest->OwnerAddress->Street = KladrValueToStr(kladr_addr->Values["�����"]);
      PrintRequest->OwnerAddress->House = KladrValueToStr(kladr_addr->Values["���"]);
      PrintRequest->OwnerAddress->Building = KladrValueToStr(kladr_addr->Values["����� �������"]);
      PrintRequest->OwnerAddress->Flat = KladrValueToStr(kladr_addr->Values["��������"]);

      delete kladr_addr;

      if(q_vehicles->FieldByName("vehicle_type_id")->AsInteger == 3) PrintRequest->UnladenMass = q_vehicles->FieldByName("unladen_mass")->AsInteger;

      if(!q_policy->FieldByName("no_tehosmotr")->AsInteger){
         PrintRequest->InspectionDocument = new Document();
         PrintRequest->InspectionDocument->TypeCode = AnsiString(53);
         PrintRequest->InspectionDocument->Series = q_policy->FieldByName("tto_series")->AsString;
         PrintRequest->InspectionDocument->Number = q_policy->FieldByName("tto_number")->AsString;
         PrintRequest->InspectionDocument->IssueDate = new TXSDateTime();
         PrintRequest->InspectionDocument->IssueDate->AsDateTime = q_policy->FieldByName("tto_date")->AsDateTime.Val ? q_policy->FieldByName("tto_date")->AsDateTime : TDateTime(q_policy->FieldByName("tto_year")->AsInteger, q_policy->FieldByName("tto_month")->AsInteger, month_last_day[q_policy->FieldByName("tto_month")->AsInteger - 1]);
      }

      PrintRequest->Insurer = new PersonName();
      PrintRequest->Insurer->LastName = q_policy->FieldByName("is_e_policy")->AsInteger ? AnsiString("�������� �. �.") : q_insurer->FieldByName("saler_name_normal")->AsString;
   }
}
//---------------------------------------------------------------------------
void ThreadUFO::FillPrintClaimRequest(PrintRequest *PrintRequest)
{
   PrintRequest->PrintOnlyDocumentType = Claim;

   PrintRequest->Series = di->polis_seria;
   PrintRequest->Number = di->polis_number;
   PrintRequest->ContractDate = new TXSDateTime();
   PrintRequest->ContractDate->AsDateTime = Date();

   PrintRequest->Draft = true;
   PrintRequest->CalculationId = di->contract_id;

   if(!di->prev_seria.IsEmpty() && !di->prev_number.IsEmpty()){
      PrintRequest->PreviousPolicy = new PreviousPolicy();
      PrintRequest->PreviousPolicy->Series = di->prev_seria;
      PrintRequest->PreviousPolicy->Number = di->prev_number;
   }

   PrintRequest->SpecialNotes = empty_str;

   PrintRequest->InsurantAddress = new AddressEntry();
   PrintRequest->InsurantAddress->FullAddress = pi[0].address;
   PrintRequest->InsurantAddress->CountryCode = KladrValueToStr(pi[0].kladr_addr->Values["����������� ID"]).ToIntDef(643);
   PrintRequest->InsurantAddress->KladrCode = KladrValueToStr(pi[0].kladr_addr->Values["��� �����"].SubString(1, 11) + two_nulls);
   PrintRequest->InsurantAddress->PostCode = KladrValueToStr(pi[0].kladr_addr->Values["������"]);
   PrintRequest->InsurantAddress->Region = KladrValueToStr(pi[0].kladr_addr->Values["������"]);
   PrintRequest->InsurantAddress->Area = KladrValueToStr(pi[0].kladr_addr->Values["�����"]);
   PrintRequest->InsurantAddress->City = KladrValueToStr(pi[0].kladr_addr->Values["�����"]);
   PrintRequest->InsurantAddress->Place = KladrValueToStr(pi[0].kladr_addr->Values["�������"]);
   PrintRequest->InsurantAddress->Street = KladrValueToStr(pi[0].kladr_addr->Values["�����"]);
   PrintRequest->InsurantAddress->House = KladrValueToStr(pi[0].kladr_addr->Values["���"]);
   PrintRequest->InsurantAddress->Building = KladrValueToStr(pi[0].kladr_addr->Values["����� �������"]);
   PrintRequest->InsurantAddress->Flat = KladrValueToStr(pi[0].kladr_addr->Values["��������"]);

   PrintRequest->InsurantContacts = new Contacts();
   PrintRequest->InsurantContacts->MobilePhone = pi[0].phone_mobil;

   PrintRequest->OwnerAddress = new AddressEntry();
   PrintRequest->OwnerAddress->FullAddress = pi[1].address;
   PrintRequest->OwnerAddress->CountryCode = KladrValueToStr(pi[1].kladr_addr->Values["����������� ID"]).ToIntDef(643);
   PrintRequest->OwnerAddress->KladrCode = KladrValueToStr(pi[1].kladr_addr->Values["��� �����"].SubString(1, 11) + two_nulls);
   PrintRequest->OwnerAddress->PostCode = KladrValueToStr(pi[1].kladr_addr->Values["������"]);
   PrintRequest->OwnerAddress->Region = KladrValueToStr(pi[1].kladr_addr->Values["������"]);
   PrintRequest->OwnerAddress->Area = KladrValueToStr(pi[1].kladr_addr->Values["�����"]);
   PrintRequest->OwnerAddress->City = KladrValueToStr(pi[1].kladr_addr->Values["�����"]);
   PrintRequest->OwnerAddress->Place = KladrValueToStr(pi[1].kladr_addr->Values["�������"]);
   PrintRequest->OwnerAddress->Street = KladrValueToStr(pi[1].kladr_addr->Values["�����"]);
   PrintRequest->OwnerAddress->House = KladrValueToStr(pi[1].kladr_addr->Values["���"]);
   PrintRequest->OwnerAddress->Building = KladrValueToStr(pi[1].kladr_addr->Values["����� �������"]);
   PrintRequest->OwnerAddress->Flat = KladrValueToStr(pi[1].kladr_addr->Values["��������"]);

   if(vi->vehicle_type_id == 3) PrintRequest->UnladenMass = vi->unladen_mass;

   if(!di->no_tehosmotr){
      PrintRequest->InspectionDocument = new Document();
      PrintRequest->InspectionDocument->TypeCode = AnsiString(53);
      PrintRequest->InspectionDocument->Series = di->tto_series;
      PrintRequest->InspectionDocument->Number = di->tto_number;
      PrintRequest->InspectionDocument->IssueDate = new TXSDateTime();
      PrintRequest->InspectionDocument->IssueDate->AsDateTime = di->tto_date;
   }

   PrintRequest->Insurer = new PersonName();
   PrintRequest->Insurer->LastName = di->is_e_policy ? AnsiString("�������� �. �.") : di->user_info.name;
}
//---------------------------------------------------------------------------
void ThreadUFO::GetPDF(OperationResultOfArrayOfPrintResultgx6iBzRq *ArrayResultOfPrint)
{
   di->system_error = empty_str;
   di->validations_errors->Clear();
   di->data_print->Clear();

   int h, m;

   if(ArrayResultOfPrint->IsSuccess){
      for(int i = 0, cnt = ArrayResultOfPrint->Data.Length; i < cnt; ++i){
         //AnsiString n = ArrayResultOfPrint->Data[i]->Name;
         di->data_print->Add(ArrayResultOfPrint->Data[i]->Name + AnsiString("=") + ArrayResultOfPrint->Data[i]->Document);
         di->time_s = IncMinute(ArrayResultOfPrint->Data[i]->PrintDate->DateTime->AsDateTime, ArrayResultOfPrint->Data[i]->PrintDate->OffsetMinutes).FormatString("hh:nn");
      }
   }
   else{
      di->system_error = ArrayResultOfPrint->ErrorMessage;
      for(int i = 0, cnt = ArrayResultOfPrint->ValidationErrors.Length; i < cnt; ++i) di->validations_errors->Add(ArrayResultOfPrint->ValidationErrors[i]);
   }
}
//---------------------------------------------------------------------------
void ThreadUFO::FillAttachFileRequest(AttachFileRequest *AttachFileReq)
{
   AttachFileReq->ContractId = di->contract_id;
//   AttachFileReq->AutoApprove = true;

   TADOQuery *q_scan_docs = m_api->dbGetCursor(res, "select * from osago_scan_docs_temp order by number_doc");
   AttachFileReq->AttachmentFiles.Length = q_scan_docs->RecordCount;
   for(q_scan_docs->First(); !q_scan_docs->Eof; q_scan_docs->Next()){
      TFileStream *fs = new TFileStream(q_scan_docs->FieldByName("filepath")->AsString + q_scan_docs->FieldByName("filename_doc")->AsString, fmOpenRead);
      fs->Position = 0;
      AnsiString doc64;
      long buff_size = (long)fs->Size;
      byte *buff = new byte[buff_size];
      fs->ReadBuffer(buff, buff_size);
      delete fs;
      m_api->Internal_String2Buff(res, &doc64, &buff, &buff_size, true);
      delete [] buff; buff = 0;

      int index = q_scan_docs->RecNo - 1;
      AttachFileReq->AttachmentFiles[index] = new AttachmentFile();
      AttachFileReq->AttachmentFiles[index]->Name = q_scan_docs->FieldByName("filename_doc")->AsString;
      AttachFileReq->AttachmentFiles[index]->Data = doc64;
   }
   m_api->dbCloseCursor(res, q_scan_docs);
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfAttachFile(OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7 *ResultOfAttachFiles)
{
   if(ResultOfAttachFiles->IsSuccess){
      for(int i = 0, cnt = ResultOfAttachFiles->Data.Length; i < cnt; ++i){
         AnsiString document_id = ResultOfAttachFiles->Data[i]->key;
         AnsiString status_load = QuotedStr(!document_id.IsEmpty() ? "��������" : "�� ��������. ��������� ������� �������.");
         m_api->dbExecuteQuery(res, "update osago_scan_docs_temp set document_id=" + QuotedStr(document_id) + ", status_load=" + status_load + " where filename_doc=" + QuotedStr(ResultOfAttachFiles->Data[i]->value));
      }
   }
   else m_api->dbExecuteQuery(res, "update osago_scan_docs_temp set status_load='�� ��������. ��������� ������� �������.'");

   di->error_load_scans = ResultOfAttachFiles->ErrorMessage;
}
//---------------------------------------------------------------------------
void ThreadUFO::FillCheckPaymentRequest(CheckPaymentRequest *CheckPaymentReq)
{
   CheckPaymentReq->CodeSystemFrom = 33;
   CheckPaymentReq->CalculationId = di->contract_id;
   CheckPaymentReq->BranchCode = di->user_info.skk;
   switch(di->user_info.lnr.Length()){
      case 10:
      case 12: CheckPaymentReq->Lnr = di->user_info.lnr; break;
      default: CheckPaymentReq->Lnr = AddNulls(di->user_info.lnr, 8); break;
   }

   CheckPaymentReq->Payment = new NS_Osago2ProxyService::Payment();
   CheckPaymentReq->Payment->Series = di->polis_seria;
   CheckPaymentReq->Payment->Number = di->polis_number;
   CheckPaymentReq->Payment->PaymentMethod = di->payment_method_id;
   CheckPaymentReq->Payment->PaymentType = di->payment_id;
   CheckPaymentReq->Payment->PaymentDate = new TXSDateTime();
   CheckPaymentReq->Payment->PaymentDate->AsDateTime = di->pd_date;
   CheckPaymentReq->Payment->PaymentDocType = di->payment_doc_id;
   CheckPaymentReq->Payment->ReceiptSeries = di->pd_series;
   CheckPaymentReq->Payment->ReceiptNumber = di->pd_number;
   if(di->payment_method_id == 2) CheckPaymentReq->Payment->ConfirmCode = di->authorization_code;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfCheckPaymentRequest(OperationResultOfboolean *ResultOfCheckPayment)
{
   if((ResultOfCheckPayment->IsSuccess && ResultOfCheckPayment->Data) || (ResultOfCheckPayment->ValidationCodeErrors.Length == 1 && ResultOfCheckPayment->ValidationCodeErrors[0]->key == AnsiString("OSAGO_4467_10"))) di->no_check_payment = 0;
   else{
      di->no_check_payment = 1;
      di->check_payment_error = ResultOfCheckPayment->ErrorMessage;
   }
}
//---------------------------------------------------------------------------
void ThreadUFO::FillFindStoaRequest(FindServiceStationsRequest *findStoaRequest)
{
   findStoaRequest->PolicyTypeCode = AnsiString("006");
   if(!vi->is_foreign_registration && !vi->is_transit) findStoaRequest->KladrCode = di->RsaKtTerritoryId();
   findStoaRequest->ClassifierVehicleModelCode = vi->rsa_code;
   findStoaRequest->ManufactureYear = vi->construction_year;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfFindStoaRequest(OperationResultOfstring *ResultOfFindStoaRequest)
{
   di->stoa_request_id = empty_str;
   di->stoa_request_error = empty_str;

   if(ResultOfFindStoaRequest->IsSuccess) di->stoa_request_id = ResultOfFindStoaRequest->Data;
   else di->stoa_request_error = ResultOfFindStoaRequest->ErrorMessage;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfFindStoaResult(OperationResultOfFindResultoTurZuT3 *ResultOfFindStoaResult)
{
   di->stoa_result_error = empty_str;

   if(ResultOfFindStoaResult->IsSuccess){
      di->stoa_result_status = ResultOfFindStoaResult->Data->Status;
      m_api->dbExecuteQuery(res, "delete * from osago_stoa_temp");
      if(ResultOfFindStoaResult->Data->Status == Found){
         for(int i = 0, cnt = ResultOfFindStoaResult->Data->ServiceStations.Length; i < cnt; ++i){
            AnsiString sql("");
            m_api->dbExecuteQuery(res, sql.sprintf("insert into osago_stoa_temp (calc_id, stoa_number, stoa_id, stoa_name, stoa_address) values (0, %i, '%s', '%s', '%s')", i + 1, AnsiString(ResultOfFindStoaResult->Data->ServiceStations[i]->Id).c_str(), AnsiString(ResultOfFindStoaResult->Data->ServiceStations[i]->Name).c_str(), AnsiString(ResultOfFindStoaResult->Data->ServiceStations[i]->Address).c_str()));
         }

         AnsiString doc = ResultOfFindStoaResult->Data->Document;
         TMemoryStream *pdf = new TMemoryStream();
         CreatePDF(m_api, doc, pdf);
         pdf->SaveToFile(m_api->Excel_tmp_path + "\\����������.pdf");
         delete pdf;
      }
   }
   else di->stoa_result_error = ResultOfFindStoaResult->ErrorMessage;
}
//---------------------------------------------------------------------------
void ThreadUFO::FillVerificationCodeRequest(SendVerificationCodeRequest *sendVerificationCodeRequest)
{
   sendVerificationCodeRequest->ContractId = di->contract_id;
   sendVerificationCodeRequest->Mobile     = pi[0].phone_mobil;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfSendVerificationCodeRequest(OperationResultOfboolean *ResultOfSendVerificationCodeRequest)
{
   di->send_code = ResultOfSendVerificationCodeRequest->IsSuccess && ResultOfSendVerificationCodeRequest->Data ? 1 : 0;
   di->send_code_result_error = ResultOfSendVerificationCodeRequest->ErrorMessage;
}
//---------------------------------------------------------------------------
void ThreadUFO::FillConfirmVerificationCode(ConfirmVerificationCodeRequest *confirmVerificationCodeRequest)
{
   confirmVerificationCodeRequest->ContractId = di->contract_id;
   confirmVerificationCodeRequest->VerificationCode = di->verification_code;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfConfirmVerificationCode(OperationResultOfboolean *ResultOfConfirmVerificationCode)
{
   di->confirm_code = ResultOfConfirmVerificationCode->IsSuccess && ResultOfConfirmVerificationCode->Data ? 1 : 0;
   di->confirm_code_result_error = ResultOfConfirmVerificationCode->ErrorMessage;
}
//---------------------------------------------------------------------------
void ThreadUFO::FillCancelContractRequest(CancelContractRequest *cancelContractRequest)
{
   cancelContractRequest->ContractId = q_policy->FieldByName("contract_id")->AsString;
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromCancelContractResponse(OperationResultOfguid *ResultOfGuid)
{
   di->system_error = ResultOfGuid->IsSuccess ? empty_str : AnsiString(ResultOfGuid->ErrorMessage);
   if(ResultOfGuid->IsSuccess){
      di->status_cancel = 0;
      di->validations_errors->Clear();
      m_api->dbExecuteQuery(res, "update osago_policy set cancellation_id=" + QuotedStr(ResultOfGuid->Data) + " where calc_id=" + q_policy->FieldByName("calc_id")->AsString);
   }
   else{
      di->status_cancel = -1;
      for(int i = 0, cnt = ResultOfGuid->ValidationErrors.Length; i < cnt; ++i) di->validations_errors->Add(ResultOfGuid->ValidationErrors[i]);
   }
}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromCheckStatusOfCancelContractResponse(OperationResultOfStatusOfCancelContractResultoTurZuT3 *ResultOfCancelContract)
{
   di->system_error = ResultOfCancelContract->IsSuccess ? empty_str : AnsiString(ResultOfCancelContract->ErrorMessage);

   if(ResultOfCancelContract->IsSuccess) di->status_cancel = ResultOfCancelContract->Data->Status;
   else{
      di->status_cancel = -1;
      for(int i = 0, cnt = ResultOfCancelContract->ValidationErrors.Length; i < cnt; ++i) di->validations_errors->Add(ResultOfCancelContract->ValidationErrors[i]);
   }
}
//---------------------------------------------------------------------------

