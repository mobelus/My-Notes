// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>0
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>1
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>2
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>3
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>4
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>5
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>6
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>7
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>8
// Encoding : utf-8
// Codegen  : [wfMapStringsToWideStrings+, wfUseSerializerClassForAttrs-]
// Version  : 1.0
// (26.12.2017 17:54:26 - - $Rev: 19514 $)
// ************************************************************************ //

#include "UWriteSoap.h"
#pragma hdrstop

#if !defined(Osago2ProxyServiceH)
#include "OsagoProxyService.h"
#endif



namespace NS_Osago2ProxyService {

_di_IOsago2ProxyService GetIOsago2ProxyService(bool useWSDL, AnsiString addr, THTTPRIO* HTTPRIO)
{
  static const char* defWSDL= "https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl";
  static const char* defURL = "https://ufo-fe-test-01.rgs.ru/Osago2ProxyService.svc";
  static const char* defSvc = "Osago2ProxyService";
  static const char* defPrt = "BasicHttpsBinding_IOsago2ProxyService";
  if (addr=="")
    addr = useWSDL ? defWSDL : defURL;

  rio_be rbe;
  THTTPRIO *rio = HTTPRIO ? HTTPRIO : new THTTPRIO(0);
  rio->OnBeforeExecute = rbe.HTTPRIOBeforeExecute;
  rio->OnAfterExecute = rbe.HTTPRIOAfterExecute;

  if (useWSDL) {
    rio->WSDLLocation = addr;
    rio->Service = defSvc;
    rio->Port = defPrt;
  } else {
    rio->URL = addr;
  }
  _di_IOsago2ProxyService service;
  rio->QueryInterface(service);
  if (!service && !HTTPRIO)
    delete rio;
  return service;
}


__fastcall CalcRequest::~CalcRequest()
{
  delete FAgent;
  delete FAuto;
  delete FCalculationDate;
  delete FEndDate;
  delete FInsurant;
  delete FLogging;
  delete FOwner;
  delete FOwnerLicense;
  delete FStartDate;
  delete FUpdateRequest;
  for(int i=0; i<FPeriods.Length; i++)
    if (FPeriods[i])
      delete FPeriods[i];
  for(int i=0; i<FServiceStations.Length; i++)
    if (FServiceStations[i])
      delete FServiceStations[i];
}

__fastcall Auto::~Auto()
{
  delete FAllowWeight;
  delete FDocument;
  delete FPower;
  for(int i=0; i<FDocuments.Length; i++)
    if (FDocuments[i])
      delete FDocuments[i];
  for(int i=0; i<FDrivers.Length; i++)
    if (FDrivers[i])
      delete FDrivers[i];
}

__fastcall Document::~Document()
{
  delete FIssueDate;
}

__fastcall Counteragent::~Counteragent()
{
  delete FAddress;
  delete FBirthDate;
  delete FContacts;
  delete FDocument_;
  delete FName;
  delete FPrevDocument;
  delete FPrevName;
}

__fastcall Driver::~Driver()
{
  delete FBirthDate;
  delete FDriverAddedDate;
  delete FDrivingStartExperienceDate;
  delete FLicense;
  delete FName;
  delete FPrevLicense;
  delete FPrevName;
}

__fastcall PeriodOfUse::~PeriodOfUse()
{
  delete FEndDate;
  delete FStartDate;
}

__fastcall Coefficients::~Coefficients()
{
  delete FKbc;
  delete FKbm;
  delete FKc;
  delete FKm;
  delete FKn;
  delete FKo;
  delete FKp;
  delete FKpr;
  delete FKt;
  delete FTb;
}

__fastcall UpdateRequest::~UpdateRequest()
{
  delete FAuto;
  delete FCoefficients;
  delete FEndDate;
  delete FPremium;
  delete FReturnsSum;
  delete FStartDate;
}

__fastcall CalcResult::~CalcResult()
{
  delete FDateInsurancePremium;
  delete FK;
  delete FKbmRequestDate;
  delete FPremium;
  delete FPremiumModify;
  delete FRsaCheck;
  delete FSelectedVehicleDocument;
  delete FVehicleKbmRsa;
  for(int i=0; i<FClientReasons.Length; i++)
    if (FClientReasons[i])
      delete FClientReasons[i];
  for(int i=0; i<FDrivers.Length; i++)
    if (FDrivers[i])
      delete FDrivers[i];
}

__fastcall RSACheck::~RSACheck()
{
  delete FIdentificationInsurer;
  delete FInsurer;
  delete FOwner;
}

__fastcall DriverCalcResult::~DriverCalcResult()
{
  delete FBirthDate;
  delete FDriverLicense;
  delete FKbc;
  delete FKbmRsa;
  delete FRsaCheck;
}

__fastcall RSACheckResult::~RSACheckResult()
{
  delete FCheckDate;
}

__fastcall DriverKbmRsaCalcResult::~DriverKbmRsaCalcResult()
{
  delete FValue;
  for(int i=0; i<FDriverClaims.Length; i++)
    if (FDriverClaims[i])
      delete FDriverClaims[i];
}

__fastcall VehicleKbmRsaCalcResult::~VehicleKbmRsaCalcResult()
{
  for(int i=0; i<FRsaCheck.Length; i++)
    if (FRsaCheck[i])
      delete FRsaCheck[i];
  for(int i=0; i<FVehicleClaims.Length; i++)
    if (FVehicleClaims[i])
      delete FVehicleClaims[i];
}

__fastcall PrintRequest::~PrintRequest()
{
  delete FContractDate;
  delete FFirstPremium;
  delete FInspectionDocument;
  delete FInsurantAddress;
  delete FInsurantContacts;
  delete FInsurer;
  delete FOwnerAddress;
  delete FPolicyRefundDate;
  delete FPrevContractDate;
  delete FPreviousPolicy;
}

__fastcall FindResult::~FindResult()
{
  for(int i=0; i<FServiceStations.Length; i++)
    if (FServiceStations[i])
      delete FServiceStations[i];
}

__fastcall CheckPaymentRequest::~CheckPaymentRequest()
{
  delete FPayment;
}

__fastcall Payment::~Payment()
{
  delete FPaymentDate;
}

__fastcall AttachFileRequest::~AttachFileRequest()
{
  for(int i=0; i<FAttachmentFiles.Length; i++)
    if (FAttachmentFiles[i])
      delete FAttachmentFiles[i];
}

__fastcall ContractStatusRequest::~ContractStatusRequest()
{
  delete FCreationDate;
}

__fastcall DateTimeOffset::~DateTimeOffset()
{
  delete FDateTime;
}

__fastcall OperationResultOfStatusOfCancelContractResultoTurZuT3::~OperationResultOfStatusOfCancelContractResultoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfguid::~OperationResultOfguid()
{
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfContractStatusResponseoTurZuT3::~OperationResultOfContractStatusResponseoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7::~OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7()
{
  for(int i=0; i<FData.Length; i++)
    if (FData[i])
      delete FData[i];
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfboolean::~OperationResultOfboolean()
{
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfFindResultoTurZuT3::~OperationResultOfFindResultoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfstring::~OperationResultOfstring()
{
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfCalcResultoTurZuT3::~OperationResultOfCalcResultoTurZuT3()
{
  delete FData;
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall OperationResultOfArrayOfPrintResultgx6iBzRq::~OperationResultOfArrayOfPrintResultgx6iBzRq()
{
  for(int i=0; i<FData.Length; i++)
    if (FData[i])
      delete FData[i];
  for(int i=0; i<FGrouppedErrorMessage.Length; i++)
    if (FGrouppedErrorMessage[i])
      delete FGrouppedErrorMessage[i];
  for(int i=0; i<FValidationCodeErrors.Length; i++)
    if (FValidationCodeErrors[i])
      delete FValidationCodeErrors[i];
}

__fastcall PrintResult::~PrintResult()
{
  delete FPrintDate;
}

// ************************************************************************ //
// This routine registers the interfaces and types exposed by the WebService.
// ************************************************************************ //
static void RegTypes()
{
  /* IOsago2ProxyService */
  InvRegistry()->RegisterInterface(__delphirtti(IOsago2ProxyService), L"Rgs.Ufo", L"utf-8");
  InvRegistry()->RegisterDefaultSOAPAction(__delphirtti(IOsago2ProxyService), L"Rgs.Ufo/IOsago2ProxyService/%operationName%");
  InvRegistry()->RegisterInvokeOptions(__delphirtti(IOsago2ProxyService), ioDocument);
  /* User */
  RemClassRegistry()->RegisterXSClass(__classid(User), L"Rgs.Ufo", L"User");
  /* StationsType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(StationsType_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums", L"StationsType");
  /* ArrayOfPeriodOfUse */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPeriodOfUse), L"Rgs.Ufo", L"ArrayOfPeriodOfUse");
  /* RegistrationPlaceNames */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(RegistrationPlaceNames_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums", L"RegistrationPlaceNames");
  /* ArrayOfServiceStation */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfServiceStation), L"Rgs.Ufo", L"ArrayOfServiceStation");
  /* CalcRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalcRequest), L"Rgs.Ufo", L"CalcRequest");
  /* Logging */
  RemClassRegistry()->RegisterXSClass(__classid(Logging), L"Rgs.Ufo", L"Logging");
  /* Agent */
  RemClassRegistry()->RegisterXSClass(__classid(Agent), L"Rgs.Ufo", L"Agent");
  /* ArrayOfDocument */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDocument), L"Rgs.Ufo", L"ArrayOfDocument");
  /* ArrayOfDriver */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriver), L"Rgs.Ufo", L"ArrayOfDriver");
  /* Auto */
  RemClassRegistry()->RegisterXSClass(__classid(Auto), L"Rgs.Ufo", L"Auto");
  /* Document */
  RemClassRegistry()->RegisterXSClass(__classid(Document), L"Rgs.Ufo", L"Document");
  /* Counteragent */
  RemClassRegistry()->RegisterXSClass(__classid(Counteragent), L"Rgs.Ufo", L"Counteragent");
  RemClassRegistry()->RegisterExternalPropName(__typeinfo(Counteragent), L"Document_", L"Document");
  /* Driver */
  RemClassRegistry()->RegisterXSClass(__classid(Driver), L"Rgs.Ufo", L"Driver");
  /* PersonName */
  RemClassRegistry()->RegisterXSClass(__classid(PersonName), L"Rgs.Ufo", L"PersonName");
  /* AddressEntry */
  RemClassRegistry()->RegisterXSClass(__classid(AddressEntry), L"Rgs.Ufo", L"AddressEntry");
  /* Contacts */
  RemClassRegistry()->RegisterXSClass(__classid(Contacts), L"Rgs.Ufo", L"Contacts");
  /* PeriodOfUse */
  RemClassRegistry()->RegisterXSClass(__classid(PeriodOfUse), L"Rgs.Ufo", L"PeriodOfUse");
  /* ServiceStation */
  RemClassRegistry()->RegisterXSClass(__classid(ServiceStation), L"Rgs.Ufo", L"ServiceStation");
  /* Coefficients */
  RemClassRegistry()->RegisterXSClass(__classid(Coefficients), L"Rgs.Ufo", L"Coefficients");
  /* ArrayOfstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfstring), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfstring");
  /* UpdateRequest */
  RemClassRegistry()->RegisterXSClass(__classid(UpdateRequest), L"Rgs.Ufo", L"UpdateRequest");
  /* ArrayOfClientReason */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfClientReason), L"Rgs.Ufo", L"ArrayOfClientReason");
  /* ArrayOfDriverCalcResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriverCalcResult), L"Rgs.Ufo", L"ArrayOfDriverCalcResult");
  /* CalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(CalcResult), L"Rgs.Ufo", L"CalcResult");
  /* RSACheck */
  RemClassRegistry()->RegisterXSClass(__classid(RSACheck), L"Rgs.Ufo", L"RSACheck");
  /* ClientReason */
  RemClassRegistry()->RegisterXSClass(__classid(ClientReason), L"Rgs.Ufo", L"ClientReason");
  /* DriverCalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(DriverCalcResult), L"Rgs.Ufo", L"DriverCalcResult");
  /* RSACheckResult */
  RemClassRegistry()->RegisterXSClass(__classid(RSACheckResult), L"Rgs.Ufo", L"RSACheckResult");
  /* ArrayOfClaimResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfClaimResult), L"Rgs.Ufo", L"ArrayOfClaimResult");
  /* DriverKbmRsaCalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(DriverKbmRsaCalcResult), L"Rgs.Ufo", L"DriverKbmRsaCalcResult");
  /* ClaimResult */
  RemClassRegistry()->RegisterXSClass(__classid(ClaimResult), L"Rgs.Ufo", L"ClaimResult");
  /* ArrayOfVehicleRsaCheckResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleRsaCheckResult), L"Rgs.Ufo", L"ArrayOfVehicleRsaCheckResult");
  /* VehicleKbmRsaCalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleKbmRsaCalcResult), L"Rgs.Ufo", L"VehicleKbmRsaCalcResult");
  /* VehicleRsaCheckResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleRsaCheckResult), L"Rgs.Ufo", L"VehicleRsaCheckResult");
  /* PreviousPolicy */
  RemClassRegistry()->RegisterXSClass(__classid(PreviousPolicy), L"Rgs.Ufo", L"PreviousPolicy");
  /* PrintOnlyDocumentType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(PrintOnlyDocumentType_TypeInfoHolder)), L"Rgs.Ufo", L"PrintOnlyDocumentType");
  /* PrintRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintRequest), L"Rgs.Ufo", L"PrintRequest");
  /* FindServiceStationsRequest */
  RemClassRegistry()->RegisterXSClass(__classid(FindServiceStationsRequest), L"Rgs.Ufo", L"FindServiceStationsRequest");
  /* FindServiceStationsStatus */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(FindServiceStationsStatus_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.ServiceStations", L"FindServiceStationsStatus");
  /* FindResult */
  RemClassRegistry()->RegisterXSClass(__classid(FindResult), L"Rgs.Ufo", L"FindResult");
  /* CheckPaymentRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CheckPaymentRequest), L"Rgs.Ufo", L"CheckPaymentRequest");
  /* Payment */
  RemClassRegistry()->RegisterXSClass(__classid(Payment), L"Rgs.Ufo", L"Payment");
  /* ArrayOfAttachmentFile */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAttachmentFile), L"Rgs.Ufo", L"ArrayOfAttachmentFile");
  /* AttachFileRequest */
  RemClassRegistry()->RegisterXSClass(__classid(AttachFileRequest), L"Rgs.Ufo", L"AttachFileRequest");
  /* AttachmentFile */
  RemClassRegistry()->RegisterXSClass(__classid(AttachmentFile), L"Rgs.Ufo", L"AttachmentFile");
  /* SendVerificationCodeRequest */
  RemClassRegistry()->RegisterXSClass(__classid(SendVerificationCodeRequest), L"Rgs.Ufo", L"SendVerificationCodeRequest");
  /* ConfirmVerificationCodeRequest */
  RemClassRegistry()->RegisterXSClass(__classid(ConfirmVerificationCodeRequest), L"Rgs.Ufo", L"ConfirmVerificationCodeRequest");
  /* ContractStatusRequest */
  RemClassRegistry()->RegisterXSClass(__classid(ContractStatusRequest), L"Rgs.Ufo", L"ContractStatusRequest");
  /* ContractStatusResponse */
  RemClassRegistry()->RegisterXSClass(__classid(ContractStatusResponse), L"Rgs.Ufo", L"ContractStatusResponse");
  /* CancelContractRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CancelContractRequest), L"Rgs.Ufo", L"CancelContractRequest");
  /* StatusOfCancelContractResult */
  RemClassRegistry()->RegisterXSClass(__classid(StatusOfCancelContractResult), L"Rgs.Ufo", L"StatusOfCancelContractResult");
  /* User */
  RemClassRegistry()->RegisterXSClass(__classid(User2), L"Rgs.Ufo", L"User2", L"User");
  /* CalcRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CalcRequest2), L"Rgs.Ufo", L"CalcRequest2", L"CalcRequest");
  /* Agent */
  RemClassRegistry()->RegisterXSClass(__classid(Agent2), L"Rgs.Ufo", L"Agent2", L"Agent");
  /* Auto */
  RemClassRegistry()->RegisterXSClass(__classid(Auto2), L"Rgs.Ufo", L"Auto2", L"Auto");
  /* Document */
  RemClassRegistry()->RegisterXSClass(__classid(Document2), L"Rgs.Ufo", L"Document2", L"Document");
  /* ArrayOfDriver */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriver), L"Rgs.Ufo", L"ArrayOfDriver");
  /* Driver */
  RemClassRegistry()->RegisterXSClass(__classid(Driver2), L"Rgs.Ufo", L"Driver2", L"Driver");
  /* PersonName */
  RemClassRegistry()->RegisterXSClass(__classid(PersonName2), L"Rgs.Ufo", L"PersonName2", L"PersonName");
  /* Counteragent */
  RemClassRegistry()->RegisterXSClass(__classid(Counteragent2), L"Rgs.Ufo", L"Counteragent2", L"Counteragent");
  /* AddressEntry */
  RemClassRegistry()->RegisterXSClass(__classid(AddressEntry2), L"Rgs.Ufo", L"AddressEntry2", L"AddressEntry");
  /* Contacts */
  RemClassRegistry()->RegisterXSClass(__classid(Contacts2), L"Rgs.Ufo", L"Contacts2", L"Contacts");
  /* Logging */
  RemClassRegistry()->RegisterXSClass(__classid(Logging2), L"Rgs.Ufo", L"Logging2", L"Logging");
  /* PeriodOfUse */
  RemClassRegistry()->RegisterXSClass(__classid(PeriodOfUse2), L"Rgs.Ufo", L"PeriodOfUse2", L"PeriodOfUse");
  /* ServiceStation */
  RemClassRegistry()->RegisterXSClass(__classid(ServiceStation2), L"Rgs.Ufo", L"ServiceStation2", L"ServiceStation");
  /* UpdateRequest */
  RemClassRegistry()->RegisterXSClass(__classid(UpdateRequest2), L"Rgs.Ufo", L"UpdateRequest2", L"UpdateRequest");
  /* Coefficients */
  RemClassRegistry()->RegisterXSClass(__classid(Coefficients2), L"Rgs.Ufo", L"Coefficients2", L"Coefficients");
  /* CalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(CalcResult2), L"Rgs.Ufo", L"CalcResult2", L"CalcResult");
  /* ClientReason */
  RemClassRegistry()->RegisterXSClass(__classid(ClientReason2), L"Rgs.Ufo", L"ClientReason2", L"ClientReason");
  /* DriverCalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(DriverCalcResult2), L"Rgs.Ufo", L"DriverCalcResult2", L"DriverCalcResult");
  /* DriverKbmRsaCalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(DriverKbmRsaCalcResult2), L"Rgs.Ufo", L"DriverKbmRsaCalcResult2", L"DriverKbmRsaCalcResult");
  /* ClaimResult */
  RemClassRegistry()->RegisterXSClass(__classid(ClaimResult2), L"Rgs.Ufo", L"ClaimResult2", L"ClaimResult");
  /* RSACheckResult */
  RemClassRegistry()->RegisterXSClass(__classid(RSACheckResult2), L"Rgs.Ufo", L"RSACheckResult2", L"RSACheckResult");
  /* RSACheck */
  RemClassRegistry()->RegisterXSClass(__classid(RSACheck2), L"Rgs.Ufo", L"RSACheck2", L"RSACheck");
  /* VehicleKbmRsaCalcResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleKbmRsaCalcResult2), L"Rgs.Ufo", L"VehicleKbmRsaCalcResult2", L"VehicleKbmRsaCalcResult");
  /* VehicleRsaCheckResult */
  RemClassRegistry()->RegisterXSClass(__classid(VehicleRsaCheckResult2), L"Rgs.Ufo", L"VehicleRsaCheckResult2", L"VehicleRsaCheckResult");
  /* PrintRequest */
  RemClassRegistry()->RegisterXSClass(__classid(PrintRequest2), L"Rgs.Ufo", L"PrintRequest2", L"PrintRequest");
  /* PreviousPolicy */
  RemClassRegistry()->RegisterXSClass(__classid(PreviousPolicy2), L"Rgs.Ufo", L"PreviousPolicy2", L"PreviousPolicy");
  /* FindServiceStationsRequest */
  RemClassRegistry()->RegisterXSClass(__classid(FindServiceStationsRequest2), L"Rgs.Ufo", L"FindServiceStationsRequest2", L"FindServiceStationsRequest");
  /* FindResult */
  RemClassRegistry()->RegisterXSClass(__classid(FindResult2), L"Rgs.Ufo", L"FindResult2", L"FindResult");
  /* CheckPaymentRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CheckPaymentRequest2), L"Rgs.Ufo", L"CheckPaymentRequest2", L"CheckPaymentRequest");
  /* Payment */
  RemClassRegistry()->RegisterXSClass(__classid(Payment2), L"Rgs.Ufo", L"Payment2", L"Payment");
  /* AttachFileRequest */
  RemClassRegistry()->RegisterXSClass(__classid(AttachFileRequest2), L"Rgs.Ufo", L"AttachFileRequest2", L"AttachFileRequest");
  /* AttachmentFile */
  RemClassRegistry()->RegisterXSClass(__classid(AttachmentFile2), L"Rgs.Ufo", L"AttachmentFile2", L"AttachmentFile");
  /* SendVerificationCodeRequest */
  RemClassRegistry()->RegisterXSClass(__classid(SendVerificationCodeRequest2), L"Rgs.Ufo", L"SendVerificationCodeRequest2", L"SendVerificationCodeRequest");
  /* ConfirmVerificationCodeRequest */
  RemClassRegistry()->RegisterXSClass(__classid(ConfirmVerificationCodeRequest2), L"Rgs.Ufo", L"ConfirmVerificationCodeRequest2", L"ConfirmVerificationCodeRequest");
  /* ContractStatusRequest */
  RemClassRegistry()->RegisterXSClass(__classid(ContractStatusRequest2), L"Rgs.Ufo", L"ContractStatusRequest2", L"ContractStatusRequest");
  /* ContractStatusResponse */
  RemClassRegistry()->RegisterXSClass(__classid(ContractStatusResponse2), L"Rgs.Ufo", L"ContractStatusResponse2", L"ContractStatusResponse");
  /* CancelContractRequest */
  RemClassRegistry()->RegisterXSClass(__classid(CancelContractRequest2), L"Rgs.Ufo", L"CancelContractRequest2", L"CancelContractRequest");
  /* StatusOfCancelContractResult */
  RemClassRegistry()->RegisterXSClass(__classid(StatusOfCancelContractResult2), L"Rgs.Ufo", L"StatusOfCancelContractResult2", L"StatusOfCancelContractResult");
  /* DateTimeOffset */
  RemClassRegistry()->RegisterXSClass(__classid(DateTimeOffset), L"http://schemas.datacontract.org/2004/07/System", L"DateTimeOffset");
  /* RegistrationPlaceNames */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(RegistrationPlaceNames_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums", L"RegistrationPlaceNames");
  /* DateTimeOffset */
  RemClassRegistry()->RegisterXSClass(__classid(DateTimeOffset2), L"http://schemas.datacontract.org/2004/07/System", L"DateTimeOffset2", L"DateTimeOffset");
  /* ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* ArrayOfKeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringstring");
  /* OperationResultOfStatusOfCancelContractResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfStatusOfCancelContractResultoTurZuT3), L"RGS.UFO", L"OperationResultOfStatusOfCancelContractResultoTurZuT3");
  /* OperationResultOfguid */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfguid), L"RGS.UFO", L"OperationResultOfguid");
  /* OperationResultOfContractStatusResponseoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfContractStatusResponseoTurZuT3), L"RGS.UFO", L"OperationResultOfContractStatusResponseoTurZuT3");
  /* OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7), L"RGS.UFO", L"OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7");
  /* OperationResultOfboolean */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfboolean), L"RGS.UFO", L"OperationResultOfboolean");
  /* OperationResultOfFindResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfFindResultoTurZuT3), L"RGS.UFO", L"OperationResultOfFindResultoTurZuT3");
  /* OperationResultOfstring */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfstring), L"RGS.UFO", L"OperationResultOfstring");
  /* OperationResultOfCalcResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfCalcResultoTurZuT3), L"RGS.UFO", L"OperationResultOfCalcResultoTurZuT3");
  /* ArrayOfPrintResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrintResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models", L"ArrayOfPrintResult");
  /* OperationResultOfArrayOfPrintResultgx6iBzRq */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfPrintResultgx6iBzRq), L"RGS.UFO", L"OperationResultOfArrayOfPrintResultgx6iBzRq");
  /* OperationResultOfCalcResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfCalcResultoTurZuT32), L"RGS.UFO", L"OperationResultOfCalcResultoTurZuT32", L"OperationResultOfCalcResultoTurZuT3");
  /* OperationResultOfArrayOfPrintResultgx6iBzRq */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfPrintResultgx6iBzRq2), L"RGS.UFO", L"OperationResultOfArrayOfPrintResultgx6iBzRq2", L"OperationResultOfArrayOfPrintResultgx6iBzRq");
  /* OperationResultOfstring */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfstring2), L"RGS.UFO", L"OperationResultOfstring2", L"OperationResultOfstring");
  /* OperationResultOfFindResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfFindResultoTurZuT32), L"RGS.UFO", L"OperationResultOfFindResultoTurZuT32", L"OperationResultOfFindResultoTurZuT3");
  /* OperationResultOfboolean */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfboolean2), L"RGS.UFO", L"OperationResultOfboolean2", L"OperationResultOfboolean");
  /* OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp72), L"RGS.UFO", L"OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp72", L"OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7");
  /* OperationResultOfContractStatusResponseoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfContractStatusResponseoTurZuT32), L"RGS.UFO", L"OperationResultOfContractStatusResponseoTurZuT32", L"OperationResultOfContractStatusResponseoTurZuT3");
  /* OperationResultOfguid */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfguid2), L"RGS.UFO", L"OperationResultOfguid2", L"OperationResultOfguid");
  /* OperationResultOfStatusOfCancelContractResultoTurZuT3 */
  RemClassRegistry()->RegisterXSClass(__classid(OperationResultOfStatusOfCancelContractResultoTurZuT32), L"RGS.UFO", L"OperationResultOfStatusOfCancelContractResultoTurZuT32", L"OperationResultOfStatusOfCancelContractResultoTurZuT3");
  /* KeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* KeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringstring");
  /* KeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringArrayOfstringty7Ep6D12), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringArrayOfstringty7Ep6D12", L"KeyValuePairOfstringArrayOfstringty7Ep6D1");
  /* KeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSClass(__classid(KeyValuePairOfstringstring2), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"KeyValuePairOfstringstring2", L"KeyValuePairOfstringstring");
  /* PrintResult */
  RemClassRegistry()->RegisterXSClass(__classid(PrintResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models", L"PrintResult");
  /* PrintResult */
  RemClassRegistry()->RegisterXSClass(__classid(PrintResult2), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models", L"PrintResult2", L"PrintResult");
  /* ArrayOfPeriodOfUse */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPeriodOfUse), L"Rgs.Ufo", L"ArrayOfPeriodOfUse");
  /* ArrayOfDriverCalcResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDriverCalcResult), L"Rgs.Ufo", L"ArrayOfDriverCalcResult");
  /* ArrayOfVehicleRsaCheckResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfVehicleRsaCheckResult), L"Rgs.Ufo", L"ArrayOfVehicleRsaCheckResult");
  /* PrintOnlyDocumentType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(PrintOnlyDocumentType_TypeInfoHolder)), L"Rgs.Ufo", L"PrintOnlyDocumentType");
  /* ArrayOfAttachmentFile */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfAttachmentFile), L"Rgs.Ufo", L"ArrayOfAttachmentFile");
  /* ArrayOfstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfstring), L"http://schemas.microsoft.com/2003/10/Serialization/Arrays", L"ArrayOfstring");
  /* ArrayOfKeyValuePairOfstringstring */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringstring), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringstring");
  /* FindServiceStationsStatus */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(FindServiceStationsStatus_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.ServiceStations", L"FindServiceStationsStatus");
  /* ArrayOfServiceStation */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfServiceStation), L"Rgs.Ufo", L"ArrayOfServiceStation");
  /* ArrayOfClaimResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfClaimResult), L"Rgs.Ufo", L"ArrayOfClaimResult");
  /* StationsType */
  RemClassRegistry()->RegisterXSInfo(GetClsMemberTypeInfo(__typeinfo(StationsType_TypeInfoHolder)), L"http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums", L"StationsType");
  /* ArrayOfPrintResult */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfPrintResult), L"http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models", L"ArrayOfPrintResult");
  /* ArrayOfClientReason */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfClientReason), L"Rgs.Ufo", L"ArrayOfClientReason");
  /* ArrayOfDocument */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfDocument), L"Rgs.Ufo", L"ArrayOfDocument");
  /* ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 */
  RemClassRegistry()->RegisterXSInfo(__delphirtti(ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1), L"http://schemas.datacontract.org/2004/07/System.Collections.Generic", L"ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1");
}
#pragma startup RegTypes 32

};     // NS_Osago2ProxyService

