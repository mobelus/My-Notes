//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UApprove.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma resource "*.dfm"
TfrmApproveList *frmApproveList;
//---------------------------------------------------------------------------
__fastcall TfrmApproveList::TfrmApproveList(TComponent* Owner, Dogovor_Info *p_di, VehicleInfo *p_vi)
   : TForm(Owner), di(p_di), vi(p_vi)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmApproveList::FormShow(TObject *Sender)
{
   switch(Tag){
      case 0:
         Caption = "������� ������������";
         memApprove->Lines->Text = di->non_standart_str_calc->Text;
         break;
      case 1:
         Caption = "�������� �����";
         memApprove->Lines->Text = di->what_change->Text;
         break;
      case 2:
         Caption = "���������� � ���";
         memApprove->Lines->Text = vi->alarms_terms->Text;
         break;
   }
}
//---------------------------------------------------------------------------
void __fastcall TfrmApproveList::btnCloseClick(TObject *Sender)
{
   Close();   
}
//---------------------------------------------------------------------------
