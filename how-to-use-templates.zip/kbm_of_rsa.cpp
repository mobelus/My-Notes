//---------------------------------------------------------------------------
#pragma hdrstop
#include "kbm_of_rsa.h"
//---------------------------------------------------------------------------
kbm_of_rsa::kbm_of_rsa()
{
       //this->GetKbmTo=cf;

        mode=not_check; //�� ��������� � ��������� ������
        mw=kbm; //�� ��������� ����������� ���
        if(mdt.size()==0)
        {
                doctype_rsa dt;
                dt.id_doctype_rsa=1; dt.doctype_rsa_name= "������������� � ��������";mdt.insert(make_pair(1,dt));
                dt.id_doctype_rsa=2;dt.doctype_rsa_name="������������� �������� �������";mdt.insert(make_pair(2,dt));
                dt.id_doctype_rsa=3;dt.doctype_rsa_name="������� �� ������������ �� ����� ������� �������";mdt.insert(make_pair(3,dt));
                dt.id_doctype_rsa=4; dt.doctype_rsa_name="������� �����������";mdt.insert(make_pair(4,dt));
                dt.id_doctype_rsa=5; dt.doctype_rsa_name="������� ����� ������� (�������, ��������, ��������)";mdt.insert(make_pair(5,dt));
                dt.id_doctype_rsa=6; dt.doctype_rsa_name="��������������� ������� ���������� ��";mdt.insert(make_pair(6,dt));
                dt.id_doctype_rsa=7; dt.doctype_rsa_name="����������� �������";mdt.insert(make_pair(7,dt));
                dt.id_doctype_rsa=8; dt.doctype_rsa_name="������������� � ����������� ����������� ���������� � ��������� ��� ��������";mdt.insert(make_pair(8,dt));
                dt.id_doctype_rsa=9; dt.doctype_rsa_name="��� �� ����������";mdt.insert(make_pair(9,dt));
                dt.id_doctype_rsa=10; dt.doctype_rsa_name="������������� ������� � ��"; mdt.insert(make_pair(10,dt));
                dt.id_doctype_rsa=11; dt.doctype_rsa_name="��������� ������������� �������� ���������� ��";mdt.insert(make_pair(11,dt));
                dt.id_doctype_rsa=12; dt.doctype_rsa_name="������� ���������� ��";mdt.insert(make_pair(12,dt));
                dt.id_doctype_rsa=13; dt.doctype_rsa_name="������������� ���������� ��";mdt.insert(make_pair(13,dt));
                dt.id_doctype_rsa=14; dt.doctype_rsa_name="������������� � ��������, �������� �������������� ������� ������������ �����������";mdt.insert(make_pair(14,dt));
                dt.id_doctype_rsa=15; dt.doctype_rsa_name="������� ������";mdt.insert(make_pair(15,dt));
                dt.id_doctype_rsa=16; dt.doctype_rsa_name="������� ����� ������� ������";mdt.insert(make_pair(16,dt));
                dt.id_doctype_rsa=17; dt.doctype_rsa_name="���� ���������, ���������� �������� ���"; mdt.insert(make_pair(18,dt));
                dt.id_doctype_rsa=18; dt.doctype_rsa_name="������� ���������� ����"; mdt.insert(make_pair(19,dt));
                dt.id_doctype_rsa=19; dt.doctype_rsa_name="������������� ���������� ����"; mdt.insert(make_pair(20,dt));
                dt.id_doctype_rsa=20; dt.doctype_rsa_name="������������ ������������� ��"; mdt.insert(make_pair(17,dt));
                dt.id_doctype_rsa=21; dt.doctype_rsa_name="������������� � ������";mdt.insert(make_pair(22,dt));
                dt.id_doctype_rsa=22; dt.doctype_rsa_name="������������ ������������� ������������ �����������";mdt.insert(make_pair(24,dt));
                dt.id_doctype_rsa=23; dt.doctype_rsa_name="������ ���������";mdt.insert(make_pair(23,dt));
        }
        d_kbm=NewXMLDocument();
        d_kbm->Options=d_kbm->Options<<doNodeAutoIndent;
}
//----------------------------------------------------------------------------
AnsiString kbm_of_rsa::GetRSANormHash(AnsiString fiod)
{
       return Utf8ToAnsi(GetIdikbm(false, "http://dikbm.rgs.ru:8080/KBM_Prod/SePeZ_RSA_KBM.dll/soap/Idikbm")->GetGostRSANormHash(fiod));

}
//-----------------------------------------------------------------------------
void kbm_of_rsa::CalcKBM(CalcKBMReqType &c)
{
        if(mode!=not_check) //����������, ���� ��� ��������
     {

                bool check_ok=false;
                if(mode==auto_check)
                {
                    if(mw==kbm || mw==kbmto)
                    {
                        if(c.DriversRestrictions) //����������� ��� �� ���������� � ����������
                        {
                           check_ok=c.PhysicalPersons.size()>0 && c.DateKBM.Val!=0.0;
                           for(map<int, PhysicalPerson>::iterator it=c.PhysicalPersons.begin();it!=c.PhysicalPersons.end();++it)
                           check_ok=check_ok && it->second.LastName.Length()!=0 &&
                                    it->second.FirstName.Length()!=0 &&
                                //    it->second.SecondName.Length()!=0 &&
                                    it->second.BirthDate.Val!=0.0 &&
                                    it->second.DriverDocument.Serial.Length()>=1  &&
                                    it->second.DriverDocument.Serial.Length()<=4  &&
                                    it->second.DriverDocument.Number.Length()>=1  &&
                                    it->second.DriverDocument.Number.Length()<=20;
                        }
                        else//��� ���������� (�� ����������)
                        {
                                if(c.sp==fiz)  //���� �����
                                {
                                        map<int, PhysicalPerson>::iterator it=c.PhysicalPersons.begin();
                                        if(c.PhysicalPersons.size())
                                        check_ok=it->second.LastName.Length()!=0 &&
                                                 it->second.FirstName.Length()!=0 &&
                                         //        it->second.SecondName.Length()!=0 &&
                                                 it->second.BirthDate.Val!=0.0 &&
                                                 mdt.count(it->second.PersonDocument.DocPerson)==1 &&
                                                 it->second.PersonDocument.Serial.Length()>=1 &&
                                                 it->second.PersonDocument.Serial.Length()<=4 &&
                                                 it->second.PersonDocument.Number.Length()>=1 &&
                                                 it->second.PersonDocument.Number.Length()<=12;
                                        else check_ok=false;
                                }
                                else if(c.sp==yur) //���� ����
                                {
                                        check_ok=c.JuridicalPerson.OrgName.Length()!=0 &&
                                                 ((c.JuridicalPerson.Resident && c.JuridicalPerson.INN.Length()==10)
                                                  || !c.JuridicalPerson.Resident );

                                }

                                check_ok=check_ok &&  c.DateKBM.Val!=0.0 &&
                                  c.CarIndentType.LicensePlate.Length()>0
                                 ||   (// ������ � ������ 1.1. c.CarIndentType.LicensePlate.Length()>0  ||
                                    c.CarIndentType.VIN.Length()>0  ||
                                    c.CarIndentType.BodyNumber.Length()>0  ||
                                    c.CarIndentType.ChassisNumber.Length()>0) &&
                                    // ������ � ������ 1.1. c.CarIndentType.LicensePlate.Length()<=30 &&
                                    c.CarIndentType.VIN.Length()<=17 &&
                                    c.CarIndentType.BodyNumber.Length()<=24 &&
                                    c.CarIndentType.ChassisNumber.Length()<=24;
                        }
                    }
                    if(mw==to || mw==kbmto)
                    {

                     check_ok= (mw==to?true:check_ok) &&
                                 ( (c.CarIndentType.LicensePlate.Length()>0  || //������ ������ ��� ��
                                    c.CarIndentType.VIN.Length()>0  ||
                                    c.CarIndentType.BodyNumber.Length()>0  ||
                                    c.CarIndentType.ChassisNumber.Length()>0) &&
                                    c.CarIndentType.LicensePlate.Length()<=30 && //����� ������ ��� ��
                                    c.CarIndentType.VIN.Length()<=17 &&
                                    c.CarIndentType.BodyNumber.Length()<=24 &&
                                    c.CarIndentType.ChassisNumber.Length()<=24);

                    }
                }

      }

        d_kbm->LoadFromXML(xml_kbm);
        _di_IXMLNode root=d_kbm->DocumentElement;
         root->AddChild("InsurerID")->Text=InsurerId;

//REQKBM

        if(mw==kbm || mw==kbmto) //���� ����������� ��� ��� ��� ������ � ��
        {
                _di_IXMLNode req=root->AddChild("CalcKBMRequest");
                if(c.DriversRestrictions) //����������� ��� �� �����������
                {
                        req->AddChild("DriversRestriction")->Text =LowerCase(BoolToStr(c.DriversRestrictions,true));
                        req->AddChild("DateKBM")->Text=FormatDateTime("yyyy-mm-dd'T'hh:mm:ss",c.DateKBM);//  DateTimeToXSDateTime(c.DateKBM)->NativeToXS();
                        _di_IXMLNode pps=req->AddChild("PhysicalPersons");

                        for(map<int, PhysicalPerson>::iterator it=c.PhysicalPersons.begin();it!=c.PhysicalPersons.end();++it)
                        {
                                _di_IXMLNode  pp=pps->AddChild("PhysicalPerson");
                                _di_IXMLNode dd=pp->AddChild("DriverDocument");
                                dd->AddChild("Serial")->Text=it->second.DriverDocument.Serial;
                                dd->AddChild("Number")->Text=it->second.DriverDocument.Number;
                                pp->AddChild("PersonNameBirthHash")->Text=it->second.LastName+" "+it->second.FirstName+" "+it->second.SecondName+" "+FormatDateTime("dd.mm.yyyy",it->second.BirthDate);
                        }
                }
                else//��� ���������� (�� ����������)
                {
                        _di_IXMLNode car=req->AddChild("CarIdent");
                        car->AddChild("VIN")->Text=c.CarIndentType.VIN;
                        car->AddChild("BodyNumber")->Text=c.CarIndentType.BodyNumber;
                        car->AddChild("ChassisNumber")->Text=c.CarIndentType.ChassisNumber;

                        //������ ���� ��� ��� ����� ����� ������� ���.�����, ����� ������ ������"������ �����.�� � � ���� ����� ���"
                        if(c.CarIndentType.VIN.Trim().IsEmpty() && c.CarIndentType.BodyNumber.Trim().IsEmpty() && c.CarIndentType.ChassisNumber.Trim().IsEmpty())
                            req->AddChild("LicensePlate")->Text=c.CarIndentType.LicensePlate; //��������� � 1.4

                        req->AddChild("DriversRestriction")->Text =LowerCase(BoolToStr(c.DriversRestrictions,false));
                        req->AddChild("DateKBM")->Text=FormatDateTime("yyyy-mm-dd'T'hh:mm:ss",c.DateKBM);//  DateTimeToXSDateTime(c.DateKBM)->NativeToXS();
                        if(c.sp==fiz)  //���� �����
                        {
                                _di_IXMLNode pp=req->AddChild("PhysicalPersons")->AddChild("PhysicalPerson");
                                _di_IXMLNode doc=pp->AddChild("PersonDocument");
                                map<int, PhysicalPerson>::iterator it=c.PhysicalPersons.begin();
                                doc->AddChild("DocPerson")->Text=IntToStr(mdt.count(it->second.PersonDocument.DocPerson)?mdt[it->second.PersonDocument.DocPerson].id_doctype_rsa:1);
                                doc->AddChild("Serial")->Text=it->second.PersonDocument.Serial;
                                doc->AddChild("Number")->Text=it->second.PersonDocument.Number;
                                pp->AddChild("PersonNameBirthHash")->Text=it->second.LastName+" " +it->second.FirstName+" " +it->second.SecondName+" "+FormatDateTime("dd.mm.yyyy",it->second.BirthDate);
                        }
                        else if(c.sp==yur) //���� ����
                        {
                                 _di_IXMLNode jur=req->AddChild("JuridicalPerson")->AddChild("OrgID");
                                 jur->AddChild("Resident")->Text=(c.JuridicalPerson.Resident?"true":"false");
                                 jur->AddChild("INN")->Text=c.JuridicalPerson.INN;
                                 jur->AddChild("OrgName")->Text=c.JuridicalPerson.OrgName;
                        }
                }
        }

//TOREQUEST

        if(mw==to || mw==kbmto) //������ �� ���� ��� ����������� ��
        {
                _di_IXMLNode car=root->AddChild("TicketCarRequest")->AddChild("CarIdent");
                if(c.CarIndentType.LicensePlate.Length()>0)car->AddChild("LicensePlate")->Text=c.CarIndentType.LicensePlate;
                if(c.CarIndentType.VIN.Length()>0) car->AddChild("VIN")->Text=c.CarIndentType.VIN;
                if(c.CarIndentType.BodyNumber.Length()>0)car->AddChild("BodyNumber")->Text=c.CarIndentType.BodyNumber;
                if(c.CarIndentType.ChassisNumber.Length()>0)car->AddChild("ChassisNumber")->Text=c.CarIndentType.ChassisNumber;
        }


        //if(check_ok==check_ok)!!!!!!

        //�������� �������
        ClearCalcKBMReqType(c,true);

        this->XMLRequest=d_kbm->XML->Text;

        AnsiString xml = xml_request_begin + AnsiString(root->XML) + xml_request_end;
        //AnsiString xml = xml_request_begin + xml_test + xml_request_end;
        try {
            //xml=GetKbmTo(xml);
            /*WriteToLog(xml);*/
            xml= GetIdikbm()->GetKbmTo(xml);
        }
        catch(Exception &e)
        {
                ErrorInfo ei;
                ei.code=0;
                ei.Message=e.Message.c_str();
                c.rv.m_err.insert(make_pair(ei.code,ei));
                //WriteToLog("GetIdikbm()->GetKbmTo(xml) exception=" + e.Message);
                return;
        }



        this->XMLResponse=xml;
       ConvertXMLResponseToCalcKbmReqType(xml,c);
}

//------------------------------------------------------------------------------
void kbm_of_rsa::LoadPersonKBM(_di_IXMLNode c_kbm, return_value &rv)
{
        _di_IXMLNode t;
        t=c_kbm->ChildNodes->FindNode("ErrorInfo",L"");
        rv.ei.code=StrToInt(t->ChildNodes->FindNode("Code",L"")->Text);
        rv.ei.Message=t->ChildNodes->FindNode("Message",L"")->Text;
        t=c_kbm->ChildNodes->FindNode("KBMFirstLevel",L"");
        if(t)rv.KBMFirstLevel=t->Text;
        t=c_kbm->ChildNodes->FindNode("KBMNextLevel",L"");
        if(t)rv.KBMNextLevel=t->Text;
        t=c_kbm->ChildNodes->FindNode("KBMValue",L"");
        if(t)rv.KBMValue=StrToFloat(StringReplace(StringReplace(t->Text,".",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll),",",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll))  ;
        t=c_kbm->ChildNodes->FindNode("LossAmount",L"");
        if(t)rv.LossAmount =StrToFloat(StringReplace(StringReplace(t->Text,".",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll),",",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll))  ;
        map_loss ml;
        _di_IXMLNode lss=c_kbm->ChildNodes->FindNode("Losses",L"");
        if(lss)
        {
                for(int i=0; i<lss->ChildNodes->Count;i++)
                {
                        t=lss->ChildNodes->Nodes[i]->ChildNodes->FindNode("LossDateTime",L"");
                        if(t)
                        {
                                TXSDateTime *dt=new TXSDateTime();
                                dt->XSToNative(t->Text);
                                ml[i].LossDateTime=dt->AsDateTime;
                                delete dt;
                        }
                        t=lss->ChildNodes->Nodes[i]->ChildNodes->FindNode("PolicySerialKey",L"");
                        if(t)ml[i].PolicySerialKey=t->Text;
                        t=lss->ChildNodes->Nodes[i]->ChildNodes->FindNode("PolicyNumberKey",L"");
                        if(t) ml[i].PolicyNumberKey=t->Text;
                        t=lss->ChildNodes->Nodes[i]->ChildNodes->FindNode("InsurerName",L"");
                        if(t) ml[i].InsurerName=t->Text;
                }
        }
        rv.mloss=ml;
}
//------------------------------------------------------------------------------
void kbm_of_rsa::ConvertXMLRequestToCalcKbmReqType(AnsiString &XML,CalcKBMReqType &c)
{
        if(XML.IsEmpty()) return; 
        d_kbm->LoadFromXML(XML);
        _di_IXMLNode  root=d_kbm->DocumentElement,t,t1,t2,t3,t4;
        t=root->ChildNodes->FindNode("CalcKBMRequest");
        if(t)
        {
                t1=t->ChildNodes->FindNode("CarIdent");
                if(t1)
                {
                        t2=t1->ChildNodes->FindNode("LicensePlate");
                        if(t2) c.CarIndentType.LicensePlate=t2->Text;
                        else c.CarIndentType.LicensePlate="";

                        t2=t1->ChildNodes->FindNode("VIN");
                        if(t2) c.CarIndentType.VIN=t2->Text;
                        else c.CarIndentType.VIN="";
                        t2=t1->ChildNodes->FindNode("BodyNumber");
                        if(t2) c.CarIndentType.BodyNumber=t2->Text;
                        else c.CarIndentType.BodyNumber="";
                        t2=t1->ChildNodes->FindNode("ChassisNumber");
                        if(t2) c.CarIndentType.ChassisNumber=t2->Text;
                        else c.CarIndentType.ChassisNumber="";
                }
                else
                {
                        c.CarIndentType.LicensePlate="";
                        c.CarIndentType.VIN="";
                        c.CarIndentType.BodyNumber="";
                        c.CarIndentType.ChassisNumber="";
                }


                t1=t->ChildNodes->FindNode("DriversRestriction");
                if(t1)
                {
                        c.DriversRestrictions=StrToBool(t1->Text);
                        c.sp=not_defined;
                }
                t1=t->ChildNodes->FindNode("DateKBM");
                if(t1)
                {
                        TXSDateTime *dt=new TXSDateTime();
                        dt->XSToNative(t1->Text);
                        c.DateKBM=dt->AsDateTime;
                        delete dt;
                }
                t1=t->ChildNodes->FindNode("PhysicalPersons");
                if(t1)
                {
                        t2=t1->ChildNodes->FindNode("PhysicalPerson");
                        int i=0;
                        while(t2)
                        {

                               t3=t2->ChildNodes->FindNode("PersonNameBirthHash");
                               if(t3)
                               c.PhysicalPersons[i].Hash=t3->Text;
                               else
                               c.PhysicalPersons[i].Hash="";
                               t3=t2->ChildNodes->FindNode("PersonDocument");
                               if(t3)
                               {
                                        t4=t3->ChildNodes->FindNode("DocPerson");
                                        if(t4)
                                        {
                                                int dt_rsa=StrToInt(t4->Text);
                                                for(map_skk_to_rsa_doctype::iterator it=mdt.begin();it!=mdt.end();++it)
                                                {
                                                        if(it->second.id_doctype_rsa==dt_rsa)
                                                        {
                                                                c.PhysicalPersons[i].PersonDocument.DocPerson=it->first;
                                                                break;
                                                        }
                                                }
                                        }
                                        else
                                        c.PhysicalPersons[i].PersonDocument.DocPerson=0;


                                        t4=t3->ChildNodes->FindNode("Serial");
                                        if(t4)
                                        c.PhysicalPersons[i].PersonDocument.Serial=t4->Text;
                                        else
                                        c.PhysicalPersons[i].PersonDocument.Serial="";
                                        t4=t3->ChildNodes->FindNode("Number");
                                        if(t4)
                                        c.PhysicalPersons[i].PersonDocument.Number=t4->Text;
                                        else
                                        c.PhysicalPersons[i].PersonDocument.Number="";
                               }
                               else
                               {
                                c.PhysicalPersons[i].PersonDocument.DocPerson=0;
                                c.PhysicalPersons[i].PersonDocument.Serial="";
                                c.PhysicalPersons[i].PersonDocument.Number="";
                               }


                               t3=t2->ChildNodes->FindNode("DriverDocument");
                               if(t3)
                               {
                                        t4=t3->ChildNodes->FindNode("Serial");
                                        if(t4)
                                        c.PhysicalPersons[i].DriverDocument.Serial=t4->Text;
                                        else
                                        c.PhysicalPersons[i].DriverDocument.Serial="";
                                        t4=t3->ChildNodes->FindNode("Number");
                                        if(t4)
                                        c.PhysicalPersons[i].DriverDocument.Number=t4->Text;
                                        else
                                        c.PhysicalPersons[i].DriverDocument.Number="";
                               }
                               else
                               {
                                        c.PhysicalPersons[i].DriverDocument.Serial="";
                                        c.PhysicalPersons[i].DriverDocument.Number="";
                               }

                                i++;
                                try{t2=t2->NextSibling();}catch(...){t2=0;}//� ������� �������� ��� ��������, ���� �� ����� ����������. ������!!! � �������� ��������!!!
                        }


                }

                t1=t->ChildNodes->FindNode("JuridicalPerson");
                if(t1)
                {
                        if(c.DriversRestrictions==false)
                        c.sp=yur;

                        t2=t1->ChildNodes->FindNode("OrgID"); //�������� � ������ 1.1.
                        if(t2)
                        {
                              //������ � ������ 1.1. c.JuridicalPerson.Hash=t2->Text;
                                t3=t2->ChildNodes->FindNode("Resident");
                                if(t3 && !t3->Text.IsEmpty())
                                        c.JuridicalPerson.Resident=t3->Text==WideString("true")?true:false;
                                t3=t2->ChildNodes->FindNode("INN");
                                if(t3 && !t3->Text.IsEmpty())
                                        c.JuridicalPerson.INN=t3->Text;
                                t3=t2->ChildNodes->FindNode("OrgName");
                                if(t3 && !t3->Text.IsEmpty())
                                        c.JuridicalPerson.OrgName=t3->Text;
                        }

                }
                else
                {
                 if(c.DriversRestrictions==false)
                 c.sp=fiz;
                // c.JuridicalPerson.Hash="";
                 c.JuridicalPerson.Resident=false;
                 c.JuridicalPerson.INN="";
                 c.JuridicalPerson.OrgName="";
                }

        }
        t=root->ChildNodes->FindNode("TicketCarRequest");
        if(t)
        {
                t1=t->ChildNodes->FindNode("CarIdent");
                if(t1)
                {
                 t2=t1->ChildNodes->FindNode("LicensePlate");
                 if(t2)
                 c.CarIndentType.LicensePlate=t2->Text;
                 else
                 c.CarIndentType.LicensePlate="";
                 
                 t2=t1->ChildNodes->FindNode("VIN");
                 if(t2)
                 c.CarIndentType.VIN=t2->Text;
                 else
                 c.CarIndentType.VIN="";
                 t2=t1->ChildNodes->FindNode("BodyNumber");
                 if(t2)
                 c.CarIndentType.BodyNumber=t2->Text;
                 else
                 c.CarIndentType.BodyNumber="";
                 t2=t1->ChildNodes->FindNode("ChassisNumber");
                 if(t2)
                 c.CarIndentType.ChassisNumber=t2->Text;
                 else
                 c.CarIndentType.ChassisNumber="";
                }
                else
                {
                 c.CarIndentType.LicensePlate="";
                 c.CarIndentType.VIN="";
                 c.CarIndentType.BodyNumber="";
                 c.CarIndentType.ChassisNumber="";
                }
        }
}
//------------------------------------------------------------------------------
void kbm_of_rsa::ConvertXMLResponseToCalcKbmReqType(AnsiString &xml,CalcKBMReqType &c)
{
  if(xml=="") return;
  d_kbm->LoadFromXML(xml);
        d_kbm->Encoding="UTF-8";
      _di_IXMLNode  root=d_kbm->DocumentElement;
        //���������� ������ ��������� �������
        map_error merr;
        _di_IXMLNode d=root->ChildNodes->FindNode("ErrorList",L"");
        if(d)
        {
                for(int i=0; i<d->ChildNodes->Count;i++)
                {
                        _di_IXMLNode e=d->ChildNodes->Nodes[i];
                        if(e && e->NodeName==WideString("ErrorInfo"))
                        {
                                ErrorInfo ei;
                                ei.code=StrToInt(e->ChildNodes->FindNode("Code",L"")->Text);
                                ei.Message=e->ChildNodes->FindNode("Message",L"")->Text;
                                merr.insert(make_pair(ei.code,ei));
                        }

                }
        }

        c.rv.m_err=merr;

        if(merr.size()==1 && merr.count(3)==1) //������ ��������� �������
        {
                _di_IXMLNode  crv=root->ChildNodes->FindNode("CalcResponseValue",L"");
                if(crv)
                {
                        _di_IXMLNode t=crv->ChildNodes->FindNode("IdRequestCalc",L"");   //������������� �������
                        if(t) c.rv.IdRequestCalc=t->Text;
                        _di_IXMLNode p=crv->ChildNodes->FindNode("PolicyCalc",L"");
                        if(p) //������ �� ������
                        {
                                t=p->ChildNodes->FindNode("PolicySerialKey",L"");
                                if(t)c.rv.PolicyCalc.PolicySerialKey=t->Text;
                                t=p->ChildNodes->FindNode("PolicyNumberKey",L"");
                                if(t) c.rv.PolicyCalc.PolicyNumberKey=t->Text;
                                t=p->ChildNodes->FindNode("PolicyKBM",L"");
                                if(t) c.rv.PolicyCalc.PolicyKBM=t->Text;
                                t=p->ChildNodes->FindNode("PolicyKBMValue",L"");
                                if(t)c.rv.PolicyCalc.PolicyKBMValue=StrToFloat(StringReplace(StringReplace(t->Text,".",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll),",",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll))  ;
                                t=p->ChildNodes->FindNode("InsurerName",L"");
                                if(t) c.rv.PolicyCalc.InsurerName=t->Text;
                        }

                        _di_IXMLNode r_kbm=crv->ChildNodes-> FindNode("CalcKBMResponses",L"");
                        if(r_kbm)
                        {
                                _di_IXMLNode ei_kbm=r_kbm->ChildNodes->FindNode("ErrorInfo",L"");
                                if(ei_kbm)
                                {
                                        t=ei_kbm->ChildNodes->FindNode("Code",L"");
                                        if(t) c.rv.ei_kbm.code=StrToInt(t->Text);
                                        t=ei_kbm->ChildNodes->FindNode("Message",L"");
                                        if(t) c.rv.ei_kbm.Message=t->Text;
                                }

                                _di_IXMLNode c_kbm=r_kbm->ChildNodes->FindNode("CalcKBMResponse",L"");
                                while(c_kbm)
                                {
                                        if(c_kbm->NodeName==WideString("CalcKBMResponse")) // ��� �� �� ��������� �����-������ �����
                                        {



                                                if(c.DriversRestrictions==false && c.sp==yur) //��� �����
                                                {
                                                        //������ ����� �� ����� � ������ 1.1. if(c.JuridicalPerson.Hash/* c.JuridicalPerson.OrgName+c.JuridicalPerson.INN*/ ==fiod)
                                                        {
                                                                LoadPersonKBM(c_kbm,c.JuridicalPerson.rv);
                                                        }
                                                }
                                                else if(c.DriversRestrictions==true || (c.DriversRestrictions==false && c.sp==fiz))//��� �������
                                                {

                                                        AnsiString fiod=c_kbm->ChildNodes->FindNode(/*PersonNameBirthHash*/"Hash",L"")->Text;
                                                        map<int, PhysicalPerson>::iterator it;
                                                        for(it=c.PhysicalPersons.begin();it!=c.PhysicalPersons.end();++it)
                                                        {
                                                                if(it->second.Hash/*it->second.LastName+it->second.FirstName+it->second.SecondName+FormatDateTime("ddmmyyyy",it->second.BirthDate)*/ == fiod)
                                                                {
                                                                      LoadPersonKBM(c_kbm,it->second.rv);
                                                                      break;
                                                                }
                                                         }
                                                }
                                        }
                                        try{
                                        c_kbm=c_kbm->NextSibling(); //� ������� ��������, ��� �������� exception ����� �� ����� ����������, ��������, �� ����� 0 �������!
                                        }catch(...){c_kbm=0;}
                                }
                       }


                        _di_IXMLNode c_to=crv->ChildNodes->FindNode("TicketCarResponse",L"");
                        if(c_to)
                        {
                                _di_IXMLNode d=c_to->ChildNodes->FindNode("ErrorList",L"");
                                 if(d)
                                 {
                                        map_error merr;
                                        for(int i=0; i<d->ChildNodes->Count;i++)
                                        {
                                                _di_IXMLNode e=d->ChildNodes->Nodes[i];
                                                if(e && e->NodeName==WideString("ErrorInfo"))
                                                {
                                                        ErrorInfo ei;
                                                        ei.code=StrToInt(e->ChildNodes->FindNode("Code",L"")->Text);
                                                        ei.Message=e->ChildNodes->FindNode("Message",L"")->Text;
                                                        merr.insert(make_pair(ei.code,ei));
                                                }
                                        }
                                        c.CarIndentType.rv.m_err=merr;
                                  }
                                  d=c_to->ChildNodes->FindNode("TicketExisted",L"");
                                  if(d)c.CarIndentType.rv.TicketExisted= (UpperCase(d->Text)==UpperCase(WideString("True"))?true:false);
                                  d=c_to->ChildNodes->FindNode("DateNextTO",L"");  //�� ������������ ������ ������ � ������� mm.yyyy
                                  if(d)
                                  {

                                        /* AnsiString s=Trim(d->Text);
                                         if(!s.IsEmpty())
                                         {
                                             c.CarIndentType.rv.DateNextTOMonth=s.SubString(1,2).ToIntDef(0);
                                             c.CarIndentType.rv.DateNextTOYear=s.SubString(4,4).ToIntDef(0);
                                         }
                                         */


                                        TXSDate *dt=new TXSDate();
                                        dt->XSToNative(d->Text);
                                        c.CarIndentType.rv.DateNextTOMonth=dt->Month;
                                        c.CarIndentType.rv.DateNextTOYear=dt->Year;

                                        delete dt;



                                   }

                                   d=c_to->ChildNodes->FindNode("TicketDiagnosticDate",L"");
                                   if(d)
                                   {
                                        TXSDate *dt=new TXSDate();
                                        dt->XSToNative(d->Text);
                                        c.CarIndentType.rv.TicketDiagnosticDate=TDateTime(dt->Year,dt->Month,dt->Day);
                                        delete dt;
                                   }
                        }
                }
        }
}
//------------------------------------------------------------------------------
void kbm_of_rsa::ClearCalcKBMReqType(CalcKBMReqType &c, bool response_only)
{


 c.CarIndentType.rv.TicketExisted=false;
 c.CarIndentType.rv.DateNextTOMonth=0;
 c.CarIndentType.rv.DateNextTOYear=0;
 c.CarIndentType.rv.TicketDiagnosticDate.Val=0.0;
 c.CarIndentType.rv.m_err.clear();
 c.JuridicalPerson.rv.ei.code=0;
 c.JuridicalPerson.rv.ei.Message="";
 c.JuridicalPerson.rv.KBMFirstLevel="";
 c.JuridicalPerson.rv.KBMNextLevel="";
 c.JuridicalPerson.rv.KBMValue=0.0;
 c.JuridicalPerson.rv.LossAmount=0;
 c.JuridicalPerson.rv.mloss.clear();
 c.rv.m_err.clear();
 c.rv.IdRequestCalc="";
 c.rv.PolicyCalc.PolicySerialKey="";
 c.rv.PolicyCalc.PolicyNumberKey="";
 c.rv.PolicyCalc.PolicyKBM="";
 c.rv.PolicyCalc.PolicyKBMValue=0;
 c.rv.PolicyCalc.InsurerName="";
 c.rv.ei_kbm.code=0;
 c.rv.ei_kbm.Message="";
 for(map<int, PhysicalPerson>::iterator i=c.PhysicalPersons.begin();i!=c.PhysicalPersons.end();++i)
 {
        i->second.rv.ei.code=0;
        i->second.rv.ei.Message="";
        i->second.rv.KBMFirstLevel="";
        i->second.rv.KBMNextLevel="";
        i->second.rv.KBMValue=0.0;
        i->second.rv.LossAmount=0;
        i->second.rv.mloss.clear();
 }

 if(!response_only)
 {
 c.CarIndentType.LicensePlate="";
 c.CarIndentType.VIN="";
 c.CarIndentType.BodyNumber="";
 c.CarIndentType.ChassisNumber="";
 c.DriversRestrictions=false;
 c.DateKBM.Val=0.0;
 c.PhysicalPersons.clear();
 c.JuridicalPerson.Resident=false;
 c.JuridicalPerson.OrgName="";
 c.JuridicalPerson.INN="";
// ������ � ������ 1.1. c.JuridicalPerson.Hash="";
 c.sp=not_defined;
 }
}
//------------------------------------------------------------------------------
void kbm_of_rsa::GetCalcLoggedRequest(AnsiString ID,CalcKBMReqType &c)
{
        AnsiString xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                        "<rsa:CalcLoggedRequest xsi:schemaLocation=\"com/rsa/dkbm/schema-1.8 CalcLoggedRequest.xsd\" xmlns:rsa=\"com/rsa/dkbm/schema-1.8\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                         "<InsurerID>"+InsurerId+"</InsurerID>"
                         "<RSAResponseId>"+ID+"</RSAResponseId>"
                        "</rsa:CalcLoggedRequest>";
        try
        {
               if(m_api==NULL) throw Exception("kbm_of_rsa::GetCalcLoggedRequest,m_api==NULL!!!!");
                 int res=0;
                xml=Utf8ToAnsi(GetIdikbm(false,m_api->vrGetVariable(res,"URLKBMService"))->GetKbmToRequest(xml));
                xml=StringReplace(xml,"<?xml version=\"1.0\" standalone=\"yes\"?>","<?xml version=\"1.0\" encoding=\"Windows-1251\"?>",TReplaceFlags()<<rfReplaceAll);
                _di_IXMLDocument doc=NewXMLDocument();
                doc->LoadFromXML(xml);
                _di_IXMLNode request=doc->DocumentElement->ChildNodes->FindNode("CalcRequest",L"");
                _di_IXMLNode response=doc->DocumentElement->ChildNodes->FindNode("CalcResponse",L"");
                _di_IXMLNode err=doc->DocumentElement->ChildNodes->FindNode("ErrorList",L"");
                this->ConvertXMLRequestToCalcKbmReqType("<?xml version=\"1.0\" encoding=\"Windows-1251\"?>"+request->XML,c);
                this->ConvertXMLResponseToCalcKbmReqType("<?xml version=\"1.0\" encoding=\"Windows-1251\"?><ns2:CalcResponse xmlns:ns2=\"com/rsa/dkbm/schema-1.8\">" +err->XML +StringReplace(response->XML,"CalcResponse","CalcResponseValue",TReplaceFlags()<<rfReplaceAll)+"</ns2:CalcResponse>",c);
        }
        catch(Exception &e)
        {
              ;
        }
}
//------------------------------------------------------------------------------
#pragma package(smart_init)
