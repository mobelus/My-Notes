//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UErrors.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma resource "*.dfm"
TfrmErrReport *frmErrReport;
//---------------------------------------------------------------------------
__fastcall TfrmErrReport::TfrmErrReport(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmErrReport::btnCloseClick(TObject *Sender)
{
   Close();   
}
//---------------------------------------------------------------------------
