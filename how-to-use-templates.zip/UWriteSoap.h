//---------------------------------------------------------------------------

#ifndef UWriteSoapH
#define UWriteSoapH

//---------------------------------------------------------------------------
#define NO_WIN32_LEAN_AND_MEAN

#include <vcl.h>
//#include <shlobj.h>
#include "FastStrReplaceUnit.hpp"
#include "functions.h"
//#include <XMLDoc.hpp>
//---------------------------------------------------------------------------
namespace NS_Osago2ProxyService {

using namespace Faststrreplaceunit;

const TReplaceFlags rf(TReplaceFlags() << rfReplaceAll);

AnsiString GetPathDesktopUser()
{
   AnsiString desktop_folder("");

   LPITEMIDLIST pidl;
   LPMALLOC pShellMalloc;
   char szDir[MAX_PATH];

   if(SUCCEEDED(SHGetMalloc(&pShellMalloc))){
	  if(SUCCEEDED(SHGetSpecialFolderLocation(0, CSIDL_DESKTOPDIRECTORY, &pidl))){
		 if(SHGetPathFromIDList(pidl, szDir)) desktop_folder = IncludeTrailingBackslash(szDir);
		 pShellMalloc->Free(pidl);
	  }
	  pShellMalloc->Release();
   }

   return desktop_folder;
}
//---------------------------------------------------------------------------
class rio_be{

public:
   void __fastcall HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest);
   void __fastcall HTTPRIOAfterExecute(const AnsiString MethodName, TStream *SOAPResponse);
};

void __fastcall rio_be::HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest)
{
   if(MethodName != AnsiString("AttachFile")){

      SOAPRequest = FastStringReplace(SOAPRequest, "NULL", "nil", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<StartDate>", "<StartDate xmlns:d2p1=\"http://schemas.datacontract.org/2004/07/System\">", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<EndDate>", "<EndDate xmlns:d2p1=\"http://schemas.datacontract.org/2004/07/System\">", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<DriverAddedDate>", "<DriverAddedDate xmlns:d2p1=\"http://schemas.datacontract.org/2004/07/System\">", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<DateTime xsi:type=\"dateTime\">", "<d2p1:DateTime>", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "</DateTime>", "</d2p1:DateTime>", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<OffsetMinutes>", "<d2p1:OffsetMinutes>", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "</OffsetMinutes>", "</d2p1:OffsetMinutes>", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "Document_", "Document", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<ModifyReasonIds>", "<ModifyReasonIds xmlns:arr=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "<string>", "<arr:string>", rf);
      SOAPRequest = FastStringReplace(SOAPRequest, "</string>", "</arr:string>", rf);

      if(MethodName == AnsiString("Print")){
         SOAPRequest = FastStringReplace(SOAPRequest, "<ContractId>", "<ContractId xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rf);
         SOAPRequest = FastStringReplace(SOAPRequest, "<AtypicalNumber>", "<AtypicalNumber xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rf);
      }
   }

   TStringList *sl = new TStringList();
   sl->Text = SOAPRequest;
   sl->Text = FastStringReplace(sl->Text, "<UserName>apo</UserName>", "", rf);
   sl->Text = FastStringReplace(sl->Text, "<Password>popa</Password>", "", rf);
   sl->Text = FastStringReplace(sl->Text, "<Password>2FRuPqO$</Password>", "", rf);
   sl->Text = FastStringReplace(sl->Text, "<UserName>apo_2</UserName>", "", rf);
   sl->Text = FastStringReplace(sl->Text, "<Password>4VSxdY5sXqHN</Password>", "", rf);

   m_api->Internal_SetLastError("������ � ��� - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);
   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_req.xml");
   delete sl;
}
//---------------------------------------------------------------------------
void __fastcall rio_be::HTTPRIOAfterExecute(const AnsiString MethodName, TStream *SOAPResponse)
{
   SOAPResponse->Position = 0;
   TStringList *sl = new TStringList();
   sl->LoadFromStream(SOAPResponse);

   m_api->Internal_SetLastError("����� ��� - " + MethodName);
   m_api->Internal_SetLastError(Utf8ToAnsi(sl->Text));
   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_resp.xml");
   delete sl;
}
//---------------------------------------------------------------------------
};

#endif
