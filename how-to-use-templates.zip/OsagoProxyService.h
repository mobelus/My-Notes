// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>0
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>1
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>2
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>3
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>4
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>5
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>6
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>7
//  >Import : https://ufot.rgs.ru:10443/Osago2ProxyService.svc?singlewsdl>8
// Encoding : utf-8
// Codegen  : [wfMapStringsToWideStrings+, wfUseSerializerClassForAttrs-]
// Version  : 1.0
// (26.12.2017 17:54:26 - - $Rev: 19514 $)
// ************************************************************************ //

#ifndef   OsagoProxyServiceH
#define   OsagoProxyServiceH

#include <System.hpp>
#include <InvokeRegistry.hpp>
#include <XSBuiltIns.hpp>
#include <SOAPHTTPClient.hpp>

#if !defined(SOAP_REMOTABLE_CLASS)
#define SOAP_REMOTABLE_CLASS __declspec(delphiclass)
#endif
#if !defined(IS_OPTN)
#define IS_OPTN 0x0001
#endif
#if !defined(IS_UNBD)
#define IS_UNBD 0x0002
#endif
#if !defined(IS_NLBL)
#define IS_NLBL 0x0004
#endif
#if !defined(IS_REF)
#define IS_REF 0x0080
#endif


namespace NS_Osago2ProxyService {

// ************************************************************************ //
// The following types, referred to in the WSDL document are not being represented
// in this file. They are either aliases[@] of other types represented or were referred
// to but never[!] declared in the document. The types from the latter category
// typically map to predefined/known XML or Borland types; however, they could also 
// indicate incorrect WSDL documents that failed to declare or import a schema type.
// ************************************************************************ //
// !:string          - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:boolean         - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:int             - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:decimal         - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:dateTime        - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:base64Binary    - "http://www.w3.org/2001/XMLSchema"[Gbl]
// !:short           - "http://www.w3.org/2001/XMLSchema"[Gbl]

class SOAP_REMOTABLE_CLASS User;
class SOAP_REMOTABLE_CLASS CalcRequest;
class SOAP_REMOTABLE_CLASS Logging;
class SOAP_REMOTABLE_CLASS Agent;
class SOAP_REMOTABLE_CLASS Auto;
class SOAP_REMOTABLE_CLASS Document;
class SOAP_REMOTABLE_CLASS Counteragent;
class SOAP_REMOTABLE_CLASS Driver;
class SOAP_REMOTABLE_CLASS PersonName;
class SOAP_REMOTABLE_CLASS AddressEntry;
class SOAP_REMOTABLE_CLASS Contacts;
class SOAP_REMOTABLE_CLASS PeriodOfUse;
class SOAP_REMOTABLE_CLASS ServiceStation;
class SOAP_REMOTABLE_CLASS Coefficients;
class SOAP_REMOTABLE_CLASS UpdateRequest;
class SOAP_REMOTABLE_CLASS CalcResult;
class SOAP_REMOTABLE_CLASS RSACheck;
class SOAP_REMOTABLE_CLASS ClientReason;
class SOAP_REMOTABLE_CLASS DriverCalcResult;
class SOAP_REMOTABLE_CLASS RSACheckResult;
class SOAP_REMOTABLE_CLASS DriverKbmRsaCalcResult;
class SOAP_REMOTABLE_CLASS ClaimResult;
class SOAP_REMOTABLE_CLASS VehicleKbmRsaCalcResult;
class SOAP_REMOTABLE_CLASS VehicleRsaCheckResult;
class SOAP_REMOTABLE_CLASS PreviousPolicy;
class SOAP_REMOTABLE_CLASS PrintRequest;
class SOAP_REMOTABLE_CLASS FindServiceStationsRequest;
class SOAP_REMOTABLE_CLASS FindResult;
class SOAP_REMOTABLE_CLASS CheckPaymentRequest;
class SOAP_REMOTABLE_CLASS Payment;
class SOAP_REMOTABLE_CLASS AttachFileRequest;
class SOAP_REMOTABLE_CLASS AttachmentFile;
class SOAP_REMOTABLE_CLASS SendVerificationCodeRequest;
class SOAP_REMOTABLE_CLASS ConfirmVerificationCodeRequest;
class SOAP_REMOTABLE_CLASS ContractStatusRequest;
class SOAP_REMOTABLE_CLASS ContractStatusResponse;
class SOAP_REMOTABLE_CLASS CancelContractRequest;
class SOAP_REMOTABLE_CLASS StatusOfCancelContractResult;
class SOAP_REMOTABLE_CLASS User2;
class SOAP_REMOTABLE_CLASS CalcRequest2;
class SOAP_REMOTABLE_CLASS Agent2;
class SOAP_REMOTABLE_CLASS Auto2;
class SOAP_REMOTABLE_CLASS Document2;
class SOAP_REMOTABLE_CLASS Driver2;
class SOAP_REMOTABLE_CLASS PersonName2;
class SOAP_REMOTABLE_CLASS Counteragent2;
class SOAP_REMOTABLE_CLASS AddressEntry2;
class SOAP_REMOTABLE_CLASS Contacts2;
class SOAP_REMOTABLE_CLASS Logging2;
class SOAP_REMOTABLE_CLASS PeriodOfUse2;
class SOAP_REMOTABLE_CLASS ServiceStation2;
class SOAP_REMOTABLE_CLASS UpdateRequest2;
class SOAP_REMOTABLE_CLASS Coefficients2;
class SOAP_REMOTABLE_CLASS CalcResult2;
class SOAP_REMOTABLE_CLASS ClientReason2;
class SOAP_REMOTABLE_CLASS DriverCalcResult2;
class SOAP_REMOTABLE_CLASS DriverKbmRsaCalcResult2;
class SOAP_REMOTABLE_CLASS ClaimResult2;
class SOAP_REMOTABLE_CLASS RSACheckResult2;
class SOAP_REMOTABLE_CLASS RSACheck2;
class SOAP_REMOTABLE_CLASS VehicleKbmRsaCalcResult2;
class SOAP_REMOTABLE_CLASS VehicleRsaCheckResult2;
class SOAP_REMOTABLE_CLASS PrintRequest2;
class SOAP_REMOTABLE_CLASS PreviousPolicy2;
class SOAP_REMOTABLE_CLASS FindServiceStationsRequest2;
class SOAP_REMOTABLE_CLASS FindResult2;
class SOAP_REMOTABLE_CLASS CheckPaymentRequest2;
class SOAP_REMOTABLE_CLASS Payment2;
class SOAP_REMOTABLE_CLASS AttachFileRequest2;
class SOAP_REMOTABLE_CLASS AttachmentFile2;
class SOAP_REMOTABLE_CLASS SendVerificationCodeRequest2;
class SOAP_REMOTABLE_CLASS ConfirmVerificationCodeRequest2;
class SOAP_REMOTABLE_CLASS ContractStatusRequest2;
class SOAP_REMOTABLE_CLASS ContractStatusResponse2;
class SOAP_REMOTABLE_CLASS CancelContractRequest2;
class SOAP_REMOTABLE_CLASS StatusOfCancelContractResult2;
class SOAP_REMOTABLE_CLASS DateTimeOffset;
class SOAP_REMOTABLE_CLASS DateTimeOffset2;
class SOAP_REMOTABLE_CLASS OperationResultOfStatusOfCancelContractResultoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfguid;
class SOAP_REMOTABLE_CLASS OperationResultOfContractStatusResponseoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7;
class SOAP_REMOTABLE_CLASS OperationResultOfboolean;
class SOAP_REMOTABLE_CLASS OperationResultOfFindResultoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfstring;
class SOAP_REMOTABLE_CLASS OperationResultOfCalcResultoTurZuT3;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfPrintResultgx6iBzRq;
class SOAP_REMOTABLE_CLASS OperationResultOfCalcResultoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfPrintResultgx6iBzRq2;
class SOAP_REMOTABLE_CLASS OperationResultOfstring2;
class SOAP_REMOTABLE_CLASS OperationResultOfFindResultoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfboolean2;
class SOAP_REMOTABLE_CLASS OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp72;
class SOAP_REMOTABLE_CLASS OperationResultOfContractStatusResponseoTurZuT32;
class SOAP_REMOTABLE_CLASS OperationResultOfguid2;
class SOAP_REMOTABLE_CLASS OperationResultOfStatusOfCancelContractResultoTurZuT32;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringArrayOfstringty7Ep6D1;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringstring;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringArrayOfstringty7Ep6D12;
class SOAP_REMOTABLE_CLASS KeyValuePairOfstringstring2;
class SOAP_REMOTABLE_CLASS PrintResult;
class SOAP_REMOTABLE_CLASS PrintResult2;

enum StationsType   /* "http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums"[GblSmpl] */
{
  None,
  FromList,
  Other
};

class StationsType_TypeInfoHolder : public TObject {
  StationsType __instanceType;
public:
__published:
  __property StationsType __propType = { read=__instanceType };
};

enum RegistrationPlaceNames   /* "http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.Enums"[GblSmpl] */
{
  Rf,
  Foreign,
  Following
};

class RegistrationPlaceNames_TypeInfoHolder : public TObject {
  RegistrationPlaceNames __instanceType;
public:
__published:
  __property RegistrationPlaceNames __propType = { read=__instanceType };
};

enum PrintOnlyDocumentType   /* "Rgs.Ufo"[GblSmpl] */
{
  Default,
  Policy,
  Claim,
  PolicyForInsurer,
  ClaimForSKR,
  EOsagoCopy,
  RejectionServiceStation,
  ClientAccept,
  Notification
};

class PrintOnlyDocumentType_TypeInfoHolder : public TObject {
  PrintOnlyDocumentType __instanceType;
public:
__published:
  __property PrintOnlyDocumentType __propType = { read=__instanceType };
};

enum FindServiceStationsStatus   /* "http://schemas.datacontract.org/2004/07/Rgs.UFO.Model.ServiceStations"[GblSmpl] */
{
  Queued,
  Error,
  Empty,
  Found
};

class FindServiceStationsStatus_TypeInfoHolder : public TObject {
  FindServiceStationsStatus __instanceType;
public:
__published:
  __property FindServiceStationsStatus __propType = { read=__instanceType };
};



// ************************************************************************ //
// XML       : User, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class User : public TRemotable {
private:
  WideString      FPassword;
  WideString      FUserName;
__published:
  __property WideString   Password = { index=(IS_NLBL), read=FPassword, write=FPassword };
  __property WideString   UserName = { index=(IS_NLBL), read=FUserName, write=FUserName };
};


typedef WideString guid; /* "http://schemas.microsoft.com/2003/10/Serialization/"[GblSmpl] */
typedef DynamicArray<PeriodOfUse*> ArrayOfPeriodOfUse; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<ServiceStation*> ArrayOfServiceStation; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : CalcRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalcRequest : public TRemotable {
private:
  StationsType    FAddServiceStations;
  bool            FAddServiceStations_Specified;
  Agent*          FAgent;
  bool            FAgent_Specified;
  Auto*           FAuto;
  bool            FAuto_Specified;
  WideString      FAutoDealerId;
  bool            FAutoDealerId_Specified;
  WideString      FBankCode;
  bool            FBankCode_Specified;
  WideString      FBranchCode;
  bool            FBranchCode_Specified;
  DateTimeOffset* FCalculationDate;
  bool            FCalculationDate_Specified;
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  bool            FClientAccept;
  bool            FClientAccept_Specified;
  guid            FCorellationId;
  bool            FCorellationId_Specified;
  DateTimeOffset* FEndDate;
  bool            FEndDate_Specified;
  Counteragent*   FInsurant;
  bool            FInsurant_Specified;
  WideString      FInsurantCompanyId;
  bool            FInsurantCompanyId_Specified;
  bool            FIsAnyone;
  bool            FIsAnyone_Specified;
  bool            FIsExistsKasko;
  bool            FIsExistsKasko_Specified;
  bool            FIsGrossViolationsOfInsurance;
  bool            FIsGrossViolationsOfInsurance_Specified;
  bool            FIsPolicyPrintedFromEKIS;
  bool            FIsPolicyPrintedFromEKIS_Specified;
  bool            FIsPreCalculation;
  bool            FIsPreCalculation_Specified;
  bool            FIsRsaChecked;
  bool            FIsRsaChecked_Specified;
  bool            FIsUpdate;
  bool            FIsUpdate_Specified;
  WideString      FLeasingCompanyId;
  bool            FLeasingCompanyId_Specified;
  Logging*        FLogging;
  bool            FLogging_Specified;
  bool            FNeedKbmRequest;
  bool            FNeedKbmRequest_Specified;
  WideString      FOtherPartnerId;
  bool            FOtherPartnerId_Specified;
  Counteragent*   FOwner;
  bool            FOwner_Specified;
  Document*       FOwnerLicense;
  bool            FOwnerLicense_Specified;
  ArrayOfPeriodOfUse FPeriods;
  bool            FPeriods_Specified;
  WideString      FPolicyCheckSum;
  bool            FPolicyCheckSum_Specified;
  WideString      FPolicyRegion;
  bool            FPolicyRegion_Specified;
  WideString      FPrimaryUseKladr;
  bool            FPrimaryUseKladr_Specified;
  RegistrationPlaceNames FRegistrationPlace;
  bool            FRegistrationPlace_Specified;
  WideString      FSaleChannelType2008Id;
  bool            FSaleChannelType2008Id_Specified;
  ArrayOfServiceStation FServiceStations;
  bool            FServiceStations_Specified;
  DateTimeOffset* FStartDate;
  bool            FStartDate_Specified;
  UpdateRequest*  FUpdateRequest;
  bool            FUpdateRequest_Specified;
  void __fastcall SetAddServiceStations(int Index, StationsType _prop_val)
  {  FAddServiceStations = _prop_val; FAddServiceStations_Specified = true;  }
  bool __fastcall AddServiceStations_Specified(int Index)
  {  return FAddServiceStations_Specified;  } 
  void __fastcall SetAgent(int Index, Agent* _prop_val)
  {  FAgent = _prop_val; FAgent_Specified = true;  }
  bool __fastcall Agent_Specified(int Index)
  {  return FAgent_Specified;  } 
  void __fastcall SetAuto(int Index, Auto* _prop_val)
  {  FAuto = _prop_val; FAuto_Specified = true;  }
  bool __fastcall Auto_Specified(int Index)
  {  return FAuto_Specified;  } 
  void __fastcall SetAutoDealerId(int Index, WideString _prop_val)
  {  FAutoDealerId = _prop_val; FAutoDealerId_Specified = true;  }
  bool __fastcall AutoDealerId_Specified(int Index)
  {  return FAutoDealerId_Specified;  } 
  void __fastcall SetBankCode(int Index, WideString _prop_val)
  {  FBankCode = _prop_val; FBankCode_Specified = true;  }
  bool __fastcall BankCode_Specified(int Index)
  {  return FBankCode_Specified;  } 
  void __fastcall SetBranchCode(int Index, WideString _prop_val)
  {  FBranchCode = _prop_val; FBranchCode_Specified = true;  }
  bool __fastcall BranchCode_Specified(int Index)
  {  return FBranchCode_Specified;  } 
  void __fastcall SetCalculationDate(int Index, DateTimeOffset* _prop_val)
  {  FCalculationDate = _prop_val; FCalculationDate_Specified = true;  }
  bool __fastcall CalculationDate_Specified(int Index)
  {  return FCalculationDate_Specified;  } 
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetClientAccept(int Index, bool _prop_val)
  {  FClientAccept = _prop_val; FClientAccept_Specified = true;  }
  bool __fastcall ClientAccept_Specified(int Index)
  {  return FClientAccept_Specified;  } 
  void __fastcall SetCorellationId(int Index, guid _prop_val)
  {  FCorellationId = _prop_val; FCorellationId_Specified = true;  }
  bool __fastcall CorellationId_Specified(int Index)
  {  return FCorellationId_Specified;  } 
  void __fastcall SetEndDate(int Index, DateTimeOffset* _prop_val)
  {  FEndDate = _prop_val; FEndDate_Specified = true;  }
  bool __fastcall EndDate_Specified(int Index)
  {  return FEndDate_Specified;  } 
  void __fastcall SetInsurant(int Index, Counteragent* _prop_val)
  {  FInsurant = _prop_val; FInsurant_Specified = true;  }
  bool __fastcall Insurant_Specified(int Index)
  {  return FInsurant_Specified;  } 
  void __fastcall SetInsurantCompanyId(int Index, WideString _prop_val)
  {  FInsurantCompanyId = _prop_val; FInsurantCompanyId_Specified = true;  }
  bool __fastcall InsurantCompanyId_Specified(int Index)
  {  return FInsurantCompanyId_Specified;  } 
  void __fastcall SetIsAnyone(int Index, bool _prop_val)
  {  FIsAnyone = _prop_val; FIsAnyone_Specified = true;  }
  bool __fastcall IsAnyone_Specified(int Index)
  {  return FIsAnyone_Specified;  } 
  void __fastcall SetIsExistsKasko(int Index, bool _prop_val)
  {  FIsExistsKasko = _prop_val; FIsExistsKasko_Specified = true;  }
  bool __fastcall IsExistsKasko_Specified(int Index)
  {  return FIsExistsKasko_Specified;  } 
  void __fastcall SetIsGrossViolationsOfInsurance(int Index, bool _prop_val)
  {  FIsGrossViolationsOfInsurance = _prop_val; FIsGrossViolationsOfInsurance_Specified = true;  }
  bool __fastcall IsGrossViolationsOfInsurance_Specified(int Index)
  {  return FIsGrossViolationsOfInsurance_Specified;  } 
  void __fastcall SetIsPolicyPrintedFromEKIS(int Index, bool _prop_val)
  {  FIsPolicyPrintedFromEKIS = _prop_val; FIsPolicyPrintedFromEKIS_Specified = true;  }
  bool __fastcall IsPolicyPrintedFromEKIS_Specified(int Index)
  {  return FIsPolicyPrintedFromEKIS_Specified;  } 
  void __fastcall SetIsPreCalculation(int Index, bool _prop_val)
  {  FIsPreCalculation = _prop_val; FIsPreCalculation_Specified = true;  }
  bool __fastcall IsPreCalculation_Specified(int Index)
  {  return FIsPreCalculation_Specified;  } 
  void __fastcall SetIsRsaChecked(int Index, bool _prop_val)
  {  FIsRsaChecked = _prop_val; FIsRsaChecked_Specified = true;  }
  bool __fastcall IsRsaChecked_Specified(int Index)
  {  return FIsRsaChecked_Specified;  } 
  void __fastcall SetIsUpdate(int Index, bool _prop_val)
  {  FIsUpdate = _prop_val; FIsUpdate_Specified = true;  }
  bool __fastcall IsUpdate_Specified(int Index)
  {  return FIsUpdate_Specified;  } 
  void __fastcall SetLeasingCompanyId(int Index, WideString _prop_val)
  {  FLeasingCompanyId = _prop_val; FLeasingCompanyId_Specified = true;  }
  bool __fastcall LeasingCompanyId_Specified(int Index)
  {  return FLeasingCompanyId_Specified;  } 
  void __fastcall SetLogging(int Index, Logging* _prop_val)
  {  FLogging = _prop_val; FLogging_Specified = true;  }
  bool __fastcall Logging_Specified(int Index)
  {  return FLogging_Specified;  } 
  void __fastcall SetNeedKbmRequest(int Index, bool _prop_val)
  {  FNeedKbmRequest = _prop_val; FNeedKbmRequest_Specified = true;  }
  bool __fastcall NeedKbmRequest_Specified(int Index)
  {  return FNeedKbmRequest_Specified;  } 
  void __fastcall SetOtherPartnerId(int Index, WideString _prop_val)
  {  FOtherPartnerId = _prop_val; FOtherPartnerId_Specified = true;  }
  bool __fastcall OtherPartnerId_Specified(int Index)
  {  return FOtherPartnerId_Specified;  } 
  void __fastcall SetOwner(int Index, Counteragent* _prop_val)
  {  FOwner = _prop_val; FOwner_Specified = true;  }
  bool __fastcall Owner_Specified(int Index)
  {  return FOwner_Specified;  } 
  void __fastcall SetOwnerLicense(int Index, Document* _prop_val)
  {  FOwnerLicense = _prop_val; FOwnerLicense_Specified = true;  }
  bool __fastcall OwnerLicense_Specified(int Index)
  {  return FOwnerLicense_Specified;  } 
  void __fastcall SetPeriods(int Index, ArrayOfPeriodOfUse _prop_val)
  {  FPeriods = _prop_val; FPeriods_Specified = true;  }
  bool __fastcall Periods_Specified(int Index)
  {  return FPeriods_Specified;  } 
  void __fastcall SetPolicyCheckSum(int Index, WideString _prop_val)
  {  FPolicyCheckSum = _prop_val; FPolicyCheckSum_Specified = true;  }
  bool __fastcall PolicyCheckSum_Specified(int Index)
  {  return FPolicyCheckSum_Specified;  } 
  void __fastcall SetPolicyRegion(int Index, WideString _prop_val)
  {  FPolicyRegion = _prop_val; FPolicyRegion_Specified = true;  }
  bool __fastcall PolicyRegion_Specified(int Index)
  {  return FPolicyRegion_Specified;  } 
  void __fastcall SetPrimaryUseKladr(int Index, WideString _prop_val)
  {  FPrimaryUseKladr = _prop_val; FPrimaryUseKladr_Specified = true;  }
  bool __fastcall PrimaryUseKladr_Specified(int Index)
  {  return FPrimaryUseKladr_Specified;  } 
  void __fastcall SetRegistrationPlace(int Index, RegistrationPlaceNames _prop_val)
  {  FRegistrationPlace = _prop_val; FRegistrationPlace_Specified = true;  }
  bool __fastcall RegistrationPlace_Specified(int Index)
  {  return FRegistrationPlace_Specified;  } 
  void __fastcall SetSaleChannelType2008Id(int Index, WideString _prop_val)
  {  FSaleChannelType2008Id = _prop_val; FSaleChannelType2008Id_Specified = true;  }
  bool __fastcall SaleChannelType2008Id_Specified(int Index)
  {  return FSaleChannelType2008Id_Specified;  } 
  void __fastcall SetServiceStations(int Index, ArrayOfServiceStation _prop_val)
  {  FServiceStations = _prop_val; FServiceStations_Specified = true;  }
  bool __fastcall ServiceStations_Specified(int Index)
  {  return FServiceStations_Specified;  } 
  void __fastcall SetStartDate(int Index, DateTimeOffset* _prop_val)
  {  FStartDate = _prop_val; FStartDate_Specified = true;  }
  bool __fastcall StartDate_Specified(int Index)
  {  return FStartDate_Specified;  } 
  void __fastcall SetUpdateRequest(int Index, UpdateRequest* _prop_val)
  {  FUpdateRequest = _prop_val; FUpdateRequest_Specified = true;  }
  bool __fastcall UpdateRequest_Specified(int Index)
  {  return FUpdateRequest_Specified;  } 

public:
  __fastcall ~CalcRequest();
__published:
  __property StationsType AddServiceStations = { index=(IS_OPTN|IS_NLBL), read=FAddServiceStations, write=SetAddServiceStations, stored = AddServiceStations_Specified };
  __property Agent*          Agent = { index=(IS_OPTN|IS_NLBL), read=FAgent, write=SetAgent, stored = Agent_Specified };
  __property Auto*            Auto = { index=(IS_OPTN|IS_NLBL), read=FAuto, write=SetAuto, stored = Auto_Specified };
  __property WideString AutoDealerId = { index=(IS_OPTN|IS_NLBL), read=FAutoDealerId, write=SetAutoDealerId, stored = AutoDealerId_Specified };
  __property WideString   BankCode = { index=(IS_OPTN|IS_NLBL), read=FBankCode, write=SetBankCode, stored = BankCode_Specified };
  __property WideString BranchCode = { index=(IS_OPTN|IS_NLBL), read=FBranchCode, write=SetBranchCode, stored = BranchCode_Specified };
  __property DateTimeOffset* CalculationDate = { index=(IS_OPTN|IS_NLBL), read=FCalculationDate, write=SetCalculationDate, stored = CalculationDate_Specified };
  __property guid       CalculationId = { index=(IS_OPTN|IS_NLBL), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property bool       ClientAccept = { index=(IS_OPTN|IS_NLBL), read=FClientAccept, write=SetClientAccept, stored = ClientAccept_Specified };
  __property guid       CorellationId = { index=(IS_OPTN|IS_NLBL), read=FCorellationId, write=SetCorellationId, stored = CorellationId_Specified };
  __property DateTimeOffset*    EndDate = { index=(IS_OPTN|IS_NLBL), read=FEndDate, write=SetEndDate, stored = EndDate_Specified };
  __property Counteragent*   Insurant = { index=(IS_OPTN|IS_NLBL), read=FInsurant, write=SetInsurant, stored = Insurant_Specified };
  __property WideString InsurantCompanyId = { index=(IS_OPTN|IS_NLBL), read=FInsurantCompanyId, write=SetInsurantCompanyId, stored = InsurantCompanyId_Specified };
  __property bool         IsAnyone = { index=(IS_OPTN), read=FIsAnyone, write=SetIsAnyone, stored = IsAnyone_Specified };
  __property bool       IsExistsKasko = { index=(IS_OPTN|IS_NLBL), read=FIsExistsKasko, write=SetIsExistsKasko, stored = IsExistsKasko_Specified };
  __property bool       IsGrossViolationsOfInsurance = { index=(IS_OPTN), read=FIsGrossViolationsOfInsurance, write=SetIsGrossViolationsOfInsurance, stored = IsGrossViolationsOfInsurance_Specified };
  __property bool       IsPolicyPrintedFromEKIS = { index=(IS_OPTN|IS_NLBL), read=FIsPolicyPrintedFromEKIS, write=SetIsPolicyPrintedFromEKIS, stored = IsPolicyPrintedFromEKIS_Specified };
  __property bool       IsPreCalculation = { index=(IS_OPTN), read=FIsPreCalculation, write=SetIsPreCalculation, stored = IsPreCalculation_Specified };
  __property bool       IsRsaChecked = { index=(IS_OPTN|IS_NLBL), read=FIsRsaChecked, write=SetIsRsaChecked, stored = IsRsaChecked_Specified };
  __property bool         IsUpdate = { index=(IS_OPTN|IS_NLBL), read=FIsUpdate, write=SetIsUpdate, stored = IsUpdate_Specified };
  __property WideString LeasingCompanyId = { index=(IS_OPTN|IS_NLBL), read=FLeasingCompanyId, write=SetLeasingCompanyId, stored = LeasingCompanyId_Specified };
  __property Logging*      Logging = { index=(IS_OPTN|IS_NLBL), read=FLogging, write=SetLogging, stored = Logging_Specified };
  __property bool       NeedKbmRequest = { index=(IS_OPTN|IS_NLBL), read=FNeedKbmRequest, write=SetNeedKbmRequest, stored = NeedKbmRequest_Specified };
  __property WideString OtherPartnerId = { index=(IS_OPTN|IS_NLBL), read=FOtherPartnerId, write=SetOtherPartnerId, stored = OtherPartnerId_Specified };
  __property Counteragent*      Owner = { index=(IS_OPTN|IS_NLBL), read=FOwner, write=SetOwner, stored = Owner_Specified };
  __property Document*  OwnerLicense = { index=(IS_OPTN|IS_NLBL), read=FOwnerLicense, write=SetOwnerLicense, stored = OwnerLicense_Specified };
  __property ArrayOfPeriodOfUse    Periods = { index=(IS_OPTN|IS_NLBL), read=FPeriods, write=SetPeriods, stored = Periods_Specified };
  __property WideString PolicyCheckSum = { index=(IS_OPTN|IS_NLBL), read=FPolicyCheckSum, write=SetPolicyCheckSum, stored = PolicyCheckSum_Specified };
  __property WideString PolicyRegion = { index=(IS_OPTN|IS_NLBL), read=FPolicyRegion, write=SetPolicyRegion, stored = PolicyRegion_Specified };
  __property WideString PrimaryUseKladr = { index=(IS_OPTN|IS_NLBL), read=FPrimaryUseKladr, write=SetPrimaryUseKladr, stored = PrimaryUseKladr_Specified };
  __property RegistrationPlaceNames RegistrationPlace = { index=(IS_OPTN|IS_NLBL), read=FRegistrationPlace, write=SetRegistrationPlace, stored = RegistrationPlace_Specified };
  __property WideString SaleChannelType2008Id = { index=(IS_OPTN|IS_NLBL), read=FSaleChannelType2008Id, write=SetSaleChannelType2008Id, stored = SaleChannelType2008Id_Specified };
  __property ArrayOfServiceStation ServiceStations = { index=(IS_OPTN|IS_NLBL), read=FServiceStations, write=SetServiceStations, stored = ServiceStations_Specified };
  __property DateTimeOffset*  StartDate = { index=(IS_OPTN|IS_NLBL), read=FStartDate, write=SetStartDate, stored = StartDate_Specified };
  __property UpdateRequest* UpdateRequest = { index=(IS_OPTN|IS_NLBL), read=FUpdateRequest, write=SetUpdateRequest, stored = UpdateRequest_Specified };
};




// ************************************************************************ //
// XML       : Logging, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Logging : public TRemotable {
private:
  int             FQuotationId;
  bool            FQuotationId_Specified;
  guid            FSessionId;
  bool            FSessionId_Specified;
  int             FUserProfileId;
  bool            FUserProfileId_Specified;
  void __fastcall SetQuotationId(int Index, int _prop_val)
  {  FQuotationId = _prop_val; FQuotationId_Specified = true;  }
  bool __fastcall QuotationId_Specified(int Index)
  {  return FQuotationId_Specified;  } 
  void __fastcall SetSessionId(int Index, guid _prop_val)
  {  FSessionId = _prop_val; FSessionId_Specified = true;  }
  bool __fastcall SessionId_Specified(int Index)
  {  return FSessionId_Specified;  } 
  void __fastcall SetUserProfileId(int Index, int _prop_val)
  {  FUserProfileId = _prop_val; FUserProfileId_Specified = true;  }
  bool __fastcall UserProfileId_Specified(int Index)
  {  return FUserProfileId_Specified;  } 
__published:
  __property int        QuotationId = { index=(IS_OPTN), read=FQuotationId, write=SetQuotationId, stored = QuotationId_Specified };
  __property guid        SessionId = { index=(IS_OPTN), read=FSessionId, write=SetSessionId, stored = SessionId_Specified };
  __property int        UserProfileId = { index=(IS_OPTN), read=FUserProfileId, write=SetUserProfileId, stored = UserProfileId_Specified };
};




// ************************************************************************ //
// XML       : Agent, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Agent : public TRemotable {
private:
  WideString      FBKCardId;
  bool            FBKCardId_Specified;
  WideString      FINN;
  bool            FINN_Specified;
  WideString      FId;
  bool            FId_Specified;
  WideString      FKPP;
  bool            FKPP_Specified;
  WideString      FLNR;
  bool            FLNR_Specified;
  int             FOfficeId;
  bool            FOfficeId_Specified;
  WideString      FSubjectTypeId;
  bool            FSubjectTypeId_Specified;
  void __fastcall SetBKCardId(int Index, WideString _prop_val)
  {  FBKCardId = _prop_val; FBKCardId_Specified = true;  }
  bool __fastcall BKCardId_Specified(int Index)
  {  return FBKCardId_Specified;  } 
  void __fastcall SetINN(int Index, WideString _prop_val)
  {  FINN = _prop_val; FINN_Specified = true;  }
  bool __fastcall INN_Specified(int Index)
  {  return FINN_Specified;  } 
  void __fastcall SetId(int Index, WideString _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetKPP(int Index, WideString _prop_val)
  {  FKPP = _prop_val; FKPP_Specified = true;  }
  bool __fastcall KPP_Specified(int Index)
  {  return FKPP_Specified;  } 
  void __fastcall SetLNR(int Index, WideString _prop_val)
  {  FLNR = _prop_val; FLNR_Specified = true;  }
  bool __fastcall LNR_Specified(int Index)
  {  return FLNR_Specified;  } 
  void __fastcall SetOfficeId(int Index, int _prop_val)
  {  FOfficeId = _prop_val; FOfficeId_Specified = true;  }
  bool __fastcall OfficeId_Specified(int Index)
  {  return FOfficeId_Specified;  } 
  void __fastcall SetSubjectTypeId(int Index, WideString _prop_val)
  {  FSubjectTypeId = _prop_val; FSubjectTypeId_Specified = true;  }
  bool __fastcall SubjectTypeId_Specified(int Index)
  {  return FSubjectTypeId_Specified;  } 
__published:
  __property WideString   BKCardId = { index=(IS_OPTN|IS_NLBL), read=FBKCardId, write=SetBKCardId, stored = BKCardId_Specified };
  __property WideString        INN = { index=(IS_OPTN|IS_NLBL), read=FINN, write=SetINN, stored = INN_Specified };
  __property WideString         Id = { index=(IS_OPTN|IS_NLBL), read=FId, write=SetId, stored = Id_Specified };
  __property WideString        KPP = { index=(IS_OPTN|IS_NLBL), read=FKPP, write=SetKPP, stored = KPP_Specified };
  __property WideString        LNR = { index=(IS_OPTN|IS_NLBL), read=FLNR, write=SetLNR, stored = LNR_Specified };
  __property int          OfficeId = { index=(IS_OPTN|IS_NLBL), read=FOfficeId, write=SetOfficeId, stored = OfficeId_Specified };
  __property WideString SubjectTypeId = { index=(IS_OPTN|IS_NLBL), read=FSubjectTypeId, write=SetSubjectTypeId, stored = SubjectTypeId_Specified };
};


typedef DynamicArray<Document*>   ArrayOfDocument; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<Driver*>     ArrayOfDriver;  /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : Auto, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Auto : public TRemotable {
private:
  TXSDecimal*     FAllowWeight;
  bool            FAllowWeight_Specified;
  WideString      FChassisNumber;
  bool            FChassisNumber_Specified;
  WideString      FClassifierVehicleModelCode;
  bool            FClassifierVehicleModelCode_Specified;
  Document*       FDocument;
  bool            FDocument_Specified;
  ArrayOfDocument FDocuments;
  bool            FDocuments_Specified;
  ArrayOfDriver   FDrivers;
  bool            FDrivers_Specified;
  WideString      FFrameNumber;
  bool            FFrameNumber_Specified;
  bool            FHasTrailer;
  bool            FHasTrailer_Specified;
  WideString      FKbmClassForPreCalc;
  bool            FKbmClassForPreCalc_Specified;
  WideString      FLicensePlate;
  bool            FLicensePlate_Specified;
  int             FManufactureYear;
  bool            FManufactureYear_Specified;
  TXSDecimal*     FPower;
  bool            FPower_Specified;
  WideString      FPtsBrand;
  bool            FPtsBrand_Specified;
  WideString      FPtsModel;
  bool            FPtsModel_Specified;
  WideString      FPurposeUseCode;
  bool            FPurposeUseCode_Specified;
  int             FSeatCount;
  bool            FSeatCount_Specified;
  WideString      FVin;
  bool            FVin_Specified;
  void __fastcall SetAllowWeight(int Index, TXSDecimal* _prop_val)
  {  FAllowWeight = _prop_val; FAllowWeight_Specified = true;  }
  bool __fastcall AllowWeight_Specified(int Index)
  {  return FAllowWeight_Specified;  } 
  void __fastcall SetChassisNumber(int Index, WideString _prop_val)
  {  FChassisNumber = _prop_val; FChassisNumber_Specified = true;  }
  bool __fastcall ChassisNumber_Specified(int Index)
  {  return FChassisNumber_Specified;  } 
  void __fastcall SetClassifierVehicleModelCode(int Index, WideString _prop_val)
  {  FClassifierVehicleModelCode = _prop_val; FClassifierVehicleModelCode_Specified = true;  }
  bool __fastcall ClassifierVehicleModelCode_Specified(int Index)
  {  return FClassifierVehicleModelCode_Specified;  } 
  void __fastcall SetDocument(int Index, Document* _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetDocuments(int Index, ArrayOfDocument _prop_val)
  {  FDocuments = _prop_val; FDocuments_Specified = true;  }
  bool __fastcall Documents_Specified(int Index)
  {  return FDocuments_Specified;  } 
  void __fastcall SetDrivers(int Index, ArrayOfDriver _prop_val)
  {  FDrivers = _prop_val; FDrivers_Specified = true;  }
  bool __fastcall Drivers_Specified(int Index)
  {  return FDrivers_Specified;  } 
  void __fastcall SetFrameNumber(int Index, WideString _prop_val)
  {  FFrameNumber = _prop_val; FFrameNumber_Specified = true;  }
  bool __fastcall FrameNumber_Specified(int Index)
  {  return FFrameNumber_Specified;  } 
  void __fastcall SetHasTrailer(int Index, bool _prop_val)
  {  FHasTrailer = _prop_val; FHasTrailer_Specified = true;  }
  bool __fastcall HasTrailer_Specified(int Index)
  {  return FHasTrailer_Specified;  } 
  void __fastcall SetKbmClassForPreCalc(int Index, WideString _prop_val)
  {  FKbmClassForPreCalc = _prop_val; FKbmClassForPreCalc_Specified = true;  }
  bool __fastcall KbmClassForPreCalc_Specified(int Index)
  {  return FKbmClassForPreCalc_Specified;  } 
  void __fastcall SetLicensePlate(int Index, WideString _prop_val)
  {  FLicensePlate = _prop_val; FLicensePlate_Specified = true;  }
  bool __fastcall LicensePlate_Specified(int Index)
  {  return FLicensePlate_Specified;  } 
  void __fastcall SetManufactureYear(int Index, int _prop_val)
  {  FManufactureYear = _prop_val; FManufactureYear_Specified = true;  }
  bool __fastcall ManufactureYear_Specified(int Index)
  {  return FManufactureYear_Specified;  } 
  void __fastcall SetPower(int Index, TXSDecimal* _prop_val)
  {  FPower = _prop_val; FPower_Specified = true;  }
  bool __fastcall Power_Specified(int Index)
  {  return FPower_Specified;  } 
  void __fastcall SetPtsBrand(int Index, WideString _prop_val)
  {  FPtsBrand = _prop_val; FPtsBrand_Specified = true;  }
  bool __fastcall PtsBrand_Specified(int Index)
  {  return FPtsBrand_Specified;  } 
  void __fastcall SetPtsModel(int Index, WideString _prop_val)
  {  FPtsModel = _prop_val; FPtsModel_Specified = true;  }
  bool __fastcall PtsModel_Specified(int Index)
  {  return FPtsModel_Specified;  } 
  void __fastcall SetPurposeUseCode(int Index, WideString _prop_val)
  {  FPurposeUseCode = _prop_val; FPurposeUseCode_Specified = true;  }
  bool __fastcall PurposeUseCode_Specified(int Index)
  {  return FPurposeUseCode_Specified;  } 
  void __fastcall SetSeatCount(int Index, int _prop_val)
  {  FSeatCount = _prop_val; FSeatCount_Specified = true;  }
  bool __fastcall SeatCount_Specified(int Index)
  {  return FSeatCount_Specified;  } 
  void __fastcall SetVin(int Index, WideString _prop_val)
  {  FVin = _prop_val; FVin_Specified = true;  }
  bool __fastcall Vin_Specified(int Index)
  {  return FVin_Specified;  } 

public:
  __fastcall ~Auto();
__published:
  __property TXSDecimal* AllowWeight = { index=(IS_OPTN|IS_NLBL), read=FAllowWeight, write=SetAllowWeight, stored = AllowWeight_Specified };
  __property WideString ChassisNumber = { index=(IS_OPTN|IS_NLBL), read=FChassisNumber, write=SetChassisNumber, stored = ChassisNumber_Specified };
  __property WideString ClassifierVehicleModelCode = { index=(IS_OPTN|IS_NLBL), read=FClassifierVehicleModelCode, write=SetClassifierVehicleModelCode, stored = ClassifierVehicleModelCode_Specified };
  __property Document*    Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property ArrayOfDocument  Documents = { index=(IS_OPTN|IS_NLBL), read=FDocuments, write=SetDocuments, stored = Documents_Specified };
  __property ArrayOfDriver    Drivers = { index=(IS_OPTN|IS_NLBL), read=FDrivers, write=SetDrivers, stored = Drivers_Specified };
  __property WideString FrameNumber = { index=(IS_OPTN|IS_NLBL), read=FFrameNumber, write=SetFrameNumber, stored = FrameNumber_Specified };
  __property bool       HasTrailer = { index=(IS_OPTN|IS_NLBL), read=FHasTrailer, write=SetHasTrailer, stored = HasTrailer_Specified };
  __property WideString KbmClassForPreCalc = { index=(IS_OPTN|IS_NLBL), read=FKbmClassForPreCalc, write=SetKbmClassForPreCalc, stored = KbmClassForPreCalc_Specified };
  __property WideString LicensePlate = { index=(IS_OPTN|IS_NLBL), read=FLicensePlate, write=SetLicensePlate, stored = LicensePlate_Specified };
  __property int        ManufactureYear = { index=(IS_OPTN|IS_NLBL), read=FManufactureYear, write=SetManufactureYear, stored = ManufactureYear_Specified };
  __property TXSDecimal*      Power = { index=(IS_OPTN|IS_NLBL), read=FPower, write=SetPower, stored = Power_Specified };
  __property WideString   PtsBrand = { index=(IS_OPTN|IS_NLBL), read=FPtsBrand, write=SetPtsBrand, stored = PtsBrand_Specified };
  __property WideString   PtsModel = { index=(IS_OPTN|IS_NLBL), read=FPtsModel, write=SetPtsModel, stored = PtsModel_Specified };
  __property WideString PurposeUseCode = { index=(IS_OPTN|IS_NLBL), read=FPurposeUseCode, write=SetPurposeUseCode, stored = PurposeUseCode_Specified };
  __property int         SeatCount = { index=(IS_OPTN|IS_NLBL), read=FSeatCount, write=SetSeatCount, stored = SeatCount_Specified };
  __property WideString        Vin = { index=(IS_OPTN|IS_NLBL), read=FVin, write=SetVin, stored = Vin_Specified };
};




// ************************************************************************ //
// XML       : Document, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Document : public TRemotable {
private:
  TXSDateTime*    FIssueDate;
  bool            FIssueDate_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  WideString      FTypeCode;
  bool            FTypeCode_Specified;
  void __fastcall SetIssueDate(int Index, TXSDateTime* _prop_val)
  {  FIssueDate = _prop_val; FIssueDate_Specified = true;  }
  bool __fastcall IssueDate_Specified(int Index)
  {  return FIssueDate_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 
  void __fastcall SetTypeCode(int Index, WideString _prop_val)
  {  FTypeCode = _prop_val; FTypeCode_Specified = true;  }
  bool __fastcall TypeCode_Specified(int Index)
  {  return FTypeCode_Specified;  } 

public:
  __fastcall ~Document();
__published:
  __property TXSDateTime*  IssueDate = { index=(IS_OPTN|IS_NLBL), read=FIssueDate, write=SetIssueDate, stored = IssueDate_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
  __property WideString   TypeCode = { index=(IS_OPTN|IS_NLBL), read=FTypeCode, write=SetTypeCode, stored = TypeCode_Specified };
};




// ************************************************************************ //
// XML       : Counteragent, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Counteragent : public TRemotable {
private:
  AddressEntry*   FAddress;
  bool            FAddress_Specified;
  TXSDateTime*    FBirthDate;
  bool            FBirthDate_Specified;
  Contacts*       FContacts;
  bool            FContacts_Specified;
  Document*       FDocument_;
  bool            FDocument__Specified;
  WideString      FInn;
  bool            FInn_Specified;
  bool            FIsResident;
  bool            FIsResident_Specified;
  WideString      FKK;
  bool            FKK_Specified;
  WideString      FKPP;
  bool            FKPP_Specified;
  PersonName*     FName;
  bool            FName_Specified;
  WideString      FOGRN;
  bool            FOGRN_Specified;
  WideString      FOrganizationName;
  bool            FOrganizationName_Specified;
  Document*       FPrevDocument;
  bool            FPrevDocument_Specified;
  PersonName*     FPrevName;
  bool            FPrevName_Specified;
  int             FSubjectTypeId;
  bool            FSubjectTypeId_Specified;
  void __fastcall SetAddress(int Index, AddressEntry* _prop_val)
  {  FAddress = _prop_val; FAddress_Specified = true;  }
  bool __fastcall Address_Specified(int Index)
  {  return FAddress_Specified;  } 
  void __fastcall SetBirthDate(int Index, TXSDateTime* _prop_val)
  {  FBirthDate = _prop_val; FBirthDate_Specified = true;  }
  bool __fastcall BirthDate_Specified(int Index)
  {  return FBirthDate_Specified;  } 
  void __fastcall SetContacts(int Index, Contacts* _prop_val)
  {  FContacts = _prop_val; FContacts_Specified = true;  }
  bool __fastcall Contacts_Specified(int Index)
  {  return FContacts_Specified;  } 
  void __fastcall SetDocument_(int Index, Document* _prop_val)
  {  FDocument_ = _prop_val; FDocument__Specified = true;  }
  bool __fastcall Document__Specified(int Index)
  {  return FDocument__Specified;  } 
  void __fastcall SetInn(int Index, WideString _prop_val)
  {  FInn = _prop_val; FInn_Specified = true;  }
  bool __fastcall Inn_Specified(int Index)
  {  return FInn_Specified;  } 
  void __fastcall SetIsResident(int Index, bool _prop_val)
  {  FIsResident = _prop_val; FIsResident_Specified = true;  }
  bool __fastcall IsResident_Specified(int Index)
  {  return FIsResident_Specified;  } 
  void __fastcall SetKK(int Index, WideString _prop_val)
  {  FKK = _prop_val; FKK_Specified = true;  }
  bool __fastcall KK_Specified(int Index)
  {  return FKK_Specified;  } 
  void __fastcall SetKPP(int Index, WideString _prop_val)
  {  FKPP = _prop_val; FKPP_Specified = true;  }
  bool __fastcall KPP_Specified(int Index)
  {  return FKPP_Specified;  } 
  void __fastcall SetName(int Index, PersonName* _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetOGRN(int Index, WideString _prop_val)
  {  FOGRN = _prop_val; FOGRN_Specified = true;  }
  bool __fastcall OGRN_Specified(int Index)
  {  return FOGRN_Specified;  } 
  void __fastcall SetOrganizationName(int Index, WideString _prop_val)
  {  FOrganizationName = _prop_val; FOrganizationName_Specified = true;  }
  bool __fastcall OrganizationName_Specified(int Index)
  {  return FOrganizationName_Specified;  } 
  void __fastcall SetPrevDocument(int Index, Document* _prop_val)
  {  FPrevDocument = _prop_val; FPrevDocument_Specified = true;  }
  bool __fastcall PrevDocument_Specified(int Index)
  {  return FPrevDocument_Specified;  } 
  void __fastcall SetPrevName(int Index, PersonName* _prop_val)
  {  FPrevName = _prop_val; FPrevName_Specified = true;  }
  bool __fastcall PrevName_Specified(int Index)
  {  return FPrevName_Specified;  } 
  void __fastcall SetSubjectTypeId(int Index, int _prop_val)
  {  FSubjectTypeId = _prop_val; FSubjectTypeId_Specified = true;  }
  bool __fastcall SubjectTypeId_Specified(int Index)
  {  return FSubjectTypeId_Specified;  } 

public:
  __fastcall ~Counteragent();
__published:
  __property AddressEntry*    Address = { index=(IS_OPTN|IS_NLBL), read=FAddress, write=SetAddress, stored = Address_Specified };
  __property TXSDateTime*  BirthDate = { index=(IS_OPTN|IS_NLBL), read=FBirthDate, write=SetBirthDate, stored = BirthDate_Specified };
  __property Contacts*    Contacts = { index=(IS_OPTN|IS_NLBL), read=FContacts, write=SetContacts, stored = Contacts_Specified };
  __property Document*   Document_ = { index=(IS_OPTN|IS_NLBL), read=FDocument_, write=SetDocument_, stored = Document__Specified };
  __property WideString        Inn = { index=(IS_OPTN|IS_NLBL), read=FInn, write=SetInn, stored = Inn_Specified };
  __property bool       IsResident = { index=(IS_OPTN|IS_NLBL), read=FIsResident, write=SetIsResident, stored = IsResident_Specified };
  __property WideString         KK = { index=(IS_OPTN|IS_NLBL), read=FKK, write=SetKK, stored = KK_Specified };
  __property WideString        KPP = { index=(IS_OPTN|IS_NLBL), read=FKPP, write=SetKPP, stored = KPP_Specified };
  __property PersonName*       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property WideString       OGRN = { index=(IS_OPTN|IS_NLBL), read=FOGRN, write=SetOGRN, stored = OGRN_Specified };
  __property WideString OrganizationName = { index=(IS_OPTN|IS_NLBL), read=FOrganizationName, write=SetOrganizationName, stored = OrganizationName_Specified };
  __property Document*  PrevDocument = { index=(IS_OPTN|IS_NLBL), read=FPrevDocument, write=SetPrevDocument, stored = PrevDocument_Specified };
  __property PersonName*   PrevName = { index=(IS_OPTN|IS_NLBL), read=FPrevName, write=SetPrevName, stored = PrevName_Specified };
  __property int        SubjectTypeId = { index=(IS_OPTN), read=FSubjectTypeId, write=SetSubjectTypeId, stored = SubjectTypeId_Specified };
};




// ************************************************************************ //
// XML       : Driver, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Driver : public TRemotable {
private:
  TXSDateTime*    FBirthDate;
  bool            FBirthDate_Specified;
  int             FCountryCode;
  bool            FCountryCode_Specified;
  DateTimeOffset* FDriverAddedDate;
  bool            FDriverAddedDate_Specified;
  int             FDriverId;
  bool            FDriverId_Specified;
  TXSDateTime*    FDrivingStartExperienceDate;
  bool            FDrivingStartExperienceDate_Specified;
  bool            FIsDriverAdded;
  bool            FIsDriverAdded_Specified;
  bool            FIsDriverRemoved;
  bool            FIsDriverRemoved_Specified;
  Document*       FLicense;
  bool            FLicense_Specified;
  PersonName*     FName;
  bool            FName_Specified;
  Document*       FPrevLicense;
  bool            FPrevLicense_Specified;
  PersonName*     FPrevName;
  bool            FPrevName_Specified;
  void __fastcall SetBirthDate(int Index, TXSDateTime* _prop_val)
  {  FBirthDate = _prop_val; FBirthDate_Specified = true;  }
  bool __fastcall BirthDate_Specified(int Index)
  {  return FBirthDate_Specified;  } 
  void __fastcall SetCountryCode(int Index, int _prop_val)
  {  FCountryCode = _prop_val; FCountryCode_Specified = true;  }
  bool __fastcall CountryCode_Specified(int Index)
  {  return FCountryCode_Specified;  } 
  void __fastcall SetDriverAddedDate(int Index, DateTimeOffset* _prop_val)
  {  FDriverAddedDate = _prop_val; FDriverAddedDate_Specified = true;  }
  bool __fastcall DriverAddedDate_Specified(int Index)
  {  return FDriverAddedDate_Specified;  } 
  void __fastcall SetDriverId(int Index, int _prop_val)
  {  FDriverId = _prop_val; FDriverId_Specified = true;  }
  bool __fastcall DriverId_Specified(int Index)
  {  return FDriverId_Specified;  } 
  void __fastcall SetDrivingStartExperienceDate(int Index, TXSDateTime* _prop_val)
  {  FDrivingStartExperienceDate = _prop_val; FDrivingStartExperienceDate_Specified = true;  }
  bool __fastcall DrivingStartExperienceDate_Specified(int Index)
  {  return FDrivingStartExperienceDate_Specified;  } 
  void __fastcall SetIsDriverAdded(int Index, bool _prop_val)
  {  FIsDriverAdded = _prop_val; FIsDriverAdded_Specified = true;  }
  bool __fastcall IsDriverAdded_Specified(int Index)
  {  return FIsDriverAdded_Specified;  } 
  void __fastcall SetIsDriverRemoved(int Index, bool _prop_val)
  {  FIsDriverRemoved = _prop_val; FIsDriverRemoved_Specified = true;  }
  bool __fastcall IsDriverRemoved_Specified(int Index)
  {  return FIsDriverRemoved_Specified;  } 
  void __fastcall SetLicense(int Index, Document* _prop_val)
  {  FLicense = _prop_val; FLicense_Specified = true;  }
  bool __fastcall License_Specified(int Index)
  {  return FLicense_Specified;  } 
  void __fastcall SetName(int Index, PersonName* _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetPrevLicense(int Index, Document* _prop_val)
  {  FPrevLicense = _prop_val; FPrevLicense_Specified = true;  }
  bool __fastcall PrevLicense_Specified(int Index)
  {  return FPrevLicense_Specified;  } 
  void __fastcall SetPrevName(int Index, PersonName* _prop_val)
  {  FPrevName = _prop_val; FPrevName_Specified = true;  }
  bool __fastcall PrevName_Specified(int Index)
  {  return FPrevName_Specified;  } 

public:
  __fastcall ~Driver();
__published:
  __property TXSDateTime*  BirthDate = { index=(IS_OPTN), read=FBirthDate, write=SetBirthDate, stored = BirthDate_Specified };
  __property int        CountryCode = { index=(IS_OPTN|IS_NLBL), read=FCountryCode, write=SetCountryCode, stored = CountryCode_Specified };
  __property DateTimeOffset* DriverAddedDate = { index=(IS_OPTN|IS_NLBL), read=FDriverAddedDate, write=SetDriverAddedDate, stored = DriverAddedDate_Specified };
  __property int          DriverId = { index=(IS_OPTN|IS_NLBL), read=FDriverId, write=SetDriverId, stored = DriverId_Specified };
  __property TXSDateTime* DrivingStartExperienceDate = { index=(IS_OPTN), read=FDrivingStartExperienceDate, write=SetDrivingStartExperienceDate, stored = DrivingStartExperienceDate_Specified };
  __property bool       IsDriverAdded = { index=(IS_OPTN|IS_NLBL), read=FIsDriverAdded, write=SetIsDriverAdded, stored = IsDriverAdded_Specified };
  __property bool       IsDriverRemoved = { index=(IS_OPTN|IS_NLBL), read=FIsDriverRemoved, write=SetIsDriverRemoved, stored = IsDriverRemoved_Specified };
  __property Document*     License = { index=(IS_OPTN|IS_NLBL), read=FLicense, write=SetLicense, stored = License_Specified };
  __property PersonName*       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property Document*  PrevLicense = { index=(IS_OPTN|IS_NLBL), read=FPrevLicense, write=SetPrevLicense, stored = PrevLicense_Specified };
  __property PersonName*   PrevName = { index=(IS_OPTN|IS_NLBL), read=FPrevName, write=SetPrevName, stored = PrevName_Specified };
};




// ************************************************************************ //
// XML       : PersonName, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PersonName : public TRemotable {
private:
  WideString      FFirstName;
  bool            FFirstName_Specified;
  WideString      FLastName;
  bool            FLastName_Specified;
  WideString      FSecondName;
  bool            FSecondName_Specified;
  void __fastcall SetFirstName(int Index, WideString _prop_val)
  {  FFirstName = _prop_val; FFirstName_Specified = true;  }
  bool __fastcall FirstName_Specified(int Index)
  {  return FFirstName_Specified;  } 
  void __fastcall SetLastName(int Index, WideString _prop_val)
  {  FLastName = _prop_val; FLastName_Specified = true;  }
  bool __fastcall LastName_Specified(int Index)
  {  return FLastName_Specified;  } 
  void __fastcall SetSecondName(int Index, WideString _prop_val)
  {  FSecondName = _prop_val; FSecondName_Specified = true;  }
  bool __fastcall SecondName_Specified(int Index)
  {  return FSecondName_Specified;  } 
__published:
  __property WideString  FirstName = { index=(IS_OPTN|IS_NLBL), read=FFirstName, write=SetFirstName, stored = FirstName_Specified };
  __property WideString   LastName = { index=(IS_OPTN|IS_NLBL), read=FLastName, write=SetLastName, stored = LastName_Specified };
  __property WideString SecondName = { index=(IS_OPTN|IS_NLBL), read=FSecondName, write=SetSecondName, stored = SecondName_Specified };
};




// ************************************************************************ //
// XML       : AddressEntry, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddressEntry : public TRemotable {
private:
  WideString      FArea;
  bool            FArea_Specified;
  WideString      FBuilding;
  bool            FBuilding_Specified;
  WideString      FCity;
  bool            FCity_Specified;
  int             FCountryCode;
  bool            FCountryCode_Specified;
  WideString      FFlat;
  bool            FFlat_Specified;
  WideString      FFullAddress;
  bool            FFullAddress_Specified;
  WideString      FHouse;
  bool            FHouse_Specified;
  WideString      FKladrCode;
  bool            FKladrCode_Specified;
  WideString      FPlace;
  bool            FPlace_Specified;
  WideString      FPostCode;
  bool            FPostCode_Specified;
  WideString      FRegion;
  bool            FRegion_Specified;
  WideString      FStreet;
  bool            FStreet_Specified;
  void __fastcall SetArea(int Index, WideString _prop_val)
  {  FArea = _prop_val; FArea_Specified = true;  }
  bool __fastcall Area_Specified(int Index)
  {  return FArea_Specified;  } 
  void __fastcall SetBuilding(int Index, WideString _prop_val)
  {  FBuilding = _prop_val; FBuilding_Specified = true;  }
  bool __fastcall Building_Specified(int Index)
  {  return FBuilding_Specified;  } 
  void __fastcall SetCity(int Index, WideString _prop_val)
  {  FCity = _prop_val; FCity_Specified = true;  }
  bool __fastcall City_Specified(int Index)
  {  return FCity_Specified;  } 
  void __fastcall SetCountryCode(int Index, int _prop_val)
  {  FCountryCode = _prop_val; FCountryCode_Specified = true;  }
  bool __fastcall CountryCode_Specified(int Index)
  {  return FCountryCode_Specified;  } 
  void __fastcall SetFlat(int Index, WideString _prop_val)
  {  FFlat = _prop_val; FFlat_Specified = true;  }
  bool __fastcall Flat_Specified(int Index)
  {  return FFlat_Specified;  } 
  void __fastcall SetFullAddress(int Index, WideString _prop_val)
  {  FFullAddress = _prop_val; FFullAddress_Specified = true;  }
  bool __fastcall FullAddress_Specified(int Index)
  {  return FFullAddress_Specified;  } 
  void __fastcall SetHouse(int Index, WideString _prop_val)
  {  FHouse = _prop_val; FHouse_Specified = true;  }
  bool __fastcall House_Specified(int Index)
  {  return FHouse_Specified;  } 
  void __fastcall SetKladrCode(int Index, WideString _prop_val)
  {  FKladrCode = _prop_val; FKladrCode_Specified = true;  }
  bool __fastcall KladrCode_Specified(int Index)
  {  return FKladrCode_Specified;  } 
  void __fastcall SetPlace(int Index, WideString _prop_val)
  {  FPlace = _prop_val; FPlace_Specified = true;  }
  bool __fastcall Place_Specified(int Index)
  {  return FPlace_Specified;  } 
  void __fastcall SetPostCode(int Index, WideString _prop_val)
  {  FPostCode = _prop_val; FPostCode_Specified = true;  }
  bool __fastcall PostCode_Specified(int Index)
  {  return FPostCode_Specified;  } 
  void __fastcall SetRegion(int Index, WideString _prop_val)
  {  FRegion = _prop_val; FRegion_Specified = true;  }
  bool __fastcall Region_Specified(int Index)
  {  return FRegion_Specified;  } 
  void __fastcall SetStreet(int Index, WideString _prop_val)
  {  FStreet = _prop_val; FStreet_Specified = true;  }
  bool __fastcall Street_Specified(int Index)
  {  return FStreet_Specified;  } 
__published:
  __property WideString       Area = { index=(IS_OPTN|IS_NLBL), read=FArea, write=SetArea, stored = Area_Specified };
  __property WideString   Building = { index=(IS_OPTN|IS_NLBL), read=FBuilding, write=SetBuilding, stored = Building_Specified };
  __property WideString       City = { index=(IS_OPTN|IS_NLBL), read=FCity, write=SetCity, stored = City_Specified };
  __property int        CountryCode = { index=(IS_OPTN), read=FCountryCode, write=SetCountryCode, stored = CountryCode_Specified };
  __property WideString       Flat = { index=(IS_OPTN|IS_NLBL), read=FFlat, write=SetFlat, stored = Flat_Specified };
  __property WideString FullAddress = { index=(IS_OPTN|IS_NLBL), read=FFullAddress, write=SetFullAddress, stored = FullAddress_Specified };
  __property WideString      House = { index=(IS_OPTN|IS_NLBL), read=FHouse, write=SetHouse, stored = House_Specified };
  __property WideString  KladrCode = { index=(IS_OPTN|IS_NLBL), read=FKladrCode, write=SetKladrCode, stored = KladrCode_Specified };
  __property WideString      Place = { index=(IS_OPTN|IS_NLBL), read=FPlace, write=SetPlace, stored = Place_Specified };
  __property WideString   PostCode = { index=(IS_OPTN|IS_NLBL), read=FPostCode, write=SetPostCode, stored = PostCode_Specified };
  __property WideString     Region = { index=(IS_OPTN|IS_NLBL), read=FRegion, write=SetRegion, stored = Region_Specified };
  __property WideString     Street = { index=(IS_OPTN|IS_NLBL), read=FStreet, write=SetStreet, stored = Street_Specified };
};




// ************************************************************************ //
// XML       : Contacts, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Contacts : public TRemotable {
private:
  WideString      FEmail;
  bool            FEmail_Specified;
  WideString      FHomePhone;
  bool            FHomePhone_Specified;
  WideString      FMobilePhone;
  bool            FMobilePhone_Specified;
  WideString      FWorkPhone;
  bool            FWorkPhone_Specified;
  void __fastcall SetEmail(int Index, WideString _prop_val)
  {  FEmail = _prop_val; FEmail_Specified = true;  }
  bool __fastcall Email_Specified(int Index)
  {  return FEmail_Specified;  } 
  void __fastcall SetHomePhone(int Index, WideString _prop_val)
  {  FHomePhone = _prop_val; FHomePhone_Specified = true;  }
  bool __fastcall HomePhone_Specified(int Index)
  {  return FHomePhone_Specified;  } 
  void __fastcall SetMobilePhone(int Index, WideString _prop_val)
  {  FMobilePhone = _prop_val; FMobilePhone_Specified = true;  }
  bool __fastcall MobilePhone_Specified(int Index)
  {  return FMobilePhone_Specified;  } 
  void __fastcall SetWorkPhone(int Index, WideString _prop_val)
  {  FWorkPhone = _prop_val; FWorkPhone_Specified = true;  }
  bool __fastcall WorkPhone_Specified(int Index)
  {  return FWorkPhone_Specified;  } 
__published:
  __property WideString      Email = { index=(IS_OPTN|IS_NLBL), read=FEmail, write=SetEmail, stored = Email_Specified };
  __property WideString  HomePhone = { index=(IS_OPTN|IS_NLBL), read=FHomePhone, write=SetHomePhone, stored = HomePhone_Specified };
  __property WideString MobilePhone = { index=(IS_OPTN|IS_NLBL), read=FMobilePhone, write=SetMobilePhone, stored = MobilePhone_Specified };
  __property WideString  WorkPhone = { index=(IS_OPTN|IS_NLBL), read=FWorkPhone, write=SetWorkPhone, stored = WorkPhone_Specified };
};




// ************************************************************************ //
// XML       : PeriodOfUse, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PeriodOfUse : public TRemotable {
private:
  DateTimeOffset* FEndDate;
  bool            FEndDate_Specified;
  int             FId;
  bool            FId_Specified;
  bool            FIsUsagePeriodAdded;
  bool            FIsUsagePeriodAdded_Specified;
  bool            FIsUsagePeriodRemoved;
  bool            FIsUsagePeriodRemoved_Specified;
  DateTimeOffset* FStartDate;
  bool            FStartDate_Specified;
  void __fastcall SetEndDate(int Index, DateTimeOffset* _prop_val)
  {  FEndDate = _prop_val; FEndDate_Specified = true;  }
  bool __fastcall EndDate_Specified(int Index)
  {  return FEndDate_Specified;  } 
  void __fastcall SetId(int Index, int _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetIsUsagePeriodAdded(int Index, bool _prop_val)
  {  FIsUsagePeriodAdded = _prop_val; FIsUsagePeriodAdded_Specified = true;  }
  bool __fastcall IsUsagePeriodAdded_Specified(int Index)
  {  return FIsUsagePeriodAdded_Specified;  } 
  void __fastcall SetIsUsagePeriodRemoved(int Index, bool _prop_val)
  {  FIsUsagePeriodRemoved = _prop_val; FIsUsagePeriodRemoved_Specified = true;  }
  bool __fastcall IsUsagePeriodRemoved_Specified(int Index)
  {  return FIsUsagePeriodRemoved_Specified;  } 
  void __fastcall SetStartDate(int Index, DateTimeOffset* _prop_val)
  {  FStartDate = _prop_val; FStartDate_Specified = true;  }
  bool __fastcall StartDate_Specified(int Index)
  {  return FStartDate_Specified;  } 

public:
  __fastcall ~PeriodOfUse();
__published:
  __property DateTimeOffset*    EndDate = { index=(IS_OPTN), read=FEndDate, write=SetEndDate, stored = EndDate_Specified };
  __property int                Id = { index=(IS_OPTN), read=FId, write=SetId, stored = Id_Specified };
  __property bool       IsUsagePeriodAdded = { index=(IS_OPTN|IS_NLBL), read=FIsUsagePeriodAdded, write=SetIsUsagePeriodAdded, stored = IsUsagePeriodAdded_Specified };
  __property bool       IsUsagePeriodRemoved = { index=(IS_OPTN|IS_NLBL), read=FIsUsagePeriodRemoved, write=SetIsUsagePeriodRemoved, stored = IsUsagePeriodRemoved_Specified };
  __property DateTimeOffset*  StartDate = { index=(IS_OPTN), read=FStartDate, write=SetStartDate, stored = StartDate_Specified };
};




// ************************************************************************ //
// XML       : ServiceStation, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ServiceStation : public TRemotable {
private:
  WideString      FAddress;
  bool            FAddress_Specified;
  WideString      FId;
  bool            FId_Specified;
  WideString      FName;
  bool            FName_Specified;
  void __fastcall SetAddress(int Index, WideString _prop_val)
  {  FAddress = _prop_val; FAddress_Specified = true;  }
  bool __fastcall Address_Specified(int Index)
  {  return FAddress_Specified;  } 
  void __fastcall SetId(int Index, WideString _prop_val)
  {  FId = _prop_val; FId_Specified = true;  }
  bool __fastcall Id_Specified(int Index)
  {  return FId_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
__published:
  __property WideString    Address = { index=(IS_OPTN|IS_NLBL), read=FAddress, write=SetAddress, stored = Address_Specified };
  __property WideString         Id = { index=(IS_OPTN|IS_NLBL), read=FId, write=SetId, stored = Id_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
};




// ************************************************************************ //
// XML       : Coefficients, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Coefficients : public TRemotable {
private:
  TXSDecimal*     FKbc;
  bool            FKbc_Specified;
  TXSDecimal*     FKbm;
  bool            FKbm_Specified;
  TXSDecimal*     FKc;
  bool            FKc_Specified;
  TXSDecimal*     FKm;
  bool            FKm_Specified;
  TXSDecimal*     FKn;
  bool            FKn_Specified;
  TXSDecimal*     FKo;
  bool            FKo_Specified;
  TXSDecimal*     FKp;
  bool            FKp_Specified;
  TXSDecimal*     FKpr;
  bool            FKpr_Specified;
  TXSDecimal*     FKt;
  bool            FKt_Specified;
  TXSDecimal*     FTb;
  bool            FTb_Specified;
  void __fastcall SetKbc(int Index, TXSDecimal* _prop_val)
  {  FKbc = _prop_val; FKbc_Specified = true;  }
  bool __fastcall Kbc_Specified(int Index)
  {  return FKbc_Specified;  } 
  void __fastcall SetKbm(int Index, TXSDecimal* _prop_val)
  {  FKbm = _prop_val; FKbm_Specified = true;  }
  bool __fastcall Kbm_Specified(int Index)
  {  return FKbm_Specified;  } 
  void __fastcall SetKc(int Index, TXSDecimal* _prop_val)
  {  FKc = _prop_val; FKc_Specified = true;  }
  bool __fastcall Kc_Specified(int Index)
  {  return FKc_Specified;  } 
  void __fastcall SetKm(int Index, TXSDecimal* _prop_val)
  {  FKm = _prop_val; FKm_Specified = true;  }
  bool __fastcall Km_Specified(int Index)
  {  return FKm_Specified;  } 
  void __fastcall SetKn(int Index, TXSDecimal* _prop_val)
  {  FKn = _prop_val; FKn_Specified = true;  }
  bool __fastcall Kn_Specified(int Index)
  {  return FKn_Specified;  } 
  void __fastcall SetKo(int Index, TXSDecimal* _prop_val)
  {  FKo = _prop_val; FKo_Specified = true;  }
  bool __fastcall Ko_Specified(int Index)
  {  return FKo_Specified;  } 
  void __fastcall SetKp(int Index, TXSDecimal* _prop_val)
  {  FKp = _prop_val; FKp_Specified = true;  }
  bool __fastcall Kp_Specified(int Index)
  {  return FKp_Specified;  } 
  void __fastcall SetKpr(int Index, TXSDecimal* _prop_val)
  {  FKpr = _prop_val; FKpr_Specified = true;  }
  bool __fastcall Kpr_Specified(int Index)
  {  return FKpr_Specified;  } 
  void __fastcall SetKt(int Index, TXSDecimal* _prop_val)
  {  FKt = _prop_val; FKt_Specified = true;  }
  bool __fastcall Kt_Specified(int Index)
  {  return FKt_Specified;  } 
  void __fastcall SetTb(int Index, TXSDecimal* _prop_val)
  {  FTb = _prop_val; FTb_Specified = true;  }
  bool __fastcall Tb_Specified(int Index)
  {  return FTb_Specified;  } 

public:
  __fastcall ~Coefficients();
__published:
  __property TXSDecimal*        Kbc = { index=(IS_OPTN), read=FKbc, write=SetKbc, stored = Kbc_Specified };
  __property TXSDecimal*        Kbm = { index=(IS_OPTN), read=FKbm, write=SetKbm, stored = Kbm_Specified };
  __property TXSDecimal*         Kc = { index=(IS_OPTN), read=FKc, write=SetKc, stored = Kc_Specified };
  __property TXSDecimal*         Km = { index=(IS_OPTN), read=FKm, write=SetKm, stored = Km_Specified };
  __property TXSDecimal*         Kn = { index=(IS_OPTN), read=FKn, write=SetKn, stored = Kn_Specified };
  __property TXSDecimal*         Ko = { index=(IS_OPTN), read=FKo, write=SetKo, stored = Ko_Specified };
  __property TXSDecimal*         Kp = { index=(IS_OPTN), read=FKp, write=SetKp, stored = Kp_Specified };
  __property TXSDecimal*        Kpr = { index=(IS_OPTN), read=FKpr, write=SetKpr, stored = Kpr_Specified };
  __property TXSDecimal*         Kt = { index=(IS_OPTN), read=FKt, write=SetKt, stored = Kt_Specified };
  __property TXSDecimal*         Tb = { index=(IS_OPTN), read=FTb, write=SetTb, stored = Tb_Specified };
};


typedef DynamicArray<WideString>  ArrayOfstring;  /* "http://schemas.microsoft.com/2003/10/Serialization/Arrays"[GblCplx] */


// ************************************************************************ //
// XML       : UpdateRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UpdateRequest : public TRemotable {
private:
  Auto*           FAuto;
  bool            FAuto_Specified;
  Coefficients*   FCoefficients;
  bool            FCoefficients_Specified;
  DateTimeOffset* FEndDate;
  bool            FEndDate_Specified;
  bool            FIsGrossViolationsOfInsurance;
  bool            FIsGrossViolationsOfInsurance_Specified;
  ArrayOfstring   FModifyReasonIds;
  bool            FModifyReasonIds_Specified;
  TXSDecimal*     FPremium;
  bool            FPremium_Specified;
  WideString      FPrimaryUseKladr;
  bool            FPrimaryUseKladr_Specified;
  RegistrationPlaceNames FRegistrationPlace;
  bool            FRegistrationPlace_Specified;
  TXSDecimal*     FReturnsSum;
  bool            FReturnsSum_Specified;
  DateTimeOffset* FStartDate;
  bool            FStartDate_Specified;
  void __fastcall SetAuto(int Index, Auto* _prop_val)
  {  FAuto = _prop_val; FAuto_Specified = true;  }
  bool __fastcall Auto_Specified(int Index)
  {  return FAuto_Specified;  } 
  void __fastcall SetCoefficients(int Index, Coefficients* _prop_val)
  {  FCoefficients = _prop_val; FCoefficients_Specified = true;  }
  bool __fastcall Coefficients_Specified(int Index)
  {  return FCoefficients_Specified;  } 
  void __fastcall SetEndDate(int Index, DateTimeOffset* _prop_val)
  {  FEndDate = _prop_val; FEndDate_Specified = true;  }
  bool __fastcall EndDate_Specified(int Index)
  {  return FEndDate_Specified;  } 
  void __fastcall SetIsGrossViolationsOfInsurance(int Index, bool _prop_val)
  {  FIsGrossViolationsOfInsurance = _prop_val; FIsGrossViolationsOfInsurance_Specified = true;  }
  bool __fastcall IsGrossViolationsOfInsurance_Specified(int Index)
  {  return FIsGrossViolationsOfInsurance_Specified;  } 
  void __fastcall SetModifyReasonIds(int Index, ArrayOfstring _prop_val)
  {  FModifyReasonIds = _prop_val; FModifyReasonIds_Specified = true;  }
  bool __fastcall ModifyReasonIds_Specified(int Index)
  {  return FModifyReasonIds_Specified;  } 
  void __fastcall SetPremium(int Index, TXSDecimal* _prop_val)
  {  FPremium = _prop_val; FPremium_Specified = true;  }
  bool __fastcall Premium_Specified(int Index)
  {  return FPremium_Specified;  } 
  void __fastcall SetPrimaryUseKladr(int Index, WideString _prop_val)
  {  FPrimaryUseKladr = _prop_val; FPrimaryUseKladr_Specified = true;  }
  bool __fastcall PrimaryUseKladr_Specified(int Index)
  {  return FPrimaryUseKladr_Specified;  } 
  void __fastcall SetRegistrationPlace(int Index, RegistrationPlaceNames _prop_val)
  {  FRegistrationPlace = _prop_val; FRegistrationPlace_Specified = true;  }
  bool __fastcall RegistrationPlace_Specified(int Index)
  {  return FRegistrationPlace_Specified;  } 
  void __fastcall SetReturnsSum(int Index, TXSDecimal* _prop_val)
  {  FReturnsSum = _prop_val; FReturnsSum_Specified = true;  }
  bool __fastcall ReturnsSum_Specified(int Index)
  {  return FReturnsSum_Specified;  } 
  void __fastcall SetStartDate(int Index, DateTimeOffset* _prop_val)
  {  FStartDate = _prop_val; FStartDate_Specified = true;  }
  bool __fastcall StartDate_Specified(int Index)
  {  return FStartDate_Specified;  } 

public:
  __fastcall ~UpdateRequest();
__published:
  __property Auto*            Auto = { index=(IS_OPTN|IS_NLBL), read=FAuto, write=SetAuto, stored = Auto_Specified };
  __property Coefficients* Coefficients = { index=(IS_OPTN|IS_NLBL), read=FCoefficients, write=SetCoefficients, stored = Coefficients_Specified };
  __property DateTimeOffset*    EndDate = { index=(IS_OPTN|IS_NLBL), read=FEndDate, write=SetEndDate, stored = EndDate_Specified };
  __property bool       IsGrossViolationsOfInsurance = { index=(IS_OPTN), read=FIsGrossViolationsOfInsurance, write=SetIsGrossViolationsOfInsurance, stored = IsGrossViolationsOfInsurance_Specified };
  __property ArrayOfstring ModifyReasonIds = { index=(IS_OPTN|IS_NLBL), read=FModifyReasonIds, write=SetModifyReasonIds, stored = ModifyReasonIds_Specified };
  __property TXSDecimal*    Premium = { index=(IS_OPTN|IS_NLBL), read=FPremium, write=SetPremium, stored = Premium_Specified };
  __property WideString PrimaryUseKladr = { index=(IS_OPTN|IS_NLBL), read=FPrimaryUseKladr, write=SetPrimaryUseKladr, stored = PrimaryUseKladr_Specified };
  __property RegistrationPlaceNames RegistrationPlace = { index=(IS_OPTN|IS_NLBL), read=FRegistrationPlace, write=SetRegistrationPlace, stored = RegistrationPlace_Specified };
  __property TXSDecimal* ReturnsSum = { index=(IS_OPTN|IS_NLBL), read=FReturnsSum, write=SetReturnsSum, stored = ReturnsSum_Specified };
  __property DateTimeOffset*  StartDate = { index=(IS_OPTN|IS_NLBL), read=FStartDate, write=SetStartDate, stored = StartDate_Specified };
};


typedef DynamicArray<ClientReason*> ArrayOfClientReason; /* "Rgs.Ufo"[GblCplx] */
typedef DynamicArray<DriverCalcResult*> ArrayOfDriverCalcResult; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : CalcResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalcResult : public TRemotable {
private:
  WideString      FCalculationErrors;
  bool            FCalculationErrors_Specified;
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  WideString      FCheckSum;
  bool            FCheckSum_Specified;
  bool            FClientLevel;
  bool            FClientLevel_Specified;
  ArrayOfClientReason FClientReasons;
  bool            FClientReasons_Specified;
  DateTimeOffset* FDateInsurancePremium;
  bool            FDateInsurancePremium_Specified;
  ArrayOfDriverCalcResult FDrivers;
  bool            FDrivers_Specified;
  bool            FIsEOsago;
  bool            FIsEOsago_Specified;
  bool            FIsNeedScans;
  bool            FIsNeedScans_Specified;
  bool            FIsOwnerNotExistsInRsa;
  bool            FIsOwnerNotExistsInRsa_Specified;
  Coefficients*   FK;
  bool            FK_Specified;
  TXSDateTime*    FKbmRequestDate;
  bool            FKbmRequestDate_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  TXSDecimal*     FPremium;
  bool            FPremium_Specified;
  TXSDecimal*     FPremiumModify;
  bool            FPremiumModify_Specified;
  int             FPrevDocOwnerKbm;
  bool            FPrevDocOwnerKbm_Specified;
  RSACheck*       FRsaCheck;
  bool            FRsaCheck_Specified;
  WideString      FRsaDraftPolicyId;
  bool            FRsaDraftPolicyId_Specified;
  Document*       FSelectedVehicleDocument;
  bool            FSelectedVehicleDocument_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  VehicleKbmRsaCalcResult* FVehicleKbmRsa;
  bool            FVehicleKbmRsa_Specified;
  void __fastcall SetCalculationErrors(int Index, WideString _prop_val)
  {  FCalculationErrors = _prop_val; FCalculationErrors_Specified = true;  }
  bool __fastcall CalculationErrors_Specified(int Index)
  {  return FCalculationErrors_Specified;  } 
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetCheckSum(int Index, WideString _prop_val)
  {  FCheckSum = _prop_val; FCheckSum_Specified = true;  }
  bool __fastcall CheckSum_Specified(int Index)
  {  return FCheckSum_Specified;  } 
  void __fastcall SetClientLevel(int Index, bool _prop_val)
  {  FClientLevel = _prop_val; FClientLevel_Specified = true;  }
  bool __fastcall ClientLevel_Specified(int Index)
  {  return FClientLevel_Specified;  } 
  void __fastcall SetClientReasons(int Index, ArrayOfClientReason _prop_val)
  {  FClientReasons = _prop_val; FClientReasons_Specified = true;  }
  bool __fastcall ClientReasons_Specified(int Index)
  {  return FClientReasons_Specified;  } 
  void __fastcall SetDateInsurancePremium(int Index, DateTimeOffset* _prop_val)
  {  FDateInsurancePremium = _prop_val; FDateInsurancePremium_Specified = true;  }
  bool __fastcall DateInsurancePremium_Specified(int Index)
  {  return FDateInsurancePremium_Specified;  } 
  void __fastcall SetDrivers(int Index, ArrayOfDriverCalcResult _prop_val)
  {  FDrivers = _prop_val; FDrivers_Specified = true;  }
  bool __fastcall Drivers_Specified(int Index)
  {  return FDrivers_Specified;  } 
  void __fastcall SetIsEOsago(int Index, bool _prop_val)
  {  FIsEOsago = _prop_val; FIsEOsago_Specified = true;  }
  bool __fastcall IsEOsago_Specified(int Index)
  {  return FIsEOsago_Specified;  } 
  void __fastcall SetIsNeedScans(int Index, bool _prop_val)
  {  FIsNeedScans = _prop_val; FIsNeedScans_Specified = true;  }
  bool __fastcall IsNeedScans_Specified(int Index)
  {  return FIsNeedScans_Specified;  } 
  void __fastcall SetIsOwnerNotExistsInRsa(int Index, bool _prop_val)
  {  FIsOwnerNotExistsInRsa = _prop_val; FIsOwnerNotExistsInRsa_Specified = true;  }
  bool __fastcall IsOwnerNotExistsInRsa_Specified(int Index)
  {  return FIsOwnerNotExistsInRsa_Specified;  } 
  void __fastcall SetK(int Index, Coefficients* _prop_val)
  {  FK = _prop_val; FK_Specified = true;  }
  bool __fastcall K_Specified(int Index)
  {  return FK_Specified;  } 
  void __fastcall SetKbmRequestDate(int Index, TXSDateTime* _prop_val)
  {  FKbmRequestDate = _prop_val; FKbmRequestDate_Specified = true;  }
  bool __fastcall KbmRequestDate_Specified(int Index)
  {  return FKbmRequestDate_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetPremium(int Index, TXSDecimal* _prop_val)
  {  FPremium = _prop_val; FPremium_Specified = true;  }
  bool __fastcall Premium_Specified(int Index)
  {  return FPremium_Specified;  } 
  void __fastcall SetPremiumModify(int Index, TXSDecimal* _prop_val)
  {  FPremiumModify = _prop_val; FPremiumModify_Specified = true;  }
  bool __fastcall PremiumModify_Specified(int Index)
  {  return FPremiumModify_Specified;  } 
  void __fastcall SetPrevDocOwnerKbm(int Index, int _prop_val)
  {  FPrevDocOwnerKbm = _prop_val; FPrevDocOwnerKbm_Specified = true;  }
  bool __fastcall PrevDocOwnerKbm_Specified(int Index)
  {  return FPrevDocOwnerKbm_Specified;  } 
  void __fastcall SetRsaCheck(int Index, RSACheck* _prop_val)
  {  FRsaCheck = _prop_val; FRsaCheck_Specified = true;  }
  bool __fastcall RsaCheck_Specified(int Index)
  {  return FRsaCheck_Specified;  } 
  void __fastcall SetRsaDraftPolicyId(int Index, WideString _prop_val)
  {  FRsaDraftPolicyId = _prop_val; FRsaDraftPolicyId_Specified = true;  }
  bool __fastcall RsaDraftPolicyId_Specified(int Index)
  {  return FRsaDraftPolicyId_Specified;  } 
  void __fastcall SetSelectedVehicleDocument(int Index, Document* _prop_val)
  {  FSelectedVehicleDocument = _prop_val; FSelectedVehicleDocument_Specified = true;  }
  bool __fastcall SelectedVehicleDocument_Specified(int Index)
  {  return FSelectedVehicleDocument_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 
  void __fastcall SetVehicleKbmRsa(int Index, VehicleKbmRsaCalcResult* _prop_val)
  {  FVehicleKbmRsa = _prop_val; FVehicleKbmRsa_Specified = true;  }
  bool __fastcall VehicleKbmRsa_Specified(int Index)
  {  return FVehicleKbmRsa_Specified;  } 

public:
  __fastcall ~CalcResult();
__published:
  __property WideString CalculationErrors = { index=(IS_OPTN|IS_NLBL), read=FCalculationErrors, write=SetCalculationErrors, stored = CalculationErrors_Specified };
  __property guid       CalculationId = { index=(IS_OPTN), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property WideString   CheckSum = { index=(IS_OPTN|IS_NLBL), read=FCheckSum, write=SetCheckSum, stored = CheckSum_Specified };
  __property bool       ClientLevel = { index=(IS_OPTN|IS_NLBL), read=FClientLevel, write=SetClientLevel, stored = ClientLevel_Specified };
  __property ArrayOfClientReason ClientReasons = { index=(IS_OPTN|IS_NLBL), read=FClientReasons, write=SetClientReasons, stored = ClientReasons_Specified };
  __property DateTimeOffset* DateInsurancePremium = { index=(IS_OPTN|IS_NLBL), read=FDateInsurancePremium, write=SetDateInsurancePremium, stored = DateInsurancePremium_Specified };
  __property ArrayOfDriverCalcResult    Drivers = { index=(IS_OPTN|IS_NLBL), read=FDrivers, write=SetDrivers, stored = Drivers_Specified };
  __property bool         IsEOsago = { index=(IS_OPTN|IS_NLBL), read=FIsEOsago, write=SetIsEOsago, stored = IsEOsago_Specified };
  __property bool       IsNeedScans = { index=(IS_OPTN|IS_NLBL), read=FIsNeedScans, write=SetIsNeedScans, stored = IsNeedScans_Specified };
  __property bool       IsOwnerNotExistsInRsa = { index=(IS_OPTN|IS_NLBL), read=FIsOwnerNotExistsInRsa, write=SetIsOwnerNotExistsInRsa, stored = IsOwnerNotExistsInRsa_Specified };
  __property Coefficients*          K = { index=(IS_OPTN|IS_NLBL), read=FK, write=SetK, stored = K_Specified };
  __property TXSDateTime* KbmRequestDate = { index=(IS_OPTN|IS_NLBL), read=FKbmRequestDate, write=SetKbmRequestDate, stored = KbmRequestDate_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property TXSDecimal*    Premium = { index=(IS_OPTN), read=FPremium, write=SetPremium, stored = Premium_Specified };
  __property TXSDecimal* PremiumModify = { index=(IS_OPTN|IS_NLBL), read=FPremiumModify, write=SetPremiumModify, stored = PremiumModify_Specified };
  __property int        PrevDocOwnerKbm = { index=(IS_OPTN|IS_NLBL), read=FPrevDocOwnerKbm, write=SetPrevDocOwnerKbm, stored = PrevDocOwnerKbm_Specified };
  __property RSACheck*    RsaCheck = { index=(IS_OPTN|IS_NLBL), read=FRsaCheck, write=SetRsaCheck, stored = RsaCheck_Specified };
  __property WideString RsaDraftPolicyId = { index=(IS_OPTN|IS_NLBL), read=FRsaDraftPolicyId, write=SetRsaDraftPolicyId, stored = RsaDraftPolicyId_Specified };
  __property Document*  SelectedVehicleDocument = { index=(IS_OPTN|IS_NLBL), read=FSelectedVehicleDocument, write=SetSelectedVehicleDocument, stored = SelectedVehicleDocument_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
  __property VehicleKbmRsaCalcResult* VehicleKbmRsa = { index=(IS_OPTN|IS_NLBL), read=FVehicleKbmRsa, write=SetVehicleKbmRsa, stored = VehicleKbmRsa_Specified };
};




// ************************************************************************ //
// XML       : RSACheck, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RSACheck : public TRemotable {
private:
  RSACheckResult* FIdentificationInsurer;
  bool            FIdentificationInsurer_Specified;
  RSACheckResult* FInsurer;
  bool            FInsurer_Specified;
  RSACheckResult* FOwner;
  bool            FOwner_Specified;
  void __fastcall SetIdentificationInsurer(int Index, RSACheckResult* _prop_val)
  {  FIdentificationInsurer = _prop_val; FIdentificationInsurer_Specified = true;  }
  bool __fastcall IdentificationInsurer_Specified(int Index)
  {  return FIdentificationInsurer_Specified;  } 
  void __fastcall SetInsurer(int Index, RSACheckResult* _prop_val)
  {  FInsurer = _prop_val; FInsurer_Specified = true;  }
  bool __fastcall Insurer_Specified(int Index)
  {  return FInsurer_Specified;  } 
  void __fastcall SetOwner(int Index, RSACheckResult* _prop_val)
  {  FOwner = _prop_val; FOwner_Specified = true;  }
  bool __fastcall Owner_Specified(int Index)
  {  return FOwner_Specified;  } 

public:
  __fastcall ~RSACheck();
__published:
  __property RSACheckResult* IdentificationInsurer = { index=(IS_OPTN|IS_NLBL), read=FIdentificationInsurer, write=SetIdentificationInsurer, stored = IdentificationInsurer_Specified };
  __property RSACheckResult*    Insurer = { index=(IS_OPTN|IS_NLBL), read=FInsurer, write=SetInsurer, stored = Insurer_Specified };
  __property RSACheckResult*      Owner = { index=(IS_OPTN|IS_NLBL), read=FOwner, write=SetOwner, stored = Owner_Specified };
};




// ************************************************************************ //
// XML       : ClientReason, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ClientReason : public TRemotable {
private:
  WideString      FCode;
  bool            FCode_Specified;
  WideString      FText;
  bool            FText_Specified;
  void __fastcall SetCode(int Index, WideString _prop_val)
  {  FCode = _prop_val; FCode_Specified = true;  }
  bool __fastcall Code_Specified(int Index)
  {  return FCode_Specified;  } 
  void __fastcall SetText(int Index, WideString _prop_val)
  {  FText = _prop_val; FText_Specified = true;  }
  bool __fastcall Text_Specified(int Index)
  {  return FText_Specified;  } 
__published:
  __property WideString       Code = { index=(IS_OPTN|IS_NLBL), read=FCode, write=SetCode, stored = Code_Specified };
  __property WideString       Text = { index=(IS_OPTN|IS_NLBL), read=FText, write=SetText, stored = Text_Specified };
};




// ************************************************************************ //
// XML       : DriverCalcResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverCalcResult : public TRemotable {
private:
  TXSDateTime*    FBirthDate;
  bool            FBirthDate_Specified;
  int             FDriverId;
  bool            FDriverId_Specified;
  Document*       FDriverLicense;
  bool            FDriverLicense_Specified;
  WideString      FFullName;
  bool            FFullName_Specified;
  TXSDecimal*     FKbc;
  bool            FKbc_Specified;
  DriverKbmRsaCalcResult* FKbmRsa;
  bool            FKbmRsa_Specified;
  RSACheckResult* FRsaCheck;
  bool            FRsaCheck_Specified;
  void __fastcall SetBirthDate(int Index, TXSDateTime* _prop_val)
  {  FBirthDate = _prop_val; FBirthDate_Specified = true;  }
  bool __fastcall BirthDate_Specified(int Index)
  {  return FBirthDate_Specified;  } 
  void __fastcall SetDriverId(int Index, int _prop_val)
  {  FDriverId = _prop_val; FDriverId_Specified = true;  }
  bool __fastcall DriverId_Specified(int Index)
  {  return FDriverId_Specified;  } 
  void __fastcall SetDriverLicense(int Index, Document* _prop_val)
  {  FDriverLicense = _prop_val; FDriverLicense_Specified = true;  }
  bool __fastcall DriverLicense_Specified(int Index)
  {  return FDriverLicense_Specified;  } 
  void __fastcall SetFullName(int Index, WideString _prop_val)
  {  FFullName = _prop_val; FFullName_Specified = true;  }
  bool __fastcall FullName_Specified(int Index)
  {  return FFullName_Specified;  } 
  void __fastcall SetKbc(int Index, TXSDecimal* _prop_val)
  {  FKbc = _prop_val; FKbc_Specified = true;  }
  bool __fastcall Kbc_Specified(int Index)
  {  return FKbc_Specified;  } 
  void __fastcall SetKbmRsa(int Index, DriverKbmRsaCalcResult* _prop_val)
  {  FKbmRsa = _prop_val; FKbmRsa_Specified = true;  }
  bool __fastcall KbmRsa_Specified(int Index)
  {  return FKbmRsa_Specified;  } 
  void __fastcall SetRsaCheck(int Index, RSACheckResult* _prop_val)
  {  FRsaCheck = _prop_val; FRsaCheck_Specified = true;  }
  bool __fastcall RsaCheck_Specified(int Index)
  {  return FRsaCheck_Specified;  } 

public:
  __fastcall ~DriverCalcResult();
__published:
  __property TXSDateTime*  BirthDate = { index=(IS_OPTN|IS_NLBL), read=FBirthDate, write=SetBirthDate, stored = BirthDate_Specified };
  __property int          DriverId = { index=(IS_OPTN|IS_NLBL), read=FDriverId, write=SetDriverId, stored = DriverId_Specified };
  __property Document*  DriverLicense = { index=(IS_OPTN|IS_NLBL), read=FDriverLicense, write=SetDriverLicense, stored = DriverLicense_Specified };
  __property WideString   FullName = { index=(IS_OPTN|IS_NLBL), read=FFullName, write=SetFullName, stored = FullName_Specified };
  __property TXSDecimal*        Kbc = { index=(IS_OPTN|IS_NLBL), read=FKbc, write=SetKbc, stored = Kbc_Specified };
  __property DriverKbmRsaCalcResult*     KbmRsa = { index=(IS_OPTN|IS_NLBL), read=FKbmRsa, write=SetKbmRsa, stored = KbmRsa_Specified };
  __property RSACheckResult*   RsaCheck = { index=(IS_OPTN|IS_NLBL), read=FRsaCheck, write=SetRsaCheck, stored = RsaCheck_Specified };
};




// ************************************************************************ //
// XML       : RSACheckResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RSACheckResult : public TRemotable {
private:
  DateTimeOffset* FCheckDate;
  bool            FCheckDate_Specified;
  WideString      FCheckId;
  bool            FCheckId_Specified;
  bool            FIsSubjectChecked;
  bool            FIsSubjectChecked_Specified;
  bool            FIsSubjectFound;
  bool            FIsSubjectFound_Specified;
  void __fastcall SetCheckDate(int Index, DateTimeOffset* _prop_val)
  {  FCheckDate = _prop_val; FCheckDate_Specified = true;  }
  bool __fastcall CheckDate_Specified(int Index)
  {  return FCheckDate_Specified;  } 
  void __fastcall SetCheckId(int Index, WideString _prop_val)
  {  FCheckId = _prop_val; FCheckId_Specified = true;  }
  bool __fastcall CheckId_Specified(int Index)
  {  return FCheckId_Specified;  } 
  void __fastcall SetIsSubjectChecked(int Index, bool _prop_val)
  {  FIsSubjectChecked = _prop_val; FIsSubjectChecked_Specified = true;  }
  bool __fastcall IsSubjectChecked_Specified(int Index)
  {  return FIsSubjectChecked_Specified;  } 
  void __fastcall SetIsSubjectFound(int Index, bool _prop_val)
  {  FIsSubjectFound = _prop_val; FIsSubjectFound_Specified = true;  }
  bool __fastcall IsSubjectFound_Specified(int Index)
  {  return FIsSubjectFound_Specified;  } 

public:
  __fastcall ~RSACheckResult();
__published:
  __property DateTimeOffset*  CheckDate = { index=(IS_OPTN|IS_NLBL), read=FCheckDate, write=SetCheckDate, stored = CheckDate_Specified };
  __property WideString    CheckId = { index=(IS_OPTN|IS_NLBL), read=FCheckId, write=SetCheckId, stored = CheckId_Specified };
  __property bool       IsSubjectChecked = { index=(IS_OPTN|IS_NLBL), read=FIsSubjectChecked, write=SetIsSubjectChecked, stored = IsSubjectChecked_Specified };
  __property bool       IsSubjectFound = { index=(IS_OPTN|IS_NLBL), read=FIsSubjectFound, write=SetIsSubjectFound, stored = IsSubjectFound_Specified };
};


typedef DynamicArray<ClaimResult*> ArrayOfClaimResult; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : DriverKbmRsaCalcResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverKbmRsaCalcResult : public TRemotable {
private:
  WideString      FClass;
  bool            FClass_Specified;
  ArrayOfClaimResult FDriverClaims;
  bool            FDriverClaims_Specified;
  WideString      FError;
  bool            FError_Specified;
  WideString      FErrorCode;
  bool            FErrorCode_Specified;
  bool            FIsDriverNotExistsInRsa;
  bool            FIsDriverNotExistsInRsa_Specified;
  WideString      FMessage;
  bool            FMessage_Specified;
  WideString      FMessageCode;
  bool            FMessageCode_Specified;
  int             FPrevDocDriverKbm;
  bool            FPrevDocDriverKbm_Specified;
  WideString      FPrevPolicyCompany;
  bool            FPrevPolicyCompany_Specified;
  WideString      FPrevPolicyNumber;
  bool            FPrevPolicyNumber_Specified;
  WideString      FPrevPolicySeries;
  bool            FPrevPolicySeries_Specified;
  WideString      FRequestId;
  bool            FRequestId_Specified;
  TXSDecimal*     FValue;
  bool            FValue_Specified;
  void __fastcall SetClass(int Index, WideString _prop_val)
  {  FClass = _prop_val; FClass_Specified = true;  }
  bool __fastcall Class_Specified(int Index)
  {  return FClass_Specified;  } 
  void __fastcall SetDriverClaims(int Index, ArrayOfClaimResult _prop_val)
  {  FDriverClaims = _prop_val; FDriverClaims_Specified = true;  }
  bool __fastcall DriverClaims_Specified(int Index)
  {  return FDriverClaims_Specified;  } 
  void __fastcall SetError(int Index, WideString _prop_val)
  {  FError = _prop_val; FError_Specified = true;  }
  bool __fastcall Error_Specified(int Index)
  {  return FError_Specified;  } 
  void __fastcall SetErrorCode(int Index, WideString _prop_val)
  {  FErrorCode = _prop_val; FErrorCode_Specified = true;  }
  bool __fastcall ErrorCode_Specified(int Index)
  {  return FErrorCode_Specified;  } 
  void __fastcall SetIsDriverNotExistsInRsa(int Index, bool _prop_val)
  {  FIsDriverNotExistsInRsa = _prop_val; FIsDriverNotExistsInRsa_Specified = true;  }
  bool __fastcall IsDriverNotExistsInRsa_Specified(int Index)
  {  return FIsDriverNotExistsInRsa_Specified;  } 
  void __fastcall SetMessage(int Index, WideString _prop_val)
  {  FMessage = _prop_val; FMessage_Specified = true;  }
  bool __fastcall Message_Specified(int Index)
  {  return FMessage_Specified;  } 
  void __fastcall SetMessageCode(int Index, WideString _prop_val)
  {  FMessageCode = _prop_val; FMessageCode_Specified = true;  }
  bool __fastcall MessageCode_Specified(int Index)
  {  return FMessageCode_Specified;  } 
  void __fastcall SetPrevDocDriverKbm(int Index, int _prop_val)
  {  FPrevDocDriverKbm = _prop_val; FPrevDocDriverKbm_Specified = true;  }
  bool __fastcall PrevDocDriverKbm_Specified(int Index)
  {  return FPrevDocDriverKbm_Specified;  } 
  void __fastcall SetPrevPolicyCompany(int Index, WideString _prop_val)
  {  FPrevPolicyCompany = _prop_val; FPrevPolicyCompany_Specified = true;  }
  bool __fastcall PrevPolicyCompany_Specified(int Index)
  {  return FPrevPolicyCompany_Specified;  } 
  void __fastcall SetPrevPolicyNumber(int Index, WideString _prop_val)
  {  FPrevPolicyNumber = _prop_val; FPrevPolicyNumber_Specified = true;  }
  bool __fastcall PrevPolicyNumber_Specified(int Index)
  {  return FPrevPolicyNumber_Specified;  } 
  void __fastcall SetPrevPolicySeries(int Index, WideString _prop_val)
  {  FPrevPolicySeries = _prop_val; FPrevPolicySeries_Specified = true;  }
  bool __fastcall PrevPolicySeries_Specified(int Index)
  {  return FPrevPolicySeries_Specified;  } 
  void __fastcall SetRequestId(int Index, WideString _prop_val)
  {  FRequestId = _prop_val; FRequestId_Specified = true;  }
  bool __fastcall RequestId_Specified(int Index)
  {  return FRequestId_Specified;  } 
  void __fastcall SetValue(int Index, TXSDecimal* _prop_val)
  {  FValue = _prop_val; FValue_Specified = true;  }
  bool __fastcall Value_Specified(int Index)
  {  return FValue_Specified;  } 

public:
  __fastcall ~DriverKbmRsaCalcResult();
__published:
  __property WideString      Class = { index=(IS_OPTN|IS_NLBL), read=FClass, write=SetClass, stored = Class_Specified };
  __property ArrayOfClaimResult DriverClaims = { index=(IS_OPTN|IS_NLBL), read=FDriverClaims, write=SetDriverClaims, stored = DriverClaims_Specified };
  __property WideString      Error = { index=(IS_OPTN|IS_NLBL), read=FError, write=SetError, stored = Error_Specified };
  __property WideString  ErrorCode = { index=(IS_OPTN|IS_NLBL), read=FErrorCode, write=SetErrorCode, stored = ErrorCode_Specified };
  __property bool       IsDriverNotExistsInRsa = { index=(IS_OPTN|IS_NLBL), read=FIsDriverNotExistsInRsa, write=SetIsDriverNotExistsInRsa, stored = IsDriverNotExistsInRsa_Specified };
  __property WideString    Message = { index=(IS_OPTN|IS_NLBL), read=FMessage, write=SetMessage, stored = Message_Specified };
  __property WideString MessageCode = { index=(IS_OPTN|IS_NLBL), read=FMessageCode, write=SetMessageCode, stored = MessageCode_Specified };
  __property int        PrevDocDriverKbm = { index=(IS_OPTN|IS_NLBL), read=FPrevDocDriverKbm, write=SetPrevDocDriverKbm, stored = PrevDocDriverKbm_Specified };
  __property WideString PrevPolicyCompany = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicyCompany, write=SetPrevPolicyCompany, stored = PrevPolicyCompany_Specified };
  __property WideString PrevPolicyNumber = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicyNumber, write=SetPrevPolicyNumber, stored = PrevPolicyNumber_Specified };
  __property WideString PrevPolicySeries = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicySeries, write=SetPrevPolicySeries, stored = PrevPolicySeries_Specified };
  __property WideString  RequestId = { index=(IS_OPTN|IS_NLBL), read=FRequestId, write=SetRequestId, stored = RequestId_Specified };
  __property TXSDecimal*      Value = { index=(IS_OPTN), read=FValue, write=SetValue, stored = Value_Specified };
};




// ************************************************************************ //
// XML       : ClaimResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ClaimResult : public TRemotable {
private:
  WideString      FClaimDate;
  bool            FClaimDate_Specified;
  WideString      FClaimPolicyInsurer;
  bool            FClaimPolicyInsurer_Specified;
  WideString      FClaimPolicyNumber;
  bool            FClaimPolicyNumber_Specified;
  WideString      FClaimPolicySeries;
  bool            FClaimPolicySeries_Specified;
  void __fastcall SetClaimDate(int Index, WideString _prop_val)
  {  FClaimDate = _prop_val; FClaimDate_Specified = true;  }
  bool __fastcall ClaimDate_Specified(int Index)
  {  return FClaimDate_Specified;  } 
  void __fastcall SetClaimPolicyInsurer(int Index, WideString _prop_val)
  {  FClaimPolicyInsurer = _prop_val; FClaimPolicyInsurer_Specified = true;  }
  bool __fastcall ClaimPolicyInsurer_Specified(int Index)
  {  return FClaimPolicyInsurer_Specified;  } 
  void __fastcall SetClaimPolicyNumber(int Index, WideString _prop_val)
  {  FClaimPolicyNumber = _prop_val; FClaimPolicyNumber_Specified = true;  }
  bool __fastcall ClaimPolicyNumber_Specified(int Index)
  {  return FClaimPolicyNumber_Specified;  } 
  void __fastcall SetClaimPolicySeries(int Index, WideString _prop_val)
  {  FClaimPolicySeries = _prop_val; FClaimPolicySeries_Specified = true;  }
  bool __fastcall ClaimPolicySeries_Specified(int Index)
  {  return FClaimPolicySeries_Specified;  } 
__published:
  __property WideString  ClaimDate = { index=(IS_OPTN|IS_NLBL), read=FClaimDate, write=SetClaimDate, stored = ClaimDate_Specified };
  __property WideString ClaimPolicyInsurer = { index=(IS_OPTN|IS_NLBL), read=FClaimPolicyInsurer, write=SetClaimPolicyInsurer, stored = ClaimPolicyInsurer_Specified };
  __property WideString ClaimPolicyNumber = { index=(IS_OPTN|IS_NLBL), read=FClaimPolicyNumber, write=SetClaimPolicyNumber, stored = ClaimPolicyNumber_Specified };
  __property WideString ClaimPolicySeries = { index=(IS_OPTN|IS_NLBL), read=FClaimPolicySeries, write=SetClaimPolicySeries, stored = ClaimPolicySeries_Specified };
};


typedef DynamicArray<VehicleRsaCheckResult*> ArrayOfVehicleRsaCheckResult; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : VehicleKbmRsaCalcResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleKbmRsaCalcResult : public TRemotable {
private:
  WideString      FClass;
  bool            FClass_Specified;
  WideString      FError;
  bool            FError_Specified;
  WideString      FMessage;
  bool            FMessage_Specified;
  WideString      FMessageCode;
  bool            FMessageCode_Specified;
  WideString      FPrevPolicyCompany;
  bool            FPrevPolicyCompany_Specified;
  WideString      FPrevPolicyNumber;
  bool            FPrevPolicyNumber_Specified;
  WideString      FPrevPolicySeries;
  bool            FPrevPolicySeries_Specified;
  ArrayOfVehicleRsaCheckResult FRsaCheck;
  bool            FRsaCheck_Specified;
  WideString      FRsaRequestError;
  bool            FRsaRequestError_Specified;
  WideString      FRsaRequestId;
  bool            FRsaRequestId_Specified;
  ArrayOfClaimResult FVehicleClaims;
  bool            FVehicleClaims_Specified;
  void __fastcall SetClass(int Index, WideString _prop_val)
  {  FClass = _prop_val; FClass_Specified = true;  }
  bool __fastcall Class_Specified(int Index)
  {  return FClass_Specified;  } 
  void __fastcall SetError(int Index, WideString _prop_val)
  {  FError = _prop_val; FError_Specified = true;  }
  bool __fastcall Error_Specified(int Index)
  {  return FError_Specified;  } 
  void __fastcall SetMessage(int Index, WideString _prop_val)
  {  FMessage = _prop_val; FMessage_Specified = true;  }
  bool __fastcall Message_Specified(int Index)
  {  return FMessage_Specified;  } 
  void __fastcall SetMessageCode(int Index, WideString _prop_val)
  {  FMessageCode = _prop_val; FMessageCode_Specified = true;  }
  bool __fastcall MessageCode_Specified(int Index)
  {  return FMessageCode_Specified;  } 
  void __fastcall SetPrevPolicyCompany(int Index, WideString _prop_val)
  {  FPrevPolicyCompany = _prop_val; FPrevPolicyCompany_Specified = true;  }
  bool __fastcall PrevPolicyCompany_Specified(int Index)
  {  return FPrevPolicyCompany_Specified;  } 
  void __fastcall SetPrevPolicyNumber(int Index, WideString _prop_val)
  {  FPrevPolicyNumber = _prop_val; FPrevPolicyNumber_Specified = true;  }
  bool __fastcall PrevPolicyNumber_Specified(int Index)
  {  return FPrevPolicyNumber_Specified;  } 
  void __fastcall SetPrevPolicySeries(int Index, WideString _prop_val)
  {  FPrevPolicySeries = _prop_val; FPrevPolicySeries_Specified = true;  }
  bool __fastcall PrevPolicySeries_Specified(int Index)
  {  return FPrevPolicySeries_Specified;  } 
  void __fastcall SetRsaCheck(int Index, ArrayOfVehicleRsaCheckResult _prop_val)
  {  FRsaCheck = _prop_val; FRsaCheck_Specified = true;  }
  bool __fastcall RsaCheck_Specified(int Index)
  {  return FRsaCheck_Specified;  } 
  void __fastcall SetRsaRequestError(int Index, WideString _prop_val)
  {  FRsaRequestError = _prop_val; FRsaRequestError_Specified = true;  }
  bool __fastcall RsaRequestError_Specified(int Index)
  {  return FRsaRequestError_Specified;  } 
  void __fastcall SetRsaRequestId(int Index, WideString _prop_val)
  {  FRsaRequestId = _prop_val; FRsaRequestId_Specified = true;  }
  bool __fastcall RsaRequestId_Specified(int Index)
  {  return FRsaRequestId_Specified;  } 
  void __fastcall SetVehicleClaims(int Index, ArrayOfClaimResult _prop_val)
  {  FVehicleClaims = _prop_val; FVehicleClaims_Specified = true;  }
  bool __fastcall VehicleClaims_Specified(int Index)
  {  return FVehicleClaims_Specified;  } 

public:
  __fastcall ~VehicleKbmRsaCalcResult();
__published:
  __property WideString      Class = { index=(IS_OPTN|IS_NLBL), read=FClass, write=SetClass, stored = Class_Specified };
  __property WideString      Error = { index=(IS_OPTN|IS_NLBL), read=FError, write=SetError, stored = Error_Specified };
  __property WideString    Message = { index=(IS_OPTN|IS_NLBL), read=FMessage, write=SetMessage, stored = Message_Specified };
  __property WideString MessageCode = { index=(IS_OPTN|IS_NLBL), read=FMessageCode, write=SetMessageCode, stored = MessageCode_Specified };
  __property WideString PrevPolicyCompany = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicyCompany, write=SetPrevPolicyCompany, stored = PrevPolicyCompany_Specified };
  __property WideString PrevPolicyNumber = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicyNumber, write=SetPrevPolicyNumber, stored = PrevPolicyNumber_Specified };
  __property WideString PrevPolicySeries = { index=(IS_OPTN|IS_NLBL), read=FPrevPolicySeries, write=SetPrevPolicySeries, stored = PrevPolicySeries_Specified };
  __property ArrayOfVehicleRsaCheckResult   RsaCheck = { index=(IS_OPTN|IS_NLBL), read=FRsaCheck, write=SetRsaCheck, stored = RsaCheck_Specified };
  __property WideString RsaRequestError = { index=(IS_OPTN|IS_NLBL), read=FRsaRequestError, write=SetRsaRequestError, stored = RsaRequestError_Specified };
  __property WideString RsaRequestId = { index=(IS_OPTN|IS_NLBL), read=FRsaRequestId, write=SetRsaRequestId, stored = RsaRequestId_Specified };
  __property ArrayOfClaimResult VehicleClaims = { index=(IS_OPTN|IS_NLBL), read=FVehicleClaims, write=SetVehicleClaims, stored = VehicleClaims_Specified };
};




// ************************************************************************ //
// XML       : VehicleRsaCheckResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleRsaCheckResult : public RSACheckResult {
private:
  WideString      FDocumentType;
  bool            FDocumentType_Specified;
  void __fastcall SetDocumentType(int Index, WideString _prop_val)
  {  FDocumentType = _prop_val; FDocumentType_Specified = true;  }
  bool __fastcall DocumentType_Specified(int Index)
  {  return FDocumentType_Specified;  } 
__published:
  __property WideString DocumentType = { index=(IS_OPTN|IS_NLBL), read=FDocumentType, write=SetDocumentType, stored = DocumentType_Specified };
};




// ************************************************************************ //
// XML       : PreviousPolicy, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PreviousPolicy : public Document {
private:
  WideString      FPreviousDocumentInsurer;
  bool            FPreviousDocumentInsurer_Specified;
  void __fastcall SetPreviousDocumentInsurer(int Index, WideString _prop_val)
  {  FPreviousDocumentInsurer = _prop_val; FPreviousDocumentInsurer_Specified = true;  }
  bool __fastcall PreviousDocumentInsurer_Specified(int Index)
  {  return FPreviousDocumentInsurer_Specified;  } 
__published:
  __property WideString PreviousDocumentInsurer = { index=(IS_OPTN|IS_NLBL), read=FPreviousDocumentInsurer, write=SetPreviousDocumentInsurer, stored = PreviousDocumentInsurer_Specified };
};




// ************************************************************************ //
// XML       : PrintRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintRequest : public TRemotable {
private:
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  bool            FClientAccept;
  bool            FClientAccept_Specified;
  TXSDateTime*    FContractDate;
  bool            FContractDate_Specified;
  guid            FCorellationId;
  bool            FCorellationId_Specified;
  bool            FDraft;
  bool            FDraft_Specified;
  TXSDecimal*     FFirstPremium;
  bool            FFirstPremium_Specified;
  Document*       FInspectionDocument;
  bool            FInspectionDocument_Specified;
  WideString      FInspectionOperatorId;
  bool            FInspectionOperatorId_Specified;
  AddressEntry*   FInsurantAddress;
  bool            FInsurantAddress_Specified;
  Contacts*       FInsurantContacts;
  bool            FInsurantContacts_Specified;
  PersonName*     FInsurer;
  bool            FInsurer_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  WideString      FOtherInformation;
  bool            FOtherInformation_Specified;
  AddressEntry*   FOwnerAddress;
  bool            FOwnerAddress_Specified;
  DateTimeOffset* FPolicyRefundDate;
  bool            FPolicyRefundDate_Specified;
  DateTimeOffset* FPrevContractDate;
  bool            FPrevContractDate_Specified;
  PreviousPolicy* FPreviousPolicy;
  bool            FPreviousPolicy_Specified;
  PrintOnlyDocumentType FPrintOnlyDocumentType;
  bool            FPrintOnlyDocumentType_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  WideString      FSpecialNotes;
  bool            FSpecialNotes_Specified;
  WideString      FSpecialNotesE;
  bool            FSpecialNotesE_Specified;
  int             FUnladenMass;
  bool            FUnladenMass_Specified;
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetClientAccept(int Index, bool _prop_val)
  {  FClientAccept = _prop_val; FClientAccept_Specified = true;  }
  bool __fastcall ClientAccept_Specified(int Index)
  {  return FClientAccept_Specified;  } 
  void __fastcall SetContractDate(int Index, TXSDateTime* _prop_val)
  {  FContractDate = _prop_val; FContractDate_Specified = true;  }
  bool __fastcall ContractDate_Specified(int Index)
  {  return FContractDate_Specified;  } 
  void __fastcall SetCorellationId(int Index, guid _prop_val)
  {  FCorellationId = _prop_val; FCorellationId_Specified = true;  }
  bool __fastcall CorellationId_Specified(int Index)
  {  return FCorellationId_Specified;  } 
  void __fastcall SetDraft(int Index, bool _prop_val)
  {  FDraft = _prop_val; FDraft_Specified = true;  }
  bool __fastcall Draft_Specified(int Index)
  {  return FDraft_Specified;  } 
  void __fastcall SetFirstPremium(int Index, TXSDecimal* _prop_val)
  {  FFirstPremium = _prop_val; FFirstPremium_Specified = true;  }
  bool __fastcall FirstPremium_Specified(int Index)
  {  return FFirstPremium_Specified;  } 
  void __fastcall SetInspectionDocument(int Index, Document* _prop_val)
  {  FInspectionDocument = _prop_val; FInspectionDocument_Specified = true;  }
  bool __fastcall InspectionDocument_Specified(int Index)
  {  return FInspectionDocument_Specified;  } 
  void __fastcall SetInspectionOperatorId(int Index, WideString _prop_val)
  {  FInspectionOperatorId = _prop_val; FInspectionOperatorId_Specified = true;  }
  bool __fastcall InspectionOperatorId_Specified(int Index)
  {  return FInspectionOperatorId_Specified;  } 
  void __fastcall SetInsurantAddress(int Index, AddressEntry* _prop_val)
  {  FInsurantAddress = _prop_val; FInsurantAddress_Specified = true;  }
  bool __fastcall InsurantAddress_Specified(int Index)
  {  return FInsurantAddress_Specified;  } 
  void __fastcall SetInsurantContacts(int Index, Contacts* _prop_val)
  {  FInsurantContacts = _prop_val; FInsurantContacts_Specified = true;  }
  bool __fastcall InsurantContacts_Specified(int Index)
  {  return FInsurantContacts_Specified;  } 
  void __fastcall SetInsurer(int Index, PersonName* _prop_val)
  {  FInsurer = _prop_val; FInsurer_Specified = true;  }
  bool __fastcall Insurer_Specified(int Index)
  {  return FInsurer_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetOtherInformation(int Index, WideString _prop_val)
  {  FOtherInformation = _prop_val; FOtherInformation_Specified = true;  }
  bool __fastcall OtherInformation_Specified(int Index)
  {  return FOtherInformation_Specified;  } 
  void __fastcall SetOwnerAddress(int Index, AddressEntry* _prop_val)
  {  FOwnerAddress = _prop_val; FOwnerAddress_Specified = true;  }
  bool __fastcall OwnerAddress_Specified(int Index)
  {  return FOwnerAddress_Specified;  } 
  void __fastcall SetPolicyRefundDate(int Index, DateTimeOffset* _prop_val)
  {  FPolicyRefundDate = _prop_val; FPolicyRefundDate_Specified = true;  }
  bool __fastcall PolicyRefundDate_Specified(int Index)
  {  return FPolicyRefundDate_Specified;  } 
  void __fastcall SetPrevContractDate(int Index, DateTimeOffset* _prop_val)
  {  FPrevContractDate = _prop_val; FPrevContractDate_Specified = true;  }
  bool __fastcall PrevContractDate_Specified(int Index)
  {  return FPrevContractDate_Specified;  } 
  void __fastcall SetPreviousPolicy(int Index, PreviousPolicy* _prop_val)
  {  FPreviousPolicy = _prop_val; FPreviousPolicy_Specified = true;  }
  bool __fastcall PreviousPolicy_Specified(int Index)
  {  return FPreviousPolicy_Specified;  } 
  void __fastcall SetPrintOnlyDocumentType(int Index, PrintOnlyDocumentType _prop_val)
  {  FPrintOnlyDocumentType = _prop_val; FPrintOnlyDocumentType_Specified = true;  }
  bool __fastcall PrintOnlyDocumentType_Specified(int Index)
  {  return FPrintOnlyDocumentType_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 
  void __fastcall SetSpecialNotes(int Index, WideString _prop_val)
  {  FSpecialNotes = _prop_val; FSpecialNotes_Specified = true;  }
  bool __fastcall SpecialNotes_Specified(int Index)
  {  return FSpecialNotes_Specified;  } 
  void __fastcall SetSpecialNotesE(int Index, WideString _prop_val)
  {  FSpecialNotesE = _prop_val; FSpecialNotesE_Specified = true;  }
  bool __fastcall SpecialNotesE_Specified(int Index)
  {  return FSpecialNotesE_Specified;  } 
  void __fastcall SetUnladenMass(int Index, int _prop_val)
  {  FUnladenMass = _prop_val; FUnladenMass_Specified = true;  }
  bool __fastcall UnladenMass_Specified(int Index)
  {  return FUnladenMass_Specified;  } 

public:
  __fastcall ~PrintRequest();
__published:
  __property guid       CalculationId = { index=(IS_OPTN), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property bool       ClientAccept = { index=(IS_OPTN|IS_NLBL), read=FClientAccept, write=SetClientAccept, stored = ClientAccept_Specified };
  __property TXSDateTime* ContractDate = { index=(IS_OPTN), read=FContractDate, write=SetContractDate, stored = ContractDate_Specified };
  __property guid       CorellationId = { index=(IS_OPTN|IS_NLBL), read=FCorellationId, write=SetCorellationId, stored = CorellationId_Specified };
  __property bool            Draft = { index=(IS_OPTN|IS_NLBL), read=FDraft, write=SetDraft, stored = Draft_Specified };
  __property TXSDecimal* FirstPremium = { index=(IS_OPTN|IS_NLBL), read=FFirstPremium, write=SetFirstPremium, stored = FirstPremium_Specified };
  __property Document*  InspectionDocument = { index=(IS_OPTN|IS_NLBL), read=FInspectionDocument, write=SetInspectionDocument, stored = InspectionDocument_Specified };
  __property WideString InspectionOperatorId = { index=(IS_OPTN|IS_NLBL), read=FInspectionOperatorId, write=SetInspectionOperatorId, stored = InspectionOperatorId_Specified };
  __property AddressEntry* InsurantAddress = { index=(IS_OPTN|IS_NLBL), read=FInsurantAddress, write=SetInsurantAddress, stored = InsurantAddress_Specified };
  __property Contacts*  InsurantContacts = { index=(IS_OPTN|IS_NLBL), read=FInsurantContacts, write=SetInsurantContacts, stored = InsurantContacts_Specified };
  __property PersonName*    Insurer = { index=(IS_OPTN|IS_NLBL), read=FInsurer, write=SetInsurer, stored = Insurer_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property WideString OtherInformation = { index=(IS_OPTN|IS_NLBL), read=FOtherInformation, write=SetOtherInformation, stored = OtherInformation_Specified };
  __property AddressEntry* OwnerAddress = { index=(IS_OPTN|IS_NLBL), read=FOwnerAddress, write=SetOwnerAddress, stored = OwnerAddress_Specified };
  __property DateTimeOffset* PolicyRefundDate = { index=(IS_OPTN|IS_NLBL), read=FPolicyRefundDate, write=SetPolicyRefundDate, stored = PolicyRefundDate_Specified };
  __property DateTimeOffset* PrevContractDate = { index=(IS_OPTN|IS_NLBL), read=FPrevContractDate, write=SetPrevContractDate, stored = PrevContractDate_Specified };
  __property PreviousPolicy* PreviousPolicy = { index=(IS_OPTN|IS_NLBL), read=FPreviousPolicy, write=SetPreviousPolicy, stored = PreviousPolicy_Specified };
  __property PrintOnlyDocumentType PrintOnlyDocumentType = { index=(IS_OPTN|IS_NLBL), read=FPrintOnlyDocumentType, write=SetPrintOnlyDocumentType, stored = PrintOnlyDocumentType_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
  __property WideString SpecialNotes = { index=(IS_OPTN|IS_NLBL), read=FSpecialNotes, write=SetSpecialNotes, stored = SpecialNotes_Specified };
  __property WideString SpecialNotesE = { index=(IS_OPTN|IS_NLBL), read=FSpecialNotesE, write=SetSpecialNotesE, stored = SpecialNotesE_Specified };
  __property int        UnladenMass = { index=(IS_OPTN|IS_NLBL), read=FUnladenMass, write=SetUnladenMass, stored = UnladenMass_Specified };
};




// ************************************************************************ //
// XML       : FindServiceStationsRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class FindServiceStationsRequest : public TRemotable {
private:
  WideString      FClassifierVehicleModelCode;
  bool            FClassifierVehicleModelCode_Specified;
  WideString      FInsuranceCompany;
  bool            FInsuranceCompany_Specified;
  WideString      FKladrCode;
  bool            FKladrCode_Specified;
  int             FManufactureYear;
  bool            FManufactureYear_Specified;
  WideString      FPolicyTypeCode;
  bool            FPolicyTypeCode_Specified;
  void __fastcall SetClassifierVehicleModelCode(int Index, WideString _prop_val)
  {  FClassifierVehicleModelCode = _prop_val; FClassifierVehicleModelCode_Specified = true;  }
  bool __fastcall ClassifierVehicleModelCode_Specified(int Index)
  {  return FClassifierVehicleModelCode_Specified;  } 
  void __fastcall SetInsuranceCompany(int Index, WideString _prop_val)
  {  FInsuranceCompany = _prop_val; FInsuranceCompany_Specified = true;  }
  bool __fastcall InsuranceCompany_Specified(int Index)
  {  return FInsuranceCompany_Specified;  } 
  void __fastcall SetKladrCode(int Index, WideString _prop_val)
  {  FKladrCode = _prop_val; FKladrCode_Specified = true;  }
  bool __fastcall KladrCode_Specified(int Index)
  {  return FKladrCode_Specified;  } 
  void __fastcall SetManufactureYear(int Index, int _prop_val)
  {  FManufactureYear = _prop_val; FManufactureYear_Specified = true;  }
  bool __fastcall ManufactureYear_Specified(int Index)
  {  return FManufactureYear_Specified;  } 
  void __fastcall SetPolicyTypeCode(int Index, WideString _prop_val)
  {  FPolicyTypeCode = _prop_val; FPolicyTypeCode_Specified = true;  }
  bool __fastcall PolicyTypeCode_Specified(int Index)
  {  return FPolicyTypeCode_Specified;  } 
__published:
  __property WideString ClassifierVehicleModelCode = { index=(IS_OPTN|IS_NLBL), read=FClassifierVehicleModelCode, write=SetClassifierVehicleModelCode, stored = ClassifierVehicleModelCode_Specified };
  __property WideString InsuranceCompany = { index=(IS_OPTN|IS_NLBL), read=FInsuranceCompany, write=SetInsuranceCompany, stored = InsuranceCompany_Specified };
  __property WideString  KladrCode = { index=(IS_OPTN|IS_NLBL), read=FKladrCode, write=SetKladrCode, stored = KladrCode_Specified };
  __property int        ManufactureYear = { index=(IS_OPTN|IS_NLBL), read=FManufactureYear, write=SetManufactureYear, stored = ManufactureYear_Specified };
  __property WideString PolicyTypeCode = { index=(IS_OPTN|IS_NLBL), read=FPolicyTypeCode, write=SetPolicyTypeCode, stored = PolicyTypeCode_Specified };
};




// ************************************************************************ //
// XML       : FindResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class FindResult : public TRemotable {
private:
  WideString   FDocument;
  bool            FDocument_Specified;
  ArrayOfServiceStation FServiceStations;
  bool            FServiceStations_Specified;
  FindServiceStationsStatus FStatus;
  bool            FStatus_Specified;
  void __fastcall SetDocument(int Index, WideString _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetServiceStations(int Index, ArrayOfServiceStation _prop_val)
  {  FServiceStations = _prop_val; FServiceStations_Specified = true;  }
  bool __fastcall ServiceStations_Specified(int Index)
  {  return FServiceStations_Specified;  } 
  void __fastcall SetStatus(int Index, FindServiceStationsStatus _prop_val)
  {  FStatus = _prop_val; FStatus_Specified = true;  }
  bool __fastcall Status_Specified(int Index)
  {  return FStatus_Specified;  } 

public:
  __fastcall ~FindResult();
__published:
  __property WideString   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property ArrayOfServiceStation ServiceStations = { index=(IS_OPTN|IS_NLBL), read=FServiceStations, write=SetServiceStations, stored = ServiceStations_Specified };
  __property FindServiceStationsStatus     Status = { index=(IS_OPTN), read=FStatus, write=SetStatus, stored = Status_Specified };
};




// ************************************************************************ //
// XML       : CheckPaymentRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CheckPaymentRequest : public TRemotable {
private:
  WideString      FBranchCode;
  bool            FBranchCode_Specified;
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  int             FCodeSystemFrom;
  bool            FCodeSystemFrom_Specified;
  WideString      FLnr;
  bool            FLnr_Specified;
  Payment*        FPayment;
  bool            FPayment_Specified;
  void __fastcall SetBranchCode(int Index, WideString _prop_val)
  {  FBranchCode = _prop_val; FBranchCode_Specified = true;  }
  bool __fastcall BranchCode_Specified(int Index)
  {  return FBranchCode_Specified;  } 
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetCodeSystemFrom(int Index, int _prop_val)
  {  FCodeSystemFrom = _prop_val; FCodeSystemFrom_Specified = true;  }
  bool __fastcall CodeSystemFrom_Specified(int Index)
  {  return FCodeSystemFrom_Specified;  } 
  void __fastcall SetLnr(int Index, WideString _prop_val)
  {  FLnr = _prop_val; FLnr_Specified = true;  }
  bool __fastcall Lnr_Specified(int Index)
  {  return FLnr_Specified;  } 
  void __fastcall SetPayment(int Index, Payment* _prop_val)
  {  FPayment = _prop_val; FPayment_Specified = true;  }
  bool __fastcall Payment_Specified(int Index)
  {  return FPayment_Specified;  } 

public:
  __fastcall ~CheckPaymentRequest();
__published:
  __property WideString BranchCode = { index=(IS_OPTN|IS_NLBL), read=FBranchCode, write=SetBranchCode, stored = BranchCode_Specified };
  __property guid       CalculationId = { index=(IS_OPTN), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property int        CodeSystemFrom = { index=(IS_OPTN), read=FCodeSystemFrom, write=SetCodeSystemFrom, stored = CodeSystemFrom_Specified };
  __property WideString        Lnr = { index=(IS_OPTN|IS_NLBL), read=FLnr, write=SetLnr, stored = Lnr_Specified };
  __property Payment*      Payment = { index=(IS_OPTN|IS_NLBL), read=FPayment, write=SetPayment, stored = Payment_Specified };
};




// ************************************************************************ //
// XML       : Payment, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Payment : public TRemotable {
private:
  WideString      FConfirmCode;
  bool            FConfirmCode_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  TXSDateTime*    FPaymentDate;
  bool            FPaymentDate_Specified;
  int             FPaymentDocType;
  bool            FPaymentDocType_Specified;
  int             FPaymentMethod;
  bool            FPaymentMethod_Specified;
  int             FPaymentType;
  bool            FPaymentType_Specified;
  WideString      FReceiptNumber;
  bool            FReceiptNumber_Specified;
  WideString      FReceiptSeries;
  bool            FReceiptSeries_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  void __fastcall SetConfirmCode(int Index, WideString _prop_val)
  {  FConfirmCode = _prop_val; FConfirmCode_Specified = true;  }
  bool __fastcall ConfirmCode_Specified(int Index)
  {  return FConfirmCode_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetPaymentDate(int Index, TXSDateTime* _prop_val)
  {  FPaymentDate = _prop_val; FPaymentDate_Specified = true;  }
  bool __fastcall PaymentDate_Specified(int Index)
  {  return FPaymentDate_Specified;  } 
  void __fastcall SetPaymentDocType(int Index, int _prop_val)
  {  FPaymentDocType = _prop_val; FPaymentDocType_Specified = true;  }
  bool __fastcall PaymentDocType_Specified(int Index)
  {  return FPaymentDocType_Specified;  } 
  void __fastcall SetPaymentMethod(int Index, int _prop_val)
  {  FPaymentMethod = _prop_val; FPaymentMethod_Specified = true;  }
  bool __fastcall PaymentMethod_Specified(int Index)
  {  return FPaymentMethod_Specified;  } 
  void __fastcall SetPaymentType(int Index, int _prop_val)
  {  FPaymentType = _prop_val; FPaymentType_Specified = true;  }
  bool __fastcall PaymentType_Specified(int Index)
  {  return FPaymentType_Specified;  } 
  void __fastcall SetReceiptNumber(int Index, WideString _prop_val)
  {  FReceiptNumber = _prop_val; FReceiptNumber_Specified = true;  }
  bool __fastcall ReceiptNumber_Specified(int Index)
  {  return FReceiptNumber_Specified;  } 
  void __fastcall SetReceiptSeries(int Index, WideString _prop_val)
  {  FReceiptSeries = _prop_val; FReceiptSeries_Specified = true;  }
  bool __fastcall ReceiptSeries_Specified(int Index)
  {  return FReceiptSeries_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 

public:
  __fastcall ~Payment();
__published:
  __property WideString ConfirmCode = { index=(IS_OPTN|IS_NLBL), read=FConfirmCode, write=SetConfirmCode, stored = ConfirmCode_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property TXSDateTime* PaymentDate = { index=(IS_OPTN), read=FPaymentDate, write=SetPaymentDate, stored = PaymentDate_Specified };
  __property int        PaymentDocType = { index=(IS_OPTN), read=FPaymentDocType, write=SetPaymentDocType, stored = PaymentDocType_Specified };
  __property int        PaymentMethod = { index=(IS_OPTN), read=FPaymentMethod, write=SetPaymentMethod, stored = PaymentMethod_Specified };
  __property int        PaymentType = { index=(IS_OPTN), read=FPaymentType, write=SetPaymentType, stored = PaymentType_Specified };
  __property WideString ReceiptNumber = { index=(IS_OPTN|IS_NLBL), read=FReceiptNumber, write=SetReceiptNumber, stored = ReceiptNumber_Specified };
  __property WideString ReceiptSeries = { index=(IS_OPTN|IS_NLBL), read=FReceiptSeries, write=SetReceiptSeries, stored = ReceiptSeries_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
};


typedef DynamicArray<AttachmentFile*> ArrayOfAttachmentFile; /* "Rgs.Ufo"[GblCplx] */


// ************************************************************************ //
// XML       : AttachFileRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AttachFileRequest : public TRemotable {
private:
  ArrayOfAttachmentFile FAttachmentFiles;
  bool            FAttachmentFiles_Specified;
  guid            FContractId;
  bool            FContractId_Specified;
  void __fastcall SetAttachmentFiles(int Index, ArrayOfAttachmentFile _prop_val)
  {  FAttachmentFiles = _prop_val; FAttachmentFiles_Specified = true;  }
  bool __fastcall AttachmentFiles_Specified(int Index)
  {  return FAttachmentFiles_Specified;  } 
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 

public:
  __fastcall ~AttachFileRequest();
__published:
  __property ArrayOfAttachmentFile AttachmentFiles = { index=(IS_OPTN|IS_NLBL), read=FAttachmentFiles, write=SetAttachmentFiles, stored = AttachmentFiles_Specified };
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
};




// ************************************************************************ //
// XML       : AttachmentFile, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AttachmentFile : public TRemotable {
private:
  WideString      FData;
  bool            FData_Specified;
  WideString      FName;
  bool            FName_Specified;
  void __fastcall SetData(int Index, WideString _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
__published:
  __property WideString       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
};




// ************************************************************************ //
// XML       : SendVerificationCodeRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class SendVerificationCodeRequest : public TRemotable {
private:
  guid            FContractId;
  bool            FContractId_Specified;
  WideString      FMobile;
  bool            FMobile_Specified;
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
  void __fastcall SetMobile(int Index, WideString _prop_val)
  {  FMobile = _prop_val; FMobile_Specified = true;  }
  bool __fastcall Mobile_Specified(int Index)
  {  return FMobile_Specified;  } 
__published:
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
  __property WideString     Mobile = { index=(IS_OPTN|IS_NLBL), read=FMobile, write=SetMobile, stored = Mobile_Specified };
};




// ************************************************************************ //
// XML       : ConfirmVerificationCodeRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ConfirmVerificationCodeRequest : public TRemotable {
private:
  guid            FContractId;
  bool            FContractId_Specified;
  WideString      FVerificationCode;
  bool            FVerificationCode_Specified;
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
  void __fastcall SetVerificationCode(int Index, WideString _prop_val)
  {  FVerificationCode = _prop_val; FVerificationCode_Specified = true;  }
  bool __fastcall VerificationCode_Specified(int Index)
  {  return FVerificationCode_Specified;  } 
__published:
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
  __property WideString VerificationCode = { index=(IS_OPTN|IS_NLBL), read=FVerificationCode, write=SetVerificationCode, stored = VerificationCode_Specified };
};




// ************************************************************************ //
// XML       : ContractStatusRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractStatusRequest : public TRemotable {
private:
  DateTimeOffset* FCreationDate;
  bool            FCreationDate_Specified;
  WideString      FNumber;
  bool            FNumber_Specified;
  WideString      FSeries;
  bool            FSeries_Specified;
  void __fastcall SetCreationDate(int Index, DateTimeOffset* _prop_val)
  {  FCreationDate = _prop_val; FCreationDate_Specified = true;  }
  bool __fastcall CreationDate_Specified(int Index)
  {  return FCreationDate_Specified;  } 
  void __fastcall SetNumber(int Index, WideString _prop_val)
  {  FNumber = _prop_val; FNumber_Specified = true;  }
  bool __fastcall Number_Specified(int Index)
  {  return FNumber_Specified;  } 
  void __fastcall SetSeries(int Index, WideString _prop_val)
  {  FSeries = _prop_val; FSeries_Specified = true;  }
  bool __fastcall Series_Specified(int Index)
  {  return FSeries_Specified;  } 

public:
  __fastcall ~ContractStatusRequest();
__published:
  __property DateTimeOffset* CreationDate = { index=(IS_OPTN), read=FCreationDate, write=SetCreationDate, stored = CreationDate_Specified };
  __property WideString     Number = { index=(IS_OPTN|IS_NLBL), read=FNumber, write=SetNumber, stored = Number_Specified };
  __property WideString     Series = { index=(IS_OPTN|IS_NLBL), read=FSeries, write=SetSeries, stored = Series_Specified };
};




// ************************************************************************ //
// XML       : ContractStatusResponse, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractStatusResponse : public TRemotable {
private:
  guid            FCalculationId;
  bool            FCalculationId_Specified;
  bool            FResult;
  bool            FResult_Specified;
  void __fastcall SetCalculationId(int Index, guid _prop_val)
  {  FCalculationId = _prop_val; FCalculationId_Specified = true;  }
  bool __fastcall CalculationId_Specified(int Index)
  {  return FCalculationId_Specified;  } 
  void __fastcall SetResult(int Index, bool _prop_val)
  {  FResult = _prop_val; FResult_Specified = true;  }
  bool __fastcall Result_Specified(int Index)
  {  return FResult_Specified;  } 
__published:
  __property guid       CalculationId = { index=(IS_OPTN), read=FCalculationId, write=SetCalculationId, stored = CalculationId_Specified };
  __property bool           Result = { index=(IS_OPTN), read=FResult, write=SetResult, stored = Result_Specified };
};




// ************************************************************************ //
// XML       : CancelContractRequest, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CancelContractRequest : public TRemotable {
private:
  guid            FContractId;
  bool            FContractId_Specified;
  void __fastcall SetContractId(int Index, guid _prop_val)
  {  FContractId = _prop_val; FContractId_Specified = true;  }
  bool __fastcall ContractId_Specified(int Index)
  {  return FContractId_Specified;  } 
__published:
  __property guid       ContractId = { index=(IS_OPTN), read=FContractId, write=SetContractId, stored = ContractId_Specified };
};




// ************************************************************************ //
// XML       : StatusOfCancelContractResult, global, <complexType>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class StatusOfCancelContractResult : public TRemotable {
private:
  int             FStatus;
  bool            FStatus_Specified;
  void __fastcall SetStatus(int Index, int _prop_val)
  {  FStatus = _prop_val; FStatus_Specified = true;  }
  bool __fastcall Status_Specified(int Index)
  {  return FStatus_Specified;  } 
__published:
  __property int            Status = { index=(IS_OPTN), read=FStatus, write=SetStatus, stored = Status_Specified };
};




// ************************************************************************ //
// XML       : User, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class User2 : public User {
private:
__published:
};




// ************************************************************************ //
// XML       : CalcRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalcRequest2 : public CalcRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : Agent, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Agent2 : public Agent {
private:
__published:
};




// ************************************************************************ //
// XML       : Auto, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Auto2 : public Auto {
private:
__published:
};




// ************************************************************************ //
// XML       : Document, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Document2 : public Document {
private:
__published:
};




// ************************************************************************ //
// XML       : Driver, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Driver2 : public Driver {
private:
__published:
};




// ************************************************************************ //
// XML       : PersonName, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PersonName2 : public PersonName {
private:
__published:
};




// ************************************************************************ //
// XML       : Counteragent, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Counteragent2 : public Counteragent {
private:
__published:
};




// ************************************************************************ //
// XML       : AddressEntry, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AddressEntry2 : public AddressEntry {
private:
__published:
};




// ************************************************************************ //
// XML       : Contacts, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Contacts2 : public Contacts {
private:
__published:
};




// ************************************************************************ //
// XML       : Logging, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Logging2 : public Logging {
private:
__published:
};




// ************************************************************************ //
// XML       : PeriodOfUse, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PeriodOfUse2 : public PeriodOfUse {
private:
__published:
};




// ************************************************************************ //
// XML       : ServiceStation, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ServiceStation2 : public ServiceStation {
private:
__published:
};




// ************************************************************************ //
// XML       : UpdateRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class UpdateRequest2 : public UpdateRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : Coefficients, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Coefficients2 : public Coefficients {
private:
__published:
};




// ************************************************************************ //
// XML       : CalcResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CalcResult2 : public CalcResult {
private:
__published:
};




// ************************************************************************ //
// XML       : ClientReason, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ClientReason2 : public ClientReason {
private:
__published:
};




// ************************************************************************ //
// XML       : DriverCalcResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverCalcResult2 : public DriverCalcResult {
private:
__published:
};




// ************************************************************************ //
// XML       : DriverKbmRsaCalcResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class DriverKbmRsaCalcResult2 : public DriverKbmRsaCalcResult {
private:
__published:
};




// ************************************************************************ //
// XML       : ClaimResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ClaimResult2 : public ClaimResult {
private:
__published:
};




// ************************************************************************ //
// XML       : RSACheckResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RSACheckResult2 : public RSACheckResult {
private:
__published:
};




// ************************************************************************ //
// XML       : RSACheck, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class RSACheck2 : public RSACheck {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleKbmRsaCalcResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleKbmRsaCalcResult2 : public VehicleKbmRsaCalcResult {
private:
__published:
};




// ************************************************************************ //
// XML       : VehicleRsaCheckResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class VehicleRsaCheckResult2 : public VehicleRsaCheckResult {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PrintRequest2 : public PrintRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : PreviousPolicy, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class PreviousPolicy2 : public PreviousPolicy {
private:
__published:
};




// ************************************************************************ //
// XML       : FindServiceStationsRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class FindServiceStationsRequest2 : public FindServiceStationsRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : FindResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class FindResult2 : public FindResult {
private:
__published:
};




// ************************************************************************ //
// XML       : CheckPaymentRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CheckPaymentRequest2 : public CheckPaymentRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : Payment, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class Payment2 : public Payment {
private:
__published:
};




// ************************************************************************ //
// XML       : AttachFileRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AttachFileRequest2 : public AttachFileRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : AttachmentFile, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class AttachmentFile2 : public AttachmentFile {
private:
__published:
};




// ************************************************************************ //
// XML       : SendVerificationCodeRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class SendVerificationCodeRequest2 : public SendVerificationCodeRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : ConfirmVerificationCodeRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ConfirmVerificationCodeRequest2 : public ConfirmVerificationCodeRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : ContractStatusRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractStatusRequest2 : public ContractStatusRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : ContractStatusResponse, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class ContractStatusResponse2 : public ContractStatusResponse {
private:
__published:
};




// ************************************************************************ //
// XML       : CancelContractRequest, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class CancelContractRequest2 : public CancelContractRequest {
private:
__published:
};




// ************************************************************************ //
// XML       : StatusOfCancelContractResult, global, <element>
// Namespace : Rgs.Ufo
// ************************************************************************ //
class StatusOfCancelContractResult2 : public StatusOfCancelContractResult {
private:
__published:
};




// ************************************************************************ //
// XML       : DateTimeOffset, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System
// ************************************************************************ //
class DateTimeOffset : public TRemotable {
private:
  TXSDateTime*    FDateTime;
  short           FOffsetMinutes;

public:
  __fastcall ~DateTimeOffset();
__published:
  __property TXSDateTime*   DateTime = { read=FDateTime, write=FDateTime };
  __property short      OffsetMinutes = { read=FOffsetMinutes, write=FOffsetMinutes };
};




// ************************************************************************ //
// XML       : DateTimeOffset, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System
// ************************************************************************ //
class DateTimeOffset2 : public DateTimeOffset {
private:
__published:
};


typedef DynamicArray<KeyValuePairOfstringArrayOfstringty7Ep6D1*> ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */
typedef DynamicArray<KeyValuePairOfstringstring*> ArrayOfKeyValuePairOfstringstring; /* "http://schemas.datacontract.org/2004/07/System.Collections.Generic"[GblCplx] */


// ************************************************************************ //
// XML       : OperationResultOfStatusOfCancelContractResultoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfStatusOfCancelContractResultoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  StatusOfCancelContractResult* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, StatusOfCancelContractResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfStatusOfCancelContractResultoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property StatusOfCancelContractResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfguid, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfguid : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  guid            FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, guid _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfguid();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property guid             Data = { index=(IS_OPTN), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfContractStatusResponseoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfContractStatusResponseoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  ContractStatusResponse* FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, ContractStatusResponse* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfContractStatusResponseoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property ContractStatusResponse*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  ArrayOfKeyValuePairOfstringstring FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property ArrayOfKeyValuePairOfstringstring       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfboolean, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfboolean : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  bool            FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, bool _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfboolean();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property bool             Data = { index=(IS_OPTN), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfFindResultoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfFindResultoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  FindResult*     FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, FindResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfFindResultoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property FindResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfstring, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfstring : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  WideString      FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, WideString _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfstring();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property WideString       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfCalcResultoTurZuT3, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfCalcResultoTurZuT3 : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  CalcResult*     FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, CalcResult* _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfCalcResultoTurZuT3();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property CalcResult*       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};


typedef DynamicArray<PrintResult*> ArrayOfPrintResult; /* "http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models"[GblCplx] */


// ************************************************************************ //
// XML       : OperationResultOfArrayOfPrintResultgx6iBzRq, global, <complexType>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfPrintResultgx6iBzRq : public TRemotable {
private:
  guid            FCorrelationId;
  bool            FCorrelationId_Specified;
  ArrayOfPrintResult FData;
  bool            FData_Specified;
  WideString      FErrorMessage;
  bool            FErrorMessage_Specified;
  ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 FGrouppedErrorMessage;
  bool            FGrouppedErrorMessage_Specified;
  bool            FIsSuccess;
  bool            FIsSuccess_Specified;
  WideString      FServiceVersion;
  bool            FServiceVersion_Specified;
  ArrayOfKeyValuePairOfstringstring FValidationCodeErrors;
  bool            FValidationCodeErrors_Specified;
  ArrayOfstring   FValidationErrors;
  bool            FValidationErrors_Specified;
  ArrayOfstring   FWarningMessages;
  bool            FWarningMessages_Specified;
  void __fastcall SetCorrelationId(int Index, guid _prop_val)
  {  FCorrelationId = _prop_val; FCorrelationId_Specified = true;  }
  bool __fastcall CorrelationId_Specified(int Index)
  {  return FCorrelationId_Specified;  } 
  void __fastcall SetData(int Index, ArrayOfPrintResult _prop_val)
  {  FData = _prop_val; FData_Specified = true;  }
  bool __fastcall Data_Specified(int Index)
  {  return FData_Specified;  } 
  void __fastcall SetErrorMessage(int Index, WideString _prop_val)
  {  FErrorMessage = _prop_val; FErrorMessage_Specified = true;  }
  bool __fastcall ErrorMessage_Specified(int Index)
  {  return FErrorMessage_Specified;  } 
  void __fastcall SetGrouppedErrorMessage(int Index, ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 _prop_val)
  {  FGrouppedErrorMessage = _prop_val; FGrouppedErrorMessage_Specified = true;  }
  bool __fastcall GrouppedErrorMessage_Specified(int Index)
  {  return FGrouppedErrorMessage_Specified;  } 
  void __fastcall SetIsSuccess(int Index, bool _prop_val)
  {  FIsSuccess = _prop_val; FIsSuccess_Specified = true;  }
  bool __fastcall IsSuccess_Specified(int Index)
  {  return FIsSuccess_Specified;  } 
  void __fastcall SetServiceVersion(int Index, WideString _prop_val)
  {  FServiceVersion = _prop_val; FServiceVersion_Specified = true;  }
  bool __fastcall ServiceVersion_Specified(int Index)
  {  return FServiceVersion_Specified;  } 
  void __fastcall SetValidationCodeErrors(int Index, ArrayOfKeyValuePairOfstringstring _prop_val)
  {  FValidationCodeErrors = _prop_val; FValidationCodeErrors_Specified = true;  }
  bool __fastcall ValidationCodeErrors_Specified(int Index)
  {  return FValidationCodeErrors_Specified;  } 
  void __fastcall SetValidationErrors(int Index, ArrayOfstring _prop_val)
  {  FValidationErrors = _prop_val; FValidationErrors_Specified = true;  }
  bool __fastcall ValidationErrors_Specified(int Index)
  {  return FValidationErrors_Specified;  } 
  void __fastcall SetWarningMessages(int Index, ArrayOfstring _prop_val)
  {  FWarningMessages = _prop_val; FWarningMessages_Specified = true;  }
  bool __fastcall WarningMessages_Specified(int Index)
  {  return FWarningMessages_Specified;  } 

public:
  __fastcall ~OperationResultOfArrayOfPrintResultgx6iBzRq();
__published:
  __property guid       CorrelationId = { index=(IS_OPTN), read=FCorrelationId, write=SetCorrelationId, stored = CorrelationId_Specified };
  __property ArrayOfPrintResult       Data = { index=(IS_OPTN|IS_NLBL), read=FData, write=SetData, stored = Data_Specified };
  __property WideString ErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FErrorMessage, write=SetErrorMessage, stored = ErrorMessage_Specified };
  __property ArrayOfKeyValuePairOfstringArrayOfstringty7Ep6D1 GrouppedErrorMessage = { index=(IS_OPTN|IS_NLBL), read=FGrouppedErrorMessage, write=SetGrouppedErrorMessage, stored = GrouppedErrorMessage_Specified };
  __property bool        IsSuccess = { index=(IS_OPTN), read=FIsSuccess, write=SetIsSuccess, stored = IsSuccess_Specified };
  __property WideString ServiceVersion = { index=(IS_OPTN|IS_NLBL), read=FServiceVersion, write=SetServiceVersion, stored = ServiceVersion_Specified };
  __property ArrayOfKeyValuePairOfstringstring ValidationCodeErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationCodeErrors, write=SetValidationCodeErrors, stored = ValidationCodeErrors_Specified };
  __property ArrayOfstring ValidationErrors = { index=(IS_OPTN|IS_NLBL), read=FValidationErrors, write=SetValidationErrors, stored = ValidationErrors_Specified };
  __property ArrayOfstring WarningMessages = { index=(IS_OPTN|IS_NLBL), read=FWarningMessages, write=SetWarningMessages, stored = WarningMessages_Specified };
};




// ************************************************************************ //
// XML       : OperationResultOfCalcResultoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfCalcResultoTurZuT32 : public OperationResultOfCalcResultoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfArrayOfPrintResultgx6iBzRq, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfPrintResultgx6iBzRq2 : public OperationResultOfArrayOfPrintResultgx6iBzRq {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfstring, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfstring2 : public OperationResultOfstring {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfFindResultoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfFindResultoTurZuT32 : public OperationResultOfFindResultoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfboolean, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfboolean2 : public OperationResultOfboolean {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp72 : public OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfContractStatusResponseoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfContractStatusResponseoTurZuT32 : public OperationResultOfContractStatusResponseoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfguid, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfguid2 : public OperationResultOfguid {
private:
__published:
};




// ************************************************************************ //
// XML       : OperationResultOfStatusOfCancelContractResultoTurZuT3, global, <element>
// Namespace : RGS.UFO
// ************************************************************************ //
class OperationResultOfStatusOfCancelContractResultoTurZuT32 : public OperationResultOfStatusOfCancelContractResultoTurZuT3 {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringArrayOfstringty7Ep6D1, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringArrayOfstringty7Ep6D1 : public TRemotable {
private:
  WideString      Fkey;
  ArrayOfstring   Fvalue;
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property ArrayOfstring      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringstring, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringstring : public TRemotable {
private:
  WideString      Fkey;
  WideString      Fvalue;
__published:
  __property WideString        key = { index=(IS_NLBL), read=Fkey, write=Fkey };
  __property WideString      value = { index=(IS_NLBL), read=Fvalue, write=Fvalue };
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringArrayOfstringty7Ep6D1, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringArrayOfstringty7Ep6D12 : public KeyValuePairOfstringArrayOfstringty7Ep6D1 {
private:
__published:
};




// ************************************************************************ //
// XML       : KeyValuePairOfstringstring, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/System.Collections.Generic
// ************************************************************************ //
class KeyValuePairOfstringstring2 : public KeyValuePairOfstringstring {
private:
__published:
};




// ************************************************************************ //
// XML       : PrintResult, global, <complexType>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models
// ************************************************************************ //
class PrintResult : public TRemotable {
private:
  WideString      FCassandraId;
  bool            FCassandraId_Specified;
  WideString      FCheckSum;
  bool            FCheckSum_Specified;
  WideString      FComment;
  bool            FComment_Specified;
  WideString   FDocument;
  bool            FDocument_Specified;
  WideString   FESign;
  bool            FESign_Specified;
  WideString      FName;
  bool            FName_Specified;
  DateTimeOffset* FPrintDate;
  bool            FPrintDate_Specified;
  void __fastcall SetCassandraId(int Index, WideString _prop_val)
  {  FCassandraId = _prop_val; FCassandraId_Specified = true;  }
  bool __fastcall CassandraId_Specified(int Index)
  {  return FCassandraId_Specified;  } 
  void __fastcall SetCheckSum(int Index, WideString _prop_val)
  {  FCheckSum = _prop_val; FCheckSum_Specified = true;  }
  bool __fastcall CheckSum_Specified(int Index)
  {  return FCheckSum_Specified;  } 
  void __fastcall SetComment(int Index, WideString _prop_val)
  {  FComment = _prop_val; FComment_Specified = true;  }
  bool __fastcall Comment_Specified(int Index)
  {  return FComment_Specified;  } 
  void __fastcall SetDocument(int Index, WideString _prop_val)
  {  FDocument = _prop_val; FDocument_Specified = true;  }
  bool __fastcall Document_Specified(int Index)
  {  return FDocument_Specified;  } 
  void __fastcall SetESign(int Index, WideString _prop_val)
  {  FESign = _prop_val; FESign_Specified = true;  }
  bool __fastcall ESign_Specified(int Index)
  {  return FESign_Specified;  } 
  void __fastcall SetName(int Index, WideString _prop_val)
  {  FName = _prop_val; FName_Specified = true;  }
  bool __fastcall Name_Specified(int Index)
  {  return FName_Specified;  } 
  void __fastcall SetPrintDate(int Index, DateTimeOffset* _prop_val)
  {  FPrintDate = _prop_val; FPrintDate_Specified = true;  }
  bool __fastcall PrintDate_Specified(int Index)
  {  return FPrintDate_Specified;  } 

public:
  __fastcall ~PrintResult();
__published:
  __property WideString CassandraId = { index=(IS_OPTN|IS_NLBL), read=FCassandraId, write=SetCassandraId, stored = CassandraId_Specified };
  __property WideString   CheckSum = { index=(IS_OPTN|IS_NLBL), read=FCheckSum, write=SetCheckSum, stored = CheckSum_Specified };
  __property WideString    Comment = { index=(IS_OPTN|IS_NLBL), read=FComment, write=SetComment, stored = Comment_Specified };
  __property WideString   Document = { index=(IS_OPTN|IS_NLBL), read=FDocument, write=SetDocument, stored = Document_Specified };
  __property WideString      ESign = { index=(IS_OPTN|IS_NLBL), read=FESign, write=SetESign, stored = ESign_Specified };
  __property WideString       Name = { index=(IS_OPTN|IS_NLBL), read=FName, write=SetName, stored = Name_Specified };
  __property DateTimeOffset*  PrintDate = { index=(IS_OPTN), read=FPrintDate, write=SetPrintDate, stored = PrintDate_Specified };
};




// ************************************************************************ //
// XML       : PrintResult, global, <element>
// Namespace : http://schemas.datacontract.org/2004/07/RGS.UFO.CommonInterfaces.Models
// ************************************************************************ //
class PrintResult2 : public PrintResult {
private:
__published:
};



// ************************************************************************ //
// Namespace : Rgs.Ufo
// soapAction: Rgs.Ufo/IOsago2ProxyService/%operationName%
// transport : http://schemas.xmlsoap.org/soap/http
// style     : document
// binding   : BasicHttpsBinding_IOsago2ProxyService
// service   : Osago2ProxyService
// port      : BasicHttpsBinding_IOsago2ProxyService
// URL       : https://ufo-fe-test-01.rgs.ru/Osago2ProxyService.svc
// ************************************************************************ //
__interface INTERFACE_UUID("{D94E6314-C875-D5AC-F7F9-798393C6B32D}") IOsago2ProxyService : public IInvokable
{
public:
  virtual OperationResultOfCalcResultoTurZuT3* Calculate(const User* user, const CalcRequest* calcRequest) = 0;
  virtual OperationResultOfArrayOfPrintResultgx6iBzRq* Print(const User* user, const PrintRequest* printRequest) = 0;
  virtual DateTimeOffset* Ping() = 0;
  virtual OperationResultOfstring* FindServiceStations(const User* user, const FindServiceStationsRequest* findServiceStationsRequest) = 0;
  virtual OperationResultOfFindResultoTurZuT3* FindServiceStationsResult(const User* user, const WideString requestId, const bool print) = 0;
  virtual OperationResultOfboolean* CheckPayment(const User* user, const CheckPaymentRequest* checkPaymentRequest) = 0;
  virtual OperationResultOfArrayOfKeyValuePairOfstringstringR8RmUPp7* AttachFile(const User* user, const AttachFileRequest* attachFile) = 0;
  virtual OperationResultOfboolean* SendVerificationCode(const User* user, const SendVerificationCodeRequest* sendVerificationCodeRequest) = 0;
  virtual OperationResultOfboolean* ConfirmVerificationCode(const User* user, const ConfirmVerificationCodeRequest* confirmVerificationCodeRequest) = 0;
  virtual OperationResultOfContractStatusResponseoTurZuT3* CheckContractStatus(const User* user, const ContractStatusRequest* contractStatusRequest) = 0;
  virtual OperationResultOfguid* CancelContract(const User* user, const CancelContractRequest* cancelContractRequest) = 0;
  virtual OperationResultOfStatusOfCancelContractResultoTurZuT3* StatusOfCancelContract(const User* user, const guid requestId) = 0;
};
typedef DelphiInterface<IOsago2ProxyService> _di_IOsago2ProxyService;

_di_IOsago2ProxyService GetIOsago2ProxyService(bool useWSDL=false, AnsiString addr="", THTTPRIO* HTTPRIO=0);


};     // NS_Osago2ProxyService

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace NS_Osago2ProxyService;
#endif



#endif // Osago2ProxyServiceH
