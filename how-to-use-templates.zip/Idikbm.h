// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://dikbm.rgs.ru:8080/KBM_Prod/SePeZ_RSA_KBM.dll/wsdl/Idikbm
// Version  : 1.0
// (04.06.2014 12:17:50 - $Revision:   1.0.1.0.1.82  $)
// ************************************************************************ //

#ifndef   IdikbmH
#define   IdikbmH

#include <System.hpp>
#include <InvokeRegistry.hpp>
#include <XSBuiltIns.hpp>
#include <SoapHTTPClient.hpp>


namespace NS_Idikbm {

// ************************************************************************ //
// The following types, referred to in the WSDL document are not being represented
// in this file. They are either aliases[@] of other types represented or were referred
// to but never[!] declared in the document. The types from the latter category
// typically map to predefined/known XML or Borland types; however, they could also 
// indicate incorrect WSDL documents that failed to declare or import a schema type.
// ************************************************************************ //
// !:string          - "http://www.w3.org/2001/XMLSchema"


// ************************************************************************ //
// Namespace : urn:dikbm-Idikbm
// soapAction: urn:dikbm-Idikbm#%operationName%
// transport : http://schemas.xmlsoap.org/soap/http
// style     : rpc
// binding   : Idikbmbinding
// service   : Idikbmservice
// port      : IdikbmPort
// URL       : http://dikbm.rgs.ru:8080/KBM_Prod/SePeZ_RSA_KBM.dll/soap/Idikbm
// ************************************************************************ //
__interface INTERFACE_UUID("{075D1B34-421A-46B7-A0F7-CA45CF1CBCB7}") Idikbm : public IInvokable
{
public:
  virtual AnsiString      GetKbmTo(const AnsiString data) = 0; 
  virtual AnsiString      GetKbmToRequest(const AnsiString data) = 0; 
  virtual AnsiString      GetGostRSANormHash(const AnsiString data) = 0; 
  virtual AnsiString      GetFunction(const AnsiString function_name, const AnsiString data) = 0; 
};
typedef DelphiInterface<Idikbm> _di_Idikbm;

_di_Idikbm GetIdikbm(bool useWSDL=false, AnsiString addr="");



#endif // __Idikbm_h__

};     // NS_Idikbm

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace NS_Idikbm;
#endif

 