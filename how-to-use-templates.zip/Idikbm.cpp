// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://dikbm.rgs.ru:8080/KBM_Prod/SePeZ_RSA_KBM.dll/wsdl/Idikbm
// Version  : 1.0
// (04.06.2014 12:17:50 - $Revision:   1.0.1.0.1.82  $)
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#if !defined(IdikbmH)
#include "Idikbm.h"
#endif



namespace NS_Idikbm {

_di_Idikbm GetIdikbm(bool useWSDL, AnsiString addr)
{
  // http://dikbm_test.rgs.ru:8080/dikbm_test/
  static const char* defWSDL= "http://apo.rgs.ru/SePeZ_RSA_KBM_Prod/SePeZ_RSA_KBM.dll/wsdl/Idikbm";
  static const char* defURL = "http://apo.rgs.ru/SePeZ_RSA_KBM_Prod/SePeZ_RSA_KBM.dll/soap/Idikbm";
  static const char* defSvc = "Idikbmservice";
  static const char* defPrt = "IdikbmPort";
  if (addr=="")
    addr = useWSDL ? defWSDL : defURL;

  //rio_be rbe;
  THTTPRIO *rio = new THTTPRIO(0);
  //rio->OnBeforeExecute = rbe.HTTPRIOBeforeExecute;
  //rio->OnAfterExecute = rbe.HTTPRIOAfterExecute;

  if (useWSDL) {
    rio->WSDLLocation = addr;
    rio->Service = defSvc;
    rio->Port = defPrt;
  } else {
    rio->URL = addr;
  }
  _di_Idikbm service;
  rio->QueryInterface(service);
  if (!service)
    delete rio;
  return service;
}


// ************************************************************************ //
// This routine registers the interfaces and types used by invoke the SOAP
// Service.
// ************************************************************************ //
static void RegTypes()
{
  /* Idikbm */
  InvRegistry()->RegisterInterface(__interfaceTypeinfo(Idikbm), L"urn:dikbm-Idikbm", L"");
  InvRegistry()->RegisterDefaultSOAPAction(__interfaceTypeinfo(Idikbm), L"urn:dikbm-Idikbm#%operationName%");
}
#pragma startup RegTypes 32

};     // NS_Idikbm

 