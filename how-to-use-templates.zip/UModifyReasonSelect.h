//---------------------------------------------------------------------------

#ifndef UModifyReasonSelectH
#define UModifyReasonSelectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "TMops_api.h"
#include <Buttons.hpp>
#include <CheckLst.hpp>
//---------------------------------------------------------------------------
class TFModifyReasonSelect : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TBitBtn *BitBtnOk;
        TBitBtn *BitBtnCancel;
        TLabel *Label1;
        TCheckListBox *clbReasons;
        void __fastcall BitBtnOkClick(TObject *Sender);
        void __fastcall BitBtnCancelClick(TObject *Sender);
        void __fastcall clbReasonsClickCheck(TObject *Sender);
private:	// User declarations
   mops_api_028 *m_api;
   int ProductId;
   int IsForeignRegistration;
   int MultiDrive;
   TList* SelectedReasonsId;
   bool  OnlySelectedReasons; 
   int res;
   void SelectDuplicate(int index);
   void SelectMultiDrive(int index);
public:		// User declarations
        __fastcall TFModifyReasonSelect(TComponent* Owner,mops_api_028 *mapi, int productId,int isForeignRegistration,  int multiDrive,  TList* selectedReasonsId);
};
//---------------------------------------------------------------------------
extern PACKAGE TFModifyReasonSelect *FModifyReasonSelect;
//---------------------------------------------------------------------------
#endif
