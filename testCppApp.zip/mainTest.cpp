	#include <iostream>

	class A
	{
	public:
		virtual void Printer()
		{
			std::cout << "A print" << std::endl;
		}
		virtual ~A()
		{
			std::cout << "~A" << std::endl;
		}
	};
	
	class B : public A
	{
	public:
		void Printer()
		{
			std::cout << "B" << std::endl;;
		}
		~B()
		{
			std::cout << "~B" << std::endl;
		}
	};
	
	template <typename T>
	class Temp
	{
	public:
		void print(T* t)
		{
			t->Printer();
		};
	};
	
	int main()
	{
		B b;
		b.Printer();
	
		A* a = &b;
		a->Printer();
	
		Temp<A> printer;
		printer.print(a);
		
		return 0;
	}
