
#include <iostream>
struct A {
	A(int val) : m_val(val) {}
	int m_val;
};

struct B : A
{
	B(int val) : A(val) {}
};


int main()
{
	try
	{
		try
		{
			throw B(5);
		}
		catch (A a)
		{
			a.m_val *= 2;
			throw;
		}
		catch (B b)
		{
			b.m_val -= 2;
			throw b;
		}
	}
	catch (A a)
	{
		std::cout << a.m_val; // 5
	}

	return 0;
}

