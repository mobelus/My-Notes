#include <string>
#include <fstream>
#include <iostream>
#include <vector>

class FFiles
{
public:
	void remove_comments(std::ifstream&, std::ofstream&);
	void checkCommentsSlashSlash(std::string&, bool&, std::ofstream&);
	void checkComments(std::string&, bool&, std::ofstream&);
};
