#include "FFiles.h"

void FFiles::checkCommentsSlashSlash(std::string& line, bool& flag, std::ofstream& Target)
{
	if (!flag)
	{
		for (int i = 0; i < line.length(); ++i)
		{
			// searching for " // " to eliminate all its content.
			if ( (line.at(i) == '/') && (line.at(i + 1) == '/') )
			{
				break;
			}
			else
			{
				// copy the character of the position i to the Target
				Target << line[i];
			}
		}
		Target << std::endl;
	}
}

void FFiles::checkComments(std::string& line, bool& flag, std::ofstream& Target)
{
	// initialized as 1, because if don't find "/*" will not set flag true
	int contaAspas = 1;
	
	// searching for " /* " to eliminate it and all its content.
	// the .find searchs in the forward direction for the first occurrence of a substring that matches
	// the specified sequence of characters and returns its position
	if (line.find("/*") < line.length()) 
	{
		contaAspas = 0;
		//check if "/*" is or isn't a commentary
		for (int i = 0; i < line.find("/*"); ++i)
		{
			if ((line.at(i) == '"'))
			{
				contaAspas++;
			}
		}
	}
	//in case of even quotation marks it's a commentary
	if ((contaAspas % 2) == 0) 
	{
		flag = true;
	}

	//check the "//" comments
	checkCommentsSlashSlash(line, flag, Target); 

	if (flag)
	{
		//when it finds the end of commentary, it restarts to copy
		if (line.find("*/") < line.length()) 
		{
			flag = false;
		}
	}
}


void FFiles::remove_comments(std::ifstream& Source, std::ofstream& Target)
{
	//auxiliar string to store the read line
	std::string line;
	bool flag = false;

	// This loop is to get assure that the whole input file is read.
	while (!Source.eof())
	{
		// To read line by line checks comments for the read line
		getline(Source, line);
		checkComments(line, flag, Target);
	} // WILE 
}

