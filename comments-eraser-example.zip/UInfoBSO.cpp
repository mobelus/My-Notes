//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UInfoBSO.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmInfoCheck *frmInfoCheck;
//---------------------------------------------------------------------------
__fastcall TfrmInfoCheck::TfrmInfoCheck(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
