﻿ОТЧЁТ ДЛЯ РУКОВОДИТЕЛЕЙ:
- каждый вторник и четверг.

Добрый всем день,
Сегодня мой последний день в компании, большое спасибо всем. Приглашаю угоститься пиццей около кухни 4 этажа.
Получил много нового опыта, но пора двигаться дальше…
По всем рабочим вопросам можно обращаться к Сокольскому В.Б. и Городенцеву Е.Ю.




C:\Users\PAObrosov\Desktop\Screens\KASKO\3-7200-0665104-10032017-цыкунов

Павел, привет.
Я таки установил себе телеграм, вот номер +7968 459 57 12, добавляй, а то бывают вопросы и спросить было-бы неплохо)
Спасибо.

КАК СДЕЛАТЬ ЗАПИСЬ В БД КОРРЕКТНОЙ:
1) _mops_calcs_
Найти запись и выставить в NoErrors = -1
2) _mops_Err_Warn_Calcs_Count_
Найти запись 	с указанным id = calc_id и уждалить две соответвующие записи из БД 


ПОДДЕРЖКА
http://jira-rgs.rgs.ru:8080/browse/APOII-1450

http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=1116
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0217
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0317
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0417
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0517
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0617
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0817

http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=0917
http://jira-rgs.rgs.ru:8080/secure/TempoUserBoard!timesheet.jspa?v=1&filterIds=-1001&periodType=BILLING&periodView=PERIOD&period=1217
	
МОИ СКК:
http://jira-rgs.rgs.ru:8080/issues/?filter=16638




new_premiya_osn_risk = m_api->Round(di->calc_info.osn_risk_itog_tarif * (di->calc_info.str_summa + (reasons_surcharge[17].select ? SumAD() : 0.0)) / 100);


surcharge_value = m_api->Round( (new_premiya_osn_risk - premiya_osn_risk_orig) * days_coeff );
	  



7200
0136436
13.10.2017

	  
	  
	  
vgDrawRowHeader

btnRequest
  void TFReissCalc::ChangeMultiDrive()
  void TFReissCalc::LoadPerson
  LoadPerson
  LoadPerson
  LoadKssData
  LoadVozmType
  LoadData
  Reason_CheckComboBoxPropertiesCloseUp
  SetVisible_VG_Items
  Recalc
  Recalc
  gridDopushCustomDrawItem
  
btnRequestUFO

  
7100
1037109
28.12.2017


ЖУЧКИН
АЛЕКСАНДР
МИХАЙЛОВИЧ

23.08.1977
23.08.1995

0817
485067






!!! GroupBox4

void TFCalc::LoadFrame(long id_calc)
...
   if (MYGLOBAL::is_general)
   {
        TSPurpose->ItemIndex = TSPurpose->IndexOf("Ïðî÷èå");

        GroupBox4->Visible=true;
        TADOQuery *qg = m_api->dbGetCursor(res,"SELECT dognum,calc_date FROM OSAGO_R_general WHERE id="+q->FieldByName("general_id")->AsString);
        GDogNum->Caption = qg->FieldByName("dognum")->AsString;
        LNR->Caption =  m_api->dbGetStringFromQuery(res,"select LNR from _mops_polzovateli_ where id=" + m_api->vrGetVariable(res, "_mops_global_tekushi_polzovatel_id_"));
        INN->Caption = q->FieldByName("pol_zayav_strah_inn")->AsString;
        calcDate->Date = qg->FieldByName("calc_date")->AsDateTime;
        m_api->dbCloseCursor(res,qg);

        CheckSpecialConditions();
   }
   

!!! CheckSpecialConditions();
   
//---------------------------------------------------------------------------
void TFCalc::CheckSpecialConditions()
{
        AnsiString QClientID;
        AnsiString sql = "select CLIENT_BA_ID from OSAGO_R_7_9_25 where CLIENT_INN = '"+INN->Caption+"'";
/*
с) условия предоставления прав пользователю использования спец. условий для всех клиентов.
если в СКК 7.9.26 поле CLIENT_BO_ID для выбранного пользователя не заполнено, то ему должны предоставляться спец. условия для всех договоров всех клиентов, указанных в СКК 7.9.25.
*/

      int cnt = m_api->dbGetIntFromQuery(res, "select count(*) from OSAGO_R_7_9_24 where LNR='"+LNR->Caption+"'");
        bool ba_id_isempty=false;
        if(cnt>0) //если вообще есть в бд такой
        {
            ba_id_isempty = m_api->dbGetStringFromQuery(res, "select CLIENT_BA_ID from OSAGO_R_7_9_26 where LNR='"+LNR->Caption+"'").Trim().IsEmpty();
            if(ba_id_isempty)
            {
                AnsiString pol_zayav_strah_inn = m_api->dbGetStringFromQuery(res, "select pol_zayav_strah_inn from OSAGO_R_main where calc_id="+IntToStr(calc_id));
                if(!pol_zayav_strah_inn.IsEmpty())
                   MYGLOBAL::SpecialConditions = m_api->dbGetIntFromQuery(res, "select count(*) from OSAGO_R_7_9_25 where CLIENT_INN='"+pol_zayav_strah_inn+"'") > 0;
            }
        }

        if(!MYGLOBAL::SpecialConditions)
        {
//            QClientID = m_api->dbGetStringFromQuery(res,"select CLIENT_BA_ID from OSAGO_R_7_9_25 where CLIENT_INN='"+INN->Caption+"'");
//            MYGLOBAL::SpecialConditions = m_api->dbGetIntFromQuery(res, "select COUNT(*) from OSAGO_R_7_9_26 where LNR='"+LNR->Caption+"' AND CLIENT_BA_ID='"+QClientID+"' AND (CONTRACT_NUMBER='"+GDogNum->Caption+"' OR CONTRACT_NUMBER='')");
// Костыль для случая нескольких записей в OSAGO_R_7_9_26 для одного и того же ИНН
            AnsiString sqlOASOR_7926 =  "SELECT COUNT(*)"
                                        " FROM OSAGO_R_7_9_26 A INNER JOIN OSAGO_R_7_9_25 B ON A.CLIENT_BA_ID= B.CLIENT_BA_ID"
                                        " WHERE A.LNR = '"+LNR->Caption+"'"
                                        "   AND (A.CONTRACT_NUMBER = '"+GDogNum->Caption+"'"
                                        "       OR CONTRACT_NUMBER='')"
                                        "   AND B.CLIENT_INN = '"+INN->Caption+"'";

            MYGLOBAL::SpecialConditions = m_api->dbGetIntFromQuery(res, sqlOASOR_7926);

        }
        if (MYGLOBAL::SpecialConditions)
        {
                SpecStatus->Caption = "Ok";
                ShowMessage("Для Вас разблокированы спец. условия");
        }
        else
        {
          SpecStatus->Caption = "None";
        }
}


Коммнентарий присутствоваший в коде, внутри функции, определяющей договор по спец условиям или нет:

с) условия предоставления прав пользователю использования спец. условий для всех клиентов.
если в СКК 7.9.26 поле CLIENT_BO_ID для выбранного пользователя не заполнено,
то ему должны предоставляться спец. условия для всех договоров всех клиентов, указанных в СКК 7.9.25.


Примерное описание того, что происходит исходя из кода:

(0) Таблица OSAGO_R_7_9_24, смотрим есть ли человек по его ЛНРу, и проверяем Далее ...
(1) ... Если успешно отработали по запросу (0), Тогда: в таблицах OSAGO_R_7_9_26, OSAGO_R_7_9_25 по ЛНР, ИНН и Номеру Договора и смотрится имеет данный пользователь Спец.Условия / Договор со Спец. Условиями или нет.

  "select CLIENT_BA_ID from OSAGO_R_7_9_26 where LNR='"+LNR->Caption+"'").Trim().IsEmpty();
  "select pol_zayav_strah_inn from OSAGO_R_main where calc_id="+IntToStr(calc_id));
  "select count(*) from OSAGO_R_7_9_25 where CLIENT_INN='"+pol_zayav_strah_inn+"'") > 0;
 
(2) ... Если успешно отработали по запросам (0) + (1), Тогда: в таблицах OSAGO_R_7_9_26, OSAGO_R_7_9_25 по ЛНР, ИНН и Номеру Договора и смотрится имеет данный пользователь Спец.Условия / Договор со Спец. Условиями или нет.
 "SELECT COUNT(*)"
  " FROM OSAGO_R_7_9_26 A INNER JOIN OSAGO_R_7_9_25 B ON A.CLIENT_BA_ID= B.CLIENT_BA_ID"
  " WHERE A.LNR = '"+LNR->Caption+"'"
  "   AND (A.CONTRACT_NUMBER = '"+GDogNum->Caption+"'"
  "       OR CONTRACT_NUMBER='')"
  "   AND B.CLIENT_INN = '"+INN->Caption+"'";

  
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

Юрики - со Спец проектами - им оставить переоформление



82 - 76 _ID
gl_dict_vzr_allowed_branches
83 - 77 _ID
gl_dict_vzr_allowed_users




Были введены 2 глобальных справоника, связанные с модулем ВЗР

1) Справочник для подразделений которым доступен вход в модуль ВЗР
gl_dict_vzr_allowed_branches [столбец BRANCHE_CODE] ( Путь: system/apo_db )

2) Справочник с ЛНР пользователей, которым доступен вход в модуль ВЗР
gl_dict_vzr_allowed_users [столбец LNR] ( Путь: system/apo_db )


Так же имеем отдельно таблицу с подразделениями
3) BRANCHES [столбец BRANCH_CODE Код текущего подразделения, столбец BRANCHES_FK Код родителя ] ( Путь: system/BRANCHES_OFFICES )

Текущий пользователь и информация о нём
4) _mops_polzovateli_ [столбец SKK, столбец LNR] ( Путь: system/apo_db )


Как мы проверяем факт того открывать модуль ВЗР пользователю или нет:
1) Если текущий пользователь с его ЛНР найден по ЛНРу в справочнике gl_dict_vzr_allowed_users, то открываем
, т.е. если _mops_polzovateli_:LNR содержится в gl_dict_vzr_allowed_users:LNR 
2) А так же в случае если, столбец SKK, который по факту является Кодом подразделения в таблице BRANCHES:BRANCH_CODE, и так же gl_dict_vzr_allowed_branches:BRANCHE_CODE 


Соответсвие устанавливается Так:
Относительно текущего Подрахделения, которое равно значению СКК текущего пользователя мы двигаемся по подразделениям ВВЕРХ, до Главного офиса, по таблице BRANCHES (( Путь: system/BRANCHES_OFFICES ))
Мы получаем Коды всех вышестоящих подразделений, где находится сотрудник и проверяем не содержится ли хотя бы одно из них среди gl_dict_vzr_allowed_branches [столбец BRANCHE_CODE]
Если совпадение найдено, значит Пользователю доступен модуль ВЗР и мы его ему открываем, если нет, значит не открываем модуль и выводим сообщение "Модуль АПО - ВЗР закрыт на доработку. Оформление полисов необходимо осуществлять в ПО ВИРТУ. По возникшим вопросам обращаться в ДВЗР ЦО к Горощук Елене elena_goroshchuk@rgs.ru"

Исправление обработки тега Разрешённой массы автомобиля


- C:\CBuilder6\Source\Developer Express Inc\Library\CBuilder6
- C:\Program Files (x86)\Developer Express Inc\Library\CBuilder6
- C:\CBuilder6\Source\6.acnt_regcb6\acnt_regcb6 v6.30\CB6
C:\Projects\APO2\Project\Mops\Modules\external libraries\curl\include\curl
C:\Projects\APO2\Project\Mops\Modules\external libraries\curl



C:\Projects\APO2\Project\Mops\Modules\external libraries\curl


$(AlphaControls)
C:\CBuilder6\Source\6.acnt_regcb6\acnt_regcb6 v6.30\CB6
AlphaControls = C:\Program Files (x86)\Borland\CBuilder6\comp\acnt_regcb6


FastReport4 = C:\CBuilder6\Source\FastReports\FastReport4
RXLib = C:\CBuilder6\Source\4.RXLib
AlphaControls = C:\Program Files (x86)\Borland\CBuilder6\comp\acnt_regcb6
DevExpress = C:\CBuilder6\Source\Developer Express Inc
EhLib = C:\CBuilder6\Source\EhLib
ToDeveloper = C:\Projects\APO2\Project\Mops\to_developer

GlobusLib = C:\Program Files(x86)\Globus.lib

-----------
Includes:

C:\Program Files (x86)\Borland\CBuilder6\Projects
C:\CBuilder6\Source\Developer Express Inc\Library\CBuilder6
C:\CBuilder6\Source\6.acnt_regcb6\acnt_regcb6 v6.30\CB6
C:\CBuilder6\Source\4.RXLib\Units
C:\CBuilder6\Source\EhLib\BCB6
C:\CBuilder6\Source\Developer Express Inc\Library
C:\CBuilder6\Source\EhLib\Common
C:\CBuilder6\Source\FastReports\FastReport4
C:\CBuilder6\Source\FastReports\FastReport4\ADO
C:\CBuilder6\Source\FastReports\FastReport4\BDE
C:\CBuilder6\Source\FastReports\FastReport4\Bpl
C:\CBuilder6\Source\FastReports\FastReport4\DBX
C:\CBuilder6\Source\FastReports\FastReport4\ExportPack
C:\CBuilder6\Source\FastReports\FastReport4\IBX
C:\CBuilder6\Source\FastReports\FastReport4\Lib
C:\Program Files (x86)\Borland\CBuilder6\comp\acnt_regcb6\CB6
C:\Program Files (x86)\Borland\CBuilder6\RXLib\Units
C:\Program Files (x86)\Borland\CBuilder6\EhLib\BCB6




-----------
Library:

C:\Program Files (x86)\Borland\CBuilder6\Projects
C:\CBuilder6\Source\Developer Express Inc\Library\CBuilder6
C:\CBuilder6\Source\6.acnt_regcb6\acnt_regcb6 v6.30\CB6
C:\CBuilder6\Source\FastReports\FastReport4
C:\CBuilder6\Source\FastReports\FastReport4\ADO
C:\CBuilder6\Source\FastReports\FastReport4\BDE
C:\CBuilder6\Source\FastReports\FastReport4\Bpl
C:\CBuilder6\Source\FastReports\FastReport4\DBX
C:\CBuilder6\Source\FastReports\FastReport4\IBX
C:\CBuilder6\Source\FastReports\FastReport4\ExportPack
C:\CBuilder6\Source\FastReports\FastReport4\Lib
C:\Program Files (x86)\Borland\CBuilder6\RXLib\Units
C:\Program Files (x86)\Borland\CBuilder6\comp\acnt_regcb6\CB6
C:\Program Files (x86)\Borland\CBuilder6\EhLib\BCB6




















КАСКО:
- Внесено исправление принятия договора на согласование (под учёткой Андеррайтера)
- Доделано переоформление через УФО
- Поправлена логика последовательности доступности кнопок "Акутализовать догновор" и "Выполнить Расчёт"
- Исправлен процесс добавления Допущеных к управлению при внесении изменений в договор по причине изменения списка лиц допущенных к управлению.

ВЗР:
- Правки, в форме расчёта, в форме печати, в форме представителя страховщика.
- Добавлен комментарий для потомков о том, как правильно собирать, кому передавать сборку (Никите), как правильно раскатывать данный модуль для ОМС-ников для НЕ_ОМС-ников




old:
http://apo.rgs.ru/underwriting/punderwriting.dll/soap/Iunderwriting

new:
http://apo.rgs.ru/underwritingnew/punderwriting.dll/soap/Iunderwriting



# ПАНЕЛЬ АНДЕРРАЙТЕРА:

логин
пароль

oldm
oldm





Макс, ты спрашивал про что-нибудь с именем функции.
Вообще Макрос __FUNCTION__ / __FUNC__
Я подпилил более универсальный варик, включая Билдеровскую версию:

#ifndef __FUNCTION_NAME__
    #ifdef WIN32   //WINDOWS
        #ifdef __BORLANDC__
            #define __FUNCTION_NAME__   __FUNC__ // CPPBulder version
        #endif
        #ifdef _MSC_FULL_VER
            #define __FUNCTION_NAME__   __FUNCTION__ // MSVS version
        #endif
    #else          //*NIX
        #define __FUNCTION_NAME__   __func__
    #endif
#endif



в




При исключении водителя оставшийся водитель теперь отображается в печатных формах как добавление, что некорректно.

ИДЕАЛЬНЫЙ ДОГОВОР С МНОЖЕСТВОМ ДОПУЩЕННЫХ27200
0548113
10.03.2017








- Исправления в печатной форме для допущенных к управлению
- Исправлен баг в процессе удаления допущенного к управлению





Новый формат Exel-файла - Страна Резидент на своём месте.





var_value
0
0
4251
1
1
1
0
24.11.2017 13:49:12
Инструкция пользователя
ftp-apo.rgs.ru:49021

apo_update_downloader3
o0gm5OI672NnaDyeC5MIh2aoTh2HaPmf
APO2_UPDATES/Roznitsa
proxy-h.rgs.ru
3128
0
1
0
21
ftp.rgs.ru
apo2
Humv+msUjhQp7d5/YGD9kibGig==

"ПАО СК ""Росгосстрах"""



Microsoft WDM Image Capture (Win32) (Version:  6.1.7601.17514)
2

// PROD ///////////////////////////////////////////////////////////////////////
https://ufo.rgs.ru:8443/KaskoProxyService.svc?singleWsdl

// TEST ///////////////////////////////////////////////////////////////////////
https://ufot.rgs.ru:8443/KaskoProxyService.svc?singleWsdl


52
Лебедь Марина Валерьевна
https://ufo.rgs.ru/KaskoProxyService.svc?singleWsdl
http://apo.rgs.ru/Card_create_SOAP_Service_test/Card_create_SOAP_Service.dll/soap/ICard_create_SOAP_Service
1
1
0
52
HP LaserJet P3011/P3015 PCL6
0
18.08.2016 22:00:00
apo.rgs.ru#80#10.224.1.240#194.190.20.75
https://ufo.rgs.ru/InspectionProxyService.svc?singleWsdl
0
1
1
HP LaserJet P3011/P3015 PCL6
-1
ВАРНАКОВА АННА АНАТОЛЬЕВНА
GRUPPAGRUPPA
1
1
1
1
1
1
Все регионы
Амурской области
Игрунова Анна Юрьевна
sdfsdf
efwer
0
zczzczcz
150
0
1
1
1
0
0
0
2
0
1
0
0
1
1
https://ufo.rgs.ru/Osago2ProxyService.svc?singleWsdl
1.7
1.8
10.10.2017 23:00:00
НЕТ
1
Представителев Представитель Представтелевич
52

// PROD ///////////////////////////////////////////////////////////////////////
http://apo.rgs.ru/IBD_RSA_WebServ/IBD_RSA_WebServ.dll/soap/IIBD_RSA_WebServ

// TEST ///////////////////////////////////////////////////////////////////////
http://arm-apo.ss.rgs.ru/IDB_RSA_Test/IBD_RSA_WebServ.dll/soap/IIBD_RSA_WebServ

https://life.rgs.ru/eltsearch/EltService.svc
24
24
0
0
21.12.2015
1
1
1
0
1800000

1
https://apo.rgs.ru/apo2_arm_reader.dll/soap/IAPO2_ARM_READER
Инструкция ВЗР
1
0
0
sdfdsf
Семенова Э.В.
1
http://apo.rgs.ru/underwriting/punderwriting.dll/soap/Iunderwriting
https://apo.rgs.ru/apo2_arm_reader.dll/soap/IAPO2_ARM_READER
31.10.2017 19:32:32
1
Выполнено
 

2222
qweqeqeqeqqqqqqqqqqqqqqqqq
7707067683
a12
132
1
1
1
1
1
19.10.2017
1
https://apo.rgs.ru/kaban/kaban.dll/soap/Ikaban
sdfsdfs
http://arm-apo.ss.rgs.ru/SePeZ_RSA_KBM_Test_18/SePeZ_RSA_KBM.dll/soap/Idikbm
Пермский край.
Калужская обл.
cc@rgsbank.ru
0
C:\Users\AlAKuznetsov\Desktop\
xls
2
1
0
44


1
1
C:\rgs\apo2_r\
0
0
CKK2_PRD
apo
8/UB0QWezvQ4mgrWZQnziQ==
0
http://nsso.rgs.ru/NSSO_OSGOP/NSSO_OSGOP_Serv_p.dll/soap/INSSO_OSGOP_Serv
1
1
C:\_WORK_RGS\TASKS\sborki\osago-1-8\
5
1
1
0
1
1
Калькулятор АПО2
1996036412
1
1
http://arm-apo.ss.rgs.ru/Send_OSAGO_Service_Test_18/Send_OSAGO_Service.dll/soap/Isend_OSAGO_Service
1
1
Москва




  .  .    

фывапп
1
1
22
Филиал ПАО 'Росгосстрах' в Алтайском крае Агентство 'Центральное' в г. Барнаул


8-   -   -    
ИП ЧАЙКА


2
51
Представитель страховщика
номер доверенности
14.10.2014


Меньщикова Ирина Анатольевна
KuznetsovAA
1
1
1
1
1
1
0
1
1
52
4
0
22


8-   -   -    
asfdafadsfsd


1
1
1
1
1
1
1
1
цукцук
01.01.2012
1
1
1
28
наименование страховщика
Российская Федерация, г. Москва, д. 7.
банковские реквизиты
8-   -   -    
Степанова Людмила Владимировна
продающее подразделение

1
1
1
1
1
1
1
1
1
1
1
1
1
ЧаВо
1
1
1
1










6001
0005392
30.12.2016

7200
0500182
10.03.2017





КАСКО Переоформление - фикс в печатной форме для допущенных к управлению. Убрал лишнюю кнопку "Удалить допущенного к управлению"


Новый Генеральный договор
длоытрдл
ЫВДЛАТ
УЦВЫДАЛОТИ
УЦЫКДПЛ

ИНН
6950077482

3453546
1231254
24346534

БЕЗНАЛ НОМЕР
1234567
18.12.2017

ЗАЯВКИ - ВСЕ
НОМЕР СЧЁТА
11234366

ПОЛИС
ЕЕЕ
1014010427






от Ольги:
1,808,278 - решил сервис деск

самая частая ошибка !!!!
1,788,721 - доплата
1,810,146 - доплата


ХХХ 0021932111 от 21.12.2017 в данном договоре проблемы с доплатой.






1,815,929






   EZnakTS->Text=q->FieldByName("pol_zayav_ts_gosznak")->AsString;
   
   
   
1,798,612
либо убрать требование предоставления информации по грузовым авто “Массы без нагрузки”, 


Заявка (1,767,205), в наименовании Юр.лица отрабатывала лишняя проверка на недоступность ввода кавычек - исправлено. 
	




X96270500H0829595

Ïîëüçîâàòåëü	Äàòà äîáàâëåíèÿ	Ïðåôèêñ ðàáî÷åãî ìåñòà	Íîìåð ðàñ÷åòà	Êîððåêòíàÿ çàïèñü	Ñòàòóñ îòïðàâêè	Ñòàòóñ	Äàòà îòïðàâêè â ðñà	Ñåðèÿ ïîëèñà	Íîìåð ïîëèñà	Äàòà âûäà÷è ïîëèñà	Ïðåìèÿ	Ðåãèîí	Ñòðàõîâàòåëü	Ìàðêà ÒÑ	Ìîäåëü ÒÑ	Ðåãèñòðàöèîííûé çíàê	VIN ÒÑ	Ãåíåðàëüíûé
Ëåáåäü Ìàðèíà Âàëåðüåâíà	15.12.2017 16:41:38	ÐÌ1	616	Äà				ÅÅÅ	5465765973	15.12.2017	3334,61		ÔÃÓÏ «Ïî÷òà Êðûìà"	ÃÀÇ	2705	Â020ÅÊ82		2



6B5C

F0FF




99220501003





МОСКВА 
Код КЛАДР 
77000000000078200
77000000000289200

КРЫМ
9100000000000 

Владимирская Область. 
Код КЛАДР: 
3300000000000.

Челябинская Область, 
код КЛАДР
74000001000203900,





isCheckSummEmpty



1
1
https://ufo.rgs.ru/Osago2ProxyService.svc?singleWsdl
1.7
1.8
10.10.2017 23:00:00
НЕТ
1
Представителев Представитель Представтелевич
52

// PROD
http://apo.rgs.ru/IBD_RSA_WebServ/IBD_RSA_WebServ.dll/soap/IIBD_RSA_WebServ

// TEST
http://arm-apo.ss.rgs.ru/IDB_RSA_Test/IBD_RSA_WebServ.dll/soap/IIBD_RSA_WebServ

https://life.rgs.ru/eltsearch/EltService.svc
24
24
0
0
21.12.2015
1











mops_global_dicts
27
Справочник Автодилеры

mops_global_dicts_tables
7.4.20 - gl_dict_autodealer - Cправочник "Автодилеры"
27
32

mops_skk_dicts
49*
7.4.20
Cправочник 'Автодилеры'

mops_skk_to_produkti
100
49*
180
-1

mops_produkti
21 !!!
ОСАГО
20
22
10

        sl->Add("ÀÀÀ");
        sl->Add("ÂÂÂ");
        sl->Add("ÑÑÑ");
        sl->Add("ÅÅÅ");
        sl->Add("ÕÕÕ");


CBMarkaTS

CBMarkaAndModelTS


   AnsiString sqlStr = "update OSAGO_R_main2 set ";
   sqlStr = sqlStr + "tip_ts_id							   = " + IntToStr( TSType->ItemIndex == -1 ? 0 : (int)TSType->Items->Objects[TSType->ItemIndex] ) + " ,";
   sqlStr = sqlStr + "pol_zayav_ts_marka_model_for_print   ='" + m_api->Internal_Prepare_SQL_Text(res, CBMarkaAndModelTS->Text).c_str() + "',";
   sqlStr = sqlStr + "pol_zayav_code_marka_model_for_print ='" + IntToStr( cb_save(CBMarkaAndModelTS) ) + "',";

   sqlStr = sqlStr.Delete(sqlStr.Length(), 1); // Удаляем последнюю запятую !!!
   sqlStr = sqlStr + " where (calc_id=" + IntToStr(id_calc) + ")";
   m_api->dbExecuteQuery(res, sql);

   


   



В новом окне, установите разделителем точку:


В Windows XP для этого, зайдите в Панель управления и там откройте Язык и региональные стандарты и нажмите кнопку Настройка...:



RBBezOgrVod
RBAnyVod




ОСАГО - 1. Договор ЕЕЕ 0707008447 от 07.07.2015 пролонгировать. В справочнике «Предыдущий страховщик» отсутствуют значения
http://jira-rgs.rgs.ru:8080/browse/APOII-827?filter=-1

Фортуна Авто - новый модуль
http://jira-rgs.rgs.ru:8080/browse/APOII-1348?filter=-1

История изменения данных субъекта ОСАГО ФЛ. Тестирование
http://jira-rgs.rgs.ru:8080/browse/APOII-1715?filter=-1

Переоформление договора ОСАГО. Данные в заявлении на переоформление - В заявлении на переоформление неправильно выделены данные:
http://jira-rgs.rgs.ru:8080/browse/APOII-1237?filter=-1



Переоформление ОСАГО_Иностранное ТС
http://jira-rgs.rgs.ru:8080/browse/APOII-1663?filter=-1





// ШАНЬШЕРОВ СЕРГЕЙ ВЛАДИМИРОВИЧ
ЕЕЕ
1014178873
29.11.2017







   string osob = <UserData."osob_otmet_txt">;
   
   
   

///////////////////////////////////

Ольга, здравствуте.
Меня интересует следующее:
1) Как происходило переоформление договора ?
1.1) Через кнопки меню ""


1. поменять данные на тестовый РСА
2. начать запрос Договора


ЕЕЕ
1014169740
14.06.2017

1013099454
04.12.2017


1013099454
14.06.2017






////////////////////////////////

Лебедь
ЕЕЕ
1004665917



ЛНР
01332972

ЕЕЕ
1014010424
Однослойный

Нал
Квитанция А7

серия
5662
номер
476084




ОСАГО  ЮЛ  -  ИНН:
6950077482

АДРЕС ИЗ КЛАДР:
Белгородская обл.
Нет
г.Белгород
Нет
ул. 8 Марта

д. 6
корп. 1
кв 10



Начальный номер полиса:
1014570995

-----------------------
Добавляем вручную

Расчёт:
Марка - Киа
Модель - Рио

Мощность дв. 150



А661ОМ199
KNDJD735985847025

Изменит КБМ









   if(q->FieldByName("osob_otmet_memoid")->IsNull == false )
   { //по новому через мемо
     AnsiString osob_otmet_txt("");
     osob_otmet_memoid = q->FieldByName("osob_otmet_memoid")->AsInteger;
     m_api->dbReadWriteInternalMemo(res, osob_otmet_txt, osob_otmet_memoid, true, "osago_r_memo");

     MOsOtm->Text = (osob_otmet_txt.IsEmpty() && m_api->vrGetVariable(res, "corporate") != one_str) ? def_osob_otmet : osob_otmet_txt;
   }
   else
   { //устарело
     st = q->FieldByName("pol_zayav_osob_otmet")->AsString; // ТЕКСТ !!!
	 //
	 //
     MOsOtm->Text = (st.IsEmpty() && m_api->vrGetVariable(res, "corporate") != one_str) ? def_osob_otmet : st;
   }


         memoid = qw->FieldByName("osob_otmet_memoid")->AsInteger; //присвоим старое
         m_api->dbReadWriteInternalMemo(res, memostr, memoid, true, "osago_r_memo"); //читаем
         int osobmemoid = m_api->dbGenerateId(res, "OSAGO_R_memo"); //генерим новое
         m_api->dbReadWriteInternalMemo(res, memostr,   osobmemoid,   false, "OSAGO_R_memo"); //записываем уже новое мемо
		 
		 
   int osob_otmet_memoid = m_api->dbGetIntFromQuery(res, "select osob_otmet_memoid from OSAGO_R_main where calc_id=" + IntToStr(calc_id));
   AnsiString osob_otmet_txt("");
   m_api->dbReadWriteInternalMemo(res, osob_otmet_txt, osob_otmet_memoid, true, "osago_r_memo");		 

      AnsiString sql = "select '" + m_api->Internal_Prepare_SQL_Text(res,orgformfull) + "' as orgformfull, '" +
                    m_api->Internal_Prepare_SQL_Text(res,license) + "' as license, '" +
                    m_api->Internal_Prepare_SQL_Text(res,orgform) + "' as orgform, '" +
                    m_api->Internal_Prepare_SQL_Text(res,osob_otmet_txt) + "' as osob_otmet_txt," +
                    " osago.* from OSAGO_R_main osago where calc_id=" + IntToStr(calc_id);

   


26.02.2018 - 04.03.2018

30.07.2018 - 12.08.2018

01.10.2018 - 07.10.2018







Доработка заполнения поля Реквизитов представителя страховщика при переоформлении договора


sEdit1->


// ШАНЬШЕРОВ СЕРГЕЙ ВЛАДИМИРОВИЧ
ЕЕЕ
1014178873
29.11.2017




ЕЕЕ
1014178921 ОТ 29.11.2017

Дата закл. договора
10.06.2017
Дата рожд. страх.
28.08.1980
номер ВУ
59HX 978542


CBMarkaTSChange
CBMarkaAndModelTS







ЕЕЕ
1014178921
Дата закл. договора
10.06.2017
Дата рожд. страх.
28.08.1980
номер ВУ
59HX 978542



ЕЕЕ
1005748435
Дата рожд. страх.
15.10.1965

10.03.2017

EEE
1005014516
Дата рожд. страх.
02.12.1971



6B5C



1,784,025

Добрый день ! С октября не можем работать в программе АПО, писали уже несколько раз на ваш адрес, вернее внести изменения и сделать Фортуну,
вкладка паспорт не открывается и вкладка полис( где отмечается однослойный или двухслойный), сделайте, пожалуйста






gl_dict_5_1_14_modification_ts



      "    gl_dict_carrier_models mm1"

      CBMarkaTS->Items->AddObject(Trim(q->FieldByName("brand_name")->AsString),(TObject*)q->FieldByName("code")->AsInteger);

      CBModelTS->AddItem(q->FieldByName("model_name")->AsString, (TObject*)q->FieldByName("code")->AsInteger);
	  
	  






select gld_5_1_14.ID from gl_dict_5_1_14_modification_ts gld_5_1_14 where gld_5_1_14.scc_status = 0

select gl_dict_5_1_14_modification_ts.ID from gl_dict_5_1_14_modification_ts where gl_dict_5_1_14_modification_ts.scc_status = 0


select 5_1_14.ID 
from gl_dict_5_1_14_modification_ts as 5_1_14
where 5_1_14.scc_status = 0


select 5_1_14.BRAND_MODIFICATION, 5_1_14.ID 
from gl_dict_5_1_14_modification_ts as 5_1_14
where 5_1_14.scc_status = 0



select gld_5_1_14.BRAND_MODIFICATION, gld_5_1_14.ID 
from gl_dict_5_1_14_modification_ts gld_5_1_14
//        , gl_dict_carrier_models mrkmdl
where gld_5_1_14.scc_status = 0
    and gld_5_1_14.CARRIER_TYPE_CODE = '002'
//order by
// mrkmdl.carrier_type_fk
 

 
select gld_5_1_14.BRAND_MODIFICATION, gld_5_1_14.ID 
from gl_dict_5_1_14_modification_ts gld_5_1_14
where gld_5_1_14.scc_status = 0
    and gld_5_1_14.CARRIER_TYPE_CODE = '002'
order by
 gld_5_1_14.id

 
 
 


-- 5.1.14
select *
from  rgsscc.ref_CARRIERMODIFICATION
where scc_status=0

select ct.code "CARRIER_TYPE_CODE", cm.* from rgsscc.ref_carriermodification cm
join RGSSCC.REF_CARRIER_TYPE ct on CM.CARRIER_TYPE=CT.SCC_ID
where cm.scc_status=0 and ct.scc_status=0

-- 5.1.3
select *
from  rgsscc.REF_CARRIER_MODELS
where scc_status=0

-- 5.1.1
select *
from  rgsscc.REF_CARRIER_TYPE
where scc_status=0



-- 5.1.14 <->  5.1.3
select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_MODELS
where rgsscc.REF_CARRIERMODIFICATION.CODE = rgsscc.REF_CARRIER_MODELS.CODE

-- 5.1.14 <-> 5.1.1
select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_TYPE
where rgsscc.REF_CARRIERMODIFICATION.carrier_type = rgsscc.REF_CARRIER_TYPE.CODE


select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_MODELS
where rgsscc.REF_CARRIERMODIFICATION.CODE = rgsscc.REF_CARRIER_MODELS.CODE
--where rgsscc.REF_CARRIERMODIFICATION.scc_status=0
--and rgsscc.REF_CARRIERMODIFICATION.CODE = rgsscc.REF_CARRIER_MODELS.CODE


MODIFICATION_TS_5_1_14

select "SCC_ID","SCC_STATUS","ID","DATE_FROM","DATE_TO","TICK","IS_NODE","BASE_ID","CARRIER_MODIFICATION_ID","CODE","BRAND_MODIFICATION","MODIFICATION","IS_DEFAULT","CARRIER_TYPE","START_DATE","END_DATE"
from  rgsscc.ref_CARRIERMODIFICATION
where scc_status=0
 


 
select ct.code "CARRIER_TYPE_CODE", cm.* from rgsscc.ref_carriermodification cm
join RGSSCC.REF_CARRIER_TYPE ct on CM.CARRIER_TYPE=CT.SCC_ID
where cm.scc_status=0 and ct.scc_status=0





EEE
1005014516
Дата рожд. страх.
02.12.1971


07.06.2017
06.12.2017
06.06.2018



	ЕЕЕ
	1005748435
	06.03.2017


3.	Значения выбираются из выпадающего списка, который формируется на основании значений поля BRAND_MODIFICATION справочника CARRIER_MODIFICATION.
•	Отбираются строки, для которых значение поля CARRIER_TYPE совпадает с типом ТС по договору.




Добрый день!
Клиент обратился за продлением периода. Первоначально полис был оформлен на 6 месяцев ( оплачено 70% от года ),
затем период был просрочен и полис продлен еще на 3 месяца, т.е оплачено еще 50% от годовой премии. Сейчас клиент обратился,
чтобы продлить полис до конца года. Менеджер все сделал через АПО-2, программа показала возврат части страховой премии 
и клиенту это было озвучено. Так же распечатан полный пакет документов в котором есть распоряжение на возврат.
В полисе который выдан взамен тоже указана премия меньше. 
 
Подскажите, пожалуйста, в таких случаях мы производим возврат или нет? 

-- 5.1.14
select *
from  rgsscc.ref_CARRIERMODIFICATION
where scc_status=0

-- 5.1.3
select *
from  rgsscc.REF_CARRIER_MODELS
where scc_status=0

select ct.code "CARRIER_TYPE_CODE", cm.* from rgsscc.ref_carriermodification cm
join RGSSCC.REF_CARRIER_TYPE ct on CM.CARRIER_TYPE=CT.SCC_ID
where cm.scc_status=0 and ct.scc_status=0


--select *
--from  rgsscc.REF_CARRIER_MODELS
--where scc_status=0
--and RF_DEV_TYPE_FK$ = 3
--and RF_DEV_TYPE_FK = 3

-- 5.1.1
select *
from  rgsscc.REF_CARRIER_TYPE
where scc_status=0



-- 5.1.14 <->  5.1.3
select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_MODELS
where rgsscc.REF_CARRIERMODIFICATION.CODE = rgsscc.REF_CARRIER_MODELS.CODE

-- 5.1.14 <->  5.1.3
select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_MODELS
where rgsscc.REF_CARRIERMODIFICATION.CODE = RGSSCC.REF_CARRIER_MODELS.CARRIER_TYPE_FK_


-- 5.1.14 <-> 5.1.1
select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_TYPE
where rgsscc.REF_CARRIERMODIFICATION.carrier_type = rgsscc.REF_CARRIER_TYPE.CODE


select rgsscc.REF_CARRIERMODIFICATION.CODE
from  rgsscc.REF_CARRIERMODIFICATION, rgsscc.REF_CARRIER_MODELS
where rgsscc.REF_CARRIERMODIFICATION.CODE = rgsscc.REF_CARRIER_MODELS.CODE
--where rgsscc.REF_CARRIERMODIFICATION.scc_status=0
--and rgsscc.REF_CARRIERMODIFICATION.CODE = rgsscc.REF_CARRIER_MODELS.CODE







OSAGO_2017_12_04

Доработка взаимодействия с новым форматом Exel-файла для подгрузки в модуль.

Исправление отправки в ОСАГО 24 информации о том является страхователь Резидентом или нет.




Исправление автоматического расчёта доплаты премии, при выборе причины переоформления - Использование ТС с прицепом/без





gl_dict_5_1_14_modification_ts


OSAGO_R_AutoDictOsagoVehType

Набираем Марки:
//loadmarka
gl_dict_carrier_models

Набираем Модели:
GL_DICT_CARRIER_MODELS

   TADOQuery *q = m_api->dbGetCursor(res, "select code, model_name from  GL_DICT_CARRIER_MODELS where (brand_name='" + Marka +
                                                                                              "' and carrier_type_fk=" + IntToStr(tstypeid) +
                                                                                              " and active_entry='Y'"
                                                                                             // + " and used_by_rami='Y'" //â âûãðóçêó îñàãî24 ïðîâåðÿòü åñëè ýòî used_by_rami=N  ïîäñòàâëÿòü äðóãóþ ìàðêó/ìîäåëü èä
                                                                                              + ") order by model_name");
																							  
      CBModelTS->AddItem(q->FieldByName("model_name")->AsString, (TObject*)q->FieldByName("code")->AsInteger);

	  
	  


double CalcOsago::CalcKpr() {
	

  ShowResult();
  CalcPrem();
  
  
  





   cbResident->Checked = q->FieldByName("sobst_resident")->AsString == "1" ? 1 : 0;

            qw->FieldByName("sobst_resident")->AsInteger = ex->fromExcelCell(cur_line, EXEL_COL_IS_RESIDENT) == "Äà" ? 1 : 0;
   
   


Исправлен баг с всмплывающим сообщением про номер телефона Страхователя




Телефон:
1,800,467



ÂÂÂ
ÑÑÑ
ÅÅÅ
XXX

ВВВ
ССС
ЕЕЕ
XXX


Перезапустите АПО2 и обновите модуль до последней версии, баг устранён.



ÂÂÂ
ÑÑÑ
ÅÅÅ
XXX


ÂÂÂ
ÅÅÅ


EPolSer

   EPolSer->ItemIndex = EPolSer->Items->IndexOf(q->FieldByName("pol_zayav_pol_ser")->AsString);
   if(EPolSer->ItemIndex < 0) EPolSer->ItemIndex = 1;
EPolNum
   

EPRPolSer
EPRPolNum




2584
chkNoContacts->Checked

1355
куда 


Исправление автоматического расчёта доплаты премии, при выборе причины переоформления - Изменение цели использования ТС (использование ТС в качестве такси)

Обноление справочников:
- 7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры ОСАГО ЮЛ
- 7.9.25 Справочник клиентов по Бизнес-ОСАГО 
- 7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 







1,622,848



      if( MYGLOBAL::gEditType & 2048 ) { //Цель исп.ТС
        TSPurpose->Enabled = true;
        TSPurpose->Color = clYellow;
      }
	  
	  

	  
TSPurposeChange(TObject *Sender)


ClassCalcOsago:
void CalcOsago::SetPurposeId(long value) // 5 TAXI
{
   PurposeId = 0;
   FilteredQuery(vehpurpose, "purpose_id=" + IntToStr(value)); // 5 TAXI
   if(qw[vehpurpose]->RecordCount == 1)
        PurposeId = value;
   SetError(30, !(qw[vehpurpose]->RecordCount == 1));
   CalcBp();
}


CalcBp





        double prem = Recalc(qw);
//на заполненость печати проверить неможем(надо писать функ. проверки по полям бд(щас по полям на форме только есть)) но по крайней мере считаем корректным если премия посчиталась
        if(prem==0)
        {
            lf->Add("Премия не расчиталась, требуется редактирование");
            correct=false;
        }
//чексумма
        AnsiString osago_prem_int = IntToStr( (int)prem );
        AnsiString str_in = polser->Text + qw->FieldByName("pol_zayav_pol_num")->AsString + /*DEInsBDate->Date.FormatString("ddmmyyyy") +*/ osago_prem_int;
        AnsiString checksumm = m_api->GetCrc16ForPolisSign(res, str_in);
        m_api->dbExecuteQuery(res, "insert into osago_r_main2 (calc_id,checksumm) values("+IntToStr(calc_id)+",'"+checksumm+"')");

		
		


   // SAVE
   if(osob_otmet_memoid == 0) osob_otmet_memoid = m_api->dbGenerateId(res, "OSAGO_R_memo");
    m_api->dbReadWriteInternalMemo(res, MOsOtm->Text, osob_otmet_memoid, false, "OSAGO_R_memo");
   
   // LOAD
     osob_otmet_memoid = q->FieldByName("osob_otmet_memoid")->AsInteger;
     m_api->dbReadWriteInternalMemo(res, osob_otmet_txt, osob_otmet_memoid, true, "osago_r_memo");
     MOsOtm->Text = (osob_otmet_txt.IsEmpty() && m_api->vrGetVariable(res, "corporate") != one_str) ? def_osob_otmet : osob_otmet_txt;

     st = q->FieldByName("pol_zayav_osob_otmet")->AsString;
   



MainWinFC
//   m_api->Raise_Error_Warning(res, this, 0, "Не выполнен расчет.", "Не выполнен расчет.", 0, PRARM, err_num++, (produktindex != FORTUNA_ONLY) && (calc->IT->Caption == dash) );


// ЗАМЕНА ТЕХ ОСМОТРА НА ДИАГНОСТИЧЕСКУЮ КАРТУ: никак не развести по дефайнам в этом месте, т.к.
//  находится в OSAGO_R_MAIN_2		//   находится в OSAGO_R_MAIN_1
//"pol_zayav_ts_diagcard_num='%s',"		// "pol_zayav_ts_tehosmort_num='%s',"
//"pol_zayav_ts_diagcard_month='%s',"	// "pol_zayav_ts_tehosmort_month='%s',"
//"pol_zayav_ts_diagcard_year='%s',"	// "pol_zayav_ts_tehosmort_year='%s',"


sql = sql + "pol_zayav_ts_diagcard_num  ='" + m_api->Internal_Prepare_SQL_Text(res, editTehOsmortNum->Text.Trim()).c_str() + "'";
sql = sql + "pol_zayav_ts_diagcard_month='" + m_api->Internal_Prepare_SQL_Text(res, cboxTehOsmortMonth->Text).c_str() + "'";
sql = sql + "pol_zayav_ts_diagcard_year ='" + m_api->Internal_Prepare_SQL_Text(res, cboxTehOsmortYear->Text).c_str() + "'";





ЛНР:
01606520




ОСАГО  ЮЛ  -  ИНН:
6950077482

АДРЕС ИЗ КЛАДР:
Белгородская обл.
Нет
г.Белгород
Нет
ул. 8 Марта

д. 6
корп. 1
кв 10



Начальный номер полиса:
1014570995

-----------------------
Добавляем вручную

Расчёт:
Марка - Киа
Модель - Рио

Мощность дв. 150



А661ОМ199
KNDJD735985847025

Изменит КБМ











//   m_api->Raise_Error_Warning(res, this, 0, "Íå âûïîëíåí ðàñ÷åò.", "Íå âûïîëíåí ðàñ÷åò.", 0, PRARM, err_num++, (produktindex != FORTUNA_ONLY) && (calc->IT->Caption == dash) );





Сборка со СТАРОЙ схемой EXEL-файла

Сборка с НОВОЙ схемой EXEL-файла




EInsNameYur
EStrachCodeKK

     
 
 


FIND  cNeedNewVer

bool _bool_osago_old_enable_krm_request = m_api->vrGetVariable(res, "_osago_old_enable_krm_request_") == 1 ? true : false;

if(!_bool_osago_old_enable_krm_request) // #OPA 2017.11.22: Скрыть сообщение про ОСАГО 2.0 по параметру _osago_old_enable_krm_request_
{ ShowMessage(cNeedNewVerFiz); }

							
cNeedNewVer
Скрыть сообщение про ОСАГО 2.0
_osago_old_enable_krm_request_


if(m_pCalc != 0) { TFrameCalc *fr = (TFrameCalc *)m_pCalc;



Исправление в печатной форме для корректного отображения данных по дате окончания страхования.





//////////////////////////////////////////////////////////////////////////////
   // Начиная с доработки  http://jira-rgs.rgs.ru:8080/browse/APOII-1765
   // согласно пункту 5: 5. Убрать  обязательность заполнения поля "номер , серия и дата свидетельства о регистрации юридического лица"
   // в связи с тем, что с 01.01.2017 года при регистрации юридического лица, больше не выдается свидетельство о регистрации, а выдается лист записи.
   //

   bool is_fiz = (RBInsFiz->Checked && !ip_strah->Enabled);
   if(is_fiz) {  }

[Собственник]Неверно указана дата рождения

// Начиная с доработки  http://jira-rgs.rgs.ru:8080/browse/APOII-1765
// согласно пункту 5: 5. Убрать  обязательность заполнения поля "номер , серия и дата свидетельства о регистрации юридического лица"
// в связи с тем, что с 01.01.2017 года при регистрации юридического лица, больше не выдается свидетельство о регистрации, а выдается лист записи.
//
//   TDateTime enteredOwnDocDate = Date();
//   if(CheckDate(DEOwnDocDate->Text)) enteredOwnDocDate = DEOwnDocDate->Date;
//   m_api->Raise_Error_Warning(res, this, 0, "[Собственник]Дата выдачи документа не может быть раньше текущей даты", "[Собственник]Дата выдачи документа не может быть раньше текущей даты", 0, PRARM, err_num++,
//        !iz_osago_online && (produktindex != OSAGO_ONLY) && (DEOwnDocDate->Enabled && enteredOwnDocDate > Date()) );
//   m_api->Raise_Error_Warning(res, this, 0, "[Собственник]Неверно указана дата выдачи документа", "[Собственник]Неверно указана дата выдачи документа", 0, PRARM, err_num++,
//        !iz_osago_online && (produktindex != OSAGO_ONLY) && (DEOwnDocDate->Enabled && CheckDate(DEOwnDocDate->Text) == 0) );
   


VZR SHENGEN
/////////////////////////////////////
15 дней к зоне Шенген в Вирту

dtESrok = str_polis_end_data
dtSSrok = str_polis_start_data
dtInsurSrok = dtESrok - dtSSrok
dtDiff = dtESrok - dtSSrok

 10 дней
24.11.2017 - 03.12.2017 -- 10
dtESrok = str_polis_end_data   = 03.12.2017
dtSSrok = str_polis_start_data = 24.11.2017
dtInsurSrok = dtESrok - dtSSrok= 10
dtDiff = dtInsurSrok - UserData."MainDays" = 10 - 10 = 0


if (dtInsurSrok == UserData."MainDays")  then if(dtInsurSrok <= 90) then +15
if (dtInsurSrok == UserData."MainDays")  then if(dtInsurSrok  > 90) then +0
if (dtInsurSrok  > UserData."MainDays")  then if(dtDiff < 15) then +(15-dtDiff)
if (dtInsurSrok  > UserData."MainDays")  then if(dtInsurSrok - UserData."MainDays" > 15) then +0

dtESrokLimit = str_polis_start_data + 90;
dtESrokLimit = dtESrokLimit - 1;                                             



if(dtESrok - dtSSrok)
			   
1.	Если срок страхования строго равен кол-ву дней, но не более 90 включительно, то прибавляем 15 дней
Пример: с 01.01.2018   по 15.01.2018  на 15 дней, то после перерасчёта будет по 30.01.2018.
2.	Если срок страхования равен кол-ву дней, и более 90 дней, то не прибавляем 15 дней
Пример: с 01.01.2018 по 01.05.2018  срок на 10 дней, то после перерасчёта дата окончания не меняется.
3.	Если срок страхования больше, чем кол-во дней, но разница между сроком страхования и кол-вом дней менее 15 дней, то прибавляем разницу что бы получилось   15 дней. 
Пример:   01.05.2018 по 20.05.2018  кол-во дней = 15, то в полисе срок страхования должен быть с 01.05.18 по 30.05.18 
Пояснение
Период страхования всегда равен количеству застрахованных дней +15дней. Если период не более 90 дней.
4.	Если срок страхования больше, чем кол-во дней, но разница между сроком страхования и кол-вом дней более 15 дней, то не прибавляем 15 дней
Пример:   с 01.01.2018 по 01.02.2018 на 2 дня  срок после перерасчёта не изменится.



DaysTo = [UserData."MainDays"]

        lSQL = "update vzr174Pr_calc set "
        " MainDays=" + (eDays->Text) + ","

		

		

количество дней срока страхования;
	
    int days = m_api->dbGetIntFromQuery(m_Res, "select DaysTo from VZR174Pr" + spec + "_Terms where ID = " + IntToStr(idTerm));
    eDays->Value = days;

	
	

//Форматирование при печати.
        idTerr = (int)CBTerritory->Items->Objects[CBTerritory->ItemIndex];
        nAddDay = 0;

        sCountryReport = MakeReportString();
        if(idTerr == 2) { //шенген
           sCountryReport = "Schengen";
        }
		
////////////////////////////////////		
    if(CBTerritory->ItemIndex != -1){
      int id = (int)CBTerritory->Items->Objects[CBTerritory->ItemIndex];
      sCListBoxStraniSel->Clear();
      TADOQuery *qw = NULL;

//запрос стран группы
      switch(id) {
        case 2: //СНГ
        case 4: //Шенген

//////////////////////////////////////

  m_idSchengen = gAPI->dbGetIntFromQuery(gRes, "select id_terr from VZR174Pr_terr where terr_name = 'Schengen'");
		
//////////////////////////////////////
DEFAULT_VALUE_DAY = 15
//////////////////////////////////////


        " idMainTerritory="         + IntToStr((int)CBTerritory->Items->Objects[CBTerritory->ItemIndex])                       + ","

		


	if(osob_otmet_memoid == 0) osob_otmet_memoid = m_api->dbGenerateId(res, "OSAGO_R_memo");
   m_api->dbReadWriteInternalMemo(res, MOsOtm->Text, osob_otmet_memoid, false, "OSAGO_R_memo");

   
   if(q->FieldByName("osob_otmet_memoid")->IsNull == false ) { //ïî íîâîìó ÷åðåç ìåìî
     AnsiString osob_otmet_txt("");
     osob_otmet_memoid = q->FieldByName("osob_otmet_memoid")->AsInteger;
     m_api->dbReadWriteInternalMemo(res, osob_otmet_txt, osob_otmet_memoid, true, "osago_r_memo");
     MOsOtm->Text = (osob_otmet_txt.IsEmpty() && m_api->vrGetVariable(res, "corporate") != one_str) ? def_osob_otmet : osob_otmet_txt;
   } else {
      //óñòàðåëî
     st = q->FieldByName("pol_zayav_osob_otmet")->AsString;
     MOsOtm->Text = (st.IsEmpty() && m_api->vrGetVariable(res, "corporate") != one_str) ? def_osob_otmet : st;
   }
   
   
   
		
///////////////////////////////////////////////////////////////////////////////





OSAGO_R_AutoDictOsagoVehType





select *
from  rgsscc.ref_CARRIERMODIFICATION
where scc_status=0


Модификации ТС для печати

MODIFICATION_TS_5_1_14
gl_dict_5_1_14_modification_ts
gl_dict_7_5_4_blank_series



НО В !!!
ConvertXMLResponseToCalcKbmReqType
TicketDiagnosticDate ??? как исправлять-то ?


Не заполнена дата очередного технического осмотра (дата окончания действия диагностической карты) (TicketDiagnosticDate)
при заполненном номере документа технического осмотра (TicketCarNumber)



//////////////////////////////////////////////////////////////////////////////
В БД 
pol_zayav_strah_key_client_code

В ИНТЕРФЕЙС:
keyclientcode


FieldByName("pol_zayav_strah_inn")->AsString     = inn->Text;
qw->FieldByName("")->AsString = ->Text;

qw->FieldByName("pol_zayav_strah_key_client_code")->AsString = strKeyClientCode;//ïðèîðèòåò èç åêñåëü åñëè êîä êëþ÷.êëíò ñòðàõîâàòåëÿ èç åêñåëü îòëè÷àåòñÿ îò êîäà ÊÊ ñòðàõîâàòåëÿ â ãåíåðàëüíîì

qw->FieldByName("pol_zayav_ts_mass_unladen")->AsInteger = massunladen; }


qw->FieldByName("pol_zayav_ts_diagcard_num")->AsString = st;
qw->FieldByName("pol_zayav_ts_diagcard_month")->AsString = mes[mesint]; // pol_zayav_ts_tehosmort_month
qw->FieldByName("pol_zayav_ts_diagcard_year")->AsString = st;
qw->FieldByName("pol_zayav_ts_diagcard_to_not_exist")->AsInteger = st == "Да" ? 1 : 0;
		 
"pricep"
		 


//////////////////////////////////////////////////////////////////////////////



/* // DELETE




 if(pcInsurer->ActivePageIndex == 0){
    sPPhysical->Visible = true;
    sPJuridical->Visible = false;
  }
 if(pcInsurer->ActivePageIndex == 1){
    sPPhysical->Visible = false;
    sPJuridical->Visible = true;




   CBBlankType->Items->Add("001");




Анна, благодарю за предоставленные данные.

Ещё несколько вопросов у меня имеется, которые важны для доработки:
1) "ТО отсуствует по закону"
(!)- Где на Интерфейсе формы "Генеральный Договор" мне разместить данный комбобокс ?

- доступные варианты только "Да" / "Нет" ?
- Каков алгоритм определения данного пункта ?
- Что делать, если и возмсожен ли случай, когда в поле пусто (ни "Да" ни "Нет") ?

2) Номер Диаг.Какрты и сроки:
- Возможен ли вариант: Что ЕСТЬ номер Диаг.карты, но не указан срок (Что выводить в качестве предупредительного сообщения) ?
- Возможен ли вариант: Что НЕТ  номера Диаг.карты, но указан срок (Что выводить в качестве предупредительного сообщения) ?

3) Код КК - Верно ли я зафикстировал, что это "Код Ключевого Клиента"
(!)- Где на Интерфейсе формы "Генеральный Договор" мне разместить данное поле ?

- Встроить ли стандартные проверки и какие (должно быть целым, положительным, неотрицаительным числом, и всё остальное недопустимо ? есть ли предел для данного значения может ?)

4) Масса без нагрузки
(!)- Где на Интерфейсе формы "Генеральный Договор" мне разместить данное поле ?

- Встроить ли стандартные проверки и какие (должно быть целым, положительным, неотрицаительным числом, и всё остальное недопустимо ? есть ли предел для данного значения может ?)

(!) Необходимо ли вообще дорабатывать экранные формы, по тем полям, что согласно новым столбцам в EXEL-файле отсуствуют как элементы интерфейса на экранной форме Генерального договора ?






//МАРКА ТС
         AnsiString marka = ex->fromExcelCell(cur_line, 5).Trim();
         AnsiString marka2 = ex->fromExcelCell(cur_line, 7).Trim();
         qw->FieldByName("pol_zayav_ts_marka")->AsString     = marka;
         qw->FieldByName("pol_zayav_ts_marka2")->AsString    = marka2.IsEmpty() ? AnsiString("="):marka2; // "=";
         qw->FieldByName("pol_zayav_code_marka")->AsString   = m_api->dbGetStringFromQuery(res,"select code from gl_dict_carrier_models where brand_name='"+ marka +"' and model_name=''");

		 


// СУХАРЕВ МАКСИМ МИХАЙЛОВИЧ = Класс аварийности 13 Кбм = 0,5
СУХАРЕВ
МАКСИМ
МИХАЙЛОВИЧ
04.01.1984
02ВУ
219513
10.10.2006

// БАНИШЕВ НИКИТА ВЯЧЕСЛАВОВИЧ = 5
БАНИШЕВ
НИКИТА
ВЯЧЕСЛАВОВИЧ
07.02.1992
78ХС
002977
17.02.2010

		 
// нету и присылается ТРИ дефолтное, но с успешным ответом
Еваев
Василий
Михайлович
12.08.1982
7116
654602
17.12.2002



1,753,379

БАНИШЕВ
НИКИТА
17.02.2010
17.02.2020
78ХС
002977

[IIF( <UserData_2."rsa_req_info_type"> >0 , 'По водителю; ' [UserData_2."f"] [UserData_2."i"] [UserData_2."o"] ' запрос в АИС РСА произведён по ' [IIF( <UserData_2."rsa_req_info_type"> = 1,'предыдущим данным прав ', [IIF( <UserData_2."rsa_req_info_type"> = 2,'предыдущим персон. данным и водит. удост. ','' )] )]
[IIF( <UserData_2."rsa_req_info_type"> = 1, [UserData_2."prev_prava_s"] [UserData_2."prev_prava_n"], [IIF( <UserData_2."rsa_req_info_type"> = 2, [UserData_2."prev_f"] [UserData_2."prev_i"] [UserData_2."prev_o"] ';' [UserData_2."prev_prava_s"] [UserData_2."prev_prava_n"] ,'' )] )] ,'' )] 



[IIF( i>0 
		, 'По вод.; '"fio" 'по ' [IIF( i= 1 
											, 'предыдущим прав '
											, [IIF( i= 2
														, 'предыдущ перс. и вод.уд. '
														, '' 
														)]
											)]
								[IIF( i= 1
											, "ps""pn"
											, [IIF( i= 2
														, "pf""pi""po"' ; '"ps""pn" 
														,'' 
														)]
											)] 
		, '' 
		)] 




[UserData_2.""]


усл ? тру : фолс

[IIF( <UserData."pol_zayav_dop_tolko_sled_voditeli">,'Изменением состава лиц, допущенных к управлению застрахованного ТС','Изменением списка допущенных лиц к управлению ТС на «все допущены»')]

[IIF( <UserData."pol_zayav_dop_tolko_sled_voditeli">,'Изменением состава лиц, допущенных к управлению застрахованного ТС','Изменением списка допущенных лиц к управлению ТС на «все допущены»')]



[iif(<UserData."pol_zayav_strah_FU"> =1,'ИНН ' + <UserData."pol_zayav_strah_inn">,<UserData."pol_zayav_strah_docum"> + ' серия ' + <UserData."pol_zayav_strah_doc_ser"> + ' номер ' + <UserData."pol_zayav_strah_doc_num">)] телефон [UserData."pol_zayav_strah_telefon3"]





1) Поправил проставление галочек "Водитель ФИО не менял" и "ВУ не менялось", после сохранения допущенного в список допущенных и повторного открытия на изменение/просмотр данных по нему.
2) Добавил в Печатную форму вывод информации по запросу данных из РСА, по предыдущим данным Допущенного к управлению.

в заявлении на страхование при заключении сейчас так печатается, если Кбм по предыдущим данным определен
в инструкции по АПО есть, которую мы готовили к запуску функционал
а


         AnsiString str = q_dop->FieldByName("rsa_req_info_type")->AsString;
		 d.RSARequestInfoType   = (str.IsEmpty() || str == "NULL")  ? StrToInt( str ) ? Dopush::DOPUSH_RSA_CUR_USER_CUR_VU;

        // I   этап - Запрос с текущими ФИО пользователя и с текущими правами
        testHiddenRSACurrUserCurrVUInfo(*f, strAvarClass, strBonusMalus);

        // II  этап - Запрос с предыдущими ФИО (вдруг сменил ФИО,... )  и с текущими правами     (... а прав на тот момент были ещё старыми)
        if( strAvarClass==DEFAULT_AVAR_CLASS_3 || strAvarClass.IsEmpty() || strBonusMalus.IsEmpty() )
        { testHiddenRSACurrUserPrevVUInfo(*f, strAvarClass, strBonusMalus); }

        // III этап - Запрос с предыдущими ФИО (вдруг сменил ФИО) и с предыдущими правами  (вдруг сменил права)
        if( strAvarClass==DEFAULT_AVAR_CLASS_3 || strAvarClass.IsEmpty() || strBonusMalus.IsEmpty() )
        { testHiddenRSAPrevUserPrevVUInfo(*f, strAvarClass, strBonusMalus); }

        // IV  - После всех 3ёх этапов, если ничего не найдено оставляем Дефолтный класс аварйности или выставляем найденный
        if( !strAvarClass.IsEmpty() && (strAvarClass != DEFAULT_AVAR_CLASS_3) )
        { f->CBBM->ItemIndex = f->CBBM->Items->IndexOf(strAvarClass); //выставляем найденный класс
        }
        else
        { f->CBBM->ItemIndex = f->CBBM->Items->IndexOf(DEFAULT_AVAR_CLASS_3); //выставляем класс = 3 по умполчанию
        }
		 




 1771558 

 
7100
0768065
06.07.2017 
 
 
vzr174Pr_calc

strach_pasport_addr
strach_pasport_type


"select (last_name+' '+first_name+' '+second_name) as fio_pm, phisical_sex, phisical_birth_date, document_issue_date, document_series, document_number"

casco_persons_r
       " permitted_status=1 and" // Добавить в список лиц, допущенных к управлению
       " permitted_status=3 and" // Исклоючить из списка лиц, допущенных к управлению


   q_perm->FieldByName("permitted_status")->Value = pm_status;
   
   


1,771,558

По водителю «ФИО» запрос в АИС РСА произведен по предыдущей фамилии

Имеются только ограничения такого рода: 
Недоступность выбора причин переоформления, для определённых серий договора:
(Например: Засериваем чекбокс "Выдача дубликата полиса в связи с утерей", если серия договора == "ХХХ")




http://jira-rgs.rgs.ru:8080/browse/APOII-1690



Иваев
Василий
Михайлович
12.08.1982
7116
654602
17.12.2002

Иваев
Василий
7116
654602





[IIF( <UserData_2."rsa_req_info_type"> >0 , 'По водителю; ' [UserData_2."f"] [UserData_2."i"] [UserData_2."o"] ' запрос в АИС РСА произведён по ' [IIF( <UserData_2."rsa_req_info_type"> = 1,'предыдущим данным прав ', [IIF( <UserData_2."rsa_req_info_type"> = 2,'предыдущим персон. данным и водит. удост. ','' )] )]
[IIF( <UserData_2."rsa_req_info_type"> = 1, [UserData_2."prev_prava_s"] [UserData_2."prev_prava_n"], [IIF( <UserData_2."rsa_req_info_type"> = 2, [UserData_2."prev_f"] [UserData_2."prev_i"] [UserData_2."prev_o"] ';' [UserData_2."prev_prava_s"] [UserData_2."prev_prava_n"] ,'' )] )] ,'' )] 

              MasterData23.Visible := true;           


			  
			  



Error("Расширение территории доступно только для ТС группы ИГ1-ИГ3, ОГ1", ++error_num, is_autorization && reasons_surcharge[15]

di->no_calc
- Убрать перерасчёт премии после Авторизации.








- Блок "Информация по переоформлению" более не пропадает во время выбора причин переоформления.
- В блок заносится информация о Доплате только после Авторизации догоора и запроса в УФО.
- Поле "контактный телефон" - пропадало всегда.
- При Расчете доплаты по договору, в случае если доплаты не требуется - выводится корректное сообщение
- Временно переместил мешающее вводу информационное поле "По окончанию ввода нажмите клавишу Enter"
- Ошибки УФО в рассмотрение не брал


6001
0005392
30.12.2016

7200
0500182
10.03.2017


01.01.1999
01.01.2017








1) Поправи проставление галочек "Водитель ФИО не менял" и "ВУ не менялось", после сохранения допущенного в список допущенных и повторного открытия на изменение/просмотр данных по нему.
2) Добавил в Печатную форму вывод информации по запросу данных из РСА, по предыдущим данным Допущенного к управлению

34147

32386





	
- Убран вывод сообщений обязательного ввода ввод даты выдачи ВУ и даты окончания ВУ,
если стоят отметки «ВУ не менялось». 
- При редактировании добавленного водителя выводится 
такое же окно с инф-цией о предыдущих данных ФИО / ВУ, как и при добавлении. 
- Поправлен запрос КБМ, на первичном этапе с текущ. ФИО + текущ.ВУ / текущ. ФИО + предыдущ. ВУ / предыдущ. ФИО + предыдущ. ВУ



	


- Поправлен запрос КБМ с текущими ФИО и предыдущим ВУ.

 
DB_PURPOSE_TAXI


CBBlankType


CBNewBlankType	


FillCalcKBMReqTypeToForm

123456789012345678901234567890123456789012
FillCalcCurrUserCurrVUInfoKBMReqTypeToForm


Еваев
Василий
Михайлович
12.08.1982
7116
654602
17.12.2002



1,753,379

БАНИШЕВ
НИКИТА
ВЫЧЕСЛАВОВИЧ
07.02.1992
78ХС
002977
17.02.2010

БАНИШЕВ
НИКИТА
17.02.2010
17.02.2020
78ХС
002977



[IIF( <UserData."pol_zayav_dop_tolko_sled_voditeli">,'Изменением состава лиц, допущенных к управлению застрахованного ТС','Изменением списка допущенных лиц к управлению ТС на «все допущены»')]


      f->EFirstName->Text   = d.FirsName;
      f->ESecondName->Text  = d.SecondName;
      f->ELastName->Text    = d.LastName;
      f->EVUSer->Text       = d.DriverLicenseSer;
      f->EVUNum->Text       = d.DriverLicenseNum;
      // Ïðåäûäóùèå äàííûå Äîïóùåííîãî ê óïðàâëåíèþ
      f->EPrevFirstName->Text   = d.PrevFirsName;
      f->EPrevSecondName->Text  = d.PrevSecondName;
      f->EPrevLastName->Text    = d.PrevLastName;
      f->EVUPrevSer->Text       = d.PrevDriverLicenseSer;
      f->EVUPrevNum->Text       = d.PrevDriverLicenseNum;
      f->DatePrevVUStart->Date  = d.PrevDocDateStart;
      f->DatePrevVUEnd->Date    = d.PrevDocDateEnd;



Переоформление
причны - измен. данных транстп средства + гос номера   БЕЗ перерасчёта
Поменяла гос номер
Помегняла серию номер дату выдачи ПТС

Полис серия ЕЕЕ
номер внесла сама
Тип бланка - пустой



1,754,627

Здравствуйте, пришлите пожалуйста СЕРИЮ, НОМЕР Договора и ДАТУ заключения договора.

Если у водителя нет предыдущего Водительского удостоверения (ВУ), то заполняйте поля предыдущего ВУ, как поля текущего имеющегося ВУ. И дату выдачи и дату окончания вписывайте, для имеющихся прав соответственно.
Если у водителя не менялись ФИО, вписывайте в предыдущие, его текущие данные. 

Ответ: Так как был зпрос на то, что VIN редактировать более нельзя, в данной ситуации всё отрабатывает верно.  Удалите информацию из VIN  в учётной системе, такого в VIN быть не должно.
После этого выполните запрос из апо-2 повторно на подгрузку договора. Могут быть задержки после правки в учётной системе с подгрузкой исправленной информации.

Ответ: Удостоверьтесь, что модуль обновился до последней версии.


/*-------------------------------Описание типичной ошибки------------------------------
*/


Было 3 типа заявок, которые в явном виде выделялись в чёткие группы, которые я соответсвенно пометил как:
1) "Осаго 1.0 ошибка - РСА 1.8" - Ошибка связанная с неверной обработкой в модуле запроса в РСА. Я его поправил и раскатил всё на страну, если эти заявки продолжают повторяться, то единственное что я могу допсутить в качестве причины - У них не обновился модуль, и это надо проверить 
2) "Осаго 1.0 ошибка - номер полиса" - непонятная мне ошибка, но часто встречающаяся .... возникает по всей видимости после того как пользователь собирается добавить допущенного к управлению, и модуль у него после заполнения всех полей и финального нажатия на кноку "Добавить" повисает
Примеры: (Характерно тем, что ничего такого принтскрины обычные, ошибок явных нет, но в предупредительном окне одна и та же надпись только "Не указан номер полиса")
1,751,582
1,752,876
3) "Осаго 1.0 ошибка" Многие заявки, что так помечены, как я завметил НЕ ОТНОСЯТСЯ к ОСАГО 1.0, а явно из Модуля ОСАГО 2.0  .... Не лепите приписку "Осаго 1.0 ошибка" массово и без проверки на версию модуля, и желательно пересмотрите те заявки, где группировка "Осаго 1.0 ошибка" уже стоит, откройте, и хотябы переправьте на 2.0, там где в реальности заявка касается ОСАГО 2.0


Описание типичной ошибки:

-----------------------------------------------------------
Некая Новая ошибка с загрузкой договора:

1,756,036
ХХХ
0005101146
21.05.2017

1,755,949
ХХХ
0003659068
14.04.2017

-----------------------------------------------------------
№ заявки:
1,754,691
Пример предупредительного сообщения:
Стаж персоны не может быть отрицательным 
ПРИЧИНА:
Косяк в коде.
РЕШЕНИЕ:
Поправил, если повторяется, то у них не обновился модуль.

-----------------------------------------------------------
№ заявки:
1,753,337
Пример предупредительного сообщения:
Не могу вписать человека,программа запрашивает у клиента придущие
права, а него их нет, т.к. он получил права в 2013году
ПРИЧИНА:
Пользователи не понимают что делать в открывшейся форме
РЕШЕНИЕ:
Если у водителя нет предыдущего Водительского удостоверения (ВУ), то заполняйте поля предыдущего ВУ, как поля текущего имеющегося ВУ.

-----------------------------------------------------------
№ заявки:
1,753,577
1,752,908
Пример предупредительного сообщения:
Дата рождения 4-го допущенного к управлению
Дата рождения 3-го допущенного к управлению


№ заявки:
1,753,437
Пример предупредительного сообщения:
Ошибка в программе: List index out of bounds (-1)
[ДАТА РОЖДЕНИЯ ДОПУЩЕНОГО из заявки 1,753,577 И LIST INDEX   ЯВНО КАК-ТО СВЯЗАНЫ !!!!]

№ заявки:
1,753,560
Пустые поля: "документ удостоверяющий личность" + "тип бланка"

№ заявки:
1,754,183
1,754,692
Пустые поля: "тип бланка"





1,751,582
ПРОБЛЕМА РАСЧЁТА С ИНФОРМАЦИЕЙ О ДОГОВОРЕ



- В случае добавления допущенного к управлению в форме "Информация о допущеном к управлению" добавлено предупредительное сообщение, чтобы пользователи понимали как правильно заполнять поля в случае с предыдущими водительскими удостоверениями и предыдущими ФИО добавляемых водителей.


- Поправлен процесс запроса данных из РСА, согласно новой схеме 1.8

- В форме "Информация о допущеном к управлению" добавлена инструкция как правильно заполнять поля для предыдущих ФИО / ВУ
- Недоступность комбобокса при изменении целей использования ТС в качестве такси исправлена
- Исправлена логика работы поля ИНН у Страхователя


Если у водителя нет предыдущего Водительского удостоверения (ВУ), то заполняйте поля предыдущего ВУ, как поля текущего имеющегося ВУ.

1,752,946



1,753,379

БАНИШЕВ
НИКИТА
ВЫЧЕСЛАВОВИЧ
07.02.1992
78ХС
002977
17.02.2010

БАНИШЕВ
НИКИТА
17.02.2010
17.02.2020
78ХС
002977





<?xml version="1.0" encoding="UTF-8"?>
<rsa:CalcRequest xsi:schemaLocation="com/rsa/dkbm/schema-1.8 CalcRequest.xsd" xmlns:rsa="com/rsa/dkbm/schema-1.8" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<CalcRequestValue>
  <InsurerID>03000000</InsurerID>
  <CalcKBMRequest>
    <DriversRestriction>true</DriversRestriction>
    <DateKBM>2017-10-11T00:00:00</DateKBM>
    <PhysicalPersons>
      <PhysicalPerson>
        <DriverDocument>
          <Serial>78ХС</Serial>
          <Number>002977</Number>
        </DriverDocument>
        <PersonNameBirthHash>БАНИШЕВ НИКИТА ВЫЧЕСЛАВОВИЧ 07.02.1992</PersonNameBirthHash>
      </PhysicalPerson>
    </PhysicalPersons>
  </CalcKBMRequest>
</CalcRequestValue>
</rsa:CalcRequest>




<?xml version="1.0" standalone="yes"?>
<ns2:CalcResponse xmlns:ns2="com/rsa/dkbm/schema-1.8">
	<CalcResponseValue>
		<IdRequestCalc>3635042932</IdRequestCalc>
		<PolicyCalc>
			<PolicyKBM>3</PolicyKBM>
			<PolicyKBMValue>1</PolicyKBMValue>
		</PolicyCalc>
		<CalcKBMResponses>
			<ErrorInfo>
				<Code>3</Code>
				<Message>Обработан успешно</Message>
			</ErrorInfo>
			<CalcKBMResponse>
				<ErrorInfo>
					<Code>801</Code>
					<Message>КБМ не найден, возвращен стандартный класс</Message>
				</ErrorInfo>
				<DriverDocument>
					<Serial>78ХС</Serial>
					<Number>002977</Number>
				</DriverDocument>
				<Hash>БАНИШЕВ НИКИТА ВЫЧЕСЛАВОВИЧ 07.02.1992</Hash>
				<KBMNextLevel>3</KBMNextLevel>
				<KBMValue>1</KBMValue>
				<LossAmount>0</LossAmount>
			</CalcKBMResponse>
		</CalcKBMResponses>
	</CalcResponseValue>
	<ErrorList>
		<ErrorInfo>
			<Code>3</Code>
			<Message>Обработан успешно</Message>
		</ErrorInfo>
	</ErrorList>
</ns2:CalcResponse>












ГОС РЕГ ЗНАК
С365КК03

иДЕНТ нОМЕР
XTA21154074475480
ОБРАБАТЫВАЕТСЯ УСПЕШНО ПО СХЕМЕ 1.8:

<?xml version="1.0" encoding="UTF-8"?>
<rsa:CalcRequest xsi:schemaLocation="com/rsa/dkbm/schema-1.8 CalcRequest.xsd" xmlns:rsa="com/rsa/dkbm/schema-1.8" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<CalcRequestValue>
  <InsurerID>03000000</InsurerID>
  <TicketCarRequest>
    <CarIdent>
      <VIN>XTA21154074475480</VIN>
    </CarIdent>
  </TicketCarRequest>
</CalcRequestValue>
</rsa:CalcRequest>


<?xml version="1.0" standalone="yes"?>
<ns2:CalcResponse xmlns:ns2="com/rsa/dkbm/schema-1.8">
	<CalcResponseValue>
		<IdRequestCalc>3635042288</IdRequestCalc>
		<TicketCarResponse>
			<TicketExisted>true</TicketExisted>
			<Serial>serial</Serial>
			<Number>1234567890</Number>
			<TicketDiagnosticDate>2017-10-12</TicketDiagnosticDate>
			<ErrorList>
				<ErrorInfo>
					<Code>3</Code>
					<Message>Обработан успешно</Message>
				</ErrorInfo>
			</ErrorList>
		</TicketCarResponse>
	</CalcResponseValue>
	<ErrorList>
		<ErrorInfo>
			<Code>3</Code>
			<Message>Обработан успешно</Message>
		</ErrorInfo>
	</ErrorList>
</ns2:CalcResponse>


Сборка ОСАГО 1.0 с поправленными значениями переменных для схемы 1.8

Сборка ОСАГО 1.0 от 11.10.2017 c улучшениями обработки запросов по схеме РСА 1.8



Сборка ОСАГО 1.0 с новыми значениями переменных для схемы 1.8

Сборка ОСАГО 1.0 от 10.10.2017 для перехода на схему РСА 1.8


   OSAGO_AND_FORTUNA = 0 //0 âêë ÔÀ + ÎÑÀÃÎ
  ,OSAGO_ONLY            //1 âêë òîëüêî îñàãî
  ,FORTUNA_ONLY          //2 âêë òîëüêî ôîðòóíà

  
  








БЫЛА ОБНАРУЖЕНА ФУНКИЦЯ которая связана с расчётом к5 / к6


Save_Dogovors_k5_k6(m_api, q_save->FieldByName("calc_id")->AsInteger, di, pi, pm, gridDopush);
void TFReissCalc::SetColorOnCurrentError()


            btnRequest->Caption = "Авторизовать договор (запросить в ЦБД)";
            vg_AutorizationInfo->Properties->Value = "Договор найден в ЦБД";

			
			






//////////////////////

01.01.1999
01.01.2017


6001
0005392
30.12.2016

7200
0500182
10.03.2017






РСА 1.8
В формирование XML добавлено: Значение параметра TrailerKPR - независит более от типа ТС и от типа Физ.лицо/Юр.лицо [0 - нет прицепа / 1 - есть прицеп]
Тестирование запросов на различных ФЛ и ЮЛ запросов согласно новой схеме РСА, для проверки правильности работы.



Я немного не правильно написал их...Там суть была на то чтобы проверить понимания того в какой памяти создаются переменные. В первом случае в с лежал бы адрес одного из элементов стоящих либо до либо после а в зависимости от того куда растет стек(в приведенном примере есть смыл только если стек растет вверх).

Во втором примере, поскольку статические переменные располагаются в другой памяти, в с лежал бы свой собственный адрес(опять же для стека растущего вверх)








produkt->Enabled
produkt->ItemIndex = q->FieldByName("produkt")->AsInteger
produkt->Controls[0]->Enabled









_mops_global_CurVersionKbmRSA_ 1.7
_mops_global_NextVersionKbmRSA_ 1.8

_mops_global_StartDateNextVersionRSA_ 20.09.2017

URLKBMService 
http://arm-apo.ss.rgs.ru/SePeZ_RSA_KBM_Test_18/SePeZ_RSA_KBM.dll
КБМ

_mops_sendosago24_soap_server_address_
http://arm-apo.ss.rgs.ru/Send_OSAGO_Service_Test_18/Send_OSAGO_Service.dll
ОСАГО-24


44 --- апри

фьючер

примитивы синхр

очередь запрпосов
в момент когда вы чтото добавляете в очередь
захватили мьютекс -> положили -> отпустили мьютекс
ЕСЛИ кому-то нужно ждать пока в очереди что-то появится, то он будет
ЛИБО - постоянно захватывать мьютекс и проверять, тем самым отжирая память
либо использовать

Можно через СЕМАФОР: Продюсер - Косьюмер

Можно через: СОБЫТИЕ

Событие = очередь пуста, или норм размеров
Событие = очередь переполнена

Консьюмеры в очереди ждут пока событие не станет свободным.

Что-то перешло из Состояния_1 в Состояние_2

КОНДИШН_ВАРИЭЙБЛ


ФЬЮЧЕР - может пригодиться нам когда
какая-то функция должна что-то вернуть.
- мы гарантируем через фьючер 
.get() - ожидаем, что она нам из потока функции вернёт нам резульатат
- бросает эксепшн, если оно не вернуло - обработка этого процесса через этот эксепшн


Когда из какого-то потока нам нужно вернуть значение 
и как мы можем гарантировать получения результата как его ожидать можно и т.д.

//////////////////////////////////////////////////////////// 5.45

ДЕДЛОКИ:

когда случаются
что можно сделать
как отдебажить

мы можем взять обычный нерекурсивный мьютекс и захватить его повторно второй как-то фукнкцией ниже по стеку - и он залочится

2 объекта:
обоим нужен доступ к 2-ум ресурсам.
им обоим нужно обратиться этим двум ресурсам, но каждый обращается.

2 потока
2 мьютекса
1 поток захватил мутекс 1
2 поток захватил мутекс 2
1 потоку нужен мутекс 2
2 потоку нужен мутекс 1
каждый из потоков будет ждать пока
мутексы освободятся

Каждому потоку нуж

п1 -> м1 (м1 будет захвачен)
п2 -> м2
всё Ок
Далее
п1 -> м2 (будет о)
п2 -> м1

Каждый будет ждать другого 

ПРИМЕР С ФИЛОСОФАМИ ВИЛКАМИ И ЛОЖКАМИ


КАК ЭТО РЕШАЕТСЯ: стандартные пути решения:

0) На уровне СОГЛАШЕНИЙ
 - таймер ожидания (Костыльное решение) если мы по таймеру будем всё откатывать, то придётся ВСЁ откатывать

1) СОГЛАШЕНИЕ ВНУТРИ СИСТЕМЫ ОБ ОЧЕРЕДИ
2 функуции захватывают 2 мьютекса.
При том, что 2 разраба пишут подобные  
Порядок захвата:
1. Сначала захватываем мьютекс базы данных
2. ПОТОМ захватываем мьютекс Сокета
3. ПОТОМ и т.д. мьютекс_N

Если вся система будет действовать по этим шагам и это будет общим соглашением
для всех подсистем, то проблемы дедлока не возникнет

2) ИНДИВИТУАЛЬНОЕ РЕШЕНИЕ



(?) Есть ПРОЦЕСС зависший (на Дедлоке / или просто)
Какие места в коде залочились неправильно почему потоки висят ?
На уровне полльзователя - ПРОСТО ЧТО_ТО ЗАВИСЛО
Как диагностировать место проблемы.

- ЛОГИРОВАНИЕ
- МЫ МОЖЕМ подключиться через ОТЛАДЧИК - СТАРТ ТРЕЙС использовать 
- при условии, что нам будет изместно имя процесса в системе подключаемся отладчиком и смотрим, где он висит, на каком мьютексе и т.д.

//////////////////////////////////////////////////////////// 18

ПРОФИЛИРОВАНИЕ 

- оптимизация кода

Есть процесс который тормозит.
100.000 строк кода
На живом процессе - одна функуция выполняется 90% времени, её надо оптимизировать.

ПРОФИЛИРОВАНИЕ ПАМЯТИ

- Это НЕ УТЕЧКИ
- Это рабочая программа, работающая верно, НО что-то не смотря на это ест жустко много.

//////////////////////////////////////////////////////////// 22

ЗАДАЧКА:

СИНГЛТОН - честный многопоточный было большой
Си++11 - Синглтон Из 11-го стандарта
Си++11 многопоточную безопасную инициализацию статических переменных

static param;
fun_getInstance()
MyClass();

гарантируется корректная инициализация статической переменной при многопоточном выполнении.


ЗАДАЧКА:
написать функцию которая принимает 2 параметра а, б. и возвращает а в степени б. // pow( , ) - только myPow();



	//схема 1.8 //20.09.17// Добавить параметр // DateInsurancePremium (Дата начисления страховой премии) - согласно DiKBM_Operator_guide_add fields_v.2.1.doc
	TDateTime DateCreate = q->FieldByName("pol_zayav_date_zayav")->AsDateTime; //дата заключения
	TDateTime DateActionBeg = q->FieldByName("pol_zayav_srok_strah_s")->AsDateTime; //дата начала действия договора/начала страхования

	// максимальная из даты заключения и даты начала действия договора
	TDateTime MaxDate = int((int)DateCreate > (int)DateActionBeg ? DateCreate : DateActionBeg),
		dt = Date(),
		CurrentStartPeriod(YearOf(dt), MonthOf(dt), 1), //начало текущего периода отчётности
		ValidDateInsurancePremium = MaxDate >= CurrentStartPeriod ? MaxDate : dt; //дата начисления премии
	policy->AddChild("DateInsurancePremium")->Text = q2->FieldByName("pol_zayav_date_prem_nachisl")->AsDateTime.FormatString("yyyy-mm-dd");

	

	
	

	policy->AddChild("DateInsurancePremium")->Text = q2->FieldByName("pol_zayav_date_prem_nachisl")->AsDateTime.FormatString("yyyy-mm-dd");

	
	




История изменения данных субъекта ОСАГО ФЛ:
http://jira-rgs.rgs.ru:8080/browse/APOII-1601
Изменение цели ТС на Такси:
http://jira-rgs.rgs.ru:8080/browse/APOII-1605
ОСАГО1.требования ОД: договор, квитанция, возраст, дата, кем выдан:
http://jira-rgs.rgs.ru:8080/browse/APOII-1572
Удаление "Фортуны-Авто" из модуля ОСАГО 1.0:
http://jira-rgs.rgs.ru:8080/browse/APOII-1593
ПФ - Изменение формы отказов в заключении ОСАГО:
http://jira-rgs.rgs.ru:8080/browse/APOII-1739




32386
XTK21043050050022

1001404185
30-06-2017


start_date = (int)qw->FieldByName("pol_zayav_srok_strah_po")->AsDateTime + 1; //start_date = dt; //Если дата начала страхования
		
Дата заявления
DEZDate
pol_zayav_date_zayav

Дата Переоформления
DatePereoforml

Срок страхования С
DEInsBDate
pol_zayav_srok_strah_s

Срок страхования ПО
DEInsEDate
pol_zayav_srok_strah_po


Использования С
DEBPI1
Использования ПО
DEEPI1



















pol_zayav_date_zayav

        newdog->FieldByName("")->AsDateTime = datezayav; // дата 

		
      qw->FieldByName("")->AsString  = (dt + 1).DateString();
	  start_date
	  
      qw->FieldByName("")->AsString = IncYear(dt).DateString();
	  IncYear(start_date) - 1;
		
		

         newdog->FieldByName("pol_zayav_srok_strah_s")->AsString = old_srok_s;
         newdog->FieldByName("pol_zayav_srok_strah_po")->AsString = old_srok_po;


*Диапазон текущего отчетного периода с первого числа текущего месяца по последнее число текущего месяца.
		 
		 
         newdog->FieldByName("pereoform_old_prem")->AsFloat = newdog->FieldByName("calc_prem")->AsFloat; //премию старую сохраняем отдельно
         newdog->FieldByName("pereoform_date")->AsDateTime = Date(); //дата переоформления, будет на бланках проставляться

		 


  if (SetXML(calc_id)) {
	  
	  
_mops_sendosago24_soap_server_address_


РСА 1.8
http://confluence.rgs.ru:8080/pages/viewpage.action?pageId=141660824
http://confluence.rgs.ru:8080/pages/diffpagesbyversion.action?pageId=136219073&selectedPageVersions=8&selectedPageVersions=7


	//схема 1.8 IsRent (Признак ТС сдается) - согласно ФТ_ДИКБМ от 20.09.2017 - "Удалить логику заполнения параметра "IsRent", параметр "IsRent" удален из схемы"

	//TicketCarResponse.Serial
	
	







378 Х
379
339
6130
278
206 Х



Поновее - 30.06.2017
ЕЕЕ         1001404182


НОРЕКЯН
ВИТЯ
ВОЛОДЯЕВИЧ
18.07.1970
MH
010618
29.11.1989
Класс аварийности 3
Кбм = 1


МАНУКЯН
ГРИГОР
ВОЛОДЯЕВИЧ
17.02.1972
UH
014422
17.03.2003
Класс аварийности 5
Кбм = 0,90












C:\_WORK_RGS\TASKS\03_OSAGO_R\old-15-CORRECT-MainFrame-



СУХАРЕВ
МАКСИМ
МИХАЙЛОВИЧ
04.01.1984
02ВУ
219513
10.10.2006

Класс аварийности 13
Кбм = 0,5

ЕРОФЕЕВ
ВАЛЕРИЙ
ВАСИЛЬЕВИЧ
15.09.1956
0211
371043
11.11.2002

Класс аварийности 4
Кбм = 0,95

КЛЕВАКИН
АНТОН
ИОСИФОВИЧ
07.12.1983
66BK
005125
01.01.2001

Класс аварийности 5
Кбм = 0,90

ФИЛИМОНОВА
АНАСТАСИЯ
ЛЕОНИДОВНА
24.09.1985
66OM
096366
01.01.2008

Класс аварийности 5
Кбм = 0,90


ЕВГРАШИН
ЕВГЕНИЙ
ГЕННАДЬЕВИЧ
12.05.1973
1119
916956
01.01.1998




FillCalcKBMReqTypeToForm

   void testHiddenRSACurrUserCurrVUInfo(TDUForm& f, AnsiString& strAvarClass, AnsiString& strBonusMalus);
   void testHiddenRSACurrUserPrevVUInfo(TDUForm& f, AnsiString& strAvarClass, AnsiString& strBonusMalus);
   void testHiddenRSAPrevUserPrevVUInfo(TDUForm& f, AnsiString& strAvarClass, AnsiString& strBonusMalus);

   
   void FillCalcKBMReqTypeToForm(CalcKBMReqType &kbmreq); //заполняет данными из формы структуру запроса
   //void FillCalcCurrUserCurrVUInfoKBMReqTypeToForm(CalcKBMReqType &kbmreq); //заполняет данными текущих документов из формы структуру запроса
   void FillCalcCurrUserPrevVUInfoKBMReqTypeToForm(CalcKBMReqType &kbmreq); //заполняет данными текущих ФИО и предыдущих ВУ документов из формы структуру запроса
   void FillCalcPrevUserPrevVUInfoKBMReqTypeToForm(CalcKBMReqType &kbmreq); //заполняет данными предыдущих ФИО и предыдущих ВУ документов из формы структуру запроса
   


    all_dop_k_upr = co->GetAllDop();
    co->ClearAllDop();




co->dop_k_upr;






КАСКО Переоформление:
- Добавлены сообщения о неправильно вводимой информации в окне "Добавление допущенного к управлению"
- Расширен список стран в Доп соглашении № 16 о расширении территории страхования


                      + "," + (current->SubItems->Strings[12].IsEmpty()?AnsiString("0"):current->SubItems->Strings[12])
                      + "," + d.PrevFirsName
                      + "," + d.PrevSecondNme
                      + "," + d.PrevLastName
                      + "," + d.PrevDriverLicenseSer
                      + "," + d.PrevDriverLicenseNum
                      + "," + m_api->Internal_Convert_Date_To_SQL(res, d.PrevDocDateStart, false)
                      + "," + m_api->Internal_Convert_Date_To_SQL(res, d.PrevDocDateEnd,   false)
                      + ")" ;
					  
					  
					  

         d.PrevFirsName         = q_dop->FieldByName("prev_i")->AsString;
         d.PrevSecondName       = q_dop->FieldByName("prev_o")->AsString;
         d.PrevLastName         = q_dop->FieldByName("prev_f")->AsString;
         d.PrevDriverLicenseSer = q_dop->FieldByName("prev_prava_s")->AsString;
         d.PrevDriverLicenseNum = q_dop->FieldByName("prev_prava_n")->AsString;
         d.PrevDocDateStart     = q_dop->FieldByName("prev_doc_start")->AsDateTime;
         d.PrevDocDateEnd       = q_dop->FieldByName("prev_doc_end")->AsDateTime;

		 
		 
  3670

  
  








Настоящим Стороны пришли к соглашению изложить последний абзац п.п. 2.15.1 Правил страхования № 171 в редакции «Территория страхования - Российская Федерация, Абхазия, Австрия, Азербайджан, Андорра, Армения, Беларусь, Бельгия, Болгария, Босния и Герцеговина, Ватикан, Великобритания, Венгрия, Германия, Греция, Грузия, Дания, Исландия, Испания, Ирландия, Италия, Казахстан, Кипр, Латвия, Литва, Лихтенштейн, Люксембург, Македония, Мальта, Молдова, Монако, Нидерланды, Норвегия, Польша, Португалия, Румыния, Сан-Марино, Сербия, Словакия, Словения, Финляндия, Франция, Хорватия, Черногория, Чехия, Швейцария, Швеция, Эстония, за исключением территорий вооруженных конфликтов, войн, чрезвычайных положений.

Российская Федерация, Абхазия, Австрия, Азербайджан, Андорра, Армения, Беларусь, Бельгия, Болгария, Босния и Герцеговина, Ватикан, Великобритания, Венгрия, Германия, Греция, Грузия, Дания, Исландия, Испания, Ирландия, Италия, Казахстан, Кипр, Латвия, Литва, Лихтенштейн, Люксембург, Македония, Мальта, Молдова, Монако, Нидерланды, Норвегия, Польша, Португалия, Румыния, Сан-Марино, Сербия, Словакия, Словения, Финляндия, Франция, Хорватия, Черногория, Чехия, Швейцария, Швеция, Эстония

, , , , , , , , 





Грузия, Азербайджан, Абхазия, Армения, Казахстан, Сербия, Черногория, Великобритания, Исландия, Ирландия, Лихтенштейн, Андорра, Ватикан, Кипр, Мальта, Сан-Марино





                      AnsiString predF = current->SubItems->Strings[14];
                      AnsiString predI = current->SubItems->Strings[15];
					  

OSAGO_R_dop_k_upr

         SGDop->Cells[10][n] = qw_dop->FieldByName("prev_f")->AsString;
         SGDop->Cells[11][n] = qw_dop->FieldByName("prev_i")->AsString;
         SGDop->Cells[12][n] = qw_dop->FieldByName("prev_o")->AsString;
         SGDop->Cells[13][n] = qw_dop->FieldByName("prev_prava_s")->AsString;
         SGDop->Cells[14][n] = qw_dop->FieldByName("prev_prava_n")->AsString;
         SGDop->Cells[15][n] = qw_dop->FieldByName("prev_doc_start")->AsString;
         SGDop->Cells[16][n] = qw_dop->FieldByName("prev_doc_end")->AsString;
		 

   f->CBBM->ItemIndex=f->CBBM->Items->IndexOf("3"); //по умолчанию ставим 3-й класс
   
   
   /* //TSInfo

ts_age




//---------------------------------------------------------------------------
MaskDocType::MaskDocType(const int type)


static MaskDocType mask_doc_type(person_mask), mask_vehicle_doc_type(vehicle_mask);



   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag, pm[Tag].doc_seria, pm[Tag].doc_number);

      di->programm_id = q_load->FieldByName("programm_id")->AsInteger;
	  

	  
	  
7200
0500182
10.03.2017





#include "UAddPermitted.h"
#include "mainwinfc.h"
#include "UReissCalc.h"
#include "UADevices.h"



++
#include "UReissCalc.h"

#include "KaskoProxyService.h"
#include "UThreadUFO.h"

#include "UThreadK5.h"

#include "anderrpanel.h"

#include "functions.h"
#include "struct.h"
#include "constants.h"












void __fastcall TFCalc::StrahClick(TObject *Sender)


LVDopUpr->Items->Count + 1

OSAGO_R_MAIN2

		  + ",pol_zayav_strah_doc_date="			+ m_api->Internal_Convert_Date_To_SQL(res,	strInsDocDate, false) + ""
		  + ",pol_zayav_strah_doc_date_end="		+ m_api->Internal_Convert_Date_To_SQL(res,	strInsDocDateEnd, false) + ""
		  + ",pol_zayav_sobstv_doc_date="			+ m_api->Internal_Convert_Date_To_SQL(res,	strOwnDocDate, false) + ""
		  + ",pol_zayav_sobstv_doc_date_end="		+ m_api->Internal_Convert_Date_To_SQL(res,	strOwnDocDateEnd, false) + ""


OSAGO_R_dop_k_upr

         d.doc_start    = q_dop->FieldByName("doc_start")->AsDateTime;
         d.doc_end      = q_dop->FieldByName("doc_end")->AsDateTime;
		 
		 
		 
		 




CascoTariffCoeff



ekaterina_arzamastseva@rgs.ru




tip t;
tip* const p1
const tip* p2
tip const* p3

*p1 = t;
//p1 = &t;

   1 	K1
   28	Kд
   18	Kю
   2	K2
   3	K3
   4	K4
   5	K5
   19	K6
   7	K7
   11	Kр
   9	Kар

   23	Kпр

   24	Kс
   22	Kрс
   26 
		Kб
   0  	Kприск
   14	Kа

   
   if(coeff_base.count(1))  bt_calcstr += " * " + S(di->calc_info.k1)  + "(K1)";
   if(coeff_base.count(28)) bt_calcstr += " * " + S(di->calc_info.kd)  + "(Kд)";
   if(coeff_base.count(18)) bt_calcstr += " * " + S(di->calc_info.kyu) + "(Kю)";
   if(coeff_base.count(2))  bt_calcstr += " * " + S(di->calc_info.k2)  + "(K2)";
   if(coeff_base.count(3))  bt_calcstr += " * " + S(di->calc_info.k3)  + "(K3)";
   if(coeff_base.count(4))  bt_calcstr += " * " + S(di->calc_info.k4)  + "(K4)";
   if(coeff_base.count(5))  bt_calcstr += " * " + S(di->calc_info.k5)  + "(K5)";
   if(coeff_base.count(19)) bt_calcstr += " * " + S(di->calc_info.k6)  + "(K6)";
   if(coeff_base.count(7))  bt_calcstr += " * " + S(di->calc_info.k7)  + "(K7)";
   if(coeff_base.count(11)) bt_calcstr += " * " + S(di->calc_info.kr)  + "(Kр)";
   if(coeff_base.count(9))  bt_calcstr += " * " + S(di->calc_info.kar) + "(Kар)";
   if(coeff_base.count(23)) bt_calcstr += " * " + S(di->calc_info.kpr) + "(Kпр)";
   if(coeff_base.count(24)) bt_calcstr += " * " + S(di->calc_info.ks)  + "(Kс)";
   if(coeff_base.count(22)) bt_calcstr += " * " + S(di->calc_info.krs) + "(Kрс)";
   if(coeff_base.count(26) && di->bank_id > 0)
                            bt_calcstr += " * " + S(di->calc_info.kb)  + "(Kб)";
   if(di->bank_id > 0)      bt_calcstr += " * " + S(di->calc_info.kfr) + "(Kприск)";
   if(coeff_base.count(14)) bt_calcstr += " * " + S(di->calc_info.ka)  + "(Kа)";
   
   


СТАРЫЙ ТЕКСТ

Страхователь, Застрахованное лицо, Выгодоприобретатель
Страхователь - дееспособное физическое лицо или юридическое лицо, заключившее со Страховщиком Договор страхования.
Застрахованное лицо - физическое лицо в возрасте от 1 года до 74 лет, названное в Договоре страхования как застрахованное лицо, в пользу которого заключен Договор страхования, если в нем не назначено в качестве Выгодоприобретателя другое лицо.
Выгодоприобретатель - любое физическое или юридическое лицо, назначенное в Договоре страхования с письменного согласия Застрахованного лица в качестве получателя страховой выплаты в случае смерти Застрахованного лица.
На страхование не принимаются: - инвалиды I, II группы; дети, которым установлена категория «ребенок-инвалид»; -  лица со стойкими нервными или психическими расстройствами, состоящие на учете в психоневрологическом или наркологическом диспансерах;  - лица, находящиеся под следствием или осужденные к лишению свободы.
Страховыми случаями при условии того, что указанные события: а) не наступили в результате совершения Застрахованным лицом в возрасте 14 лет и старше умышленного преступления; б) не произошли с лицами, которые на момент заключения Договора страхования относились к категориям лиц, указанным в разделе «На страхование не принимаются» настоящих Условий; в) не наступили в результате управления Застрахованным лицом транспортным средством без права на управление транспортным средством данной категории или передачи Застрахованным лицом управления транспортным средством лицу, не имевшему права на управление транспортным средством данной категории; г) не наступили в результате управления Застрахованным лицом в состоянии алкогольного или иного опьянения транспортным средством, а также в результате передачи управления транспортным средством лицу, находившемуся в состоянии алкогольного, наркотического или токсического опьянения; д) не наступили в результате самоубийства (покушения на самоубийство) Застрахованного лица в возрасте 14 лет и старше, если Договор страхования действовал менее двух лет, за исключением тех случаев, когда оно было доведено до такого состояния противоправными действиями третьих лиц; е) не наступили в результате умышленного причинения Застрахованным лицом в возрасте 14 лет и старше себе телесных повреждений; ж) не наступили в результате несчастного случая, наступившего с Застрахованным лицом в местах лишения свободы; з) не наступили в результате отравления алкоголем (веществами, содержащими алкоголь), а также наркотическими веществами Застрахованного лица в возрасте 14 лет и старше, если компетентными органами не установлен факт их насильственного введения, ошибочного либо вынужденного употребления; и) не наступили в результате заболевания СПИДом; к) не наступили в результате профессиональных занятий Застрахованным лицом опасными видами спорта (авто- и мотоспорт, прыжки с парашютом, контактные единоборства, альпинизм, горный и водный туризм, подводное плавание и т.п.), являются: травма, явившаяся следствием несчастного случая, случайное острое отравление химическими веществами, произошедшие в результате ДТП. Указанные события признаются страховыми случаями, если они произошли в период действия страхования и сопровождались причинением вреда здоровью Застрахованного лица, предусмотренного Таблицей размеров страховых выплат № 3; инвалидность I, II, III группы или категория «ребенок-инвалид», первично установленная Застрахованному лицу вследствие травмы, явившейся следствием несчастного случая, или случайного острого отравления химическими веществами, полученной или развившегося в результате ДТП в период действия страхования и послуживших причиной установления инвалидности в период действия страхования; смерть Застрахованного лица, вследствие травмы, явившейся следствием несчастного случая, или случайного острого отравления химическими веществами, произошедших в результате ДТП в период действия страхования и послуживших причиной смерти в период действия страхования, а также смерть, наступившая в период действия страхования от удушения вследствие случайного попадания в дыхательные пути инородного тела, утопления, переохлаждения организма, произошедших в результате ДТП.
Размер страховой суммы: Страховая сумма устанавливается в фиксированном размере (см. лицевую сторону настоящего полиса). В отношении Застрахованного лица по одним и тем же страховым рискам на совпадающий в части или полностью период страхования может быть заключен только один Договор страхования/страховой полис. Каждый последующий заключенный Договор страхования с одним или несколькими вышеуказанными условиями страхования считается сделкой, совершенной под влиянием заблуждения, имеющего существенное значение (ст. 178 ГК РФ), в том числе для определения вероятности наступления страхового случая и размера возможных убытков от его наступления и признается недействительным в соответствии с действующим законодательством с момента его заключения.
Основания для отказа в страховой выплате: Страховщик освобождается от обязательства произвести страховую выплату в том случае, если события, предусмотренные Договором страхования, наступили в результате: воздействия ядерного взрыва, радиации или радиоактивного заражения; военных действий, а также маневров или иных военных мероприятий; гражданской войны, народных волнений всякого рода или забастовок; умысла Страхователя, Выгодоприобретателя или Застрахованного лица.

Страховщик отказывает в страховой выплате при наличии хотя бы одного из следующих обстоятельств: если Договор страхования является недействительным в соответствии с законодательством Российской Федерации; если страховой случай в действительности не имел места или не подтвержден соответствующими документами; если наступившее событие не отвечает признакам страхового случая, предусмотренного Договором страхования; если наступившее событие исключено из страхования (в соответствии с условиями настоящих Правил и/или Договора страхования); если имеются основания для освобождения Страховщика от страховой выплаты, предусмотренные законодательством Российской Федерации; если не выполнены какие-либо условия страховой выплаты, предусмотренные разделом «Порядок представления документов для страховой выплаты» настоящих Условий.
При наступлении страхового случая с Застрахованным лицом размеры страховых выплат определяются в процентах от страховой суммы: в связи с травмой, случайным острым отравлением - в соответствии с Таблицей размеров страховых выплат № 3; при установлении инвалидности: I группы - 100%; II группы - 70%; III группы - 40%; категории «ребенок-инвалид» - 30%; в случае смерти - 100%.
Общая сумма выплат за один или несколько страховых случаев, предусмотренных в Договоре страхования и происшедших с Застрахованным лицом в период действия страхования, не может превышать установленной для него страховой суммы.
Порядок представления документов для страховой выплаты: для решения вопроса о страховой выплате Страховщику представляются следующие документы:
- письменное заявление о страховой выплате, страховой полис, квитанция на получение страховой премии (если она уплачивалась наличными деньгами), документ, удостоверяющий личность;
- документы компетентных органов, свидетельствующие о наступлении в период действия страхования определенного случая, имеющего признаки страхового, об обстоятельствах и характере его наступления (справка ГИБДД или иной документ судебно-следственных органов о подтверждении факта дорожно-транспортного происшествия, в результате которого был причинен вред жизни и здоровью Застрахованного лица), документы компетентных органов, содержащие полный диагноз, поставленный Застрахованному лицу, сведения о сроках лечения, лечебных и диагностических мероприятиях;
- справка органа медико-социальной экспертизы об установлении группы (категории) инвалидности - представляется в случае установления инвалидности;
- копия свидетельства о смерти Застрахованного лица, заверенная в установленном законодательством порядке, медицинский документ (или его копия, заверенная в установленном законодательством порядке) с указанием причины смерти Застрахованного лица (выписка из медицинского свидетельства о смерти и т.п.) - представляется в случае смерти Застрахованного лица;
- копия Свидетельства о праве на наследство, заверенная в установленном законодательством порядке - представляется только наследником или наследниками.
В случае если представленные документы не содержат информации, необходимой для принятия решения о страховой выплате (либо определения ее размера), а также содержат противоречивую информацию, Страховщик имеет право по согласованию со Страхователем (Застрахованным, Выгодоприобретателем) запросить дополнительные документы, необходимые для принятия окончательного обоснованного решения, а также проводить экспертизу представленных документов, самостоятельно выяснять причины и обстоятельства страхового случая.
В случае отказа Страхователя (Застрахованного, Выгодоприобретателя) от предоставления дополнительно запрашиваемых документов, Страховщик имеет право произвести страховую выплату в неоспариваемой части, подтвержденной предоставленными на момент выплаты документами, либо отказать в страховой выплате.
Решение о страховой выплате или об отказе в выплате принимается Страховщиком в течение 10 рабочих дней со дня получения всех необходимых документов. Решение о страховой выплате оформляется актом о страховом случае, в случае отказа в страховой выплате Страховщик письменно сообщает об этом заявителю. Страховая выплата производится Страховщиком в течение 10 рабочих дней с момента принятия решения о страховой выплате, путем перечисления во вклад на имя заявителя в отделении банка, переводом по почте или наличными деньгами - по желанию получателя, а также иным способом - по соглашению сторон. Днем выплаты считается дата списания средств со счета Страховщика в банке, оформление почтового перевода или выдачи наличных денег. Перевод подлежащих выплате сумм по почте, телеграфу или на счет получателя осуществляется за счет его средств.
Порядок разрешения споров: споры по договору страхования между Страховщиком и Страхователем разрешаются путем переговоров, а при недостижении согласия - в порядке, предусмотренном законодательством Российской Федерации.
Во всем остальном, что не предусмотрено настоящим Договором, действует положение Правил индивидуального страхования от несчастных случаев № 26 в редакции, действующей на момент заключения Договора страхования. При решении спорных вопросов положения Договора страхования имеют преимущественную силу по отношению к Правилам.


НОВЫЙ ТЕКСТ

Страхователь, Застрахованное лицо, Выгодоприобретатель
Страхователь – дееспособное физическое лицо или юридическое лицо, заключившее со Страховщиком Договор страхования.
Застрахованное лицо – физическое лицо в возрасте от 1 года, названное в Договоре страхования как застрахованное лицо, в пользу которого заключен Договор страхования, если в нем не назначено в качестве Выгодоприобретателя другое лицо.
Выгодоприобретатель – любое физическое или юридическое лицо, назначенное в Договоре страхования с письменного согласия Застрахованного лица в качестве получателя страховой выплаты в случае смерти Застрахованного лица.
Страховыми случаями при условии того, что указанные события: а) не наступили в результате совершения Застрахованным лицом в возрасте 14 лет и старше умышленного преступления; б) не наступили в результате управления Застрахованным лицом транспортным средством без права на управление транспортным средством данной категории или передачи Застрахованным лицом управления транспортным средством лицу, не имевшему права на управление транспортным средством данной категории; в) не наступили в результате управления Застрахованным лицом в состоянии алкогольного или иного опьянения транспортным средством, а также в результате передачи управления транспортным средством лицу, находившемуся в состоянии алкогольного, наркотического или токсического опьянения; г) не наступили в результате самоубийства (покушения на самоубийство) Застрахованного лица в возрасте 14 лет и старше, если Договор страхования действовал менее двух лет, за исключением тех случаев, когда оно было доведено до такого состояния противоправными действиями третьих лиц; д) не наступили в результате умышленного причинения Застрахованным лицом в возрасте 14 лет и старше себе телесных повреждений; е) не наступили в результате отравления алкоголем (веществами, содержащими алкоголь), а также наркотическими веществами Застрахованного лица в возрасте 14 лет и старше, если компетентными органами не установлен факт их насильственного введения, ошибочного либо вынужденного употребления; ж) не наступили в результате заболевания СПИДом, послужившим причиной наступления заявленного события в период действия договора по заболеванию СПИДом, диагноз которого установлен ранее заключения Договора страхования; з) не наступили в результате профессиональных занятий Застрахованным лицом опасными видами спорта (альпинизм, горный туризм, скалолазание, спелеотуризм, парашютный спорт, парапланеризм, дельтапланеризм, бейсджампинг, банджиджампинг, контактные единоборства, авто- и мотоспорт, стритрейсинг, велосипедный мотокросс, верховая езда, футбол, хоккей, лыжный спорт, санный спорт, сноуборд, воднолыжный спорт, водный туризм, рафтинг, каякинг, виндсерфинг, кайтсерфинг, вейкбординг, дайвинг, фридайвинг), являются:  травма, явившаяся следствием несчастного случая, случайное острое отравление химическими веществами , произошедшие в результате ДТП. Указанные события признаются страховыми случаями, если они произошли в период действия страхования и сопровождались причинением вреда здоровью Застрахованного лица, предусмотренного Таблицей размеров страховых выплат No 3; инвалидность I, II, III группы или категория «ребенок-инвалид», первично установленная Застрахованному лицу вследствие травмы, явившейся следствием несчастного случая, или случайного острого отравления химическими веществами, полученной или развившегося в результате ДТП в период действия страхования и послуживших причиной установления инвалидности в период действия страхования; смерть Застрахованного лица, вследствие травмы, явившейся следствием несчастного случая, или случайного острого отравления химическими веществами, произошедших в результате ДТП в период действия страхования и послуживших причиной смерти в период действия страхования, а также смерть, наступившая в период действия страхования от удушения вследствие случайного попадания в дыхательные пути инородного тела, утопления, переохлаждения организма, произошедших в результате ДТП.
Размер страховой суммы:  Страховая сумма устанавливается в фиксированном размере (см. лицевую сторону настоящего полиса). 
Основания для отказа в страховой выплате: Страховщик освобождается от обязательства произвести страховую выплату в том случае, если события, предусмотренные Договором страхования, наступили в результате: воздействия ядерного взрыва, радиации или радиоактивного заражения; военных действий, а также маневров или иных военных мероприятий; гражданской войны, народных волнений всякого рода или забастовок; умысла Страхователя, Выгодоприобретателя или Застрахованного лица.
У Страховщика не возникает правовых оснований/обязанности по выплате возмещения при наличии хотя бы одного из следующих обстоятельств: если Договор страхования является недействительным в соответствии с законодательством Российской Федерации; в части выплаты, которая не подтверждена документально и отсутствие документов по факту причинения вреда здоровью Застрахованного лица/его смерти в результате несчастного случая или болезни, которой не позволяет Страховщику установить соответствующий размер убытков; если страховой случай в действительности не имел места или не подтвержден соответствующими документами; если наступившее событие не отвечает признакам страхового случая, предусмотренного Правилами No26 и/или настоящим Договором страхования; если наступившее событие исключено из страхования (в соответствии с условиями Правил No26  и/или настоящего Договора страхования); если имеются основания для освобождения Страховщика от страховой выплаты, предусмотренные законодательством Российской Федерации; если Страхователь в одностороннем порядке отказался от исполнения обязательств и/или изменил условия Правил No26 и/или заключенного договора страхования; если не выполнены какие-либо условия страховой выплаты, предусмотренные разделом «Порядок представления документов для страховой выплаты» настоящих Условий и такое неисполнение сказалось на обязанности Страховщика выплатить страховое возмещение.
При наступлении страхового случая с Застрахованным лицом размеры страховых выплат определяются в процентах от страховой суммы: в связи с травмой, случайным острым отравлением – в соответствии с Таблицей размеров страховых выплат No 3; при установлении инвалидности: I группы – 100%; II группы – 70%; III группы – 40%; категории «ребенок-инвалид» – 30%; в случае смерти – 100%.
Общая сумма выплат за один или несколько страховых случаев, предусмотренных в Договоре страхования и происшедших с Застрахованным лицом в период действия страхования, не может превышать установленной для него страховой суммы.
Порядок представления документов для страховой выплаты: для решения вопроса о страховой выплате Страховщику представляются следующие документы:
Во всех случаях:
- письменное заявление о страховой выплате; 
- страховой полис, квитанция на получение страховой премии, неотъемлемые приложения к страховому полису в случаях предусмотренных настоящими условиями;
- документ, удостоверяющий личность;
- документы компетентных органов, свидетельствующие о наступлении в период действия страхования ДТП и подтверждающие факт причинения вреда здоровью или жизни Застрахованного лица (справка о ДТП и Приложение к справке о ДТП о наличии Пострадавших по форме, предусмотренной законодательством РФ, Постановление (Определение) следственных органов, Решение, Определение или Приговор суда (если обстоятельства события, послужившего причиной наступления заявленного события с Застрахованным лицом, подлежат расследованию в соответствие с законодательством РФ));
- медицинские документы, свидетельствующие о наступлении в период действия страхования с  Застрахованным лицом события, имеющего признаки страхового случая, о характере его наступления, содержащие полный диагноз, сведения о сроках лечения, лечебных и диагностических мероприятиях (при амбулаторном лечении – выписка из амбулаторной карты из медицинского учреждения за весь срок наблюдения (лечения), при стационарном лечении – выписной эпикриз по стационарному лечению из медицинского учреждения за весь срок наблюдения (лечения)/выписка из истории болезни);
- Акт о спортивной травме, Протокол соревнований (при необходимости, когда должна быть установлена связь заявленного события с участием Застрахованного лица в соревнованиях и тренировке).
Дополнительно при травмах Застрахованного лица, сопровождающихся костными повреждениями (вывихи, переломы и т.д.):
- рентгеновские снимки до лечения и в конце лечения
- заключение рентгенолога по результатам проведения рентгенографии.
Дополнительно в случае установления инвалидности Застрахованному лицу:
- справка органа медико-социальной экспертизы об установлении группы (категории) инвалидности;
- направление на медико-социальную экспертизу организацией, оказывающей лечебно-профилактическую помощь, Протокол проведения медико-социальной экспертизы по формам, предусмотренным законодательством РФ.
Дополнительно при смерти Застрахованного лица:
- свидетельство о смерти Застрахованного лица из органов записи актов гражданского состояния;
- медицинский документ с указанием причины смерти Застрахованного лица (медицинское свидетельство о смерти, справка о смерти, иные документы в соответствии с законодательством РФ);
- свидетельства о праве на наследство (представляется при смерти только наследником или наследниками).
Дополнительно если Застрахованное лицо являлось водителем:
- водительское удостоверение, иной документ, подтверждающий право управления соответствующей категории транспортного средства;
- Акт освидетельствования на состояние алкогольного опьянения, Акт медицинского освидетельствования, либо Заключение (Акт) судебно-медицинской экспертизы (исследования).
Вышеуказанные документы предоставляются Страховщику в оригинале или копиях, оформленных надлежащим образом (заверенные нотариально или заверенные в установленном законодательством РФ порядке (подписью лиц, штампом и печатью учреждения, выдавших данный документ).
В случае если представленные документы не содержат информации, указанной в п.9.2., 9.5. Правил No26 и они не позволяют Страховщику установить соответствующий размер убытка, а также содержат противоречивую информацию, Страховщик имеет право по согласованию со Страхователем (Застрахованным, Выгодоприобретателем) запросить дополнительные документы, необходимые для принятия окончательного обоснованного решения, а также проводить экспертизу представленных документов, самостоятельно выяснять причины и обстоятельства страхового случая.
У Страховщика не возникает правовых оснований/обязанностей по выплате возмещения в части выплаты, которая не подтверждена документально и отсутствие документов по факту причинения вреда здоровью Застрахованного лица/его смерти в результате несчастного случая или болезни, которой не позволяет Страховщику установить соответствующий размер убытков.
Решение о страховой выплате или об отказе в выплате принимается Страховщиком в течение 10 рабочих дней со дня получения всех необходимых документов. Решение о страховой выплате оформляется актом о 
страховом случае, в случае отказа в страховой выплате Страховщик письменно сообщает об этом заявителю. Страховая выплата производится Страховщиком в течение 10 рабочих дней с момента принятия решения о страховой выплате, путем перечисления во вклад на имя заявителя в отделении банка, переводом по почте или наличными деньгами – по желанию получателя, а также иным способом – по соглашению сторон. 
Днем выплаты считается дата списания средств со счета Страховщика в банке, оформление почтового перевода или выдачи наличных денег. 
Перевод подлежащих выплате сумм по почте, телеграфу или на счет получателя осуществляется за счет его средств.
Порядок разрешения споров: споры по договору страхования между Страховщиком и Страхователем разрешаются путем переговоров, а при недостижении согласия – в порядке, предусмотренном законодательством Российской Федерации.
Во всем остальном, что не предусмотрено настоящим Договором, действует положение Правил индивидуального страхования от несчастных случаев No 26 в редакции, действующей на момент заключения Договора страхования. При решении спорных вопросов положения Договора страхования имеют преимущественную силу по отношению к Правилам.





Страхователь, Застрахованное лицо, Выгодоприобретатель
Страхователь – дееспособное физическое лицо или юридическое лицо, заключившее со Страховщиком Договор страхования.
Застрахованное лицо – физическое лицо в возрасте от 1 года, названное в 
Договоре страхования как застрахованное лицо, в пользу которого заклю-
чен Договор страхования, если в нем не назначено в качестве Выгодопри-
обретателя другое лицо.
Выгодоприобретатель – любое физическое или юридическое лицо, назна-
ченное в Договоре страхования с письменного согласия Застрахованного 
лица в качестве получателя страховой выплаты в случае смерти Застрахо-
ванного лица.
Страховыми случаями
 при условии того, что указанные события: а) не 
наступили в результате совершения Застрахованным лицом в возрасте 14 
лет и старше умышленного преступления; б) не наступили в результате 
управления Застрахованным лицом транспортным средством без права на 
управление транспортным средством данной категории или передачи 
Застрахованным лицом управления транспортным средством лицу, не 
имевшему права на управление транспортным средством данной катего-
рии; в) не наступили в результате управления Застрахованным лицом в 
состоянии алкогольного или иного опьянения транспортным средством, а 
также в результате передачи управления транспортным средством лицу, 
находившемуся в состоянии алкогольного, наркотического или токсиче-
ского опьянения; г) не наступили в результате самоубийства (покушения 
на самоубийство) Застрахованного лица в возрасте 14 лет и старше, если 
Договор страхования действовал менее двух лет, за исключением тех 
случаев, когда оно было доведено до такого состояния противоправными 
действиями третьих лиц; д) не наступили в результате умышленного 
причинения Застрахованным лицом в возрасте 14 лет и старше себе 
телесных повреждений; е) не наступили в результате отравления алкого-
лем (веществами, содержащими алкоголь), а также наркотическими 
веществами Застрахованного лица в возрасте 14 лет и старше, если 
компетентными органами не установлен факт их насильственного введе-
ния, ошибочного либо вынужденного употребления; ж) не наступили в 
результате заболевания СПИДом, послужившим причиной наступления 
заявленного события в период действия договора по заболеванию 
СПИДом, диагноз которого установлен ранее заключения Договора 
страхования; з) не наступили в результате профессиональных занятий 
Застрахованным лицом опасными видами спорта (альпинизм, горный 
туризм, скалолазание, спелеотуризм, парашютный спорт, параплане-
ризм, дельтапланеризм, бейсджампинг, банджиджампинг, контактные 
единоборства, авто- и мотоспорт, стритрейсинг, велосипедный 
мотокросс, верховая езда, футбол, хоккей, лыжный спорт, санный спорт, 
сноуборд, воднолыжный спорт, водный туризм, рафтинг, каякинг, 
виндсерфинг, кайтсерфинг, вейкбординг, дайвинг, фридайвинг), являют-
ся: 
травма
, явившаяся следствием несчастного случая, 
случайное 
острое отравление химическими веществами
, произошедшие в 
результате ДТП. Указанные события признаются страховыми случаями, 
если они произошли в период действия страхования и сопровождались 
причинением вреда здоровью Застрахованного лица, предусмотренного 
Таблицей размеров страховых выплат No 3; 
инвалидность I, II, III группы 
или категория «ребенок-инвалид»
, первично установленная Застрахо-
ванному лицу вследствие травмы, явившейся следствием несчастного 
случая, или случайного острого отравления химическими веществами, 
полученной или развившегося в результате ДТП в период действия 
страхования и послуживших причиной установления инвалидности в 
период действия страхования; 
смерть Застрахованного лица
, вслед-
ствие травмы, явившейся следствием несчастного случая, или случайного 
острого отравления химическими веществами, произошедших в результа-
те ДТП в период действия страхования и послуживших причиной смерти в 
период действия страхования, а также смерть, наступившая в период 
действия страхования от удушения вследствие случайного попадания в 
дыхательные пути инородного тела, утопления, переохлаждения организ-
ма, произошедших в результате ДТП.
Размер страховой суммы:
 Страховая сумма устанавливается в фикси-
рованном размере (см. лицевую сторону настоящего полиса). 
Основания для отказа в страховой выплате:
 Страховщик освобождает-
ся от обязательства произвести страховую выплату в том случае, если 
события, предусмотренные Договором страхования, наступили в результа-
те: воздействия ядерного взрыва, радиации или радиоактивного зараже-
ния; военных действий, а также маневров или иных военных мероприятий; 
гражданской войны, народных волнений всякого рода или забастовок; 
умысла Страхователя, Выгодоприобретателя или Застрахованного лица.
У Страховщика не возникает правовых оснований/обязанности по 
выплате возмещения при наличии хотя бы одного из следующих 
обстоятельств:
 если Договор страхования является недействительным в 
соответствии с законодательством Российской Федерации; в части 
выплаты, которая не подтверждена документально и отсутствие докумен-
тов по факту причинения вреда здоровью Застрахованного лица/его 
смерти в результате несчастного случая или болезни, которой не позволя-
ет Страховщику установить соответствующий размер убытков; если 
страховой случай в действительности не имел места или не подтвержден 
соответствующими документами; если наступившее событие не отвечает 
признакам страхового случая, предусмотренного Правилами No26 и/или 
настоящим Договором страхования; если наступившее событие исключе-
но из страхования (в соответствии с условиями Правил No26  и/или настоя-
щего Договора страхования); если имеются основания для освобождения 
Страховщика от страховой выплаты, предусмотренные законодатель-
ством Российской Федерации; если Страхователь в одностороннем 
порядке отказался от исполнения обязательств и/или изменил условия 
Правил No26 и/или заключенного договора страхования; если не выполне-
ны какие-либо условия страховой выплаты, предусмотренные разделом 
«Порядок представления документов для страховой выплаты» настоящих 
Условий и такое неисполнение сказалось на обязанности Страховщика 
выплатить страховое возмещение.
При наступлении страхового случая с Застрахованным лицом 
размеры страховых выплат определяются в процентах от страховой 
суммы:
 в связи с травмой, случайным острым отравлением – в соответ-
ствии с Таблицей размеров страховых выплат No 3; при установлении 
инвалидности: I группы – 100%; II группы – 70%; III группы – 40%; категории 
«ребенок-инвалид» – 30%; в случае смерти – 100%.
Общая сумма выплат за один или несколько страховых случаев, 
предусмотренных в Договоре страхования и происшедших с Застра-






хованным лицом в период действия страхования, не может превы-
шать установленной для него страховой суммы.
Порядок представления документов для страховой выплаты:
 для 
решения вопроса о страховой выплате Страховщику представляются 
следующие документы:
Во всех случаях:
- письменное заявление о страховой выплате; 
- страховой полис, квитанция на получение страховой премии, неотъемле-
мые приложения к страховому полису в случаях предусмотренных настоя-
щими условиями;
- документ, удостоверяющий личность;
- документы компетентных органов, свидетельствующие о наступлении в 
период действия страхования ДТП и подтверждающие факт причинения 
вреда здоровью или жизни Застрахованного лица (справка о ДТП и Прило-
жение к справке о ДТП о наличии Пострадавших по форме, предусмотрен-
ной законодательством РФ, Постановление (Определение) следственных 
органов, Решение, Определение или Приговор суда (если обстоятельства 
события, послужившего причиной наступления заявленного события с 
Застрахованным лицом, подлежат расследованию в соответствие с 
законодательством РФ));
- медицинские документы, свидетельствующие о наступлении в период 
действия страхования с Застрахованным лицом события, имеющего 
признаки страхового случая, о характере его наступления, содержащие 
полный диагноз, сведения о сроках лечения, лечебных и диагностических 
мероприятиях (при амбулаторном лечении – выписка из амбулаторной 
карты из медицинского учреждения за весь срок наблюдения (лечения), 
при стационарном лечении – выписной эпикриз по стационарному 
лечению из медицинского учреждения за весь срок наблюдения (лече-
ния)/выписка из истории болезни);
- Акт о спортивной травме, Протокол соревнований (при необходимости, 
когда должна быть установлена связь заявленного события с участием 
Застрахованного лица в соревнованиях и тренировке).
Дополнительно при травмах Застрахованного лица, сопровождающихся 
костными повреждениями (вывихи, переломы и т.д.):
- рентгеновские снимки до лечения и в конце лечения
- заключение рентгенолога по результатам проведения рентгенографии.
Дополнительно в случае установления инвалидности Застрахованному 
лицу:
- справка органа медико-социальной экспертизы об установлении группы 
(категории) инвалидности;
- направление на медико-социальную экспертизу организацией, оказыва-
ющей лечебно-профилактическую помощь, Протокол проведения 
медико-социальной экспертизы по формам, предусмотренным законода-
тельством РФ.
Дополнительно при смерти Застрахованного лица:
- свидетельство о смерти Застрахованного лица из органов записи актов 
гражданского состояния;
- медицинский документ с указанием причины смерти Застрахованного 
лица (медицинское свидетельство о смерти, справка о смерти, иные 
документы в соответствии с законодательством РФ);
- свидетельства о праве на наследство (представляется при смерти только 
наследником или наследниками).
Дополнительно если Застрахованное лицо являлось водителем:
- водительское удостоверение, иной документ, подтверждающий право 
управления соответствующей категории транспортного средства;
- Акт освидетельствования на состояние алкогольного опьянения, Акт 
медицинского освидетельствования, либо Заключение (Акт) судебно-
медицинской экспертизы (исследования).
Вышеуказанные документы предоставляются Страховщику в оригинале 
или копиях, оформленных надлежащим образом (заверенные нотариаль-
но или заверенные в установленном законодательством РФ порядке 
(подписью лиц, штампом и печатью учреждения, выдавших данный 
документ).
В случае если представленные документы не содержат информации, 
указанной в п.9.2., 9.5. Правил No26 и они не позволяют Страховщику 
установить соответствующий размер убытка, а также содержат противо-
речивую информацию, Страховщик имеет право по согласованию со 
Страхователем (Застрахованным, Выгодоприобретателем) запросить 
дополнительные документы, необходимые для принятия окончательного 
обоснованного решения, а также проводить экспертизу представленных 
документов, самостоятельно выяснять причины и обстоятельства страхо-
вого случая.
У Страховщика не возникает правовых оснований/обязанностей по выпла-
те возмещения в части выплаты, которая не подтверждена документально 
и отсутствие документов по факту причинения вреда здоровью Застрахо-
ванного лица/его смерти в результате несчастного случая или болезни, 
которой не позволяет Страховщику установить соответствующий размер 
убытков.
Решение о страховой выплате или об отказе в выплате принимается 
Страховщиком в течение 10 рабочих дней со дня получения всех необходи-
мых документов. Решение о страховой выплате оформляется актом о 
страховом случае, в случае отказа в страховой выплате Страховщик 
письменно сообщает об этом заявителю. Страховая выплата производит-
ся Страховщиком в течение 10 рабочих дней с момента принятия решения 
о страховой выплате, путем перечисления во вклад на имя заявителя в 
отделении банка, переводом по почте или наличными деньгами – по 
желанию получателя, а также иным способом – по соглашению сторон. 
Днем выплаты считается дата списания средств со счета Страховщика в 
банке, оформление почтового перевода или выдачи наличных денег. 
Перевод подлежащих выплате сумм по почте, телеграфу или на счет 
получателя осуществляется за счет его средств.
Порядок разрешения споров:
 споры по договору страхования между 
Страховщиком и Страхователем разрешаются путем переговоров, а при 
недостижении согласия – в порядке, предусмотренном законодатель-
ством Российской Федерации.
Во всем остальном, что не предусмотрено настоящим Договором, 
действует положение Правил индивидуального страхования от несчаст-
ных случаев No 26 в редакции, действующей на момент заключения 
Договора страхования. При решении спорных вопросов положения 
Договора страхования имеют преимущественную силу по отношению к 
Правилам.


Уменьшить   Увеличить 


1ЮЛ Полис Фортуна Авто (черновик)


TOP WAS:
3,52

3,24
3,30

3,21
3,21
3,21





0,42
2,53
5,20


$001E1B9A


Настоящим Страхователь подтверждает своё согласие на обработку Страховщиком, ЗАО "АВТОАССИСТАНС", 115088, Москва, 2-й Южнопортовый проезд, д. 18, стр. 2, ПАО "РГС Банк", 107078, г. Москва, ул. Мясницкая д. 43, стр. 2 в порядке, установленном Правилами страхования, перечисленных в настоящем Договоре и в п.

В случае досрочного отказа Страхователя от настоящего Договора страхования в течение 5-ти рабочих дней с момента его заключения уплаченная Страховщику страховая премия подлежит возврату в полном размере в срок не более 10-ти рабочих дней с момента расторжения. Настоящим Страхователь подтверждает свое согласие на обработку Страховщиком, Российским Автомобильным Товариществом (ЗАО «АВТОАССИСТАНС», 115088, Москва, 2-й Южнопортовый проезд, д. 18, стр. 2), Росгосстрах-банком (ПАО «РГС Банк», 107078,г. Москва, ул. Мясницкая д. 43, стр. 2) в порядке, установленном Правилами страхования, перечисленных в настоящем Договоре и в п.8.10. Правил страхования, персональных данных Страхователя и Застрахованного лица для осуществления страхования по Договору страхования, а также оказания иных услуг в рамках настоящего Договора или любого иного, заключенного со Страховщиком, ЗАО «АВТОАССИСТАНС» или ПАО «РГС Банк», а также в целях проверки качества оказания страховых и иных услуг, урегулирования убытков, администрирования Договора, информирования Страхователя и Застрахованного лица о других продуктах и услугах Страховщика, ЗАО «АВТОАССИСТАНС», ПАО «РГС Банк», в том числе посредством сетей электросвязи на абонентский номер Страхователя, указанный в настоящем Договоре.


<b>Действие страхования по договору страхования, заключенному впервые, наступает</b> с шестого дня после дня уплаты страховой премии наличными деньгами или путем безналичного перечисления.

<b>Действие страхования по договору страхования, заключенному в новый срок (возобновленный),</b> наступает со следующего дня после окончания предыдущего договора страхования при условии уплаты страховой премии наличными деньгами или путем безналичного перечисления до даты окончания предыдущего договора.


Релиз ОСАГО Переоформление от 21.08.2017
- Внесены исправления и обработки ошибочно вводимых данных во многие контролы
- Внесены изменения в процесс переоформления по причине: Изменение цели использования в качестве Такси
- Внесены изменения в процесс переоформления по причинам: Изменение данных страхователя / собственника
- Внесены изменения в процесс переоформления по причине: Изменение списка лиц допущенных к управлению ТС 





01893438

1001312393



RBInsFiz
ip_strah
RBInsJur
SMSSending


7200
0665104
10.03.2017






   if( MYGLOBAL::gEditType & 8 ) RBNewInsJur->Checked = RBInsJur->Checked;
   if( MYGLOBAL::gEditType & 8 ) RBNewOwnJur->Checked = RBOwnJur->Checked;
   
   ЕЕЕ
   0390490046
   20.12.2016
   19.12.2017
  
   
   https://bitcointalk.org/index.php?


Изменение марки, модели ТС
Изменение государственного регистрационного номера
Изменение ФИО водителя, допущенного к управлению
Выдача дубликата полиса
Смена Собственника ТС
Изменение категории ТС
Изменение цели использования ТС
Добавление водителя
Увеличение периода использования ТС
Увеличить срок страхования (для владельцев ТС, зарегистрированных в иностранных государствах)
Неправильная тарификация Договора
Использование ТС с прицепом/без прицепа
Изменение VIN, кузова
Изменение регистрационных документов ТС
Замена водительского удостоверения водителя
Замена документа, удостоверяющего личность Собственника ТС в связи с заменой/утратой
Изменение ФИО собственника ТС
Замена документа, удостоверяющего личность Страхователя в связи с заменой/утратой
Изменение ФИО страхователя
Смена места жительства или места регистрации страхователя - не собственника ТС
Смена места регистрации Собственника ТС
Исключение водителя
Изменение на неограниченное количество водителей
Изменение на ограниченный список водителей
Уменьшение периода использования ТС
Уменьшить срок страхования (только для владельцев ТС, зарегистрированных в иностранных государствах)
Изменение мощности двигателя, количества пассажирских мест, грузоподъемности ТС




      if( MYGLOBAL::gStatusDog == 4 ) { //копия дог-для изменений
	  
	  






gE4RfhFY6234fdghU




   TDateTime enteredInsDocDateEnd = Date();
   if(CheckDate(DEInsDocDateEnd->Text)) enteredInsDocDateEnd = DEInsDocDateEnd->Date;
   m_api->Raise_Error_Warning(res, this, 0, "[Страхователь]Дата окончания документа не может быть раньше даты его выдачи", "[Страхователь]Дата окончания документа не может быть раньше даты его выдачи", 0, PRARM, err_num++,
        !iz_osago_online && (produktindex != 1) && (DEInsDocDateEnd->Enabled && enteredInsDocDateEnd <= enteredInsDocDate) );

		
		
		



eAccidentPrem



0392359636
30.11.2016

1006687790
12.12.2016


Александр Юрьевич, АПО неверно считает возврат премии при внесении изменений.
В полис был вписан молодой водитель и была произведена доплата.
Через три дня его выписывают из полиса, АПО почему-то считает возврат исходя из того,
что молодой водитель был вписан с начала срока действия договора, а не с  даты его вписания.
В результате вместо 6210,04 программа рассчитывает возврат 2526,27.

Клиент в договор ОСАГО 30.05.2017г. вписал водителя и 02.06.2017г. его исключил.
Доплата за этого водителя составила 6 336,08 р., а возврат составил всего 2 526,27 р.
Клиент считает, что за 3 дня слишком много с него удержали.
Готовим ответ на жалобу.
Формула расчета возврата изложена только в инструкции, а это внутренний документ.
Нам сейчас все-таки на инструкцию ссылаться?  
-- 




fio
От Страхователя: <u>[UserData_2."fio"]</u>
[UserData_4."doc_type"]: <u>[IIF(<UserData_2."is_autorization"> = 1,'cерия: ' + <UserData_4."document_series"> + ', номер: ' + <UserData_4."document_number"> + ', выдан: ' + <UserData_4."document_issue_org"> + ' ' + DateToStr(<UserData_4."document_issue_date">),<UserData_4."document_number">)]</u>
Адрес местожительства: <u>[UserData_4."address"]</u>
Телефон: <u>[UserData_4."phone_mobil"]</u>
fio




// gbFortuna
// FA_grbox


->Attributes["premium_rur"]





Проверка номеров предыдущего и текущего договора на совпадение
"Номер предыдущего договора не может совпадать с номером текущего договора", 
"Номер предыдущего договора" - номер предыдущего договора не может совпадать с текущим договором

название организации, выдавшей ПТС/Свидетельство о регистрации ТС. Название государственной организации не может содержать спецсимволы.
1.	Запретить ввод спецсимволов;
2.	Сделать поле обязательным для заполнения (это поможет снизить количество пакетов отправляемых на повторное сканирование).

Возраст
1.	Значение в поле не может быть больше 140 лет от текущей даты.
2.	Значение в поле не может превышать текущую дату.


"Дата выдачи документа"(страхователя): значение в поле не может превышать текущую дату.



   if(CheckDateFormat(DateEdit2->Text))
   {
     int nNumYears = CalcYears(IncDay(DateEdit2->Date), today );
     if(nNumYears > 0 && nNumYears <= 140)
       v2->Value = nNumYears;
     else
     {
       ShowMessage("Ñòàæ ïåðñîíû íå ìîæåò áûòü áîëåå 140 ëåò");
       v2->Value = 0;
     }
   }

void __fastcall TFrame1::EInsDocSeriaKeyPress(TObject *Sender, char &Key)
{
   //Set<char, 0, 255> s;
   //s <<' '<<'-'<<'*'<<'.'<<'_'<<'/'<<'\\'<<'\''<<','<<'['<<']'<<'}'<<'{'<<'+'<<'!'<<':'<<'?'<<'='<<'%'<<'$'<<'^'<<'"'<<';'<<'&'<<'|'<<'~'<<'`'<<VK_BACK;
   //if(!s.Contains(Key)) Key = 0;

   if(Key==VK_BACK) return;
   AnsiString restrictedSymbols(" -*._\/\\,[]}{+!:?=%$'^\";&|~`");
   if(restrictedSymbols.Pos(AnsiString(Key)))
   Key = 0;
} //---------------------------------------------------------------------------





_ButtonToScrollFrameBar

Тестирование печатной формы.

- вывод ИД расчёта и ИД договора, с выводом 




//---------------------------------------------------------------------------

/*
////////////////////////////////////
ITERATOR:
i++ / ++i

i = 2;
k = i++; // post // k = i ,  i = i+1 // 
k = ++i; // pre //  i = i+1, k = i

for(iterator it; it<n; it++) - временный объект создаём который равен текущему значению итератора до увеличения на один и увеличиваем только ПОСЛЕ того как вернули это временное значение
for(iterator it; it<n; ++it) - МЫ ВОЗВРАЩАЕМ АКУТАЛЬНУЮ ВЕРСИЮ ИТЕРАТОР И НЕ ГЕНЕРИРУЕТСЯ ВРЕМЕННЫЙ ОБЪЕКТ. 1) Увеличили итератор на 1 ... 2) отправляем в цикл увеличенный на 1 элемент и работаем с ним
// временный объект - копия текущего итератора, но со следующей позицией 

*/

/*
доступ рандомный к каждому эл-ту
дек - двутороняя очередь - пушбэк / пушфронт
вектор - есть только пушбек

.begin() - действительный ПЕРВЫЙ элемент
.end() - Следующий ПОСЛЕ последнего элемента элемент (недействительный)

".size() == 0"  ВМЕСТО ЭТОГО всегда ЛУЧШЕ  ".empty()"
Причина - .size()  - вызывает пересчёт всех элементов
Причина - .empty() - возвращает bool-значение.

////////////////////////////////////
ВЕКТОР
забит до 100-тни. вектор делаем пушбек - пересоздаётся новый буфер как правило расширенный вдвое
1) существующие элоементы туда в него копируются из старого и после 2) вставляется новый вставленный элемент.
Все итераторы при этом стали НЕвалидные, которые указывали не предыдущий кусок памяти.
- перераспределение памяти каждый раз перекопирует всё полностью
+ вектора (Стринг и Вектор - есть метод vec.data() = получаем указатель на весь смежный 
участок памяти который занимает весь вектор и работем с ним как с обычным буфером (массив данных))
+ доступ к произвольному эелементу присуствует 
Вставка в вектор - О(1) - ПРИЧИНА - потому что это массив и мы оп индексу можем спокойно обратиться к любому элементу, тоесть операция получения эл-та по индексу (его "номеру") 
Джосатис - о вставке - иногда это бывает О(n) - если надо перераспоределять буфер - изза того, что линейно последовательно происходит копирование по одному элементу из старого места на новое старого вектора на место нового +выделение памяти под размер нового вектора, размер которого вдвое больше старого.

////////////////////////////////////
ДЕК (DEQUE) - Двусторонняя очередь
забит до 100-тни. в дек делаем пушбек/пушфронт - ВСЕ ИТЕРАТОРЫ целые остаются.
Все ссылки так и остались на своём месте, только добавилась новая.
+ перераспределение памяти удобнее и быстрее
- невозможно использовать весь дек целиком, потомучто все элементы фрагментированы и лежат каждый в своём месте.
- доступ к произвольному эелементу присуствует. Только используя итераторы.

STD::SORT - ТРЕБУЕТ От контейнера итератора произвольного доступа (random iterator).
quick_sort - можно использовать как к ДЕКу так и к ВЕКТОРу - QUICK_SORT

////////////////////////////////////
СПИСОК (LIST)
обычный STD::SORT изза последовательного доступа к элементам использовать нельзя
.list_sort() - сортировка СЛИЯНИЕМ = MERGE_SORT. Сложность O(n*log(n))

Поиск элемента О(n), потомучто надо пройти по всем элементам

Удаление элемента - итераторы на всё 
////////////////////////////////////
Во всех Красно-Чёрное Дерево. 
О(log(n)) во всех функциях, где n - число элементов
SET, MULTISET, MAP, MULTIMAP

SET - хранит все элементы в отсортированном виде (с поправкой на тип элементов)
SET.insert() - 

MAP _map

MULTIMAP _mmap
_mmap - вернёт последний вставленный элемент

Сет - только один параметр, value
Map - имеет два параметра, key <-> value
Соответсвенно, когда нам избыточно key и не нужно его указывать и мы готовы использовать обычные key индексы которые нам предоставляет Сет, используем его.
Если же хотим задавать собственные key - то стоит использовать map

ВЕКТОР против СЕТ для сохранения и сортировки названия файлов.
1) Сет вставка -> n*log(n). вектор вставка -> n*(операция перераспределения вектора при каждой вставке). 
2) Сортировка Вектора - наиболее оптимальную для случая с вектором можем взять быстрыю сортировку n*log(n). Сортировка Сета не нужна вообще.
3) Обработать каждый элемент - накопить, сортировать и обработать. Через Итератор О(n) - последовательно обрабатываем каждый элемент

////////////////////////////////////
UNORDERED_SET
UNORDERED_MAP

При попадании в одну и туже ячейку, тоесть произошла коллизия, то список расширяется. Можно задавать - хэш промахи +фрагментация
Insert, Search, Remove - O(1) НО 


*/

/*
SWAP()
Всегда стоит использовать ФУНКЦИЮ ЧЛЕН, она всегда БЫСТРЕЕ, чем обобщённая работает. (С итератором последовательного доступа для списков и доугих контейнеров)


Есть функции для обработки блоков элементов:
INSERT_RANGE() - функции, которые обрабатывают целые интервалы, всегда работают быстрее, чем в циклах с использованием аналогичных итераторов
*/

/*
События с Автособросом / Без автосброса.
thrd1.CreateEvent(AUTO_RESET)
thrd1.SetEvent() - Установили в СИГНАЛЬНОЕ СОСТОЯНИЕ

while()
{
// Событие Без_Автосброса то нужно явно вызывать ResetEvent() - перевод в НЕСИГНАЛЬНОЕ СОСТОЯНИЕ
  thrd2.WaitForSingleObject()
  ResetEvent();
  thrd3.WaitForSingleObject()
  ResetEvent();
}

while()
{
// Событие C_Автосбросом то НЕ нужно явно вызывать ResetEvent(), он по выходу из WaitForSingleObject сбросится сам
  thrd2.WaitForSingleObject()
  thrd3.WaitForSingleObject()
}


ИСПОЛЬЗОРВАНИЕ СОБЫТИЙ:
МЫ ВНУТРИ СВОЕГО ПРОЦЕССА ПОНАСОЗДАВАЛИ ОБРАБОТЧИКИ СОБЫТИЙ, И ОБРАБАТЫВАЕМ ИХ ТОГДА КОГДА ОНИ перешли из несгнального сосотяния в сигналоьное соотсветсвенно.
Причём и мы можем отслеживать и сторонние приложенияы тоже, по ID-события / Импени события.

*/

/*
Есть счётчик который разделяется. или число к коротому прибавляется что-то.
При выполнении какойто операции

mov eax, 4
sub ecx, eax
inc eax

то это перация
int x = 4, k = 0;
x = x - k;

или x++;
mov eax, ecx;
inc ecx;
mov ecx, eax;

INTERLOCKED FUNCTIONS

__declspec (align(8)) volatile LONG _ServerState = 0;

Your way is good:
LONG Cur = InterlockedCompareExchange(&_ServerState, 0, 0);

I'm using similar solution:
LONG Cur = InterlockedExchangeAdd(&_ServerState, 0);


To anyone who has to revisit this thread I want to add to what was well explained by Bartosz that _InterlockedCompareExchange() is a good alternative to standard atomic_load() if standard atomics are not available. Here is the code for atomically reading my_uint32_t_var in C on i86 Win64. atomic_load() is included as a benchmark:

 long debug_x64_i = std::atomic_load((const std::_Atomic_long *)&my_uint32_t_var);
00000001401A6955  mov         eax,dword ptr [rbp+30h] 
00000001401A6958  xor         edi,edi 
00000001401A695A  mov         dword ptr [rbp-0Ch],eax 
    debug_x64_i = _InterlockedCompareExchange((long*)&my_uint32_t_var, 0, 0);
00000001401A695D  xor         eax,eax 
00000001401A695F  lock cmpxchg dword ptr [rbp+30h],edi 
00000001401A6964  mov         dword ptr [rbp-0Ch],eax 
    debug_x64_i = _InterlockedOr((long*)&my_uint32_t_var, 0);
00000001401A6967  prefetchw   [rbp+30h] 
00000001401A696B  mov         eax,dword ptr [rbp+30h] 
00000001401A696E  xchg        ax,ax 
00000001401A6970  mov         ecx,eax 
00000001401A6972  lock cmpxchg dword ptr [rbp+30h],ecx 
00000001401A6977  jne         foo+30h (01401A6970h) 
00000001401A6979  mov         dword ptr [rbp-0Ch],eax 

    long release_x64_i = std::atomic_load((const std::_Atomic_long *)&my_uint32_t_var);
00000001401A6955  mov         eax,dword ptr [rbp+30h] 
    release_x64_i = _InterlockedCompareExchange((long*)&my_uint32_t_var, 0, 0);
00000001401A6958  mov         dword ptr [rbp-0Ch],eax 
00000001401A695B  xor         edi,edi 
00000001401A695D  mov         eax,dword ptr [rbp-0Ch] 
00000001401A6960  xor         eax,eax 
00000001401A6962  lock cmpxchg dword ptr [rbp+30h],edi 
00000001401A6967  mov         dword ptr [rbp-0Ch],eax 
    release_x64_i = _InterlockedOr((long*)&my_uint32_t_var, 0);
00000001401A696A  prefetchw   [rbp+30h] 
00000001401A696E  mov         eax,dword ptr [rbp+30h] 
00000001401A6971  mov         ecx,eax 
00000001401A6973  lock cmpxchg dword ptr [rbp+30h],ecx 
00000001401A6978  jne         foo+31h (01401A6971h) 
00000001401A697A  mov         dword ptr [rbp-0Ch],eax

*/

/*
Процесс
Тред_1 -> ОpenProcess -> kernel32.dll -> nt.dll -> загрушка -> sysinter (подготавливает переменные помещает в стек / регистр для передачи в ядро) -> KERNEL MODE
UserMode - Работает процесс - Trojan.exe с PID

sysinter -> (*) -> KERNEL MODE:
(*) перед переключением в Kernel Mode надо сохранить состояние КОНТЕКСТ (= стек, регистры и т.д.) потока в ЮзерМоде. После чего в Ядре создаётся другой поток.
Контекст Тред_1_ЯДЕРНЫЙ - у него свой стек, свои регистры и т.д. 
PsGetCurrentProcess() - говорит какой процесс сейчас активен, что означает - какому процессу принадлежит поток ЮзерМодный из которого мы перешли в КернелМод
Этот метод вернул тебе информацию об этом процессе => |Требуем защищать IE, и В список защищённых процессов будет попадать PID этого IE |  (Рестрт процесса регулируется Нотификационными функциями)
Так вот. До тех пор, пока вся работа в Ядре не закончится, поток в Юзермодже будет залочен и приостановлен полностью. => Тоесть 
Изолированный процесс - У нас есть PID защищённого процесса. PID of current Process. GetPIDofCurrentProcess есть PID_Protected -> if(PID_Protected != CurrentProcess) return AccessDenied // 
Блокируемые расширения => СreateProcess() => 

НОВАЯ ЗАПИСЬ 20
*/










 
/////////////////////////////////////////////////////////////
// О ВИРТ. ФУНКЦИЯХ
/////////////////////////////////////////////////////////////
// http://www.cyberforum.ru/cpp-beginners/thread1391513.html#post7321173
// 17.03.2015, 23:25  [ТС]

    AA* pa; 
// Указателю на базовый класс присваиваем адрес ПРОИЗВОДНОГО класса:
    pa=&b;   
    pa->f();// виртуальный вызов f() из B
    pa->AA::f();// невиртуальный вызов f() из AA

/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  УМНЫЙ УКАЗАТЕЛЬ
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  УМНЫЙ УКАЗАТЕЛЬ - UNIQUE_PTR
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  УМНЫЙ УКАЗАТЕЛЬ - SHARED_PTR
/////////////////////////////////////////////////////////////
MY SHARED_PTR:
http://www.cyberforum.ru/cpp-beginners/thread943866.html

/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  LIST
/////////////////////////////////////////////////////////////

	http://www.cyberforum.ru/cpp-beginners/thread178335.html#post1039880

NEED LIST WITH A    NODE
struct node
{
	char some;
	int key;
};
	
/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  VECTOR
/////////////////////////////////////////////////////////////
	
	http://www.cyberforum.ru/cpp-beginners/thread178335.html#post1693182

/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  HASH TABLE
/////////////////////////////////////////////////////////////

http://www.programmersforum.ru/showthread.php?t=69994

const int maxn=10000;
struct node
{
	char znac[20];
	int key;
};

int kolcol;
int kolsl;
int ObTable;

node hashtable[maxn];



/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЙ  MAP
/////////////////////////////////////////////////////////////

	
/////////////////////////////////////////////////////////////
// РЕАЛИЗОВАТЬ СВОЮ ФУНКЦИЮ  ATOI
/////////////////////////////////////////////////////////////

int atoi(char s[])
{
    int i, n;
    n = 0;
    for (i = 0; s[i] >= '0' && s[i] <= '9'; ++i)
		n = (n * 10) + (s[i] - '0');
    return n;
}

int atoi(char* s)
{
    int n = 0;
    while( *s >= '0' && *s <= '9' ) {
        n *= 10;
        n += *s++;
        n -= '0';
    }
    return n;
}

int my_atoi(const char*  src)
{
	int result = 0;
	int digit = 1;
	const int DIGIT_DIFFERENCE = 10;
	const char ZERO_SYMBOL = '0';
	for(int i = (strlen(str)-1); i >= 0; i--)
	{
		result = result + (digit * int(str[i]-ZERO_SYMBOL));
		digit = digit * DIGIT_DIFFERENCE;
	}
	return result;
	
	// NO delimiters 
	// NO trim string fuction for space-characters 
	// NO negative numbers / multiple minus symbols in string
	// NO check if there exist other symbols than numbers in string
}


#include <iostream>
#include <cstdlib>
using namespace std;
static const char MINUS = '-';
char* my_trimLeft(const char* src);
int my_atoi(const char*  src);
int main()
{
	cout << my_atoi("bjk vvh-)(-20856--fbhcfr f");
	cin.get();
	return 0;
}
// Implement the function, that transforms string into integer.
int my_atoi(const char*  src)
{
	bool isNegative = false;
	char* str = my_trimLeft(src);
	if(str == NULL)
	{
		return EXIT_FAILURE;			// input error, terminating
	}
	if(str[0] == MINUS)
	{
		isNegative = true;
		str++;
	}
	int result = 0;
	int digit = 1;
	const int DIGIT_DIFFERENCE = 10;
	const char ZERO_SYMBOL = '0';
	for(int i = (strlen(str)-1); i >= 0; i--)
	{
		result = result + (digit * int(str[i]-ZERO_SYMBOL));
		digit = digit * DIGIT_DIFFERENCE;
	}
	if(isNegative == false)
	{
		delete [] str;
		return result;
	}
	else
	{
		str--;
		delete [] str;
		return -result;
	}
}
char* my_trimLeft(const char* src)
{
	if(strlen(src) == 0)	// there's no string
	{
		return NULL;
	}
	char* resultStr = new char[strlen(src)];
	int srcIndex = 0;
	int resultIndex = 0;
	while(	(0 == isdigit(src[srcIndex]))
		&&
			(srcIndex < strlen(src))
		)
	{
		if ((src[srcIndex] == MINUS) && (0 != isdigit(src[srcIndex+1])))
		{
			resultStr[resultIndex] = MINUS;
			resultIndex++;
		}
		srcIndex++;
	}
	// now srcIndex indexes the first numeric in the string
	while(	(0 != isdigit(src[srcIndex]))
		&&
			(srcIndex < strlen(src))
		)
	{
		resultStr[resultIndex] = src[srcIndex];
		resultIndex++;
		srcIndex++;
	}
	resultStr[resultIndex] = '\0';
	if(resultIndex == 0)	// no numerics in the string
	{
		return NULL;
	}
	return resultStr;
}


int my_atoi(const char*  src)
{
  int result = 0;
  const char*  tmp_src;
  tmp_src = src;

  if (*tmp_src=='-')
	  tmp_src++;
  for(;strlen(tmp_src)>0; result = (result*10) + ((char)*(tmp_src++)-'0'));
  result *= (*src == '-') ? -1 : 1;
  
  return result;
}


#include <iostream.h>
#include <string.h>
#include <ctype.h>

char *itoa (int n, char *s)
{
 char *t=s;
 int z=0;
 
 if (n<0) { z=1; n = -n; }
 do *s++ = n%10 + '0';
 while (n/=10);
 if (z) *s++ = '-';
 *s = '\0';
 
 return strrev(t);
}

int atoi (char *s)
{
 int z=0, n=0;
 while(isspace(*s)) s++;
 
 if (*s=='-')
 { z=1; s++; }
 else if (*s=='+')
	 s++;
 while (isdigit(*s))
	 n = (10*n) + *s++ - '0';
 return (z?-n:n);
}

void main ()
{
 int n=-31289;
 char buf[80];
 cout << "\nitoa=" << itoa (n,buf);
 cout << "\natoi=" << atoi (buf);
 cin.get();
}

/////////////////////////////////////////////////////////////
// РАЗВЕРНУТЬ СТРОКУ
/////////////////////////////////////////////////////////////

// STL РЕШЕНИЕ
#include <iostream>
#include<string>
#include <algorithm>

std::string goodbyeWorld="Hello World";
std::reverse(goodbyeWorld.begin(), goodbyeWorld.end());
std::cout<<goodbyeWorld<<std::endl;

// ШАБЛОННОЕ РЕШЕНИЕ
#include <iostream>
#include <algorithm>

template<typename T> void t_reverse(T* a, T* b) 
{
    T t;
    for(b -= 1; a < b; ++a, --b) {
        t  = *a;
       *a = *b;
       *b = t;
   }
}


int main()
{
   char s[] = "123";
   puts(s);  // исходная строка
   t_reverse(s, s + strlen(s));
   puts(s);  // вывод реверс-строки
	
   double arr[] = { 10.99, 34.66, 3.14567, 1.7 };
   int size  = sizeof(arr)/sizeof(arr[0]);

   // выведем исходный массив
   std::copy(arr, arr + size, std::ostream_iterator<double>(std::cout, "\t"));
   t_reverse(arr, arr + size);
   std::cout << std::endl;
   // выведем реверс массив
   std::copy(arr, arr + size, std::ostream_iterator<double>(std::cout, "\t"));
   return 0;
}



// РЕКУРСИВНОЕ РЕШЕНИЕ
#include <iostream.h>
 
void RevStr(char* S,int l)
{
    char c;
    if (l > 1)
    {
      c=S[0];
      S[0]=S[l-1];
      S[l-1]=c;
      RevStr(S+1,l-2);
    }             
}       
 
int main(int argc, char* argv[])
{
    char S[12]="Test of pen";
    RevStr(S,11);
    cout << S << endl;
    return 0;
}


// РЕШЕНИЕ НА УКАЗАТЕЛЯХ
char* strrev(char* str)
{
    char* left = str;
    char* rigth = str;
    while (*str++)
		str -= 2;
    while (left < str)
    {
        char c = *left;
        *left++ = *str;
        *str-- = c;
    }
    return rigth;
}

int main()
{
    char x[100] = {"String reverse"};
    std::cout << strrev(x);
    return 0;
}

// ЧЕРЕЗ ПОЛОВИНУ С ЛЕВОЙ СТОРОНЫ
{
   char str[] = "12345678";
   const size_t strLen = sizeof(str);
   for (size_t i = (strLen/2)-1; i--;)
      swap(str[i], str[strLen-i-2]);
   cout << str << endl;
}

// ЧЕРЕЗ ПОЛОВИНУ С ПРАВОЙ СТОРОНЫ
  l = strlen(s);
  for (i = 0; i < l/2; i++)
  {
     s[l+1] = s[i];
     s[i] = s[l-i];
     s[l-i] = s[l+1];
  } 
  s[l+1]=0;

  
  
  
  
  
  
  
  
  


https://github.com/google/googletest


https://www.microsoft.com/en-us/download/confirmation.aspx?id=17851





   int count_ad = gridAD->Items->Count;

   
   for(int i = 0, n = gridAD->Items->Count; i < n; i++)
      if(gridAD->Items->Item[i]->Checked) result += adevice[i].cost;

   return result;   


   
        if(reasons_surcharge[17].select){
         m_api->dbExecuteQuery(res, "delete * from casco_devices_r where calc_id=" + q_save->FieldByName("calc_id")->AsString);
         TADOQuery *q_ad_r = m_api->dbGetCursor(res, "select * from casco_devices_r where calc_id=" + q_save->FieldByName("calc_id")->AsString, 0, 1);
         for(int i = 0, j = 0, cnt = gridAD->Items->Count; i < cnt; ++i)
            if(gridAD->Items->Item[i]->Checked){
               q_ad_r->Insert();
               q_ad_r->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->AsInteger;
               q_ad_r->FieldByName("number")->Value = j + 1;
               q_ad_r->FieldByName("id_device")->Value = adevice[i].id;
               q_ad_r->FieldByName("cost_device")->Value = adevice[i].cost;
               q_ad_r->FieldByName("description")->Value = adevice[i].name_detail;
               ++j;
            }
         q_ad_r->UpdateBatch();
         m_api->dbCloseCursor(res, q_ad_r);
      }
 
 
 
   
            for(int i = 0, j = 0, cnt = gridAD->Items->Count; i < cnt; ++i)
            if(gridAD->Items->Item[i]->Checked){
               q_ad_r->Insert();
               q_ad_r->FieldByName("calc_id")->Value = q_save->FieldByName("calc_id")->AsInteger;
               q_ad_r->FieldByName("number")->Value = j + 1;
               q_ad_r->FieldByName("id_device")->Value = adevice[i].id;
               q_ad_r->FieldByName("cost_device")->Value = adevice[i].cost;
               q_ad_r->FieldByName("description")->Value = adevice[i].name_detail;
               ++j;
            }

casco_devices_r


frmADevices

AddEquipments




void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesInitPopup(TObject *Sender)
{
   last_reasons = vg_Reason->Properties->Value;
}





di->pay_id

pay_id_arm = NodeToStr(policy->ChildNodes->FindNode("payment_method_id")).ToIntDef(0)






   if(coeff_base.count(1))  bt_calcstr += " * " + S(di->calc_info.k1)  + "(K1)";
   if(coeff_base.count(28)) bt_calcstr += " * " + S(di->calc_info.kd)  + "(Kä)";
   if(coeff_base.count(18)) bt_calcstr += " * " + S(di->calc_info.kyu) + "(Kþ)";
   if(coeff_base.count(2))  bt_calcstr += " * " + S(di->calc_info.k2)  + "(K2)";
   if(coeff_base.count(3))  bt_calcstr += " * " + S(di->calc_info.k3)  + "(K3)";
   if(coeff_base.count(4))  bt_calcstr += " * " + S(di->calc_info.k4)  + "(K4)";
   if(coeff_base.count(5))  bt_calcstr += " * " + S(di->calc_info.k5)  + "(K5)";
   if(coeff_base.count(19)) bt_calcstr += " * " + S(di->calc_info.k6)  + "(K6)";
   if(coeff_base.count(7))  bt_calcstr += " * " + S(di->calc_info.k7)  + "(K7)";
   if(coeff_base.count(11)) bt_calcstr += " * " + S(di->calc_info.kr)  + "(Kð)";
   if(coeff_base.count(9))  bt_calcstr += " * " + S(di->calc_info.kar) + "(Kàð)";
   if(coeff_base.count(23)) bt_calcstr += " * " + S(di->calc_info.kpr) + "(Kïð)";
   if(coeff_base.count(24)) bt_calcstr += " * " + S(di->calc_info.ks)  + "(Kñ)";
   if(coeff_base.count(22)) bt_calcstr += " * " + S(di->calc_info.krs) + "(Kðñ)";
   if(coeff_base.count(26) && di->bank_id > 0)
                            bt_calcstr += " * " + S(di->calc_info.kb)  + "(Ká)";
   if(di->bank_id > 0)      bt_calcstr += " * " + S(di->calc_info.kfr) + "(Kïðèñê)";
   if(coeff_base.count(14)) bt_calcstr += " * " + S(di->calc_info.ka)  + "(Kà)";
   
   



newpereoformprem

doplata->Caption

gDoplata

calcPrem(


      AnsiString str___ = "new_premiya_osn_risk= " + FloatToStr(new_premiya_osn_risk) + " " +
                          "di->calc_info.osn_risk_itog_tarif= " + FloatToStr(di->calc_info.osn_risk_itog_tarif) + " " +
                               "bt= " + FloatToStr( m_api->Round(di->calc_info.bt ) ) + " " +					  //
                               "k1= " + (coeff_base.count(1)  ? FloatToStr( di->calc_info.k1 ) : IntToStr(1) ) + " " + //*
                               "kd= " + (coeff_base.count(28) ? FloatToStr( di->calc_info.kd ) : IntToStr(1) ) + " " + //*
                               "k3= " + (coeff_base.count(3)  ? FloatToStr( di->calc_info.k3 ) : IntToStr(1) ) + " " + //*
                               "k4= " + (coeff_base.count(4)  ? FloatToStr( di->calc_info.k4 ) : IntToStr(1) ) + " " + //*
                               "k5= " + (coeff_base.count(5)  ? FloatToStr( di->calc_info.k5 ) : IntToStr(1) ) + " " + //*
                               "k7= " + (coeff_base.count(7)  ? FloatToStr( di->calc_info.k7 ) : IntToStr(1) ) + " " + //*
                               "kar= " + (coeff_base.count(9)  ? FloatToStr( di->calc_info.kar) : IntToStr(1) ) + " " + //*
                               "kr= " + (coeff_base.count(11) ? FloatToStr( di->calc_info.kr ) : IntToStr(1) ) + " " + //*
                               "ka= " + (coeff_base.count(14) ? FloatToStr( di->calc_info.ka ) : IntToStr(1) ) + " " + //*
                               "k6= " + (coeff_base.count(19) ? FloatToStr( di->calc_info.k6 ) : IntToStr(1) ) + " " + //*
                               "ks= " + (coeff_base.count(24) ? FloatToStr( di->calc_info.ks ) : IntToStr(1) ) + " " + //*
                               "krs= " + (coeff_base.count(22) ? FloatToStr( di->calc_info.krs) : IntToStr(1) ) + " " + //*
                               "kpr= " + (coeff_base.count(23) ? FloatToStr( di->calc_info.kpr) : IntToStr(1) ) + " " + //*
                               "kb= " + (coeff_base.count(26) ? FloatToStr( di->calc_info.kb ) : IntToStr(1) ) + " " + //*
							   "kfr= " + FloatToStr( di->calc_info.kfr ) ;














void __fastcall TfrmAddPermitted::TextItemPropertiesChange(TObject *Sender)
{
   //vg->InplaceEditor->PostEditValue();
//*
   labHint->Top = vg->InplaceEditor->Top + 16;
   labHint->Visible = true;
//*
   //vg->FocusRow(vg->FocusedRow, 1);
   vg->FocusRow((vg->FocusedRow, 1);
   TcxEditorRow *r = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   //int indx_ = r->IndexOf(vg->FocusedRow);
   int abs_indx = r->AbsoluteIndex;
   int indx = r->Index;


	   int count_permit = gridDopush->Items->Count;
	   for (int i = 0; i < count_permit; ++i)
	   {
		   gridDopush->Items->Item[i]->SubItems->Strings[3] = pm[i].k1;
		   gridDopush->Items->Item[i]->SubItems->Strings[4] = pm[i].k6;
	   }
 
 
î÷èñòèòü grid íóæíî â


Регион заключения договора: Республика Башкортостан.
Дата заключения договора: 30.12.2016 г. 
Страхуемый риск: КАСКО.
Срок страхования: 12 мес. 
Марка, модель: BMW, 730.
Группа ТС: ИГ3.
Возраст ТС: 3 лет. 
Первоначальный договор
Действительная стоимость: 3 000 000 руб.
Страховая сумма по основному риску: 3 000 000 руб.
Премия по исходному договору: 82 500 руб.
Cрок страхования в днях (N): 365.
Количество дней за истекший срок страхования (n): 127.
Итоговый тариф (новый): 2.75 %
T = 11.93(Тб) * 0.62(K1) * 1.00(Kд) * 1.00(K3) * 1.00(K4) * 0.58(K5) * 1.00(K6) * 1.00(K7) * 0.86(Kр) * 1.49(Kар) * 0.50(Kпр) * 1.00(Kс) * 1.00(Kрс) * 1.00(Kа)
Премия с измененными условиями: 82 500 руб.

ДОПЛАТА: 0 руб.

Расчет произведен: 05.05.2017




Регион заключения договора: Республика Башкортостан.
Дата заключения договора: 30.12.2016 г. 
Страхуемый риск: КАСКО.
Срок страхования: 12 мес. 
Марка, модель: BMW, 730.
Группа ТС: ИГ3.
Возраст ТС: 3 лет. 
Первоначальный договор
Действительная стоимость: 3 000 000 руб.
Страховая сумма по основному риску: 3 000 000 руб.
Премия по исходному договору: 199 500 руб.
Cрок страхования в днях (N): 365.
Количество дней за истекший срок страхования (n): 127.
Итоговый тариф (новый): 6.65 %
T = 11.93(Тб) * 1.50(K1) * 1.00(Kд) * 1.00(K3) * 1.00(K4) * 0.58(K5) * 1.00(K6) * 1.00(K7) * 0.86(Kр) * 1.49(Kар) * 0.50(Kпр) * 1.00(Kс) * 1.00(Kрс) * 1.00(Kа)
Премия с измененными условиями: 199 500 руб.

ДОПЛАТА: 0 руб.

Расчет произведен: 05.05.2017





sFrameBarFCalc


  object btnDopushMinus: TsBitBtn
    Left = 216
    Top = 446
    Width = 33
    Height = 20
    Hint = #1044#1086#1073#1072#1074#1080#1090#1100
    ParentShowHint = False
    ShowHint = True
    TabOrder = 3
    Visible = False
    OnClick = btnDopushMinusClick
    Glyph.Data = {
      C6000000424DC6000000000000007600000028000000100000000A0000000100
      04000000000050000000120B0000120B00001000000000000000000000000000
      800000800000008080008000000080008000808000007F7F7F00BFBFBF000000
      FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00333333333333
      3333333333300333333333333337033333333333333703333333333000070000
      0333333777777777033333333337033333333333333703333333333333370333
      33333333333333333333}
    SkinData.SkinSection = 'BUTTON'
  end
  
  
  
  





      di->count_permitted = count_permit + 1;
      Recalc();
   }	  
	  

void __fastcall TFReissCalc::btnDopushPlusClick(TObject *Sender)





Реализован расчёт через сервис УФО с авторизованным договором по старым условиями и отдельно добавленным допущенным (с которым был выполнен перерасчёт).


Анализ алгоритма работы в модуле "КАСКО 2.0" в случае выбора причины, требующей Пересчёта, для его адаптации и встраивания в модуль "КАСКО Переоформление".




   //ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag, pm[Tag].doc_seria, pm[Tag].doc_number);

         //ChangeMask(MaskItemSeries, MaskItemNumber, editPmDocSeria, editPmDocNumber, pm, Tag);
		 

//*
   bool b_ = false;
	        //btnOK->Enabled = 																										   ;
	b_ =    pm[Tag].sex > 0 																										   ;
	b_ =    !pm[Tag].lastname.IsEmpty()																								   ;
	b_ =    !pm[Tag].firstname.IsEmpty() 																							   ;
	b_ =    pm[Tag].birthdate.Val && pm[Tag].doc_issue_date.Val 																	   ;
	        //&& (																													   ;
	b_ =    !MaskItemSeries->Properties->EditMask.IsEmpty()																			   ;
	b_ =	!pm[Tag].doc_seria.IsEmpty()																							   ;
	b_ =	!pm[Tag].doc_seria.Pos(underline_str)																					   ;
	        //||																													   ;
	b_ =    MaskItemSeries->Properties->EditMask.IsEmpty() 																			   ;
	b_ =    !pm[Tag].doc_seria.IsEmpty()																							   ;
	b_ =    !MaskItemNumber->Properties->EditMask.IsEmpty()																			   ;
	b_ =    !pm[Tag].doc_number.IsEmpty()																							   ;
	b_ =    !pm[Tag].doc_number.Pos(underline_str)																					   ;
	        //|| 																													   ;
	b_ =    MaskItemNumber->Properties->EditMask.IsEmpty()																			   ;
	b_ =    !pm[Tag].doc_number.IsEmpty()																							   ;
                                                                                                                                       ;
	b_ =    pm[Tag].age > 17																										   ;
	b_ =    (pm[Tag].age - pm[Tag].experience) > 17;
    int n_ =(pm[Tag].age - pm[Tag].experience);
//*/

   btnOK->Enabled = pm[Tag].sex > 0 && !pm[Tag].lastname.IsEmpty() && !pm[Tag].firstname.IsEmpty() && /*!pm[Tag].secondname.IsEmpty() &&*/ pm[Tag].birthdate.Val && pm[Tag].doc_issue_date.Val /*&& !pm[Tag].address.IsEmpty()*/
                  && (
                      (!MaskItemSeries->Properties->EditMask.IsEmpty() && !pm[Tag].doc_seria.IsEmpty() && !pm[Tag].doc_seria.Pos(underline_str))
                      || (MaskItemSeries->Properties->EditMask.IsEmpty() && !pm[Tag].doc_seria.IsEmpty())
                     )
                  && (
                      (!MaskItemNumber->Properties->EditMask.IsEmpty() && !pm[Tag].doc_number.IsEmpty() && !pm[Tag].doc_number.Pos(underline_str))
                      || (MaskItemNumber->Properties->EditMask.IsEmpty() && !pm[Tag].doc_number.IsEmpty())
                     )
                  && pm[Tag].age > 17 && (pm[Tag].age - pm[Tag].experience) > 17;
				  
				  

				  
				  
				  




void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesCloseUp(TObject *Sender)

void TFReissCalc::SetVisible_VG_Items(const int reason)

void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesInitPopup(TObject *Sender)
{
   last_reasons = vg_Reason->Properties->Value;
}




//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
Есть 2 причины завязанные на ПЕРЕСЧЁТ:
1) Изменение списка допущенных
2) Изменение способа возмещения ущерба


Анализ алгоритма перерасчёта премии при изменении способа возмещения ущерба, реализация выполнения перерасчёта автоматически, при выборе двух причин, при которых он должен производиться.


По шагам:
0) Загружаем Договор
0) Авторизуем договор
1) Выбираем в причинах "Изменение списка допущенных"
2) Добавляем допущенного
 (!) Посмотреть куда добавляются новые допущенные
 
и со старыми условиями + этот допущенный => закидываем в расчет и выполнить перерасчёт
ДОБАВИТЬ ДОПУЩЕННОГО с Большим стажем
ДОБАВИТЬ ДОПУЩЕННОГО с Маленьким стажем

Старый расчёт с новыми данными подружить...

В КАСКО 2.0 Если выбрана причина с Пересчётом
 (!) В КАСКО 2.0 есть  no_calc - переменная отвечающая за пересчёт
Пока не пересчитает эта ошибка не уходит

И причина влияющая на пересчёт должа СБРАСЫВАТЬ перерасчёт доплаты и т.д.

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////



POLICY_ID	POLICY_SERIES	POLICY_NUMBER	STATEMENT_DATE	INVOICE_DATE	POLICY_DATE	PREMIUM_CHARGE_DATE	START_DATE	END_DATE	POLICY_START_DATE		  POLICY_END_DATE	CANCEL_DATE	AGENT_STATEMENT_ID	DESCRIPTION	PROGRAM_VERSION	XML_VERSION	USER_ID	AGENT_ID	PREMIUM_CHARGE_TYPE_ID	COMMISSION_CHARGE_TYPE_ID	SCHEDULE_TYPE_ID	CONTRACT_ID	POLICY_STATUS_ID	CANCEL_REASON_ID	INSERT_DATE	PROLONGATION_CANCEL	LOSS_IN_PROCESS	PROLONGATION_DATE	PROLONGATION_USER_ID	CANCEL_USER_ID	SALE_CHANNEL_ID	SALE_CHANNEL_TYPE_ID	PROJECT_ID	CANCEL_STATEMENT_DATE	CANCEL_UPDATE_DATE	ANALYTICS1	ANALYTICS2	ANALYTICS3	ANALYTICS4	ANALYTICS5	CODE1	CODE2	CODE3	RESERVED	LOGGING_LEVEL	DEBT_AMORTIZATION_DATE	DEBT_AMORTIZATION_REASON_ID	SALE_CHANNEL_TYPE2008_ID	REQUEST_SOURCE_ID	PROGRAM_ID	EDITION_NUMBER	KBM_RSA_ID	QUOTES_DATE	IS_AGREED	UNDERWRITER	SECURITY_NAME	REISSUE_DATE	USER_KBM_RSA_ID	RSA_BONUS_MALUS_ID	DC_REQUEST_ID	DC_REQUEST_RESULT	DC_REQUEST_DATE	IS_NOT_REQUIRED_TO	ORIGIN_TYPE_ID	OFFICE_ID	OTO_BRANCH_ID	WRITEOFF_DEBT_DATE	QUALITY_ID	MODIFY_DATE	SYS_SOURCE	CHECK_SUM	CARD_CONTRACT_DATE	CARD_INSERT_DATE	SYS_CREATOR	SYS_EDITOR	IS_EMPTY_SOURCE_CHECKSUM	PREV_CONTRACT_LIABILITY	CALCULATED_CRC	CHECKSUM_STATUS_ID	IS_CO_INSURANCE	CO_INSURANCE_ROLE_ID	CONTRACT_ID_1	INSURER_SUBJECT_ID	CONTRACT_CLASS_ID	CONTRACT_TYPE_ID	CONTRACT_OPTION_ID	CONTRACT_STATUS_ID	AGENT_ID_1	PRODUCT_ID	CONTRACT_SERIES	CONTRACT_NUMBER	CONTRACT_DESCRIPTION	PREV_CONTRACT_SERIES	PREV_CONTRACT_NUMBER	FACULTATIVE_QUOTA_RATE	FACULTATIVE_COMMISSION_RATE	FACULTATIVE_CONTRACTOR_ID	PRINCIPAL_ID	INSURER_CONTRACTOR_ID	CO_INSURERS_PRESENT	INPUT_ACCURACY_STATUS_ID	CURRENCY_ID	INPUT_WRONG_SUM

12028804816	7100	0696248			21.02.2017	21.02.2017	21.02.2017 17:01	20.02.2018 23:59	21.02.2017 17:01	20.02.2018 23:59		12028f50e8ee00f0311e79b24


52020e3689d	4000	4653515			21.02.2017	21.02.2017	21.02.2017 12:05	20.02.2018 23:59	21.02.2017 12:05	20.02.2018 23:59		52020bbb8d88004b311e7a29a		ARM4	auto	_ROOT	52020de6b70690140187a5eae	1		_ROOT00000000000000000005	52020e3689af004b311e7b66d	50		09.03.2017 13:33		0				52020bd5507220126133f6bcc					6601623	0	0										310			1		21.02.2017	0															09.03.2017 13:33	11	536C					0		536C	2	0		52020e3689af004b311e7b66d	52020e234fcf004b311e7b66d	5	1	1	50	52020de6b70690140187a5eae	301	4000	4653515											RUR	


1b11e78484	6001			0524188			21.02.2017		21.02.2017		27.02.2017	26.02.2018 23:59	27.02.2017	26.02.2018	5002750d6bed0001a11e7bc8a ARM4		_ROOT	500270000100d68c166718426	1		_ROOT00000000000000000005	500276454de50001b11e78484	50		03.03.2017 17:12		0				50027ab57d540077f11e6a93c						0	0		N								120		

11e7a49d	СБ 37			1144627			21.02.2017		21.02.2017		27.02.2017	26.02.2018 23:59	27.02.2017	




(CalculationRequest.PolicyStartDate): Дата начала страхования (19.09.2015 0:00:00 +03:00) не может быть меньше даты расчета (2017-04-26T00:00:00.0000000+03:00)

(CalculationRequest.PolicyStartDate): Дата начала страхования (26.04.2017 0:00:00 +03:00) не может быть позднее даты окончания страхования (18.09.2016 23:59:00 +03:00)





void ThreadUFO::FillCalculationRequest(CalculationRequest *CalcReq)
{
	
   int nType = di->type_multydrive;
   //CalcReq->Vehicles[0]->AdmittedLimitId  = di->type_multydrive; // !!!!! // Òèï äîïóùåííûõ ê óïðàâëåíèþ (Ñïðàâî÷íèê 7.3.67, Ref_AutoDictLimitedDrivers) (Vehicle.AdmittedLimitId): Çíà÷åíèå íå íàéäåíî â ñïðàâî÷íèêå
   CalcReq->Vehicles[0]->AdmittedLimitId = (nType != 100) ? nType : 1; // !!!!! // Òèï ñòðàõîâàòåëÿ (ñïðàâî÷íèê 7.3.28) (Insurant.SubjectTypeId): Çíà÷åíèå íå íàéäåíî â ñïðàâî÷íèêå

   if((nType == 1) || (nType == 100))
   {
      CalcReq->Vehicles[0]->Drivers.Length = di->count_permitted;
      for(int i = 0, j = 0; i < 16; ++i)
      {
         if(pm[i].permitted_check)
         {
            CalcReq->Vehicles[0]->Drivers[j] = new Driver();
            CalcReq->Vehicles[0]->Drivers[j]->Id = IntToStr(i + 1);

			


btnRequestClick

gridAD
gridADClick
btnADEditClick


pm[i]




pi[0].status

Далее переделать логику связанную с изменением причин, изменениями по допущенным и доп. выплатой.





FillCalculationRequest


casco_persons
casco_calc
casco_memo




UThreadUFO

void ThreadUFO::SelectionFromResultOfCalculation(OperationResultOfCalculationResultoTurZuT3 *ResultOfCalc)
{
   // Премии
   di->calc_info.premiya_osn_risk = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->VehiclePremium->DecimalString).ToDouble();

UREISCALC
                     case 2:
                        is_kasko = true;
                        q_save->FieldByName("risk_id")->Value = di->risk = q_r->FieldByName("risk_id")->AsInteger;
                        q_save->FieldByName("risk_main")->Value = q_r->FieldByName("risk_code")->AsString;
                        q_save->FieldByName("tariff")->Value = StrToFloatStr(child_node->Attributes["tariff"]).ToDouble();
                        q_save->FieldByName("str_summa")->Value = di->calc_info.str_summa = StrToFloatStr(child_node->Attributes["liability"]).ToDouble();

                        double premia_di = di->calc_info.premiya_osn_risk;
                        double premia_di_str = StrToFloatStr(child_node->Attributes["premium"]).ToDouble() * 2;

                        q_save->FieldByName("premium_main_risk")->Value = di->calc_info.premiya_osn_risk = StrToFloatStr(child_node->Attributes["premium"]).ToDouble() * 2;






убрать расчёт коэффициентов
убрать расчёт К5
из рассчёта застрахованных убрать расчёт К6


const AnsiString fs("yyyy.mm.dd hh:nn:ss"), empty_str(""), dot_line("---"),  dot("."), null_str(0), one_str(1), space_str(" "), underline_str("_"), pdf("PDF"), not_filename("/\\:*?\"<>|.,'"), category[7] = {"B", "C", "D", "Спецтехника", "E", "E", "E"}, damages[5] = {"убытков нет", "1 убыток", "2 убытка", "3 убытка", "4 убытка или более"}, copy_persons("Страхователя\r\nВыгодоприобретателя"), person[] = {"страхователь", "выгодоприобретатель", "собственник"}, person_tp[] = {"страхователю", "выгодоприобретателю", "собственнику"}, sex("Мужской\r\nЖенский"), mask("L000LL000;1;_"), russia("Российская Федерация"), code_russia("643"), vB("Вариант \"B\""),
                 space_str_nonbreak('\xA0'), space_str_long('\x98'),
                 ts_age_str[13] = {" г.", " г., возраст ТС - 1 год", " г., возраст ТС - 2 года", " г., возраст ТС - 3 года", " г., возраст ТС - 4 года", " г., возраст ТС - 5 лет", " г., возраст ТС - 6 лет", " г., возраст ТС - 7 лет", " г., возраст ТС - 8 лет", " г., возраст ТС - 9 лет", " г., возраст ТС - 10 лет", " г., возраст ТС - 11 лет", " г., возраст ТС - 12 лет"},
                 head_grid("    №     Пол                                  ФИО                                       Возраст / Стаж       Коэффициент K1   Коэффициент K6"), reg_plate_possible("АВЕКМНОРСТХУDавекмнорстхуd0123456789"),
                 programm_error_text("Для данных условий нельзя выбрать программу \"%s\", т.к. "), prefix[4] = {"", "B", "Ow", "Pm"}, combobox("TdxInspectorTextPickRow"), variant[] = {"А", "Б", "В"},
				 
const AnsiString variant[] = {"А", "Б", "В"};

//---------------------------------------------------------------------------
/*////////////////// STRUCTURES DIFFERENCE //////////////////////////////////
struct Dogovor_Info{
   AnsiString polis_seria, polis_number, atypical_number, prev_seria, prev_number, credit_number, 
   zalog_number, calc_date, params[5], pd_series, pd_number, authorization_code, comments_sign[6], 
   contract_id, bank_code, risk_object_forkv;
   TDateTime polis_date, datesrok_s, datesrok_po, credit_date, zalog_date, statement_date, cancell_date, 
   payment_date[12], last_polis_ed_incday, pd_date, email_date;
   int region_id, status_dogovor, dogovor_type, monthcount, bank_id, type_money, contract_type, reiss_type, 
   REGION_TYPE, count_accidents, no_calc, ts_count, old_programm_id, calc_type;
   int product_id, risk, type_multydrive, payments_count, programm_id, project_id, pay_id, franshize_id, 
   franshize_unit, comments_mid[6], sale_channel_id, system_insur, variant, franshize_size;
   int mid_validation, mid_non_standart, mid_oi_errors, approvalstatus, vehcount, contract_type_precalc, 
   k56precalc_parameter, index_max_k6, count_permitted;
   double vzd, base_vzd;
   AnsiString system_error, time_s, product_name, last_contract, system, bp_error_text, calculation_id;
   TStringList *non_standart_str_calc, *validations_errors, *insbridge_errors, *what_change, *data_print, *non_standart_str_id;
   bool is_ander_login, is_new_dogovor, is_msoff, is_opoff, black_print;
   MapStrSetInt MR;
   std::map<AnsiString, MapIntDouble> MRCoeffs;
   std::map<int, AnsiString> statusname, form_apo_ufo;
   std::set<int> prg_comfort, partner_sale_channel, mop_sale_channel;
   CalcInfo calc_info;
   UserInfo user_info;
   AnderInfo ander_info;
   TADOQuery *q_banks, *q_regions;

   // from old TOOLS.H
   int big_payment1;

   
//---------------------------------------------------------------------------
/*////////////////// STRUCTURES DIFFERENCE //////////////////////////////////

VehicleInfo{

   Variant brand_id, model_id;
   AnsiString vehicle_brand_name, vehicle_model_name, 
   vehicle_brand_name_print, vehicle_model_name_print;
   int vehicle_type_id, vehicle_group, is_registration_vehicle, 
   construction_year, is_new_vehicle, vehicle_age, res;
   AnsiString rsa_code, vin, body_number, chassis_number, 
   registration_mark, transdekra_id, inspection_id;
   int required_alarm_scheme, alarms[3], alarms_default[3], 
   is_trailer, is_gap, inspection_needed, inspection_status;

   int vehicle_registration_type_id;
   AnsiString registration_series, registration_number;
   TDateTime registration_issue_date, inspection_date;

   int allowed_mass, number_of_seats, engine_power_hp, 
   count_of_keys, usage_purpose_id, devices_state_id;
   double engine_volume;

   TADOQuery *q_brands, *q_models;

   
   // from old TOOLS.H
   int big_payment1;

//---------------------------------------------------------------------------
/*////////////////// STRUCTURES DIFFERENCE //////////////////////////////////
/* // NEW														// OLD
struct CalcInfo{                                                
double  kar, kr, kyu, bt, k1, k2,        // OLD
		k3, k4, k5, k6, k7,              // from old TOOLS.H
double  ka, ks, krs, kpr, kb, kkv,         double  kss_old
		kd, kfr, kbfprlg, kgap;                    kss_new
double  osn_risk_itog_tarif                        kss_sum_limit
        coef_prop                                  kss_premium_limit;
        old_premium_paid;                          kdiscount;
double  premiya_osn_risk                           payment1;
        premiya_dsago                              str_summa1
        premiya_all                                str_summa2
        premiya_ns                                 cost_vehicle_new;
        payed_sum                        
        premiya_dms                        double  anderr_summ_limit
        premiya_gap                                anderr_ka_limit;
        pnd_premium_exp                    double  coeff_limit;
        pnd_premium_tech;                  int     anderr_dsago
double  premiya_osn_risk_for_bp                    anderr_variant_b
        min_premiya_osn_risk                       risk_model
        cost_tdr                                   cross_error;
        cost_min                           std::map<int, double="">
        cost_max                           min_premium_ekonom, kpr_dtp;
        cost_vehicle                     // from old TOOLS.H
        old_cost_vehicle                 
        str_summa                        
        str_summa_ns                      CalcInfo()
        old_str_summa                     {
        old_premium                         // from old TOOLS.H
        paid                             	min_premium_ekonom[1] = 10000;
        payment_part[12]                 	min_premium_ekonom[2] = 15000;
        curr_limit                       	min_premium_ekonom[3] = 33000;
        claims_damages                   	min_premium_ekonom[6] = 8000;
        pnd_liability_exp                	min_premium_ekonom[7] = 8000;
        pnd_liability_tech;              	// from old TOOLS.H

std::map<AnsiString, int="">
  base_kv;
  std::map<int, AnsiString="">
    k1_fr;
    int liab_type, damage_limit, str_summa_dsago, str_summa_dms, type_of_calc;

*/








http://jira-rgs.rgs.ru:8080/browse/CKKII-3333

Замена в текущем модуле КАСКО Переоформление файла с вспомогательными функциями, константами и структурами на аналогичные файлы с вспомогательными объектами из модуля КАСКО-УФО (2.0) завершена до того уровня, что проект с обновлёнными файлами и объектами собирается.
Следующим этапом нужно будет пересмотреть те парамтеры, что остались внутри модуля из старой реализации, нужны ли они или удалить их, посмотреть какой функционал отпал или работает некорректно и нужно ли вносить изменения в БД модуля.





http://jira-rgs.rgs.ru:8080/browse/CKKII-3237
http://jira-rgs.rgs.ru:8080/browse/CKKII-3311
http://jira-rgs.rgs.ru:8080/browse/CKKII-3228



VehicleInfo
VehicleTdxInfo


VehicleInfo
TSInfo

#include "UReissCalc.h"
#include "UThreadK5.h"
#include "anderrpanel.h"

#include "UAddPermitted.h"
#include "UADevices.h"
#include "UPayment.h"


f_calc

/* //#include "UPayment1.h"
/* //#include "oldcalc.h"

/* //#include "newcalc.h"

Исправлена ошибка при  выдачае дубликата при переоформлении - корректная проверка срока действия договора (указанный договор теперь действителен до 23:59:59 той даты, что сохранена в БД) 


KASKO 
  #include "itogi.h"
  #include "mainwinfc.h"
  #include "anderrpanel.h"
  #include <SysUtils.hpp>
  #include <shlobj.h>
  #include "offerscust.h"
  #include "tools.h"
  #include <math.h>
  #include <DateUtils.hpp>
  
  #include "XML_progress_form_c.h"
  #include "UReissCalc.h"
  #include "UInfo.h"                                   
  #include "UDubl.h"
  #include "UReportParams.h"
  #include "UTypeDogovor.h"
  #include "UInfoRast.h"

DOP_UPR_FORM_C
CPP
  #include "tools.h"
  #include "DopUprFormC.h"
  
ITOGI

XML_Progress_Form_c

MAIN_WIN_FC
H
  #include "tools.h"

TRANSDECRA FUNCTIONS
CPP
  #include "Transdekra_funcs.h"
  #include "tools.h"

UIINFO

OFFERSCUST

UDubl

UReportParams

anderrpanel
CPP
 //#include "newcalc.h"
 #include "IAPO2_ARM_READER.h"
 #include <DateUtils.hpp>
 #include "UReissCalc.h"
H
 #include "tools.h"
 #include "UViewHistory.h"
 #include "TMops_api.h"

UAddPermitted
CPP
 #include "UThreadK5.h"
H
 #include "TMops_api.h"
 #include "tools.h"
 #include "SHDocVw_OCX.h"

UViewHistory

UThreadK5H
H
 #include "tools.h" 
 
UReissCalc
CPP
 #include "UThreadK5.h"
 #include "anderrpanel.h"
H 
 #include "UAddPermitted.h"
 #include "UADevices.h"
 #include "UPayment.h"
 #include "tools.h"
 
UADevices 
H 
 #include "tools.h"

UPayment 
CPP
 #include "UPayment.h"
 #include "UReissCalc.h"


 
 
  

  
  
  
Изменние алгоритма расчёта внутри модуля КАСКО Переоформление 

Внутри модуля КАСКО переоформление изменить логику авторизации договора.





































NS_ZASTR
id_zastr	Числовой
calc_id		Числовой
num			Числовой
sport		Логический
risk_object_type_id	Текстовый
address		Текстовый
phone_home	Текстовый
auto_summ_id Числовой

id_zastr	calc_id	num	str_summ	str_prem	sport	risk_object_type_id	first_name	second_name	last_name	full_name	phisical_birth_date	phisical_sex	phisical_sex_str	phisical_sex_indx	addr_mid	address	phone_home	phone_mobil	benefics	shares	benefics_str	auto_summ_id
340	28423	1	0	0	0		ЮРИЙ	ВЛАДИМИРОВИЧ	КУДИН	КУДИН ЮРИЙ ВЛАДИМИРОВИЧ	25.11.1959		М	-1	0			+7(926)333-22-11				0
341	28423	2	0	0	0		ЮРИЙ	ВЛАДИМИРОВИЧ	КУДИН	КУДИН ЮРИЙ ВЛАДИМИРОВИЧ	25.11.1959		М	-1	140							0
342	28424	1	0	0	0		ЮРИЙ	ВЛАДИМИРОВИЧ	КУДИН	КУДИН ЮРИЙ ВЛАДИМИРОВИЧ	25.11.1959			-1	0			+7(926)333-22-11				0


 ? новые договора ОСАГО ФЛ
 ? возобновление (пролонгацию) для ОСАГО ФЛ



http://confluence.rgs.ru:8080/pages/viewpage.action?pageId=136230837
см. в "ФОРМАЛИЗАЦИЯ ТРЕБОВАНИЙ" -> Описание требования №2.
В "1.Запрос списка СТОА:" среди параметров присуствует 


Банк получателя / Beneficiary's bank
Alfa-Bank, Moscow, Russia

SWIFT: ALFARUMM

Получатель / Beneficiary
Mr. Obrosov Pavel Aleksandrovich

Счёт получателя /
Beneficiary's Acc. number
40817978004280006830

Банк-корреспондент Банка получателя /
Correspondent bank of beneficiary`s bank
COMMERZBANK AG, Frankfurt am Main

SWIFT: COBADEFF

Счёт в банке-корреспонденте /
Acc. With corresp/ Bank number
400886894501EUR

Сумма перевода / Summ to send
8300 Euro



 - АНАЛИЗ БД
Прошу вас прислать Логи и Анализ БД. 
Инструкции содержатся в предыдущем с нашей стороны письме.



невозможно 

1,595,809
Ошибка в программе: Access violation at address 622E626E. Read of address 622E626E
1,582,857
Ошибка в программе: Access violation at address 01B86B0F. Write of address 00000052
1,585,248
1,590,820
1,596,946
Ошибка в программе: Access violation at address 00A6A807 in module 'mops_api.bpl'. Read of address 000000A1
1,584,074
Ошибка в программе: Access violation at address 0FCFBF43 in module 'OSAGO_187960.dll'. Read of address 000002F4
1,596,140
Ошибка в программе: Access violation at address 40005905 in module 'rtl60.bpl'. Read of address 6F4D5F20
1,596,325
Ошибка в программе: Access violation at address 0042CD49 in module 'APO2.exe'. Read of address 00000000
1,596,327
Ошибка в программе: Access violation at address 400F2E64 in module  'vcl60.bpl'. Read of address 00000004
1,590,601
Ошибка в программе: Access violation at address 40005905 in module 'rtl60.bpl'. Read of address 6F4D5F20
1,596,689
Ошибка в программе: Access violation at address 400058FE in module  'rtl60.bpl'. Read of address 0D8FBFD0
1,589,025
Ошибка в программе: Access violation at address 00A6A807 in module 'mops_api.bpl'. Read of address 000000A1
1,601,279
Ошибка в программе: Access violation at address 40005905 in module 'rtl60.bpl'. Read of address 6C61626F
1,595,022
Ошибка в программе: Access violation at address 40005905 in module 'rtl60.bpl'. Read of address 6C61626F
1,595,167
Ошибка в программе: Access violation at address 40005905 in module 'dbrtl60.bpl'. Read of address 00000030
1,594,900
Ошибка в программе: Access violation at address 40107DC3 in module 'vcl60.bpl'. Read of address 00000045
1,588,360
Ошибка в программе: Access violation at address 400058E2 in module 'rtl60.bpl'. Read of address 726F7453
1,593,571
Ошибка в программе: Access violation at address 40005905 in module 'rtl60.bpl'. Read of address 656D616E
1,596,193
Ошибка в программе: Access violation at address 40005905 in module  'rtl60.bpl'. Read of address 34303630
1,594,660
Ошибка в программе: Access violation at address 40005905 in module 'dbrtl60.bpl'. Read of address 00000030
1,598,139
Ошибка в программе: Access violation at address 4032F16E in module 'dbrtl60.bpl'. Read of address 00000000
1,596,540
Ошибка в программе: Access violation at address 40107DC3 in module 'vcl60.bpl'. Read of address 00000045
1,595,091
Ошибка в программе: Access violation at address 40005905 in module 'rtl60.bpl'. Read of address 6E696D64
1,598,266
Ошибка в программе: Access violation at address 0042CD25 in module 'APO2.exe'. Read of address 00000000
1,589,658
Ошибка в программе: Access violation at address 0042CD25 in module 'APO2.exe'. Read of address 00000000


1,594,660

ТЕ ЧТО Я МОЖЕТ БЫТЬ МОГУ РЕШИТЬ
1,590,848
1,598,379
1,601,403

1,584,000

ОСАГО
1,598,182

1,597,317




From:  Бойцова Юлия <boytsova@spb.rgs.ru>


Здравствуйте.

В АРО-2 в “Медицина/Клещ” агент дома ввел договор, при выходе из программы было сообщение о том, то договор успешно отправлен.
Но у нас в ДМС говорят, что ничего не получили. Почему такое может быть?

В АРО-2 в “Медицина/Клещ” агент дома ввел договор, при выходе из программы было сообщение о том, то договор успешно отправлен.
Но у нас в ДМС говорят, что ничего не получили. Почему такое может быть?


Юлия Бойцова

Начальник отдела поддержки пользователей

Управления информационных технологий


From:  Бойцова Юлия <boytsova@spb.rgs.ru>


Здравствуйте.

В АРО-2 в “Авто/ОСАГО” частая ситуация, когда при переоформлении ОСАГО программа ругается на адрес собственника.
Надо подтвердить его, а для этого надо заново запросить договор для переоформления, чтобы отметить изменение данных собственника.
Например, договор ЕЕЕ 0392639508 от 15.12.16

Юлия Бойцова







From:  Алиева Рабия Лютвали кызы <rlalieva@tyumen.rgs.ru>


*При расчете нового договора, идет расчет 20 минут. Компьютер 
перезагружала, АПО тоже, но окончательный расчет не выдает*







#ifdef OSAGO_KBM_IGNORE_WARNING
//       int res;
//       m_api->Raise_Error_Warning(res, this, 0, cRegLockErr, cRegLockErr, 0, PRARM, "<ОСАГО>", lock);
#endif
Синхронизацию проводил 28 февраля 2017 Порубов Максим Викторович

From:  МОП1 Губахинский отдел <45908110.mop1@perm.rgs.ru>


Добрый день,
При внесении изменений в договоры ОСАГО программа неверно расчитывает
итоговую премию и соответственно сумму доплаты.
Прилагаю образ экрана: в этом случае премия итого должна быть 4348.61
и сумма доплаты 1304.58



-- 
С уважением,Брежнева Марина Викторовна
 Менеджер офисных продаж Страховой отдел в г. Губаха 
г.Губаха, ул. газеты "Правда", 19
 Филиал ПАО "Росгосстрах" в Пермском крае
 
(248)40460


ОГРАНИЧЕНИЕ ОТВЕТСТВЕННОСТИ
Данное письмо может содержать конфиденциальную информацию.Если данное письмо попало к вам по ошибке, пожалуйста,
сообщите об этом отправителю. Любое распространение данного письма третьим лицам, включающее печать,
хранение, публикацию и копирование запрещено. ООО "Росгосстрах" не несет ответственности за любое несанкционированное
оиспользование сведений, содержащихся в письме.



From:  МОП1 Губахинский отдел <45908110.mop1@perm.rgs.ru>


Добрый день,
При внесении изменений в договоры ОСАГО программа неверно расчитывает
итоговую премию и соответственно сумму доплаты.
Прилагаю образ экрана: в этом случае премия итого должна быть 4348.61
и сумма доплаты 1304.58



-- 
С уважением,Брежнева Марина Викторовна
 Менеджер офисных продаж Страховой отдел в г. Губаха 
г.Губаха, ул. газеты "Правда", 19
 Филиал ПАО "Росгосстрах" в Пермском крае
 
(248)40460


ОГРАНИЧЕНИЕ ОТВЕТСТВЕННОСТИ
Данное письмо может содержать конфиденциальную информацию.Если данное письмо попало к вам по ошибке, пожалуйста,
сообщите об этом отправителю. Любое распространение данного письма третьим лицам, включающее печать,
хранение, публикацию и копирование запрещено. ООО "Росгосстрах" не несет ответственности за любое несанкционированное
оиспользование сведений, содержащихся в письме.


Жиры, которые надо переназначить на Олега (у меня не достаточно привелегий)

1) http://jira-rgs.rgs.ru:8080/browse/CKKII-3010
7.4.25 - Загрузка справочника в "Переформление КАСКО"

2) http://jira-rgs.rgs.ru:8080/browse/CKKII-3049
7.4.20, 21, 24, 25 - Загрузка справочника в "Переформление КАСКО"
7.4.22, 23 - Загружались ранее в Фортуне Авто, в новой фортуне не используются и их загрузка закоменчена 

3) http://jira-rgs.rgs.ru:8080/browse/CKKII-3081
7.4.25 (см. 2)) - Загрузка справочника в "Переформление КАСКО"
7.6.37 - Загрузка справочника в "Переформление КАСКО"

4) http://jira-rgs.rgs.ru:8080/browse/CKKII-3171
7.4.20, 21, 24, 25 - Загрузка справочника в "Переформление КАСКО"
7.4.22, 23 - Загружались ранее в Фортуне Авто, в новой фортуне не используются и их загрузка закоменчена 
7.6.37 - Загрузка справочника в "Переформление КАСКО"


0) моё - http://jira-rgs.rgs.ru:8080/browse/CKKII-3039
∙ 7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры ОСАГО ЮЛ
∙ 7.9.25 Справочник клиентов по Бизнес-ОСАГО 
∙ 7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 
1) = 1) Олег
2) = 2) Олег
3) моё - http://jira-rgs.rgs.ru:8080/browse/CKKII-3056
7.5.5 Справочник "Связи серий и типов БСО"
4) = 3) Олег
5) моё - http://jira-rgs.rgs.ru:8080/browse/CKKII-3085
∙ 7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры ОСАГО ЮЛ
∙ 7.9.25 Справочник клиентов по Бизнес-ОСАГО 
∙ 7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 
∙ 7.7.96 Справочник защищённых страхователей ЮЛ для сегментации ОСАГО ЮЛ
6) = 4) Олег
7) моё - http://jira-rgs.rgs.ru:8080/browse/CKKII-3128
7.1.61 (Справочник спецпродавцов ОСАГО)


Обноление справочников:
- 7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры ОСАГО ЮЛ
- 7.9.25 Справочник клиентов по Бизнес-ОСАГО 
- 7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 

/////////////////////////////////////////////////////////////////////////////////
ОСАГО:
-7.1.61 -G- gl_dict_special_agent_7_1_61 - Справочник "спецпродавцов ОСАГО"

7.4.20 - gl_dict_autodealer - Cправочник "Автодилеры"
7.4.21 - gl_dict_autodealer_company - Cправочник "Привязка автодилеров к филиальной сети Компании"
7.4.24 - gl_dict_otherpartner - Справочник "Прочие партнеры"
7.4.25 - gl_dict_otherpartner_company - Проект справочника "Привязка прочих партнеров к филиальной сети Компании"

int Universal_Func(AnsiString command, void* lparam, void* hparam)
        if(command=="Загружаем справочник из СКК (Первый параметр - код справочника AnsiString*, api СКК можно получить функцией glDic_Get_SKK_API)")
        {

                else if(NumSpr=="7.4.20")
                        ReloadSpr7_4_20(m_api,pSKK);
                else if(NumSpr=="7.4.21")
                        ReloadSpr7_4_21(m_api,pSKK);
                else if(NumSpr=="7.4.24")
                        ReloadSpr7_4_24(m_api,pSKK);
                else if(NumSpr=="7.4.25")
                        ReloadSpr7_4_25(m_api,pSKK);


                else if(NumSpr=="7.9.25")
                        ReloadSpr7_9_25(m_api,pSKK);
                else if(NumSpr=="7.9.24")
                        ReloadSpr7_9_24(m_api,pSKK);
                else if(NumSpr=="7.9.26")
					



O-7.4.24 -G-Х- gl_dict_otherpartner - Справочник "Прочие партнеры"
O-7.4.25 -G-Х- gl_dict_otherpartner_company - Проект справочника "Привязка прочих партнеров к филиальной сети Компании"
+ПЕРЕОФОРМЛЕНИЕ КАСКО
O-7.4.21 -G-Х- gl_dict_autodealer_company - Cправочник "Привязка автодилеров к филиальной сети Компании"
O-7.4.20 -G-Х- gl_dict_autodealer - Cправочник "Автодилеры"

-7.9.24 -L- OSAGO_R_7_9_24 - Справочник сотрудников РГС, сопровождающих спец. договоры ОСАГО ЮЛ
-7.9.25 -L- OSAGO_R_7_9_25 - Справочник клиентов по Бизнес-ОСАГО 
-7.9.26 -L- OSAGO_R_7_9_26 - Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 

ФОРТУНА АВТО
-7.7.82 -G-Х- gl_dict_7_7_82_fortuneavto - Справочник страховых сумм и премий по продуктам Фортуна Авто 
v 7.7.82 тарифы фортуна авто
<Product key="dict-7-7-82" name="Справочник страховых сумм и премий по продуктам Фортуна-Авто" text="Обновление справочника прошло успешно." emails="ivan_katerburgsky@rgs.ru" folders="AVTO;osago_dsago_kasko_to_ns_report;OSAGO_KASKO_GC_Flat_VZR_NS_NPF;OSAGO_R;RGS_Bank;Roznitsa" />

	  
-7.4.23 -L- osopo_leasingcompany_company - Cправочник "Привязка лизинговых компаний к филиальной сети Компании"
-7.4.22 -L- osopo_leasingcompany - Справочник "Лизинговые компании"

-7.5.4  -G- gl_dict_7_5_4_blank_series - Справочник "Серии БСО"
-7.5.5  -G- gl_dict_7_5_5_blank_types_series_relation - Справочник "Связи серий и типов БСО"

КАСКО:
O-7.6.37 -G-Х- gl_dict_banks - Справочник "Банки"
 х7.7.96 -   - в апо-2 не используется - Справочник "3ащищённых страхователей ЮЛ для сегментации ОСАГО ЮЛ"
/////////////////////////////////////////////////////////////////////////////////

Обновлены справочники:
- 7.4.20 Справочник "Автодилеры"
- 7.4.21 Справочник "Привязка автодилеров к филиальной сети Компании"
- XXX 7.4.22 Справочник "Лизинговые компании"
- XXX 7.4.23 Справочник "Привязка лизинговых компаний к филиальной сети Компании"
- 7.4.24 Справочник "Прочие партнеры"
- 7.4.25 Проект справочника "Привязка прочих партнеров к филиальной сети Компании"

Обновлены справочники: 7.4.20, 7.4.21, 7.4.22, 7.4.23, 7.4.24, 7.4.25


Обновлены справочники:
7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры  ОСАГО ЮЛ
7.9.25 Справочник клиентов по Бизнес-ОСАГО 
7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО

Обновлены справочники: 7.9.24, 7.9.25, 7.9.26 


Обновлён справочник
7.7.82 Справочник страховых сумм и премий по продуктам Фортуна Авто

Обновлён справочник
7.1.61 (Справочник спецпродавцов ОСАГО)

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////






13.03.2017 г.
Синхронизация и обновление
 АПО-2
∙ 7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры ОСАГО ЮЛ
∙ 7.9.25 Справочник клиентов по Бизнес-ОСАГО 
∙ 7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 

53_006/17ДРПП 09.03.2017 Обновление справочников:
7.4.25 Проект справочника 'Привязка прочих партнеров к филиальной сети Компании'
синхронизация АРМ, ЕКИС, АПО-2

53_007/17ДРПП 13.03.2017 Обновление справочников:
7.4.25 Проект справочника 'Привязка прочих партнеров к филиальной сети Компании'
7.4.21 Cправочник 'Привязка автодилеров к филиальной сети Компании'
7.4.20 Cправочник 'Автодилеры'
7.4.23 Cправочник 'Привязка лизинговых компаний к филиальной сети Компании'
7.4.22 Справочник "Лизинговые компании"
7.4.24 Справочник "Прочие партнеры"
синхронизация АРМ, ЕКИС, АПО-2

30_043/17ОД   14.03.2017   7.5.4 Справочник "Серии БСО"
 7.5.5 Справочник "Связи серий и типов БСО"
СН6136 и 6032 к 5134 Полис ф. 5034 Фортуна «Авто» - К (1) однослойный и квитанция ф. А-7

53_008/17ДРПП  16.03.2017   Обновление справочников:
7.4.25 Проект справочника 'Привязка прочих партнеров к филиальной сети Компании'
7.6.37 Справочник «Банки»
синхронизация АРМ, ЕКИС, АПО-2

 30_007/17БКС
 16.03.2017 г.
 Синхронизация и обновление
 АПО-2
∙ 7.9.24 Справочник сотрудников РГС, сопровождающих спец. договоры  ОСАГО ЮЛ
∙ 7.9.25 Справочник клиентов по Бизнес-ОСАГО 
∙ 7.9.26 Справочник полномочий по сопровождению клиентов по Бизнес-ОСАГО 
∙ 7.7.96 Справочник защищённых страхователей ЮЛ для сегментации ОСАГО ЮЛ

53_009/17ДРПП   23.03.2017   Обновление справочников:
 7.4.25 Проект справочника 'Привязка прочих партнеров к филиальной сети Компании'
7.4.21 Cправочник 'Привязка автодилеров к филиальной сети Компании'
7.4.20 Cправочник 'Автодилеры'
7.4.23 Cправочник 'Привязка лизинговых компаний к филиальной сети Компании'
7.4.22 Справочник "Лизинговые компании"
7.4.24 Справочник "Прочие партнеры"
7.6.37 Справочник «Банки»
синхронизация АРМ, ЕКИС, АПО-2

21_133/17ДА 21.03.2017 Синхронизация АПО2 и InsBridge со справочником 7.1.61 (Справочник спецпродавцов ОСАГО)
/////////////////////////////////////////////////////////////////////////////////





1) Заявка - 1,597,575 - Убрана проверка и предупредительное сообщение внутри Авто-Осаго-Возврат по КБМ - Проверка на чёрные списки.
2) Доработано - Добавлена проверка у Собственника на серию/номер и корректность длинны в обоих текстбоксах в случае когда они не пусты (аналогично Страхователю).







Исправления: 1) Сохранение галки "Согласен на СМС рассылку" в БД. 2) Исчезновение списка Застрахованных при смене пользователя, при кроссировании.
Работа с Аналитиком и уточнение требований по доработке.
1) Исправление с верно выводящимися сообщениями для серии/номера док-та удост.личность  2) переписан INSERT для обновления записей в базе с Пустыми номером/серией док-та удост.личность 


2635343

0268029589




Исправления: 1) Сохранение галки "Согласен на СМС рассылку" в БД. 2) Исчезновение списка Застрахованных при смене пользователя, при кроссировании.




#ifdef DOC_SER_CHECK


6002

2635340


Полис ф.1-ЮЛ двухслойный	4020	Выдан агенту / менеджеру	Беспалова Татьяна Ивановна	00328267



#include "form_general.h"
#define DOC_SER_CHECK 0


MainWinFC
   if (!(   MYGLOBAL::is_general
         || MYGLOBAL::gEditType & 2 // При изменении данных по договору с основанием = «Изменение данных страхователя»
         || MYGLOBAL::gEditType & 8 // При изменении данных по договору с основанием = «Изменение данных собственника»
      ))
   {


   
	  



Сборка с отсуствующей проверкой на номер и серию документа для ЮЛ 1) При изменении данных по договору с основанием = «Изменение данных страхователя» 2) «Изменение данных собственника» 3) тоже реализовано в форме генерального договора




   MYGLOBAL::is_general = q->FieldByName("general_id")->AsInteger > 0;

   if (MYGLOBAL::is_general) {
        TSPurpose->ItemIndex = TSPurpose->IndexOf("Прочие");

		

1) Проблема с полом страхователя и застрахованных решена, как хранение в БД модуля, так и часть с выгрузкой в Отчёт Ф113. 2) В печатные формы один Застрахованный не равный страхователю выводится верно. 


C:\C_Libraries\cpprestsdk\Release\include;

C:\C_Libraries\cpprestsdk\Release\libs;

C:\C_Libraries\cpprestsdk\Release\src;



6002

1757824

1757803

 для серии
 4000

Номер бланка
3974843
ИНН для ЮЛ
7816196304










Рассылка HQ Privatelife <hq_privatelife@rgs.ru>; от имени; Гусева Екатерина В. <ekaterina_guseva@rgs.ru>

Сборка с пересозданной таблицей nszastrah с корректным значением пола. Сборка будет работать корректно только после изменений в Модуле Отчёта Ф113.


Внесено изменение для обработки Пола страховтеля, для корревтной работы выгрузки в XML в Форме Ф113




      if(!(q->FieldByName("phisical_sex")->AsString.IsEmpty())) { pm[index].sex = (q->FieldByName("phisical_sex")->AsInteger) ? "Æ" : "Ì"; }
      pm[index].sex_indx    = !(q->FieldByName("phisical_sex")->AsString.IsEmpty()) ? q->FieldByName("phisical_sex")->AsInteger : -1;

	  
	  





Исправлено затирание серии квитанции, при выборе Наличного расчёта и Квитанции А7. Теперь при переоткорытии договора серия не стирается.
Файл новой сборки прикреплён к таску "modul-fortuna-avto-2017-03-10_.sbr"





 для серии
 4000

Номер бланка
3974843
ИНН для ЮЛ
7816196304






Обновил отображение правильной даты оплаты премии для обоих случаев Нал/Безнал во всех печатных формах
Файл новой сборки прикреплён к таску "modul-fortuna-avto-2017-03-12.sbr"

nspaytype

m_api->Fill_ComboBox_Int(res, cboxPayment, "select type_id,type_name from nspaytype order by type_name");


gl_dict_7_4_33_payment_doc_type

AnsiString sqlSelect;
if( idx == 1 || idx == 2)
{sqlSelect = "select payment_doc_id, payment_doc_name from gl_dict_7_4_33_payment_doc_type where payment_doc_id in (5,10) order by payment_doc_name";}
m_api->Fill_ComboBox_Int(res, cboxPaymentDoc, sqlSelect);


1,582,517



МОСКОВСКИЙ БАНК РЕКОНСТРУКЦИИ И РАЗВИТИЯ
ВСЕРОССИЙСКИЙ БАНК РАЗВИТИЯ РЕГИОНОВ


ФА - 1. поправлен баг в кроссировании с учётом маски серии паспорта 2. исправления печатных форм. 1) Телефоны страхователя помещаются полностью 3 штуки, 2) данные о банке посреднике помещаются в полисе 3) организован перенос длинного наименования страхователя ЮЛ/ФЛ на вторую строчку, как в полисе так и в заявлении для ЮЛ. 
Внесена дополнительная правка, на печатной форме Заявления для ЮрЛиц, чтобы наименоване ЮрЛица помещалось в правом верхнем углу формы


123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899
0,42
9,00
4,02 - 5,64
11,00

0,42
0
4,44
20,00

ЗАЯВЛЕНИЕ ДЛЯ ЮРЛИЦ
[StretchFont(Memo7, IIF((<UserData."insur_status"> =1), <UserData."insur_full_name">, <UserData."insur_last_name">+' '+ <UserData."insur_first_name">+' '+<UserData."insur_second_name">))]





[StretchFont(Memo48,<UserData."insur_phone_contact"> + '  ' + <UserData."insur_phone_mobil"> + '  ' + <UserData."insur_phone_home">)]


[IIF(<UserData."avto_count_zastr">=1,StretchFont(Memo70,<UserData_2."phone_home">+' '+<UserData_2."phone_mobil">),'- - - - - - - - - - - - - - - - - - - - - - -')]

+79265551144 +79991232211 +74951112233

2,10
4,90



Решено: 1) Проблема при кроссировании, 2) ОГРН – для ЮЛов длина 13 цифр, а ОГРНИП для ИП длина 15 цифр

Решено: 1) Проблема при кроссировании, 2) ОГРН – для ЮЛов длина 13 цифр, а ОГРНИП для ИП длина 15 цифр

На вкладке «Описание расчета» в модуле Фортуна Авто скрыта кнопка «Печать». Исправлены опечатки в сообщениях об ошибках ввода. В кроссах добавлена обработка и процесс копирования ОГРН из других продуктов.


Исправлен баг с дублированием списка документов при открытии заключённого договора. Отображение надписи для ИП, как "ОРГНИП" исправлено. На вкладке «Описание расчета» в модуле Фортуна Авто скрыта поправлен вывод страховой суммы. 

Из списка ДУЛ для Заявителя убран тип документа="Свидетельство о внесении записи в Единый гос.реестр" 

Исправление в печатной форме для отображерния длинных ФИО внутри полей подписантов, внесено исправления, чтобы функционал работал корректно на всех 4-ёх печатных формах типа "Отказ".



  2. В письме от 23.11.2016 вы утверждалои, что у вас на руках присуствует разрешение на списание средств
моей подзащитной, которая по вашему утверждению давала вам право на списание специального налога.
Если в своих показаниях вы ссылаетесь на посланную вами копию документа от 31.12.2003 
то из него вы можете чётко и дасловно увидеть, что она не имеет достоточной юридической силы
для совершения, списания специального налога, которое является предметом данного спора, 
по причине того, что разрешение на списание средств ограничивается лишь ежемесячной оплатой ЖКУ
(жилищно комунальных услуг). 
  По сему, если вы не располагаете каким-либо другим разрешением на списание средств, то я вынужден
уже сегодня вас настоятельно призвать к тому, чтобы вы осуществили перевод в размере 10.518,00 Евро
соответсвенно до 06.01.2017 на мой вышеобозначенный счёт.
  3. Что касается сбора дебиторской задолженности вам необходимо обратиться к владельцам жилплощади
Госпоже Рут Михельс, Катрин Пасс и Инес Трогш, чьи адреса вы можете посмотреть в выписке из поземельной книги.
 


 
            Настоящим подтверждаем, что [UserData."otkazdate"] года поступило обращение - [<UserData."strah_f">] [<UserData."strah_i">] [<UserData."strah_o">], дата рождения - [UserData."strah_date_rojd"] года [iif(nopasp==1,"","(документ, удостоверяющий личность - " + <UserData."strah_docum"> + ", серия "+<UserData."strah_doc_ser">+", номер " +<UserData."strah_doc_num">+", выдан (кем, когда) "+<UserData."strah_doc_vidan"> + " " + DateToStr(<UserData."strah_doc_date">))], регистрация: [UserData."strah_adr"]. Данные о транспортном средстве: [iif(notspasp==1,"",<UserData."ts_doc_type">+" серии "+<UserData."ts_PTS_ser">+" номер "+<UserData."ts_PTS_num">+" выдан "+DateToStr(<UserData."ts_PTS_date">)+" года,")] марка, модель ТС - [<UserData."ts_marka">] [<UserData."ts_model">][iif(Length(<UserData."ts_gosznak">)>1,", регистрационный знак - "+ <UserData."ts_gosznak">,"")][iif(Length(<UserData."ts_vin">)>1,", идентификационный номер (VIN) "+ <UserData."ts_vin">+",","")] категория ТС - [UserData."ts_kategor"], год выпуска - [UserData."ts_god"][iif(Length(<UserData."ts_kuzov">)>1,", кузов № - " +<UserData."ts_kuzov">,"")][iif(Length(<UserData."ts_shassi">)>1,", шасси № - "+<UserData."ts_shassi">,"")].
	Обращаем Ваше внимание, что в соответствии с требованиями ст. 10.1 Федерального закона № 40-ФЗ от 25.04.2002 г. «Об обязательном страховании гражданской ответственности владельцев транспортных средств»:
«При заключении договора обязательного страхования в целях расчета страховой премии и проверки данных о наличии или отсутствии страховых выплат, а также проверки факта прохождения технического осмотра страховщик использует информацию, содержащуюся в автоматизированной информационной системе обязательного страхования, созданной в соответствии со статьей 30 настоящего Федерального закона, и информацию, содержащуюся в единой автоматизированной информационной системе технического осмотра. Заключение договора обязательного страхования без внесения сведений о страховании в автоматизированную информационную систему обязательного страхования, созданную в соответствии со статьей 30 настоящего Федерального закона, и проверки соответствия представленных страхователем сведений содержащейся в автоматизированной информационной системе обязательного страхования и в единой автоматизированной информационной системе технического осмотра информации не допускается».
В момент Вашего обращения за заключением договора ОСАГО автоматизированная информационная система обязательного страхования не доступна и договор обязательного страхования не может быть заключен, т.к. у представителя страховщика, к которому вы обратились за заключением договора ОСАГО, отсутствует техническая возможность проверить информацию о наличии или отсутствии страховых выплат и факта прохождения технического осмотра транспортного средства, указанного Вами в Заявлении на страхование, а также ему не представляется возможным внести сведения о заключаемом договоре обязательного страхования в автоматизированную информационную систему обязательного страхования.

Внесено изменение в печатную форму. ФИО подписантов в конце формы (шрифт) рсширяется или уменьшается, в зависимости от длины вводимых ФИО так, чтобы не уходить за пределы текстового поля


<UserData."strah_o">


[StretchFont(Memo8,<UserData."strah_f"> +" "+ <UserData."strah_i"> +" "+ <UserData."strah_o"> )] 
[StretchFont(Memo9,<UserData."fio_agent"> )] 


[StretchFont(Memo202,<UserData."project_name">)] 

function StretchFont(m:TfrxMemoView;s:String):String;
var      
       i:Extended;
       btmp:TBitmap;
       f:boolean;
       flowto:TFrxMemoView;
       LastMemoView:TfrxMemoView;
       fs:Integer;                               
begin
      fs:=5;              
       btmp:=TBitmap.Create();
       LastMemoView:=m;                                                                           
       f:=false;
       flowto:=TfrxMemoView(m.FlowTo);
         i:=m.Width-m.ParagraphGap-m.GapX;
        while flowto<> nil do
        begin                    
               i:=i+flowto.Width-flowto.ParagraphGap-flowto.GapX;
               flowto:= TFrxMemoView(flowto.FlowTo);                                                             
        end;                  
         
         i:=i*0.96; //                                                                                                                                               


         
while not f do
begin
               btmp.Canvas.Font:=m.Font;
               if((btmp.Canvas.TextWidth(s)<i) or (m.Font.Size<=fs)) then           
                     f:=true
               else
                    begin                              
                      m.Font.Size:=m.Font.Size-1;
                      flowto:=TFrxMemoView(m.FlowTo);                                                                                  
                     while flowto<> nil do
                        begin                    
                                flowto.Font.Size:=flowto.Font.Size-1;
                                lastmemoview:=flowto;                                                                                
                                flowto:= TFrxMemoView(flowto.FlowTo);                                    
                        end;                       
                    end;                                                      
end;          
btmp.Free();
if(m.Font.Size<=fs) then
       lastmemoview.WordWrap:=true;                                                            
result:=s;                                  
end;

/////////////////////////////////////////////////////////

{

 svyaz_s_RSA.Visible =  <UserData."typeotkaz"> == 0;                          
 ne_komplekt.Visible =  <UserData."typeotkaz"> == 1;
 ts_neosmotr.Visible =  <UserData."typeotkaz"> == 2;
 net_doverennosti.Visible =  <UserData."typeotkaz"> == 3;


 String s="";
 String doc = <UserData."nodoc">;
 int nopasp=0;
 int notspasp=0;     
 if( copy(doc,1,1) == "1" ) {
   s = " заявление о заключении договора обязательного страхования,";
 }          
 if( copy(doc,2,1) == "1" ) {
   nopasp=1;                 
   s += " паспорт или иной удостоверяющий личность документ (если страхователем является физическое лицо),";
 }  
 if( copy(doc,3,1) == "1" ) {
   s += " свидетельство о государственной регистрации юридического лица (если страхователем является юридическое лицо),";
 }  
 if( copy(doc,4,1) == "1" ) {
   notspasp=1;                                                
   s += " паспорт транспортного средства или  свидетельство о регистрации транспортного средства, технический паспорт или технический талон либо аналогичные документы),";
 }  
 if( copy(doc,5,1) == "1" ) {
   s += " водительское удостоверение или копии водительского удостоверения  всех лиц, допущенных к управлению транспортным средством,";
 }  
 if( copy(doc,6,1) == "1" ) {
   s += " диагностическая карта,";
 }

 SetLength(s, Length(s)-1);                                                           

}



String StretchFont(TfrxMemoView& m, String s)                  
{
       double i;
       TBitmap btmp = TBitmap.Create;
       //bool f = false;
       TFrxMemoView flowto = TFrxMemoView(m.FlowTo);
             
       i = m.Width - m.ParagraphGap - m.GapX;
       while (flowto)
       {                    
               i = i + flowto.Width - flowto.ParagraphGap - flowto.GapX;
               flowto = TFrxMemoView(flowto.FlowTo);                                                             
       }
             
       while (true)
       {
               btmp.Canvas.Font = m.Font;
               if((btmp.Canvas.TextWidth(s)<i)||(m.Font.Size<=6))
               {                   
                     break;  
               }                                          
               else
               {                   
                       m.Font.Size = m.Font.Size-1;
                       flowto = TFrxMemoView(m.FlowTo);                                                                                  
                       while (flowto)
                       {                    
                               flowto.Font.Size = flowto.Font.Size-1;
                               flowto = TFrxMemoView(flowto.FlowTo);                                    
                       }                       
               }                                                                                             
       }          
       return s;                                  
}  


//////////////////////////////////////////




//////////////////////////////////////////////////////////////
////////////////////// 2017 1-ЮЛ полис Фортуна АВТО(черновик)
  
// FROM OSAGO
function DateToStrM(dt:TDateTime):String;
var
       temp:String;
       month :integer;                                                   
begin
   //temp:=FormatDateTime('dd',dt);
   temp:= '';
     
   month:=StrToInt(FormatDateTime('mm',dt));
   case month of
   1: temp:=temp+' Января ';    
   2: temp:=temp+' Февраля ';
   3: temp:=temp+' Марта ';
   4: temp:=temp+' Апреля ';
   5: temp:=temp+' Мая ';
   6: temp:=temp+' Июня ';
   7: temp:=temp+' Июля ';
   8: temp:=temp+' Августа ';
   9: temp:=temp+' Сентября ';
   10: temp:=temp+' Октября ';       
   11: temp:=temp+' Ноября ';
   12: temp:=temp+' Декабря ';       
   end;                     
  // temp:=temp + FormatDateTime('yyyy',dt);                                                                                    
   Result:=temp;
end;

  
function StretchFont(m:TfrxMemoView;s:String):String;
var      
       i:Extended;
       btmp:TBitmap;
       f:boolean;
       flowto:TFrxMemoView;
       LastMemoView:TfrxMemoView;
       fs:Integer;                               
begin
      fs:=5;              
       btmp:=TBitmap.Create();
       LastMemoView:=m;                                                                           
       f:=false;
       flowto:=TfrxMemoView(m.FlowTo);
         i:=m.Width-m.ParagraphGap-m.GapX;
        while flowto<> nil do
        begin                    
               i:=i+flowto.Width-flowto.ParagraphGap-flowto.GapX;
               flowto:= TFrxMemoView(flowto.FlowTo);                                                             
        end;                  
         
         i:=i*0.96; //                                                                                                                                               


         
while not f do
begin
               btmp.Canvas.Font:=m.Font;
               if((btmp.Canvas.TextWidth(s)<i) or (m.Font.Size<=fs)) then           
                     f:=true
               else
                    begin                              
                      m.Font.Size:=m.Font.Size-1;
                      flowto:=TFrxMemoView(m.FlowTo);                                                                                  
                     while flowto<> nil do
                        begin                    
                                flowto.Font.Size:=flowto.Font.Size-1;
                                lastmemoview:=flowto;                                                                                
                                flowto:= TFrxMemoView(flowto.FlowTo);                                    
                        end;                       
                    end;                                                      
end;          
btmp.Free();
if(m.Font.Size<=fs) then
       lastmemoview.WordWrap:=true;                                                            
result:=s;                                  
end;

//////////////////////////////////////////////////////////////
// ФА 2016
var    
   strah :boolean; //1 если застрахован сам страхователь
   allprem:Integer;//общая страх прем.                                            
   allsum:Integer;//общая страх сумм
   rcount:Integer;//кол-во записей
   index_for:Integer;                                         
begin

//Line1.Visible:=<UserData."insur_is_face">=0;

//Page2.Visible := <UserData."sale_channel_id"> <> 135; //РГС-БАНК                                                                                 
       
strah:=false;

//rcount := MasterData1.DataSet.RecordCount;                                                          
rcount := <UserData."avto_count_zastr">;                                                          
  
  
// MasterData1.DataSet.First;
// while(not MasterData1.DataSet.Eof) do
// begin
//    if( <UserData_3."insur_strah"> = 1 )then begin//застрахован сам страхователь
//        Memo81.Text := 'X';//FormatFloat('### ###',<UserData_3."strahprem">);
//        Memo90.Text := FormatFloat('### ###',<UserData_3."strahprem">);           
//        strah:=true;                                 
//        end                 
//    else begin 
//        Memo82.Text := 'X';//FormatFloat('### ###',<UserData_3."strahprem">);
//        Memo91.Text := FormatFloat('### ###',<UserData_3."strahprem">);                    
//    end;             
// 
//    allprem := allprem + <UserData_3."strahprem">;
//    allsum := allsum + <UserData_3."strahsum">;                                                     
//   
//   MasterData1.DataSet.Next;                        
// end;                                
// 
// //Если страхователь и 1застр лицо просто перекладываем из мемо82 в мемо91 премию                                                                                                              
// //if( (rcount =2) and (strah=true) ) then begin Memo91.Text := FormatFloat('### ###',<UserData_3."strahprem">);//Memo82.Text; Memo82.Text := '- - - - - - - - - - - -'; 
// //       end;
//       
// //Если застрахованных 2 но нет самого страхователя т.е. просто два каких то лица
// //или если больше 2х                                                 
// //4)	Если застрахованных лиц 2 и более составляется список застрахованных лиц идентично реализованному в действующем модуле Фортуны АВТО:    
// if( (rcount > 2) or ((rcount = 2) and (strah=false)) ) then
// begin
//   Memo82.Text := 'согласно списку';         
//   Memo91.Text := Memo82.Text;
//   Memo81.Text := '- - - - - - - - - - - - - - - - - - - - - - -';                                          
// end;          


//if( rcount=1 ) then Memo53.Text := <UserData_3."famil">+' '+<UserData_3."name">+' '+<UserData_3."otch">;                                      

////Memo96.Text :=  FormatFloat('### ###', allsum);
////Memo99.Text :=  FormatFloat('### ###', allprem);    
  
if( strah=true ) then Line1.Visible:= false;

if( length(<UserData."insur_inn">)=0 ) then //для физ.лиц галку не ставим                                                                              
       CheckBox1.Checked := false;                                                                        
    
        
//end.


///////////////////////////////////////////////////////////////////
//begin

Line1.Visible:=<UserData."insur_is_face">=0;
MasterData1.DataSet.First;

////////////////////////////////////////////////////while(not MasterData1.DataSet.Eof)do
for index_for := 0  to rcount-1 do
begin
       if( <UserData."insur_is_face"> = 1 )then begin//застрахован сам страхователь
        Memo81.Text := 'X';//FormatFloat('### ###',<UserData_3."strahprem">);
        Memo90.Text := FormatFloat('### ###',<UserData_2."str_prem">);           
        strah:=true;
        end                 
    else begin 
        Memo82.Text := 'X';//FormatFloat('### ###',<UserData_3."strahprem">);
        Memo91.Text := FormatFloat('### ###',<UserData_2."str_prem">);
     end;

    allprem := allprem + <UserData_2."str_prem">;
    allsum := allsum + <UserData_2."str_summ">;         
  
//       if(<UserData_4."num">=1) then
//         begin
//               Memo80.Text:=FormatFloat('###,###,###',<UserData_4."sm">);
//               //Memo89.Text:=FormatFloat('###,###,###',<UserData_4."prem">);                                             
//         end;                   
//    
//       if(<UserData_4."num">=2) then
//         begin
//               //Memo83.Text:=FormatFloat('###,###,###',<UserData_4."sm">);
//               //Memo92.Text:=FormatFloat('###,###,###',<UserData_4."prem">);                                             
                   
////////////////////////////////////////////////////    MasterData1.dataSet.Next;
end;          

//Если страхователь и 1застр лицо просто перекладываем из мемо82 в мемо91 премию
//if( (rcount =2) and (strah=true) ) then 
//begin
//  Memo91.Text := FormatFloat('### ###',<UserData_3."strahprem">);
//  Memo82.Text := '- - - - - - - - - - - -';
//end;
if( (((rcount = 2) and (strah=true))) ) then
begin
  Memo53.Text := 'Согласно приложенному к Полису списку';         
//  Memo91.Text :=  allprem;
//  Memo90.Text :=  allprem;
  Memo91.Text := Memo90.Text; // str_prem                       
  Memo82.Text := Memo81.Text; // X         
end;
  
//Если застрахованных 2 но нет самого страхователя т.е. просто два каких то лица
//или если больше 2х                                                 
//4)	Если застрахованных лиц 2 и более составляется список застрахованных лиц идентично реализованному в действующем модуле Фортуны АВТО:    
if( (rcount > 2) or ((rcount = 2) and (strah=false)) ) then
begin
  Memo82.Text := 'согласно списку';         
  Memo91.Text := Memo82.Text;
  Memo81.Text := '- - - - - - - - - - - - - - - - - - - - - - -';                                          
end;
  
  
  
end.









    select distinct
       t.terr_id
      ,t.terr_name
     from
       gl_dict_regions t
       left join gl_dict_7_7_82_fortuneavto f
       on t.terr_id = CInt(f.KLADR)
     where
       f.TO_7783_FK
       in (1,2,3,50926060)
     and f.start_date <= Date()
     and f.end_date >=Date()
  group by t.terr_id
  order by t.terr_name




Убрана проверка обязательности полей "Серия", "Номер", "Дата выдачи" Для случая когда 1. тип страхователя =ЮЛ  И 2. тип документа="Свидетельство о внесении записи в Единый гос.реестр". Если вышеупомянутые данные пусты, то договор для ЮЛ можно распечатать.

 для серии
 4000

Номер бланка
3974843
ИНН для ЮЛ
7816196304



[iif( (typeotkaz==3 and and and strah_docum=="Свидетельство о внесении записи в единый государственный реестр"),"","(д...)]








































Lebenslauf

Persönliche Daten

Adresse:			Rajevskogo Str. 3, 121151 Moskau
Telefon:			+7(926)386-2556, +7(926)714-3724
E-Mail:				mobelus@gmail.com
Geburtsdatum / -ort:		06.07.1986 / Moskau
Familienstand:		verpartnert, keine Kinder
Staatsangehörigkeit:		Russisch

Berufliche Erfahrung

05/2016 – bis heute		C++ Leading Developer 
RGS GROUP OAG, Moskau	
•	Entwicklung und Unterstützung von einem CAM-System vorbestimmt für Berechnungen der Versicherungslebensmittel. Entwicklung von GUI und Backend auf C++ in C++ Builder und mit MFC-Framework in MS Visual Studio 2013
•	Stack von Technologien: FastReport für Bildung der Druckformen, XML, SQL-Anforderungen, Datenbanken - Access, MS SQL, Oracle

04/2015 – 05/2016		C++ Softwareentwickler 
Encore GmbH, Moskau	
•	Entwicklung und Unterstützung eines Windows- Benutzerauthentifizierungssystem (Credential Provider, WinAPI, CryptoAPI)
•	Entwicklung von Bibliotheken und Windows-Services die private Benutzer-Informationen spechern und bearbeiten. (Token Zugriff und etc.)
•	Entwicklung von Integritätkontrollsystem von Dateien und Windows-Registrierungsdatenbank. In diesem Projekt habe ich persönlich - Teile von GUI auf QT entwickelt und den Teil für Integritätkontrolle von Registrierungsdatenbank auf mich genommen

12/2012 – 04/2015		C++ Softwareentwickler
Symbol-Design GmbH, Moskau
•	Entwicklung von Software für verschiedene Geräte wie Densitometer, Controller u.a.
•	GUI-Programmierung (MFC, BCGP, Qt) von (Multi-Thread) Client-Server Applikationen und deren Komponente, auf Basis von OPC-Protokoll und COM, DCOM Techniligien

•	Unterstützung von einem CAM-System für Fixierung von Erdölleck auf der Erdölleitung und deren Anteile, so wie auch von Buchhaltungserfassung und Dokumentendurchlauf Systemen auf Tankläger (C, C++, C#)
•	Entwicklung von Utility auf der Client-Seite für Arbeit mit der Datenbank MSSQL Server
•	Erstellung der Betriebsdokumentation

10/2007 – 07/2008		Junior C/C++ Entwickler (Betriebspraktikum) 
Kaspersky GAG (Kaspersky Lab), Moskau
•	Entwicklung und Debuggen von einzelnen Teilen verschieder Projekte: C++, asm, JavaScript
•	Analyse von Antivieren-Software und Programmieren von Suchalgorithmen

11/2006 – 08/2012		IT-Administrator für Windows Systeme 
Lamaneks GmbH, Moskau
•	technischer Ansprechpartner für Mitarbeiter
•	Administration von Windows Systemen sowohl virtualisierte als auch reale Systeme
•	Einrichtung lokaler Netze innerhalb des Unternehmens
•	schriftliche und mündliche Kommunikation mit Kollegen in der deutschen und englischen Sprache

Studium und Ausbildung

09/2004 – 02/2010		Studium der Computersicherheit
				Moskauer Staatliches Institut für Elektronik und Mathematik – 				technische Universität (MIEM TU), Moskau
Studienschwerpunkte: Kryptographie, Wahrscheinlichkeitstheorie, Methoden des Informationsschutzes, Programmierung von Datenschutzalgorithmen
Thesis-Thema: “Analyse der statistischen Kriterien zur Prüfung der Hypothese hinsichtlich der gleichmäßigen Verteilung der Reihenfolgen, die auf Eigenschaften der zufälligen Substitutionen basieren“ (Note 4,0 von 5,0 Punkten)
Abschluss: Mathematiker (Fachrichtung Datenschutz)
Abschlussnote: 4,0 von 5,0 Punkten

09/1993 – 06/2004		Abitur
Höhere Schule № 1283 mit erweitertem Deutschunterricht,  	Moskau
				Abschlussnote: 4,2 von 5,0 Punkten


Weiterbildung

03/2016			Linux (Ubuntu). Level 2: C development on Linux
				«Specialist» Computer Training Center, in Moskau
08/2011			TELC Zertifikat DEUTSCH C1 (Note 3)
				Sprachkurs in der Sprachschule PROLOG in Berlin
08/2006			TestDaF (LV 4, HV 4, SA 4, МA 5) Zeugnisnummer: 040759
				Deutschkurs am Humboldt-Institut e.V. in Ratzenried
09/2003 – 07/2004		Deutsches Sprachdiplom der Kultusministerkonferenz Stufe 2
				Sprachniveau: B2. (höhere Schule № 1283 in Moskau)

Besondere Kenntnisse

EDV-Kenntnisse		• С, С++, С#, Objective-C, assembler, HTML, JavaScript, Delphi
				• OPC, COM, DCOM, ATL, ADO, QML • WinAPI
				• STL, Boost, MFC, QT, BCGP, tinyXML, MSXML, crypt++
				• MS Builder 6.0, Visual Studio 2010, 2012, 2013
				• MySQL, MSSQL
				• Git
				• Microsoft Office 2010, LaTex
Sprachkenntnisse		Russisch (Muttersprache), Deutsch (fließend), Englisch (fließend)
Führerschein			internatioal, Klasse B

Hobbys & Interessen

Hobbys			Entwicklung von Mobilen-Apps, Photografie, Videobearbeitung, 				







КАСКО - Переоформление

void TFReissCalc::Recalc()
{
...
   Error("Не указана(ы) причина(ы) переоформления договора", ++error_num, VarToStr(vg_Reason->Properties->Value) == empty_str);
	
}

void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesInitPopup(TObject *Sender)
{
   last_reasons = VarToStr(vg_Reason->Properties->Value);
}

void __fastcall TFReissCalc::Reason_CheckComboBoxPropertiesCloseUp(TObject *Sender)
{
   if(vg->InplaceEditor) vg->InplaceEditor->PostEditValue();
   AnsiString val = VarToStr(vg_Reason->Properties->Value);

void TFReissCalc::LoadFrame(TADOQuery *q_load)
{
   AnsiString memo_text("");
...   
   m_api->dbCloseCursor(res, q_reasons);
   AnsiString strReasons = ";" + last_reasons;
   if(!last_reasons.IsEmpty()) vg_Reason->Properties->Value = static_cast<TVariant>(strReasons);




   
   

   перехода из пользовательского ре жима в режим ядра (а он отнимает не менее 1000 такюв
   
Пока ресурс занят или пока не произошло "особое событие", система переводит поток в ждущий режим, исключая его из числа планируемых, и берет на себя роль агента, действующего в интересах спящего потока Она выведет его из ждущего ре жима, когда освободится нужный ресурс или произойдет "oco6oc событие"
Большинство потоков почти постоянно находится в ждущем режиме И когда си стема обнаруживает, чю все потоки уже несколько минут спят, срабатывает механизм управления электоропитанием

volatile — без нсго рабо тa моей программы просто немыслима Он сообщает компилятору, что переменная может быть изменена извне приложения — операционной системой, аппаратным устройством или другим потоком. 
Точнее, спецификатор volatile заставляет компиля тор исключить эту переменную из оптимизации и всегда перезагружать ее значение из памяти. 


Критическая секция (critical section) — это небольшой участок кода, требующий мо нопольного доступа к каким-то общим данным. Она позволяет сделать так, чтобы единовременно только один поток получал доступ к определенному ресурсу 

Преимущество критических секций в том, что они просты в использовании и выполняются очень быстро, так как реализованы на основе Interlocked-функций А главный недостаток — нельзя синхронизировать потоки в разных процессах. 
структурa struct CRITICAL_SECTION   

•	Если значения элементов структуры указывают на то, что ресурс занял другим потоком, EnterCriticalSection переводит вызывающий поток в режим ожидания. Это потрясающее свойство критических секций: поток, пребывая в ожидании, не тратит ни кванта процессорного времени Система запоминает, что данный поток хочет получить доступ к ресурсу, и - как только поток, занимавший этот ресурс, вызывает LeaveCriticalSection — вновь начинает выделять нашему пото ку процессорное время При этом она передает ему ресурс, автоматически обновляя элементы структуры CRITICAL_SECTION

Чем она действительно ценна, так это способно стью выполнять их на уровне атомарного доступа. Даже если два потока на много процессорной машине одновременно вызовут EnterCriticalSection, функция все равно корректно справится со своей задачей: один пошк получит ресурс, другой — перей дет в ожидание.


В действительности потоки, ожидающие освобождения критической секции, никогда не блокируются «навечно» EnterCriticalSection устроена так, что по истечении определенного времени, генерирует исключение. После этого Вы можете подключить к своей программе отладчик и посмотреть, что в ней слу чилось. Длительность времени ожидания функцией EnterCriticaiSection опреде ляется значением параметра CriticalSectionTimeout, который хранится в следу ющем разделе системного реестра:
HKEY_LOCAL_MACHlNE\System\CurrentControlSet\Control\Session Manager
   


   
Поддержка пользователей продукта АПО2.
Обработка заявок и вопросов от пользователей, получение пользователями помощи и нужных инструкций, для поддержания корректной работы программы.

Разработка и доработка программного обеспечения.
Написание и отладка кода программ, необходимых заказчику. Реализация задач по разработке и доработке, поступающие от вышестоящего начальства.



Could not convert variant of type (String) into type (Double)
1,550,274

ОШИБКА !!! Данные не записаны. ФП2_НС
1,553,742

Access violation at address 4032F16E in module 'dbrtl60.bpl'. Read of address 00000000
1,553,706
1,553,958




gl_dict_7_4_9_blank_types

число
SCC_ID
текст
BLANK_TYPE_NAME
текст
BLANK_TYPE_ID
DATE_TO
DATE_FROM

текст
BLANK_TYPE_ID
текст
BLANK_TYPE_NAME
число
A7_FOR_BLANK
DATE_FROM
DATE_TO



nscalc
nsmemo
nsbso
nszastr
nsrisktypes

nsbenefic
nsopf
nsdoctype

nsdict_7_4_9_blank_types_a7_14849


key:
dict-7-4-33
dict-blank-series-types-and-products
report-fortuna-avto

name:
Справочник типов платёжных документов(СКК 7.4.33)
Справочники типов и серий бланков их связей и связка типов бланков с продуктами (СКК 7.4.9, 7.5.4, 7.5.5, 7.10.16)
Отчет агента ф.113м для Фортуна Авто 3.0

<Product key="dict-5-4-11" name="Справочник операторов технического осмотра(СКК 5.4.11)" text="Обновление справочника прошло успешно." emails="" folders="AVTO;osago_dsago_kasko_to_ns_report;OSAGO_KASKO_GC_Flat_VZR_NS_NPF;OSAGO_R;RGS_Bank;Roznitsa" />      
<Product key="dict-autodealer-and-other" name="Справочники автодилеров и прочих партнёров и их связка с регионами (СКК 7.4.20, 7.4.21, 7.4.24, 7.4.25)" text="Обновление справочника прошло успешно." emails="" folders="AVTO;osago_dsago_kasko_to_ns_report;OSAGO_KASKO_GC_Flat_VZR_NS_NPF;OSAGO_R;RGS_Bank;Roznitsa;GreenCard;NPF;Gost" />
<Product key="report" name="Отчет агента" text="Обновление модуля прошло успешно." emails="" folders="AVTO;osago_dsago_kasko_to_ns_report;RGS_Bank;Roznitsa;NPF;NPF2;Gost;MHDTP_Guest" />



 для серии
 4000

Номер бланка
3974843
ИНН для ЮЛ
7816196304



clearFIOandBirthDate
ClearDataPermitted
ReplaceDataPermitted


void TFrame1::ReplaceDataPermitted(const int index_dest, const int index_source)
void TFrame1::ClearDataPermitted(const int index_clear)


pm


НЕУЧТЁНОЧКИ И ОПАСНОСТИ
- fillComboBoxSeries:
 // (!!!) ВНИМАНИЕ  gl_dict_terr_osago_kasko  - не обнавляется автоматически
 //       если расширится список территорий преимущественного использования,
 //       или селекты использующие эту таблицу будут возвращать НУЛИ,
 //       перепроверьте хватает ли в ней записи и если нет, длобавьте вручную

-Paste()
 // (!!!) ВНИМАНИЕ  Различить Физлицо и ИП невозможно из-за особенности формата XML
 //       Формат XML документа, благодаря которому осуществляется перенос данных из одного модуля в другой,
 //       для Страхователя, Собственника и др. не предусматривает возможности различать Физических лиц и 
 //       Индивидуального Предпринимателя (ИП). ИП считается за Физическое лицо. То есть формат различает
 //       только Юр.лиц и Физ.лиц (ИП считаются Физ.лицами).

 
Уже созданные Записи в Фортуне стоит пересохранить, и перевыбрать: наим. юр-лица, ФИО страхователя (представителя), пол, гражданство, галочку смс, тип документа, перевыбрать и сохранить адрес в КЛАДР.

ЛОГИКА ТАКАЯ: В случае копирования из ОСАГО 1+2 в ФА
Если ФЛ (ИП) - Копируем ФИО Страхователя
Если ЮЛ - Наименование ЮЛ передаём в Фамилии Страхователя, Имя и Отчество оставляем пустыми (поэтому ФИО страхователя будут пусты ... таков формат)

Из ОСАГО 1+2 НЕ будет доходить Гражданство.
Требуется доработка 1 - не заполняется в формате XML
Требуется доработка 2 - не заполняется в формате XML
 
Из ОСАГО 2 у страхователя не отправляются телефоны дом.+раб.
Требуется доработка на стороне ОСАГО 2.0

Из ОСАГО 2 не доходит ПОЛ 
Пола в модуле у страхователя просто нет

Из ОСАГО 1+2 не доходит ОГРН 
Требуется доработка 1 - ОГРН отсуствет в модуле
Требуется доработка 2 - ОГРН не заполняется в формате XML
















// GOOD OLD WORKING PASTE
bool Paste(const AnsiString &XMLData)
{
#if 1
	long calc_id = m_api->dbInsert_Empty_Calc(res); // вставляется полностью пустая запись
	if (calc_id <= 0) return false;

	_di_IXMLDocument XMLDoc = NewXMLDocument();
	XMLDoc->LoadFromXML(XMLData);
	if (m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\fortuna_avto_paste.xml");

	//XMLDoc->LoadFromFile(m_api->Excel_tmp_path + "\\fortuna_avto_paste.xml");
	//if (m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\fortuna_avto_paste.xml");

	XMLDoc->Active = true;
	XMLDoc->Options.Clear();
	XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;
	XMLDoc->Version = "1.0";
	XMLDoc->Encoding = "WINDOWS-1251";
	XMLDoc->StandAlone = "no";
	XMLDoc->NodeIndentStr = "         ";
	_di_IXMLNode Root, node1, node2, node3, node4, node5;

    // Start Parsing our XML
	Root = XMLDoc->DocumentElement;
	if (!Root) return false;

	AnsiString sql("update nscalc set ");
	m_api->dbExecuteQuery(res, "insert into nscalc (calc_id) values (" + IntToStr(calc_id) + ")");


// Set default parameters for FORTUNA_AVTO
    //Выставляем Территорию преимущественного использовагния Всем по умолчанию Москву,
    // чтобы при вставке после открытия фрейма комбобокс не был пустым. Пусть перевыбирают просто.
	sql = sql + "territory_id = '0',";

    sql = sql + "program_name =" +"'Авто',";
	sql = sql + "program_id ="   +"0,";
	//sql = sql + "code_prod ="    +"7000000,";
	//sql = sql + "name_prod ="    +"'7000000 ЦО РГС-Фортуна Авто (на условиях Пр.26)',";


	////node1 = Root->ChildNodes->FindNode("region");
	////sql = sql + "calc_territor_isp_obl='" + node1->Text + "',";

	//NN код региона +11нулей
	//   sql = sql + "kladr='" + node1->Attributes["code"] + "00000000000',"; // code 77  =    7700000000000  регион-Москва

	////node1 = Root->ChildNodes->FindNode("city");
	//if (node1) sql + "calc_territor_isp_ter='" + node1->Text + "',";


	node1 = Root->ChildNodes->FindNode("sale_channel");
	int sale_id = AnsiString(node1->Attributes["code"]).ToIntDef(0);
	sql = sql + "sale_channel='" + m_api->dbGetStringFromQuery(res, "select name_kanal from gl_dict_kanal_prodag where id=" + IntToStr(sale_id)) + "',";
	sql = sql + "sale_channel_id=" + IntToStr(sale_id) + ",";

/*
	node1 = Root->ChildNodes->FindNode("ts");
	node2 = node1->ChildNodes->FindNode("type_ts");
	if (!node2->Text.IsEmpty()) { //если данные о тс есть
	//...
		sql = sql + " pol_zayav_ts_PTS_date=" + m_api->Internal_Convert_Date_To_SQL(res, node2->Attributes["issue_date"]) + ",";
	}
//*/

	//аналитика
	node1 = Root->ChildNodes->FindNode("sale");
	int autoid(0), bankid(0), otherid(0);
	//if (TryStrToInt(node1->ChildNodes->FindNode("car_dealer")->Attributes["code"], autoid))
	//	sql = sql + "autodealer_id=" + IntToStr(autoid) + ",";
	if (TryStrToInt(node1->ChildNodes->FindNode("bank_partner")->Attributes["code"], bankid))
		sql = sql + "bank_id=" + IntToStr(bankid) + ",";
	//if (TryStrToInt(node1->ChildNodes->FindNode("other_partner")->Attributes["code"], otherid))
	//	sql = sql + "other_partner_id=" + IntToStr(otherid) + ",";

	//if ((autoid + bankid + otherid)>0)
	//	sql = sql + "partner_analiz=true,";

	sql = sql.Delete(sql.Length(), 1); // Удаляем последнюю запятую !!!
	m_api->dbExecuteQuery(res, sql + " where calc_id=" + IntToStr(calc_id));


	//участники страхования
	//int count_dop(0);
	int count_benefics(0),count_ins(0), count_persons(0);
	int insur_addr_memo_id(0), zastr_addr_memo_id(0);
	AnsiString insur_f, insur_i, insur_o, insur_bdate, insur_sex;
	AnsiString sobst_f, sobst_i, sobst_o, sobst_bdate, sobst_sex;
	//AnsiString zastr_f, zastr_i, zastr_o, zastr_bdate;
	node1 = Root->ChildNodes->FindNode("persons");
	node2 = node1->ChildNodes->FindNode("person");
    std::map<unsigned int, bool> mapOfPersonHash;
    std::map<unsigned int, bool>::iterator itOfPersonHash;

	while (node2)
	{
		int code = AnsiString(node2->Attributes["code"]).ToIntDef(0);

		// Сначала добавим страхователя в свою таблицу
		if ((code & 4) == 4) //нашли страхователя
		{
			sql = "update nscalc set ";
			AnsiString contacts("");

			if ((code & 2) == FIZ_LIZO) //физлицо +ИП
			{
			    insur_i = AnsiString(node2->ChildNodes->FindNode("first_name")->Text);
   		    	insur_f = AnsiString(node2->ChildNodes->FindNode("last_name")->Text);
			    insur_o = AnsiString(node2->ChildNodes->FindNode("second_name")->Text);
                insur_bdate = m_api->Internal_Convert_Date_To_SQL(res, AnsiString(node2->ChildNodes->FindNode("physical_bitrh_date")->Text), false);
				insur_sex = AnsiString(node2->ChildNodes->FindNode("physical_sex")->Text);

				sql = sql + "insur_last_name =   '" + insur_f + "',"; //f + "',";
			    sql = sql + "insur_first_name =  '" + insur_i + "',"; //i + "',";
			    sql = sql + "insur_second_name = '" + insur_o + "',"; //o + "',";
				sql = sql + "insur_full_name =   '" + insur_f + " " + insur_i + " " + insur_o + "',";
				sql = sql + "insur_birth_date = "   + insur_bdate + ",";
				//sql = sql + "insur_birth_date = " + m_api->Internal_Convert_Date_To_SQL(res, AnsiString(node2->ChildNodes->FindNode("physical_bitrh_date")->Text), false) + ",";

				if (code & 4) //person  =страхователь физ.лицо
				{
					sql = sql + "insur_nationality ='" + node2->ChildNodes->FindNode("citizenship")->Text + "',";
					node3 = node2->ChildNodes->FindNode("documents");

					//sql = sql + "polis_date = " + m_api->Internal_Convert_Date_To_SQL(res, str, false) + ",";
					sql = sql + "insur_document_issue_org = '" + AnsiString(node3->ChildNodes->FindNode("document_issue_organization")->Text) + "',";

                    AnsiString str = AnsiString(node3->ChildNodes->FindNode("document_issue_date")->Text);
					sql = sql + "insur_document_issue_date = " + m_api->Internal_Convert_Date_To_SQL(res, str, false) + ",";
				}

                AnsiString strSex(insur_sex);
                if( !(strSex.IsEmpty() || strSex=="-1") )
                { strSex = (strSex == one_str) ? AnsiString("Ж") : AnsiString("М"); } // чтобы по умолчанию или если пусто, то выставлялся "М"
                else
                {strSex = "";}
            	sql = sql + "insur_sex_str = '" + strSex + "',";
				insur_sex = insur_sex.IsEmpty() ? AnsiString("-1") : insur_sex;
				sql = sql + "insur_sex_indx = " + insur_sex + ",";

				//sql = sql + "insur_sex_str = " + node2->ChildNodes->FindNode("physical_sex")->Text
				//	//(AnsiString(node2->ChildNodes->FindNode("physical_sex")->Text) == null_str ? AnsiString("М") : AnsiString("Ж"))
				//	+ ",";

				// (!!!) ВНИМАНИЕ  Различить Физлицо и ИП невозможно из-за особенности формата XML
                //
                AnsiString strINN = AnsiString(node2->ChildNodes->FindNode("inn")->Text);
				//sql = sql + "insur_inn = '" +strINN+ "',";
                //if( !strINN.IsEmpty() ) // Физлицо +ИП (ибо ИП это Физлицо с заполненным ИНН)
				//{ sql = sql + "insur_status = " +IntToStr(FIZ_IP)+ ","; }
                //else // Физлицо (у обычгного физлица ИНН пуст)
				//{ sql = sql + "insur_status = " +IntToStr(FIZ_LIZO)+ ","; }
				sql = sql + "insur_status = " +IntToStr(FIZ_LIZO)+ ",";
			}
			else if ((code & 2) == 2) //юрлицо
			{
				sql = sql + "insur_full_name = '" + AnsiString(node2->ChildNodes->FindNode("last_name")->Text) + "',";
				//sql = sql + "insur_yur_name = '" + AnsiString(node2->ChildNodes->FindNode("last_name")->Text) + "',";
				sql = sql + "insur_inn = '" + AnsiString(node2->ChildNodes->FindNode("inn")->Text) + "',";
				sql = sql + "insur_status = " +IntToStr(JUR_LIZO)+ ",";
			}

			//КЛАДР
			node3 = node2->ChildNodes->FindNode("addresses");
			std::auto_ptr<TStringList> addr(new TStringList());
			addr->Values["Кнопка"] = "Ок";
			addr->Values["Код Кладр"] = node3->ChildNodes->FindNode("code_kladr")->Text;
			addr->Values["Фильтр Регион"] = node3->ChildNodes->FindNode("filter_kladr")->Text;
			addr->Values["Государство"] = node3->ChildNodes->FindNode("country")->Text;
			addr->Values["Регион"] = node3->ChildNodes->FindNode("region")->Text;
			addr->Values["Район"] = node3->ChildNodes->FindNode("area")->Text;
			addr->Values["Город"] = node3->ChildNodes->FindNode("place")->Text;
			//         addr->Values["Поселок"] = node3->ChildNodes->FindNode("place")->Text;
			addr->Values["Индекс"] = node3->ChildNodes->FindNode("zip")->Text;
			addr->Values["Улица"] = node3->ChildNodes->FindNode("street")->Text;
			addr->Values["Дом"] = node3->ChildNodes->FindNode("house")->Text;
			addr->Values["Номер корпуса"] = node3->ChildNodes->FindNode("building")->Text;
			addr->Values["Квартира"] = node3->ChildNodes->FindNode("flat")->Text;

			insur_addr_memo_id = m_api->dbGenerateId(res, "nsmemo");
			m_api->dbReadWriteInternalMemo(res, addr->Text, insur_addr_memo_id, false, "nsmemo");
			sql = sql + "insur_addr_mid = " + IntToStr(insur_addr_memo_id) + ",";

			sql = sql + "insur_address = '" + AnsiString(node3->ChildNodes->FindNode("exact_address")->Text) + "',";
			sql = sql + "insur_adr_index='" + AnsiString(node3->ChildNodes->FindNode("zip")->Text) + "',";
			sql = sql + "insur_adr_gos_vo='" + AnsiString(node3->ChildNodes->FindNode("country")->Text) + "',";
			sql = sql + "insur_adr_kr_obl='" + AnsiString(node3->ChildNodes->FindNode("region")->Text) + "',";
			sql = sql + "insur_adr_raion='" + AnsiString(node3->ChildNodes->FindNode("area")->Text) + "',";
			sql = sql + "insur_adr_nas_punkt='" + AnsiString(node3->ChildNodes->FindNode("place")->Text) + "',";
			sql = sql + "insur_adr_ulitsa='" + AnsiString(node3->ChildNodes->FindNode("street")->Text) + "',";
			sql = sql + "insur_adr_dom='" + AnsiString(node3->ChildNodes->FindNode("house")->Text) + "',";
			sql = sql + "insur_adr_korpus='" + AnsiString(node3->ChildNodes->FindNode("building")->Text) + "',";
			sql = sql + "insur_adr_kvartira='" + AnsiString(node3->ChildNodes->FindNode("flat")->Text) + "',";

			//документ страхователя
			node3 = node2->ChildNodes->FindNode("documents");
			//sql = sql + "pol_zayav" + field + "docum='" + m_api->dbGetStringFromQuery(res, "select tip_doc from OSAGO_R_tip_doc where id_tip_doc=" + node3->ChildNodes->FindNode("document")->Attributes["code"]) + "',";
			//sql = sql + "pol_zayav" + field + "doc_ser='" + AnsiString(node3->ChildNodes->FindNode("document_series")->Text) + "',";
			//sql = sql + "pol_zayav" + field + "doc_num='" + AnsiString(node3->ChildNodes->FindNode("document_number")->Text) + "',";

			//AnsiString sqlSelect = "select tip_doc from OSAGO_R_tip_doc where id_tip_doc=" + node3->ChildNodes->FindNode("document")->Attributes["code"];

            //AnsiString docCode = "'"+ node3->ChildNodes->FindNode("document")->Attributes["code"] +"'";
			//AnsiString sqlSelect = "select payment_doc_id from gl_dict_7_4_33_payment_doc_type where is_use_pay_virtu = " + docCode ;
			//sql = sql + "insur_document_type_id = " + m_api->dbGetStringFromQuery(res, sqlSelect) + ",";

            AnsiString strNormalizedDocSeries = AnsiString(node3->ChildNodes->FindNode("document_series")->Text);
            strNormalizedDocSeries = NormalizeStr(strNormalizedDocSeries);
			sql = sql + "insur_document_series  = '" + strNormalizedDocSeries + "',";
            AnsiString strNormalizedDocNumber = AnsiString(node3->ChildNodes->FindNode("document_number")->Text);
            strNormalizedDocNumber = NormalizeStr(strNormalizedDocNumber);
			sql = sql + "insur_document_number  = '" + strNormalizedDocNumber + "',";

			//телефоны
			node3 = node2->ChildNodes->FindNode("contacts");

			node4 = node3->ChildNodes->First();
			int ii(0);
			while (node4)
			{
				if (TryStrToInt(node4->Attributes["contact_type_id"], ii))
				{
                    AnsiString strNormalizedPhoneNumber;
					switch (ii)
					{
					case 1:
                      strNormalizedPhoneNumber = node4->Attributes["contact_data"];
                      //strNormalizedPhoneNumber = NormalizeStr(strNormalizedPhoneNumber);
                      sql = sql + "insur_phone_home = '" + strNormalizedPhoneNumber + "',";
                    break;
					case 2:
                      strNormalizedPhoneNumber = node4->Attributes["contact_data"];
                      //strNormalizedPhoneNumber = NormalizeStr(strNormalizedPhoneNumber);
                      sql = sql + "insur_phone_mobil = '" + strNormalizedPhoneNumber + "',";
                    break;
					case 3:
                      if ((code & 4) && !AnsiString(node4->Attributes["spam"]).IsEmpty()) //страхователь контакт моб.тел (согл. на смс рассылку?)
					    sql = sql + "sms_sending=" + node4->Attributes["spam"] + ",";

                      // нормализуем именно этот номер, ибо он записывается потом в 2 отдельных поля "КОД(3 ц.)" и "НОМЕР(7 ц.)"
                      strNormalizedPhoneNumber = node4->Attributes["contact_data"];
                      strNormalizedPhoneNumber = NormalizeStr(strNormalizedPhoneNumber);
					  sql = sql + "insur_phone_contact = '" + strNormalizedPhoneNumber + "',";
					break;
					case 5:
					  if (code & 4) //email страхователя
					    sql = sql + "insur_email_contact = '" + node4->Attributes["contact_data"] + "',";
					break;
					}
				}
				node4 = node4->NextSibling();
			}

			sql = sql.Delete(sql.Length(), 1); // Удаляем последнюю запятую !!!

            //sql = sql + " insur_email_contact = 'check@mail.ru'";
            sql = sql + " where calc_id=" + IntToStr(calc_id);
            m_api->dbExecuteQuery(res, sql);
		}
		//*
		// После добавим в таблицу с застрахованными
		// 4 - страхователя в застрахованных
		// 8 - собственника в застрахованных
		// 32 - допущенный к управлению в застрахованных
		if (((code & 4) == 4) || ((code & 8) == 8) || ((code & 32) == 32))
		{
			//std::auto_ptr<TStringList*> addr(new TStringList());
			TStringList* addr = new TStringList();
			MakeKladrAddr(node2, addr, zastr_addr_memo_id); //генерим zastr_addr_memo_id, т.к. в nscalc_insur_memo у нас хранится memo_id только для страхователя, для всех сотальных надо генерить
            delete addr; //нужен только на момент генерации zastr_addr_memo_id

			bool doAddPerson = true;
			//AnsiString fname, lname, sname, strBirthDate, strSex;
			AnsiString person_fname, person_lname, person_sname, person_birthday, person_sex;
			person_fname = AnsiString(node2->ChildNodes->FindNode("first_name")->Text);
			person_lname = AnsiString(node2->ChildNodes->FindNode("last_name")->Text);
			person_sname = AnsiString(node2->ChildNodes->FindNode("second_name")->Text);
			person_birthday = AnsiString(node2->ChildNodes->FindNode("physical_bitrh_date")->Text);
   			person_sex = AnsiString(node2->ChildNodes->FindNode("physical_sex")->Text);

			// Только у Страхователя и Собственника есть статус Физ.Лицо=0 / Юр.Лицо=1 / ИП=2, в застрахованных
			// можно добвлять только Физ.Лиц, потому проверяем Физ.Лица ли Страх. и Собств., остальных мы автоматом считаем Физ.Лицами
			if ( ((code & 4) == 4) || ((code & 8) == 8) )
			{
				// Страхователь / Собственник НЕ Физлицо => НЕ добавляем в застрахованных
				if ((code & 2) == 2) //Юрлицо (только Юрлиц не добавляем)
                {
                  doAddPerson = false;
                }

				// У Страхователя / Собственника должен быть заполнен ФИО + ДР + Пол, иначе НЕ добавляем его
				if (person_fname.IsEmpty() && person_lname.IsEmpty() && person_sname.IsEmpty() && person_birthday.IsEmpty() && person_sex.IsEmpty())
				{
                  doAddPerson = false;
                }
			}

		    if ((code & 8) == 8) // заносим информацию от Собственника
			{sobst_i = person_fname, sobst_f = person_lname, sobst_o = person_sname, sobst_bdate = person_birthday, sobst_sex = person_sex;}


			if ((code & 2) == FIZ_LIZO) // Физлицо
            {
              //Для Физлиц (и ИП) мы должны добавлять только неповторяющихся по ФИО+ДР
              unsigned int hash_FIO_BD = hash(person_lname + person_fname + person_lname + person_birthday);
              itOfPersonHash = mapOfPersonHash.find(hash_FIO_BD);
              if(itOfPersonHash == mapOfPersonHash.end())
              {
                mapOfPersonHash[hash_FIO_BD]=true; // не нашли => уникален => добавляем
              }
              else
              {
                mapOfPersonHash[hash_FIO_BD]=false;  // дубликат
                doAddPerson = false;
              }
            }

            //*
			// ни один из застрахованных не должен совпадать с Страхователем или Собственником по ФИО + ДР
			// если нашлось совпадение, то не добавляем эту персону, оставляя именно Страхователя, ибо он в приоритете
			if (((code & 4) != 4)) // Обходим страхователя с этой проверкой, иначе проверим самого с собой
			{
			if (person_fname == insur_i && person_lname == insur_f   && person_birthday == insur_bdate)
			{
              //т.к. отчество необязательное, то проверяем его, только если оно заполнено
			  if (!person_sname.IsEmpty() && !insur_o.IsEmpty())
			  {
				  if (person_sname == insur_o)
				  {
                    doAddPerson = false;
                  }
			  }
			  else
              {
                doAddPerson = false;
              }
			}

			if (((code & 8) != 8)) // Обходим сравнение с собственником, чтобы не сравнивать его с самим собой
            {
			if (person_fname == sobst_i && person_lname == sobst_f   && person_birthday == sobst_bdate)
			{
              //т.к. отчество необязательное, то проверяем его, только если оно заполнено
			  if (!person_sname.IsEmpty() && !sobst_o.IsEmpty())
			  {
				  if (person_sname == sobst_o)
				  {
                    doAddPerson = false;
                  }
			  }
			  else
              {
                doAddPerson = false;
              }
			}
            }

			}
            //*/

            if(doAddPerson)
            {
			count_ins++;
			long id_zastr = m_api->dbGenerateId(res, "nszastr");
			//m_api->dbExecuteQuery(res, "insert into osago_r_dop_k_upr (kbm,avar,calc_id,num_dop_upr) values('3','0'," + IntToStr(calc_id) + "," + IntToStr(count_dop) + ")");
			//TADOQuery *qw = m_api->dbGetCursor(res, "select * from nszastr where id_zastr=-1", 0, 1);
			sql = " update nszastr set ";
	        m_api->dbExecuteQuery(res, "insert into nszastr (calc_id, num) values (" + IntToStr(calc_id) +" , "+ IntToStr(count_ins) +")" );

			sql = sql + "id_zastr =" + IntToStr(id_zastr) +",";
			sql = sql + "calc_id =" + IntToStr(calc_id) + ",";
			sql = sql + "num =" + IntToStr(count_ins) + ",";
			sql = sql + "str_summ =" + FloatToStr(0.0) + ",";
			sql = sql + "str_prem =" + FloatToStr(0.0) + ",";

			sql = sql + "first_name='" + person_fname + "',";
			sql = sql + "last_name='" + person_lname + "',";
			sql = sql + "second_name='" + person_sname + "',";
			sql = sql + "full_name='" + person_lname + " " + person_fname + " " + person_sname + "',";
			sql = sql + "phisical_birth_date=" + m_api->Internal_Convert_Date_To_SQL(res, person_birthday, false) + ",";

			AnsiString strSex(person_sex);
            if( !(strSex.IsEmpty() || strSex=="-1") )
            { strSex = (strSex == one_str) ? AnsiString("Ж") : AnsiString("М"); } // чтобы по умолчанию или если пусто, то выставлялся "М"
            else
            {strSex = "";}
			sql = sql + "phisical_sex_str = '" + strSex + "',";
			person_sex = person_sex.IsEmpty() ? AnsiString("-1") : person_sex;
			sql = sql + "phisical_sex_indx = " + person_sex + ",";
			//sql = sql + "phisical_sex = " + IntToStr( tmp_str ) == null_str ? 0 : 1) + ",";

			if ( ((code & 4) == 4) ) // Для страхователя поместили именно его memo_id
			{sql = sql + "addr_mid = " + IntToStr(insur_addr_memo_id) + ",";}
			else
			{sql = sql + "addr_mid =" + IntToStr(zastr_addr_memo_id) + ",";}
			node3 = node2->ChildNodes->FindNode("addresses");
			sql = sql + "address ='" + (node3->ChildNodes->FindNode("exact_address") ? (AnsiString)(node3->ChildNodes->FindNode("exact_address")->Text) : empty_str) + "',";


            AnsiString ph_mob, ph_home;
			GetPhones(node2->ChildNodes->FindNode("contacts"), /*status*/ FIZ_LIZO, ph_mob, ph_home); // считаем всех дошедших до этого шага физлицами
			sql = sql + "phone_home ='" + ph_home + "',";
			sql = sql + "phone_mobil ='" + ph_mob + "',";
			sql = sql + "auto_summ_id ='" + null_str +"',";

			//node3 = node2->ChildNodes->FindNode("documents");
			//node4 = node3->ChildNodes->FindNode("document");
			//if (node4->Attributes["code"] == AnsiString("17"))
			//{	sql = sql + " stag=" + IntToStr(CalcYears(Sysutils::StrToDateDef(date_str, Date()), Date())); 		}
			//else
            //{ sql = sql.Delete(sql.Length(), 1); }

            sql = sql.Delete(sql.Length(), 1); // Удаляем последнюю запятую !!!
            m_api->dbExecuteQuery(res, sql + " where calc_id=" + IntToStr(calc_id) + " and num=" + IntToStr(count_ins));
            }


			// ВЫВОД ПРЕДУПРЕДИТЕЛЬНЫХ СООБЩЕНИЙ
			if ((code & 4) == 4) // Страхователь НЕ добавился => сообщение
			{
              // выводим предупредительное сообщение только для ЮЛ
              if ((code & 2) == FIZ_LIZO) // Для Физлица (или ИП) Страхователя Добавляем галку Страх=Застрах
              {
                if (doAddPerson) // Страхователь Физлицо (или ИП) и Успешно добавился => выставляем в БД галку "Страх=Застрах"
			    {m_api->dbExecuteQuery(res, "update nscalc set insur_is_face=" + one_str + " where calc_id=" + IntToStr(calc_id));}
              }
              else if ((code & 2) == 2) // Юрлицо
              {
                if (!doAddPerson)  Application->MessageBox("Поля ФИО Страхователя/пол/дата рождения не заполнены или указаны не верно", "Надо заполнить Страхователя", MB_OK);
              }

            }

			if ((code & 8) == 8) // Собственник НЕ добавился => сообщение
			{
              // выводим спец. сообщение только для ЮЛ
              if ((code & 2) == 2) // Юрлицо
              {
                if (!doAddPerson)  Application->MessageBox("Поля ФИО Собственника/пол/дата рождения не заполнены или указаны не верно", "Надо заполнить Собственника", MB_OK);
              }
            }
			//else
			//{m_api->dbExecuteQuery(res, "update nscalc set insur_is_face=" + one_str + " where calc_id=" + IntToStr(calc_id));}
		}
		//*/

		node2 = node2->NextSibling();
	}

    int numOfEqualPersons = 1;
    for (itOfPersonHash = mapOfPersonHash.begin(); itOfPersonHash != mapOfPersonHash.end(); ++itOfPersonHash)
    {
        if( !itOfPersonHash->second )
        {numOfEqualPersons++;}
    }

    if(numOfEqualPersons > 1)
    {
      AnsiString strMessage = "Было найдено " +IntToStr(numOfEqualPersons)+ " Застрахованных с одинаковыми ФИО+др. Первые встретившиеся Записи пользователей добавлены, но их копии нет!";
      Application->MessageBox(strMessage.c_str(), "Внимание", MB_OK);
    }

/*
	node1 = Root->ChildNodes->FindNode("fortuna_avto_dop");
    if(node1) {
	  node2 = node1->ChildNodes->FindNode("territory_preim_isp");
      //AnsiString str = AnsiString(node2->Attributes["code"]);
	  m_api->dbExecuteQuery(res, "update nscalc set territory_id = '" + AnsiString(node2->Attributes["code"]) + "' where calc_id=" + IntToStr(calc_id));
	  //m_api->dbExecuteQuery(res, "update nscalc set territory_name = '" + AnsiString(node2->Text) + "' where calc_id=" + IntToStr(calc_id));
    }
*/
    if(count_ins==0) {count_ins=1;} // должен быть минимум один  // Под конец сохраняем число застрахованных
	m_api->dbExecuteQuery(res, "update nscalc set avto_count_zastr=" + IntToStr(count_ins) + " where calc_id=" + IntToStr(calc_id));

	//if (m_api->is_debug) XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\fortuna_avto_paste.xml");
    m_api->Module_Refresh_Main_Grid(res);
	return res == _Mops_API_Ok_;
    
#endif








































































































SAVE_FRAME
   AnsiString ins_str;
   ins_str = ins_addr->Text; owner_str = owner_addr->Text;
   m_api->dbReadWriteInternalMemo( res, ins_str,   ins_mid,   false, "OSAGO_R_memo");
   
   SAVE ins_mid
   
   

   for(int i = 0; i < count_ins_face; ++i)
   {
      memo_text = pm[i].kladr_addr->Text;
      if(CheckAddrList(pm[i].kladr_addr)) m_api->dbReadWriteInternalMemo(res, memo_text, pm[i].memo_id, false, "nsmemo");
   }


LOAD_FRAME

   ins_mid = q->FieldByName("pol_zayav_strah_mid")->AsInteger;  

   AnsiString ins_str;
   m_api->dbReadWriteInternalMemo(res, ins_str,   ins_mid,   true, "OSAGO_R_memo");
   ins_addr->Text   = ins_str;

   
   
      pm[index].memo_id    = q->FieldByName("addr_mid")->AsInteger;
      if(pm[index].memo_id)
	  {
         AnsiString memo_text;
         m_api->dbReadWriteInternalMemo(res, memo_text, pm[index].memo_id, true, "nsmemo");
         pm[index].kladr_addr->Text = memo_text;
      }
      pm[index].address     = q->FieldByName("address")->AsString;



	  
   m_api->dbReadWriteInternalMemo(res, ins_str,   ins_mid,   true, "OSAGO_R_memo");
   m_api->dbReadWriteInternalMemo(res, owner_str, owner_mid, true, "OSAGO_R_memo");
   ins_addr->Text   = ins_str;

   
   
   
   








OPF->Strings[editOPF->Items->IndexOf(pi[0]->opf)])
cboxPayment->ItemIndex = cboxPayment->Items->IndexOfObject((TObject*)q->FieldByName("payment_id")->AsInteger);




SaveFrame

   ins_str = ins_addr->Text;
   m_api->dbReadWriteInternalMemo( res, ins_str,   ins_mid,   false, "OSAGO_R_memo");

   if(osob_otmet_memoid == 0) osob_otmet_memoid = m_api->dbGenerateId(res, "OSAGO_R_memo");
   m_api->dbReadWriteInternalMemo(res, MOsOtm->Text, osob_otmet_memoid, false, "OSAGO_R_memo");




















      if((code & 4) == 4) //нашли страхователя 
	  if((code & 8) == 8) //нашли собственника

	  
      if((code & 2) == 0){ //физлицо
         if( code & 4 ) { //person  =страхователь физ.лицо
      if((code & 2) == 2){ //юрлицо
		 
		 


[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]

[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]


В

orig
[StretchFont(Memo20,<UserData."insur_adr_index"> + ', '+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

12
[<UserData."insur_yur_name">]



IIF( length(<UserData."insur_adr_index">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_kr_obl">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_raion">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_nas_punkt">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_ulitsa">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_dom">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_korpus">)>0, DO, ELSE)

	
[StretchFont(Memo20,<UserData."insur_adr_index"> + IIF( length(<UserData."insur_adr_index">)>0, ', ', '')+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

		
[
  StretchFont(Memo20, 
  <UserData."insur_adr_index"> 
  + IIF( length(<UserData."insur_adr_kr_obl">)>0, ', ', '') + <UserData."insur_adr_kr_obl"> 
  + IIF( length(<UserData."insur_adr_raion">)>0, ', ', '')  + <UserData."insur_adr_raion">
  + IIF( length(<UserData."insur_adr_nas_punkt">)>0, ', ', '') + <UserData."insur_adr_nas_punkt"> 
  + IIF( length(<UserData."insur_adr_ulitsa">)>0, ', ', '') + <UserData."insur_adr_ulitsa"> 
  + IIF( length(<UserData."insur_adr_dom">)>0, ', д. ', '')  + <UserData."insur_adr_dom"> 
  + IIF( length(<UserData."insur_adr_korpus">)>0, ', корп./стр. ', '') + <UserData."insur_adr_korpus">)
]

















[IIF((<UserData."payment_id">=1) ,<UserData."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]


[IIF(<UserData."payment_id">=1,'В том числе: наличными денежными средствами','')]
В том числе: безналичными денежными средствами


if( <UserData."payment_id">=3 ) then
begin
  Memo232.Text := '----'; // str_prem
end;
    
[IIF(,,'')]




[StretchFont(Memo202,<UserData."project_name">)] 


[StretchFont(Memo20,<UserData."insur_adr_index"> + ', '+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

[ ]




[StretchFont(Memo207,<UserData."bank_name">)]



[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,1,2),'-- --')]
[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,4,2),'-- --')]
[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,7,4),'-- -- -- --')]

[IIF(<UserData."insur_status"> <>0,DateToStrM(<UserData."insur_dategosreg">),'-- --')]
insur_dategosreg






<UserData."insur_full_name">










ЗАПИСЬ 24
СТРАХОВАТЕЛЕВ
СТРАХОВАТЕЛЬ
СТРАХОВАЕТЕЛЕВИЧ
01.01.1990
36 05
422247
06.06.2006
771771
ОВД Района Мытищи

+7(999)333-22-11
8-495-999-88-77
8-926-999-88-77
fiz_lizo@mail.ru
/////////////////////////////////////////////

СОБСТВЕННИКОВ
СОБСТВ
СОБСТВЕННИКОВИЧ
15.06.1986
36 05
422247




node2->Attributes["code"] = IntToStr(4 | (qw->FieldByName("pol_zayav_strah_FU")->AsBoolean ? 2 : 0));

AnsiString GetCode(TADOQuery* q)
{
   int code(0);

   if(q->FieldByName("status")->AsInteger > 1) code = 2;
   switch(q->FieldByName("type_person")->AsInteger){
      case 1:  code += 4;  break;
      case 2:  code += 8; break;
      //case 3:  code += 8;  break;
      default: code += 32; break;
   }

   return IntToStr(code);
}









 
 

F:\Projects\apo2\OSAGO_UFO\APO2.exe

dEBUG admin z80orionpc$ 
 
 



 
 _ROOT00000000000000007026
_ROOT00000000000000007027
_ROOT00000000000000007028
_ROOT00000000000000007031




RISK_OBJECT_NAME
risk_object_name
INSURANCE_RULE_ID
insurance_rule_id
RULE_NAME
rule_name
LIABILITY
liability

 
 
 
 
 
 
 
16

0,42
11,40
4,87
8,60
[UserData."insur_ogrn"]

0,42
11,40
6,49
8,60



30
 
0,42
13,63
5,29
6,37

[StretchFont(Memo30,<UserData."insur_regorg_name">)] 

0,42
13,63
6,91
6,37
 
 
// FROM OSAGO
function DateToStrM(dt:TDateTime):String;
var
       temp:String;
       month :integer;                                                   
begin
   //temp:=FormatDateTime('dd',dt);
   temp:= '';
     
   month:=StrToInt(FormatDateTime('mm',dt));
   case month of
   1: temp:=temp+' ßíâàðÿ ';    
   2: temp:=temp+' Ôåâðàëÿ ';
   3: temp:=temp+' Ìàðòà ';
   4: temp:=temp+' Àïðåëÿ ';
   5: temp:=temp+' Ìàÿ ';
   6: temp:=temp+' Èþíÿ ';
   7: temp:=temp+' Èþëÿ ';
   8: temp:=temp+' Àâãóñòà ';
   9: temp:=temp+' Ñåíòÿáðÿ ';
   10: temp:=temp+' Îêòÿáðÿ ';       
   11: temp:=temp+' Íîÿáðÿ ';
   12: temp:=temp+' Äåêàáðÿ ';       
   end;                     
  // temp:=temp + FormatDateTime('yyyy',dt);                                                                                    
   Result:=temp;
end;


 
 


// FROM OLD FORTUNA
function DateToStrM(dt:TDateTime):String;
var
       temp:String;
       month :integer;                                                   
begin
   //temp:=FormatDateTime('dd',dt);
 
   month:=StrToInt(FormatDateTime('mm',dt));
   case month of
   1: temp:=temp+' ßíâàðÿ ';    
   2: temp:=temp+' Ôåâðàëÿ ';
   3: temp:=temp+' Ìàðòà ';
   4: temp:=temp+' Àïðåëÿ ';
   5: temp:=temp+' Ìàÿ ';
   6: temp:=temp+' Èþíÿ ';
   7: temp:=temp+' Èþëÿ ';
   8: temp:=temp+' Àâãóñòà ';
   9: temp:=temp+' Ñåíòÿáðÿ ';
   10: temp:=temp+' Îêòÿáðÿ ';       
   11: temp:=temp+' Íîÿáðÿ ';
   12: temp:=temp+' Äåêàáðÿ ';       
   end;                     
  // temp:=temp + FormatDateTime('yyyy',dt);                                                                                    
   Result:=temp;
end;  





 
 

[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]

[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]


В

orig
[StretchFont(Memo20,<UserData."insur_adr_index"> + ', '+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

12
[<UserData."insur_yur_name">]



IIF( length(<UserData."insur_adr_index">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_kr_obl">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_raion">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_nas_punkt">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_ulitsa">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_dom">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_korpus">)>0, DO, ELSE)

	
[StretchFont(Memo20,<UserData."insur_adr_index"> + IIF( length(<UserData."insur_adr_index">)>0, ', ', '')+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

		
[
  StretchFont(Memo20, 
  <UserData."insur_adr_index"> 
  + IIF( length(<UserData."insur_adr_kr_obl">)>0, ', ', '') + <UserData."insur_adr_kr_obl"> 
  + IIF( length(<UserData."insur_adr_raion">)>0, ', ', '')  + <UserData."insur_adr_raion">
  + IIF( length(<UserData."insur_adr_nas_punkt">)>0, ', ', '') + <UserData."insur_adr_nas_punkt"> 
  + IIF( length(<UserData."insur_adr_ulitsa">)>0, ', ', '') + <UserData."insur_adr_ulitsa"> 
  + IIF( length(<UserData."insur_adr_dom">)>0, ', д. ', '')  + <UserData."insur_adr_dom"> 
  + IIF( length(<UserData."insur_adr_korpus">)>0, ', корп./стр. ', '') + <UserData."insur_adr_korpus">)
]

















[IIF((<UserData."payment_id">=1) ,<UserData."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]


[IIF(<UserData."payment_id">=1,'В том числе: наличными денежными средствами','')]
В том числе: безналичными денежными средствами


if( <UserData."payment_id">=3 ) then
begin
  Memo232.Text := '----'; // str_prem
end;
    
[IIF(,,'')]




[StretchFont(Memo202,<UserData."project_name">)] 


[StretchFont(Memo20,<UserData."insur_adr_index"> + ', '+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

[ ]




[StretchFont(Memo207,<UserData."bank_name">)]



[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,1,2),'-- --')]
[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,4,2),'-- --')]
[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,7,4),'-- -- -- --')]

[IIF(<UserData."insur_status"> <>0,DateToStrM(<UserData."insur_dategosreg">),'-- --')]
insur_dategosreg


 
[IIF(ValidDate(<UserData."polis_date">),DateToStrM(<UserData."polis_date">),'- - - - - ')]

[IIF(ValidDate(<UserData."polis_date">),DateToStrM(<UserData."polis_date">),'- - - - - ')]



 
 



[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]

[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]


В

orig
[StretchFont(Memo20,<UserData."insur_adr_index"> + ', '+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

12
[<UserData."insur_yur_name">]



IIF( length(<UserData."insur_adr_index">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_kr_obl">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_raion">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_nas_punkt">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_ulitsa">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_dom">)>0, DO, ELSE)
IIF( length(<UserData."insur_adr_korpus">)>0, DO, ELSE)

	
[StretchFont(Memo20,<UserData."insur_adr_index"> + IIF( length(<UserData."insur_adr_index">)>0, ', ', '')+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

		
[
  StretchFont(Memo20, 
  <UserData."insur_adr_index"> 
  + IIF( length(<UserData."insur_adr_kr_obl">)>0, ', ', '') + <UserData."insur_adr_kr_obl"> 
  + IIF( length(<UserData."insur_adr_raion">)>0, ', ', '')  + <UserData."insur_adr_raion">
  + IIF( length(<UserData."insur_adr_nas_punkt">)>0, ', ', '') + <UserData."insur_adr_nas_punkt"> 
  + IIF( length(<UserData."insur_adr_ulitsa">)>0, ', ', '') + <UserData."insur_adr_ulitsa"> 
  + IIF( length(<UserData."insur_adr_dom">)>0, ', д. ', '')  + <UserData."insur_adr_dom"> 
  + IIF( length(<UserData."insur_adr_korpus">)>0, ', корп./стр. ', '') + <UserData."insur_adr_korpus">)
]



[IIF((<UserData."payment_id">=1) ,<UserData."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]


[IIF(<UserData."payment_id">=1,'В том числе: наличными денежными средствами','')]
В том числе: безналичными денежными средствами


if( <UserData."payment_id">=3 ) then
begin
  Memo232.Text := '----'; // str_prem
end;
    
[IIF(,,'')]




[StretchFont(Memo202,<UserData."project_name">)] 


[StretchFont(Memo20,<UserData."insur_adr_index"> + ', '+ <UserData."insur_adr_kr_obl"> + ', ' + <UserData."insur_adr_raion"> + ', ' + <UserData."insur_adr_nas_punkt"> + ', ' + <UserData."insur_adr_ulitsa"> + ', д. ' + <UserData."insur_adr_dom"> + ', корп./стр. ' + <UserData."insur_adr_korpus">)]

[ ]




[StretchFont(Memo207,<UserData."bank_name">)]



[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,1,2),'-- --')]
[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,4,2),'-- --')]
[IIF(<UserData."insur_status"> <>0,Copy(<UserData."insur_dategosreg">,7,4),'-- -- -- --')]

[IIF(<UserData."insur_status"> <>0,DateToStrM(<UserData."insur_dategosreg">),'-- --')]
insur_dategosreg



 
 
 
 
    AnsiString lnr = m_api->dbGetStringFromQuery(res,"select LNR from _mops_polzovateli_ where id="+m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));
    AnsiString user = m_api->dbGetStringFromQuery(res, "select name from _mops_polzovateli_ where id="+ m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));
    //AnsiString skk_ = m_api->dbGetStringFromQuery(res,"select SKK from _mops_polzovateli_ where id="+m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));

	
 
 
 [iif(<UserData."insur_status"> <>1,<UserData."insur_full_name">,<UserData."insur_fio_predst">)]

 [<UserData."insur_last_name">+' '+ <UserData."insur_first_name">+' '+<UserData."insur_second_name">]

 
 
 
 
    sEdit1->Text = m_api->dbGetStringFromQuery(res, "select name from _mops_polzovateli_ where id="+ m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));

        AnsiString skk = m_api->dbGetStringFromQuery(res,"select SKK from _mops_polzovateli_ where id="+m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));	
	
	
	
 
 
 
 
 
 
[UserData."insur_regorg_name"]
12345678911234567892123456789312345678941234567895


[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,1,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,2,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,4,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,5,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,9,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,10,1),'- -'))]

 
 
 
 
 
if( length(<UserData."pol_zayav_strah_inn">)=0 ) then //äëÿ ôèç.ëèö ãàëêó íå ñòàâèì                                                                              
       CheckBox1.Checked := false; 

[IIF( length(<UserData."insur_inn">)>0,Copy(<UserData."polis_date">,1,2),'- - -')]
[IIF( length(<UserData."insur_inn">)>0,DateToStrM(<UserData."polis_date">),'- - - - - ')]
[IIF( length(<UserData."insur_inn">)>0,Copy(<UserData."polis_date">,9,2),'- -')]

	   
[IIF( length(<UserData."pol_zayav_strah_inn">)>0,Copy(<UserData."pol_zayav_date_zayav">,1,2),'- - -')]
[IIF( length(<UserData."pol_zayav_strah_inn">)>0,DateToStrM(<UserData."pol_zayav_date_zayav">),'- - - - - ')]
[IIF( length(<UserData."pol_zayav_strah_inn">)>0,Copy(<UserData."pol_zayav_date_zayav">,9,2),'- -')]

 
 
 

		select skk_7_10_16.blank_series_id, skk_7_10_16.series_name
		 from  gl_dict_7_10_16_product_blank_relation skk_7_10_16
		 where 
           skk_7_10_16.FORT_AUTO_PRODUCT_ID='1'
         and
         (
          skk_7_10_16.subject_federation_code = '78'
          or skk_7_10_16.subject_federation_code = '0'
         )
		 and   skk_7_10_16.start_date <= Date() and skk_7_10_16.end_date >=Date()
		 group by skk_7_10_16.blank_series_id, skk_7_10_16.series_name
		 order by skk_7_10_16.series_name
		;


http://confluence.rgs.ru:8080/pages/viewpage.action?pageId=134880059
Фортуна Авто - Функциональные Треб. - Общие Треб.
Пункты:
РГ.ФА.АПО2.00060.04
РГ.ФА.АПО2.00060.05
РГ.ФА.АПО2.00060.06
РГ.ФА.АПО2.00060.07
РГ.ФА.АПО2.00060.08
РГ.ФА.АПО2.00060.09
РГ.ФА.АПО2.00060.010






ОБЩАЯ СТРАХОВАЯ ПРЕМИЯ
получена

[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,2,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,5,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,10,1),'- -'))]

[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]
[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,2,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,2,1),'- -'))]
[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,4,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,4,1),'- -'))]
[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,5,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,5,1),'- -'))]
[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,9,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,9,1),'- -'))]
[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,10,1), IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,10,1),'- -'))]

от
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,1,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,2,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,4,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,5,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,9,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,10,1),'- -'))]

[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,1,1),'- -'))]
[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,2,1),'- -'))]
[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,4,1),'- -'))]
[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,5,1),'- -'))]
[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,9,1),'- -'))]
[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,10,1),'- -'))]

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ОБЩАЯ СТРАХОВАЯ ПРЕМИЯ
получена

[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."payment_date">,1,1), IIF( <UserData."payment_doc_id">=3, Copy(<UserData."pp_beznal_date">,1,1),'- -'))]
[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."payment_date">,2,1), IIF( <UserData."payment_doc_id">=3, Copy(<UserData."pp_beznal_date">,2,1),'- -'))]
[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."payment_date">,4,1), IIF( <UserData."payment_doc_id">=3, Copy(<UserData."pp_beznal_date">,4,1),'- -'))]
[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."payment_date">,5,1), IIF( <UserData."payment_doc_id">=3, Copy(<UserData."pp_beznal_date">,5,1),'- -'))]
[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."payment_date">,9,1), IIF( <UserData."payment_doc_id">=3, Copy(<UserData."pp_beznal_date">,9,1),'- -'))]
[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."payment_date">,10,1), IIF( <UserData."payment_doc_id">=3, Copy(<UserData."pp_beznal_date">,10,1),'- -'))]

от

[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,1,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,2,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,4,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,5,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,9,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,10,1),'- -'))]

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ОБЩАЯ СТРАХОВАЯ ПРЕМИЯ
получена
[IIF(<UserData."payment_id">=1, Copy(<UserData."pp_date">,1,1), IIF( <UserData."payment_id">=3, Copy(<UserData."pp_beznal_date">,1,1),'- -'))]
[IIF(<UserData."payment_id">=1, Copy(<UserData."pp_date">,2,1), IIF( <UserData."payment_id">=3, Copy(<UserData."pp_beznal_date">,2,1),'- -'))]
[IIF(<UserData."payment_id">=1, Copy(<UserData."pp_date">,4,1), IIF( <UserData."payment_id">=3, Copy(<UserData."pp_beznal_date">,4,1),'- -'))]
[IIF(<UserData."payment_id">=1, Copy(<UserData."pp_date">,5,1), IIF( <UserData."payment_id">=3, Copy(<UserData."pp_beznal_date">,5,1),'- -'))]
[IIF(<UserData."payment_id">=1, Copy(<UserData."pp_date">,9,1), IIF( <UserData."payment_id">=3, Copy(<UserData."pp_beznal_date">,9,1),'- -'))]
[IIF(<UserData."payment_id">=1, Copy(<UserData."pp_date">,10,1), IIF( <UserData."payment_id">=3, Copy(<UserData."pp_beznal_date">,10,1),'- -'))]
№
[IIF(<UserData."payment_id">=3,Copy(<UserData."pp_number">,1,1),'- -')]
[IIF(<UserData."payment_id">=3,Copy(<UserData."pp_number">,2,1),'- -')]
[IIF(<UserData."payment_id">=3,Copy(<UserData."pp_number">,3,1),'- -')]
[IIF(<UserData."payment_id">=3,Copy(<UserData."pp_number">,4,1),'- -')]
[IIF(<UserData."payment_id">=3,Copy(<UserData."pp_number">,5,1),'- -')]
от
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_beznal_date">),Copy(<UserData."pp_beznal_date">,1,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_beznal_date">),Copy(<UserData."pp_beznal_date">,2,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_beznal_date">),Copy(<UserData."pp_beznal_date">,4,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_beznal_date">),Copy(<UserData."pp_beznal_date">,5,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_beznal_date">),Copy(<UserData."pp_beznal_date">,9,1),'- -'))]
[(IIF((<UserData."payment_id">=3) and ValidDate(<UserData."pp_beznal_date">),Copy(<UserData."pp_beznal_date">,10,1),'- -'))]

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ОБЩАЯ СТРАХОВАЯ ПРЕМИЯ
получена
[IIF(<UserData."payment_doc_id">=1, Copy(<UserData."pp_date">,1,1),'- -')]

[<UserData."payment_doc_id">]




   m_api->Internal_Prepare_SQL_Text(res,q_dop->FieldByName("sex")->AsString) +"','"+
   m_api->Raise_Error_Warning(res, this, 0, "[Страхователь]Не указан пол", "[Страхователь]Не указан пол", 0, PRARM, err_num++, RBInsFiz->Checked && CBStrachSex->Text.Trim().IsEmpty());
   m_api->Raise_Error_Warning(res, this, 0, "[Собственник]Не указан пол", "[Собственник]Не указан пол", 0, PRARM, err_num++, RBOwnFiz->Checked && CBOwnSex->Text.Trim().IsEmpty());

                    "pol_zayav_strah_sex='%s', "

                      RBInsFiz->Checked?m_api->Internal_Prepare_SQL_Text(res,CBStrachSex->Text).c_str():"",
                      RBOwnFiz->Checked?m_api->Internal_Prepare_SQL_Text(res,CBOwnSex->Text).c_str():"",					  

					  
					  
CBStrachSex->ItemIndex = q->FieldByName("pol_zayav_strah_FU")->AsBoolean ? -1 : CBStrachSex->Items->IndexOf(q->FieldByName("pol_zayav_strah_sex")->AsString);
SGDop->Cells[5][n] = qw_dop->FieldByName("sex")->AsString;
CBSex->ItemIndex = CBSex->Items->IndexOf(SGDop->Cells[ACol][ARow]);
AnsiString sex = ((TsComboBox*)Sender)->Text; //проставляет пол только если он выбран(а по умолчанию будет М)
if(!sex.IsEmpty()) cf->ClientDataSet1->FieldByName("sex")->AsString = sex;
if(((TControl*)Sender)->Name == "CBSex") {

  if( Sender->ClassNameIs("TsComboBox") )
  AnsiString sex = ((TsComboBox*)Sender)->Text; //проставляет пол только если он выбран(а по умолчанию будет М)
  if(!sex.IsEmpty()) cf->ClientDataSet1->FieldByName("sex")->AsString = sex;
	  


sql = sql + "pol_zayav" + field + "sex='" + node2->ChildNodes->FindNode("physical_sex")->Text
sql = sql + "sex='" + (AnsiString(node2->ChildNodes->FindNode("physical_sex")->Text) == null_str ? AnsiString("М") : AnsiString("Ж"))+ "',";

node3 = node2->AddChild("physical_sex");
if(!is_yur) node3->Text = qw->FieldByName("pol_zayav_strah_sex")->AsString == "М" ? null_str : one_str;

node3 = node2->AddChild("physical_sex");
if(!qw->FieldByName("pol_zayav_sobstv_FU")->AsBoolean)
  node3->Text = qw->FieldByName("pol_zayav_sobstv_sex")->AsString == "М" ? AnsiString("0") : AnsiString("1");

node2->AddChild("physical_sex")->Text        = qwd->FieldByName("sex")->AsString == "М" ? AnsiString("0") : AnsiString("1");	
	

//------------------------------------------------------------------------------
void XMLLoad_(AnsiString XML)
{
qdu->FieldByName("sex")->AsString   = sl->Strings[i + val * 2].Trim().SubString(1, 1).UpperCase();	

//------------------------------------------------------------------------------
void XMLLoad__(AnsiString XML)
{	
        if(Root->ChildNodes->FindNode("drivers_sex")!=0)
         {
             sl->Text = StringReplace(AnsiString(Root->ChildNodes->FindNode("drivers_sex")->Text).Trim(), ";", "\n", TReplaceFlags() << rfReplaceAll);
             qdu->First(); qdu->Edit();
             for(int i = 0, cnt = sl->Count; i < cnt; ++i, qdu->Next(), qdu->Edit())
                qdu->FieldByName("sex")->AsString = sl->Strings[i].Trim();
         }
 

//0.0.0.1 XML
long LoadDataFromARM0001(AnsiString st)
{
                      if(AnsiString(Root->ChildNodes->FindNode("Pol")->Text).Trim()=="Jen.") qw->FieldByName("pol_zayav_strah_sex")->AsString="Ж";
                      if(AnsiString(Root->ChildNodes->FindNode("Pol")->Text).Trim()=="Muj.") qw->FieldByName("pol_zayav_strah_sex")->AsString="М";

                                qdu->FieldByName("sex")->AsString        = AnsiString(node->ChildNodes->FindNode("Dopusch_Pol")->Text).Trim();
					  
	
	
	
	
Проверка, тестирование функционала Копирования и вставки записей внутри продукта. Устранение багов.

Проверка, тестирование функционала копирования и вставки записей в Кросс-Продукты "ОСАГО" и "ОСАГО 2.0". Устранение багов из списка замечаний от тестировщика. Добавление сборки к таску. В сборку включены Копирование, Вставка, Кроссы и исправления, кроме пунктов, касающихся Печатных Форм: 6, 15, 17, 18, 19, 21, 22, 25, +доп.вопросы



select CInt(skk_7_10_16.blank_series_id), skk_7_10_16.series_name
 from  gl_dict_7_10_16_product_blank_relation skk_7_10_16
 where 
   skk_7_10_16.FORT_AUTO_PRODUCT_ID='1'
 and 
 (
  skk_7_10_16.subject_federation_code='78'
  or skk_7_10_16.subject_federation_code = '0'
 )
 and   skk_7_10_16.start_date <= Date() and skk_7_10_16.end_date >=Date()
 group by skk_7_10_16.blank_series_id, skk_7_10_16.series_name
//order by skk_7_10_16.series_name"






   node1 = Root->ChildNodes->FindNode("sale");
   node2 = node1->ChildNodes->FindNode("car_dealer");
   node2->Attributes["code"] = qw->FieldByName("autodealer_id")->AsInteger;
   node2 = node1->ChildNodes->FindNode("bank_partner");
   node2->Attributes["code"] = qw->FieldByName("bank_id")->AsInteger;
   node2 = node1->ChildNodes->FindNode("other_partner");
   node2->Attributes["code"] = qw->FieldByName("other_partner_id")->AsInteger;
   
   
   


old_sale_channel_id(0),


SAVE
                    "sale_channel='%s',"
                    "sale_channel_id=%i"
					
                      (tvSaleChannel->Selected ? tvSaleChannel->Selected->Text : AnsiString("")).c_str(),
                      (tvSaleChannel->Selected ? (int)tvSaleChannel->Selected->Data : 0),					
					
					
LOAD

   old_sale_channel_id = q->FieldByName("old_sale_channel_id")->AsInteger;					
					

   m_api->Raise_Error_Warning(res, this, 0, "Обратите внимание! Данный договор ранее был заключен в партнерском канале продаж. Возможно его следует отнести к каналу перевода 139.", "Обратите внимание! Данный договор ранее был заключен в партнерском канале продаж. Возможно его следует отнести к каналу перевода 139.",
                              0, WARN, err_num++, old_sale_channel_id > 140 && old_sale_channel_id < 150 && (int)tvSaleChannel->Selected->Data != 139);

   
   
   
   
   
   
   
   
   
   
   
   



fortuna_avto_2016_12_29_modul_i_spravochniki.zip



   SELECT ckk_7_10_16.scc_id,
          ckk_7_10_16.date_from,
          ckk_7_10_16.date_to,
          ckk_7_5_4.blank_series_id,
          ckk_7_5_4.series_name,
          ckk_7_10_16.blank_type_id,
          ckk_7_10_16.short_blank_type_name,
          ckk_4_1_4.SUBJECT_FEDERATION_CODE,
          ckk_7_7_83.FORT_AUTO_PRODUCT_ID,
          ckk_7_10_16.start_date,
          ckk_7_10_16.end_date
     FROM rgsscc.ref_product_blank_fa ckk_7_10_16,
          rgsscc.REF_FORT_AUTO_PRODUCTS ckk_7_7_83,
          rgsscc.REF_SUBJECT_RF ckk_4_1_4,
          rgsscc.ref_dictblankseries ckk_7_5_4
    WHERE     ckk_7_7_83.scc_id = ckk_7_10_16.fa_prod_id
          AND ckk_7_5_4.scc_id = ckk_7_10_16.blank_series_id
          AND ckk_4_1_4.scc_id = ckk_7_10_16.subject_federation_code
          AND ckk_7_10_16.scc_status = 0;
		  






select skk_7_10_16.blank_series_id, skk_7_10_16.series_name
from gl_dict_7_10_16_product_blank_relation skk_7_10_16
where 
 skk_7_10_16.FORT_AUTO_PRODUCT_ID='3'
 and 
 (skk_7_10_16.subject_federation_code='' or skk_7_10_16.subject_federation_code=0)
 and   skk_7_10_16.start_date <= Date() and skk_7_10_16.end_date >=Date()
group by skk_7_10_16.blank_series_id, skk_7_10_16.series_name



50926060




[UserData."pol_zayav_strah_fio"] 
<=>
[UserData."insur_full_name"]

//////////////////////////////////////////////
//////////////////////////////////////////////
СПИСОК ЗАСТРАХОВАННЫХ

СПИСОК
застрахованных лиц к полису

[UserData."polis_seria"]
[UserData."polis_number"]
[(IIF(ValidDate(<UserData."polis_date">),'«'+FormatDateTime('dd',<UserData."polis_date">)+'»',''))]
[(IIF(ValidDate(<UserData."polis_date">),IIF((MonthOf(<UserData."polis_date">) = 3) Or (MonthOf(<UserData."polis_date">) = 8),FormatDateTime('mmmm',<UserData."polis_date">) + 'а',Format('%sя',[Copy(FormatDateTime('mmmm',<UserData."polis_date">),1,Length(FormatDateTime('mmmm',<UserData."polis_date">))-1)])),''))]
[(IIF(ValidDate(<UserData."polis_date">),FormatDateTime('yy',<UserData."polis_date">)+' г.',''))]

Фамилия, имя, отчество
[UserData_5."z.full_name"]

Адрес, дата рождения
[UserData_5."address"] [UserData_5."phisical_birth_date"]

АДРЕС
[<UserData."insur_adr_index">+ ', '+ <UserData."insur_adr_kr_obl"> 
+ ' '+<UserData."insur_adr_raion"> 
+ ' '+<UserData."insur_adr_nas_punkt">
+ ' '+<UserData."insur_adr_ulitsa"> + ' д.'+ <UserData."insur_adr_dom"> + ' корп./стр.' + <UserData."insur_adr_korpus"> + ' кв.'+ <UserData."insur_adr_kvartira">]


Страховая сумма
[UserData_5."str_summ"]

Страховая премия
[UserData_5."str_prem"]

Выгодоприобретатель (Ф.И.О.)
[iif(<UserData_5."b.full_name"><>'',<UserData_5."b.full_name">+',  доля  '+FormatFloat('0.00',<UserData_5."share">)+' %','- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]


ИТОГО:
[UserData."avto_str_summa"]
[UserData."premiya"]


//////////////////////////////////////////////
//////////////////////////////////////////////
ЗАЯВЛЕНИЕ ДЛЯ ЮР ЛИЦ

Общая страховая премия по Договору страхования в размере  <u>        [FormatFloat('###,###,###,##0.00',<UserData."premiya">)]        </u> рублей за всех Застрахованных лиц будет уплачена единовременно до «<u>[FormatDateTime('dd',<UserData."payment_date">)]</u>» <u> [DateToStrM(<UserData."payment_date">)] </u> 20<u>  [FormatDateTime('yy',<UserData."payment_date">)]  </u>  г.

[UserData."insur_address"]
[UserData."insur_address"]

подписью
[UserData."insur_fio_predst"]
[UserData."insur_fio_ruk"]
//////////////////////////////////////////////
//////////////////////////////////////////////









//////////////////////////////////////////////
//////////////////////////////////////////////


[<UserData."insur_inn">]
32
[StretchFont(Memo32,iif(<UserData."insur_status">=0,<UserData."insur_doc_type">+' серия: '+<UserData."insur_document_series">+', №: '+<UserData."insur_document_number">+' Выдан: '+<UserData."insur_document_issue_org">+' '+FormatDateTime('dd.mm.yyyy',<UserData."insur_document_issue_date">)+' г.',''))]


//////////////////////////////////////////////
//////////////////////////////////////////////

function DateToStrM(dt:TDateTime):String;
var
       temp:String;
       month :integer;                                                   
begin
   //temp:=FormatDateTime('dd',dt);
   temp:= '';
     
   month:=StrToInt(FormatDateTime('mm',dt));
   case month of
   1: temp:=temp+' Января ';    
   2: temp:=temp+' Февраля ';
   3: temp:=temp+' Марта ';
   4: temp:=temp+' Апреля ';
   5: temp:=temp+' Мая ';
   6: temp:=temp+' Июня ';
   7: temp:=temp+' Июля ';
   8: temp:=temp+' Августа ';
   9: temp:=temp+' Сентября ';
   10: temp:=temp+' Октября ';       
   11: temp:=temp+' Ноября ';
   12: temp:=temp+' Декабря ';       
   end;                     
  // temp:=temp + FormatDateTime('yyyy',dt);                                                                                    
   Result:=temp;
end;  
  
function StretchFont(m:TfrxMemoView;s:String):String;
var      
       i:Extended;
       btmp:TBitmap;
       f:boolean;
       flowto:TFrxMemoView;
       LastMemoView:TfrxMemoView;
       fs:Integer;                               
begin
      fs:=5;              
       btmp:=TBitmap.Create();
       LastMemoView:=m;                                                                           
       f:=false;
       flowto:=TfrxMemoView(m.FlowTo);
         i:=m.Width-m.ParagraphGap-m.GapX;
        while flowto<> nil do
        begin                    
               i:=i+flowto.Width-flowto.ParagraphGap-flowto.GapX;
               flowto:= TFrxMemoView(flowto.FlowTo);                                                             
        end;                  
         
         i:=i*0.96; //                                                                                                                                               


         
while not f do
begin
               btmp.Canvas.Font:=m.Font;
               if((btmp.Canvas.TextWidth(s)<i) or (m.Font.Size<=fs)) then           
                     f:=true
               else
                    begin                              
                      m.Font.Size:=m.Font.Size-1;
                      flowto:=TFrxMemoView(m.FlowTo);                                                                                  
                     while flowto<> nil do
                        begin                    
                                flowto.Font.Size:=flowto.Font.Size-1;
                                lastmemoview:=flowto;                                                                                
                                flowto:= TFrxMemoView(flowto.FlowTo);                                    
                        end;                       
                    end;                                                      
end;          
btmp.Free();
if(m.Font.Size<=fs) then
       lastmemoview.WordWrap:=true;                                                            
result:=s;                                  
end;



var    
   strah :boolean; //1 если застрахован сам страхователь
   allprem:Integer;//общая страх прем.                                            
   allsum:Integer;//общая страх сумм
   rcount:Integer;//кол-во записей                                                                    
begin

Page2.Visible := <UserData."sale_channel_id"> <> 135; //РГС-БАНК                                                                                 
       
strah:=false;

rcount := MasterData2.DataSet.RecordCount;                                                          
  
MasterData2.DataSet.First;
while(not MasterData2.DataSet.Eof) do
begin
   if( <UserData_3."insur_strah"> = 1 )then begin//застрахован сам страхователь
       Memo81.Text := 'X';//FormatFloat('### ###',<UserData_3."strahprem">);
       Memo90.Text := FormatFloat('### ###',<UserData_3."strahprem">);           
       strah:=true;                                 
       end                 
   else begin 
       Memo82.Text := 'X';//FormatFloat('### ###',<UserData_3."strahprem">);
       Memo91.Text := FormatFloat('### ###',<UserData_3."strahprem">);                    
   end;             

   allprem := allprem + <UserData_3."strahprem">;
   allsum := allsum + <UserData_3."strahsum">;                                                     
  
  MasterData2.DataSet.Next;                        
end;                                

//Если страхователь и 1застр лицо просто перекладываем из мемо82 в мемо91 премию                                                                                                              
//if( (rcount =2) and (strah=true) ) then begin Memo91.Text := FormatFloat('### ###',<UserData_3."strahprem">);//Memo82.Text; Memo82.Text := '- - - - - - - - - - - -'; 
//       end;
      
//Если застрахованных 2 но нет самого страхователя т.е. просто два каких то лица
//или если больше 2х                                                 
//4)	Если застрахованных лиц 2 и более составляется список застрахованных лиц идентично реализованному в действующем модуле Фортуны АВТО:    
if( (rcount > 2) or ((rcount = 2) and (strah=false)) ) then
begin
  Memo82.Text := 'согласно списку';         
  Memo91.Text := Memo82.Text;
  Memo81.Text := '- - - - - - - - - - - - - - - - - - - - - - -';                                          
end;          


if( rcount=1 ) then Memo53.Text := <UserData_3."famil">+' '+<UserData_3."name">+' '+<UserData_3."otch">;                                      

//Memo96.Text :=  FormatFloat('### ###', allsum);
//Memo99.Text :=  FormatFloat('### ###', allprem);    
  
if( strah=true ) then Line1.Visible:= false;

if( length(<UserData."pol_zayav_strah_inn">)=0 ) then //для физ.лиц галку не ставим                                                                              
       CheckBox1.Checked := false;                                                                        
    
        
end.

//////////////////////////////////////////////
//////////////////////////////////////////////
function DateToStrM(dt:TDateTime):String;
var
       temp:String;
       month :integer;                                                   
begin
   //temp:=FormatDateTime('dd',dt);
 
   month:=StrToInt(FormatDateTime('mm',dt));
   case month of
   1: temp:=temp+' ßíâàðÿ ';    
   2: temp:=temp+' Ôåâðàëÿ ';
   3: temp:=temp+' Ìàðòà ';
   4: temp:=temp+' Àïðåëÿ ';
   5: temp:=temp+' Ìàÿ ';
   6: temp:=temp+' Èþíÿ ';
   7: temp:=temp+' Èþëÿ ';
   8: temp:=temp+' Àâãóñòà ';
   9: temp:=temp+' Ñåíòÿáðÿ ';
   10: temp:=temp+' Îêòÿáðÿ ';       
   11: temp:=temp+' Íîÿáðÿ ';
   12: temp:=temp+' Äåêàáðÿ ';       
   end;                     
  // temp:=temp + FormatDateTime('yyyy',dt);                                                                                    
   Result:=temp;
end;  
  
function StretchFont(m:TfrxMemoView;s:String):String;
var      
       i:Extended;
       btmp:TBitmap;
       f:boolean;
       flowto:TFrxMemoView;
       LastMemoView:TfrxMemoView;
       fs:Integer;                               
begin
      fs:=5;              
       btmp:=TBitmap.Create();
       LastMemoView:=m;                                                                           
       f:=false;
       flowto:=TfrxMemoView(m.FlowTo);
         i:=m.Width-m.ParagraphGap-m.GapX;
        while flowto<> nil do
        begin                    
               i:=i+flowto.Width-flowto.ParagraphGap-flowto.GapX;
               flowto:= TFrxMemoView(flowto.FlowTo);                                                             
        end;                  
         
         i:=i*0.96; //                                                                                                                                               


         
while not f do
begin
               btmp.Canvas.Font:=m.Font;
               if((btmp.Canvas.TextWidth(s)<i) or (m.Font.Size<=fs)) then           
                     f:=true
               else
                    begin                              
                      m.Font.Size:=m.Font.Size-1;
                      flowto:=TFrxMemoView(m.FlowTo);                                                                                  
                     while flowto<> nil do
                        begin                    
                                flowto.Font.Size:=flowto.Font.Size-1;
                                lastmemoview:=flowto;                                                                                
                                flowto:= TFrxMemoView(flowto.FlowTo);                                    
                        end;                       
                    end;                                                      
end;          
btmp.Free();
if(m.Font.Size<=fs) then
       lastmemoview.WordWrap:=true;                                                            
result:=s;                                  
end;

begin
Line1.Visible:=<UserData."insur_is_face">=0;

MasterData1.DataSet.First;

while(not MasterData1.DataSet.Eof)do
begin
       if(<UserData_4."num">=1) then
         begin
               Memo80.Text:=FormatFloat('###,###,###',<UserData_4."sm">);
               //Memo89.Text:=FormatFloat('###,###,###',<UserData_4."prem">);                                             
         end;                   

       if(<UserData_4."num">=2) then
         begin
               //Memo83.Text:=FormatFloat('###,###,###',<UserData_4."sm">);
               //Memo92.Text:=FormatFloat('###,###,###',<UserData_4."prem">);                                             
         end;                   
    
  MasterData1.dataSet.Next;                                        
end;          

  
end.


//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////


Форма № [UserData."polis_short_name"]

<b>СТРАХОВЩИК:</b> [UserData."orgform"] «РОСГОССТРАХ»

Лицензия  [UserData."license"]

Серия [UserData."polis_seria"]

№ [UserData."polis_number"]


[(IIF((<UserData."insur_status">=1) and (ValidDate(<UserData."polis_date">)),Copy(<UserData."polis_date">,1,2),'- - -'))]
[(IIF((<UserData."insur_status">=1) and (ValidDate(<UserData."polis_date">)),DateToStrM(<UserData."polis_date">),'- - - - - - '))]
[(IIF((<UserData."insur_status">=1) and (ValidDate(<UserData."polis_date">)),Copy(<UserData."polis_date">,9,2),'- -'))]
<=>
[IIF( length(<UserData."insur_inn">)>0,Copy(<UserData."polis_date">,1,2),'- - -')]
[IIF( length(<UserData."insur_inn">)>0,DateToStrM(<UserData."polis_date">),'- - - - - ')]
[IIF( length(<UserData."insur_inn">)>0,Copy(<UserData."polis_date">,9,2),'- -')]


[<UserData."avto_count_zastr">] <=> [MasterData2.DataSet.RecordCount]

ФИО
[UserData."insur_full_name"]

[<UserData."insur_inn">]
[UserData."insur_ogrn"]

***дата гос.регистрации
1
2
3

рег орган
[UserData."insur_regorg_name"]
документ удост
[StretchFont(Memo32,iif(<UserData."insur_status">=0,<UserData."insur_doc_type">+' серия: '+<UserData."insur_document_series">+', №: '+<UserData."insur_document_number">+' Выдан: '+<UserData."insur_document_issue_org">+' '+FormatDateTime('dd.mm.yyyy',<UserData."insur_document_issue_date">)+' г.',''))]

гражд
[UserData."insur_nationality"]
дата рожд
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,1,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,2,1),'-'))]

[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,4,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,5,1),'-'))]

[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,7,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,8,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,9,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,10,1),'-'))]

телефон
[StretchFont(Memo48,<UserData."insur_phone_mobil">+'  '+<UserData."insur_phone_home">)]
<=>
[StretchFont(Memo48,<UserData."insur_phone_contact"> + '  ' + <UserData."insur_phone_mobil"> + '  ' + <UserData."insur_phone_home">)]
АДРЕС
[<UserData."insur_adr_index">+ ', '+ <UserData."insur_adr_kr_obl"> 
+ ' '+<UserData."insur_adr_raion"> 
+ ' '+<UserData."insur_adr_nas_punkt">
+ ' '+<UserData."insur_adr_ulitsa"> + ' д.'+ <UserData."insur_adr_dom"> + ' корп./стр.' + <UserData."insur_adr_korpus"> + ' кв.'+ <UserData."insur_adr_kvartira">]


ЗАСТРАХ ЛИЦО
[iif(<UserData."avto_count_zastr">=1, <UserData_2."full_name">,'Согласно приложенному к Полису списку')]
<!=>
[(IIF( (MasterData2.DataSet.RecordCount =1), (<UserData_3."famil">+' '+<UserData_3."name">+' '+<UserData_3."otch">),'Согласно приложенному к Полису списку'))]

Адрес
[iif(<UserData."avto_count_zastr">=1, <UserData_2."address">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
Дата рождения
<!=>
[(IIF( (MasterData2.DataSet.RecordCount =1) and  ValidDate(<UserData_3."birthday">),Copy(<UserData_3."birthday">,1,1),'- -'))]

[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,1,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,2,1),'- -'))]
/
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,4,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,5,1),'- -'))]
/
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,7,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,8,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,9,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,10,1),'- -'))]


ТЕЛ
[IIF(<UserData."avto_count_zastr">=1,<UserData_2."phone_home">+' '+<UserData_2."phone_mobil">,'- - - - - - - - - - - - - - - - - - - - - - -')]

СТРАХ СУММА НА ОДНОГО
[UserData_2."str_summ"]

ОБЩАЯ СТРАХОВАЯ СУММА
[UserData."SumString"]
ОБЩАЯ СТРАХОВАЯ ПРЕМИЯ
[UserData."PremiumString"]

ПОЛУЧЕНА
<!=>
[IIF(<UserData."ns_payment_id">=1, Copy(<UserData."ns_paymentdata">,1,1), 
IIF( <UserData."ns_payment_id">=3, Copy(<UserData."ns_beznalpaymentdata">,1,1),'- -'))]

[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,2,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,5,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,10,1),'- -'))]



1
[IIF(<UserData."payment_id">=1,'V','- -')]
НАЛ
[IIF(<UserData."payment_id">=3,'V','- -')]
безнал 
поруч №
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,1,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,2,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,3,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,4,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,5,1),'- -')]
от
[(IIF((<UserData."ns_payment_doc_id">=2) and ValidDate(<UserData."ns_paymentdata">),Copy(<UserData."ns_paymentdata">,1,1),'- -'))]

[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,1,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,2,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,4,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,5,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,9,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,10,1),'- -'))]

СРОК ДЕЙСТВИЯ ДОГОВОРА – 1 год
с 0 часов 00 минут
[Copy(<UserData."srok_date_s">,1,1)]


[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,2,1),'- -'))]
/
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,5,1),'- -'))]
/
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,7,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,8,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,10,1),'- -'))]
по 23 часа 59 минут
[Copy(<UserData."srok_date_po">,1,1)]

[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,2,1),'- -'))]
/
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,5,1),'- -'))]
/
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,7,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,8,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,10,1),'- -'))]

ВЫГОДОПРИОБРЕТАТЕЛЬ(Ф.И.О.)
1
2

ПРИЗНАК ДОГОВОРА:
[IIF(<UserData."dogovor_type">=0,'V','- -')]
первоначальный
[IIF(<UserData."dogovor_type">=2,'V','- -')]
дубликат
[IIF(<UserData."dogovor_type">=1,'V','- -')]
возобновление договора серия
[IIF(<UserData."dogovor_type">=1,<UserData."prev_seria">,'- - - - - - - -')]
№
[IIF(<UserData."dogovor_type">=1,<UserData."prev_number">,'- - - - - - - - - -')]

действующего до
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,1,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,2,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,4,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,5,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,9,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,10,1),'- -'))]

под подписью
[iif(<UserData."insur_status"> <>1,<UserData."insur_full_name">,<UserData."insur_fio_predst"> )]
<!=>
[UserData."pol_zayav_strah_fio"]

Дата
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,5,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -'))]

<b>ЗАСТРАХОВАННЫЙ:</b>
***

<b>СТРАХОВЩИК:</b>
[StretchFont(Memo200,<UserData."agent">)]

Дата выдачи полиса
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,5,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -'))]

Банк посредник
[StretchFont(Memo207,<UserData."bank_name">)]
Канал продаж
[StretchFont(Memo208,<UserData."sale_channel">)]
Агент
[StretchFont(Memo211,<UserData."agent">)]
Группа продавцов
[StretchFont(Memo212,<UserData."group_sales">)]

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

КВИТАНЦИЯ № [UserData."pp_number"] Серия [UserData."pp_seria"] 
НА ПОЛУЧЕНИЕ СТРАХОВОЙ ПРЕМИИ (ВЗНОСА)

Страховщик: [UserData."orgformfull"] «РОСГОССТРАХ»

Страхователь
[UserData."insur_full_name"]

Номер и серия страхового полиса
Серия [UserData."polis_seria"] № [UserData."polis_number"]

Вид страхования 
СТРАХОВАНИЕ ОТ НЕСЧАСТНЫХ СЛУЧАЕВ И БОЛЕЗНЕЙ

Получена страховая премия (взнос)
[UserData."PremiumString"]
<!=>
[iif(<UserData."ns_payment_doc_id">=10,<UserData_3."PremiumString">,'')]


В том числе: наличными денежными средствами
[IIF((<UserData."payment_card">=false) ,<UserData."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
<!=>
[IIF(<UserData."ns_payment_id">=1,<UserData_3."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]

с использованием платежной карты
***

Получил
Представитель Страховщика/Страховой брокер
[UserData."agent"]

Оплатил
[iif(<UserData."insur_status"> <>1,<UserData."insur_full_name">,<UserData."insur_fio_predst">)]
<!=>
[UserData."pol_zayav_strah_fio"]

Дата расчета
[IIF(ValidDate(<UserData."pol_zayav_date_zayav">),Copy(<UserData."pol_zayav_date_zayav">,1,1),'- -')]

[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),DateToStrM(<UserData."polis_date">),'- - - - - ')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,7,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,8,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -')]


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////



      AnsiString s1 = DateToStr(ns_date_s);
      AnsiString s2 = DateToStr(ns_date_po);
      int u=0;
	  

2017 Полис Фортуна АВТО(черновик)
2
2017 Полис Фортуна АВТО
3
2017 1-ЮЛ полис Фортуна АВТО(черновик)
4
2017 1-ЮЛ полис Фортуна АВТО
5
2017 ФА Оборотная сторона
6
Фортуна приложение(список застрахованных)
7
Фортуна Заявление ждя юр.лиц



КВИТАНЦИЯ № [UserData."ns_paymentnum"] Серия [UserData."ns_paymentser"] 
НА ПОЛУЧЕНИЕ СТРАХОВОЙ ПРЕМИИ (ВЗНОСА)

Серия [UserData."ns_policy_bso_series"] № [UserData."ns_polis_num"]









UserData_4

Memo3
<b>СТРАХОВЩИК:</b> [UserData."orgform"] «РОСГОССТРАХ»
Memo4
Лицензия  [UserData."license"]
Memo6
Серия [UserData."ns_policy_bso_series"]
Memo7
№ [UserData."ns_polis_num"]
Memo11
[UserData."pol_zayav_strah_fio"]

Memo14
[<UserData."pol_zayav_strah_inn">]
Memo32
[StretchFont(Memo32,<UserData."pol_zayav_strah_docum">+' серия: '+<UserData."pol_zayav_strah_doc_ser">+',№:'+<UserData."pol_zayav_strah_doc_num">
+ IIF( length(<UserData."pol_zayav_strah_inn">)=0, ' Выдан: '+<UserData."pol_zayav_strah_doc_vidan">+' '+FormatDateTime('dd.mm.yyyy',<UserData."pol_zayav_strah_doc_date">)+' г.', '')
)]

Memo34
[UserData."pol_zayav_strah_grajdanstvo"]
Memo36
[IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,1,1),'-')]
Memo37
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,2,1),'-'))]
Memo39
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,4,1),'-'))]
Memo40
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,5,1),'-'))]
Memo42
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,7,1),'-'))]
Memo43
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,8,1),'-'))]
Memo44
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,9,1),'-'))]
Memo45
[(IIF(ValidDate(<UserData."pol_zayav_strah_date_rojd">),Copy(<UserData."pol_zayav_strah_date_rojd">,10,1),'-'))]

Memo48
[StretchFont(Memo48,<UserData."pol_zayav_strah_telefon3"> + '  ' + <UserData."pol_zayav_strah_telefon"> + '  ' + <UserData."pol_zayav_strah_telefon2">)]

Memo50
[<UserData."pol_zayav_strah_index">+ ', '+ <UserData."pol_zayav_strah_res_kr_obl"> 
+ ' '+<UserData."pol_zayav_strah_raion"> 
+ ' '+<UserData."pol_zayav_strah_nas_punkt">
+ ' '+<UserData."pol_zayav_strah_ulitsa"> + ' д.'+ <UserData."pol_zayav_strah_dom"> + ' корп./стр.' + <UserData."pol_zayav_strah_korpus"> + ' кв.'+ <UserData."pol_zayav_strah_kvartira">]










<b>СТРАХОВЩИК:</b> [UserData."orgform"] «РОСГОССТРАХ»
Лицензия  [UserData."license"]

Серия [UserData."polis_seria"]
№ [UserData."polis_number"]

32
[StretchFont(Memo32,iif(<UserData."insur_status">=0,<UserData."insur_document_type_id">+' серия: '+<UserData."insur_document_series">+', №: '+<UserData."insur_document_number">+' Выдан: '+<UserData."insur_document_issue_org">+' '+FormatDateTime('dd.mm.yyyy',<UserData."insur_document_issue_date">)+' г.',''))]

[StretchFont(Memo32,iif(<UserData."insur_status">=0,<UserData."insur_doc_type">+' серия: '+<UserData."insur_document_series">+', №: '+<UserData."insur_document_number">+' Выдан: '+<UserData."insur_document_issue_org">+' '+FormatDateTime('dd.mm.yyyy',<UserData."insur_document_issue_date">)+' г.',''))]
insur_doc_type




[(IIF((<UserData."insur_status">=1) and (ValidDate(<UserData."polis_date">)),Copy(<UserData."polis_date">,1,2),'- - -'))]
[(IIF((<UserData."insur_status">=1) and (ValidDate(<UserData."polis_date">)),DateToStrM(<UserData."polis_date">),'- - - - - '))]
[(IIF((<UserData."insur_status">=1) and (ValidDate(<UserData."polis_date">)),Copy(<UserData."polis_date">,9,2),'- -'))]

[<UserData."avto_count_zastr">]


// Страхователь
[UserData."insur_full_name"]
[<UserData."insur_inn">]
[UserData."insur_ogrn"]

FormatDateTime('dd',<UserData."pol_zayav_strah_doc_date">)
FormatDateTime('mm',<UserData."pol_zayav_strah_doc_date">)
FormatDateTime('yyyy',<UserData."pol_zayav_strah_doc_date">)

FormatDateTime('dd.mm.yyyy',<UserData."pol_zayav_strah_doc_date">)


[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,2,1),'- -'))]

[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,5,1),'- -'))]

[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,7,1),'- -'))]
[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,8,1),'- -'))]
[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."insur_dategosreg">),Copy(<UserData."insur_dategosreg">,10,1),'- -'))]
//

[UserData."insur_regorg_name"]
[StretchFont(Memo32,iif(<UserData."insur_status">=0,<UserData."insur_doc_type">+' серия: '+<UserData."insur_document_series">+', №: '+<UserData."insur_document_number">+' Выдан: '+<UserData."insur_document_issue_org">+' '+FormatDateTime('dd.mm.yyyy',<UserData."insur_document_issue_date">)+' г.',''))]

[iif(Length(<UserData."insur_nationality">)>0,<UserData."insur_nationality">,'- - - - - - - - - - ')]

[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,1,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,2,1),'-'))]

[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,4,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,5,1),'-'))]

[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,7,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,8,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,9,1),'-'))]
[(IIF(ValidDate(<UserData."insur_birth_date">),Copy(<UserData."insur_birth_date">,10,1),'-'))]

[StretchFont(Memo48,<UserData."insur_phone_mobil">+'  '+<UserData."insur_phone_home">)]

[UserData."insur_address"]

////

[iif(<UserData."avto_count_zastr">=1, <UserData_2."full_name">,'Согласно приложенному к Полису списку')]

[iif(<UserData."avto_count_zastr">=1, <UserData_2."address">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]

[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,1,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,2,1),'- -'))]

[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,4,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,5,1),'- -'))]

[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,7,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,8,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,9,1),'- -'))]
[(IIF( (<UserData."avto_count_zastr">=1) and  ValidDate(<UserData_2."phisical_birth_date">),Copy(<UserData_2."phisical_birth_date">,10,1),'- -'))]

[IIF(<UserData."avto_count_zastr">=1,<UserData_2."phone_home">+' '+<UserData_2."phone_mobil">,'- - - - - - - - - - - - - - - - - - - - - - -')]

////

[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=1 ) and(<UserData."insur_is_face">=1)  ,'V'     ,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
Застр.Лицо
[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=1 ) and(<UserData."insur_is_face">=0)  ,'V'     ,'- - - - - - - - - - - - - - - -')]

[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=2 ) and(<UserData."insur_is_face">=1)  ,'V'     ,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
Застр.Лицо
[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=2 ) and(<UserData."insur_is_face">=0)  ,'V'     ,'- - - - - - - - - - - - - - - -')]


[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=1 ) and(<UserData."insur_is_face">=1)  ,'V'     ,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
Застр.Лицо
[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=1 ) and(<UserData."insur_is_face">=0)  ,'V'     ,'- - - - - - - - - - - - - - - -')]

[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=2 ) and(<UserData."insur_is_face">=1)  ,'V'     ,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
Застр.Лицо
[IIF( (<UserData."avto_count_zastr">=1)  and (<UserData_2."nums">=2 ) and(<UserData."insur_is_face">=0)  ,'V'     ,'- - - - - - - - - - - - - - - -')]


[UserData."SumString"]
[UserData."PremiumString"]
получена
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,2,1),'- -'))]
,
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,5,1),'- -'))]
,
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."payment_date">),Copy(<UserData."payment_date">,10,1),'- -'))]
у
[IIF(<UserData."payment_id">=1,'V','- -')]
[IIF(<UserData."payment_id">=3,'V','- -')]

№
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,1,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,2,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,3,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,4,1),'- -')]
[IIF(<UserData."payment_doc_id">=2,Copy(<UserData."pp_number">,5,1),'- -')]

от 
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,1,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,2,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,4,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,5,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,9,1),'- -'))]
[(IIF((<UserData."payment_doc_id">=2) and ValidDate(<UserData."pp_date">),Copy(<UserData."pp_date">,10,1),'- -'))]

////

[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,2,1),'- -'))]

[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,5,1),'- -'))]

[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,7,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,8,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,10,1),'- -'))]

по 23 часов 59 минут
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,2,1),'- -'))]

[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,5,1),'- -'))]

[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,7,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,8,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."srok_date_po">),Copy(<UserData."srok_date_po">,10,1),'- -'))]


ПРИЗНАК ДОГОВОРА:
[IIF(<UserData."dogovor_type">=0,'V','- -')]

[IIF(<UserData."dogovor_type">=2,'V','- -')]

[IIF(<UserData."dogovor_type">=1,'V','- -')]

возобн дог номер
[IIF(<UserData."dogovor_type">=1,<UserData."prev_seria">,'- - - - - - - -')]
[IIF(<UserData."dogovor_type">=1,<UserData."prev_number">,'- - - - - - - - - -')]
действующего до
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,1,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,2,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,4,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,5,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,9,1),'- -'))]
[(IIF((<UserData."dogovor_type">=1) and ValidDate(<UserData."prev_date">),Copy(<UserData."prev_date">,10,1),'- -'))]

ИНЫЕ УСЛОВИЯ

[iif(<UserData."insur_status"> <>1,<UserData."insur_full_name">,<UserData."insur_fio_predst"> )]

[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -'))]

[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,5,1),'- -'))]

[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -'))]

<b>СТРАХОВАТЕЛЬ:</b> . С условиями договора, в том числе изложенными на . оборотной стороне настоящего полиса, согласен. Полис и правила страхования получил.
Дата выдачи полиса
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -'))]

[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,4,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,5,1),'- -'))]

[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -'))]
[(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -'))]
Проект
[StretchFont(Memo202,<UserData."project_name">)]

<b>ЗАСТРАХОВАННЫЙ:</b>
с назначением Выгодоприобретателя (-ей) согласен
[iif(<UserData."avto_count_zastr">=1, <UserData_2."full_name">,'- - - - - - - -')]

Банк посредник
[StretchFont(Memo207,<UserData."bank_name">)]
Канал продаж
[StretchFont(Memo208,<UserData."sale_channel">)]

<b>СТРАХОВЩИК:</b>
наименование, почтовый адрес, телефон
[StretchFont(Memo200,<UserData."agent">)]

Агент
[StretchFont(Memo211,<UserData."agent">)]
Группа продавцов
[StretchFont(Memo212,<UserData."group_sales">)]

////////////////////////////////////////////////////
// СТРАНИЦА ДВА

(!) КВИТАНЦИЯ № [UserData."ns_paymentnum"] Серия [UserData."ns_paymentser"] 
НА ПОЛУЧЕНИЕ СТРАХОВОЙ ПРЕМИИ (ВЗНОСА)

Страховщик: [UserData."orgformfull"] «РОСГОССТРАХ»

Страхователь
[iif(<UserData."payment_doc_id">=10,<UserData."insur_full_name">,'')]

Номер и серия страхового полиса
[iif(<UserData."payment_doc_id">=10,'Серия: '+<UserData."polis_seria">+' Номер: '+<UserData."polis_number">,'')]

Вид страхования СТРАХОВАНИЕ ОТ НЕСЧАСТНЫХ СЛУЧАЕВ

Получена страховая премия (взнос)
[iif(<UserData."payment_doc_id">=10,<UserData."PremiumString">,'')]
В том числе:наличными денежными средствами
[IIF((<UserData."payment_doc_id">=10) and (<UserData."payment_card">=false) ,<UserData."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
с использованием платежной карты
[IIF((<UserData."payment_doc_id">=10) and (<UserData."payment_card">=true) ,<UserData."PremiumString">,'- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')]
Получил
Представитель Страховщика/Страховой брокер
[IIF(<UserData."payment_doc_id">=10,<UserData."agent">,'')]

Оплатил
[IIF(<UserData."payment_doc_id">=10,iif(<UserData."insur_status"> <>1,<UserData."insur_full_name">,<UserData."insur_fio_predst">),'')]
Дата расчета
[IIF(<UserData."payment_doc_id">=10,IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -'),'')]
[IIF(<UserData."payment_doc_id">=10,(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -')),'')]

[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,1,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,2,1),'- -')]

[IIF(<UserData."payment_doc_id">=10,IIF(ValidDate(<UserData."polis_date">),DateToStrM(<UserData."polis_date">),'- - - - - '),'')]
[IIF(ValidDate(<UserData."polis_date">),DateToStrM(<UserData."polis_date">),'- - - - - ')]


[IIF(<UserData."payment_doc_id">=10,(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,7,1),'- -')),'')]
[IIF(<UserData."payment_doc_id">=10,(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,8,1),'- -')),'')]
[IIF(<UserData."payment_doc_id">=10,(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -')),'')]
[IIF(<UserData."payment_doc_id">=10,(IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -')),'')]

[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,7,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,8,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,9,1),'- -')]
[IIF(ValidDate(<UserData."polis_date">),Copy(<UserData."polis_date">,10,1),'- -')]



















[(IIF(ValidDate(<UserData."srok_date_s">),Copy(<UserData."srok_date_s">,1,1),'- -'))]





SELECT ckk_7_5_4.BLANK_SERIES_ID, CKK_7_5_4.SERIES_NAME
FROM rgsscc.ref_dictblankseries ckk_7_5_4
WHERE ckk_7_5_4.scc_status = 0
AND CKK_7_5_4.SERIES_NAME
IN (
'Н5033'
,'Н5035'
,'Н7006'
,'Н7007'
,'Н7008'
,'Н7009'
,'Н7010'
,'Н7011'
,'Н7012'
,'Н7013'
,'Н7014'
,'Н7015'
,'Н7016'
,'Н7017'
,'Н7041'
,'Н7042'
,'Н7043'
,'Н7044'
,'Н7046'
,'Н7047'
,'Н7048'
,'Н7049'
,'Н7050'
,'Н7051'
,'Н7052'
,'Н7073'
,'Н7074'
,'Н7075'
,'Н7076'
,'Н7077'
,'Н7078'
,'Н7079'
,'Н7080'
,'Н7081'
,'Н7082'
,'Н7083'
,'Н7084'
,'Н7085'
,'Н7086'
,'Н7087'
,'Н7088'
,'Н7089'
,'Н7090'
,'Н8010'
,'Н8011'
,'Н8012'
,'Н8013'
,'Н8014'
,'Н8015'
,'Н8050'
,'Н8051'
,'Н8053'
,'Н8054'
,'Н8055'
,'Н8056'
,'Н8057'
,'Н8058'
,'Н8059'
,'Н8060'
,'Н8061'
)
GROUP BY CKK_7_5_4.BLANK_SERIES_ID, CKK_7_5_4.SERIES_NAME


SELECT ckk_7_5_4.BLANK_SERIES_ID, CKK_7_5_4.SERIES_NAME
FROM rgsscc.ref_dictblankseries ckk_7_5_4
WHERE ckk_7_5_4.scc_status = 0
AND CKK_7_5_4.SERIES_NAME
IN (
'7200'
,'СН6130'
,'СН6131'
,'СН6132'
,'СН6133'
,'СН6134'
,'СН7130'
,'СН7131'
,'СН7132'
,'СН7133'
,'СН7134'
,'СН6230'
,'СН6231'
,'СН6232'
,'СН6233'
,'СН6234'
,'СН7230'
,'СН7231'
,'СН7232'
,'СН7233'
,'СН7234'
,'Н7075'
,'Н7006'
,'Н8015'
,'Н7074'
,'Н7081'
,'Н7012'
,'Н7047'
,'Н8051'
,'Н7078'
,'Н7086'
,'Н7077'
,'Н7076'
,'Н8053'
,'Н7048'
,'Н7015'
,'Н7009'
,'7009'
,'7047'
,'7048'
,'1-5034'
,'1-5034'
,'7041'
,'7044'
,'7006'
,'7074'
,'7073'
,'7075'
,'7075'
,'Н7041'
,'7016'
,'Н7044'
,'Н8050'
,'Н7043'
,'4000'
,'6001'
,'4000'
,'6002'
,'СБ 26'
,'СН7135'
,'СН6135'
,'7100'
,'7100'
,'СБ 78'
,'СБ 78'
,'7200'
,'СН8130'
,'СН8131'
,'СН8132'
,'СН8133'
,'СН8134'
,'СН9130'
,'СН9131'
,'СН9132'
,'СН9133'
,'СН9134'
,'СН8230'
,'СН8231'
,'СН8232'
,'СН8233'
,'СН8234'
,'СН9230'
,'СН9231'
,'СН9232'
,'СН9233'
,'СН9234'
,'Н7073'
,'Н7007'
,'Н7042'
,'Н8054'
,'Н7079'
,'Н8056'
,'Н7080'
,'Н7082'
,'Н8055'
,'Н7049'
,'Н7013'
,'Н7087'
,'Н7088'
,'Н7014'
,'Н7050'
,'Н8057'
,'Н7089'
,'Н8013'
,'7007'
,'7008'
,'7049'
,'7050'
,'2-5035'
,'2-5035'
,'7042'
,'7043'
,'Н7008'
,'Н5035'
,'4000'
,'6001'
,'4000'
,'6002'
,'СБ 26'
,'7100'
,'7100'
,'СБ 78'
,'7200'
,'СН5130'
,'СН5131'
,'СН5132'
,'СН5133'
,'СН5134'
,'СН5230'
,'СН5231'
,'СН5232'
,'СН5233'
,'СН5234'
,'СН4230'
,'СН4231'
,'СН4232'
,'СН4233'
,'СН4234'
,'Н7046' 
,'Н8058'
,'Н7083'
,'Н8014'
,'Н8060'
,'Н7084'
,'Н7085'
,'Н7051'
,'Н8059'
,'Н7090'
,'Н8010'
,'Н8011'
,'Н7016'
,'Н7017'
,'Н7052'
,'Н8061'
,'Н8012'
,'Н7011'
,'Н7010'
,'Н5033'
,'7010'
,'7011'
,'7051'
,'7052'
,'3-5033'
,'3-5033'
,'7045'
,'7046'
,'СН4130'
,'СН4131'
,'СН4132'
,'СН4133'
,'СН4134'
,'4000'
,'6001'
,'4000'
,'6002'
,'СБ 26'
,'7100'
,'7100'
,'6033'
,'6034'
,'7200'
,'4000'
,'6001'
,'4000'
,'6002'
,'СБ 26'
,'7100'
,'СБ 78'
,'СН3001'
,'СН3002'
)
GROUP BY CKK_7_5_4.BLANK_SERIES_ID, CKK_7_5_4.SERIES_NAME






DROP VIEW APO.ALARMS_7_2_43;

/* Formatted on 07.12.2016 11:54:26 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.ALARMS_7_2_43
(
   "RequiredAlarmsScheme",
   "Product_Id",
   "Program_Id",
   "VehicleRsaModelId",
   "VehicleGroupId",
   "CascoTerritoryId",
   "VehicleYearMin",
   "VehicleYearMax",
   "PpsId",
   "PpsName",
   "EpsId",
   "EpsName",
   "MpuId",
   "MpuName",
   "risk_group",
   "Start_Date",
   "End_Date"
)
AS
     SELECT                                               --CKK_7_2_43.CKK_ID,
           CKK_7_2_51_6.NUMREQALARM_ID "RequiredAlarmsScheme",
            --CKK_7_2_51_6.ALARM_SYSTEMS "RequiredAlarmsText",
            -- CKK_7_2_43.RISK_GROUP "IsRiskVehicle"  ,
            NVL (CKK_7_3_2_1.PRODUCT_ID, 0) "Product_Id",
            NVL (CKK_7_4_8_2.PROJECT_ID, 0) "Program_Id",
            NVL (CKK_5_1_3_3.CODE, '000000000') "VehicleRsaModelId",
            NVL (CKK_7_2_9_4.VEHICLE_GROUP_ID, 0) "VehicleGroupId",
            NVL (CKK_7_2_8_5.CASCO_TERRITORY_ID, 0) "CascoTerritoryId",
            NVL (TO_CHAR (CKK_7_2_43.YEAR_PROD_MIN), 1900) "VehicleYearMin",
            NVL (TO_CHAR (CKK_7_2_43.YEAR_PROD_MAX), 3000) "VehicleYearMax",
            --ckk_7_2_51_6.alarm_guard_1,
            --ckk_7_2_49_1.scc_id,
            ckk_7_2_49_1.alarm_guard_id "PpsId",
            ckk_7_2_49_1.alarm_guard "PpsName",
            --ckk_7_2_51_6.alarm_guard_2,
            --ckk_7_2_49_2.scc_id,
            ckk_7_2_49_2.alarm_guard_id "EpsId",
            ckk_7_2_49_2.alarm_guard "EpsName",
            --ckk_7_2_51_6.alarm_guard_3,
            --ckk_7_2_49_3.scc_id,
            ckk_7_2_49_3.alarm_guard_id "MpuId",
            ckk_7_2_49_3.alarm_guard "MpuName",
            ckk_7_2_43.risk_group "risk_group",
            CKK_7_2_43.START_DATE "Start_Date",
            NVL (CKK_7_2_43.END_DATE, TO_DATE ('01.01.3000', 'dd.mm.yyyy'))
               "End_Date"
       FROM RGSSCC.REF_CASCOALARMSYSTEMS CKK_7_2_43,
            RGSSCC.REF_PRODUCT CKK_7_3_2_1,
            RGSSCC.REF_DICTPROJECT CKK_7_4_8_2,
            RGSSCC.REF_CARRIER_MODELS CKK_5_1_3_3,
            RGSSCC.REF_AUTODICTVEHICLEGROUP CKK_7_2_9_4,
            RGSSCC.REF_AUTODICTCASCOTERRITORY CKK_7_2_8_5,
            RGSSCC.REF_NUMREQALARM CKK_7_2_51_6,
            rgsscc.ref_alarm_guard ckk_7_2_49_1,
            rgsscc.ref_alarm_guard ckk_7_2_49_2,
            rgsscc.ref_alarm_guard ckk_7_2_49_3
      WHERE     CKK_7_2_51_6.NUMREQALARM_ID IS NOT NULL
            AND CKK_7_2_43.SCC_STATUS = 0
            AND CKK_7_2_43.TO_732_FK_ = CKK_7_3_2_1.SCC_ID(+)
            AND CKK_7_3_2_1.SCC_STATUS(+) = 0
            AND CKK_7_2_43.TO_748_FK_ = CKK_7_4_8_2.SCC_ID(+)
            AND CKK_7_4_8_2.SCC_STATUS(+) = 0
            AND CKK_7_2_43.CARRIER_MODELS_CODE_FK_ = CKK_5_1_3_3.SCC_ID(+)
            AND CKK_5_1_3_3.SCC_STATUS(+) = 0
            AND CKK_7_2_43.AUTODICTVEHICLEGROUP_VEHICL_F_ =
                   CKK_7_2_9_4.SCC_ID(+)
            AND CKK_7_2_9_4.SCC_STATUS(+) = 0
            AND CKK_7_2_43.AUTODICTCASCOTERRITORY_CASC_F_ =
                   CKK_7_2_8_5.SCC_ID(+)
            AND CKK_7_2_8_5.SCC_STATUS(+) = 0
            AND CKK_7_2_43.TO_7251_FK_ = CKK_7_2_51_6.SCC_ID(+)
            AND CKK_7_2_51_6.SCC_STATUS(+) = 0
            AND ckk_7_2_51_6.alarm_guard_1 = ckk_7_2_49_1.scc_id(+)
            AND ckk_7_2_49_1.scc_status(+) = 0
            AND ckk_7_2_51_6.alarm_guard_2 = ckk_7_2_49_2.scc_id(+)
            AND ckk_7_2_49_2.scc_status(+) = 0
            AND ckk_7_2_51_6.alarm_guard_3 = ckk_7_2_49_3.scc_id(+)
            AND ckk_7_2_49_3.scc_status(+) = 0
   ORDER BY 4,
            5,
            6,
            7,
            8,
            9,
            11;

			




DROP VIEW APO.ALARMS_7_2_43;

/* Formatted on 07.12.2016 11:54:26 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.ALARMS_7_2_43
(
   "RequiredAlarmsScheme",
   "Product_Id",
   "Program_Id",
   "VehicleRsaModelId",
   "VehicleGroupId",
   "CascoTerritoryId",
   "VehicleYearMin",
   "VehicleYearMax",
   "PpsId",
   "PpsName",
   "EpsId",
   "EpsName",
   "MpuId",
   "MpuName",
   "risk_group",
   "Start_Date",
   "End_Date"
)
AS
     SELECT                                               --CKK_7_2_43.CKK_ID,
           CKK_7_2_51_6.NUMREQALARM_ID "RequiredAlarmsScheme",
            --CKK_7_2_51_6.ALARM_SYSTEMS "RequiredAlarmsText",
            -- CKK_7_2_43.RISK_GROUP "IsRiskVehicle"  ,
            NVL (CKK_7_3_2_1.PRODUCT_ID, 0) "Product_Id",
            NVL (CKK_7_4_8_2.PROJECT_ID, 0) "Program_Id",
            NVL (CKK_5_1_3_3.CODE, '000000000') "VehicleRsaModelId",
            NVL (CKK_7_2_9_4.VEHICLE_GROUP_ID, 0) "VehicleGroupId",
            NVL (CKK_7_2_8_5.CASCO_TERRITORY_ID, 0) "CascoTerritoryId",
            NVL (TO_CHAR (CKK_7_2_43.YEAR_PROD_MIN), 1900) "VehicleYearMin",
            NVL (TO_CHAR (CKK_7_2_43.YEAR_PROD_MAX), 3000) "VehicleYearMax",
            --ckk_7_2_51_6.alarm_guard_1,
            --ckk_7_2_49_1.scc_id,
            ckk_7_2_49_1.alarm_guard_id "PpsId",
            ckk_7_2_49_1.alarm_guard "PpsName",
            --ckk_7_2_51_6.alarm_guard_2,
            --ckk_7_2_49_2.scc_id,
            ckk_7_2_49_2.alarm_guard_id "EpsId",
            ckk_7_2_49_2.alarm_guard "EpsName",
            --ckk_7_2_51_6.alarm_guard_3,
            --ckk_7_2_49_3.scc_id,
            ckk_7_2_49_3.alarm_guard_id "MpuId",
            ckk_7_2_49_3.alarm_guard "MpuName",
            ckk_7_2_43.risk_group "risk_group",
            CKK_7_2_43.START_DATE "Start_Date",
            NVL (CKK_7_2_43.END_DATE, TO_DATE ('01.01.3000', 'dd.mm.yyyy'))
               "End_Date"
       FROM RGSSCC.REF_CASCOALARMSYSTEMS CKK_7_2_43,
            RGSSCC.REF_PRODUCT CKK_7_3_2_1,
            RGSSCC.REF_DICTPROJECT CKK_7_4_8_2,
            RGSSCC.REF_CARRIER_MODELS CKK_5_1_3_3,
            RGSSCC.REF_AUTODICTVEHICLEGROUP CKK_7_2_9_4,
            RGSSCC.REF_AUTODICTCASCOTERRITORY CKK_7_2_8_5,
            RGSSCC.REF_NUMREQALARM CKK_7_2_51_6,
            rgsscc.ref_alarm_guard ckk_7_2_49_1,
            rgsscc.ref_alarm_guard ckk_7_2_49_2,
            rgsscc.ref_alarm_guard ckk_7_2_49_3
      WHERE     CKK_7_2_51_6.NUMREQALARM_ID IS NOT NULL
            AND CKK_7_2_43.SCC_STATUS = 0
            AND CKK_7_2_43.TO_732_FK_ = CKK_7_3_2_1.SCC_ID(+)
            AND CKK_7_3_2_1.SCC_STATUS(+) = 0
            AND CKK_7_2_43.TO_748_FK_ = CKK_7_4_8_2.SCC_ID(+)
            AND CKK_7_4_8_2.SCC_STATUS(+) = 0
            AND CKK_7_2_43.CARRIER_MODELS_CODE_FK_ = CKK_5_1_3_3.SCC_ID(+)
            AND CKK_5_1_3_3.SCC_STATUS(+) = 0
            AND CKK_7_2_43.AUTODICTVEHICLEGROUP_VEHICL_F_ =
                   CKK_7_2_9_4.SCC_ID(+)
            AND CKK_7_2_9_4.SCC_STATUS(+) = 0
            AND CKK_7_2_43.AUTODICTCASCOTERRITORY_CASC_F_ =
                   CKK_7_2_8_5.SCC_ID(+)
            AND CKK_7_2_8_5.SCC_STATUS(+) = 0
            AND CKK_7_2_43.TO_7251_FK_ = CKK_7_2_51_6.SCC_ID(+)
            AND CKK_7_2_51_6.SCC_STATUS(+) = 0
            AND ckk_7_2_51_6.alarm_guard_1 = ckk_7_2_49_1.scc_id(+)
            AND ckk_7_2_49_1.scc_status(+) = 0
            AND ckk_7_2_51_6.alarm_guard_2 = ckk_7_2_49_2.scc_id(+)
            AND ckk_7_2_49_2.scc_status(+) = 0
            AND ckk_7_2_51_6.alarm_guard_3 = ckk_7_2_49_3.scc_id(+)
            AND ckk_7_2_49_3.scc_status(+) = 0
   ORDER BY 4,
            5,
            6,
            7,
            8,
            9,
            11;

			
			
			




DROP VIEW APO.BANKI;

/* Formatted on 07.12.2016 9:57:55 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.BANKI
(
   ID,
   CODE,
   NAME,
   SORT_ORDER,
   REF_CODE
)
AS
     SELECT id,
            code,
            name,
            sort_order,
            LPAD (code, 2, code) AS ref_code
       FROM rgsscc.ref_fid_banki
      WHERE     date_from <= SYSDATE
            AND NVL (date_to, SYSDATE) >= SYSDATE
            AND ref_code_fk_fk <> 1
   ORDER BY sort_order;
   
   
   
   
   

DROP VIEW APO.BASE_RATE_KASKO_7_3_59;

/* Formatted on 06.12.2016 15:00:45 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.BASE_RATE_KASKO_7_3_59
(
   CASCO_BASE_RATE_ID,
   PRODUCT_ID,
   VEHICLE_GROUP_ID,
   CASCO_TERRITORY_TYPE_ID,
   CASCO_RISK_ID,
   VEHICLE_AGE,
   DAMAGE_SUM_LIMIT,
   NON_AGGREGATE_SUM,
   COEFF_VALUE,
   START_DATE,
   END_DATE
)
AS
     SELECT TO_NUMBER (ckk_7_3_59.casco_base_rate_id) casco_base_rate_id,
            TO_NUMBER (ckk_7_3_63.casco_territory_type_id)
               casco_territory_type_id,
            TO_NUMBER (ckk_7_3_59.vehicle_age) vehicle_age,
            NVL (ckk_7_3_59.damage_sum_limit, 0) damage_sum_limit,
            TO_NUMBER (ckk_7_3_59.non_aggregate_sum) non_aggregate_sum,
            ckk_7_3_59.coeff_value,
            NVL (ckk_7_3_59.end_date, '01.01.3000') end_date
(!!!)  FROM rgsscc.ref_cascodictbaserate_ ckk_7_3_59 
            LEFT JOIN rgsscc.ref_product ckk_7_3_2
               ON ckk_7_3_59.tabl_7_3_2_fk_ = ckk_7_3_2.scc_id
                  AND ckk_7_3_2.scc_status = 0
      WHERE ckk_7_3_59.scc_status = 0
   ORDER BY TO_NUMBER (ckk_7_3_59.casco_base_rate_id);


//////////////////////////////////////////////////////////////////////

APO.NSFA_DICT_PROD_BLANK_7_10_16
APO.NSFA_DICT_BLANK_SERIES_7_5_4
APO.NSFA_DICT_B_TYPES_SERIES_7_5_5
APO.NSFA_DICT_BLANK_TYPE_7_4_9

gl_dict_7_5_4_blank_series
gl_dict_7_5_5_blank_types_series_relation
gl_dict_7_4_9_blank_types
gl_dict_7_10_16_product_blank_relation

//////////////////////////////////////////////////////////////////////

select * from rgsscc.REF_CASCOALARMSYSTEMS CKK_7_2_43 
      WHERE CKK_7_2_43.scc_status = 0
   
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

APO.NSFA_DICT_BLANK_SERIES_7_5_4

NSFA_DICT_BLANK_SERIES_7_5_4
gl_dict_7_5_4_blank_series

select * from rgsscc.ref_product_blank_fa ckk_7_10_16 
      WHERE ckk_7_10_16.scc_status = 0

select * from rgsscc.ref_dictblankseries ckk_7_5_4 
      WHERE ckk_7_5_4.scc_status = 0

      SCC_ID
      SCC_STATUS
      BASE_ID
      TICK
	  DATE_TO
      DATE_FROM
	  ID
	  SERIES_NAME
	  SORT_ORDER
	  BLANK_SERIES_ID
	  CREATION_TIME
	  IS_NODE
	  USER_ID

	  
DROP VIEW APO.NSFA_DICT_BLANK_SERIES_7_5_4;

/* Formatted on 07.12.2016 10:14:07 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.NSFA_DICT_BLANK_SERIES_7_5_4
(
   SCC_ID,
   DATE_TO,
   DATE_FROM,
   SERIES_NAME,
   BLANK_SERIES_ID
)
AS
   SELECT ckk_7_5_4.scc_id,
          ckk_7_5_4.date_to,
          ckk_7_5_4.date_from,
          ckk_7_5_4.series_name,
          ckk_7_5_4.blank_series_id
     FROM rgsscc.ref_dictblankseries ckk_7_5_4
    WHERE ckk_7_5_4.scc_status = 0;

/*
     SELECT TO_NUMBER (ckk_7_4_9.scc_id) scc_id,
            TO_NUMBER (ckk_7_4_9.scc_status) scc_status,
            TO_NUMBER (ckk_7_4_9.blank_type_name) vehicle_age,
            NVL (ckk_7_4_9.damage_sum_limit, 0) damage_sum_limit,
            NVL (ckk_7_4_9.end_date, '01.01.3000') end_date
(!!!)  FROM rgsscc.ref_dictblanktype ckk_7_4_9 
      WHERE ckk_7_4_9.scc_status = 0
*/

	
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

APO.NSFA_DICT_B_TYPES_SERIES_7_5_5
	  
NSFA_DICT_BLANK_TYPES_SERIES_RELATION_7_5_5
gl_dict_7_5_5_blank_types_series_relation
select * from rgsscc.ref_dictblanktypeseries ckk_7_5_5 
      WHERE ckk_7_5_5.scc_status = 0

      SCC_ID
      SCC_STATUS
      BASE_ID
      TAB_755_FK$
      TABL_755_FK$
	  DBTS_ID
	  END_DATE
	  START_DATE
	  CREATION_TIME
	  IS_NODE
	  USER_ID
	  TICK
	  DATE_TO
	  DATE_FROM
	  ID
	  TAB_755_FK_
	  TABL_755_FK_
	  TAB_755_FK
	  TABL_755_FK
	
	  
DROP VIEW APO.NSFA_DICT_BLANK_TYPES_SERIES_RELATION_7_5_5;

/* Formatted on 07.12.2016 10:14:07 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.NSFA_DICT_BLANK_TYPES_SERIES_RELATION_7_5_5
(
   SCC_ID,
   END_DATE,
   START_DATE,
   TAB_755_FK_,
   TABL_755_FK_
)
AS
   SELECT ckk_7_5_5.scc_id,
          ckk_7_5_5.end_date,
          ckk_7_5_5.start_date,
          ckk_7_5_5.tab_755_fk_,
          ckk_7_5_5.tabl_755_fk_
     FROM rgsscc.ref_dictblanktypeseries ckk_7_5_5
    WHERE ckk_7_5_5.scc_status = 0;
	
	
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
 
APO.NSFA_DICT_BLANK_TYPE_7_4_9

NSFA_DICT_BLANK_TYPE_7_4_9

   SELECT ckk_7_4_9.scc_id,
          ckk_7_4_9.blank_type_name,
          ckk_7_4_9.blank_type_id,
          ckk_7_4_9.date_to,
          ckk_7_4_9.date_from
     FROM rgsscc.ref_dictblanktype ckk_7_4_9
    WHERE ckk_7_4_9.scc_status = 0

   
NSFA_DICT_BLANK_TYPE_7_4_9
gl_dict_7_4_9_blank_types
select * from rgsscc.ref_dictblanktype ckk_7_4_9 
      WHERE ckk_7_4_9.scc_status = 0
	  
      SCC_ID ->
      SCC_STATUS
	  BASE_ID
      TO_722_FK$
      USE_ARM
      ACTIVE_ENTRY
      CONTRACT_CLASS_ID
      SORT_ORDER
	  BLANK_TYPE_NAME ->
      BLANK_TYPE_ID ->
	  IS_NODE
      USER_ID
      TICK
	  DATE_TO
      DATE_FROM
	  ID
      TO_722_FK_
      TO_722_FK


DROP VIEW APO.NSFA_DICT_BLANK_TYPE_7_4_9;

/* Formatted on 07.12.2016 15:00:45 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.NSFA_DICT_BLANK_TYPE_7_4_9
(
      SCC_ID
	  BLANK_TYPE_NAME
      BLANK_TYPE_ID
	  DATE_TO
      DATE_FROM
)
AS
   SELECT ckk_7_4_9.scc_id,
          ckk_7_4_9.blank_type_name,
 		  ckk_7_4_9.blank_type_id,
		  ckk_7_4_9.date_to,
		  ckk_7_4_9.date_from
	  FROM rgsscc.ref_dictblanktype ckk_7_4_9 
    WHERE ckk_7_4_9.scc_status = 0

   
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

APO.NSFA_DICT_PROD_BLANK_7_10_16
	  
NSFA_DICT_PRODUCT_BLANK_RELATION_7_10_16
gl_dict_7_10_16_product_blank_relation
select * from rgsscc.ref_product_blank_fa ckk_7_10_16 
      WHERE ckk_7_10_16.scc_status = 0

      SCC_ID
      SCC_STATUS
      ID
      DATE_FROM
	  DATE_TO
	  TICK
	  IS_NODE
	  BASE_ID
	  BLANK_SERIES_ID
	  BLANK_SERIES_NAME
	  SCHORT_BLANK_TYPE_NAME
	  SUBJECT_FEDERATION_CODE
	  FA_PROD_ID
	  START_DATE
	  END_DATE
	  ID_FA_NUMBER
	  

DROP VIEW APO.NSFA_DICT_PROD_BLANK_7_10_16;

/* Formatted on 13.12.2016 17:51:41 (QP5 v5.149.1003.31008) */
CREATE OR REPLACE FORCE VIEW APO.NSFA_DICT_PROD_BLANK_7_10_16
(
   SCC_ID,
   DATE_FROM,
   DATE_TO,
   BLANK_SERIES_ID,
   BLANK_SERIES_NAME,
   BLANK_TYPE_ID,
   SHORT_BLANK_TYPE_NAME,
   SUBJECT_FEDERATION_CODE,
   FA_PROD_ID,
   START_DATE,
   END_DATE
)
AS

SELECT
       ckk_7_10_16.scc_id
      ,ckk_7_10_16.date_from
      ,ckk_7_10_16.date_to
      ,ckk_7_5_4.blank_series_id
      ,ckk_7_5_4.series_name
      ,ckk_7_10_16.blank_type_id
      ,ckk_7_10_16.short_blank_type_name
      ,ckk_4_1_4.SUBJECT_FEDERATION_CODE
      ,ckk_7_7_83.FORT_AUTO_PRODUCT_ID
      ,ckk_7_10_16.start_date
      ,ckk_7_10_16.end_date
 FROM
       rgsscc.ref_product_blank_fa ckk_7_10_16
      ,rgsscc.REF_FORT_AUTO_PRODUCTS ckk_7_7_83
      ,rgsscc.REF_SUBJECT_RF ckk_4_1_4
      ,rgsscc.ref_dictblankseries ckk_7_5_4
WHERE
       ckk_7_7_83.scc_id = ckk_7_10_16.fa_prod_id
 AND   ckk_7_5_4.scc_id = ckk_7_10_16.blank_series_id
 AND   ckk_4_1_4.scc_id = ckk_7_10_16.subject_federation_code
 AND   ckk_7_10_16.scc_status = 0;	
	  

	  
//OSAGO_R_ns_bso








3948726

ОВД района Дорогомилово

7816196304



Жан клод ван дам
Жан-клод Ван-Дамов
жан клод'ван`дамович

сахали






select * from rgsscc.ref_product_blank_fa ckk_7_10_16   WHERE ckk_7_10_16.scc_status = 0 and ckk_7_10_16.subject_federation_code = 29909372
select * from rgsscc.ref_dictblankseries ckk_7_5_4  WHERE ckk_7_5_4.scc_status = 0
select * from rgsscc.REF_SUBJECT_RF ckk_4_1_4   WHERE ckk_4_1_4.scc_status = 0


select skk_7_10_16.blank_series_id, skk_7_10_16.blank_series_name
 from rgsscc.ref_product_blank_fa skk_7_10_16
where
skk_7_10_16.FA_PROD_ID = 30483411
and   skk_7_10_16.blank_series_id = 30463716
--and   skk_7_10_16.blank_series_name<>'СБ 78'
--and
--(
--skk_7_10_16.subject_federation_code = 29909371
--skk_7_10_16.subject_federation_code<>29909372
--skk_7_10_16.subject_federation_code = 29909603
--or skk_7_10_16.subject_federation_code = 0
--)
and skk_7_10_16.start_date <= sysdate 
and skk_7_10_16.end_date >= sysdate
group by skk_7_10_16.blank_series_id, skk_7_10_16.blank_series_name
;

select * from  rgsscc.ref_product_blank_fa t1, rgsscc.ref_dictblankseries t2
where T1.BLANK_SERIES_ID = T2.SCC_ID
and T2.SERIES_NAME = 'СБ 78'
;

select * from rgsscc.REF_FORT_AUTO_PRODUCTS
select * from rgsscc.REF_SUBJECT_RF



   SELECT ckk_7_10_16.scc_id,
          ckk_7_10_16.date_from,
          ckk_7_10_16.date_to,
          ckk_7_5_4.blank_series_id,
          ckk_7_5_4.series_name,
          ckk_7_4_9.blank_type_id,
          ckk_7_10_16.short_blank_type_name,
          ckk_4_1_4.SUBJECT_FEDERATION_CODE,
          ckk_7_7_83.FORT_AUTO_PRODUCT_ID,
          ckk_7_10_16.start_date,
          ckk_7_10_16.end_date
     FROM rgsscc.ref_product_blank_fa ckk_7_10_16,
          rgsscc.REF_FORT_AUTO_PRODUCTS ckk_7_7_83,
          rgsscc.REF_SUBJECT_RF ckk_4_1_4,
          rgsscc.ref_dictblankseries ckk_7_5_4,
          rgsscc.ref_dictblanktype ckk_7_4_9
    WHERE     ckk_7_7_83.scc_id = ckk_7_10_16.fa_prod_id
          AND ckk_7_5_4.scc_id = ckk_7_10_16.blank_series_id
          AND ckk_7_4_9.scc_id = ckk_7_10_16.blank_type_id
          AND ckk_4_1_4.scc_id = ckk_7_10_16.subject_federation_code
          AND ckk_7_10_16.scc_status = 0;

		  
		  
		  
14864


iif((insur_status = 1), insur_yur_name, insur_full_name)
	

[IIF((<UserData."insur_status"> = 1), <UserData."insur_yur_name">, <UserData."insur_full_name">)]

[(IIF((<UserData."insur_status">=1) and ( ValidDate() )
, DateToStrM(), '- - - - - - '))]






Общая страховая сумма по Договору страхования <u>        [FormatFloat('###,###,###,##0.00',allsumm)]        </u> руб.

Общая страховая премия по Договору страхования в размере  <u>        [FormatFloat('###,###,###,##0.00',allprem)]        </u>   рублей за всех Застрахованных лиц будет уплачена единовременно до «<u>[FormatDateTime('dd',<UserData."payment_date">)]</u>» <u> [DateToStrM(<UserData."payment_date">)] </u> 20<u> [FormatDateTime('yy',<UserData."payment_date">)]</u>  г.



[UserData."avto_str_summa"]

[UserData."premiya"]






Согласование с Аналитиками ФТ, внешнего вида некоторых интерфейсов и логики работы конечного продукта.

- Изучение старого модуля фортуна Авто.
Изучение взаимодейтсивя старого модуля фортуна Авто с используемыми им справочниками.

- Изучение реализации модуля Фортуна Авто встренного в модуль ОСАГО.
Изучение справочника osago_r_ns_bso и взаимосвязанных с ним, для понимания работы модуля и логики производимых им рассчётов.

- Перенос логики Расчёта из существующего модуля ОСАГО из части Фортуна Авто
в старый модуль Фортуна Авто, с возможностью выбора "Территории премущественного использования"

- Доработка выбора страховых сумм и корректного расчёта конечной страховой суммы и страховой премии
для указанного пользователем "Числа застрахованных" и "Территории преимущественного использования" 

- Изучение справочников: Типы БСО, Связи промежуточного справочника Типов и серий БС, Серии БСО, Справочник СКК
Изменение логики работы вкладки "Данные для печати документа" с новыми справочниками.

- Замена раскрывающегося списка с заполняемыми элементами на отдельные эдитбоксы, чекбоксы и групбоксы во вкладке "Данные для печати" в Элементе "Страхователь" с сохранением логики работы модуля.
Поправлен Tab-order внутри вкладок "Расчёт" и "Данные для печати документа".

- Добавление справочников СКК в АПО, Проверка запросов к справочникам, для отображени нужной информации в интерфейсе.

- Формирование представлений для выгрузки и синхронизации данных из справочников СКК. Доработка получения "Типа (бланка) полиса" из справочника 7.4.9 через "Серию бланка" из справочника 7.5.4. и 7.5.5

- Доработка получения "Серии бланка полиса" исходя из указанного пользователем Региона и Страховой суммы. Формирование совместно с аналитиком тестовых данных для справочника 7.10.16 для тестирования интерфейса и корректности получения данных из новых заведённых справочников.

- Подготовка запроса для получения Типа полиса, по выбранной Серии бланка для указанного региона и страховой суммы.


- Вывод на печатной форме номера серии бланка в правильном формате программно.



? - [v] Оплата и использованием платёжной карты <=> Тип оплаты (Нал / Безнал) ???




