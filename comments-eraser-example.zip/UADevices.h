//---------------------------------------------------------------------------
#ifndef UADevicesH
#define UADevicesH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <DB.hpp>

#include "cxButtons.hpp"
#include "cxControls.hpp"
#include "cxDBEditRepository.hpp"
#include "cxEdit.hpp"
#include "cxEditRepositoryItems.hpp"
#include "cxGraphics.hpp"
#include "cxInplaceContainer.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "cxStyles.hpp"
#include "cxVGrid.hpp"

//#include "tools.h"
#include "structures.h"

//---------------------------------------------------------------------------
class TfrmADevices : public TForm{
__published:	// IDE-managed Components
   TcxVerticalGrid *vg;
   TcxEditRepository *cxEditRepository1;
   TcxStyleRepository *cxStyleRepository1;
   TcxStyle *cxStyle1;
   TcxStyle *cxStyle2;
   TcxStyle *cxStyle3;
   TcxStyle *cxStyle4;
   TcxEditorRow *vg_Position;
   TcxEditorRow *vg_Cost;
   TcxEditRepositoryLookupComboBoxItem *LookupComboBoxItem;
   TcxEditRepositoryCurrencyItem *CurrencyItem;
   TcxButton *btnOK;
   TcxButton *btnCancel;
   TcxEditorRow *vg_WhatIsIt;
   TDataSource *DataSource1;
   TcxCategoryRow *vgCategoryRow1;
   TcxEditRepositoryTextItem *TextItem;
   TStaticText *labHint;
   void __fastcall FormDestroy(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall btnCancelClick(TObject *Sender);
   void __fastcall vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties);
   void __fastcall CurrencyItemPropertiesChange(TObject *Sender);
   void __fastcall CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error);
   void __fastcall LookupComboBoxItemPropertiesChange(TObject *Sender);
   void __fastcall TextItemPropertiesChange(TObject *Sender);
   void __fastcall btnOKClick(TObject *Sender);
private:	// User declarations
   int res, btn;
   mops_api_028 *m_api;
   TADOQuery *q_equip;
   AddDevice *adevice, adevice_temp;
private:
   void Validate();
public:		// User declarations
   __fastcall TfrmADevices(TComponent* Owner, mops_api_028 *_m_api, AddDevice *p_adevices);
   void SetButtonPress(const int who){ btn = who; }

};
//---------------------------------------------------------------------------
extern PACKAGE TfrmADevices *frmADevices;
//---------------------------------------------------------------------------
#endif
