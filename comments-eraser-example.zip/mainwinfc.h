//---------------------------------------------------------------------------
#ifndef MainWinFCH
#define MainWinFCH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>

#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include "sCurrEdit.hpp"
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "sBitBtn.hpp"
#include "sButton.hpp"
#include "sEdit.hpp"
#include "sComboBox.hpp"
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxGroupBox.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "sCheckBox.hpp"
#include "cxButtons.hpp"
#include "cxCalendar.hpp"
#include "cxDropDownEdit.hpp"
#include "cxMaskEdit.hpp"
#include "cxTextEdit.hpp"
#include "dxEditor.hpp"
#include "dxEdLib.hpp"

//#include "tools.h"
#include "structures.h"
#include "functions.h"

#include <vector>
#include <set>
//#include "UPayment1.h"
//---------------------------------------------------------------------------
class TFrameNew;
class TFrame1 : public TFrame
{
__published:	// IDE-managed Components
   TTimer *Tim;
   TLabel *labNonStandardDogovor;
   TdxInspector *DogovorInfo;
   TdxInspectorTextRow *PolisHead;
   TdxInspectorTextPickRow *cboxBSO;
   TdxInspectorTextRow *editPolisSeria;
   TdxInspectorTextRow *editPolisNumber;
   TdxInspectorTextDateRow *datePolisDate;
   TdxInspectorTextRow *SrokHead;
   TdxInspectorTextDateRow *dateSrokS;
   TdxInspectorTextDateRow *dateSrokPo;
   TdxInspectorTextRow *ProlongHead;
   TdxInspectorTextRow *editPrevSeria;
   TdxInspectorTextRow *editPrevNumber;
   TdxInspectorTextRow *CreditHead;
   TdxInspectorTextRow *editCreditNumber;
   TdxInspectorTextDateRow *dateCredit;
   TdxInspectorTextRow *ZalogHead;
   TdxInspectorTextRow *editZalogNumber;
   TdxInspectorTextDateRow *dateZalog;
   TStaticText *labTimeS;
   TdxInspector *InsuredInfo;
   TdxInspectorTextRow *editINN;
   TdxInspectorTextPickRow *editDocType;
   TdxInspectorTextDateRow *dateDocVidan;
   TdxInspectorTextRow *editDocIssueOrg;
   TdxInspectorTextButtonRow *editAddress;
   TdxInspectorTextRow *editOrganization;
   TdxInspectorTextRow *editOGRN;
   TdxInspectorTextPickRow *editSmsSending;
   TdxInspectorTextRow *editEmail;
   TdxInspectorTextRow *editHead;
   TdxInspectorTextRow *editHeadContacts;
   TdxInspectorTextMaskRow *editPhone;
   TdxInspectorTextRow *editChkContacts;
   TdxInspectorTextPickRow *editCitizenShip;
   TdxInspector *BeneficInfo;
   TdxInspectorTextRow *editBLastName;
   TdxInspectorTextRow *editBFirstName;
   TdxInspectorTextRow *editBSecondName;
   TdxInspectorTextDateRow *editBBirthDate;
   TdxInspectorTextRow *editBINN;
   TdxInspectorTextPickRow *editBDocType;
   TdxInspectorTextDateRow *dateBDocVidan;
   TdxInspectorTextRow *editBDocIssueOrg;
   TdxInspectorTextButtonRow *editBAddress;
   TdxInspectorTextRow *editBOrganization;
   TdxInspectorTextRow *editBOGRN;
   TdxInspectorTextPickRow *editBCopyData;
   TdxInspectorTextPickRow *editBStatus;
   TdxInspectorTextRow *editBHead;
   TdxInspectorTextRow *editBDepartSb;
   TdxInspectorTextRow *editBNumberSb;
   TdxInspectorTextRow *editBPlaceSb;
   TdxInspector *VehicleTdxInfo;
   TdxInspectorTextRow *editTSMarka;
   TdxInspectorTextRow *editTSModel;
   TdxInspectorTextSpinRow *editPower;
   TdxInspectorTextSpinRow *editKeyCount;
   TdxInspectorTextSpinRow *editSeatCount;
   TdxInspectorTextRow *editPTSSeria;
   TdxInspectorTextRow *editPTSNumber;
   TdxInspectorTextDateRow *editPTSDate;
   TdxInspectorTextSpinRow *editVolume;
   TdxInspectorTextPickRow *editDocTypeTS;
   TdxInspectorTextRow *VehicleInfoHead;
   TdxInspector *PolisInfo679_1;
   TdxInspectorTextRow *SchedulePaymentsHead;
   TdxInspectorTextRow *SchedPayment1;
   TdxInspectorTextRow *DopUslHead;
   TdxInspectorTextRow *editDopUsl1;
   TdxInspectorTextRow *editDopUsl2;
   TdxInspector *PolisInfo679_2;
   TdxInspectorTextRow *OsmotrHead;
   TdxInspectorTextPickRow *cboxOsmotr;
   TdxInspectorTextDateRow *dateOsmotr;
   TdxInspectorTextRow *AddPrintHead;
   TdxInspectorTextRow *editAgent;
   TdxInspectorTextRow *editSalePlace;
   TdxInspectorTextRow *PolisInfo679_2Row7;
   TTreeView *tvSaleChannel;
   TdxInspector *PaymentInfo;
   TdxInspectorTextRow *PaymentInfoHead;
   TdxInspectorTextPickRow *cboxPayment;
   TdxInspectorTextPickRow *cboxPaymentDoc;
   TdxInspectorTextRow *editSerPP;
   TdxInspectorTextRow *editNumPP;
   TdxInspectorTextRow *DopOborHead;
   TdxInspectorTextPickRow *cboxTypeInsurDO;
   TdxInspectorTextRow *editDopSogNumber;
   TStringGrid *gridAD;
   TComboBox *cboxTypeAD;
   TsCalcEdit *ceditCostAD;
   TEdit *editDescrAD;
   TPanel *Panel1;
   TsBitBtn *btnADPlus;
   TsBitBtn *btnADMinus;
   TStaticText *labHint;
   TdxInspectorTextPickRow *cboxUsagePurpose;
   TdxInspectorTextPickRow *cboxPackage;
   TdxInspectorTextRow *DogovorInfoRow18;
   TcxButton *btnCheckBSO;
   TdxInspectorTextMaskRow *editDocSeria;
   TdxInspectorTextMaskRow *editDocNumber;
   TdxInspectorTextMaskRow *editBDocSeria;
   TdxInspectorTextMaskRow *editBDocNumber;
   TdxInspectorTextMemoRow *editUsagePurpose;
   TsCheckBox *chkNoContacts;
   TdxInspectorTextPickRow *cboxBigPayment1;
   TdxInspectorTextPickRow *cboxPaymentMethod;
   TdxInspectorTextRow *editCodeAutorization;
   TdxInspectorTextRow *editEmailInfo;
   void __fastcall TimTimer(TObject *Sender);
   void __fastcall ControlChange(TObject *Sender);
   void __fastcall tvSaleChannelChange(TObject *Sender,TTreeNode *Node);
   void __fastcall editAddressButtonClick(TObject *Sender, int AbsoluteIndex);
   void __fastcall btnADPlusClick(TObject *Sender);
   void __fastcall btnADMinusClick(TObject *Sender);
   void __fastcall gridADSelectCell(TObject *Sender, int ACol, int ARow, bool &CanSelect);
   void __fastcall cboxTypeADChange(TObject *Sender);
   void __fastcall cboxTypeADExit(TObject *Sender);
   void __fastcall editDescrADChange(TObject *Sender);
   void __fastcall ceditCostADChange(TObject *Sender);
   void __fastcall ceditCostADExit(TObject *Sender);
   void __fastcall ceditCostADKeyPress(TObject *Sender, char &Key);
   void __fastcall chkNoContactsClick(TObject *Sender);
   void __fastcall datePolisDate_Change(TObject *Sender);
   void __fastcall editCitizenShipCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall editDocTypeTSCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall DogovorInfoEditChange(TObject *Sender);
   void __fastcall cboxBSOCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall DogovorInfoEdited(TObject *Sender, TdxInspectorNode *Node, TdxInspectorRow *Row);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall cboxOsmotrCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall PolisHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall editHeadContactsDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall VehicleInfoHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall cboxPaymentCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall cboxTypeInsurDOCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall DogovorInfoDrawValue(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall cboxUsagePurposeCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall FrameResize(TObject *Sender);
   void __fastcall btnCheckBSOClick(TObject *Sender);
   void __fastcall editDocTypeCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall editSmsSendingCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall editBCopyDataCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall editBStatusCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall datePolisDateEditButtonClick(TObject *Sender);
   void __fastcall cboxBigPayment1CloseUp(TObject *Sender, Variant &Value,  bool &Accept);
private:	// User declarations
   void Error(const AnsiString& text, const AnsiString& err_type, const int unique, bool term, int warning = 0);
   void LoadTree(TTreeView *tree, TTreeNode *node, int parent_id);
   double Round(const double& val){ return dynamic_cast<mops_api_007*>(m_api)->Round(val); }
   void CopyDataInsuredToBenefic_Or_ClearDataBenefic(const int index);
   void LoadDataPerson(const int index);
   void DisableGBP();
   int GetStateDataToAgreed();
   bool CheckEmail();
   void LoadTelematicDevices();
private:
   mops_api_028 *m_api;

   PersonInfo *pi, *pm;
// //#include "tools.h"
   //TSInfo *tsi;
   VehicleInfo *tsi;
   Dogovor_Info *di;

/* //#include "UPayment1.h"
   TfrmPayment1 *frmp1;
*/
   typedef pair<int, AnsiString> Kanal;
   typedef multimap<int, Kanal> Kanals;
   Kanals mmap;
   TADOQuery *q_load, *q_bl_persons, *region_bl;
   TDateTime osmotr_date;
   TStringList *error;
   AnsiString ser_pp, num_pp, authorization_code, ds_do_number, curr_error, usage_purpose, old_policy_blank, old_policy_series, old_policy_number;
   int res, old_sale_channel_id, result_check_bso, count_check, last_result_check_bso, last_count_check;
   bool in_event, is_editbuttonclick;
public:		// User declarations
//   __fastcall TFrame1(TComponent* Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, TSInfo *p_tsi, Dogovor_Info *p_di);
   __fastcall TFrame1(TComponent* Owner, mops_api_028 *_m_api, PersonInfo *p_pi, PersonInfo *p_pm, VehicleInfo *p_tsi, Dogovor_Info *p_di);
   __fastcall ~TFrame1();
   void Prepare();
   void Validate();
   void SaveFrame(TADOQuery *q);
   void LoadFrame(TADOQuery *q);
   void SetStatusInsured();
   void SetStatusBenefic(const int s);
   bool IsChangeData(){ return labNonStandardDogovor->Height > 3; };
   void DisableControls();
   void SetSaleChannel(const AnsiString& nm_ch);
   bool IsEmptyGrid();
   int BlackListSearch();
   void dateSrokS_Change();
   void SetVisibleDogovorRows(bool v);
   void SetVisibleProlongRows(bool v);
   void SetVisibleCreditRows(bool v);
   void InvalidateAll();
   void RecalcPayments();

   void SetValueCheckBox(TsCheckBox* chk, const int v, ptr_onclick onclick);

public:
   TFrameNew *f_calc;
   TStringList *non_standart_str;
};
//---------------------------------------------------------------------------
const int fi[] = {17, 15, 16, 0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11},
          ji[] = {17, 15, 16, 13, 4, 14, 9, 10, 11},
          ro[] = {0, 1, 2, 13, 15, 16};
//---------------------------------------------------------------------------
extern PACKAGE TFrame1 *Frame1;
//---------------------------------------------------------------------------
#endif
