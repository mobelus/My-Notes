//---------------------------------------------------------------------------
#ifndef functionsH
#define functionsH
#include "sCurrEdit.hpp"
#include "sTooledit.hpp"
#include "dxInspRw.hpp"
#include "sCheckBox.hpp"
#include "Tmops_api.h"
#include "cxEditRepositoryItems.hpp"
#include "cxVGrid.hpp"
#include "structures.h"
#include "cxDBLookupComboBox.hpp"
#include "cxPC.hpp"
#include "dxInspRw.hpp"
#include "glGrBox.hpp"


#ifndef __FUNCTION_NAME__
    #ifdef WIN32   //WINDOWS
        #ifdef __BORLANDC__
            #define __FUNCTION_NAME__   __FUNC__ // CPPBulder version
        #endif
        #ifdef _MSC_FULL_VER
            #define __FUNCTION_NAME__   __FUNCTION__ // MSVS version
        #endif
    #else          //*NIX
        #define __FUNCTION_NAME__   __func__
    #endif
#endif


static MaskDocType mask_doc_type(person_mask), mask_vehicle_doc_type(vehicle_mask);
extern mops_api_028 *m_api;

//---------------------------------------------------------------------------

AnsiString S(const double& x);
AnsiString FormatDigits(const double& x);
AnsiString FloatToSQLStr(const double& f);
AnsiString FloatToSQLStr(AnsiString s);
void FloatToRubAndKopeik(const double& x, AnsiString& rub, AnsiString& kopeik); //
AnsiString StrToFloatStr(const AnsiString& s, const AnsiString& def = "0");
AnsiString FloatToIntStr(const double& f);
int CalcYears(const TDateTime& dt1, const TDateTime& dt2);
int GetIndexObject(TStrings* lst, const int& val);
int GetIndexItemByTag(TcxRadioGroupItems*, const int t);
void ResetChk(TCheckBox* chk, ptr_onclick onclick = 0);
void ResetCxChk(TcxCheckBox* chk, ptr_onclick onclick = 0);
void ResetSChk(TsCheckBox* chk, ptr_onclick onclick = 0);
void SetValueCheckBox(TsCheckBox* chk, const int v, ptr_onclick onclick);
void SetValueCheckBox(TCheckBox* chk, const int v, ptr_onclick onclick);
void SetValueCxCheckBox(TcxCheckBox* chk, const int v, ptr_onclick onclick);
void SetValueEdit(TEdit *cedit, const AnsiString& val, ptr_onchange onchange);
void SetValueCalcEdit(TsCalcEdit *cedit, const double& val, ptr_onchange onchange);
void SetValueDateEdit(TsDateEdit *dedit, const TDateTime& val, ptr_onchange onchange);
void SetValueRowDateEdit(TcxEditorRow *dedit, const TDateTime& val);
void SetValueRowDateEdit(TcxDateEdit *dedit, const TDateTime& val);
void SetValueRowDateEdit(TdxInspectorTextDateRow *dedit, const TDateTime& val);
TDateTime CalcEndDateInsur(const TDateTime& start_date, const int srok_month);
AnsiString FirstUpper(const AnsiString& str, const int is_end_to_lower = 0);
AnsiString AddNulls(const AnsiString& str, const int count);
AnsiString AddNulls(const AnsiString& str); //
AnsiString ClearPhoneNumber(const AnsiString& str);

bool IsCharANumber(char Char);
AnsiString NormalizeNumberStr(AnsiString StrToNormalize);
AnsiString NormalizeSummNumberStr(AnsiString StrToNormalize);
AnsiString NormalizeSummWithDotToNumberStr(AnsiString StrToNormalize);
bool IsDigitOnly(AnsiString Str);
bool IsLetterOnly(AnsiString Str);
bool CheckAreNumbersAndLetters(const AnsiString& str); // check if the symbols in a Strring are numberes and latin BIG LETTERS
bool CheckAreAllNumbers(const AnsiString& str); // check if the symbols in a Strring are ALL numberes

AnsiString DeleteLastSymbol(AnsiString str);

void FilterDataSet(TADOQuery *qq, const AnsiString& filter);
void FilterDataSet(TClientDataSet *qq, const AnsiString& filter);
bool CheckVIN(const AnsiString& vin);
bool CheckRegPlate(const AnsiString& rgpl);
AnsiString NodeToStr(_di_IXMLNode node);
AnsiString NormVIN_GN(mops_api_025 *m_api, const AnsiString& numb);
void SeparateFIO(const AnsiString& fio, const int status, AnsiString& lname, AnsiString& fname, AnsiString& sname);
void MakeKladrAddrFromARM(mops_api_028 *_m_api, _di_IXMLNode child_node, TStringList* addr, int& memo_id);
void MakeKladrAddrFromUXML(mops_api_028 *_m_api, _di_IXMLNode person, TStringList *addr, int& memo_id, AnsiString& exact_address);
bool CheckAddrList(TStringList* addrlist);
AnsiString MarkaId(const int model_id);
double GetKprSb(const double& val);
void GetPhones(_di_IXMLNode contacts, AnsiString& ph_mob, AnsiString& ph_home, AnsiString& ph_rab, int &sms);
AnsiString IntToBin(const int ANumber, int ABitCount = 32);
void FieldValueIDToVGEditor(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row);
void FieldValueIDToVGEditor_(const int fv, TcxEditRepositoryComboBoxItem *cboxitem, TcxEditorRow *row);
void K1(mops_api_024 *m_api, const int index_pm, PersonInfo *pm, Dogovor_Info *di);

/*
void ChangeMask(TcxMaskEdit *DocSeria, TcxMaskEdit *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TdxInspectorTextMaskRow *DocSeria, TdxInspectorTextMaskRow *DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
//void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, TSInfo *p_tsi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, VehicleInfo *p_tsi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
*/
// FROM OLD TOOLS
void ChangeMask(TdxInspectorTextMaskRow *DocSeria, TdxInspectorTextMaskRow *DocNumber, PersonInfo *p_pi, const int index,const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, PersonInfo *p_pi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");
void ChangeMask(TcxEditRepositoryMaskItem *DocSeria, TcxEditRepositoryMaskItem *DocNumber, TcxEditorRow *r_DocSeria, TcxEditorRow *r_DocNumber, VehicleInfo *p_tsi, const int index, const AnsiString& v1 = "", const AnsiString& v2 = "");


int GetDrvCount(TADOQuery *qq);
int GetCountPermitted(TListView *gridDopush);
int MonthsCount(const TDateTime& ANow, const TDateTime& AThen);
void VariantToDate(Variant v, TDateTime& dt);
void PmDataToRecord(TADOQuery* q_perm, PersonInfo *pm, const int calc_id, const int num, const int i, const int pm_status);
void Save_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, PersonInfo *pi, PersonInfo *pm, TListView *gridDopush);
void Load_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, PersonInfo *pi, PersonInfo *pm);
void Save_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm, TListView *gridDopush);
void Load_Dogovors_k5_k6(mops_api_028 *m_api, const int calc_id, Dogovor_Info *di, PersonInfo *pi, PersonInfo *pm);

void SetTextTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange = 0);
void ClearTcxComboBox(TcxComboBox *cbox, ptr_onchange onchange);
void SetIndexTcxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange = 0, const int type = 1/* 0 - ��������, 1 - object*/, const Variant& default_value = variant_null);
void SetValuecxCurrencyEdit(TcxCurrencyEdit *cedit, const Variant& value, ptr_onchange onchange = 0);
void SetEnterInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange);
void ExitFromEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange);
void SetEnterInComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange);
void ExitFromComboBox(const AnsiString& str, TcxComboBox *cbox, ptr_onchange onchange);
void SetEnterInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit);
void ExitFromButtonEditBox(const AnsiString& str, TcxButtonEdit *edit);
void SetTextAndColorInEditBox(const AnsiString& str, TEdit *edit, ptr_onchange onchange);
void SetTextAndColorInButtonEditBox(const AnsiString& str, TcxButtonEdit *edit);
void SetValueAndHintInDateEdit(TsDateEdit* dedit, const TDateTime& dt, ptr_onchange onchange, TStaticText *hint);
void SetValueAndHintInMaskEdit(TcxMaskEdit* edit, const AnsiString& str, ptr_onchange onchange, TStaticText *hint);
void SetIndexAndHintIncxComboBox(TcxComboBox *cbox, Variant& value, ptr_onchange onchange, const int type, TStaticText *hint);
void SetIndexTocxRadioGroup(TcxRadioGroup *rg, const int index, ptr_onclick onclick);
void SetValueTocxLookupComboBox(TcxLookupComboBox *cbox, const Variant& value, ptr_oneditvaluechanged oneditvaluechanged);
void SetHeightsToPcAndGb(TcxPageControl *pc, TglGroupBox *gb, Dogovor_Info *di = 0);
void SetHeightInspector1(TCustomdxInspectorControl *inspector); //
void SetHeightInspector2(TCustomdxInspectorControl *inspector); //
void SetHeightInspector_1(TdxInspector *inspector); //
void SetHeightInspector_2(TdxInspector *inspector); //
int GetToplabHint_1(TdxInspector *inspector); //
int GetToplabHint_2(TdxInspector *inspector); //
int GetToplabHint(TCustomdxInspectorControl *inspector); //
void SetActivePageTocxPageControl(TcxPageControl *pc, TcxTabSheet *sh, ptr_onchange onchange);
void SetTextAndColorTocxComboBox(TcxComboBox *cbox, const AnsiString& value, ptr_onchange onchange);
AnsiString ReservToStr(const std::set<int>& s);
void SetValuecxSpinEdit(TcxSpinEdit *spinedit, const double& value, ptr_onchange onchange, ptr_onvalidate onvalidate);
void LoadDataCurrentUser(mops_api_028 *m_api, Dogovor_Info *p_di);
void MakeExportFilters(TSaveDialog *sd, Dogovor_Info *di, Map_Int_Str &filter);
AnsiString Translit_Text(const AnsiString& source, const int rus_lat = 0);
void SetValueRadioButton(TRadioButton *rb, const int v, ptr_onclick onclick);
bool VariantIsBad(const Variant& v){ return v.IsNull() || v.IsEmpty() || !v.intVal || AnsiString(v) == "+7("; };
void CreatePDF(AnsiString doc, TMemoryStream *pdf);
AnsiString NodeAttributeToStr(_di_IXMLNode node, const AnsiString& name, const AnsiString& value);
AnsiString ClearStr(const AnsiString& str);
int GetVehicleGroup(mops_api_028 *m_api, const int vehicle_type_id, const AnsiString& rsa_code, const int allowed_mass, const int number_of_seats, const AnsiString& calc_date);
__int64 FileSize(const AnsiString& fn);
AnsiString ConvertDateTime(const TDateTime& date, AnsiString& time, const int offsethour);
AnsiString ConvertDateTimeNoZeros(const TDateTime& date, AnsiString& time, const int offsethour);
Boolean PasportInBadList(AnsiString DocSeria, AnsiString DocNumber, Integer DocType, AnsiString APO2_ARM_READER_ADR);
//---------------------------------------------------------------------------

#endif



