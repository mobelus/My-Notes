//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UReportParams.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma resource "*.dfm"
TfRepParams *fRepParams;
//---------------------------------------------------------------------------
__fastcall TfRepParams::TfRepParams(TComponent* Owner, mops_api_024 *_m_api) : TForm(Owner), m_api(_m_api)
{
   dateS->EditText  = TDateTime(2013, 2, 18).DateString();
   datePo->EditText = Date().DateString();

   q = m_api->dbGetCursor(res, "select distinct t2.terr_id,t2.filial_name_vrp from casco_calc t1,gl_dict_regions t2,_mops_calcs_ t3 where t1.region_id=t2.terr_id and t1.calc_id=t3.id and t3.deleted=0 and t3.status_id in(3,4)");
   for(q->First(); !q->Eof; q->Next()) cboxFilial->Items->AddObject(q->FieldByName("filial_name_vrp")->AsString, (TObject*)q->FieldByName("terr_id")->AsInteger);
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select distinct t1.sale_place from casco_calc t1,_mops_calcs_ t3 where t1.calc_id=t3.id and t3.deleted=0 and t3.status_id in(3,4)");
   for(q->First(); !q->Eof; q->Next()) if(!q->FieldByName("sale_place")->AsString.IsEmpty()) cboxOSP->Items->Add(q->FieldByName("sale_place")->AsString);
   m_api->dbCloseCursor(res, q);

   q = m_api->dbGetCursor(res, "select distinct t1.from_whom_sent from casco_calc t1,_mops_calcs_ t3 where t1.calc_id=t3.id and t3.deleted=0 and t3.status_id in(3,4)");
   for(q->First(); !q->Eof; q->Next()) if(!q->FieldByName("from_whom_sent")->AsString.IsEmpty()) cboxSaler->Items->Add(q->FieldByName("from_whom_sent")->AsString);
   m_api->dbCloseCursor(res, q);
}
//---------------------------------------------------------------------------
void __fastcall TfRepParams::btnClearClick(TObject *Sender)
{
   dateS->EditText  = TDateTime(2013, 2, 18).DateString();
   datePo->EditText = Now().DateString();

   cboxDogovorType->EditText = "���";
   cboxFilial->EditText      = "���";
   cboxOSP->EditText         = "���";
   cboxSaler->EditText       = "���";
}
//---------------------------------------------------------------------------
void __fastcall TfRepParams::btnOKClick(TObject *Sender)
{
   ParamsInfo->PostEditor();

   int index_dog = cboxDogovorType->Items->IndexOf(cboxDogovorType->EditText),
       index_fil = cboxFilial->Items->IndexOf(cboxFilial->EditText),
       index_osp = cboxOSP->Items->IndexOf(cboxOSP->EditText),
       index_sal = cboxSaler->Items->IndexOf(cboxSaler->EditText);

   filter_report = " and t5.date_add>=" + m_api->Internal_Convert_Date_To_SQL(res, dateS->EditText) + " and t5.date_add<=" + m_api->Internal_Convert_Date_To_SQL(res, datePo->EditText);

   if(index_dog > 0) filter_report = filter_report + " and t5.status_id=" + IntToStr(index_dog + 2);
   else filter_report = filter_report + " and t5.status_id in (3,4)";

   if(index_fil > 0) filter_report = filter_report + " and t1.region_id=" + IntToStr((int)cboxFilial->Items->Objects[index_fil]);
   if(index_osp > 0) filter_report = filter_report + " and t1.sale_place='" + cboxOSP->EditText + "'";
   if(index_sal > 0) filter_report = filter_report + " and t1.from_whom_sent='" + cboxSaler->EditText + "'";

   filter_report = filter_report + " order by t5.date_add";

   Tag = index_dog;
}
//---------------------------------------------------------------------------
