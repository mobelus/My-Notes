//---------------------------------------------------------------------------

#include <vcl.h>
#include "IAPO2_ARM_READER.h"
#pragma hdrstop

#include "UThreadK5.h"
#pragma package(smart_init)

//---------------------------------------------------------------------------
__fastcall Thread_APO2_ARM_READER::Thread_APO2_ARM_READER(bool CreateSuspended, const int tf, const AnsiString& ssa, const AnsiString& xml_in, AnsiString *xml_out)
: TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), xml_text_in(xml_in), xml_text_out(xml_out)
{
}
//---------------------------------------------------------------------------
void __fastcall Thread_APO2_ARM_READER::Execute()
{
   RegTypes();
   switch(type_function){
      case 1:
         *xml_text_out = GetIAPO2_ARM_READER(false, soap_server_address)->GetK5K6(xml_text_in);
         break;
      case 2:
         *xml_text_out = GetIAPO2_ARM_READER(false, soap_server_address)->GetData(xml_text_in);
         break;
      case 3:
         *xml_text_out = GetIAPO2_ARM_READER(false, soap_server_address)->CheckPreferentialExtension(xml_text_in);
         break;
      case 4:
         *xml_text_out = GetIAPO2_ARM_READER(false, soap_server_address)->GetK5K6ForProductId(xml_text_in);
         break;
      case 5:
         *xml_text_out = GetIAPO2_ARM_READER(false, soap_server_address)->GetInfoForK5K6(xml_text_in);
   }
   UnRegTypes();
}
//---------------------------------------------------------------------------
