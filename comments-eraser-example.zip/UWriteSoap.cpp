//---------------------------------------------------------------------------


#pragma hdrstop

#include "UWriteSoap.h"
/*
namespace NS_KaskoProxyService {
void __fastcall rio_be::HTTPRIOBeforeExecute(const AnsiString MethodName, WideString &SOAPRequest)
{
/*
   //SOAPRequest = StringReplace(SOAPRequest, "<?xml version=\"1.0\"?>", "<?xml version=\"1.0\" encoding=\"WINDOWS-1251\"?>", TReplaceFlags() << rfReplaceAll);
   SOAPRequest = FastStringReplace(SOAPRequest, "NULL", "nil", rff);
   SOAPRequest = FastStringReplace(SOAPRequest, "<ReservationIds>", "<ReservationIds xmlns:d4p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);
   SOAPRequest = FastStringReplace(SOAPRequest, "<AlarmIds>", "<AlarmIds xmlns:d4p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);
   SOAPRequest = FastStringReplace(SOAPRequest, "<VehicleIds>", "<VehicleIds xmlns:d2p1=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">", rff);

   if(MethodName == AnsiString("PrintULAddAgreement")) SOAPRequest = FastStringReplace(SOAPRequest, "string", "d2p1:string", rff);
   else SOAPRequest = FastStringReplace(SOAPRequest, "string", "d4p1:string", rff);

   if(MethodName == AnsiString("PrintAutoProtectionPolicy") || MethodName == AnsiString("PrintCalculationSheet") || MethodName == AnsiString("PrintKaskoFLSpecial") || MethodName == AnsiString("PrintULAddAgreement")){
      SOAPRequest = FastStringReplace(SOAPRequest, "<ContractId>", "<ContractId xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
      SOAPRequest = FastStringReplace(SOAPRequest, "<AtypicalNumber>", "<AtypicalNumber xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
      SOAPRequest = FastStringReplace(SOAPRequest, "<Draft>", "<Draft xmlns=\"http://schemas.datacontract.org/2004/07/RGS.UFO.Interfaces.Kasko.Models.Print\">", rff);
   }

   TStringList *sl = new TStringList();
   sl->Text = SOAPRequest;
   sl->Text = FastStringReplace(sl->Text, "<UserName>apo</UserName>", "", rff);
   sl->Text = FastStringReplace(sl->Text, "<Password>popa</Password>", "", rff);
   m_api->Internal_SetLastError("������ � ��� - " + MethodName);
   m_api->Internal_SetLastError(sl->Text);

   sl->SaveToFile(m_api->Excel_tmp_path + "\\" + MethodName + "_req.xml");
   delete sl;
}

}
//*/

#pragma package(smart_init)
