//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UReissSelect.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxContainer"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxGroupBox"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxRadioGroup"
#pragma resource "*.dfm"
TFReissSelect *FReissSelect;
//---------------------------------------------------------------------------
__fastcall TFReissSelect::TFReissSelect(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFReissSelect::Button1Click(TObject *Sender)
{
   if(chklstSelectReiss->Checked[0] && chklstSelectReiss->Checked[1]){
      Label1->Visible = true;
      return;
   }
   ModalResult = mrOk;
}
//---------------------------------------------------------------------------

