//---------------------------------------------------------------------------

#ifndef UReissSelectH
#define UReissSelectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <CheckLst.hpp>
#include <ExtCtrls.hpp>
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxGroupBox.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "cxRadioGroup.hpp"
//---------------------------------------------------------------------------
class TFReissSelect : public TForm
{
__published:	// IDE-managed Components
   TButton *Button1;
   TButton *Button2;
   TLabel *Label1;
   TCheckListBox *chklstSelectReiss;
   void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TFReissSelect(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFReissSelect *FReissSelect;
//---------------------------------------------------------------------------
#endif
