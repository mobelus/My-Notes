//---------------------------------------------------------------------------
#ifndef newcalcH
#define newcalcH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "dxCntner.hpp"
#include "dxExEdtr.hpp"
#include "dxInspct.hpp"
#include "dxInspRw.hpp"
#include "sBitBtn.hpp"
#include "sCheckBox.hpp"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include "frxClass.hpp"
#include "frxDesgn.hpp"
#include "frxDBSet.hpp"
#include "Transdekra_funcs.h"
#include "mainwinfc.h"
//#include "tools.h"
#include <Dialogs.hpp>
#include "cxButtons.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "UAddPermitted.h"

#include <Menus.hpp>
#include <ExtCtrls.hpp>
#include <ToolWin.hpp>
#include <set>
#include <memory>

#define DEFAULT_CITY 77

//---------------------------------------------------------------------------
class TAnderrFrame;
class TFramePreCalc;
class TframeOffCust;

class TFrameNew : public TFrame{
__published:	// IDE-managed Components
   TLabel *labNonStandardDogovor_Up;
   TdxInspector *VehicleInfo;
   TdxInspectorTextRow *VehicleHead;
   TdxInspectorTextPickRow *cboxTSType;
   TdxInspectorTextPickRow *cboxTSMarka;
   TdxInspectorTextPickRow *cboxTSModel;
   TdxInspectorTextPickRow *editTSYear;
   TdxInspectorTextDateRow *datePTS;
   TdxInspectorTextRow *PUSHead;
   TdxInspectorTextMemoRow *memoProtivougonki;
   TdxInspectorTextPickRow *rgPUS;
   TdxInspectorTextRow *editProtivougon;
   TdxInspectorTextPickRow *cboxRegistration;
   TdxInspectorTextMaskRow *editRegPlate;
   TdxInspectorTextPickRow *cboxIdentificationType;
   TdxInspectorTextRow *TdrHead;
   TdxInspectorTextPickRow *Param1;
   TdxInspectorTextPickRow *Param2;
   TdxInspectorTextPickRow *Param3;
   TdxInspectorTextPickRow *Param4;
   TdxInspectorTextPickRow *Param5;
   TdxInspectorTextCurrencyRow *editTSRealCost;
   TdxInspectorTextCurrencyRow *editStrSumma;
   TdxInspectorTextRow *labCoefProp;
   TsCheckBox *chkFrInsteadK1;
   TListView *gridDopush;
   TdxInspector *TermsInfo;
   TdxInspectorTextRow *TermsHead;
   TdxInspectorTextPickRow *rgMainRisk;
   TdxInspectorTextPickRow *cboxVariant;
   TdxInspectorTextPickRow *cboxVozmType;
   TdxInspectorTextPickRow *cboxSrok;
   TdxInspectorTextPickRow *cboxCredit;
   TdxInspectorTextPickRow *cboxTypeFranshiza;
   TdxInspectorTextPickRow *cboxFranshiza;
   TdxInspectorTextRow *PrgPrjHead;
   TdxInspectorTextPickRow *cboxProjects;
   TdxInspectorTextPickRow *cboxProgramms;
   TdxInspectorTextPickRow *editKa;
   TdxInspectorTextRow *editObosnKa;
   TdxInspectorTextPickRow *editKV;
   TdxInspectorTextRow *labKV;
   TdxInspectorTextRow *AddRiskHead;
   TdxInspectorTextPickRow *cboxRegionDSAGO;
   TdxInspectorTextPickRow *cboxCity;
   TdxInspectorTextPickRow *cboxStrSummaDSAGO;
   TdxInspectorTextPickRow *cboxDogovorDSAGO;
   TdxInspectorTextPickRow *cboxAccident;
   TdxInspectorTextPickRow *cboxTSPricep;
   TdxInspectorTextCurrencyRow *ceditStrSummaNS;
   TdxInspectorTextMemoRow *commSale;
   TdxInspector *TotalInfo;
   TdxInspectorTextRow *labPremiaMain;
   TLabel *labNonStandardDogovor_Down;
   TdxInspectorTextCurrencyRow *editMaxMassa;
   TdxInspectorTextCurrencyRow *editSeatCount;
   TdxInspectorTextRow *CommHead;
   TdxInspectorTextMemoRow *commAnderr;
   TLabel *gridHead;
   TdxInspector *InsuredInfo;
   TdxInspectorTextRow *editLastName;
   TdxInspectorTextRow *editFirstName;
   TdxInspectorTextRow *editSecondName;
   TdxInspectorTextDateRow *editBirthDate;
   TdxInspectorTextRow *editHead;
   TdxInspectorTextMaskRow *editDocSeria;
   TdxInspectorTextMaskRow *editDocNumber;
   TdxInspectorTextPickRow *rgStatus;
   TdxInspector *GeneralInfo;
   TdxInspectorTextRow *GeneralInfoHead;
   TdxInspectorTextPickRow *cboxSource;
   TdxInspectorTextPickRow *cboxBank;
   TdxInspectorTextMemoRow *MemoBank;
   TdxInspectorTextPickRow *cboxFullInsur;
   TdxInspectorTextPickRow *cboxRegion;
   TdxInspector *PermittedInfo;
   TdxInspectorTextRow *DriversHead;
   TdxInspectorTextPickRow *cboxMultidrive;
   TcxButton *btnRequest;
   TStaticText *labHint;
   TsBitBtn *btnDopushPlus;
   TsBitBtn *btnDopushMinus;
   TsBitBtn *btnDopushEdit;
   TdxInspectorTextMaskRow *editTSVIN;
   TdxInspectorTextRow *cboxDogovorType;
   TdxInspectorTextCheckRow *chkDSAGO;
   TdxInspectorComplexRow *complexNS;
   TdxInspectorTextCheckRow *chkNS;
   TdxInspectorComplexRow *complexDMS;
   TdxInspectorTextCurrencyRow *ceditStrSummaDMS;
   TdxInspectorTextCheckRow *chkDMS;
   TdxInspectorTextPickRow *cboxTSCount;
   TdxInspectorTextPickRow *editDocType;
   TdxInspectorTextPickRow *cboxExtension;
   TdxInspectorTextPickRow *cboxGap;
   void __fastcall ControlChange(TObject *Sender);
   void __fastcall btnDopushPlusClick(TObject *Sender);
   void __fastcall btnDopushMinusClick(TObject *Sender);
   void __fastcall btnDopushEditClick(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall cboxRegionCloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall VehicleInfoEditChange(TObject *Sender);
   void __fastcall Param1CloseUp(TObject *Sender, Variant &Value, bool &Accept);
   void __fastcall VehicleInfoEdited(TObject *Sender, TdxInspectorNode *Node, TdxInspectorRow *Row);
   void __fastcall GeneralInfoHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall TermsHeadDrawCaption(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall VehicleInfoDrawValue(TdxInspectorRow *Sender, TCanvas *ACanvas, TRect &ARect, AnsiString &AText, TFont *AFont, TColor &AColor, bool &ADone);
   void __fastcall gridDopushCustomDrawItem(TCustomListView *Sender, TListItem *Item, TCustomDrawState State, bool &DefaultDraw);
   void __fastcall gridDopushClick(TObject *Sender);
   void __fastcall btnRequestClick(TObject *Sender);
   void __fastcall chkDSAGOToggleClick(TObject *Sender, const AnsiString Text, TdxCheckBoxState State);
   void __fastcall datePTSEditButtonClick(TObject *Sender);
private:	// User declarations
   mops_api_028 *m_api;
   Transdekra tdr;
   TfrmAddPermitted *frmAddPermitted;
   TADOQuery *q, *min_rate, *territory, *srok, *q_load, *region_bl, *dict_kb, *q_bl_persons, *q_limit, *q_bp;
   TStringList *curr_rg_pl, *error;
   TClientDataSet *clds_risks;
   TfrxDBDataset *ds;
   std::set<int> coeff_base, kv_enabled, prg_comfort, s_regnum;
   std::map<AnsiString, double> base_kv;
   std::vector<double> coeff_kd;

   PersonInfo *pi, *pm, pi_temp;
   TSInfo *tsi;
   Dogovor_Info *di;

   _di_IXMLDocument XMLDoc;
   _di_IXMLNode Root;

   AnsiString last_err, curr_error, sql, risk_code[3], name_prod, last_str, user_name, user_phone, what_change_anderr, vehicle_alarms, params[5], obosn_ka, items_ka, anderr_fio, GROUP_TS_STR, bp_error_text;
   AnsiString row_kpr_name, row_benef_prolong_name, old_ts_vin, old_year, skk_branch, premium_info, premium_tariff;
   TDateTime date_pts;

   int BS, FRANSHIZA;
   int res, old_model_id, old_region_id, region_isp_id, curr_year, ts_age_min, ts_age_max, code_prod, age_min, drv_exp_min, terr_id, count_permit_after_load, is_blacklist_rgpl, user_id, calc_k5_k6;
   int memo_comm_sale_id, memo_comm_anderr_id, memo_anderrchange_id, index_max_k6, is_blacklist_vin, programm_id_old;
   bool in_event, is_trans, nf_bt, bank_multidrive, is_risk_ts, is_bl, enable_k1f, show_message, this_frame;
   bool central_bd_error, is_editbuttonclick;

   AnsiString FAPO2_ARM_READER_ADR;

   AnsiString pre0_doc_seria, pre0_doc_number, pre1_doc_seria, pre1_doc_number;
private:
   void LoadRegions();
   void LoadTSMarkaList();
   void LoadTSModelList();
   void LoadVozmTypeList();
   void LoadRegionData();
   void LoadDSAGOList();
   bool CheckCost(const double& val);
   void CalcPremium();
   void CalcPremium_0();
   void CalcPremiumOsnRisk();
   AnsiString CalcText();
   void Error(const AnsiString& text, const int unique, bool term, int warning = 0, const AnsiString& type_error = err_prarm);
   void K1_K6_Final(bool recalc = false);
   void GetApplyingKoeffs();
   void GetGroupTS();
   double Round(const double& val){ return m_api->Round(val); }
   void Calc_bt();
   void Calc_kar();
   void Calc_k3();
   void Calc_k7();
   void Calc_Kb();
   void Protivougon();
   void CalcAll(bool is_kr = true, bool is_k7 = true, bool is_protivougon = true);
   void GetRangeAge();
   void ChangeMultiDrive();
   void LoadData();
   void ChangeSource();
   void ChangeBank();
   void GetRiskCode(const int index, const int risk_id);
   void cboxSrokChange();
   void ChangeListProject();
   void ChangeFranshizeBox(TObject *Sender = 0);
   void IsPorsche27RF();
   void DisableGBTS();
   void ChangeListFullInsur();
   void ChangeListCredits();
   bool CheckSummForBenefitProlong();
   double GetMinRate();
   void LoadCity();
   void MakeOfferCustomers();
   void DisableAllControls();
   void BlackListSearchRGPLVIN(const int type = 3);
   void SetPowerAndVolume();
   void RecalcCostTdr(bool all = true);
   void ResetTransdekra();
   void ResetTdrValues(const int index = 0);
   void ResetAllSumms();
   AnsiString GetParams();
   void SetParams(const AnsiString&);
   void SetFrInsteadK1(const double&);
   void SetStatePermitted();
   void SaveAnketa(const int, const int);
   void SetStateBenefitProlong(bool is_bnfprl);
   void SetRowKpr(const double& k_min, const double& k_max, const AnsiString& coeff = "");
   void ResetGridPermitted();
   void ShowGridOrChkPermitted(const int who);
   int CheckPermitted(TADOQuery* q);
   void CalcK6Insured();
   void GetLimitBranch();
   bool IsCreditAvailable();
   void MakePanelDopRiskOnAnderrFrame();
   void CheckBenefitProlong();
   void EnDisControlsForBP(bool state);
   AnsiString MakeFranchiseText(TADOQuery *qq);
   bool BadTerms();

   void LockEdDocAndEdKa(void);

   AnsiString __fastcall GetTSCountryFlag(AnsiString ts_marka, AnsiString ts_model);
public:
   TMemo *memo;
   TFrame1 *f_print;
   TsButton *btnZapros;
   TframeOffCust *f_off_cust;
   TAnderrFrame *f_andr_pan;
   TFramePreCalc *f_pre_calc;
   TStringList *non_standart_str;
public:		// User declarations
   __fastcall TFrameNew(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, TSInfo *p_tsi, Dogovor_Info *p_di);
   __fastcall ~TFrameNew();
   void Init();
   void Calc(TObject* Sender = 0);
   void SaveFrame(TADOQuery *q);
   void LoadFrame(TADOQuery *q);
   void Form171ToExcel();
   void ChangeOrderPayments();
   bool GetCoeffEnabled(const int id_coeff){ return coeff_base.count(id_coeff); }
   bool IsOfferEnabled(){ return (di->risk == 2 && cboxVariant->Items->IndexOf(cboxVariant->EditText) == 0 && tsi->IsCar() && !m_api->Err_Is_Calc_Error_By_Type_RT(res, err_prarm, this)); }
   bool IsNonStandartPolis();
   void RecalcOnTheDate(const TDateTime& dt);
   bool IsChangeData();
   AnsiString ChangeDataToStr();
   void ParsingXML_AgentInfo();
   void SetBl(bool val){ is_bl = val; Calc(f_print); }
   bool IsBenefitProlong(){ return di->contract_type && cboxDogovorType->Node->Count && TermsInfo->RowByName(row_benef_prolong_name)->EditText == "��"; }
   void PremiumDivide();

   void SetAnderFIO(const AnsiString& v){ anderr_fio = v; }
   void SetCostVehicle(const double& v){ di->calc_info.cost_vehicle = v; }
   void SetStrSumma(const double& v){ di->calc_info.str_summa = v; }
   void SetOldStrSumma(const double& v){ di->calc_info.old_str_summa = v; }
   void SetOldPremium(const double& v){ di->calc_info.old_premium = v; }
   void SetObosnKa(const AnsiString& v){ editObosnKa->EditText = obosn_ka = v; }
   void SetFalseThisFrame() { this_frame = false; }
};
//---------------------------------------------------------------------------
extern PACKAGE TFrameNew *FrameNew;
//---------------------------------------------------------------------------
#endif
