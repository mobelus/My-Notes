//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <DateUtils.hpp>

#include "anderrpanel.h"
#include "IAPO2_ARM_READER.h"
#include "UReissCalc.h"
//#include "newcalc.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "dxCntner"
#pragma link "dxExEdtr"
#pragma link "dxInspct"
#pragma link "dxInspRw"
#pragma link "cxControls"
#pragma link "cxDBEditRepository"
#pragma link "cxEdit"
#pragma link "cxEditRepositoryItems"
#pragma link "cxGraphics"
#pragma link "cxInplaceContainer"
#pragma link "cxStyles"
#pragma link "cxVGrid"
#pragma link "cxCurrencyEdit"
#pragma resource "*.dfm"
TAnderrFrame *AnderrFrame;
//---------------------------------------------------------------------------
//__fastcall TAnderrFrame::TAnderrFrame(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, TSInfo *p_tsi, Dogovor_Info *p_di): TFrame(Owner), m_api(mops), pi(p_pi), pm(p_pm), tsi(p_tsi), di(p_di)
__fastcall TAnderrFrame::TAnderrFrame(TComponent* Owner, mops_api_028 *mops, PersonInfo *p_pi, PersonInfo *p_pm, VehicleInfo *p_tsi, Dogovor_Info *p_di): TFrame(Owner), m_api(mops), pi(p_pi), pm(p_pm), tsi(p_tsi), di(p_di)
{
   frmVH = new TfrmViewHistory(0);

   XMLDoc = NewXMLDocument();
   XMLDoc->Active = true;
   XMLDoc->Options.Clear();
   XMLDoc->Options = XMLDoc->Options << doNodeAutoCreate << doAttrNull << doAutoPrefix << doNamespaceDecl << doNodeAutoIndent;
   XMLDoc->Version       = "1.0";
   XMLDoc->Encoding      = "WINDOWS-1251";
   XMLDoc->StandAlone    = "no";

   Root = XMLDoc->CreateNode("request");
   XMLDoc->DocumentElement = Root;
   Root = XMLDoc->DocumentElement;
   //vg_Permitted1->ViewInfo->RowRect.Top;
}
//---------------------------------------------------------------------------
void TAnderrFrame::SaveFrame(TADOQuery *q_save)
{
   q_save->FieldByName("fio_deiizb")->Value = vg_editFIO_DEIIZB->Properties->Value;
}
//---------------------------------------------------------------------------
void TAnderrFrame::LoadFrame(TADOQuery *q)
{
   di->status_dogovor = q->FieldByName("status_id")->AsInteger;
   b_kv               = q->FieldByName("base_kkv")->AsFloat;

   vg_editFIO_DEIIZB->Properties->Value = q->FieldByName("fio_deiizb")->AsString;

   switch(di->status_dogovor){
      case 3: vg_rgAgreed->Properties->Value = "���"; vg_rgAgreed->Properties->Caption = "������ ������������"; break;
      case 4: case 15: vg_rgAgreed->Properties->Value = "��"; vg_rgAgreed->Properties->Caption = "������ ������������"; break;
   }

   m_api->Err_Set_Visible_Errors_Types(res, "������ ����������|�������� � ���", false);
}
//---------------------------------------------------------------------------
void TAnderrFrame::Calc()
{
   AnsiString no_agreed_text(""), message(""), cptn(""), Ks_str = vg_paKc->Properties->Value;
   if(b_kv > 0){
      double curr_kv = 100 - StrToFloatStr(Ks_str).ToDouble() * 100.0;
      double kv_vypl = curr_kv > b_kv ? 0.0 : m_api->Round(100.0 * (b_kv - curr_kv) / (100.0 - curr_kv));
      vg_paKc->Properties->Caption = "�� (��� - " + FloatToStr(b_kv) + "%, � ������� = " + FloatToStr(kv_vypl) + "%)";
   }

   if(di->status_dogovor > 1){
      labNonStandardDogovor_Up->Height = 22;
      switch(di->status_dogovor){
         case 2:
/* //#include "newcalc.h"
            cptn = "������� �� ������� �������� �������� ��������������, �.�.: \r\n" + f_calc->non_standart_str->Text;
            labNonStandardDogovor_Up->Height = (f_calc->non_standart_str->Count + 1) * 22;
*/
            break;
         case 3: cptn = "������� �� ����������."; break;
         case 4: case 15: cptn = "������� ����������."; break;
         case 14:
            cptn = "������� �� ������� �������� �������� ��������������, �.�.: \r\n" + f_reiss->non_standart_str->Text;
            labNonStandardDogovor_Up->Height = (f_reiss->non_standart_str->Count + 1) * 22;
            break;
      }
      labNonStandardDogovor_Up->Properties->Caption = cptn;
      labNonStandardDogovor_Up->Visible = true;
      
      labNonStandardDogovor_Down->Properties->Caption = cptn;
      labNonStandardDogovor_Down->Height = labNonStandardDogovor_Up->Height;
      labNonStandardDogovor_Down->Visible = true;
   }
   else{
      labNonStandardDogovor_Down->Visible = false;
      labNonStandardDogovor_Up->Visible = false;
   }

   if(di->calc_info.ka < di->calc_info.anderr_ka_limit || di->calc_info.str_summa > di->calc_info.anderr_summ_limit || di->calc_info.str_summa2 > di->calc_info.anderr_summ_limit || di->calc_info.cost_vehicle_new > di->calc_info.anderr_summ_limit || (!di->calc_info.risk_model && (
/* //TSInfo
        tsi->is_agreed ||
*/      di->calc_info.cross_error))
/* //#include "newcalc.h"
      || (f_calc && ((f_calc->chkDSAGO->EditText == "True" && !di->calc_info.anderr_dsago) || ((f_calc->cboxVariant->EditText == "������� \"�\"" || f_calc->cboxVariant->EditText == "������� \"�\"")) && !di->calc_info.anderr_variant_b))
*/
       )
      {
      if(di->calc_info.ka < di->calc_info.anderr_ka_limit || di->calc_info.str_summa > di->calc_info.anderr_summ_limit){
         if(di->calc_info.ka < di->calc_info.anderr_ka_limit) message += AnsiString("Ka");
         if(di->calc_info.str_summa > di->calc_info.anderr_summ_limit || di->calc_info.str_summa2 > di->calc_info.anderr_summ_limit || di->calc_info.cost_vehicle_new > di->calc_info.anderr_summ_limit){
            if(!message.IsEmpty()) message += (" � ");
            message += AnsiString("��������� �����");
         }
         no_agreed_text = "��� ����� " + message + " �� ��������� �����������/�� ����������� ���� �������. ";
      }
/* //#include "newcalc.h"
      if(f_calc && ((f_calc->chkDSAGO->EditText == "True" && !di->calc_info.anderr_dsago) || ((f_calc->cboxVariant->EditText == "������� \"�\"" || f_calc->cboxVariant->EditText == "������� \"�\"") && !di->calc_info.anderr_variant_b))) no_agreed_text += "���. ���� ����� � �������� �,� ��������������� � ��. ";
*/
      if(!di->calc_info.risk_model && (
/* //TSInfo
      tsi->is_agreed ||
*/       di->calc_info.cross_error)) no_agreed_text += "������ �� ��������������� � ��.";

      vg_rgNoAgreed->Properties->Value = no_agreed_text;
      vg_rgNoAgreed->Visible = true;
      vg_rgAgreed->Visible = false;
   }
   else{
      vg_rgNoAgreed->Visible = false;
      vg_rgAgreed->Visible = true;
   } 
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::vgDrawRowHeader(TObject *Sender, TcxCanvas *ACanvas, TcxvgPainter *APainter, TcxCustomRowHeaderInfo *AHeaderViewInfo, bool &Done)
{
   /*int h(0), cnt_visible_rows(0);
   for(int i = 0, cnt = vg->Rows->Count; i < cnt; ++i){
      if(vg->IsRowVisible(vg->Rows->Items[i])){
         h += vg->Rows->Items[i]->Height;
         ++cnt_visible_rows;
      }
   }
   vg->Height = h + cnt_visible_rows + 5;*/
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::CurrencyItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   Error = false;
/* //#include "newcalc.h"
   switch(vg->FocusedRow->Tag){
      case 1:
          f_calc->SetCostVehicle(StrToFloatStr(DisplayValue).ToDouble());
         f_calc->editTSRealCost->EditText = FloatToStr(di->calc_info.cost_vehicle);
         if(f_calc->editStrSumma->ReadOnly){
            vg_paVehicleStrSumma->Properties->Value = di->calc_info.cost_vehicle;
            f_calc->SetStrSumma(di->calc_info.cost_vehicle);
            f_calc->editStrSumma->EditText = f_calc->editTSRealCost->EditText;
         }
         f_calc->Calc();
         DisplayValue = di->calc_info.cost_vehicle;
         break;
      case 2:
         f_calc->SetStrSumma(StrToFloatStr(DisplayValue).ToDouble());
         f_calc->editStrSumma->EditText = FloatToStr(di->calc_info.str_summa);
         f_calc->Calc();
         DisplayValue = di->calc_info.str_summa;
         break;
   }
*/
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::vgEdited(TObject *Sender, TcxCustomEditorRowProperties *ARowProperties)
{
   labHint->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::CurrencyItemPropertiesChange(TObject *Sender)
{
   if(vg->FocusedRow && vg->InplaceEditor){
      labHint->Top = vg->InplaceEditor->Top + 2;
      labHint->Visible = true;
   }
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::ButtonItemPropertiesButtonClick(TObject *Sender, int AButtonIndex)
{
   RegTypes();
   int index = vg->FocusedRow->Tag - 1, show(0);
   AnsiString filename = m_api->Excel_tmp_path + "\\temp.xml", caption("");
   if(index == -1){
      Root->ChildNodes->Clear();
      caption = dynamic_cast<TcxEditorRow*>(vg->FocusedRow)->Properties->Value;
      if(pi[0].dogovors["k5"].size()){
         show = 1;
         _di_IXMLNode contracts = Root->AddChild("contracts");
         for(unsigned i = 0; i < pi[0].dogovors["k5"].size(); ++i){
            _di_IXMLNode contract = contracts->AddChild("contract");
            contract->Attributes["id"]     = pi[0].dogovors["k5"][i].id;
            contract->Attributes["system"] = pi[0].dogovors["k5"][i].system;
         }
         pi[0].XMLDoc->LoadFromXML(GetIAPO2_ARM_READER(false, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"))->GetInfoContracts(XMLDoc->GetXML()->Text));
         pi[0].XMLDoc->SaveToFile(filename);
      }                                             
   }
   else{
      Root->ChildNodes->Clear();
      caption = dynamic_cast<TcxMultiEditorRow*>(vg->FocusedRow)->Properties->Editors->Items[0]->Value;
      if(di->type_multydrive == 100){
         if(pm[index].dogovors["k6"].size() || !pm[index].rsa_id.IsEmpty()){
            show = 1;
            Root->AddChild("kbm_rsa_id")->Text = pm[index].rsa_id;
            _di_IXMLNode contracts = Root->AddChild("contracts");
            for(unsigned i = 0; i < pm[index].dogovors["k6"].size(); ++i){
               _di_IXMLNode contract = contracts->AddChild("contract");
               contract->Attributes["id"]     = pm[index].dogovors["k6"][i].id;
               contract->Attributes["system"] = pm[index].dogovors["k6"][i].system;
            }
            pm[index].XMLDoc->LoadFromXML(GetIAPO2_ARM_READER(false, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"))->GetInfoContracts(XMLDoc->GetXML()->Text));
            pm[index].XMLDoc->SaveToFile(filename);
         }
      }
      else{
         if(pi[0].dogovors["k6"].size() || !pi[0].rsa_id.IsEmpty()){
            show = 1;
            Root->AddChild("kbm_rsa_id")->Text = pi[0].rsa_id;
            _di_IXMLNode contracts = Root->AddChild("contracts");
            for(unsigned i = 0; i < pi[0].dogovors["k6"].size(); ++i){
               _di_IXMLNode contract = contracts->AddChild("contract");
               contract->Attributes["id"]     = pi[0].dogovors["k6"][i].id;
               contract->Attributes["system"] = pi[0].dogovors["k6"][i].system;
            }
            pi[0].XMLDoc->LoadFromXML(GetIAPO2_ARM_READER(false, m_api->vrGetVariable(res, "_mops_global_soap_server_address_"))->GetInfoContracts(XMLDoc->GetXML()->Text));
            pi[0].XMLDoc->SaveToFile(filename);
         }
      }
   }
   UnRegTypes();
   if(show){
      frmVH->WB->Navigate(WideString(filename).c_bstr());
      frmVH->Caption = caption;
      frmVH->Show();
   }
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::K4_ComboBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
/* //#include "newcalc.h"
   if(!vg_paK4->Properties->Value.IsNull()){
      int ind = K4_ComboBoxItem->Properties->Items->IndexOf(vg_paK4->Properties->Value);
      int ind_type_fr = f_calc->cboxTypeFranshiza->Items->IndexOf(f_calc->cboxTypeFranshiza->EditText);
      if(ind == -1) ind = 0;
      if(ind_type_fr == -1) ind_type_fr = 0;
      DataDict *dataK4 = (DataDict*)K4_ComboBoxItem->Properties->Items->Objects[ind], *dataK4_calc = (DataDict*)f_calc->cboxTypeFranshiza->Items->Objects[ind_type_fr];
      switch(dataK4->id){
         case 1:
            if(dataK4_calc->id != 1){
               f_calc->cboxTypeFranshiza->EditText = "�� �����������";
               f_calc->ControlChange(f_calc->cboxTypeFranshiza);
            }
            break;
         case 6:
            if(dataK4_calc->id != 6){
               f_calc->cboxTypeFranshiza->EditText = "������������";
               f_calc->ControlChange(f_calc->cboxTypeFranshiza);
            }
            break;
         default:
            switch(dataK4->field_val1){
               case 2:
                  if(dataK4_calc->field_val1 != 2){
                     f_calc->cboxTypeFranshiza->EditText = "����������� � %";
                     f_calc->ControlChange(f_calc->cboxTypeFranshiza);
                  }
                  f_calc->cboxFranshiza->EditText = dataK4->coeff_value;
                  f_calc->Calc();
                  break;
               case 4:
                  if(dataK4_calc->field_val1 != 4){
                     f_calc->cboxTypeFranshiza->EditText = "����������� � ������ ��������";
                     f_calc->ControlChange(f_calc->cboxTypeFranshiza);
                  }
                  f_calc->cboxFranshiza->EditText = dataK4->coeff_value;
                  f_calc->Calc();
                  break;
            }
            break;
      }
   }
*/
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::K7_ComboBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();

   TcxEditorRow *row = dynamic_cast<TcxEditorRow*>(vg->FocusedRow);
   TdxInspectorTextPickRow *r_calc;
   TcxEditRepositoryComboBoxItem *cboxitem;

   if(!row->Properties->Value.IsNull())
   {
/* //#include "newcalc.h"
      switch(row->Tag){
         case 3: r_calc = f_calc->cboxVozmType; cboxitem = K7_ComboBoxItem; break;
         case 4: r_calc = f_calc->editKV; cboxitem = Kc_ComboBoxItem; break;
      }
      int ind = cboxitem->Properties->Items->IndexOf(row->Properties->Value);
      if(ind != r_calc->Items->IndexOf(r_calc->EditText)){
         r_calc->EditText = r_calc->Items->Strings[ind];
         f_calc->ControlChange(r_calc);
      }
*/
   }
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::Ka_ComboBoxItemPropertiesChange(TObject *Sender)
{
/* //#include "newcalc.h"
   double old_ka = StrToFloatStr(f_calc->editKa->EditText).ToDouble();

   vg->InplaceEditor->PostEditValue();

   if(!vg_paKa->Properties->Value.IsNull()){
      int ind = Ka_ComboBoxItem->Properties->Items->IndexOf(vg_paKa->Properties->Value);
      if(ind != f_calc->editKa->Items->IndexOf(f_calc->editKa->EditText)){
         f_calc->editKa->EditText = f_calc->editKa->Items->Strings[ind];
         if(old_ka == 1.0){
            vg_paObosnKa->Visible = true;
            vg_paObosnKa->Properties->Value = "������� ������������";
         }
         else{
            double ka = StrToFloatStr(f_calc->editKa->EditText).ToDouble();
            if(ka == 1.0){
               vg_paObosnKa->Visible = false;
               vg_paObosnKa->Properties->Value = empty_str;
            }
         }
      }
      f_calc->SetObosnKa(vg_paObosnKa->Properties->Value);
      f_calc->ControlChange(f_calc->editKa);
   }
//*/
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::CheckBoxItemPropertiesChange(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   TcxMultiEditorRow *row = dynamic_cast<TcxMultiEditorRow*>(vg->FocusedRow);
   int index = row->Tag - 1;
   if(index < 0) return;
/* //#include "newcalc.h"
   f_calc->gridDopush->Items->Item[index]->Checked = row->Properties->Editors->Items[1]->Value;
   f_calc->gridDopushClick(0);
*/
   vg_paK6->Properties->Value = di->calc_info.k6;
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::DateItemPropertiesChange(TObject *Sender)
{
   if(vg->FocusedRow && vg->InplaceEditor){
      labHint->Top = vg->InplaceEditor->Top + 2;
      labHint->Visible = true;
   }
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::DateItemPropertiesEditValueChanged(TObject *Sender)
{
   vg->InplaceEditor->PostEditValue();
   Variant val = vg_dateQT->Properties->Value;
   if(!val.IsNull()){
      AnsiString dt_str = val;
      if(dt_str.Length() < 10 || !TryStrToDate(dt_str, date_qt)) date_qt.Val = 0;
/* //#include "newcalc.h"
      else f_calc->RecalcOnTheDate(date_qt);
//*/
   }
   else date_qt.Val = 0;
   labHint->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::ResizeTimerTimer(TObject *Sender)
{
   vg->Height = ((TWinControl*)this->Owner)->Height - 7; // ������� ������ ��������
}
//---------------------------------------------------------------------------
void __fastcall TAnderrFrame::DateItemPropertiesValidate(TObject *Sender, Variant &DisplayValue, TCaption &ErrorText, bool &Error)
{
   if(Error) DisplayValue = variant_null;
   Error = false;
}
//---------------------------------------------------------------------------

