//---------------------------------------------------------------------------

#include <vcl.h>

#pragma hdrstop

#include "UReissCalc.h"
#include "UThreadUFO.h"


#pragma package(smart_init)
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, PersonInfo *p_pi, PersonInfo *p_pm)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), vi(p_vi), pi(p_pi), pm(p_pm)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi, TADOQuery *q_r, TADOQuery *q_v)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), pi(p_pi), q_reservations(q_r), q_vehicles(q_v)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, PersonInfo *p_pi)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), pi(p_pi)
{
}
//---------------------------------------------------------------------------
/*__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_m, TADOQuery *q_r, TADOQuery *q_v)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_main(q_m), q_reservations(q_r), q_vehicles(q_v)
{
} */
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_pl, TADOQuery *q_p, TADOQuery *q_v, TADOQuery *q_ins, TMemoryStream *fs)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_policy(q_pl), q_persons(q_p), q_vehicles(q_v), q_insurer(q_ins), pdf_file(fs)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_pl, TADOQuery *q_p, TADOQuery *q_v, TADOQuery *q_ins)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_policy(q_pl), q_persons(q_p), q_vehicles(q_v), q_insurer(q_ins)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, TADOQuery *q_c, TADOQuery *q_p, TADOQuery *q_v)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), q_calc(q_c), q_policy(q_p), q_vehicles(q_v)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, TADOQuery *q_insp)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), vi(p_vi), q_inspection_docs(q_insp)
{
}
//---------------------------------------------------------------------------
__fastcall ThreadUFO::ThreadUFO(bool CreateSuspended, const TypeUfoFunction& tf, const AnsiString& ssa, mops_api_028 *mops, Dogovor_Info *p_di, VehicleInfo *p_vi, TADOQuery *q_insp, TMemoryStream *fs)
   : TThread(CreateSuspended), type_function(tf), soap_server_address(ssa), m_api(mops), di(p_di), vi(p_vi), q_inspection_docs(q_insp), pdf_file(fs)
{
}
//---------------------------------------------------------------------------
void __fastcall ThreadUFO::Execute()
{
   curr_year = YearOf(Date());

   char ds = DecimalSeparator;
   DecimalSeparator = '.';
   NS_KaskoProxyService::User *user_kaskoproxy = new NS_KaskoProxyService::User();
   NS_InspectionProxyService::User *user_inspect = new NS_InspectionProxyService::User();
   //user->UserName = m_api->vrGetVariable(res, "_mops_global_ufo_login_");
   //AnsiString pass = m_api->vrGetVariable(res, "_mops_global_ufo_password_");

   //AnsiString pass1 = m_api->Shifr_Text(res, kl, pass, false);

   //user->Password = pass;

   //
   // TEST
   //
   //user_kaskoproxy->UserName = L"apo"; user_kaskoproxy->Password = L"popa";
   //user_inspect->UserName = L"apo"; user_inspect->Password = L"popa";

   //
   // PROD
   //
   user_kaskoproxy->UserName = L"apo"; user_kaskoproxy->Password = L"2FRuPqO$";
   user_inspect->UserName = L"apo"; user_inspect->Password = L"2FRuPqO$";



   //user_kaskoproxy->UserName = L"apop"; user_kaskoproxy->Password = L"0s8pRthSL";
   //user_inspect->UserName = L"apop"; user_inspect->Password = L"0s8pRthSL";

   CalculationRequest *baCalculationRequest = new CalculationRequest();
   OperationResultOfCalculationResultoTurZuT3 *ResultOfCalculation = new OperationResultOfCalculationResultoTurZuT3();

   KaskoAutoProtectionRequest *PrintPolicyRequest = new KaskoAutoProtectionRequest();
   KaskoFLSpecialRequest *PrintPolicySpecialRequest = new KaskoFLSpecialRequest();
   CalculationSheet *PrintCalculationSheet = new CalculationSheet();

   OperationResultOfPrintResult1QqCV82X *resultOfPrint = new OperationResultOfPrintResult1QqCV82X();
   OperationResultOfArrayOfPrintResult1QqCV82X *ArrayResultOfPrint = new OperationResultOfArrayOfPrintResult1QqCV82X();

   UnderwritingAdditionalInfo *baUnderInfo = new UnderwritingAdditionalInfo();
   OperationResultOfContractStatusNamesmxVaabBO *resultOfSendApprove = new OperationResultOfContractStatusNamesmxVaabBO();
   OperationResultOfQuotationStateInfooTurZuT3 *resultOfApprove = new OperationResultOfQuotationStateInfooTurZuT3();

   InspectionDocumentInput *document = new InspectionDocumentInput();
   OperationResultOfguid *ResultOfguid = new OperationResultOfguid();

   SearchParameters *searchParameters = new SearchParameters();
   searchParameters->ContractId = di->contract_id;
   OperationResultOfArrayOfInspectionoTurZuT3 *resultOfInspection = new OperationResultOfArrayOfInspectionoTurZuT3();

   OperationResultOfboolean *ResultOfboolean = new OperationResultOfboolean();

   OperationResultOfInspectionDocumentoTurZuT3 *ResultOfInspectionDocument = new OperationResultOfInspectionDocumentoTurZuT3();
                            
   switch(type_function)
   {
      case ufo_calc:
         FillCalculationRequest(baCalculationRequest);
         ResultOfCalculation = GetIKaskoProxyService(false, soap_server_address)->Calculate(user_kaskoproxy, baCalculationRequest);
         SelectionFromResultOfCalculation(ResultOfCalculation);
         break;
/* #ifdef METHODS_FROM_KASKO_2UFO
      case ufo_print_policy:
         FillPrintPolicyRequest(PrintPolicyRequest);
         ArrayResultOfPrint = GetIKaskoProxyService(false, soap_server_address)->PrintAutoProtectionPolicy(user_kaskoproxy, PrintPolicyRequest);
         GetPDF(ArrayResultOfPrint);
         break;
      case ufo_print_policy_special:
         FillPrintPolicySpecialRequest(PrintPolicySpecialRequest);
         ArrayResultOfPrint = GetIKaskoProxyService(false, soap_server_address)->PrintKaskoFLSpecial(user_kaskoproxy, PrintPolicySpecialRequest);
         GetPDF(ArrayResultOfPrint);
         break;
      case ufo_print_calc_sheet:
         FillPrintCalculationSheet(PrintCalculationSheet);
         resultOfPrint = GetIKaskoProxyService(false, soap_server_address)->PrintCalculationSheet(user_kaskoproxy, PrintCalculationSheet);
         GetPDF(resultOfPrint);
         break;
      case ufo_send_approve:
         FillUnderwritingAdditionalInfo(baUnderInfo);
         resultOfSendApprove = GetIKaskoProxyService(false, soap_server_address)->SendToApprove(user_kaskoproxy, baUnderInfo);
         SelectionFromResultOfSendApprove(resultOfSendApprove);
         break;
      case ufo_only_check_status:
         resultOfApprove = GetIKaskoProxyService(false, soap_server_address)->CheckStatus(user_kaskoproxy, q_policy->FieldByName("contract_id")->AsString);
         SelectionStatus(resultOfApprove);
         break;
      case ufo_check_status:
         resultOfApprove = GetIKaskoProxyService(false, soap_server_address)->CheckStatus(user_kaskoproxy, q_policy->FieldByName("contract_id")->AsString);
         SelectionFromResultOfApprove(resultOfApprove);
         break;
      case ufo_inspection_create:
         ResultOfguid = GetIInspectionProxyService(false, soap_server_address)->Create(user_inspect, di->contract_id, vi->vin);
         SelectionFromResultOfguid(ResultOfguid);
         break;
      case ufo_inspection_adddoc:
         FillInspectionDocumentInput(document);
         ResultOfguid = GetIInspectionProxyService(false, soap_server_address)->AddDocument(user_inspect, vi->inspection_id, document);
         SelectFromOperationResultOfguid(ResultOfguid);
         break;
      case ufo_inspection_search:
         resultOfInspection = GetIInspectionProxyService(false, soap_server_address)->Search(user_inspect, searchParameters);
         SelectionFromResultOfInspection(resultOfInspection);
         break;
      case ufo_inspection_status:
         ResultOfboolean = GetIInspectionProxyService(false, soap_server_address)->ChangeStatus(user_inspect, vi->inspection_id, 2);
         if(ResultOfboolean->Data) vi->inspection_status = 2;
         break;
      case ufo_inspection_getdoc:
         ResultOfInspectionDocument = GetIInspectionProxyService(false, soap_server_address)->GetDocument(user_inspect, q_inspection_docs->FieldByName("document_id")->AsString);
         SelectionFromResultOfInspectionDocument(ResultOfInspectionDocument);
         break;
#endif // METHODS_FROM_KASKO_2UFO
//*/

   }
/*
   switch(type_function){
      case ufo_calc:
         FillCalculationRequest(baCalculationRequest);
         ResultOfCalculation = GetIKaskoProxyService(m_api, false, soap_server_address)->Calculate(user_kaskoproxy, baCalculationRequest);
         SelectionFromResultOfCalculation(ResultOfCalculation);
         break;
      case ufo_print_policy:
         FillPrintPolicyRequest(PrintPolicyRequest);
         ArrayResultOfPrint = GetIKaskoProxyService(m_api, false, soap_server_address)->PrintAutoProtectionPolicy(user_kaskoproxy, PrintPolicyRequest);
         GetPDF(ArrayResultOfPrint);
         break;
      case ufo_print_policy_special:
         FillPrintPolicySpecialRequest(PrintPolicySpecialRequest);
         ArrayResultOfPrint = GetIKaskoProxyService(m_api, false, soap_server_address)->PrintKaskoFLSpecial(user_kaskoproxy, PrintPolicySpecialRequest);
         GetPDF(ArrayResultOfPrint);
         break;
      case ufo_print_calc_sheet:
         FillPrintCalculationSheet(PrintCalculationSheet);
         resultOfPrint = GetIKaskoProxyService(m_api, false, soap_server_address)->PrintCalculationSheet(user_kaskoproxy, PrintCalculationSheet);
         GetPDF(resultOfPrint);
         break;
      case ufo_send_approve:
         FillUnderwritingAdditionalInfo(baUnderInfo);
         resultOfSendApprove = GetIKaskoProxyService(m_api, false, soap_server_address)->SendToApprove(user_kaskoproxy, baUnderInfo);
         SelectionFromResultOfSendApprove(resultOfSendApprove);
         break;
      case ufo_only_check_status:
         resultOfApprove = GetIKaskoProxyService(m_api, false, soap_server_address)->CheckStatus(user_kaskoproxy, q_policy->FieldByName("contract_id")->AsString);
         SelectionStatus(resultOfApprove);
         break;
      case ufo_check_status:
         resultOfApprove = GetIKaskoProxyService(m_api, false, soap_server_address)->CheckStatus(user_kaskoproxy, q_policy->FieldByName("contract_id")->AsString);
         SelectionFromResultOfApprove(resultOfApprove);
         break;
      case ufo_inspection_create:
         ResultOfguid = GetIInspectionProxyService(false, soap_server_address)->Create(user_inspect, di->contract_id, vi->vin);
         SelectionFromResultOfguid(ResultOfguid);
         break;
      case ufo_inspection_adddoc:
         FillInspectionDocumentInput(document);
         ResultOfguid = GetIInspectionProxyService(false, soap_server_address)->AddDocument(user_inspect, vi->inspection_id, document);
         SelectFromOperationResultOfguid(ResultOfguid);
         break;
      case ufo_inspection_search:
         resultOfInspection = GetIInspectionProxyService(false, soap_server_address)->Search(user_inspect, searchParameters);
         SelectionFromResultOfInspection(resultOfInspection);
         break;
      case ufo_inspection_status:
         ResultOfboolean = GetIInspectionProxyService(false, soap_server_address)->ChangeStatus(user_inspect, vi->inspection_id, 2);
         if(ResultOfboolean->Data) vi->inspection_status = 2;
         break;
      case ufo_inspection_getdoc:
         ResultOfInspectionDocument = GetIInspectionProxyService(false, soap_server_address)->GetDocument(user_inspect, q_inspection_docs->FieldByName("document_id")->AsString);
         SelectionFromResultOfInspectionDocument(ResultOfInspectionDocument);
         break;
   }

*/


   delete baCalculationRequest;
   delete ResultOfCalculation;

   delete PrintPolicyRequest;
   delete PrintPolicySpecialRequest;
   delete PrintCalculationSheet;

   delete resultOfPrint;
   delete ArrayResultOfPrint;

   delete baUnderInfo;
   delete resultOfSendApprove;
   delete resultOfApprove;

   delete document;
   delete ResultOfguid;

   delete searchParameters;
   delete resultOfInspection;

   delete ResultOfboolean;

   delete ResultOfInspectionDocument;

   delete user_kaskoproxy;
   delete user_inspect;

   DecimalSeparator = ds;
}
//---------------------------------------------------------------------------
void ThreadUFO::FillCalculationRequest(CalculationRequest *CalcReq)
{
	   for (int i=0; i<2; ++i)
	   {
       		   AnsiString str___1 = /*"new_premiya_osn_risk= " + FloatToStr(new_premiya_osn_risk) + " "*/
			   "di->calc_info.osn_risk_itog_tarif= " + FloatToStr(di->calc_info.osn_risk_itog_tarif) + " "
			   "k1= "  + FloatToStr(pm[i].k1)  + " "
			   "k6= "  + FloatToStr(pm[i].k6)  + " "
			   " FINAL";
       }

   //int offsethour = m_api->dbGetIntFromQueryDef(res, "select time_utc_offset from gl_dict_time_zone where Date()>=start_date and Date()<=end_date and region_skk=" + QuotedStr(AddNulls(di->region_id, 2)));
   int offsethour = GetOffsetMin() / 60;

   // ����� �����
   if(di->calc_type) CalcReq->IsPreCalculation = true;
   CalcReq->BranchId = di->user_info.skk;
   CalcReq->ProductId = di->product_id;
   if(di->programm_id) CalcReq->ProgramId = IntToStr(di->programm_id);
   if(di->project_id)  CalcReq->ProjectId = IntToStr(di->project_id);
   if(!di->contract_id.IsEmpty()) CalcReq->ContractId = di->contract_id;
   CalcReq->BankId = di->bank_code;
   CalcReq->KaskoTerritoryId = di->region_id;

   CalcReq->CalculationDate = ConvertDateTime(TDateTime(di->calc_date), "00:00", offsethour);
   //CalcReq->CalculationDate = ConvertDateTimeNoZeros(TDateTime(di->calc_date), "00:00", offsethour);

   //CalcReq->CalculationDate = new TXSDateTime();
   //CalcReq->CalculationDate->AsDateTime = TDateTime(di->calc_date);

    unsigned short Year, Month, Day;
    di->datesrok_s.DecodeDate(&Year, &Month, &Day);
    AnsiString str__s  = "." + String(Day) + "_" + Month + "_" + Year + ".";
    di->datesrok_po.DecodeDate(&Year, &Month, &Day);
    AnsiString str__po = "." + String(Day) + "_" + Month + "_" + Year + ".";

   //di->monthcount = MonthsCount(di->datesrok_s, di->datesrok_po);
   TDateTime dtTodayPlusOneDayS, dtFromTodayPlusOneDayPo; // if Period S PO is 1 year, And today we have 26.04.2017 => dtTodayPlusOneDayS = 27.04.2017  and  dtFromTodayPlusOneDayPo = 26.04.2018
   dtTodayPlusOneDayS = IncDay(Date(), 1);
   dtFromTodayPlusOneDayPo = CalcEndDateInsur(dtTodayPlusOneDayS, di->monthcount);
   //IncDay(dtFromTodayPlusOneDayPo, -1);

   CalcReq->PolicyStartDate = ConvertDateTime(dtTodayPlusOneDayS, di->time_s, offsethour); // !!!!! // ���� ������ ����� ����������� (CalculationRequest.PolicyStartDate): ���� ������ ����������� (19.09.2015 0:00:00 +03:00) �� ����� ���� ������ ���� ������� (2017-04-25T00:00:00.0000000+03:00)
   //CalcReq->PolicyStartDate = ConvertDateTime(di->datesrok_s, di->time_s, offsethour); // !!!!! // ���� ������ ����� ����������� (CalculationRequest.PolicyStartDate): ���� ������ ����������� (19.09.2015 0:00:00 +03:00) �� ����� ���� ������ ���� ������� (2017-04-25T00:00:00.0000000+03:00)
   //CalcReq->PolicyStartDate = ConvertDateTimeNoZeros(di->datesrok_s, di->time_s, offsethour);

   /*new TXSDateTime();
   CalcReq->PolicyStartDate->AsDateTime = di->datesrok_s;
   CalcReq->PolicyStartDate->Hour = di->time_s.SubString(1, 2).ToIntDef(0);
   CalcReq->PolicyStartDate->Minute = di->time_s.SubString(4, 2).ToIntDef(0);*/

   CalcReq->PolicyEndDate = ConvertDateTime(dtFromTodayPlusOneDayPo, "23:59", offsethour);
   //CalcReq->PolicyEndDate = ConvertDateTime(di->datesrok_po, "23:59", offsethour);
   //CalcReq->PolicyEndDate = ConvertDateTimeNoZeros(di->datesrok_po, "23:59", offsethour);

   /*new TXSDateTime();
   CalcReq->PolicyEndDate->AsDateTime = di->datesrok_po;
   CalcReq->PolicyEndDate->Hour = 23;
   CalcReq->PolicyEndDate->Minute = 59; */
   CalcReq->PolicyPaymentsCount = di->payments_count;
   CalcReq->ActivePoliciesVehiclesCount = di->vehcount;
   if(di->user_info.sale_channel_id) CalcReq->SaleChannelType2008Id = AnsiString(di->user_info.sale_channel_id);
   //---------------------------------------------------------------------------

    //unsigned short Year, Month, Day;
    dtTodayPlusOneDayS.DecodeDate(&Year, &Month, &Day);
    AnsiString str_s  = "." + String(Day) + "_" + Month + "_" + Year + ".";
    dtFromTodayPlusOneDayPo.DecodeDate(&Year, &Month, &Day);
    AnsiString str_po = "." + String(Day) + "_" + Month + "_" + Year + ".";

   int mnths = MonthsCount(dtTodayPlusOneDayS, dtFromTodayPlusOneDayPo);


   // ������ �� ������������
   CalcReq->Insurant = new Insurant();

   CalcReq->Insurant->IsKeyClient = 0;

   int nStatus = pi[0].status;
   //CalcReq->Insurant->SubjectTypeId = pi[0].status; // !!!!! // ��� ������������ (���������� 7.3.28) (Insurant.SubjectTypeId): �������� �� ������� � �����������
   CalcReq->Insurant->SubjectTypeId = (nStatus != 0) ? nStatus : 1; // !!!!! // ��� ������������ (���������� 7.3.28) (Insurant.SubjectTypeId): �������� �� ������� � �����������

   CalcReq->Insurant->KladrCode = pi[0].kladr_addr->Values["��� �����"].SubString(1, 2);
   
   if(pi[0].status == 2){
      TADOQuery *q_opf = m_api->dbGetCursor(res, "select opf, opf_full from kasko_dict_opf where id=" + IntToStr(pi[0].opf_id));
      CalcReq->Insurant->Organization = new LegalEntity();
      CalcReq->Insurant->Organization->OrgForm = q_opf->FieldByName("opf")->AsString;
      CalcReq->Insurant->Organization->OrgFormFull = q_opf->FieldByName("opf_full")->AsString;
      m_api->dbCloseCursor(res, q_opf);

      CalcReq->Insurant->Organization->Name = pi[0].organization;
      CalcReq->Insurant->OGRN = pi[0].ogrn;
      CalcReq->Insurant->INN = pi[0].inn;
   }
   else{
      CalcReq->Insurant->Name = new PersonName();
      CalcReq->Insurant->Name->FirstName = pi[0].firstname;
      CalcReq->Insurant->Name->SecondName = pi[0].secondname;
      CalcReq->Insurant->Name->LastName = pi[0].lastname;
      if(!di->calc_type && pi[0].status != 2){
         CalcReq->Insurant->BirthDate = new TXSDateTime();
         CalcReq->Insurant->BirthDate->AsDateTime = pi[0].birthdate;
         CalcReq->Insurant->Document = new InsurantDocument();
         CalcReq->Insurant->Document->TypeId = AddNulls(pi[0].doc_type, 3);
         CalcReq->Insurant->Document->Series = StringReplace(pi[0].doc_seria, space_str, empty_str, rf);
         CalcReq->Insurant->Document->Number = pi[0].doc_number;
         if(pi[0].status == 5){
            CalcReq->Insurant->OGRNIP = pi[0].ogrn;
            CalcReq->Insurant->INN = pi[0].inn;
         }
      }
   }
   //---------------------------------------------------------------------------

   // ������ �� ��
   CalcReq->Vehicles.Length = 1;
   CalcReq->Vehicles[0] = new Vehicle();
   CalcReq->Vehicles[0]->VehNumber = one_str;

   CalcReq->Vehicles[0]->RsaModelId = AddNulls(vi->rsa_code, 9);

   CalcReq->Vehicles[0]->ManufactureYear = vi->construction_year;

   if(vi->construction_year == curr_year - 1)
   {
      CalcReq->Vehicles[0]->VehiclePTSDate = new TXSDateTime();
      CalcReq->Vehicles[0]->VehiclePTSDate->AsDateTime = vi->registration_issue_date;
   }

   if(vi->vehicle_type_id == 3 || vi->allowed_mass > 3500)
   {
     CalcReq->Vehicles[0]->AllowWeight = vi->allowed_mass;
   }
   if(vi->vehicle_type_id == 4)
   {
     CalcReq->Vehicles[0]->SeatCount = vi->number_of_seats;
   }

   CalcReq->Vehicles[0]->VIN = vi->vin;
   CalcReq->Vehicles[0]->ChassisNumber = vi->chassis_number;
   CalcReq->Vehicles[0]->FrameNumber = vi->body_number;
   if(vi->is_registration_vehicle == 1) CalcReq->Vehicles[0]->LicensePlate = vi->registration_mark;

   CalcReq->Vehicles[0]->TransdekraId = vi->transdekra_id;
   CalcReq->Vehicles[0]->Cost = new TXSDecimal();
   CalcReq->Vehicles[0]->Cost->DecimalString = FloatToSQLStr(!di->IsZdtp() ? di->calc_info.cost_vehicle : di->calc_info.damage_limit);
   CalcReq->Vehicles[0]->Liability = new TXSDecimal();
   CalcReq->Vehicles[0]->Liability->DecimalString = FloatToSQLStr(!di->IsZdtp() ? di->calc_info.str_summa : di->calc_info.damage_limit);
   if(di->product_id == 311){
      CalcReq->Vehicles[0]->VehicleDamageSumLimit = new TXSDecimal();
      CalcReq->Vehicles[0]->VehicleDamageSumLimit->DecimalString = IntToStr(di->calc_info.damage_limit);
   }
   CalcReq->Vehicles[0]->IsLiabilityNonAggregate = di->calc_info.liab_type ? true : false;

	   for (int i=0; i<2; ++i)
	   {
       		   AnsiString str___1 = /*"new_premiya_osn_risk= " + FloatToStr(new_premiya_osn_risk) + " "*/
			   "di->calc_info.osn_risk_itog_tarif= " + FloatToStr(di->calc_info.osn_risk_itog_tarif) + " "
			   "k1= "  + FloatToStr(pm[i].k1)  + " "
			   "k6= "  + FloatToStr(pm[i].k6)  + " "
			   " FINAL";
       }


   if(vi->is_gap){
      CalcReq->Vehicles[0]->ReservationIds.Length = 1;
      CalcReq->Vehicles[0]->ReservationIds[0] = 2;
   }
   CalcReq->Vehicles[0]->Ka = new TXSDecimal();
   CalcReq->Vehicles[0]->Ka->DecimalString = FloatToSQLStr(di->calc_info.ka);
   CalcReq->Vehicles[0]->Kc = new TXSDecimal();
   CalcReq->Vehicles[0]->Kc->DecimalString = FloatToSQLStr(di->calc_info.ks);
   CalcReq->Vehicles[0]->DsagoLiability = new TXSDecimal();
   CalcReq->Vehicles[0]->DsagoLiability->DecimalString = FloatToSQLStr(di->calc_info.str_summa_dsago);
   CalcReq->Vehicles[0]->AccidentLiability = new TXSDecimal();
   CalcReq->Vehicles[0]->AccidentLiability->DecimalString = FloatToSQLStr(di->calc_info.str_summa_ns);
   CalcReq->Vehicles[0]->DmsLiability = new TXSDecimal();
   CalcReq->Vehicles[0]->DmsLiability->DecimalString = FloatToSQLStr(di->calc_info.str_summa_dms);
   CalcReq->Vehicles[0]->HasTrailer = vi->is_trailer ? true : false;

   if(di->calc_type && !di->IsZdtp()){
      if(di->contract_type_precalc == 1) CalcReq->Vehicles[0]->PreCalcOsagoHistoryClass = di->product_id < 304 ? di->k56precalc_parameter : 1;
      else if(di->contract_type_precalc == 2) CalcReq->Vehicles[0]->PreCalcKaskoClaimsCount = di->k56precalc_parameter;
   }


   CalcReq->Vehicles[0]->IsFirstRisk = di->system_insur == 3;
   CalcReq->Vehicles[0]->UsagePurposeId = vi->usage_purpose_id ? IntToStr(vi->usage_purpose_id) : empty_str;
   CalcReq->Vehicles[0]->PaymentMethodId = IntToStr(di->pay_id);
   CalcReq->Vehicles[0]->KaskoRiskId = di->risk;
   CalcReq->Vehicles[0]->Franchise = new Franchise();
   CalcReq->Vehicles[0]->Franchise->TypeId = IntToStr(di->franshize_id);
   CalcReq->Vehicles[0]->Franchise->Value = new TXSDecimal();
   if(di->franshize_id == 3){
      //CalcReq->Vehicles[0]->Franchise->Value = new TXSDecimal();
      CalcReq->Vehicles[0]->Franchise->UnitId = IntToStr(di->franshize_unit);
      CalcReq->Vehicles[0]->Franchise->Value->DecimalString = di->franshize_size;
   }
   else CalcReq->Vehicles[0]->Franchise->Value->DecimalString = null_str;

   CalcReq->Vehicles[0]->AlarmIds.Length = (vi->alarms[0] > 0 ? 1 : 0) + (vi->alarms[1] > 0 ? 1 : 0) + (vi->alarms[2] > 0 ? 1 : 0);
   for(int i = 0, j = 0; i < 3; ++i){
      if(vi->alarms[i] > 0){ CalcReq->Vehicles[0]->AlarmIds[j] = IntToStr(vi->alarms[i]); ++j; }
   }

   int nType = di->type_multydrive;
   //CalcReq->Vehicles[0]->AdmittedLimitId  = di->type_multydrive; // !!!!! // ��� ���������� � ���������� (���������� 7.3.67, Ref_AutoDictLimitedDrivers) (Vehicle.AdmittedLimitId): �������� �� ������� � �����������
   CalcReq->Vehicles[0]->AdmittedLimitId = (nType != 100) ? nType : 1; // !!!!! // ��� ������������ (���������� 7.3.28) (Insurant.SubjectTypeId): �������� �� ������� � �����������
   //---------------------------------------------------------------------------

   // ���������� ������
   if((nType == 1) || (nType == 100))
   {
      CalcReq->Vehicles[0]->Drivers.Length = di->count_permitted;
      for(int i = 0, j = 0; i < 16; ++i)
      {
         if(pm[i].permitted_check)
         {
            CalcReq->Vehicles[0]->Drivers[j] = new Driver();
            CalcReq->Vehicles[0]->Drivers[j]->Id = IntToStr(i + 1);

            CalcReq->Vehicles[0]->Drivers[j]->BirthDate = new TXSDateTime();
            CalcReq->Vehicles[0]->Drivers[j]->BirthDate->AsDateTime = pm[i].birthdate;
            CalcReq->Vehicles[0]->Drivers[j]->DrivingStartDate = new TXSDateTime();
            CalcReq->Vehicles[0]->Drivers[j]->DrivingStartDate->AsDateTime = pm[i].doc_issue_date;

            CalcReq->Vehicles[0]->Drivers[j]->GenderCode = IntToStr(pm[i].sex);
            CalcReq->Vehicles[0]->Drivers[j]->FullName = new PersonName();
            CalcReq->Vehicles[0]->Drivers[j]->FullName->LastName = pm[i].lastname;
            CalcReq->Vehicles[0]->Drivers[j]->FullName->FirstName = pm[i].firstname;
            CalcReq->Vehicles[0]->Drivers[j]->FullName->SecondName = pm[i].secondname;
            CalcReq->Vehicles[0]->Drivers[j]->DriverLicense = new DriverLicense;
            CalcReq->Vehicles[0]->Drivers[j]->DriverLicense->Type = AddNulls(pm[i].doc_type, 3);
            CalcReq->Vehicles[0]->Drivers[j]->DriverLicense->Series = StringReplace(pm[i].doc_seria, space_str, empty_str, rf);
            CalcReq->Vehicles[0]->Drivers[j]->DriverLicense->Number = pm[i].doc_number;
            ++j;
         }
      }
   }

   if(vi->devices_state_id == 2){ // tsi
      int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
      //TADOQuery *q_devices = m_api->dbGetCursor(res, "select * from kasko_devices_temp order by number_device");
      //TADOQuery *q_devices = m_api->dbGetCursor(res, "select * from casco_devices_r order by number");
      AnsiString sql("select * from casco_devices_r ");
      sql = sql + " where calc_id=" + IntToStr(calc_id);
      TADOQuery *q_devices = m_api->dbGetCursor(res, sql);

      CalcReq->Vehicles[0]->AddEquipments.Length = q_devices->RecordCount;
      for(q_devices->First(); !q_devices->Eof; q_devices->Next()){
         if(q_devices->FieldByName("cost_device")->AsFloat > 0){
            int index_d = q_devices->RecNo - 1;
            CalcReq->Vehicles[0]->AddEquipments[index_d] = new AddEquipmentRequest();
            //CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = q_devices->FieldByName("number_device")->AsString;
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = q_devices->FieldByName("number")->AsString;
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability = new TXSDecimal();
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability->DecimalString =
            FloatToSQLStr(q_devices->FieldByName("cost_device")->AsFloat /* * q_devices->FieldByName("count_device")->AsFloat*/ ); // ������ ����� ������������, ��� ����� ������ �������� ��������� ���������� �������� �� 1-�� �����
         }
      }
      m_api->dbCloseCursor(res, q_devices); //(*)

/*    if(q_devices->Eof)
      {
        //for(int i = 0, j = 0, cnt = gridAD->Items->Count; i < cnt; ++i)
        //  if(gridAD->Items->Item[i]->Checked)
        for(int i = 0, j = 0, cnt = FReissCalc->gridAD->Items->Count; i < cnt; ++i)
          if(FReissCalc->gridAD->Items->Item[i]->Checked)
          {
            int index_d = i;
            CalcReq->Vehicles[0]->AddEquipments[index_d] = new AddEquipmentRequest();
            //CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = q_devices->FieldByName("number_device")->AsString;
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = IntToStr(FReissCalc->getAdditionalDevice(i).id); //adevice[i].id; //j + 1; (number) // adevice[i].id; (id_device)
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability = new TXSDecimal();
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability->DecimalString = FloatToSQLStr(FReissCalc->getAdditionalDevice(i).cost); //adevice[i].cost); // ������ ����� ������������, ��� ����� ������ �������� ��������� ���������� �������� �� 1-�� �����
          }
      }
      else {}

      m_api->dbCloseCursor(res, q_devices); //(*)
//*/
   } // (vi->devices_state_id == 2)


   /*
   //if(FReissCalc->gridAD->Items->Count > 0)
   if(vi->devices_state_id == 2)
   {
      int calc_id = m_api->dbGet_Main_Grid_Current_CalcID(res);
      //TADOQuery *q_devices = m_api->dbGetCursor(res, "select * from kasko_devices_temp order by number_device");
      //TADOQuery *q_devices = m_api->dbGetCursor(res, "select * from casco_devices_r order by number");
       AnsiString sql("select * from casco_devices_r ");
       sql = sql + " where calc_id=" + IntToStr(calc_id);

      TADOQuery *q_devices = m_api->dbGetCursor(res, sql);
      CalcReq->Vehicles[0]->AddEquipments.Length = q_devices->RecordCount;

      if(q_devices->Eof)
      {
        //for(int i = 0, j = 0, cnt = gridAD->Items->Count; i < cnt; ++i)
        //  if(gridAD->Items->Item[i]->Checked)
        for(int i = 0, j = 0, cnt = FReissCalc->gridAD->Items->Count; i < cnt; ++i)
          if(FReissCalc->gridAD->Items->Item[i]->Checked)
          {
            int index_d = i;
            CalcReq->Vehicles[0]->AddEquipments[index_d] = new AddEquipmentRequest();
            //CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = q_devices->FieldByName("number_device")->AsString;
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = IntToStr(FReissCalc->getAdditionalDevice(i).id); //adevice[i].id; //j + 1; (number) // adevice[i].id; (id_device)
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability = new TXSDecimal();
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability->DecimalString = FloatToSQLStr(FReissCalc->getAdditionalDevice(i).cost); //adevice[i].cost); // ������ ����� ������������, ��� ����� ������ �������� ��������� ���������� �������� �� 1-�� �����
          }
      }
      else
      {
        for(q_devices->First(); !q_devices->Eof; q_devices->Next())
        {
          if(q_devices->FieldByName("cost_device")->AsFloat > 0)
          {
            int index_d = q_devices->RecNo - 1;
            CalcReq->Vehicles[0]->AddEquipments[index_d] = new AddEquipmentRequest();
            //CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = q_devices->FieldByName("number_device")->AsString;
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Id = q_devices->FieldByName("number")->AsString;
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability = new TXSDecimal();
            CalcReq->Vehicles[0]->AddEquipments[index_d]->Liability->DecimalString =
            FloatToSQLStr(q_devices->FieldByName("cost_device")->AsFloat ); // * q_devices->FieldByName("count_device")->AsFloat );
            // ������ ����� ������������, ��� ����� ������ �������� ��������� ���������� �������� �� 1-�� �����
          }
        }
      }

      m_api->dbCloseCursor(res, q_devices);
   }
   //*/

}
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfCalculation(OperationResultOfCalculationResultoTurZuT3 *ResultOfCalc)
{
   di->contract_id = ResultOfCalc->Data->ContractId;
   di->calculation_id = ResultOfCalc->Data->CalculationId;

   di->system_error = ResultOfCalc->ErrorMessage;
   for(int i = 0, cnt = ResultOfCalc->ValidationErrors.Length; i < cnt; ++i)
   {
     di->validations_errors->Add(ResultOfCalc->ValidationErrors[i]);
   }
   if(!ResultOfCalc->Data->VehicleResults.Length) return;

   // ������ � InsBridge
   for(int i = 0, len_ce = ResultOfCalc->Data->VehicleResults[0]->CalculationErrors.Length; i < len_ce; ++i) di->insbridge_errors->Add(ResultOfCalc->Data->VehicleResults[0]->CalculationErrors[i]);

   // ������� ������������
   int len_uwm = ResultOfCalc->Data->VehicleResults[0]->UwMessagesToAgent.Length;
   if(len_uwm){
      di->non_standart_str_calc->Add("����������� ������������. �������: ");
      for(int i = 0; i < len_uwm; ++i) di->non_standart_str_calc->Add(ResultOfCalc->Data->VehicleResults[0]->UwMessagesToAgent[i]);
      int len_reasons = ResultOfCalc->Data->VehicleResults[0]->UnderwritingRequirements->ReasonIds.Length;
      for(int i = 0; i < len_reasons; ++i) di->non_standart_str_id->Add(ResultOfCalc->Data->VehicleResults[0]->UnderwritingRequirements->ReasonIds[i]->DecimalString);
   }

   // �������� ��� �����������
   di->contract_type = ResultOfCalc->Data->VehicleResults[0]->IsRenewalContract ? 1 : 0;

   // ����� �������
   di->calc_info.type_of_calc = ResultOfCalc->Data->VehicleResults[0]->VehiclePremiumCalcType;

   // �����-��
   di->calc_info.bt  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->TB->DecimalString).ToDouble();
   di->calc_info.k1  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K1->DecimalString).ToDouble();
   di->calc_info.kd  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K1D->DecimalString).ToDouble();
   di->calc_info.k2  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K2->DecimalString).ToDouble();
   di->calc_info.k3  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K3->DecimalString).ToDouble();
   di->calc_info.k4  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K4->DecimalString).ToDouble();
   di->calc_info.k5  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K5->DecimalString).ToDouble();
   di->calc_info.k6  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K6->DecimalString).ToDouble();
   di->calc_info.k7  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->K7A->DecimalString).ToDouble();
   di->calc_info.kr  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KR->DecimalString).ToDouble();
   di->calc_info.kar = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KAR->DecimalString).ToDouble();
   di->calc_info.kb  = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KB->DecimalString).ToDouble();
   di->calc_info.kyu = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KY->DecimalString).ToDouble();
   di->calc_info.krs = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KRS->DecimalString).ToDouble();
   di->calc_info.kpr = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KPR->DecimalString).ToDouble();
   di->calc_info.kfr = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->KPRisk->DecimalString).ToDouble();

   di->calc_info.osn_risk_itog_tarif = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->K->Tariff->DecimalString).ToDouble();

   // ������
   di->calc_info.premiya_osn_risk = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->VehiclePremium->DecimalString).ToDouble();
   di->calc_info.premiya_dsago = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->DsagoVehiclePremium->DecimalString).ToDouble();
   di->calc_info.premiya_ns = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->AccidentPremium->DecimalString).ToDouble();
   di->calc_info.premiya_dms = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->DmsPremium->DecimalString).ToDouble();
   di->calc_info.premiya_all = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->KaskoTotal->DecimalString).ToDouble();

   AnsiString str___ = /*"new_premiya_osn_risk= " + FloatToStr(new_premiya_osn_risk) + " " +*/
	   "di->calc_info.osn_risk_itog_tarif= " + FloatToStr(di->calc_info.osn_risk_itog_tarif) + " " +
	   "bt= " + FloatToStr(m_api->Round(di->calc_info.bt)) + " " +					  //
	   "k1= " + FloatToStr(di->calc_info.k1)  + " " + //*
	   "kd= " +  FloatToStr(di->calc_info.kd)  + " " + //*
	   "k3= " + FloatToStr(di->calc_info.k3)  + " " + //*
	   "k4= " + FloatToStr(di->calc_info.k4)  + " " + //*
	   "k5= " + FloatToStr(di->calc_info.k5)  + " " + //*
	   "k7= " + FloatToStr(di->calc_info.k7)  + " " + //*
	   "kar= "+ FloatToStr(di->calc_info.kar)  + " " + //*
	   "kr= " +  FloatToStr(di->calc_info.kr)  + " " + //*
	   "ka= " +  FloatToStr(di->calc_info.ka)  + " " + //*
	   "k6= " +  FloatToStr(di->calc_info.k6)  + " " + //*
	   "ks= " +  FloatToStr(di->calc_info.ks)  + " " + //*
	   "krs= " + FloatToStr(di->calc_info.krs) + " " + //*
	   "kpr= " + FloatToStr(di->calc_info.kpr) + " " + //*
	   "kb= " +  FloatToStr(di->calc_info.kb) + " " + //*
	   "kfr= " + FloatToStr(di->calc_info.kfr);

   // �������
   if(di->contract_type)
   {
      di->bp_error_text = ResultOfCalc->Data->VehicleResults[0]->PrefProlongError;
      AnsiString VehiclePremiumPrefProlongation = ResultOfCalc->Data->VehicleResults[0]->VehiclePremiumPrefProlongation->DecimalString;
      try
      {
        long nPPPCoefLen = ResultOfCalc->Data->VehicleResults[0]->VehiclePremiumPrefProlCoeff->InstanceSize();

        if(nPPPCoefLen != 0)
        {
          AnsiString strPPPCoef = ResultOfCalc->Data->VehicleResults[0]->VehiclePremiumPrefProlCoeff->DecimalString;
          AnsiString strfloatPPPCoef = StrToFloatStr(strPPPCoef);
          double dblPPPCoef = strfloatPPPCoef.ToDouble();

          di->calc_info.kbfprlg =
          (di->bp_error_text.IsEmpty() && !VehiclePremiumPrefProlongation.IsEmpty())
            ? dblPPPCoef
            : 0.0;
        }
        else
        {
          di->calc_info.kbfprlg = 0.0;
        }
      }
      catch(Exception& ex)
      {
        AnsiString strException = ex.Message;
        //ShowMessageBox("","",0);
        di->calc_info.kbfprlg = 1;
      }

      di->calc_info.premiya_osn_risk_for_bp = di->bp_error_text.IsEmpty() ? StrToFloatStr(VehiclePremiumPrefProlongation).ToDouble() : 0.0;
   }

   // GAP
   if(vi->is_gap){
      di->calc_info.kgap = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->VehicleGapCoeff->DecimalString).ToDouble();
      di->calc_info.premiya_gap = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->KaskoVehicleGapPremium->DecimalString).ToDouble();
   }

   // ������� �� ������������
   pi[0].k6 = StrToFloatStr(ResultOfCalc->Data->InsurantK6->DecimalString).ToDouble();
   //pi[0].rsa_id = ResultOfCalc->Data->
   pi[0].dogovors["k5"].clear(); pi[0].dogovors["k6"].clear();
   for(int i = 0, dog_count = ResultOfCalc->Data->VehicleResults[0]->PrevContractIds.Length; i < dog_count; ++i){
      if(!ResultOfCalc->Data->VehicleResults[0]->PrevContractIds[i]->K5_ContractId.IsEmpty()) pi[0].dogovors["k5"].push_back(Dogovor(ResultOfCalc->Data->VehicleResults[0]->PrevContractIds[i]->K5_ContractId, ResultOfCalc->Data->VehicleResults[0]->PrevContractIds[i]->K5_SystemId));
      if(!ResultOfCalc->Data->VehicleResults[0]->PrevContractIds[i]->K6_ContractId.IsEmpty()) pi[0].dogovors["k6"].push_back(Dogovor(ResultOfCalc->Data->VehicleResults[0]->PrevContractIds[i]->K6_ContractId, ResultOfCalc->Data->VehicleResults[0]->PrevContractIds[i]->K6_SystemId));
   }

   // ����������
   double k6_max(0.0); di->index_max_k6 = -1;
   //if(di->type_multydrive == 1)
   if(di->type_multydrive == 1 || di->type_multydrive == 100)
   {
      for(int i = 0, prm_count = ResultOfCalc->Data->VehicleResults[0]->AdmitResults.Length; i < prm_count; ++i){
         int index = StrToInt(ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->DriverId) - 1;
         pm[index].k1 = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->K1Driver->DecimalString).ToDouble();
         pm[index].k6 = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->K6Driver->DecimalString).ToDouble();
         pm[index].rsa_id = ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->KbmRsaRequestId;
         pm[index].dogovors["k6"].clear();
         for(int j = 0, dog_count = ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->DriverPrevContracts.Length; j < dog_count; ++j)
            pm[i].dogovors["k6"].push_back(Dogovor(ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->DriverPrevContracts[j]->K6_ContractId, ResultOfCalc->Data->VehicleResults[0]->AdmitResults[i]->DriverPrevContracts[j]->K6_SystemId));

         if(pm[index].k6 > k6_max){
            k6_max = pm[index].k6;
            di->index_max_k6 = index;
         }
      }
   }

   // ������ �� ���������� ��������
   if(di->contract_type){
      di->last_polis_ed_incday = IncDay(ResultOfCalc->Data->VehicleResults[0]->PrevPolicy->EndDate->AsDateTime);
      di->last_contract = ResultOfCalc->Data->VehicleResults[0]->PrevPolicy->PolicyId;
      di->system = ResultOfCalc->Data->VehicleResults[0]->PrevPolicy->SystemId;
      di->prev_seria = ResultOfCalc->Data->VehicleResults[0]->PrevPolicy->Series;
      di->prev_number = ResultOfCalc->Data->VehicleResults[0]->PrevPolicy->Number;
   }

   vi->inspection_needed = ResultOfCalc->Data->VehicleResults[0]->InspectionNeeded;

   //
   // ������ ��������
   /*di->calc_info.payment_part[0] = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->Payment1->Value->DecimalString).ToDouble();
   di->payment_date[0] = ResultOfCalc->Data->VehicleResults[0]->Payment1->Date->AsDateTime;
   if(di->payments_count > 1){
      di->calc_info.payment_part[1] = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->Payment2->Value->DecimalString).ToDouble();
      di->payment_date[1] = ResultOfCalc->Data->VehicleResults[0]->Payment2->Date->AsDateTime;
   }
   if(di->payments_count > 2){
      di->calc_info.payment_part[2] = StrToFloatStr(ResultOfCalc->Data->VehicleResults[0]->Payment3->Value->DecimalString).ToDouble();
      di->payment_date[2] = ResultOfCalc->Data->VehicleResults[0]->Payment3->Date->AsDateTime;
   } */

   // �������������
   /*vi->alarms_terms->Clear();
   for(int i = 0, q  -`

   +alm_count = ResultOfCalc->Data->VehicleResults[0]->AlarmMessages.Length; i < alm_count; ++i)
      vi->alarms_terms->Add(ResultOfCalc->Data->VehicleResults[0]->AlarmMessages[i]);*/

   if(vi->devices_state_id == 2){
      for(int d = 0, cnt_dev = ResultOfCalc->Data->VehicleResults[0]->AddEquipments.Length; d < cnt_dev; ++d)
         m_api->dbExecuteQuery(res, "update kasko_devices_temp set premium_device=" + FloatToSQLStr(ResultOfCalc->Data->VehicleResults[0]->AddEquipments[d]->Premium->DecimalString) + " where number_device=" + AnsiString(ResultOfCalc->Data->VehicleResults[0]->AddEquipments[d]->Id));
   }
}
//---------------------------------------------------------------------------
/* #ifdef METHODS_FROM_KASKO_2UFO
//---------------------------------------------------------------------------
void ThreadUFO::FillPrintPolicyRequest(KaskoAutoProtectionRequest *PrintPolicyRequest)
//---------------------------------------------------------------------------
void ThreadUFO::FillPrintPolicySpecialRequest(KaskoFLSpecialRequest *PrintPolicySpecialRequest)
//---------------------------------------------------------------------------
void ThreadUFO::FillPrintCalculationSheet(CalculationSheet *PrintCalculationSheet)
//---------------------------------------------------------------------------
void ThreadUFO::GetPDF(OperationResultOfPrintResult1QqCV82X *resultOfPrint)
//---------------------------------------------------------------------------
void ThreadUFO::GetPDF(OperationResultOfArrayOfPrintResult1QqCV82X *ArrayResultOfPrint)
//---------------------------------------------------------------------------
void ThreadUFO::FillUnderwritingAdditionalInfo(UnderwritingAdditionalInfo *underInfo)
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfSendApprove(OperationResultOfContractStatusNamesmxVaabBO *resultOfSendApprove)
//---------------------------------------------------------------------------
void ThreadUFO::SelectionStatus(OperationResultOfQuotationStateInfooTurZuT3 *resultOfApprove)
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfApprove(OperationResultOfQuotationStateInfooTurZuT3 *resultOfApprove)
//---------------------------------------------------------------------------
void ThreadUFO::IsFieldVehicleChanged(const AnsiString& fieldname, const Variant& v, TStringList *what_change)
//---------------------------------------------------------------------------
void ThreadUFO::IsFieldCalcChanged(const AnsiString& fieldname, const Variant& v, TStringList *what_change)
//---------------------------------------------------------------------------
void ThreadUFO::IsFieldPolicyChanged(const AnsiString& fieldname, const Variant& v, TStringList *what_change)
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfguid(OperationResultOfguid *ResultOfguid)
//---------------------------------------------------------------------------
void ThreadUFO::FillInspectionDocumentInput(InspectionDocumentInput *document)
//---------------------------------------------------------------------------
void ThreadUFO::SelectFromOperationResultOfguid(OperationResultOfguid *ResultOfguid)
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfInspection(OperationResultOfArrayOfInspectionoTurZuT3 *resultOfInspection)
//---------------------------------------------------------------------------
void ThreadUFO::SelectionFromResultOfInspectionDocument(OperationResultOfInspectionDocumentoTurZuT3 *ResultOfInspectionDocument)
//---------------------------------------------------------------------------
#endif // METHODS_FROM_KASKO_2UFO
//*/
//---------------------------------------------------------------------------
int ThreadUFO::GetOffsetMin()
{
   TIME_ZONE_INFORMATION tzi;
   GetTimeZoneInformation(&tzi);
   return abs(tzi.Bias);
}
//---------------------------------------------------------------------------



