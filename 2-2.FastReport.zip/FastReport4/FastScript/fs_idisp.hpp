// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_idisp.pas' rev: 6.00

#ifndef fs_idispHPP
#define fs_idispHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <fs_iinterpreter.hpp>	// Pascal unit
#include <ComObj.hpp>	// Pascal unit
#include <ActiveX.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_idisp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsOLEHelper;
class PASCALIMPLEMENTATION TfsOLEHelper : public Fs_iinterpreter::TfsCustomHelper 
{
	typedef Fs_iinterpreter::TfsCustomHelper inherited;
	
private:
	Variant __fastcall DispatchInvoke(const Variant &ParamArray, int ParamCount, Word Flags);
	
protected:
	virtual void __fastcall SetValue(const Variant &Value);
	virtual Variant __fastcall GetValue();
	
public:
	__fastcall TfsOLEHelper(const AnsiString AName);
public:
	#pragma option push -w-inl
	/* TfsItemList.Destroy */ inline __fastcall virtual ~TfsOLEHelper(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_idisp */
using namespace Fs_idisp;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fs_idisp
