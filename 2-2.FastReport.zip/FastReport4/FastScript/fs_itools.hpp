// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_itools.pas' rev: 6.00

#ifndef fs_itoolsHPP
#define fs_itoolsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Windows.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <fs_xml.hpp>	// Pascal unit
#include <fs_iinterpreter.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_itools
{
//-- type declarations -------------------------------------------------------
typedef DynamicArray<System::TVarRec >  TVarRecArray;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall fsRegisterLanguage(const AnsiString Name, const AnsiString Grammar);
extern PACKAGE AnsiString __fastcall fsGetLanguage(const AnsiString Name);
extern PACKAGE void __fastcall fsGetLanguageList(Classes::TStrings* List);
extern PACKAGE Fs_iinterpreter::TfsVarType __fastcall StrToVarType(const AnsiString TypeName, Fs_iinterpreter::TfsScript* Script);
extern PACKAGE bool __fastcall TypesCompatible(const Fs_iinterpreter::TfsTypeRec &Typ1, const Fs_iinterpreter::TfsTypeRec &Typ2, Fs_iinterpreter::TfsScript* Script);
extern PACKAGE bool __fastcall AssignCompatible(Fs_iinterpreter::TfsCustomVariable* Var1, Fs_iinterpreter::TfsCustomVariable* Var2, Fs_iinterpreter::TfsScript* Script);
extern PACKAGE Variant __fastcall VarRecToVariant(const System::TVarRec &v);
extern PACKAGE void __fastcall VariantToVarRec(const Variant &v, TVarRecArray &ar);
extern PACKAGE void __fastcall ClearVarRec(TVarRecArray &ar);
extern PACKAGE Variant __fastcall ParserStringToVariant(AnsiString s);
extern PACKAGE Fs_iinterpreter::TfsCustomVariable* __fastcall ParseMethodSyntax(const AnsiString Syntax, Fs_iinterpreter::TfsScript* Script);
extern PACKAGE Types::TPoint __fastcall fsPosToPoint(const AnsiString ErrorPos);
extern PACKAGE void __fastcall GenerateXMLContents(Fs_iinterpreter::TfsScript* Prog, Fs_xml::TfsXMLItem* Item, bool FunctionsOnly = false);
extern PACKAGE void __fastcall GenerateMembers(Fs_iinterpreter::TfsScript* Prog, TMetaClass* cl, Fs_xml::TfsXMLItem* Item);

}	/* namespace Fs_itools */
using namespace Fs_itools;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fs_itools
