// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_idbrtti.pas' rev: 6.00

#ifndef fs_idbrttiHPP
#define fs_idbrttiHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <DB.hpp>	// Pascal unit
#include <fs_ievents.hpp>	// Pascal unit
#include <fs_iclassesrtti.hpp>	// Pascal unit
#include <fs_itools.hpp>	// Pascal unit
#include <fs_iinterpreter.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_idbrtti
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsDBRTTI;
class PASCALIMPLEMENTATION TfsDBRTTI : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfsDBRTTI(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfsDBRTTI(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfsDatasetNotifyEvent;
class PASCALIMPLEMENTATION TfsDatasetNotifyEvent : public Fs_iinterpreter::TfsCustomEvent 
{
	typedef Fs_iinterpreter::TfsCustomEvent inherited;
	
public:
	void __fastcall DoEvent(Db::TDataSet* Dataset);
	virtual void * __fastcall GetMethod(void);
public:
	#pragma option push -w-inl
	/* TfsCustomEvent.Create */ inline __fastcall virtual TfsDatasetNotifyEvent(System::TObject* AObject, Fs_iinterpreter::TfsProcVariable* AHandler) : Fs_iinterpreter::TfsCustomEvent(AObject, AHandler) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfsDatasetNotifyEvent(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfsFilterRecordEvent;
class PASCALIMPLEMENTATION TfsFilterRecordEvent : public Fs_iinterpreter::TfsCustomEvent 
{
	typedef Fs_iinterpreter::TfsCustomEvent inherited;
	
public:
	void __fastcall DoEvent(Db::TDataSet* DataSet, bool &Accept);
	virtual void * __fastcall GetMethod(void);
public:
	#pragma option push -w-inl
	/* TfsCustomEvent.Create */ inline __fastcall virtual TfsFilterRecordEvent(System::TObject* AObject, Fs_iinterpreter::TfsProcVariable* AHandler) : Fs_iinterpreter::TfsCustomEvent(AObject, AHandler) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfsFilterRecordEvent(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfsFieldGetTextEvent;
class PASCALIMPLEMENTATION TfsFieldGetTextEvent : public Fs_iinterpreter::TfsCustomEvent 
{
	typedef Fs_iinterpreter::TfsCustomEvent inherited;
	
public:
	void __fastcall DoEvent(Db::TField* Sender, AnsiString &Text, bool DisplayText);
	virtual void * __fastcall GetMethod(void);
public:
	#pragma option push -w-inl
	/* TfsCustomEvent.Create */ inline __fastcall virtual TfsFieldGetTextEvent(System::TObject* AObject, Fs_iinterpreter::TfsProcVariable* AHandler) : Fs_iinterpreter::TfsCustomEvent(AObject, AHandler) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfsFieldGetTextEvent(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_idbrtti */
using namespace Fs_idbrtti;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fs_idbrtti
