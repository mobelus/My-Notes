// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_iextctrlsrtti.pas' rev: 6.00

#ifndef fs_iextctrlsrttiHPP
#define fs_iextctrlsrttiHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ComCtrls.hpp>	// Pascal unit
#include <CheckLst.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <fs_iformsrtti.hpp>	// Pascal unit
#include <fs_ievents.hpp>	// Pascal unit
#include <fs_iinterpreter.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_iextctrlsrtti
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsExtCtrlsRTTI;
class PASCALIMPLEMENTATION TfsExtCtrlsRTTI : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfsExtCtrlsRTTI(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfsExtCtrlsRTTI(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_iextctrlsrtti */
using namespace Fs_iextctrlsrtti;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fs_iextctrlsrtti
