// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_iclassesrtti.pas' rev: 6.00

#ifndef fs_iclassesrttiHPP
#define fs_iclassesrttiHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <fs_xml.hpp>	// Pascal unit
#include <fs_iinterpreter.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_iclassesrtti
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsClassesRTTI;
class PASCALIMPLEMENTATION TfsClassesRTTI : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfsClassesRTTI(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfsClassesRTTI(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_iclassesrtti */
using namespace Fs_iclassesrtti;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fs_iclassesrtti
