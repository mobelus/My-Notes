// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fs_isysrtti.pas' rev: 6.00

#ifndef fs_isysrttiHPP
#define fs_isysrttiHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ComObj.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <MaskUtils.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <fs_itools.hpp>	// Pascal unit
#include <fs_iinterpreter.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_isysrtti
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsSysFunctions;
class PASCALIMPLEMENTATION TfsSysFunctions : public Fs_iinterpreter::TfsRTTIModule 
{
	typedef Fs_iinterpreter::TfsRTTIModule inherited;
	
private:
	AnsiString FCatConv;
	AnsiString FCatDate;
	AnsiString FCatFormat;
	AnsiString FCatMath;
	AnsiString FCatOther;
	AnsiString FCatStr;
	Variant __fastcall CallMethod1(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	Variant __fastcall CallMethod2(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	Variant __fastcall CallMethod3(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	Variant __fastcall CallMethod4(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	Variant __fastcall CallMethod5(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	Variant __fastcall CallMethod6(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	Variant __fastcall CallMethod7(System::TObject* Instance, TMetaClass* ClassType, const AnsiString MethodName, Fs_iinterpreter::TfsMethodHelper* Caller);
	
public:
	__fastcall virtual TfsSysFunctions(Fs_iinterpreter::TfsScript* AScript);
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfsSysFunctions(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_isysrtti */
using namespace Fs_isysrtti;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fs_isysrtti
