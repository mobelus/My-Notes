////////////////////////////////////////////////////////////
//
//  Translated By :  Sasan VM
//  Last update   :  13 Nov 2006
//  E-mail        :  sasan_vm@yahoo.com
//
//  This resource update for FastReport 4.0
//
//  FastReport is VCL base , VCL don't support unicode. If
//  you want edit this resource save it as simple text,
//  don't use unicode or utf-8.
//
//  For use this resouce change: Winodws|Language options|
//   |Advanced|Language for non-Unicode program .. to Farsi.
//
//  and enjoy it.
 
