// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerFormControls.pas' rev: 6.00

#ifndef frxServerFormControlsHPP
#define frxServerFormControlsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerTemplates.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <frxDCtrl.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverformcontrols
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxCustomWebControl;
class PASCALIMPLEMENTATION TfrxCustomWebControl : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TAlignment FAlignment;
	Graphics::TColor FColor;
	bool FEnabled;
	Graphics::TFont* FFont;
	Extended FHeight;
	Extended FLeft;
	AnsiString FName;
	bool FReadonly;
	int FTabindex;
	Extended FTop;
	Extended FWidth;
	bool FVisible;
	Frxservertemplates::TfrxServerTemplate* FTemplate;
	void __fastcall SetFont(Graphics::TFont* Value);
	
public:
	__fastcall virtual TfrxCustomWebControl(void);
	__fastcall virtual ~TfrxCustomWebControl(void);
	virtual AnsiString __fastcall Build(void) = 0 ;
	AnsiString __fastcall PadText(AnsiString s, int width);
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Name = {read=FName, write=FName};
	__property Extended Left = {read=FLeft, write=FLeft};
	__property Extended Top = {read=FTop, write=FTop};
	__property Extended Width = {read=FWidth, write=FWidth};
	__property Extended Height = {read=FHeight, write=FHeight};
	__property Graphics::TFont* Font = {read=FFont, write=SetFont};
	__property Graphics::TColor Color = {read=FColor, write=FColor, nodefault};
	__property Classes::TAlignment Alignment = {read=FAlignment, write=FAlignment, nodefault};
	__property bool Enabled = {read=FEnabled, write=FEnabled, nodefault};
	__property bool Readonly = {read=FReadonly, write=FReadonly, nodefault};
	__property int Tabindex = {read=FTabindex, write=FTabindex, nodefault};
	__property AnsiString HTML = {read=Build};
	__property bool Visible = {read=FVisible, write=FVisible, nodefault};
	__property Frxservertemplates::TfrxServerTemplate* Template = {read=FTemplate};
};


class DELPHICLASS TfrxWebLabelControl;
class PASCALIMPLEMENTATION TfrxWebLabelControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	AnsiString FCaption;
	
public:
	__fastcall virtual TfrxWebLabelControl(void);
	__fastcall virtual ~TfrxWebLabelControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Caption = {read=FCaption, write=FCaption};
};


class DELPHICLASS TfrxWebTextControl;
class PASCALIMPLEMENTATION TfrxWebTextControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	AnsiString FText;
	int FSize;
	int FMaxlength;
	bool FPassword;
	
public:
	__fastcall virtual TfrxWebTextControl(void);
	__fastcall virtual ~TfrxWebTextControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Text = {read=FText, write=FText};
	__property int Size = {read=FSize, write=FSize, nodefault};
	__property int Maxlength = {read=FMaxlength, write=FMaxlength, nodefault};
	__property bool Password = {read=FPassword, write=FPassword, nodefault};
};


class DELPHICLASS TfrxWebDateControl;
class PASCALIMPLEMENTATION TfrxWebDateControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	AnsiString FText;
	int FSize;
	int FMaxlength;
	
public:
	__fastcall virtual TfrxWebDateControl(void);
	__fastcall virtual ~TfrxWebDateControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Text = {read=FText, write=FText};
	__property int Size = {read=FSize, write=FSize, nodefault};
	__property int Maxlength = {read=FMaxlength, write=FMaxlength, nodefault};
};


class DELPHICLASS TfrxWebTextAreaControl;
class PASCALIMPLEMENTATION TfrxWebTextAreaControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	Classes::TStrings* FText;
	int FCols;
	int FRows;
	void __fastcall SetText(Classes::TStrings* Value);
	
public:
	__fastcall virtual TfrxWebTextAreaControl(void);
	__fastcall virtual ~TfrxWebTextAreaControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property Classes::TStrings* Text = {read=FText, write=SetText};
	__property int Cols = {read=FCols, write=FCols, nodefault};
	__property int Rows = {read=FRows, write=FRows, nodefault};
};


class DELPHICLASS TfrxWebCheckBoxControl;
class PASCALIMPLEMENTATION TfrxWebCheckBoxControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	AnsiString FCaption;
	bool FChecked;
	
public:
	__fastcall virtual TfrxWebCheckBoxControl(void);
	__fastcall virtual ~TfrxWebCheckBoxControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Caption = {read=FCaption, write=FCaption};
	__property bool Checked = {read=FChecked, write=FChecked, nodefault};
};


class DELPHICLASS TfrxWebRadioControl;
class PASCALIMPLEMENTATION TfrxWebRadioControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	AnsiString FCaption;
	bool FChecked;
	
public:
	__fastcall virtual TfrxWebRadioControl(void);
	__fastcall virtual ~TfrxWebRadioControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Caption = {read=FCaption, write=FCaption};
	__property bool Checked = {read=FChecked, write=FChecked, nodefault};
};


class DELPHICLASS TfrxWebSelectControl;
class PASCALIMPLEMENTATION TfrxWebSelectControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	Classes::TStrings* FItems;
	int FCheckedValue;
	void __fastcall SetItems(Classes::TStrings* Value);
	
public:
	__fastcall virtual TfrxWebSelectControl(void);
	__fastcall virtual ~TfrxWebSelectControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property Classes::TStrings* Items = {read=FItems, write=SetItems};
	__property int CheckedValue = {read=FCheckedValue, write=FCheckedValue, nodefault};
};


class DELPHICLASS TfrxWebSubmitControl;
class PASCALIMPLEMENTATION TfrxWebSubmitControl : public TfrxCustomWebControl 
{
	typedef TfrxCustomWebControl inherited;
	
private:
	AnsiString FCaption;
	
public:
	__fastcall virtual TfrxWebSubmitControl(void);
	__fastcall virtual ~TfrxWebSubmitControl(void);
	virtual AnsiString __fastcall Build();
	virtual void __fastcall Assign(Frxclass::TfrxDialogControl* Value);
	__property AnsiString Caption = {read=FCaption, write=FCaption};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxserverformcontrols */
using namespace Frxserverformcontrols;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerFormControls
