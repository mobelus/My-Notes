// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'rc_Crypt.pas' rev: 6.00

#ifndef rc_CryptHPP
#define rc_CryptHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <rc_ApiRef.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rc_crypt
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
static const Byte _KEYLength = 0x80;
extern PACKAGE AnsiString __fastcall ExpandKey(AnsiString sKey, int iLength);
extern PACKAGE AnsiString __fastcall EnCryptString(const AnsiString sMessage, AnsiString sKeyMaterial);
extern PACKAGE AnsiString __fastcall DeCryptString(const AnsiString sMessage, AnsiString sKeyMaterial);

}	/* namespace Rc_crypt */
using namespace Rc_crypt;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// rc_Crypt
