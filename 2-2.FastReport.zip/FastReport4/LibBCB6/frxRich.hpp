// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxRich.pas' rev: 6.00

#ifndef frxRichHPP
#define frxRichHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Controls.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <frxPrinter.hpp>	// Pascal unit
#include <frxRichEdit.hpp>	// Pascal unit
#include <RichEdit.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxrich
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxRichObject;
class PASCALIMPLEMENTATION TfrxRichObject : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfrxRichObject(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxRichObject(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxRichView;
class PASCALIMPLEMENTATION TfrxRichView : public Frxclass::TfrxStretcheable 
{
	typedef Frxclass::TfrxStretcheable inherited;
	
private:
	bool FAllowExpressions;
	AnsiString FExpressionDelimiters;
	TfrxRichView* FFlowTo;
	Extended FGapX;
	Extended FGapY;
	bool FParaBreak;
	Frxrichedit::TRxRichEdit* FRichEdit;
	Classes::TMemoryStream* FTempStream;
	Classes::TMemoryStream* FTempStream1;
	bool FWysiwyg;
	bool FHasNextDataPart;
	Graphics::TMetafile* __fastcall CreateMetafile(void);
	bool __fastcall IsExprDelimitersStored(void);
	bool __fastcall UsePrinterCanvas(void);
	void __fastcall ReadData(Classes::TStream* Stream);
	void __fastcall WriteData(Classes::TStream* Stream);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TfrxRichView(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxRichView(void);
	virtual void __fastcall Draw(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	virtual void __fastcall AfterPrint(void);
	virtual void __fastcall BeforePrint(void);
	virtual void __fastcall GetData(void);
	virtual void __fastcall InitPart(void);
	virtual Extended __fastcall CalcHeight(void);
	virtual Extended __fastcall DrawPart(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual AnsiString __fastcall GetComponentText();
	virtual bool __fastcall HasNextDataPart(void);
	__property Frxrichedit::TRxRichEdit* RichEdit = {read=FRichEdit};
	
__published:
	__property bool AllowExpressions = {read=FAllowExpressions, write=FAllowExpressions, default=1};
	__property BrushStyle  = {default=0};
	__property Color  = {default=536870911};
	__property Cursor  = {default=0};
	__property DataField ;
	__property DataSet ;
	__property DataSetName ;
	__property AnsiString ExpressionDelimiters = {read=FExpressionDelimiters, write=FExpressionDelimiters, stored=IsExprDelimitersStored};
	__property TfrxRichView* FlowTo = {read=FFlowTo, write=FFlowTo};
	__property Frame ;
	__property Extended GapX = {read=FGapX, write=FGapX};
	__property Extended GapY = {read=FGapY, write=FGapY};
	__property TagStr ;
	__property URL ;
	__property bool Wysiwyg = {read=FWysiwyg, write=FWysiwyg, default=1};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxRichView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxStretcheable(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall frxAssignRich(Frxrichedit::TRxRichEdit* RichFrom, Frxrichedit::TRxRichEdit* RichTo);

}	/* namespace Frxrich */
using namespace Frxrich;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxRich
