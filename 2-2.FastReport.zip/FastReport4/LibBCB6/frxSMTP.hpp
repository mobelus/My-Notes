// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxSMTP.pas' rev: 6.00

#ifndef frxSMTPHPP
#define frxSMTPHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxmd5.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <frxProgress.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <ScktComp.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxsmtp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxSMTPClient;
class DELPHICLASS TfrxSMTPClientThread;
class PASCALIMPLEMENTATION TfrxSMTPClientThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
protected:
	TfrxSMTPClient* FClient;
	void __fastcall DoOpen(void);
	virtual void __fastcall Execute(void);
	
public:
	Scktcomp::TClientSocket* FSocket;
	__fastcall TfrxSMTPClientThread(TfrxSMTPClient* Client);
	__fastcall virtual ~TfrxSMTPClientThread(void);
};


class PASCALIMPLEMENTATION TfrxSMTPClient : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	bool FActive;
	bool FBreaked;
	Classes::TStrings* FErrors;
	AnsiString FHost;
	int FPort;
	TfrxSMTPClientThread* FThread;
	int FTimeOut;
	AnsiString FPassword;
	WideString FMailTo;
	AnsiString FUser;
	Classes::TStringList* FMailFiles;
	WideString FMailFrom;
	WideString FMailSubject;
	WideString FMailText;
	AnsiString FAnswer;
	bool FAccepted;
	AnsiString FAuth;
	int FCode;
	bool FSending;
	Frxprogress::TfrxProgress* FProgress;
	bool FShowProgress;
	AnsiString FLogFile;
	Classes::TStringList* FLog;
	Classes::TStringList* FAnswerList;
	bool F200Flag;
	bool F210Flag;
	bool F215Flag;
	WideString FOrganization;
	WideString FMailCc;
	WideString FMailBcc;
	Classes::TStringList* FRcptList;
	bool FConfirmReading;
	void __fastcall DoConnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoDisconnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoError(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket, Scktcomp::TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall DoRead(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall SetActive(const bool Value);
	void __fastcall AddLogIn(const AnsiString s);
	void __fastcall AddLogOut(const AnsiString s);
	AnsiString __fastcall DomainByEmail(const AnsiString addr);
	AnsiString __fastcall UnicodeField(const WideString Str);
	AnsiString __fastcall UnicodeString(const WideString Str);
	AnsiString __fastcall GetEmailAddress(const AnsiString Str);
	void __fastcall PrepareRcpt(void);
	
public:
	__fastcall virtual TfrxSMTPClient(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxSMTPClient(void);
	void __fastcall Connect(void);
	void __fastcall Disconnect(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	__property bool Breaked = {read=FBreaked, nodefault};
	__property Classes::TStrings* Errors = {read=FErrors, write=FErrors};
	__property AnsiString LogFile = {read=FLogFile, write=FLogFile};
	
__published:
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property AnsiString Host = {read=FHost, write=FHost};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, nodefault};
	__property AnsiString User = {read=FUser, write=FUser};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property WideString MailFrom = {read=FMailFrom, write=FMailFrom};
	__property WideString MailTo = {read=FMailTo, write=FMailTo};
	__property WideString MailCc = {read=FMailCc, write=FMailCc};
	__property WideString MailBcc = {read=FMailBcc, write=FMailBcc};
	__property WideString MailSubject = {read=FMailSubject, write=FMailSubject};
	__property WideString MailText = {read=FMailText, write=FMailText};
	__property Classes::TStringList* MailFiles = {read=FMailFiles, write=FMailFiles};
	__property bool ShowProgress = {read=FShowProgress, write=FShowProgress, nodefault};
	__property WideString Organization = {read=FOrganization, write=FOrganization};
	__property bool ConfirmReading = {read=FConfirmReading, write=FConfirmReading, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxsmtp */
using namespace Frxsmtp;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxSMTP
