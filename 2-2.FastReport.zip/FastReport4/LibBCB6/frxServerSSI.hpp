// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerSSI.pas' rev: 6.00

#ifndef frxServerSSIHPP
#define frxServerSSIHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerVariables.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverssi
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxSSIStream;
class PASCALIMPLEMENTATION TfrxSSIStream : public Classes::TMemoryStream 
{
	typedef Classes::TMemoryStream inherited;
	
private:
	AnsiString FBasePath;
	Classes::TMemoryStream* FTempStream;
	Frxservervariables::TfrxServerVariables* FVariables;
	Frxservervariables::TfrxServerVariables* FLocalVariables;
	AnsiString __fastcall ParseVarName(int VarPos, int VarLen, char * Src);
	int __fastcall SearchSign(const AnsiString Sign, char * Src, int StartPos, int Len);
	
public:
	__fastcall TfrxSSIStream(void);
	__fastcall virtual ~TfrxSSIStream(void);
	void __fastcall Prepare(void);
	__property AnsiString BasePath = {read=FBasePath, write=FBasePath};
	__property Frxservervariables::TfrxServerVariables* Variables = {read=FVariables, write=FVariables};
	__property Frxservervariables::TfrxServerVariables* LocalVariables = {read=FLocalVariables, write=FLocalVariables};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxserverssi */
using namespace Frxserverssi;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerSSI
