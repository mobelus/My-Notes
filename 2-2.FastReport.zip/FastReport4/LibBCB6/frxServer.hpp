// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServer.pas' rev: 6.00

#ifndef frxServerHPP
#define frxServerHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerPrinter.hpp>	// Pascal unit
#include <frxServerTemplates.hpp>	// Pascal unit
#include <frxServerConfig.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <frxServerClient.hpp>	// Pascal unit
#include <frxusers.hpp>	// Pascal unit
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxServerReportsList.hpp>	// Pascal unit
#include <frxServerCache.hpp>	// Pascal unit
#include <frxmd5.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxServerSSI.hpp>	// Pascal unit
#include <frxServerVariables.hpp>	// Pascal unit
#include <frxServerReports.hpp>	// Pascal unit
#include <frxServerStat.hpp>	// Pascal unit
#include <frxServerSessionManager.hpp>	// Pascal unit
#include <frxServerLog.hpp>	// Pascal unit
#include <frxGZip.hpp>	// Pascal unit
#include <frxVariables.hpp>	// Pascal unit
#include <WinSock.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <ScktComp.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserver
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TfrxServerGetReportEvent)(const AnsiString ReportName, Frxclass::TfrxReport* Report, AnsiString User = "");

typedef void __fastcall (__closure *TfrxServerGetVariablesEvent)(const AnsiString ReportName, Frxvariables::TfrxVariables* Variables, AnsiString User = "");

typedef void __fastcall (__closure *TfrxServerAfterBuildReport)(const AnsiString ReportName, Frxvariables::TfrxVariables* Variables, AnsiString User = "");

struct TSecHandle;
typedef TSecHandle *PSecHandle;

#pragma pack(push, 4)
struct TSecHandle
{
	unsigned dwLower;
	unsigned dwUpper;
} ;
#pragma pack(pop)

typedef TSecHandle  TCredHandle;

typedef TSecHandle *PCredHandle;

typedef TSecHandle *PCtxtHandle;

typedef TSecHandle  TCtxtHandle;

struct TSecBuffer;
typedef TSecBuffer *PSecBuffer;

#pragma pack(push, 4)
struct TSecBuffer
{
	unsigned cbBuffer;
	unsigned BufferType;
	void *pvBuffer;
} ;
#pragma pack(pop)

struct TSecBufferDesc;
typedef TSecBufferDesc *PSecBufferDesc;

#pragma pack(push, 4)
struct TSecBufferDesc
{
	unsigned ulVersion;
	unsigned cBuffers;
	TSecBuffer *pBuffers;
} ;
#pragma pack(pop)

typedef System::Currency *PTimeStamp;

typedef System::Currency TTimeStamp;

struct TSecPkgInfo;
typedef TSecPkgInfo *PSecPkgInfo;

#pragma pack(push, 4)
struct TSecPkgInfo
{
	unsigned fCapabilities;
	Word wVersion;
	Word wRPCID;
	unsigned cbMaxToken;
	char *Name;
	char *Comment;
} ;
#pragma pack(pop)

class DELPHICLASS TfrxReportServer;
class DELPHICLASS TfrxHTTPServer;
class PASCALIMPLEMENTATION TfrxHTTPServer : public Scktcomp::TServerSocket 
{
	typedef Scktcomp::TServerSocket inherited;
	
private:
	AnsiString FBasePath;
	bool FGzip;
	AnsiString FMainDocument;
	bool FNoCacheHeader;
	TfrxReportServer* FParentReportServer;
	AnsiString FReportPath;
	int FSocketTimeOut;
	void __fastcall ClientAccept(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall ClientDisconnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall ClientError(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket, Scktcomp::TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall GetThread(System::TObject* Sender, Scktcomp::TServerClientWinSocket* ClientSocket, Scktcomp::TServerClientThread* &SocketThread);
	
public:
	__fastcall virtual TfrxHTTPServer(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxHTTPServer(void);
	
__published:
	__property AnsiString BasePath = {read=FBasePath, write=FBasePath};
	__property bool Gzip = {read=FGzip, write=FGzip, nodefault};
	__property AnsiString MainDocument = {read=FMainDocument, write=FMainDocument};
	__property bool NoCacheHeader = {read=FNoCacheHeader, write=FNoCacheHeader, nodefault};
	__property TfrxReportServer* ParentReportServer = {read=FParentReportServer, write=FParentReportServer};
	__property AnsiString ReportPath = {read=FReportPath, write=FReportPath};
	__property int SocketTimeOut = {read=FSocketTimeOut, write=FSocketTimeOut, nodefault};
};


class DELPHICLASS TfrxServerGuard;
class PASCALIMPLEMENTATION TfrxServerGuard : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	int FTimeOut;
	TfrxReportServer* FServer;
	int FListTimeOut;
	void __fastcall DoLoadConf(void);
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TfrxServerGuard(TfrxReportServer* Server);
	__fastcall virtual ~TfrxServerGuard(void);
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, nodefault};
	__property int ListTimeOut = {read=FListTimeOut, write=FListTimeOut, nodefault};
};


class DELPHICLASS TfrxServerData;
class PASCALIMPLEMENTATION TfrxReportServer : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	bool FActive;
	Classes::TStrings* FAllow;
	Frxserverconfig::TfrxServerConfig* FConfig;
	Classes::TStrings* FDeny;
	TfrxServerGetReportEvent FGetReport;
	bool FPDFPrint;
	Classes::TStrings* FTotals;
	Frxservervariables::TfrxServerVariables* FVariables;
	TfrxHTTPServer* FWebServer;
	TfrxServerGetVariablesEvent FGetVariables;
	TfrxServerAfterBuildReport FBuildReport;
	bool FSocketOpen;
	AnsiString FConfigFileName;
	TfrxServerGuard* FGuard;
	bool FPrint;
	Classes::TStrings* __fastcall GetTotals(void);
	void __fastcall SetActive(const bool Value);
	void __fastcall SetConfig(const Frxserverconfig::TfrxServerConfig* Value);
	void __fastcall StatToVar(void);
	void __fastcall Initialize(void);
	
public:
	__fastcall virtual TfrxReportServer(Classes::TComponent* AOwner);
	__fastcall TfrxReportServer(const AnsiString Folder, const bool Socket);
	__fastcall virtual ~TfrxReportServer(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	void __fastcall Get(TfrxServerData* Data);
	void __fastcall LoadConfigs(void);
	__property Classes::TStrings* Totals = {read=GetTotals};
	__property Frxservervariables::TfrxServerVariables* Variables = {read=FVariables};
	
__published:
	__property Frxserverconfig::TfrxServerConfig* Configuration = {read=FConfig, write=SetConfig};
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property Classes::TStrings* AllowIP = {read=FAllow, write=FAllow};
	__property Classes::TStrings* DenyIP = {read=FDeny, write=FDeny};
	__property bool PrintPDF = {read=FPDFPrint, write=FPDFPrint, nodefault};
	__property bool Print = {read=FPrint, write=FPrint, nodefault};
	__property TfrxServerGetReportEvent OnGetReport = {read=FGetReport, write=FGetReport};
	__property TfrxServerGetVariablesEvent OnGetVariables = {read=FGetVariables, write=FGetVariables};
	__property TfrxServerAfterBuildReport OnAfterBuildReport = {read=FBuildReport, write=FBuildReport};
	__property bool SocketOpen = {read=FSocketOpen, write=FSocketOpen, nodefault};
	__property TfrxHTTPServer* WebServer = {read=FWebServer};
};


class DELPHICLASS TfrxServerSession;
class PASCALIMPLEMENTATION TfrxServerSession : public Scktcomp::TServerClientThread 
{
	typedef Scktcomp::TServerClientThread inherited;
	
private:
	bool FAuthNeeded;
	bool FDialog;
	AnsiString FDialogSessionId;
	int FErrorCode;
	AnsiString FErrorText;
	Frxserverutils::TfrxServerFormat FFormat;
	bool FGzip;
	AnsiString FHeader;
	AnsiString FHost;
	AnsiString FHTTPVersion;
	bool FIsReport;
	bool FKeepAlive;
	AnsiString FMethod;
	AnsiString FMIMEType;
	bool FMultipage;
	AnsiString FName;
	AnsiString FGroup;
	bool FNoCacheHeader;
	bool FPageNavigator;
	AnsiString FPageRange;
	TfrxHTTPServer* FParentHTTPServer;
	TfrxReportServer* FParentReportServer;
	bool FRedirect;
	AnsiString FReferer;
	AnsiString FRemoteIP;
	Classes::TStringList* FReplyBody;
	Classes::TStringList* FReplyHeader;
	Frxserverreports::TfrxReportSession* FRepSession;
	AnsiString FResultPage;
	Classes::TStringList* FServerReplyData;
	AnsiString FSessionId;
	Frxserversessionmanager::TfrxSessionItem* FSessionItem;
	int FSize;
	AnsiString FUserAgent;
	Frxvariables::TfrxVariables* FVariables;
	Classes::TMemoryStream* FStream;
	System::TDateTime FFileDate;
	AnsiString FCacheId;
	AnsiString FPrn;
	bool FBrowserPrn;
	AnsiString FLogin;
	AnsiString FCookie;
	AnsiString FPassword;
	AnsiString FReportMessage;
	AnsiString FReturnData;
	Classes::TStringList* FInParams;
	Classes::TStringList* FOutParams;
	TfrxServerData* FData;
	bool FActive;
	bool FAuthInProgress;
	AnsiString FAuthResponse;
	bool FAuthFinished;
	bool FAuthNewConv;
	int FMaxTokenSize;
	TSecHandle FCredHandle;
	System::Currency FExpire;
	unsigned FToken;
	TSecHandle FContextHandle;
	AnsiString FAuthType;
	Frxservervariables::TfrxServerVariables* FLocalVariables;
	bool __fastcall InitAuth(const AnsiString SecPackageName);
	bool __fastcall ProcessAuthRequest(AnsiString AuthRequest, bool NewConversation, AnsiString &AuthResponse, TSecHandle &ContextHandle, bool &AuthFinished);
	void __fastcall FinalAuth(void);
	unsigned __fastcall GetCurrentUserToken(void);
	bool __fastcall CheckBadPath(void);
	bool __fastcall CheckDeflate(AnsiString FileName);
	bool __fastcall CheckSSI(AnsiString FileName);
	AnsiString __fastcall ParseHeaderField(AnsiString Field);
	AnsiString __fastcall ParseParam(AnsiString S);
	AnsiString __fastcall GetMime(AnsiString s);
	void __fastcall CheckAuth(void);
	void __fastcall CloseSession(void);
	void __fastcall CreateReplyHTTPData(void);
	void __fastcall ErrorLog(void);
	void __fastcall MakeServerReply(void);
	void __fastcall ParseHTTPHeader(void);
	void __fastcall UpdateLocalVariables(void);
	void __fastcall UpdateSessionFName(void);
	void __fastcall WriteLogs(void);
	void __fastcall DoGetVariables(void);
	void __fastcall AddOutData(const AnsiString Name, const AnsiString Value);
	
public:
	__fastcall TfrxServerSession(bool CreateSuspended, Scktcomp::TServerClientWinSocket* ASocket);
	__fastcall virtual ~TfrxServerSession(void);
	virtual void __fastcall ClientExecute(void);
	void __fastcall PrepareReportQuery(void);
	__property bool NoCacheHeader = {read=FNoCacheHeader, write=FNoCacheHeader, nodefault};
	__property TfrxHTTPServer* ParentHTTPServer = {read=FParentHTTPServer, write=FParentHTTPServer};
	__property TfrxReportServer* ParentReportServer = {read=FParentReportServer, write=FParentReportServer};
	__property AnsiString SessionId = {read=FSessionId, write=FSessionId};
	__property Frxserversessionmanager::TfrxSessionItem* SessionItem = {read=FSessionItem, write=FSessionItem};
	__property AnsiString Login = {read=FLogin};
	__property AnsiString Password = {read=FPassword};
	__property TfrxServerData* Data = {read=FData, write=FData};
	__property bool Active = {read=FActive, write=FActive, nodefault};
	__property Frxservervariables::TfrxServerVariables* LocalVariables = {read=FLocalVariables};
};


class PASCALIMPLEMENTATION TfrxServerData : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	int FErrorCode;
	Classes::TStringList* FInParams;
	Classes::TStringList* FOutParams;
	Classes::TMemoryStream* FStream;
	AnsiString FFileName;
	AnsiString FHeader;
	AnsiString FRepHeader;
	AnsiString FHTTPVer;
	System::TDateTime FLastMod;
	System::TDateTime FExpires;
	
public:
	__fastcall TfrxServerData(void);
	__fastcall virtual ~TfrxServerData(void);
	void __fastcall Assign(TfrxServerData* Source);
	__property Classes::TStringList* InParams = {read=FInParams};
	__property Classes::TStringList* OutParams = {read=FOutParams};
	__property int ErrorCode = {read=FErrorCode, write=FErrorCode, nodefault};
	__property Classes::TMemoryStream* Stream = {read=FStream};
	__property AnsiString FileName = {read=FFileName, write=FFileName};
	__property AnsiString Header = {read=FHeader, write=FHeader};
	__property AnsiString RepHeader = {read=FRepHeader, write=FRepHeader};
	__property AnsiString HTTPVer = {read=FHTTPVer, write=FHTTPVer};
	__property System::TDateTime Expires = {read=FExpires, write=FExpires};
	__property System::TDateTime LastMod = {read=FLastMod, write=FLastMod};
};


//-- var, const, procedure ---------------------------------------------------
static const Word MAX_IE_GZIP = 0x1000;
#define SERVER_NAME "FastReport Server"
#define SERVER_VERSION "2.3.0"
#define SERVER_DATA ""
#define SID_SIGN "sid_f"

}	/* namespace Frxserver */
using namespace Frxserver;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServer
