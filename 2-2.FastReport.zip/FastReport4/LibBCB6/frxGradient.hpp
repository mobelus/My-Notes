// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxGradient.pas' rev: 6.00

#ifndef frxGradientHPP
#define frxGradientHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxgradient
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxGradientObject;
class PASCALIMPLEMENTATION TfrxGradientObject : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfrxGradientObject(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxGradientObject(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TfrxGradientStyle { gsHorizontal, gsVertical, gsElliptic, gsRectangle, gsVertCenter, gsHorizCenter };
#pragma option pop

class DELPHICLASS TfrxGradientView;
class PASCALIMPLEMENTATION TfrxGradientView : public Frxclass::TfrxView 
{
	typedef Frxclass::TfrxView inherited;
	
private:
	Graphics::TColor FBeginColor;
	Graphics::TColor FEndColor;
	TfrxGradientStyle FStyle;
	void __fastcall DrawGradient(int X, int Y, int X1, int Y1);
	Graphics::TColor __fastcall GetColor(void);
	void __fastcall SetColor(const Graphics::TColor Value);
	
public:
	__fastcall virtual TfrxGradientView(Classes::TComponent* AOwner);
	virtual void __fastcall Draw(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	
__published:
	__property Graphics::TColor BeginColor = {read=FBeginColor, write=FBeginColor, default=16777215};
	__property Graphics::TColor EndColor = {read=FEndColor, write=FEndColor, default=8421504};
	__property TfrxGradientStyle Style = {read=FStyle, write=FStyle, nodefault};
	__property Frame ;
	__property Graphics::TColor Color = {read=GetColor, write=SetColor, nodefault};
public:
	#pragma option push -w-inl
	/* TfrxView.Destroy */ inline __fastcall virtual ~TfrxGradientView(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxGradientView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxView(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxgradient */
using namespace Frxgradient;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxGradient
