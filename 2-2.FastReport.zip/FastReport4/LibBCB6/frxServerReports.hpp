// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerReports.pas' rev: 6.00

#ifndef frxServerReportsHPP
#define frxServerReportsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerTemplates.hpp>	// Pascal unit
#include <ActiveX.hpp>	// Pascal unit
#include <frxServerPrinter.hpp>	// Pascal unit
#include <frxExportODF.hpp>	// Pascal unit
#include <frxServerLog.hpp>	// Pascal unit
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxDCtrl.hpp>	// Pascal unit
#include <frxServerCache.hpp>	// Pascal unit
#include <frxServerForms.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <frxVariables.hpp>	// Pascal unit
#include <frxExportImage.hpp>	// Pascal unit
#include <frxExportXML.hpp>	// Pascal unit
#include <frxExportPDF.hpp>	// Pascal unit
#include <frxExportCSV.hpp>	// Pascal unit
#include <frxExportText.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <frxExportRTF.hpp>	// Pascal unit
#include <frxExportHTML.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverreports
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxReportSession;
class PASCALIMPLEMENTATION TfrxReportSession : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	AnsiString FPath;
	AnsiString FBasePath;
	AnsiString FSessionId;
	AnsiString FReportPath;
	AnsiString FPageRange;
	Frxserverutils::TfrxServerFormat FFormat;
	AnsiString FMainDocument;
	AnsiString FName;
	Frxvariables::TfrxVariables* FVariables;
	bool FReportErrors;
	AnsiString FError;
	AnsiString FResultPage;
	Frxclass::TfrxReport* FReport;
	Frxexporthtml::TfrxHTMLExport* FHTMLExport;
	Frxexportxml::TfrxXMLExport* FXMLExport;
	Frxexportrtf::TfrxRTFExport* FRTFExport;
	Frxexporttext::TfrxSimpleTextExport* FTXTExport;
	Frxexportimage::TfrxJPEGExport* FJPGExport;
	Frxexportimage::TfrxBMPExport* FBMPExport;
	Frxexportimage::TfrxGIFExport* FGIFExport;
	Frxexportimage::TfrxTIFFExport* FTIFFExport;
	Frxexportpdf::TfrxPDFExport* FPDFExport;
	Frxexportcsv::TfrxCSVExport* FCSVExport;
	Frxexportodf::TfrxODSExport* FODSExport;
	Frxexportodf::TfrxODTExport* FODTExport;
	Classes::TThread* FParentThread;
	Frxclass::TfrxDialogPage* CurPage;
	Classes::TComponent* FParentReportServer;
	bool FCached;
	bool FNativeClient;
	Classes::TMemoryStream* FStream;
	AnsiString FCacheId;
	AnsiString FPassword;
	bool FAuth;
	AnsiString FMessage;
	bool FPageNav;
	bool FMultipage;
	AnsiString FUserLogin;
	AnsiString FUserGroup;
	AnsiString FAvExports;
	AnsiString Fvarstr;
	AnsiString FMime;
	bool FPrint;
	void __fastcall DoError(void);
	void __fastcall DoFillForm(void);
	void __fastcall DoSaveForm(void);
	void __fastcall ShowReportDialog(Frxclass::TfrxDialogPage* Page);
	void __fastcall DoAfterBuildReport(void);
	AnsiString __fastcall ExtractReportName(const AnsiString FileName);
	void __fastcall SetNavTemplate(const AnsiString ReportName, bool Multipage, bool PicsInSameFolder, AnsiString Prefix, int TotalPages, AnsiString &Template);
	void __fastcall SetMainTemplate(const AnsiString Title, const AnsiString FrameFolder, bool Multipage, AnsiString &Template);
	AnsiString __fastcall GetResultFileName(const AnsiString ext);
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	bool Active;
	bool Continue;
	bool DialogActive;
	bool Readed;
	__fastcall TfrxReportSession(void);
	__fastcall virtual ~TfrxReportSession(void);
	__property AnsiString FileName = {read=FName, write=FName};
	__property Frxserverutils::TfrxServerFormat Format = {read=FFormat, write=FFormat, nodefault};
	__property AnsiString IndexFileName = {read=FMainDocument, write=FMainDocument};
	__property AnsiString PageRange = {read=FPageRange, write=FPageRange};
	__property Classes::TThread* ParentThread = {read=FParentThread, write=FParentThread};
	__property AnsiString ReportPath = {read=FReportPath, write=FReportPath};
	__property AnsiString ResultPage = {read=FResultPage};
	__property AnsiString RootPath = {read=FBasePath, write=FBasePath};
	__property AnsiString SessionId = {read=FSessionId, write=FSessionId};
	__property AnsiString CacheId = {read=FCacheId, write=FCacheId};
	__property Frxvariables::TfrxVariables* Variables = {read=FVariables, write=FVariables};
	__property Classes::TComponent* ParentReportServer = {read=FParentReportServer, write=FParentReportServer};
	__property bool NativeClient = {read=FNativeClient, write=FNativeClient, nodefault};
	__property Classes::TMemoryStream* Stream = {read=FStream, write=FStream};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property bool Auth = {read=FAuth, nodefault};
	__property AnsiString ReportMessage = {read=FMessage};
	__property bool PageNav = {read=FPageNav, write=FPageNav, nodefault};
	__property bool Multipage = {read=FMultipage, write=FMultipage, nodefault};
	__property AnsiString UserLogin = {read=FUserLogin, write=FUserLogin};
	__property AnsiString UserGroup = {read=FUserGroup, write=FUserGroup};
	__property AnsiString Mime = {read=FMime};
	__property bool Print = {read=FPrint, write=FPrint, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxserverreports */
using namespace Frxserverreports;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerReports
