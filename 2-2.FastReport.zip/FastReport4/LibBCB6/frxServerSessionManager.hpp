// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerSessionManager.pas' rev: 6.00

#ifndef frxServerSessionManagerHPP
#define frxServerSessionManagerHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerReports.hpp>	// Pascal unit
#include <ScktComp.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserversessionmanager
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxSessionItem;
class PASCALIMPLEMENTATION TfrxSessionItem : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	bool FActive;
	bool FCompleted;
	AnsiString FName;
	Frxserverreports::TfrxReportSession* FReportThread;
	AnsiString FSessionId;
	Scktcomp::TCustomWinSocket* FSocket;
	System::TDateTime FTimeComplete;
	System::TDateTime FTimeCreated;
	
public:
	__fastcall TfrxSessionItem(void);
	__fastcall virtual ~TfrxSessionItem(void);
	__property bool Active = {read=FActive, write=FActive, nodefault};
	__property AnsiString SessionId = {read=FSessionId, write=FSessionId};
	__property Scktcomp::TCustomWinSocket* Socket = {read=FSocket, write=FSocket};
	__property bool Completed = {read=FCompleted, write=FCompleted, nodefault};
	__property System::TDateTime TimeCreated = {read=FTimeCreated, write=FTimeCreated};
	__property System::TDateTime TimeComplete = {read=FTimeComplete, write=FTimeComplete};
	__property AnsiString FileName = {read=FName, write=FName};
	__property Frxserverreports::TfrxReportSession* ReportThread = {read=FReportThread, write=FReportThread};
};


class DELPHICLASS TfrxSessionManager;
class PASCALIMPLEMENTATION TfrxSessionManager : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	int FCleanUpTimeOut;
	TfrxSessionItem* FSession;
	Classes::TList* FSessionList;
	AnsiString FSessionPath;
	bool FShutDown;
	bool FThreadActive;
	bool __fastcall CleanUpSession(AnsiString SessionId);
	void __fastcall Clear(void);
	void __fastcall DeleteSession(void);
	void __fastcall DeleteSessionFolder(const AnsiString DirName);
	void __fastcall SetSessionPath(const AnsiString Value);
	int __fastcall GetCount(void);
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TfrxSessionManager(void);
	__fastcall virtual ~TfrxSessionManager(void);
	TfrxSessionItem* __fastcall AddSession(AnsiString SessionId, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall CompleteSession(Scktcomp::TCustomWinSocket* Socket);
	void __fastcall CompleteSessionId(AnsiString SessionId);
	TfrxSessionItem* __fastcall FindSessionBySocket(Scktcomp::TCustomWinSocket* Socket);
	TfrxSessionItem* __fastcall FindSessionById(AnsiString SessionId);
	void __fastcall CleanUp(void);
	__property int CleanUpTimeOut = {read=FCleanUpTimeOut, write=FCleanUpTimeOut, nodefault};
	__property AnsiString SessionPath = {read=FSessionPath, write=SetSessionPath};
	__property int Count = {read=GetCount, nodefault};
};


class DELPHICLASS TfrxOldSessionsCleanupThread;
class PASCALIMPLEMENTATION TfrxOldSessionsCleanupThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	AnsiString FPath;
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TfrxOldSessionsCleanupThread(const AnsiString Dir);
	__property AnsiString Path = {read=FPath, write=FPath};
public:
	#pragma option push -w-inl
	/* TThread.Destroy */ inline __fastcall virtual ~TfrxOldSessionsCleanupThread(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxSessionManager* SessionManager;

}	/* namespace Frxserversessionmanager */
using namespace Frxserversessionmanager;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerSessionManager
