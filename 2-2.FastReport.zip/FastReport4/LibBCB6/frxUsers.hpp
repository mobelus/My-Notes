// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxusers.pas' rev: 6.00

#ifndef frxusersHPP
#define frxusersHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxmd5.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <frxFileUtils.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxusers
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxUsers;
class DELPHICLASS TfrxUserGroupItem;
class PASCALIMPLEMENTATION TfrxUsers : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Frxxml::TfrxXMLDocument* FXML;
	Classes::TStringList* FUsersList;
	Classes::TStringList* FGroupsList;
	void __fastcall UnpackUsersTree(void);
	void __fastcall PackUsersTree(void);
	
public:
	__fastcall TfrxUsers(void);
	__fastcall virtual ~TfrxUsers(void);
	void __fastcall Clear(void);
	bool __fastcall CheckPassword(const AnsiString UserName, const AnsiString Password);
	bool __fastcall AllowLogin(const AnsiString UserName, const AnsiString Password);
	bool __fastcall AllowGroupLogin(const AnsiString UserName);
	bool __fastcall UserExists(const AnsiString UserName);
	bool __fastcall GroupExists(const AnsiString GroupName);
	bool __fastcall ChPasswd(const AnsiString UserName, const AnsiString NewPassword);
	TfrxUserGroupItem* __fastcall AddUser(const AnsiString UserName);
	TfrxUserGroupItem* __fastcall AddGroup(const AnsiString GroupName);
	TfrxUserGroupItem* __fastcall GetGroup(const AnsiString GroupName);
	TfrxUserGroupItem* __fastcall GetUser(const AnsiString UserName);
	bool __fastcall MemberOfGroup(const AnsiString User, const AnsiString Group);
	AnsiString __fastcall GetUserIndex(const AnsiString User);
	AnsiString __fastcall GetGroupOfUser(const AnsiString User);
	void __fastcall LoadFromFile(const AnsiString FileName);
	void __fastcall AddUserToGroup(const AnsiString UserName, const AnsiString GroupName);
	void __fastcall RemoveUserFromGroup(const AnsiString Username, const AnsiString GroupName);
	void __fastcall RemoveGroupFromUser(const AnsiString GroupName, const AnsiString Username);
	void __fastcall DeleteUser(const AnsiString UserName);
	void __fastcall DeleteGroup(const AnsiString GroupName);
	void __fastcall SaveToFile(const AnsiString FileName);
	__property Classes::TStringList* UserList = {read=FUsersList};
	__property Classes::TStringList* GroupList = {read=FGroupsList};
};


class PASCALIMPLEMENTATION TfrxUserGroupItem : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	bool FActive;
	AnsiString FPassword;
	AnsiString FName;
	AnsiString FEmail;
	AnsiString FFullName;
	AnsiString FAuthType;
	bool FIsGroup;
	Classes::TStringList* FMembers;
	AnsiString FIndexFile;
	
public:
	__fastcall TfrxUserGroupItem(void);
	__fastcall virtual ~TfrxUserGroupItem(void);
	__property AnsiString Name = {read=FName, write=FName};
	__property bool Active = {read=FActive, write=FActive, nodefault};
	__property AnsiString FullName = {read=FFullName, write=FFullName};
	__property AnsiString Email = {read=FEmail, write=FEmail};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property AnsiString AuthType = {read=FAuthType, write=FAuthType};
	__property bool IsGroup = {read=FIsGroup, write=FIsGroup, nodefault};
	__property Classes::TStringList* Members = {read=FMembers};
	__property AnsiString IndexFile = {read=FIndexFile, write=FIndexFile};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxUsers* ServerUsers;

}	/* namespace Frxusers */
using namespace Frxusers;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxusers
