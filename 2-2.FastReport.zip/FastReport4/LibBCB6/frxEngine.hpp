// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxEngine.pas' rev: 6.00

#ifndef frxEngineHPP
#define frxEngineHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxDMPClass.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <frxAggregate.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxengine
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxHeaderListItem;
class PASCALIMPLEMENTATION TfrxHeaderListItem : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	Frxclass::TfrxBand* Band;
	Extended Left;
	bool IsInKeepList;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxHeaderListItem(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxHeaderListItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxHeaderList;
class PASCALIMPLEMENTATION TfrxHeaderList : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TfrxHeaderListItem* operator[](int Index) { return Items[Index]; }
	
private:
	Classes::TList* FList;
	int __fastcall GetCount(void);
	TfrxHeaderListItem* __fastcall GetItems(int Index);
	
public:
	__fastcall TfrxHeaderList(void);
	__fastcall virtual ~TfrxHeaderList(void);
	void __fastcall Clear(void);
	void __fastcall AddItem(Frxclass::TfrxBand* ABand, Extended ALeft, bool AInKeepList);
	void __fastcall RemoveItem(Frxclass::TfrxBand* ABand);
	__property int Count = {read=GetCount, nodefault};
	__property TfrxHeaderListItem* Items[int Index] = {read=GetItems/*, default*/};
};


class DELPHICLASS TfrxEngine;
class PASCALIMPLEMENTATION TfrxEngine : public Frxclass::TfrxCustomEngine 
{
	typedef Frxclass::TfrxCustomEngine inherited;
	
private:
	Frxaggregate::TfrxAggregateList* FAggregates;
	bool FCallFromAddPage;
	bool FCallFromEndPage;
	Frxclass::TfrxBand* FCurBand;
	Frxclass::TfrxBand* FLastBandOnPage;
	bool FDontShowHeaders;
	TfrxHeaderList* FHeaderList;
	bool FFirstReportPage;
	Extended FFirstColumnY;
	bool FIsFirstBand;
	bool FIsFirstPage;
	bool FIsLastPage;
	Classes::TStrings* FHBandNamesTree;
	Frxclass::TfrxBand* FKeepBand;
	bool FKeepFooter;
	bool FKeeping;
	bool FKeepHeader;
	Extended FKeepCurY;
	Extended FSaveCurY;
	Extended FPrevFooterHeight;
	Frxxml::TfrxXMLItem* FKeepOutline;
	int FKeepPosition;
	int FKeepAnchor;
	bool FCallFromPHeader;
	Frxclass::TfrxNullBand* FOutputTo;
	Frxclass::TfrxReportPage* FPage;
	Extended FPageCurX;
	Frxclass::TfrxBand* FStartNewPageBand;
	Classes::TList* FVHeaderList;
	Frxclass::TfrxBand* FVMasterBand;
	Classes::TList* FVPageList;
	void __fastcall AddBandOutline(Frxclass::TfrxBand* Band);
	void __fastcall AddColumn(void);
	void __fastcall AddPage(void);
	void __fastcall AddPageOutline(void);
	void __fastcall AddToHeaderList(Frxclass::TfrxBand* Band);
	void __fastcall AddToVHeaderList(Frxclass::TfrxBand* Band);
	void __fastcall CheckBandColumns(Frxclass::TfrxDataBand* Band, int ColumnKeepPos, Extended SaveCurY);
	void __fastcall CheckDrill(Frxclass::TfrxDataBand* Master, Frxclass::TfrxGroupHeader* Band);
	void __fastcall CheckGroups(Frxclass::TfrxDataBand* Master, Frxclass::TfrxGroupHeader* Band, int ColumnKeepPos, Extended SaveCurY);
	void __fastcall CheckSubReports(Frxclass::TfrxBand* Band);
	void __fastcall CheckSuppress(Frxclass::TfrxBand* Band);
	void __fastcall DoShow(Frxclass::TfrxBand* Band);
	void __fastcall DrawSplit(Frxclass::TfrxBand* Band);
	void __fastcall EndColumn(void);
	void __fastcall EndKeep(Frxclass::TfrxBand* Band);
	void __fastcall InitGroups(Frxclass::TfrxDataBand* Master, Frxclass::TfrxGroupHeader* Band, int Index, bool ResetLineN = false);
	void __fastcall InitPage(void);
	void __fastcall NotifyObjects(Frxclass::TfrxBand* Band);
	void __fastcall OutlineRoot(void);
	void __fastcall OutlineUp(Frxclass::TfrxBand* Band);
	void __fastcall PreparePage(Classes::TStrings* ErrorList, bool PrepareVBands);
	void __fastcall PrepareShiftTree(Frxclass::TfrxBand* Band);
	void __fastcall RemoveFromHeaderList(Frxclass::TfrxBand* Band);
	void __fastcall RemoveFromVHeaderList(Frxclass::TfrxBand* Band);
	void __fastcall ResetSuppressValues(Frxclass::TfrxBand* Band);
	void __fastcall RunPage(Frxclass::TfrxReportPage* Page);
	void __fastcall RunReportPages(void);
	void __fastcall ShowGroupFooters(Frxclass::TfrxGroupHeader* Band, int Index, Frxclass::TfrxDataBand* Master);
	void __fastcall ShowVBands(Frxclass::TfrxBand* HBand);
	void __fastcall StartKeep(Frxclass::TfrxBand* Band, int Position = 0x0);
	void __fastcall Stretch(Frxclass::TfrxBand* Band);
	void __fastcall UnStretch(Frxclass::TfrxBand* Band);
	bool __fastcall CanShow(System::TObject* Obj, bool PrintIfDetailEmpty);
	Frxclass::TfrxBand* __fastcall FindBand(TMetaClass* Band);
	bool __fastcall RunDialogs(void);
	
protected:
	virtual Extended __fastcall GetPageHeight(void);
	
public:
	__fastcall virtual TfrxEngine(Frxclass::TfrxReport* AReport);
	__fastcall virtual ~TfrxEngine(void);
	virtual void __fastcall EndPage(void);
	virtual void __fastcall NewColumn(void);
	virtual void __fastcall NewPage(void);
	virtual bool __fastcall Run(void);
	virtual void __fastcall ShowBand(Frxclass::TfrxBand* Band)/* overload */;
	virtual void __fastcall ShowBand(TMetaClass* Band)/* overload */;
	virtual Extended __fastcall HeaderHeight(void);
	virtual Extended __fastcall FooterHeight(void);
	virtual Extended __fastcall FreeSpace(void);
	virtual void __fastcall BreakAllKeep(void);
	virtual Variant __fastcall GetAggregateValue(const AnsiString Name, const AnsiString Expression, Frxclass::TfrxBand* Band, int Flags);
	bool __fastcall Initialize(void);
	void __fastcall Finalize(void);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxengine */
using namespace Frxengine;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxEngine
