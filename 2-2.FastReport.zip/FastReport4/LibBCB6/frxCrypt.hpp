// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxCrypt.pas' rev: 6.00

#ifndef frxCryptHPP
#define frxCryptHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxClass.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxcrypt
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxCrypt;
class PASCALIMPLEMENTATION TfrxCrypt : public Frxclass::TfrxCustomCrypter 
{
	typedef Frxclass::TfrxCustomCrypter inherited;
	
private:
	AnsiString __fastcall AskKey(const AnsiString Key);
	
public:
	virtual void __fastcall Crypt(Classes::TStream* Dest, const AnsiString Key);
	virtual bool __fastcall Decrypt(Classes::TStream* Source, const AnsiString Key);
public:
	#pragma option push -w-inl
	/* TfrxCustomCrypter.Create */ inline __fastcall virtual TfrxCrypt(Classes::TComponent* AOwner) : Frxclass::TfrxCustomCrypter(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomCrypter.Destroy */ inline __fastcall virtual ~TfrxCrypt(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall frxCryptStream(Classes::TStream* Source, Classes::TStream* Dest, const AnsiString Key);
extern PACKAGE void __fastcall frxDecryptStream(Classes::TStream* Source, Classes::TStream* Dest, const AnsiString Key);

}	/* namespace Frxcrypt */
using namespace Frxcrypt;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxCrypt
