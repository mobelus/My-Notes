// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxRC4.pas' rev: 6.00

#ifndef frxRC4HPP
#define frxRC4HPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxrc4
{
//-- type declarations -------------------------------------------------------
typedef Byte *PByte;

class DELPHICLASS TfrxRC4;
class PASCALIMPLEMENTATION TfrxRC4 : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Byte FKey[256];
	void __fastcall xchg(Byte &byte1, Byte &byte2);
	
public:
	void __fastcall Start(void * Key, int KeyLength);
	void __fastcall Crypt(void * Source, void * Target, int Length);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxRC4(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxRC4(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxrc4 */
using namespace Frxrc4;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxRC4
