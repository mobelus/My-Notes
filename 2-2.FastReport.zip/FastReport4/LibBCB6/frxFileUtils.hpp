// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxFileUtils.pas' rev: 6.00

#ifndef frxFileUtilsHPP
#define frxFileUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Registry.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <ShlObj.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxfileutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int __fastcall GetFileSize(const AnsiString FileName);
extern PACKAGE int __fastcall StreamSearch(Classes::TStream* Strm, const int StartPos, const AnsiString Value);
extern PACKAGE AnsiString __fastcall BrowseDialog(const AnsiString Path, const AnsiString Title = "");
extern PACKAGE void __fastcall DeleteFolder(const AnsiString DirName);
extern PACKAGE AnsiString __fastcall GetFileMIMEType(const AnsiString Extension);

}	/* namespace Frxfileutils */
using namespace Frxfileutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxFileUtils
