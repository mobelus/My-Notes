// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxGML.pas' rev: 6.00

#ifndef frxGMLHPP
#define frxGMLHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxgml
{
//-- type declarations -------------------------------------------------------
typedef int TGmlEaResult;

typedef int TGmlElValue;

class DELPHICLASS TGmlList;
class PASCALIMPLEMENTATION TGmlList : public Classes::TList 
{
	typedef Classes::TList inherited;
	
public:
	virtual void __fastcall Clear(void);
public:
	#pragma option push -w-inl
	/* TList.Destroy */ inline __fastcall virtual ~TGmlList(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlList(void) : Classes::TList() { }
	#pragma option pop
	
};


#pragma pack(push, 4)
struct TGmlStr
{
	int Pos;
	int Len;
	AnsiString Data;
} ;
#pragma pack(pop)

class DELPHICLASS TGmlNode;
class PASCALIMPLEMENTATION TGmlNode : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	void __fastcall SetHeader(const AnsiString s);
	void __fastcall SetBody(const AnsiString s);
	
protected:
	TGmlStr FHeader;
	TGmlStr FBody;
	virtual AnsiString __fastcall GetHeader(void) = 0 ;
	virtual AnsiString __fastcall GetBody(void) = 0 ;
	
public:
	TGmlNode* FParent;
	Classes::TList* FSubNodes;
	__fastcall virtual ~TGmlNode(void);
	void __fastcall DestroyTree(void);
	bool __fastcall Empty(void);
	void __fastcall UpdateParent(void);
	void __fastcall Remove(bool DestroyItself = true);
	int __fastcall SelfSubIndex(void);
	Classes::TList* __fastcall Select(int First, int Last = 0xffffffff);
	int __fastcall NodesCount(void);
	__property AnsiString Header = {read=GetHeader, write=SetHeader};
	__property AnsiString Body = {read=GetBody, write=SetBody};
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlNode(void) : System::TObject() { }
	#pragma option pop
	
};


class DELPHICLASS TGmlRtfNode;
class DELPHICLASS TGmlRtf;
class DELPHICLASS TGmlRtfFont;
class DELPHICLASS TGmlRtfColor;
class PASCALIMPLEMENTATION TGmlRtf : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	AnsiString FText;
	TGmlRtfNode* FRoot;
	Classes::TList* FStack;
	int FPos;
	int FLast;
	Classes::TList* FFontList;
	TGmlList* FColorList;
	char __fastcall Current(bool SkipInvisibles = false);
	char __fastcall Get(void);
	char __fastcall Prepare(void);
	void __fastcall Push(void);
	void __fastcall Pop(bool Discard = false);
	bool __cdecl IsVisible(char c);
	char __fastcall Escape(char c);
	bool __cdecl IsSpecChar(char c);
	bool __cdecl IsAlpha(char c);
	bool __cdecl IsDigit(char c);
	Byte __cdecl HexDigit(char c);
	bool __fastcall SkipAlpha(void);
	bool __fastcall SkipDigit(void);
	TGmlRtfNode* __fastcall SkipControl(void);
	TGmlRtfNode* __fastcall SkipGroup(void);
	TGmlRtfNode* __fastcall SkipNumber(void);
	TGmlRtfNode* __fastcall SkipText(void);
	TGmlRtfNode* __fastcall SkipControlSymbol(void);
	Classes::TList* __fastcall SkipList(void);
	Classes::TList* __fastcall Parse(int First, int Last);
	void __fastcall LoadFonts(void);
	void __fastcall LoadColors(void);
	
public:
	__fastcall TGmlRtf(const AnsiString Text);
	__fastcall virtual ~TGmlRtf(void);
	int __fastcall Length(void);
	int __fastcall Copy(int Pos, int Len, char * Dest)/* overload */;
	AnsiString __fastcall Copy(int Pos, int Len)/* overload */;
	AnsiString __fastcall Copy(const TGmlStr &Str)/* overload */;
	char __fastcall Char(int Pos);
	void __fastcall Serialize(Classes::TStream* Stream);
	__property TGmlRtfNode* Root = {read=FRoot};
	int __fastcall FontsCount(void);
	TGmlRtfFont* __fastcall Font(int i);
	int __fastcall ColorsCount(void);
	TGmlRtfColor* __fastcall Color(int i);
};


class PASCALIMPLEMENTATION TGmlRtfNode : public TGmlNode 
{
	typedef TGmlNode inherited;
	
protected:
	virtual AnsiString __fastcall GetHeader();
	virtual AnsiString __fastcall GetBody();
	
public:
	TGmlRtf* FDoc;
	virtual void __fastcall Serialize(Classes::TStream* Stream);
	void __fastcall SerializeSubNodes(Classes::TStream* Stream, int First, int Last);
	TGmlRtfNode* __fastcall Node(int Index);
	TGmlRtfNode* __fastcall Find(const AnsiString Hdr);
	Classes::TList* __fastcall FindAll(const AnsiString Hdr, int MaxCount = 0x0);
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfNode(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfNode(void) : TGmlNode() { }
	#pragma option pop
	
};


class DELPHICLASS TGmlRtfGroup;
class PASCALIMPLEMENTATION TGmlRtfGroup : public TGmlRtfNode 
{
	typedef TGmlRtfNode inherited;
	
public:
	virtual void __fastcall Serialize(Classes::TStream* Stream);
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfGroup(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfGroup(void) : TGmlRtfNode() { }
	#pragma option pop
	
};


class DELPHICLASS TGmlRtfText;
class PASCALIMPLEMENTATION TGmlRtfText : public TGmlRtfNode 
{
	typedef TGmlRtfNode inherited;
	
public:
	virtual void __fastcall Serialize(Classes::TStream* Stream);
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfText(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfText(void) : TGmlRtfNode() { }
	#pragma option pop
	
};


class DELPHICLASS TGmlRtfControl;
class PASCALIMPLEMENTATION TGmlRtfControl : public TGmlRtfNode 
{
	typedef TGmlRtfNode inherited;
	
private:
	bool FArg;
	int FArgValue;
	void __fastcall SetValue(int x);
	int __fastcall GetValue(void);
	
public:
	virtual void __fastcall Serialize(Classes::TStream* Stream);
	__property int Value = {read=GetValue, write=SetValue, nodefault};
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfControl(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfControl(void) : TGmlRtfNode() { }
	#pragma option pop
	
};


class DELPHICLASS TGmlRtfNumber;
class PASCALIMPLEMENTATION TGmlRtfNumber : public TGmlRtfNode 
{
	typedef TGmlRtfNode inherited;
	
public:
	int FValue;
	virtual void __fastcall Serialize(Classes::TStream* Stream);
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfNumber(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfNumber(void) : TGmlRtfNode() { }
	#pragma option pop
	
};


class DELPHICLASS TGmlRtfSymbol;
class PASCALIMPLEMENTATION TGmlRtfSymbol : public TGmlRtfNode 
{
	typedef TGmlRtfNode inherited;
	
public:
	char Symbol;
	virtual void __fastcall Serialize(Classes::TStream* Stream);
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfSymbol(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfSymbol(void) : TGmlRtfNode() { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TGmlRtfFont : public TGmlRtfNode 
{
	typedef TGmlRtfNode inherited;
	
private:
	int __fastcall GetIndex(void);
	int __fastcall GetCharset(void);
	AnsiString __fastcall GetName();
	
public:
	__property int Index = {read=GetIndex, nodefault};
	__property int Charset = {read=GetCharset, nodefault};
	__property AnsiString Name = {read=GetName};
public:
	#pragma option push -w-inl
	/* TGmlNode.Destroy */ inline __fastcall virtual ~TGmlRtfFont(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfFont(void) : TGmlRtfNode() { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TGmlRtfColor : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TGmlRtfControl* R;
	TGmlRtfControl* G;
	TGmlRtfControl* B;
	AnsiString __fastcall Serialize();
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TGmlRtfColor(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TGmlRtfColor(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint GmlEaFailure = 0x0;
static const Shortint GmlEaSuccess = 0x1;
static const Shortint GmlEaIncomplete = 0x2;
static const Shortint GmlElNone = 0x0;
static const Shortint GmlElOne = 0x1;
static const Shortint GmlElAll = 0xffffffff;
extern PACKAGE char GmlRtfScEscape;
extern PACKAGE char GmlRtfScOpen;
extern PACKAGE char GmlRtfScClose;
static const Shortint GmlRtfMaxControl = 0x20;
static const Shortint GmlRtfMaxControlArg = 0xa;

}	/* namespace Frxgml */
using namespace Frxgml;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxGML
