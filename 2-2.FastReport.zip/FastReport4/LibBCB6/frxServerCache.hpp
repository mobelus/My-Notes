// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerCache.pas' rev: 6.00

#ifndef frxServerCacheHPP
#define frxServerCacheHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SyncObjs.hpp>	// Pascal unit
#include <frxServerLog.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <frxVariables.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxservercache
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxServerCacheItem;
class PASCALIMPLEMENTATION TfrxServerCacheItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FReportName;
	Frxvariables::TfrxVariables* FVariables;
	AnsiString FFileName;
	System::TDateTime FExpTime;
	AnsiString FSessionId;
	Classes::TStream* FStream;
	AnsiString FInternalId;
	
public:
	__fastcall virtual TfrxServerCacheItem(Classes::TCollection* Collection);
	__fastcall virtual ~TfrxServerCacheItem(void);
	
__published:
	__property AnsiString ReportName = {read=FReportName, write=FReportName};
	__property Frxvariables::TfrxVariables* Variables = {read=FVariables, write=FVariables};
	__property AnsiString FileName = {read=FFileName, write=FFileName};
	__property System::TDateTime ExpTime = {read=FExpTime, write=FExpTime};
	__property AnsiString SessionId = {read=FSessionId, write=FSessionId};
	__property Classes::TStream* Stream = {read=FStream, write=FStream};
	__property AnsiString InternalId = {read=FInternalId, write=FInternalId};
};


class DELPHICLASS TfrxServerCacheSpool;
class PASCALIMPLEMENTATION TfrxServerCacheSpool : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
private:
	TfrxServerCacheItem* __fastcall GetItems(int Index);
	bool __fastcall EqualVariables(const Frxvariables::TfrxVariables* Var1, const Frxvariables::TfrxVariables* Var2);
	
public:
	__fastcall TfrxServerCacheSpool(void);
	__fastcall virtual ~TfrxServerCacheSpool(void);
	__property TfrxServerCacheItem* Items[int Index] = {read=GetItems};
	HIDESBASE void __fastcall Clear(void);
	
__published:
	HIDESBASE TfrxServerCacheItem* __fastcall Add(void);
	HIDESBASE TfrxServerCacheItem* __fastcall Insert(int Index);
	int __fastcall IndexOf(const AnsiString ReportName, const Frxvariables::TfrxVariables* Variables, const AnsiString SessionId);
};


class DELPHICLASS TfrxServerCache;
class PASCALIMPLEMENTATION TfrxServerCache : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	AnsiString FCachePath;
	bool FActive;
	int FLatency;
	TfrxServerCacheSpool* FHeap;
	bool FMemoryCache;
	bool FThreadActive;
	void __fastcall SetActive(const bool Value);
	void __fastcall CleanUpFiles(void);
	void __fastcall RemoveExpired(void);
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TfrxServerCache(void);
	__fastcall virtual ~TfrxServerCache(void);
	bool __fastcall GetCachedStream(const Frxclass::TfrxReport* Report, const AnsiString ReportName, const Frxvariables::TfrxVariables* Variables, const AnsiString Id);
	bool __fastcall GetCachedReportById(const Frxclass::TfrxReport* Report, const AnsiString Id);
	void __fastcall Open(void);
	void __fastcall Close(void);
	void __fastcall Clear(void);
	void __fastcall AddReport(const Frxclass::TfrxReport* Report, const AnsiString ReportName, const Frxvariables::TfrxVariables* Variables, const AnsiString Id, const AnsiString InternalId);
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property AnsiString CachePath = {read=FCachePath, write=FCachePath};
	__property int DefaultLatency = {read=FLatency, write=FLatency, nodefault};
	__property TfrxServerCacheSpool* Heap = {read=FHeap};
	__property bool MemoryCache = {read=FMemoryCache, write=FMemoryCache, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
#define CACHE_PREFIX "$fr"
extern PACKAGE Syncobjs::TCriticalSection* CacheCS1;
extern PACKAGE TfrxServerCache* ReportCache;

}	/* namespace Frxservercache */
using namespace Frxservercache;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerCache
