// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxEditPage.pas' rev: 6.00

#ifndef frxEditPageHPP
#define frxEditPageHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <frxCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxeditpage
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxPageEditorForm;
class PASCALIMPLEMENTATION TfrxPageEditorForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OKB;
	Stdctrls::TButton* CancelB;
	Comctrls::TPageControl* PageControl1;
	Comctrls::TTabSheet* TabSheet1;
	Comctrls::TTabSheet* TabSheet3;
	Stdctrls::TGroupBox* Label11;
	Stdctrls::TLabel* Label1;
	Stdctrls::TLabel* Label2;
	Stdctrls::TLabel* UnitL1;
	Stdctrls::TLabel* UnitL2;
	Stdctrls::TEdit* WidthE;
	Stdctrls::TEdit* HeightE;
	Stdctrls::TComboBox* SizeCB;
	Stdctrls::TGroupBox* Label14;
	Stdctrls::TGroupBox* Label12;
	Extctrls::TImage* PortraitImg;
	Extctrls::TImage* LandscapeImg;
	Stdctrls::TRadioButton* PortraitRB;
	Stdctrls::TRadioButton* LandscapeRB;
	Stdctrls::TGroupBox* Label13;
	Stdctrls::TLabel* Label3;
	Stdctrls::TLabel* Label4;
	Stdctrls::TLabel* Label5;
	Stdctrls::TLabel* Label6;
	Stdctrls::TLabel* UnitL3;
	Stdctrls::TLabel* UnitL4;
	Stdctrls::TLabel* UnitL5;
	Stdctrls::TLabel* UnitL6;
	Stdctrls::TEdit* MarginLeftE;
	Stdctrls::TEdit* MarginTopE;
	Stdctrls::TEdit* MarginRightE;
	Stdctrls::TEdit* MarginBottomE;
	Stdctrls::TLabel* Label9;
	Stdctrls::TLabel* Label10;
	Stdctrls::TComboBox* Tray1CB;
	Stdctrls::TComboBox* Tray2CB;
	Stdctrls::TGroupBox* Label7;
	Stdctrls::TLabel* Label8;
	Stdctrls::TLabel* Label15;
	Stdctrls::TLabel* Label16;
	Stdctrls::TLabel* UnitL7;
	Stdctrls::TEdit* ColumnsNumberE;
	Stdctrls::TEdit* ColumnWidthE;
	Stdctrls::TMemo* ColumnPositionsM;
	Comctrls::TUpDown* UpDown1;
	Stdctrls::TGroupBox* Label17;
	Stdctrls::TLabel* Label18;
	Stdctrls::TCheckBox* PrintOnPrevCB;
	Stdctrls::TCheckBox* MirrorMarginsCB;
	Stdctrls::TCheckBox* LargeHeightCB;
	Stdctrls::TComboBox* DuplexCB;
	Stdctrls::TCheckBox* EndlessWidthCB;
	Stdctrls::TCheckBox* EndlessHeightCB;
	void __fastcall PortraitRBClick(System::TObject* Sender);
	void __fastcall SizeCBClick(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormHide(System::TObject* Sender);
	void __fastcall WidthEChange(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall UpDown1Click(System::TObject* Sender, Comctrls::TUDBtnType Button);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	
private:
	bool FUpdating;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxPageEditorForm(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxPageEditorForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxPageEditorForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxPageEditorForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxeditpage */
using namespace Frxeditpage;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxEditPage
