// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerClient.pas' rev: 6.00

#ifndef frxServerClientHPP
#define frxServerClientHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxmd5.hpp>	// Pascal unit
#include <frxHTTPClient.hpp>	// Pascal unit
#include <frxGZip.hpp>	// Pascal unit
#include <frxVariables.hpp>	// Pascal unit
#include <ScktComp.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverclient
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxServerConnection;
class PASCALIMPLEMENTATION TfrxServerConnection : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FHost;
	AnsiString FLogin;
	bool FMIC;
	AnsiString FPassword;
	int FPort;
	int FProxyPort;
	AnsiString FProxyHost;
	int FRetryCount;
	unsigned FRetryTimeout;
	unsigned FTimeout;
	AnsiString FPath;
	bool FCompression;
	void __fastcall SetPath(const AnsiString Value);
	
public:
	__fastcall virtual TfrxServerConnection(Classes::TComponent* AOwner);
	
__published:
	__property bool Compression = {read=FCompression, write=FCompression, nodefault};
	__property AnsiString Host = {read=FHost, write=FHost};
	__property AnsiString Login = {read=FLogin, write=FLogin};
	__property bool MIC = {read=FMIC, write=FMIC, nodefault};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property AnsiString ProxyHost = {read=FProxyHost, write=FProxyHost};
	__property int ProxyPort = {read=FProxyPort, write=FProxyPort, nodefault};
	__property int RetryCount = {read=FRetryCount, write=FRetryCount, nodefault};
	__property unsigned RetryTimeout = {read=FRetryTimeout, write=FRetryTimeout, nodefault};
	__property unsigned Timeout = {read=FTimeout, write=FTimeout, nodefault};
	__property AnsiString Path = {read=FPath, write=SetPath};
public:
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxServerConnection(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxReportClient;
class PASCALIMPLEMENTATION TfrxReportClient : public Frxclass::TfrxReport 
{
	typedef Frxclass::TfrxReport inherited;
	
private:
	Frxhttpclient::TfrxHTTPClient* FClient;
	TfrxServerConnection* FConnection;
	AnsiString FReportName;
	AnsiString FSessionId;
	bool FSecondPass;
	void __fastcall FillPreviewPages(void);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TfrxReportClient(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxReportClient(void);
	HIDESBASE bool __fastcall PrepareReport(void);
	HIDESBASE void __fastcall LoadFromFile(AnsiString FileName);
	HIDESBASE void __fastcall ShowReport(void);
	AnsiString __fastcall GetServerVariable(const AnsiString VariableName);
	void __fastcall Close(void);
	__property Frxhttpclient::TfrxHTTPClient* Client = {read=FClient, write=FClient};
	
__published:
	__property TfrxServerConnection* Connection = {read=FConnection, write=FConnection};
	__property AnsiString ReportName = {read=FReportName, write=FReportName};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxReportClient(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxReport(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxserverclient */
using namespace Frxserverclient;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerClient
