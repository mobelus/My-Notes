// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerVariables.pas' rev: 6.00

#ifndef frxServerVariablesHPP
#define frxServerVariablesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxservervariables
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxServerVariable;
class PASCALIMPLEMENTATION TfrxServerVariable : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FName;
	AnsiString FValue;
	
__published:
	__property AnsiString Name = {read=FName, write=FName};
	__property AnsiString Value = {read=FValue, write=FValue};
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxServerVariable(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxServerVariable(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxServerVariables;
class PASCALIMPLEMENTATION TfrxServerVariables : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	__fastcall TfrxServerVariables(void);
	AnsiString __fastcall GetValue(const AnsiString Name);
	void __fastcall AddVariable(const AnsiString Name, const AnsiString Value);
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxServerVariables(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxservervariables */
using namespace Frxservervariables;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerVariables
