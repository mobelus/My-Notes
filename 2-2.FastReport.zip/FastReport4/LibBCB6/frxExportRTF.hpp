// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxExportRTF.pas' rev: 6.00

#ifndef frxExportRTFHPP
#define frxExportRTFHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxGraphicUtils.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <frxProgress.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <frxExportMatrix.hpp>	// Pascal unit
#include <ShellAPI.hpp>	// Pascal unit
#include <jpeg.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <ComObj.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxexportrtf
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxHeaderFooterMode { hfText, hfPrint, hfNone };
#pragma option pop

class DELPHICLASS TfrxRTFExportDialog;
class PASCALIMPLEMENTATION TfrxRTFExportDialog : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OkB;
	Stdctrls::TButton* CancelB;
	Stdctrls::TGroupBox* GroupPageRange;
	Stdctrls::TLabel* DescrL;
	Stdctrls::TRadioButton* AllRB;
	Stdctrls::TRadioButton* CurPageRB;
	Stdctrls::TRadioButton* PageNumbersRB;
	Stdctrls::TEdit* PageNumbersE;
	Stdctrls::TGroupBox* GroupQuality;
	Stdctrls::TCheckBox* WCB;
	Stdctrls::TCheckBox* PageBreaksCB;
	Stdctrls::TCheckBox* PicturesCB;
	Stdctrls::TCheckBox* OpenCB;
	Dialogs::TSaveDialog* SaveDialog1;
	Stdctrls::TCheckBox* ContinuousCB;
	Stdctrls::TLabel* HeadFootL;
	Stdctrls::TComboBox* PColontitulCB;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall PageNumbersEChange(System::TObject* Sender);
	void __fastcall PageNumbersEKeyPress(System::TObject* Sender, char &Key);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxRTFExportDialog(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxRTFExportDialog(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxRTFExportDialog(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxRTFExportDialog(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxRTFExport;
class PASCALIMPLEMENTATION TfrxRTFExport : public Frxclass::TfrxCustomExportFilter 
{
	typedef Frxclass::TfrxCustomExportFilter inherited;
	
private:
	Classes::TStringList* FColorTable;
	int FCurrentPage;
	Classes::TList* FDataList;
	bool FExportPageBreaks;
	bool FExportPictures;
	bool FFirstPage;
	Classes::TStringList* FFontTable;
	Classes::TStringList* FCharsetTable;
	Frxexportmatrix::TfrxIEMatrix* FMatrix;
	bool FOpenAfterExport;
	Frxprogress::TfrxProgress* FProgress;
	bool FWysiwyg;
	AnsiString FCreator;
	TfrxHeaderFooterMode FHeaderFooterMode;
	bool FAutoSize;
	bool FExportEMF;
	WideString __fastcall TruncReturns(const WideString Str);
	AnsiString __fastcall GetRTFBorders(const Frxexportmatrix::TfrxIEMStyle* Style);
	AnsiString __fastcall GetRTFColor(const unsigned c);
	AnsiString __fastcall GetRTFFontStyle(const Graphics::TFontStyles f);
	AnsiString __fastcall GetRTFFontColor(const AnsiString f);
	AnsiString __fastcall GetRTFFontName(const AnsiString f, const int charset);
	AnsiString __fastcall GetRTFHAlignment(const Frxclass::TfrxHAlign HAlign);
	AnsiString __fastcall GetRTFVAlignment(const Frxclass::TfrxVAlign VAlign);
	WideString __fastcall StrToRTFSlash(const WideString Value);
	AnsiString __fastcall StrToRTFUnicodeEx(const WideString Value);
	AnsiString __fastcall StrToRTFUnicode(const WideString Value);
	void __fastcall ExportPage(const Classes::TStream* Stream);
	void __fastcall PrepareExport(void);
	
public:
	__fastcall virtual TfrxRTFExport(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	virtual bool __fastcall Start(void);
	virtual void __fastcall Finish(void);
	virtual void __fastcall FinishPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall StartPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall ExportObject(Frxclass::TfrxComponent* Obj);
	
__published:
	__property bool ExportEMF = {read=FExportEMF, write=FExportEMF, nodefault};
	__property bool ExportPageBreaks = {read=FExportPageBreaks, write=FExportPageBreaks, default=1};
	__property bool ExportPictures = {read=FExportPictures, write=FExportPictures, default=1};
	__property bool OpenAfterExport = {read=FOpenAfterExport, write=FOpenAfterExport, default=0};
	__property bool Wysiwyg = {read=FWysiwyg, write=FWysiwyg, nodefault};
	__property AnsiString Creator = {read=FCreator, write=FCreator};
	__property SuppressPageHeadersFooters ;
	__property TfrxHeaderFooterMode HeaderFooterMode = {read=FHeaderFooterMode, write=FHeaderFooterMode, nodefault};
	__property bool AutoSize = {read=FAutoSize, write=FAutoSize, nodefault};
	__property OverwritePrompt ;
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxRTFExport(void) : Frxclass::TfrxCustomExportFilter() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxRTFExport(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxexportrtf */
using namespace Frxexportrtf;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxExportRTF
