// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerConfig.pas' rev: 6.00

#ifndef frxServerConfigHPP
#define frxServerConfigHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerLog.hpp>	// Pascal unit
#include <IniFiles.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <SyncObjs.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverconfig
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxConfig;
class PASCALIMPLEMENTATION TfrxConfig : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Frxxml::TfrxXMLDocument* FXML;
	Classes::TStrings* FErrors;
	Classes::TStringList* FLines;
	Syncobjs::TCriticalSection* FCS;
	AnsiString FFileName;
	AnsiString FConfigFolder;
	void __fastcall UpdateLines(void);
	void __fastcall AddLine(const AnsiString Name, const AnsiString Value, Frxxml::TfrxXMLItem* XMLItem);
	int __fastcall GetCount(void);
	
public:
	AnsiString ServerMessage;
	__fastcall TfrxConfig(void);
	__fastcall virtual ~TfrxConfig(void);
	HRESULT __fastcall LoadFromStream(Classes::TStream* Stream);
	HRESULT __fastcall SaveToStream(Classes::TStream* Stream);
	HRESULT __fastcall LoadFromFile(const AnsiString FileName);
	HRESULT __fastcall SaveToFile(const AnsiString FileName);
	AnsiString __fastcall GetValue(const AnsiString Name);
	int __fastcall GetNumber(const AnsiString Name);
	bool __fastcall GetBool(const AnsiString Name);
	AnsiString __fastcall CheckValue(const AnsiString Name, const AnsiString Current);
	void __fastcall SetValue(const AnsiString Name, const AnsiString Value);
	void __fastcall SetBool(const AnsiString Name, const bool Value);
	void __fastcall Clear(void);
	void __fastcall ConfigListToFile(const AnsiString FileName);
	void __fastcall Reload(void);
	__property Classes::TStringList* Lines = {read=FLines};
	__property Frxxml::TfrxXMLDocument* XML = {read=FXML};
	__property int Count = {read=GetCount, nodefault};
	__property AnsiString ConfigFolder = {read=FConfigFolder, write=FConfigFolder};
};


class DELPHICLASS TfrxConfigItem;
class PASCALIMPLEMENTATION TfrxConfigItem : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	AnsiString FValue;
	Frxxml::TfrxXMLItem* FXMLItem;
	
public:
	__property AnsiString Value = {read=FValue, write=FValue};
	__property Frxxml::TfrxXMLItem* XMLItem = {read=FXMLItem, write=FXMLItem};
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxConfigItem(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxConfigItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxServerConfig;
class PASCALIMPLEMENTATION TfrxServerConfig : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	bool FGzip;
	AnsiString FIndexFileName;
	bool FLogging;
	AnsiString FLogin;
	AnsiString FLogPath;
	bool FMIC;
	bool FNoCacheHeader;
	Frxserverutils::TfrxServerOutputFormats FOutputFormats;
	AnsiString FPassword;
	int FPort;
	AnsiString FReportPath;
	AnsiString FRootPath;
	int FSessionTimeOut;
	int FSocketTimeOut;
	AnsiString FReportCachePath;
	int FDefaultCacheLatency;
	bool FReportCaching;
	int FMaxLogFiles;
	int FMaxLogSize;
	AnsiString FDatabase;
	AnsiString FDatabaseLogin;
	AnsiString FDatabasePassword;
	bool FReportsList;
	AnsiString FConfigFolder;
	
public:
	void __fastcall LoadFromFile(const AnsiString FileName);
	void __fastcall SaveToFile(const AnsiString FileName);
	
__published:
	__property bool Compression = {read=FGzip, write=FGzip, nodefault};
	__property AnsiString IndexFileName = {read=FIndexFileName, write=FIndexFileName};
	__property bool Logging = {read=FLogging, write=FLogging, nodefault};
	__property int MaxLogSize = {read=FMaxLogSize, write=FMaxLogSize, nodefault};
	__property int MaxLogFiles = {read=FMaxLogFiles, write=FMaxLogFiles, nodefault};
	__property AnsiString Login = {read=FLogin, write=FLogin};
	__property AnsiString LogPath = {read=FLogPath, write=FLogPath};
	__property bool MIC = {read=FMIC, write=FMIC, nodefault};
	__property bool NoCacheHeader = {read=FNoCacheHeader, write=FNoCacheHeader, nodefault};
	__property Frxserverutils::TfrxServerOutputFormats OutputFormats = {read=FOutputFormats, write=FOutputFormats, nodefault};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property AnsiString ReportPath = {read=FReportPath, write=FReportPath};
	__property AnsiString ReportCachePath = {read=FReportCachePath, write=FReportCachePath};
	__property bool ReportCaching = {read=FReportCaching, write=FReportCaching, nodefault};
	__property int DefaultCacheLatency = {read=FDefaultCacheLatency, write=FDefaultCacheLatency, nodefault};
	__property AnsiString RootPath = {read=FRootPath, write=FRootPath};
	__property int SessionTimeOut = {read=FSessionTimeOut, write=FSessionTimeOut, nodefault};
	__property int SocketTimeOut = {read=FSocketTimeOut, write=FSocketTimeOut, nodefault};
	__property AnsiString Database = {read=FDatabase, write=FDatabase};
	__property AnsiString DatabaseLogin = {read=FDatabaseLogin, write=FDatabaseLogin};
	__property AnsiString DatabasePassword = {read=FDatabasePassword, write=FDatabasePassword};
	__property bool ReportsList = {read=FReportsList, write=FReportsList, nodefault};
	__property AnsiString ConfigFolder = {read=FConfigFolder, write=FConfigFolder};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TfrxServerConfig(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxServerConfig(void) : Classes::TPersistent() { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxConfig* ServerConfig;
#define FR_SERVER_CONFIG_VERSION "2.3.0"

}	/* namespace Frxserverconfig */
using namespace Frxserverconfig;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerConfig
