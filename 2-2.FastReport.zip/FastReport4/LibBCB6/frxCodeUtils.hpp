// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxCodeUtils.pas' rev: 6.00

#ifndef frxCodeUtilsHPP
#define frxCodeUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxcodeutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall frxAddCodeRes(void);
extern PACKAGE void __fastcall frxGetEventHandlersList(Classes::TStrings* Code, const AnsiString Language, Typinfo::PTypeInfo EventType, Classes::TStrings* List);
extern PACKAGE int __fastcall frxLocateEventHandler(Classes::TStrings* Code, const AnsiString Language, const AnsiString EventName);
extern PACKAGE int __fastcall frxLocateMainProc(Classes::TStrings* Code, const AnsiString Language);
extern PACKAGE int __fastcall frxAddEvent(Classes::TStrings* Code, const AnsiString Language, Typinfo::PTypeInfo EventType, const AnsiString EventName);
extern PACKAGE void __fastcall frxEmptyCode(Classes::TStrings* Code, const AnsiString Language);

}	/* namespace Frxcodeutils */
using namespace Frxcodeutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxCodeUtils
