// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxUnicodeUtils.pas' rev: 6.00

#ifndef frxUnicodeUtilsHPP
#define frxUnicodeUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxunicodeutils
{
//-- type declarations -------------------------------------------------------
#pragma pack(push, 4)
struct TWString
{
	WideString WString;
	System::TObject* Obj;
} ;
#pragma pack(pop)

class DELPHICLASS TWideStrings;
class PASCALIMPLEMENTATION TWideStrings : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
public:
	WideString operator[](int Index) { return Strings[Index]; }
	
private:
	Classes::TList* FWideStringList;
	void __fastcall ReadData(Classes::TReader* Reader);
	void __fastcall ReadDataW(Classes::TReader* Reader);
	void __fastcall WriteDataW(Classes::TWriter* Writer);
	
protected:
	WideString __fastcall Get(int Index);
	void __fastcall Put(int Index, const WideString S);
	System::TObject* __fastcall GetObject(int Index);
	void __fastcall PutObject(int Index, System::TObject* Value);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	WideString __fastcall GetTextStr();
	void __fastcall SetTextStr(const WideString Value);
	
public:
	__fastcall TWideStrings(void);
	__fastcall virtual ~TWideStrings(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	int __fastcall Count(void);
	void __fastcall Clear(void);
	void __fastcall Delete(int Index);
	int __fastcall Add(const WideString S);
	void __fastcall AddStrings(TWideStrings* Strings);
	int __fastcall AddObject(const WideString S, System::TObject* AObject);
	int __fastcall IndexOf(const WideString S);
	void __fastcall Insert(int Index, const WideString S);
	void __fastcall LoadFromFile(const WideString FileName);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
	void __fastcall LoadFromWStream(Classes::TStream* Stream);
	void __fastcall SaveToFile(const WideString FileName);
	void __fastcall SaveToStream(Classes::TStream* Stream);
	__property System::TObject* Objects[int Index] = {read=GetObject, write=PutObject};
	__property WideString Strings[int Index] = {read=Get, write=Put/*, default*/};
	__property WideString Text = {read=GetTextStr, write=SetTextStr};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString __fastcall OemToStr(const AnsiString AnsiStr);
extern PACKAGE unsigned __fastcall CharSetToCodePage(unsigned ciCharset);
extern PACKAGE WideString __fastcall AnsiToUnicode(const AnsiString s, unsigned Charset, int CodePage = 0x0);
extern PACKAGE AnsiString __fastcall _UnicodeToAnsi(const WideString WS, unsigned Charset, int CodePage = 0x0);
extern PACKAGE unsigned __fastcall GetLocalByCharSet(unsigned Charset);

}	/* namespace Frxunicodeutils */
using namespace Frxunicodeutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxUnicodeUtils
