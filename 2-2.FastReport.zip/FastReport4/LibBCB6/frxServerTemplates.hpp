// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerTemplates.pas' rev: 6.00

#ifndef frxServerTemplatesHPP
#define frxServerTemplatesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerConfig.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxServerSSI.hpp>	// Pascal unit
#include <frxServerVariables.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxservertemplates
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxServerTemplate;
class PASCALIMPLEMENTATION TfrxServerTemplate : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Frxservervariables::TfrxServerVariables* FVariables;
	Frxserverssi::TfrxSSIStream* FSSI;
	Classes::TStringList* FTemplate;
	
public:
	__fastcall TfrxServerTemplate(void);
	__fastcall virtual ~TfrxServerTemplate(void);
	void __fastcall Clear(void);
	void __fastcall Prepare(void);
	void __fastcall SetTemplate(const AnsiString Name);
	__property Classes::TStringList* TemplateStrings = {read=FTemplate};
	__property Frxservervariables::TfrxServerVariables* Variables = {read=FVariables};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxservertemplates */
using namespace Frxservertemplates;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerTemplates
