// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerReportsList.pas' rev: 6.00

#ifndef frxServerReportsListHPP
#define frxServerReportsListHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SyncObjs.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <frxServerTemplates.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverreportslist
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxServerReportsListItem;
class PASCALIMPLEMENTATION TfrxServerReportsListItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FFileName;
	AnsiString FDescription;
	AnsiString FName;
	Classes::TStringList* FGroups;
	int FCacheLatency;
	
public:
	__fastcall virtual TfrxServerReportsListItem(Classes::TCollection* Collection);
	__fastcall virtual ~TfrxServerReportsListItem(void);
	
__published:
	__property AnsiString FileName = {read=FFileName, write=FFileName};
	__property AnsiString ReportName = {read=FName, write=FName};
	__property AnsiString Description = {read=FDescription, write=FDescription};
	__property Classes::TStringList* Groups = {read=FGroups};
	__property int CacheLatency = {read=FCacheLatency, write=FCacheLatency, nodefault};
};


class DELPHICLASS TfrxServerReportsList;
class PASCALIMPLEMENTATION TfrxServerReportsList : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
private:
	AnsiString FReportsPath;
	TfrxServerReportsListItem* __fastcall GetItems(int Index);
	void __fastcall BuildListInFolder(const AnsiString Folder);
	HIDESBASE TfrxServerReportsListItem* __fastcall GetItem(AnsiString Name);
	
public:
	__fastcall TfrxServerReportsList(void);
	__fastcall virtual ~TfrxServerReportsList(void);
	__property TfrxServerReportsListItem* Items[int Index] = {read=GetItems};
	void __fastcall BuildListOfReports(void);
	int __fastcall GetCacheLatency(const AnsiString FileName);
	bool __fastcall GetGroupMembership(const AnsiString FileName, const AnsiString Group);
	
__published:
	HIDESBASE TfrxServerReportsListItem* __fastcall Add(void);
	__property AnsiString ReportsPath = {read=FReportsPath, write=FReportsPath};
	void __fastcall GetReports4Group(const AnsiString GroupName, AnsiString &Html, AnsiString &Lines);
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxServerReportsList* ReportsList;

}	/* namespace Frxserverreportslist */
using namespace Frxserverreportslist;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerReportsList
