// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerForms.pas' rev: 6.00

#ifndef frxServerFormsHPP
#define frxServerFormsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxServerTemplates.hpp>	// Pascal unit
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxServerFormControls.hpp>	// Pascal unit
#include <frxExportMatrix.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <frxDCtrl.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverforms
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxWebForm;
class PASCALIMPLEMENTATION TfrxWebForm : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TFileStream* Exp;
	Frxexportmatrix::TfrxIEMatrix* FMatrix;
	Frxclass::TfrxDialogPage* FDialog;
	AnsiString FRepName;
	AnsiString FSession;
	void __fastcall WriteExpLn(const AnsiString str);
	AnsiString __fastcall GetHTML(Frxclass::TfrxDialogControl* Obj);
	
public:
	__fastcall TfrxWebForm(Frxclass::TfrxDialogPage* Dialog, AnsiString Session);
	__fastcall virtual ~TfrxWebForm(void);
	void __fastcall Prepare(void);
	void __fastcall Clear(void);
	void __fastcall SaveFormToFile(AnsiString FName);
	__property AnsiString ReportName = {read=FRepName, write=FRepName};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxserverforms */
using namespace Frxserverforms;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerForms
