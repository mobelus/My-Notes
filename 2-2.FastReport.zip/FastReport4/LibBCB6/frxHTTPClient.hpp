// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxHTTPClient.pas' rev: 6.00

#ifndef frxHTTPClientHPP
#define frxHTTPClientHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxmd5.hpp>	// Pascal unit
#include <frxGZip.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <ScktComp.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxhttpclient
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxHTTPClient;
class DELPHICLASS TfrxHTTPClientFields;
class PASCALIMPLEMENTATION TfrxHTTPClientFields : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	AnsiString FAcceptEncoding;
	AnsiString FHost;
	AnsiString FHTTPVer;
	AnsiString FLogin;
	AnsiString FName;
	AnsiString FPassword;
	Frxserverutils::TfrxHTTPQueryType FQueryType;
	AnsiString FReferer;
	AnsiString FUserAgent;
	AnsiString FVariables;
	AnsiString FAccept;
	AnsiString FAcceptCharset;
	AnsiString FContentType;
	AnsiString FRange;
	
public:
	__fastcall TfrxHTTPClientFields(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property AnsiString AcceptEncoding = {read=FAcceptEncoding, write=FAcceptEncoding};
	__property AnsiString Accept = {read=FAccept, write=FAccept};
	__property AnsiString AcceptCharset = {read=FAcceptCharset, write=FAcceptCharset};
	__property AnsiString FileName = {read=FName, write=FName};
	__property AnsiString Host = {read=FHost, write=FHost};
	__property AnsiString HTTPVer = {read=FHTTPVer, write=FHTTPVer};
	__property AnsiString Login = {read=FLogin, write=FLogin};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property Frxserverutils::TfrxHTTPQueryType QueryType = {read=FQueryType, write=FQueryType, nodefault};
	__property AnsiString Referer = {read=FReferer, write=FReferer};
	__property AnsiString UserAgent = {read=FUserAgent, write=FUserAgent};
	__property AnsiString Variables = {read=FVariables, write=FVariables};
	__property AnsiString ContentType = {read=FContentType, write=FContentType};
	__property AnsiString Range = {read=FRange, write=FRange};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TfrxHTTPClientFields(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxHTTPServerFields;
class PASCALIMPLEMENTATION TfrxHTTPServerFields : public Classes::TPersistent 
{
	typedef Classes::TPersistent inherited;
	
private:
	int FAnswerCode;
	AnsiString FContentEncoding;
	AnsiString FContentMD5;
	int FContentLength;
	AnsiString FLocation;
	AnsiString FSessionId;
	AnsiString FCookie;
	
public:
	__fastcall TfrxHTTPServerFields(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property int AnswerCode = {read=FAnswerCode, write=FAnswerCode, nodefault};
	__property AnsiString ContentEncoding = {read=FContentEncoding, write=FContentEncoding};
	__property AnsiString ContentMD5 = {read=FContentMD5, write=FContentMD5};
	__property int ContentLength = {read=FContentLength, write=FContentLength, nodefault};
	__property AnsiString Location = {read=FLocation, write=FLocation};
	__property AnsiString SessionId = {read=FSessionId, write=FSessionId};
	__property AnsiString Cookie = {read=FCookie, write=FCookie};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TfrxHTTPServerFields(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxClientThread;
class PASCALIMPLEMENTATION TfrxClientThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
protected:
	TfrxHTTPClient* FClient;
	void __fastcall DoOpen(void);
	virtual void __fastcall Execute(void);
	
public:
	Scktcomp::TClientSocket* FSocket;
	__fastcall TfrxClientThread(TfrxHTTPClient* Client);
	__fastcall virtual ~TfrxClientThread(void);
};


class PASCALIMPLEMENTATION TfrxHTTPClient : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	bool FActive;
	Classes::TStrings* FAnswer;
	bool FBreaked;
	TfrxHTTPClientFields* FClientFields;
	Classes::TStrings* FErrors;
	Classes::TStrings* FHeader;
	AnsiString FHost;
	bool FMIC;
	int FPort;
	AnsiString FProxyHost;
	int FProxyPort;
	int FRetryCount;
	int FRetryTimeOut;
	TfrxHTTPServerFields* FServerFields;
	Classes::TMemoryStream* FStream;
	Classes::TMemoryStream* FTempStream;
	TfrxClientThread* FThread;
	int FTimeOut;
	AnsiString FProxyLogin;
	AnsiString FProxyPassword;
	unsigned FConnectDelay;
	unsigned FAnswerDelay;
	void __fastcall DoConnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoDisconnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoError(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket, Scktcomp::TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall DoRead(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall SetActive(const bool Value);
	void __fastcall SetClientFields(const TfrxHTTPClientFields* Value);
	void __fastcall SetServerFields(const TfrxHTTPServerFields* Value);
	
public:
	Classes::TThread* ParentThread;
	unsigned StreamSize;
	__fastcall virtual TfrxHTTPClient(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxHTTPClient(void);
	void __fastcall Connect(void);
	void __fastcall Disconnect(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	__property Classes::TStrings* Answer = {read=FAnswer, write=FAnswer};
	__property bool Breaked = {read=FBreaked, nodefault};
	__property Classes::TStrings* Errors = {read=FErrors, write=FErrors};
	__property Classes::TStrings* Header = {read=FHeader, write=FHeader};
	__property Classes::TMemoryStream* Stream = {read=FStream, write=FStream};
	
__published:
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property TfrxHTTPClientFields* ClientFields = {read=FClientFields, write=SetClientFields};
	__property AnsiString Host = {read=FHost, write=FHost};
	__property bool MIC = {read=FMIC, write=FMIC, nodefault};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property AnsiString ProxyHost = {read=FProxyHost, write=FProxyHost};
	__property int ProxyPort = {read=FProxyPort, write=FProxyPort, nodefault};
	__property AnsiString ProxyLogin = {read=FProxyLogin, write=FProxyLogin};
	__property AnsiString ProxyPassword = {read=FProxyPassword, write=FProxyPassword};
	__property int RetryCount = {read=FRetryCount, write=FRetryCount, nodefault};
	__property int RetryTimeOut = {read=FRetryTimeOut, write=FRetryTimeOut, nodefault};
	__property TfrxHTTPServerFields* ServerFields = {read=FServerFields, write=SetServerFields};
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, nodefault};
	__property unsigned ConnectDelay = {read=FConnectDelay, nodefault};
	__property unsigned AnswerDelay = {read=FAnswerDelay, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxhttpclient */
using namespace Frxhttpclient;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxHTTPClient
