// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerLog.pas' rev: 6.00

#ifndef frxServerLogHPP
#define frxServerLogHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxNetUtils.hpp>	// Pascal unit
#include <frxServerUtils.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <SyncObjs.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverlog
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxServerLog;
class PASCALIMPLEMENTATION TfrxServerLog : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	int FCurrentReports;
	int FCurrentSessions;
	int FErrorsCount;
	Classes::TStringList* FLevelFName;
	Classes::TList* FLevels;
	AnsiString FLogDir;
	bool FLogging;
	int FMaxReports;
	int FMaxReportTime;
	int FMaxSessions;
	int FTotalReports;
	int FTotalReportTime;
	int FTotalSessions;
	int FMaxLogSize;
	int FMaxLogFiles;
	Syncobjs::TCriticalSection* FCS;
	int FTotalCacheHits;
	bool FThreadActive;
	void __fastcall WriteFile(const AnsiString FName, const AnsiString Text);
	void __fastcall LogRotate(const AnsiString FName);
	void __fastcall SetCurrentReports(int Value);
	void __fastcall SetCurrentSessions(int Value);
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TfrxServerLog(void);
	__fastcall virtual ~TfrxServerLog(void);
	int __fastcall AddLevel(const AnsiString FileName);
	void __fastcall Clear(void);
	void __fastcall Flush(void);
	void __fastcall ErrorReached(void);
	void __fastcall StartAddReportTime(int i);
	void __fastcall StatAddCurrentReport(void);
	void __fastcall StatAddCurrentSession(void);
	void __fastcall StatAddCacheHit(void);
	void __fastcall StatAddReports(int i);
	void __fastcall StatAddSessions(int i);
	void __fastcall StatRemoveCurrentReport(void);
	void __fastcall StatRemoveCurrentSession(void);
	void __fastcall Write(const int Level, const AnsiString Msg);
	__property bool Active = {read=FLogging, write=FLogging, nodefault};
	__property int CurrentReports = {read=FCurrentReports, write=SetCurrentReports, nodefault};
	__property int CurrentSessions = {read=FCurrentSessions, write=SetCurrentSessions, nodefault};
	__property int ErrorsCount = {read=FErrorsCount, write=FErrorsCount, nodefault};
	__property AnsiString LogDir = {read=FLogDir, write=FLogDir};
	__property int MaxReports = {read=FMaxReports, write=FMaxReports, nodefault};
	__property int MaxReportTime = {read=FMaxReportTime, write=FMaxReportTime, nodefault};
	__property int MaxSessions = {read=FMaxSessions, write=FMaxSessions, nodefault};
	__property int TotalReports = {read=FTotalReports, write=FTotalReports, nodefault};
	__property int TotalReportTime = {read=FTotalReportTime, write=FTotalReportTime, nodefault};
	__property int TotalSessions = {read=FTotalSessions, write=FTotalSessions, nodefault};
	__property int MaxLogSize = {read=FMaxLogSize, write=FMaxLogSize, nodefault};
	__property int MaxLogFiles = {read=FMaxLogFiles, write=FMaxLogFiles, nodefault};
	__property int TotalCacheHits = {read=FTotalCacheHits, write=FTotalCacheHits, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxServerLog* LogWriter;
static const Shortint ERROR_LEVEL = 0x0;
static const Shortint ACCESS_LEVEL = 0x1;
static const Shortint REFERER_LEVEL = 0x2;
static const Shortint AGENT_LEVEL = 0x3;
static const Shortint SERVER_LEVEL = 0x4;
static const Shortint SCHEDULER_LEVEL = 0x5;

}	/* namespace Frxserverlog */
using namespace Frxserverlog;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerLog
