// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxRes.pas' rev: 6.00

#ifndef frxResHPP
#define frxResHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxres
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxResources;
class PASCALIMPLEMENTATION TfrxResources : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Controls::TImageList* FDisabledButtonImages;
	Controls::TImageList* FMainButtonImages;
	Classes::TStringList* FNames;
	Controls::TImageList* FObjectImages;
	Controls::TImageList* FPreviewButtonImages;
	Frxunicodeutils::TWideStrings* FValues;
	Controls::TImageList* FWizardImages;
	Classes::TStringList* FLanguages;
	AnsiString FHelpFile;
	unsigned FCP;
	void __fastcall BuildLanguagesList(void);
	Controls::TImageList* __fastcall GetMainButtonImages(void);
	Controls::TImageList* __fastcall GetObjectImages(void);
	Controls::TImageList* __fastcall GetPreviewButtonImages(void);
	Controls::TImageList* __fastcall GetWizardImages(void);
	
public:
	__fastcall TfrxResources(void);
	__fastcall virtual ~TfrxResources(void);
	AnsiString __fastcall Get(const AnsiString StrName);
	void __fastcall Add(const AnsiString Ref, const AnsiString Str);
	void __fastcall AddW(const AnsiString Ref, WideString Str);
	void __fastcall AddStrings(const AnsiString Str);
	void __fastcall AddXML(const AnsiString Str);
	void __fastcall Clear(void);
	void __fastcall LoadFromFile(const AnsiString FileName);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
	void __fastcall SetButtonImages(Graphics::TBitmap* Images, bool Clear = false);
	void __fastcall SetObjectImages(Graphics::TBitmap* Images, bool Clear = false);
	void __fastcall SetPreviewButtonImages(Graphics::TBitmap* Images, bool Clear = false);
	void __fastcall SetWizardImages(Graphics::TBitmap* Images, bool Clear = false);
	void __fastcall UpdateFSResources(void);
	void __fastcall Help(System::TObject* Sender)/* overload */;
	__property Controls::TImageList* DisabledButtonImages = {read=FDisabledButtonImages};
	__property Controls::TImageList* MainButtonImages = {read=GetMainButtonImages};
	__property Controls::TImageList* PreviewButtonImages = {read=GetPreviewButtonImages};
	__property Controls::TImageList* ObjectImages = {read=GetObjectImages};
	__property Controls::TImageList* WizardImages = {read=GetWizardImages};
	__property Classes::TStringList* Languages = {read=FLanguages};
	__property AnsiString HelpFile = {read=FHelpFile, write=FHelpFile};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxResources* __fastcall frxResources(void);
extern PACKAGE AnsiString __fastcall frxGet(int ID);

}	/* namespace Frxres */
using namespace Frxres;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxRes
