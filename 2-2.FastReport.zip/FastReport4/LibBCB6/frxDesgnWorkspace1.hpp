// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxDesgnWorkspace1.pas' rev: 6.00

#ifndef frxDesgnWorkspace1HPP
#define frxDesgnWorkspace1HPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxPopupForm.hpp>	// Pascal unit
#include <frxDesgnWorkspace.hpp>	// Pascal unit
#include <frxDesgn.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxdesgnworkspace1
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxDesignTool { dtSelect, dtHand, dtZoom, dtText, dtFormat };
#pragma option pop

class DELPHICLASS TfrxGuideItem;
class PASCALIMPLEMENTATION TfrxGuideItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	Extended Left;
	Extended Top;
	Extended Right;
	Extended Bottom;
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxGuideItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxGuideItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxVirtualGuides;
class PASCALIMPLEMENTATION TfrxVirtualGuides : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxGuideItem* operator[](int Index) { return Items[Index]; }
	
private:
	TfrxGuideItem* __fastcall GetGuides(int Index);
	
public:
	__fastcall TfrxVirtualGuides(void);
	HIDESBASE void __fastcall Add(Extended Left, Extended Top, Extended Right, Extended Bottom);
	__property TfrxGuideItem* Items[int Index] = {read=GetGuides/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxVirtualGuides(void) { }
	#pragma option pop
	
};


class DELPHICLASS TDesignerWorkspace;
class PASCALIMPLEMENTATION TDesignerWorkspace : public Frxdesgnworkspace::TfrxDesignerWorkspace 
{
	typedef Frxdesgnworkspace::TfrxDesignerWorkspace inherited;
	
private:
	Frxdesgn::TfrxDesignerForm* FDesigner;
	int FGuide;
	Stdctrls::TListBox* FListBox;
	Frxclass::TfrxMemoView* FMemo;
	Frxpopupform::TfrxPopupForm* FPopupForm;
	bool FPopupFormVisible;
	bool FShowGuides;
	bool FSimulateMove;
	TfrxDesignTool FTool;
	TfrxVirtualGuides* FVirtualGuides;
	Classes::TList* FVirtualGuideObjects;
	void __fastcall DoLBClick(System::TObject* Sender);
	void __fastcall DoPopupHide(System::TObject* Sender);
	void __fastcall CreateVirtualGuides(void);
	void __fastcall LBDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &ARect, Windows::TOwnerDrawState State);
	void __fastcall SetShowGuides(const bool Value);
	void __fastcall SetHGuides(const Classes::TStrings* Value);
	void __fastcall SetVGuides(const Classes::TStrings* Value);
	Classes::TStrings* __fastcall GetHGuides(void);
	Classes::TStrings* __fastcall GetVGuides(void);
	__property Classes::TStrings* HGuides = {read=GetHGuides, write=SetHGuides};
	__property Classes::TStrings* VGuides = {read=GetVGuides, write=SetVGuides};
	void __fastcall SetTool(const TfrxDesignTool Value);
	
protected:
	virtual void __fastcall CheckGuides(Extended &kx, Extended &ky, bool &Result);
	DYNAMIC void __fastcall DragOver(System::TObject* Source, int X, int Y, Controls::TDragState State, bool &Accept);
	virtual void __fastcall DrawObjects(void);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall DblClick(void);
	
public:
	__fastcall virtual TDesignerWorkspace(Classes::TComponent* AOwner);
	__fastcall virtual ~TDesignerWorkspace(void);
	virtual void __fastcall DeleteObjects(void);
	DYNAMIC void __fastcall DragDrop(System::TObject* Source, int X, int Y);
	void __fastcall SimulateMove(void);
	virtual void __fastcall SetInsertion(TMetaClass* AClass, Extended AWidth, Extended AHeight, Word AFlag);
	__property bool ShowGuides = {read=FShowGuides, write=SetShowGuides, nodefault};
	__property TfrxDesignTool Tool = {read=FTool, write=SetTool, nodefault};
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TDesignerWorkspace(HWND ParentWindow) : Frxdesgnworkspace::TfrxDesignerWorkspace(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxdesgnworkspace1 */
using namespace Frxdesgnworkspace1;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxDesgnWorkspace1
