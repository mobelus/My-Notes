// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxOLE.pas' rev: 6.00

#ifndef frxOLEHPP
#define frxOLEHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <ActiveX.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <OleCtnrs.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxole
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxSizeMode { fsmClip, fsmScale };
#pragma option pop

class DELPHICLASS TfrxOLEObject;
class PASCALIMPLEMENTATION TfrxOLEObject : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfrxOLEObject(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxOLEObject(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxOLEView;
class PASCALIMPLEMENTATION TfrxOLEView : public Frxclass::TfrxView 
{
	typedef Frxclass::TfrxView inherited;
	
private:
	Olectnrs::TOleContainer* FOleContainer;
	TfrxSizeMode FSizeMode;
	bool FStretched;
	void __fastcall ReadData(Classes::TStream* Stream);
	void __fastcall SetStretched(const bool Value);
	void __fastcall WriteData(Classes::TStream* Stream);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	
public:
	__fastcall virtual TfrxOLEView(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxOLEView(void);
	virtual void __fastcall Draw(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	virtual void __fastcall GetData(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	__property Olectnrs::TOleContainer* OleContainer = {read=FOleContainer};
	
__published:
	__property BrushStyle  = {default=0};
	__property Color  = {default=536870911};
	__property Cursor  = {default=0};
	__property DataField ;
	__property DataSet ;
	__property DataSetName ;
	__property Frame ;
	__property TfrxSizeMode SizeMode = {read=FSizeMode, write=FSizeMode, default=0};
	__property bool Stretched = {read=FStretched, write=SetStretched, default=0};
	__property TagStr ;
	__property URL ;
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxOLEView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxView(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall frxAssignOle(Olectnrs::TOleContainer* ContFrom, Olectnrs::TOleContainer* ContTo);

}	/* namespace Frxole */
using namespace Frxole;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxOLE
