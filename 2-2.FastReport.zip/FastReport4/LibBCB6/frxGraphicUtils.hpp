// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxGraphicUtils.pas' rev: 6.00

#ifndef frxGraphicUtilsHPP
#define frxGraphicUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------
#undef NewLine

namespace Frxgraphicutils
{
//-- type declarations -------------------------------------------------------
typedef int TIntArray[536870911];

typedef int *PIntArray;

class DELPHICLASS TfrxHTMLTag;
class PASCALIMPLEMENTATION TfrxHTMLTag : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	int Position;
	int Size;
	int AddY;
	Graphics::TFontStyles Style;
	int Color;
	bool Default;
	bool Small;
	bool DontWRAP;
	void __fastcall Assign(TfrxHTMLTag* Tag);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxHTMLTag(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxHTMLTag(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxHTMLTags;
class PASCALIMPLEMENTATION TfrxHTMLTags : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TfrxHTMLTag* operator[](int Index) { return Items[Index]; }
	
private:
	Classes::TList* FItems;
	void __fastcall Add(TfrxHTMLTag* Tag);
	TfrxHTMLTag* __fastcall GetItems(int Index);
	
public:
	__fastcall TfrxHTMLTags(void);
	__fastcall virtual ~TfrxHTMLTags(void);
	void __fastcall Clear(void);
	int __fastcall Count(void);
	__property TfrxHTMLTag* Items[int Index] = {read=GetItems/*, default*/};
};


class DELPHICLASS TfrxHTMLTagsList;
class PASCALIMPLEMENTATION TfrxHTMLTagsList : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TfrxHTMLTags* operator[](int Index) { return Items[Index]; }
	
private:
	bool FAllowTags;
	int FAddY;
	int FColor;
	int FDefColor;
	int FDefSize;
	Graphics::TFontStyles FDefStyle;
	Classes::TList* FItems;
	int FPosition;
	int FSize;
	Graphics::TFontStyles FStyle;
	bool FDontWRAP;
	int *FTempArray;
	void __fastcall NewLine(void);
	void __fastcall Wrap(int TagsCount, bool AddBreak);
	TfrxHTMLTag* __fastcall Add(void);
	int __fastcall FillCharSpacingArray(PIntArray &ar, const WideString s, Graphics::TCanvas* Canvas, int LineIndex, int Add, bool Convert, bool DefCharset);
	TfrxHTMLTags* __fastcall GetItems(int Index);
	TfrxHTMLTag* __fastcall GetPrevTag(void);
	
public:
	__fastcall TfrxHTMLTagsList(void);
	__fastcall virtual ~TfrxHTMLTagsList(void);
	void __fastcall Clear(void);
	void __fastcall SetDefaults(Graphics::TColor DefColor, int DefSize, Graphics::TFontStyles DefStyle);
	void __fastcall ExpandHTMLTags(WideString &s);
	int __fastcall Count(void);
	__property bool AllowTags = {read=FAllowTags, write=FAllowTags, nodefault};
	__property TfrxHTMLTags* Items[int Index] = {read=GetItems/*, default*/};
	__property int Position = {read=FPosition, write=FPosition, nodefault};
};


class DELPHICLASS TfrxDrawText;
class PASCALIMPLEMENTATION TfrxDrawText : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Graphics::TBitmap* FBMP;
	Graphics::TCanvas* FCanvas;
	int FDefPPI;
	int FScrPPI;
	int *FTempArray;
	int FFontSize;
	TfrxHTMLTagsList* FHTMLTags;
	Extended FCharSpacing;
	Extended FLineSpacing;
	int FOptions;
	#pragma pack(push, 1)
	Types::TRect FOriginalRect;
	#pragma pack(pop)
	
	Extended FParagraphGap;
	WideString FPlainText;
	Extended FPrintScale;
	int FRotation;
	bool FRTLReading;
	#pragma pack(push, 1)
	Types::TRect FScaledRect;
	#pragma pack(pop)
	
	Extended FScaleX;
	Extended FScaleY;
	Frxunicodeutils::TWideStrings* FText;
	bool FWordBreak;
	bool FWordWrap;
	bool FWysiwyg;
	bool FUseDefaultCharset;
	WideString __fastcall GetWrappedText();
	bool __fastcall IsPrinter(Graphics::TCanvas* C);
	void __fastcall DrawTextLine(Graphics::TCanvas* C, const WideString s, int X, int Y, int DX, int LineIndex, Frxclass::TfrxHAlign Align, HFONT &fh, HFONT &oldfh);
	void __fastcall WrapTextLine(WideString s, int Width, int FirstLineWidth, int CharSpacing);
	
public:
	__fastcall TfrxDrawText(void);
	__fastcall virtual ~TfrxDrawText(void);
	void __fastcall SetFont(Graphics::TFont* Font);
	void __fastcall SetOptions(bool WordWrap, bool HTMLTags, bool RTLReading, bool WordBreak, bool Clipped, bool Wysiwyg, int Rotation);
	void __fastcall SetGaps(Extended ParagraphGap, Extended CharSpacing, Extended LineSpacing);
	void __fastcall SetDimensions(Extended ScaleX, Extended ScaleY, Extended PrintScale, const Types::TRect &OriginalRect, const Types::TRect &ScaledRect);
	void __fastcall SetText(Frxunicodeutils::TWideStrings* Text);
	void __fastcall SetParaBreaks(bool FirstParaBreak, bool LastParaBreak);
	WideString __fastcall DeleteTags(const WideString Txt);
	void __fastcall DrawText(Graphics::TCanvas* C, Frxclass::TfrxHAlign HAlign, Frxclass::TfrxVAlign VAlign);
	Extended __fastcall CalcHeight(void);
	Extended __fastcall CalcWidth(void);
	Extended __fastcall LineHeight(void);
	Extended __fastcall TextHeight(void);
	WideString __fastcall GetInBoundsText();
	WideString __fastcall GetOutBoundsText(bool &ParaBreak);
	Extended __fastcall UnusedSpace(void);
	void __fastcall Lock(void);
	void __fastcall Unlock(void);
	__property Graphics::TCanvas* Canvas = {read=FCanvas};
	__property int DefPPI = {read=FDefPPI, nodefault};
	__property int ScrPPI = {read=FScrPPI, nodefault};
	__property WideString WrappedText = {read=GetWrappedText};
	__property bool UseDefaultCharset = {read=FUseDefaultCharset, write=FUseDefaultCharset, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxDrawText* frxDrawText;

}	/* namespace Frxgraphicutils */
using namespace Frxgraphicutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxGraphicUtils
