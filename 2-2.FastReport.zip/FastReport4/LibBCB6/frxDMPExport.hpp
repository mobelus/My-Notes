// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxDMPExport.pas' rev: 6.00

#ifndef frxDMPExportHPP
#define frxDMPExportHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <frxDMPClass.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxdmpexport
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TfrxTranslateEvent)(System::TObject* Sender, AnsiString &s);

typedef DynamicArray<char >  frxDMPExport__2;

typedef DynamicArray<Byte >  frxDMPExport__3;

typedef DynamicArray<int >  frxDMPExport__4;

class DELPHICLASS TfrxDotMatrixExport;
class PASCALIMPLEMENTATION TfrxDotMatrixExport : public Frxclass::TfrxCustomExportFilter 
{
	typedef Frxclass::TfrxCustomExportFilter inherited;
	
private:
	int FBufWidth;
	int FBufHeight;
	DynamicArray<char >  FCharBuf;
	int FCopies;
	AnsiString FCustomFrameSet;
	int FEscModel;
	DynamicArray<Byte >  FFrameBuf;
	bool FGraphicFrames;
	int FMaxHeight;
	bool FOEMConvert;
	bool FPageBreaks;
	int FPageStyle;
	AnsiString FPrinterInitString;
	bool FSaveToFile;
	Classes::TStream* FStream;
	DynamicArray<int >  FStyleBuf;
	bool FUseIniSettings;
	TfrxTranslateEvent FOnTranslate;
	AnsiString __fastcall GetTempFName();
	Frxdmpclass::TfrxDMPFontStyles __fastcall IntToStyle(int i);
	AnsiString __fastcall StyleChange(int OldStyle, int NewStyle);
	AnsiString __fastcall StyleOff(int Style);
	AnsiString __fastcall StyleOn(int Style);
	int __fastcall StyleToInt(Frxdmpclass::TfrxDMPFontStyles Style);
	void __fastcall CreateBuf(int Width, int Height);
	void __fastcall DrawFrame(int x, int y, int dx, int dy, int Style);
	void __fastcall DrawMemo(int x, int y, int dx, int dy, Frxdmpclass::TfrxDMPMemoView* Memo);
	void __fastcall FlushBuf(void);
	void __fastcall FormFeed(void);
	void __fastcall FreeBuf(void);
	void __fastcall Landscape(void);
	void __fastcall Portrait(void);
	void __fastcall Reset(void);
	void __fastcall SetFrame(int x, int y, Byte typ);
	void __fastcall SetString(int x, int y, AnsiString s);
	void __fastcall SetStyle(int x, int y, int Style);
	void __fastcall SpoolFile(const AnsiString FileName);
	void __fastcall WriteStrLn(const AnsiString str);
	void __fastcall WriteStr(const AnsiString str);
	
public:
	__fastcall virtual TfrxDotMatrixExport(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxDotMatrixExport(void);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	virtual bool __fastcall Start(void);
	virtual void __fastcall ExportObject(Frxclass::TfrxComponent* Obj);
	virtual void __fastcall Finish(void);
	virtual void __fastcall FinishPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall StartPage(Frxclass::TfrxReportPage* Page, int Index);
	
__published:
	__property AnsiString CustomFrameSet = {read=FCustomFrameSet, write=FCustomFrameSet};
	__property int EscModel = {read=FEscModel, write=FEscModel, nodefault};
	__property bool GraphicFrames = {read=FGraphicFrames, write=FGraphicFrames, nodefault};
	__property AnsiString InitString = {read=FPrinterInitString, write=FPrinterInitString};
	__property bool OEMConvert = {read=FOEMConvert, write=FOEMConvert, default=1};
	__property bool PageBreaks = {read=FPageBreaks, write=FPageBreaks, default=1};
	__property bool SaveToFile = {read=FSaveToFile, write=FSaveToFile, nodefault};
	__property bool UseIniSettings = {read=FUseIniSettings, write=FUseIniSettings, nodefault};
	__property TfrxTranslateEvent OnTranslate = {read=FOnTranslate, write=FOnTranslate};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxDotMatrixExport(void) : Frxclass::TfrxCustomExportFilter() { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDMPExportDialog;
class PASCALIMPLEMENTATION TfrxDMPExportDialog : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OK;
	Stdctrls::TButton* Cancel;
	Dialogs::TSaveDialog* SaveDialog1;
	Extctrls::TImage* Image1;
	Stdctrls::TGroupBox* PrinterL;
	Stdctrls::TComboBox* PrinterCB;
	Stdctrls::TGroupBox* EscL;
	Stdctrls::TComboBox* EscCB;
	Stdctrls::TGroupBox* CopiesL;
	Stdctrls::TLabel* CopiesNL;
	Stdctrls::TEdit* CopiesE;
	Comctrls::TUpDown* CopiesUD;
	Stdctrls::TGroupBox* PagesL;
	Stdctrls::TLabel* DescrL;
	Stdctrls::TRadioButton* AllRB;
	Stdctrls::TRadioButton* CurPageRB;
	Stdctrls::TRadioButton* PageNumbersRB;
	Stdctrls::TEdit* RangeE;
	Stdctrls::TGroupBox* OptionsL;
	Stdctrls::TCheckBox* SaveToFileCB;
	Stdctrls::TCheckBox* PageBreaksCB;
	Stdctrls::TCheckBox* OemCB;
	Stdctrls::TCheckBox* PseudoCB;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall PrinterCBDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &ARect, Windows::TOwnerDrawState State);
	void __fastcall PrinterCBClick(System::TObject* Sender);
	void __fastcall FormHide(System::TObject* Sender);
	void __fastcall RangeEEnter(System::TObject* Sender);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	
private:
	int OldIndex;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxDMPExportDialog(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxDMPExportDialog(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxDMPExportDialog(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxDMPExportDialog(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


typedef AnsiString frxDMPExport__6[23];

typedef AnsiString frxDMPExport__8[23];

class DELPHICLASS TfrxDMPrinter;
class PASCALIMPLEMENTATION TfrxDMPrinter : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
public:
	AnsiString Commands[23];
	virtual void __fastcall Assign(Classes::TPersistent* Source);
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxDMPrinter(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxDMPrinter(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDMPrinters;
class PASCALIMPLEMENTATION TfrxDMPrinters : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxDMPrinter* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE TfrxDMPrinter* __fastcall GetItem(int Index);
	
public:
	__fastcall TfrxDMPrinters(void);
	HIDESBASE TfrxDMPrinter* __fastcall Add(void);
	void __fastcall ReadDefaultPrinters(void);
	void __fastcall ReadExtPrinters(void);
	void __fastcall ReadPrinters(Frxxml::TfrxXMLDocument* x);
	__property TfrxDMPrinter* Items[int Index] = {read=GetItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxDMPrinters(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint cmdName = 0x1;
static const Shortint cmdReset = 0x2;
static const Shortint cmdFormFeed = 0x3;
static const Shortint cmdLandscape = 0x4;
static const Shortint cmdPortrait = 0x5;
static const Shortint cmdBoldOn = 0x6;
static const Shortint cmdBoldOff = 0x7;
static const Shortint cmdItalicOn = 0x8;
static const Shortint cmdItalicOff = 0x9;
static const Shortint cmdUnderlineOn = 0xa;
static const Shortint cmdUnderlineOff = 0xb;
static const Shortint cmdSuperscriptOn = 0xc;
static const Shortint cmdSuperscriptOff = 0xd;
static const Shortint cmdSubscriptOn = 0xe;
static const Shortint cmdSubscriptOff = 0xf;
static const Shortint cmdCondensedOn = 0x10;
static const Shortint cmdCondensedOff = 0x11;
static const Shortint cmdWideOn = 0x12;
static const Shortint cmdWideOff = 0x13;
static const Shortint cmd12cpiOn = 0x14;
static const Shortint cmd12cpiOff = 0x15;
static const Shortint cmd15cpiOn = 0x16;
static const Shortint cmd15cpiOff = 0x17;
static const Shortint CommandCount = 0x17;
extern PACKAGE AnsiString CommandNames[23];
extern PACKAGE TfrxDMPrinters* frxDMPrinters;

}	/* namespace Frxdmpexport */
using namespace Frxdmpexport;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxDMPExport
