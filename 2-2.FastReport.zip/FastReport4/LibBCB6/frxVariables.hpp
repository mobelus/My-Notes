// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxVariables.pas' rev: 6.00

#ifndef frxVariablesHPP
#define frxVariablesHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxvariables
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxVariable;
class PASCALIMPLEMENTATION TfrxVariable : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	AnsiString FName;
	Variant FValue;
	
public:
	__fastcall virtual TfrxVariable(Classes::TCollection* Collection);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property AnsiString Name = {read=FName, write=FName};
	__property Variant Value = {read=FValue, write=FValue};
public:
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxVariable(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxVariables;
class PASCALIMPLEMENTATION TfrxVariables : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	Variant operator[](AnsiString Index) { return Variables[Index]; }
	
private:
	TfrxVariable* __fastcall GetItems(int Index);
	Variant __fastcall GetVariable(AnsiString Index);
	void __fastcall SetVariable(AnsiString Index, const Variant &Value);
	
public:
	__fastcall TfrxVariables(void);
	HIDESBASE TfrxVariable* __fastcall Add(void);
	HIDESBASE TfrxVariable* __fastcall Insert(int Index);
	int __fastcall IndexOf(const AnsiString Name);
	void __fastcall AddVariable(const AnsiString ACategory, const AnsiString AName, const Variant &AValue);
	void __fastcall DeleteCategory(const AnsiString Name);
	void __fastcall DeleteVariable(const AnsiString Name);
	void __fastcall GetCategoriesList(Classes::TStrings* List, bool ClearList = true);
	void __fastcall GetVariablesList(const AnsiString Category, Classes::TStrings* List);
	void __fastcall LoadFromFile(const AnsiString FileName);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
	void __fastcall LoadFromXMLItem(Frxxml::TfrxXMLItem* Item, bool OldXMLFormat = true);
	void __fastcall SaveToFile(const AnsiString FileName);
	void __fastcall SaveToStream(Classes::TStream* Stream);
	void __fastcall SaveToXMLItem(Frxxml::TfrxXMLItem* Item);
	__property TfrxVariable* Items[int Index] = {read=GetItems};
	__property Variant Variables[AnsiString Index] = {read=GetVariable, write=SetVariable/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxVariables(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxArray;
class PASCALIMPLEMENTATION TfrxArray : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	Variant operator[](Variant Index) { return Variables[Index]; }
	
private:
	TfrxVariable* __fastcall GetItems(int Index);
	Variant __fastcall GetVariable(const Variant &Index);
	void __fastcall SetVariable(const Variant &Index, const Variant &Value);
	
public:
	__fastcall TfrxArray(void);
	int __fastcall IndexOf(const Variant &Name);
	__property TfrxVariable* Items[int Index] = {read=GetItems};
	__property Variant Variables[Variant Index] = {read=GetVariable, write=SetVariable/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxArray(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxvariables */
using namespace Frxvariables;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxVariables
