// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'rc_AlgRef.pas' rev: 6.00

#ifndef rc_AlgRefHPP
#define rc_AlgRefHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Rc_algref
{
//-- type declarations -------------------------------------------------------
typedef Byte word8;

typedef Word word16;

typedef unsigned word32;

typedef Byte TArrayK[4][8];

typedef Byte *PArrayK;

typedef Byte TArrayRK[15][4][8];

typedef Byte TArrayBox[256];

//-- var, const, procedure ---------------------------------------------------
static const Shortint MAXBC = 0x8;
static const Shortint MAXKC = 0x8;
static const Shortint MAXROUNDS = 0xe;
extern PACKAGE int __fastcall rijndaelKeySched(const Byte * k, int keyBits, int blockBits, Byte * W);
extern PACKAGE int __fastcall rijndaelEncrypt(Byte * a, int keyBits, int blockBits, const Byte * rk);
extern PACKAGE int __fastcall rijndaelEncryptRound(Byte * a, int keyBits, int blockBits, const Byte * rk, int &irounds);
extern PACKAGE int __fastcall rijndaelDecrypt(Byte * a, int keyBits, int blockBits, const Byte * rk);
extern PACKAGE int __fastcall rijndaelDecryptRound(Byte * a, int keyBits, int blockBits, const Byte * rk, int &irounds);

}	/* namespace Rc_algref */
using namespace Rc_algref;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// rc_AlgRef
