// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxpnglang.pas' rev: 6.00

#ifndef frxpnglangHPP
#define frxpnglangHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxpnglang
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::ResourceString _EPngInvalidCRCText;
#define Frxpnglang_EPngInvalidCRCText System::LoadResourceString(&Frxpnglang::_EPngInvalidCRCText)
extern PACKAGE System::ResourceString _EPNGInvalidIHDRText;
#define Frxpnglang_EPNGInvalidIHDRText System::LoadResourceString(&Frxpnglang::_EPNGInvalidIHDRText)
extern PACKAGE System::ResourceString _EPNGMissingMultipleIDATText;
#define Frxpnglang_EPNGMissingMultipleIDATText System::LoadResourceString(&Frxpnglang::_EPNGMissingMultipleIDATText)
extern PACKAGE System::ResourceString _EPNGZLIBErrorText;
#define Frxpnglang_EPNGZLIBErrorText System::LoadResourceString(&Frxpnglang::_EPNGZLIBErrorText)
extern PACKAGE System::ResourceString _EPNGInvalidPaletteText;
#define Frxpnglang_EPNGInvalidPaletteText System::LoadResourceString(&Frxpnglang::_EPNGInvalidPaletteText)
extern PACKAGE System::ResourceString _EPNGInvalidFileHeaderText;
#define Frxpnglang_EPNGInvalidFileHeaderText System::LoadResourceString(&Frxpnglang::_EPNGInvalidFileHeaderText)
extern PACKAGE System::ResourceString _EPNGIHDRNotFirstText;
#define Frxpnglang_EPNGIHDRNotFirstText System::LoadResourceString(&Frxpnglang::_EPNGIHDRNotFirstText)
extern PACKAGE System::ResourceString _EPNGNotExistsText;
#define Frxpnglang_EPNGNotExistsText System::LoadResourceString(&Frxpnglang::_EPNGNotExistsText)
extern PACKAGE System::ResourceString _EPNGSizeExceedsText;
#define Frxpnglang_EPNGSizeExceedsText System::LoadResourceString(&Frxpnglang::_EPNGSizeExceedsText)
extern PACKAGE System::ResourceString _EPNGUnknownPalEntryText;
#define Frxpnglang_EPNGUnknownPalEntryText System::LoadResourceString(&Frxpnglang::_EPNGUnknownPalEntryText)
extern PACKAGE System::ResourceString _EPNGMissingPaletteText;
#define Frxpnglang_EPNGMissingPaletteText System::LoadResourceString(&Frxpnglang::_EPNGMissingPaletteText)
extern PACKAGE System::ResourceString _EPNGUnknownCriticalChunkText;
#define Frxpnglang_EPNGUnknownCriticalChunkText System::LoadResourceString(&Frxpnglang::_EPNGUnknownCriticalChunkText)
extern PACKAGE System::ResourceString _EPNGUnknownCompressionText;
#define Frxpnglang_EPNGUnknownCompressionText System::LoadResourceString(&Frxpnglang::_EPNGUnknownCompressionText)
extern PACKAGE System::ResourceString _EPNGUnknownInterlaceText;
#define Frxpnglang_EPNGUnknownInterlaceText System::LoadResourceString(&Frxpnglang::_EPNGUnknownInterlaceText)
extern PACKAGE System::ResourceString _EPNGCannotAssignChunkText;
#define Frxpnglang_EPNGCannotAssignChunkText System::LoadResourceString(&Frxpnglang::_EPNGCannotAssignChunkText)
extern PACKAGE System::ResourceString _EPNGUnexpectedEndText;
#define Frxpnglang_EPNGUnexpectedEndText System::LoadResourceString(&Frxpnglang::_EPNGUnexpectedEndText)
extern PACKAGE System::ResourceString _EPNGNoImageDataText;
#define Frxpnglang_EPNGNoImageDataText System::LoadResourceString(&Frxpnglang::_EPNGNoImageDataText)
extern PACKAGE System::ResourceString _EPNGCannotAddChunkText;
#define Frxpnglang_EPNGCannotAddChunkText System::LoadResourceString(&Frxpnglang::_EPNGCannotAddChunkText)
extern PACKAGE System::ResourceString _EPNGCannotAddInvalidImageText;
#define Frxpnglang_EPNGCannotAddInvalidImageText System::LoadResourceString(&Frxpnglang::_EPNGCannotAddInvalidImageText)
extern PACKAGE System::ResourceString _EPNGCouldNotLoadResourceText;
#define Frxpnglang_EPNGCouldNotLoadResourceText System::LoadResourceString(&Frxpnglang::_EPNGCouldNotLoadResourceText)
extern PACKAGE System::ResourceString _EPNGOutMemoryText;
#define Frxpnglang_EPNGOutMemoryText System::LoadResourceString(&Frxpnglang::_EPNGOutMemoryText)
extern PACKAGE System::ResourceString _EPNGCannotChangeTransparentText;
#define Frxpnglang_EPNGCannotChangeTransparentText System::LoadResourceString(&Frxpnglang::_EPNGCannotChangeTransparentText)
extern PACKAGE System::ResourceString _EPNGHeaderNotPresentText;
#define Frxpnglang_EPNGHeaderNotPresentText System::LoadResourceString(&Frxpnglang::_EPNGHeaderNotPresentText)
extern PACKAGE System::ResourceString _EInvalidNewSize;
#define Frxpnglang_EInvalidNewSize System::LoadResourceString(&Frxpnglang::_EInvalidNewSize)
extern PACKAGE System::ResourceString _EInvalidSpec;
#define Frxpnglang_EInvalidSpec System::LoadResourceString(&Frxpnglang::_EInvalidSpec)

}	/* namespace Frxpnglang */
using namespace Frxpnglang;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxpnglang
