// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxXML.pas' rev: 6.00

#ifndef frxXMLHPP
#define frxXMLHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxxml
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxInvalidXMLException;
class PASCALIMPLEMENTATION TfrxInvalidXMLException : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall TfrxInvalidXMLException(const AnsiString Msg) : Sysutils::Exception(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall TfrxInvalidXMLException(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall TfrxInvalidXMLException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall TfrxInvalidXMLException(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall TfrxInvalidXMLException(const AnsiString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall TfrxInvalidXMLException(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall TfrxInvalidXMLException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall TfrxInvalidXMLException(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxInvalidXMLException(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxXMLItem;
class PASCALIMPLEMENTATION TfrxXMLItem : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TfrxXMLItem* operator[](int Index) { return Items[Index]; }
	
private:
	void *FData;
	Byte FHiOffset;
	Classes::TList* FItems;
	bool FLoaded;
	int FLoOffset;
	bool FModified;
	AnsiString FName;
	TfrxXMLItem* FParent;
	AnsiString FText;
	bool FUnloadable;
	AnsiString FValue;
	int __fastcall GetCount(void);
	TfrxXMLItem* __fastcall GetItems(int Index);
	__int64 __fastcall GetOffset(void);
	void __fastcall SetOffset(const __int64 Value);
	AnsiString __fastcall GetProp(AnsiString Index);
	void __fastcall SetProp(AnsiString Index, const AnsiString Value);
	
public:
	__fastcall TfrxXMLItem(void);
	__fastcall virtual ~TfrxXMLItem(void);
	void __fastcall AddItem(TfrxXMLItem* Item);
	void __fastcall Clear(void);
	void __fastcall InsertItem(int Index, TfrxXMLItem* Item);
	TfrxXMLItem* __fastcall Add(void);
	int __fastcall Find(const AnsiString Name);
	TfrxXMLItem* __fastcall FindItem(const AnsiString Name);
	int __fastcall IndexOf(TfrxXMLItem* Item);
	bool __fastcall PropExists(const AnsiString Index);
	TfrxXMLItem* __fastcall Root(void);
	void __fastcall DeleteProp(const AnsiString Index);
	__property int Count = {read=GetCount, nodefault};
	__property void * Data = {read=FData, write=FData};
	__property TfrxXMLItem* Items[int Index] = {read=GetItems/*, default*/};
	__property bool Loaded = {read=FLoaded, nodefault};
	__property bool Modified = {read=FModified, write=FModified, nodefault};
	__property AnsiString Name = {read=FName, write=FName};
	__property __int64 Offset = {read=GetOffset, write=SetOffset};
	__property TfrxXMLItem* Parent = {read=FParent};
	__property AnsiString Prop[AnsiString Index] = {read=GetProp, write=SetProp};
	__property AnsiString Text = {read=FText, write=FText};
	__property bool Unloadable = {read=FUnloadable, write=FUnloadable, nodefault};
	__property AnsiString Value = {read=FValue, write=FValue};
};


class DELPHICLASS TfrxXMLDocument;
class PASCALIMPLEMENTATION TfrxXMLDocument : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	bool FAutoIndent;
	TfrxXMLItem* FRoot;
	AnsiString FTempDir;
	AnsiString FTempFile;
	Classes::TStream* FTempStream;
	bool FTempFileCreated;
	bool FOldVersion;
	void __fastcall CreateTempFile(void);
	void __fastcall DeleteTempFile(void);
	
public:
	__fastcall TfrxXMLDocument(void);
	__fastcall virtual ~TfrxXMLDocument(void);
	void __fastcall Clear(void);
	void __fastcall LoadItem(TfrxXMLItem* Item);
	void __fastcall UnloadItem(TfrxXMLItem* Item);
	void __fastcall SaveToStream(Classes::TStream* Stream);
	void __fastcall LoadFromStream(Classes::TStream* Stream, bool AllowPartialLoading = false);
	void __fastcall SaveToFile(const AnsiString FileName);
	void __fastcall LoadFromFile(const AnsiString FileName);
	__property bool AutoIndent = {read=FAutoIndent, write=FAutoIndent, nodefault};
	__property TfrxXMLItem* Root = {read=FRoot};
	__property AnsiString TempDir = {read=FTempDir, write=FTempDir};
	__property bool OldVersion = {read=FOldVersion, nodefault};
};


class DELPHICLASS TfrxXMLReader;
class PASCALIMPLEMENTATION TfrxXMLReader : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	char *FBuffer;
	int FBufPos;
	int FBufEnd;
	__int64 FPosition;
	__int64 FSize;
	Classes::TStream* FStream;
	bool FOldFormat;
	void __fastcall SetPosition(const __int64 Value);
	void __fastcall ReadBuffer(void);
	void __fastcall ReadItem(AnsiString &Name, AnsiString &Text);
	
public:
	__fastcall TfrxXMLReader(Classes::TStream* Stream);
	__fastcall virtual ~TfrxXMLReader(void);
	void __fastcall RaiseException(void);
	void __fastcall ReadHeader(void);
	void __fastcall ReadRootItem(TfrxXMLItem* Item, bool ReadChildren = true);
	__property __int64 Position = {read=FPosition, write=SetPosition};
	__property __int64 Size = {read=FSize};
};


class DELPHICLASS TfrxXMLWriter;
class PASCALIMPLEMENTATION TfrxXMLWriter : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	bool FAutoIndent;
	AnsiString FBuffer;
	Classes::TStream* FStream;
	Classes::TStream* FTempStream;
	void __fastcall FlushBuffer(void);
	void __fastcall WriteLn(const AnsiString s);
	void __fastcall WriteItem(TfrxXMLItem* Item, int Level = 0x0);
	
public:
	__fastcall TfrxXMLWriter(Classes::TStream* Stream);
	void __fastcall WriteHeader(void);
	void __fastcall WriteRootItem(TfrxXMLItem* RootItem);
	__property Classes::TStream* TempStream = {read=FTempStream, write=FTempStream};
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxXMLWriter(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString __fastcall frxStrToXML(const AnsiString s);
extern PACKAGE AnsiString __fastcall frxXMLToStr(const AnsiString s);
extern PACKAGE AnsiString __fastcall frxValueToXML(const Variant &Value);

}	/* namespace Frxxml */
using namespace Frxxml;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxXML
