// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxChartHelpers.pas' rev: 6.00

#ifndef frxChartHelpersHPP
#define frxChartHelpersHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <ArrowCha.hpp>	// Pascal unit
#include <BubbleCh.hpp>	// Pascal unit
#include <TeeShape.hpp>	// Pascal unit
#include <GanttCh.hpp>	// Pascal unit
#include <TeCanvas.hpp>	// Pascal unit
#include <Series.hpp>	// Pascal unit
#include <Chart.hpp>	// Pascal unit
#include <TeEngine.hpp>	// Pascal unit
#include <TeeProcs.hpp>	// Pascal unit
#include <frxChart.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxcharthelpers
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxSeriesHelper;
class PASCALIMPLEMENTATION TfrxSeriesHelper : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	virtual AnsiString __fastcall GetParamNames(void) = 0 ;
	virtual void __fastcall AddValues(Teengine::TChartSeries* Series, const AnsiString v1, const AnsiString v2, const AnsiString v3, const AnsiString v4, const AnsiString v5, const AnsiString v6, Frxchart::TfrxSeriesXType XType) = 0 ;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxSeriesHelper(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxSeriesHelper(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxStdSeriesHelper;
class PASCALIMPLEMENTATION TfrxStdSeriesHelper : public TfrxSeriesHelper 
{
	typedef TfrxSeriesHelper inherited;
	
public:
	virtual AnsiString __fastcall GetParamNames();
	virtual void __fastcall AddValues(Teengine::TChartSeries* Series, const AnsiString v1, const AnsiString v2, const AnsiString v3, const AnsiString v4, const AnsiString v5, const AnsiString v6, Frxchart::TfrxSeriesXType XType);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxStdSeriesHelper(void) : TfrxSeriesHelper() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxStdSeriesHelper(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPieSeriesHelper;
class PASCALIMPLEMENTATION TfrxPieSeriesHelper : public TfrxSeriesHelper 
{
	typedef TfrxSeriesHelper inherited;
	
public:
	virtual AnsiString __fastcall GetParamNames();
	virtual void __fastcall AddValues(Teengine::TChartSeries* Series, const AnsiString v1, const AnsiString v2, const AnsiString v3, const AnsiString v4, const AnsiString v5, const AnsiString v6, Frxchart::TfrxSeriesXType XType);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxPieSeriesHelper(void) : TfrxSeriesHelper() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxPieSeriesHelper(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxGanttSeriesHelper;
class PASCALIMPLEMENTATION TfrxGanttSeriesHelper : public TfrxSeriesHelper 
{
	typedef TfrxSeriesHelper inherited;
	
public:
	virtual AnsiString __fastcall GetParamNames();
	virtual void __fastcall AddValues(Teengine::TChartSeries* Series, const AnsiString v1, const AnsiString v2, const AnsiString v3, const AnsiString v4, const AnsiString v5, const AnsiString v6, Frxchart::TfrxSeriesXType XType);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxGanttSeriesHelper(void) : TfrxSeriesHelper() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxGanttSeriesHelper(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxArrowSeriesHelper;
class PASCALIMPLEMENTATION TfrxArrowSeriesHelper : public TfrxSeriesHelper 
{
	typedef TfrxSeriesHelper inherited;
	
public:
	virtual AnsiString __fastcall GetParamNames();
	virtual void __fastcall AddValues(Teengine::TChartSeries* Series, const AnsiString v1, const AnsiString v2, const AnsiString v3, const AnsiString v4, const AnsiString v5, const AnsiString v6, Frxchart::TfrxSeriesXType XType);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxArrowSeriesHelper(void) : TfrxSeriesHelper() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxArrowSeriesHelper(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxBubbleSeriesHelper;
class PASCALIMPLEMENTATION TfrxBubbleSeriesHelper : public TfrxSeriesHelper 
{
	typedef TfrxSeriesHelper inherited;
	
public:
	virtual AnsiString __fastcall GetParamNames();
	virtual void __fastcall AddValues(Teengine::TChartSeries* Series, const AnsiString v1, const AnsiString v2, const AnsiString v3, const AnsiString v4, const AnsiString v5, const AnsiString v6, Frxchart::TfrxSeriesXType XType);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxBubbleSeriesHelper(void) : TfrxSeriesHelper() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxBubbleSeriesHelper(void) { }
	#pragma option pop
	
};


typedef TMetaClass*TfrxSeriesHelperClass;

//-- var, const, procedure ---------------------------------------------------
static const Shortint frxNumSeries = 0xb;
extern PACKAGE TMetaClass*frxChartSeries[11];
extern PACKAGE TMetaClass*frxSeriesHelpers[11];
extern PACKAGE TfrxSeriesHelper* __fastcall frxFindSeriesHelper(Teengine::TChartSeries* Series);

}	/* namespace Frxcharthelpers */
using namespace Frxcharthelpers;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxChartHelpers
