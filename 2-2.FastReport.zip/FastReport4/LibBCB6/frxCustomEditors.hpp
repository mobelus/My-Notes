// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxCustomEditors.pas' rev: 6.00

#ifndef frxCustomEditorsHPP
#define frxCustomEditorsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxDsgnIntf.hpp>	// Pascal unit
#include <frxDMPClass.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxcustomeditors
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxViewEditor;
class PASCALIMPLEMENTATION TfrxViewEditor : public Frxdsgnintf::TfrxComponentEditor 
{
	typedef Frxdsgnintf::TfrxComponentEditor inherited;
	
public:
	virtual void __fastcall GetMenuItems(void);
	virtual bool __fastcall Execute(int Tag, bool Checked);
public:
	#pragma option push -w-inl
	/* TfrxComponentEditor.Create */ inline __fastcall TfrxViewEditor(Frxclass::TfrxComponent* Component, Frxclass::TfrxCustomDesigner* Designer, Menus::TMenu* Menu) : Frxdsgnintf::TfrxComponentEditor(Component, Designer, Menu) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxViewEditor(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCustomMemoEditor;
class PASCALIMPLEMENTATION TfrxCustomMemoEditor : public TfrxViewEditor 
{
	typedef TfrxViewEditor inherited;
	
public:
	virtual void __fastcall GetMenuItems(void);
	virtual bool __fastcall Execute(int Tag, bool Checked);
public:
	#pragma option push -w-inl
	/* TfrxComponentEditor.Create */ inline __fastcall TfrxCustomMemoEditor(Frxclass::TfrxComponent* Component, Frxclass::TfrxCustomDesigner* Designer, Menus::TMenu* Menu) : TfrxViewEditor(Component, Designer, Menu) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxCustomMemoEditor(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxcustomeditors */
using namespace Frxcustomeditors;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxCustomEditors
