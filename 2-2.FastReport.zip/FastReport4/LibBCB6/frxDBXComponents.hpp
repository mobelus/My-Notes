// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxDBXComponents.pas' rev: 6.00

#ifndef frxDBXComponentsHPP
#define frxDBXComponentsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxDBSet.hpp>	// Pascal unit
#include <fqbClass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <DBClient.hpp>	// Pascal unit
#include <Provider.hpp>	// Pascal unit
#include <SqlExpr.hpp>	// Pascal unit
#include <DBXpress.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <frxCustomDB.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxdbxcomponents
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxDBXDataset;
class PASCALIMPLEMENTATION TfrxDBXDataset : public Dbclient::TCustomClientDataSet 
{
	typedef Dbclient::TCustomClientDataSet inherited;
	
private:
	Db::TDataSet* FDataSet;
	Provider::TDataSetProvider* FProvider;
	void __fastcall SetDataset(const Db::TDataSet* Value);
	
protected:
	virtual void __fastcall OpenCursor(bool InfoQuery);
	
public:
	__fastcall virtual TfrxDBXDataset(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxDBXDataset(void);
	__property Db::TDataSet* Dataset = {read=FDataSet, write=SetDataset};
};


class DELPHICLASS TfrxDBXComponents;
class PASCALIMPLEMENTATION TfrxDBXComponents : public Frxclass::TfrxDBComponents 
{
	typedef Frxclass::TfrxDBComponents inherited;
	
private:
	Sqlexpr::TSQLConnection* FDefaultDatabase;
	TfrxDBXComponents* FOldComponents;
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	void __fastcall SetDefaultDatabase(Sqlexpr::TSQLConnection* Value);
	
public:
	__fastcall virtual TfrxDBXComponents(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxDBXComponents(void);
	virtual AnsiString __fastcall GetDescription();
	
__published:
	__property Sqlexpr::TSQLConnection* DefaultDatabase = {read=FDefaultDatabase, write=SetDefaultDatabase};
};


class DELPHICLASS TfrxDBXDatabase;
class PASCALIMPLEMENTATION TfrxDBXDatabase : public Frxclass::TfrxCustomDatabase 
{
	typedef Frxclass::TfrxCustomDatabase inherited;
	
private:
	Sqlexpr::TSQLConnection* FDatabase;
	Classes::TStrings* FStrings;
	bool FLock;
	AnsiString __fastcall GetDriverName();
	AnsiString __fastcall GetGetDriverFunc();
	AnsiString __fastcall GetLibraryName();
	AnsiString __fastcall GetVendorLib();
	void __fastcall SetDriverName(const AnsiString Value);
	void __fastcall SetGetDriverFunc(const AnsiString Value);
	void __fastcall SetLibraryName(const AnsiString Value);
	void __fastcall SetVendorLib(const AnsiString Value);
	void __fastcall OnChange(System::TObject* Sender);
	
protected:
	virtual void __fastcall SetConnected(bool Value);
	virtual void __fastcall SetDatabaseName(const AnsiString Value);
	virtual void __fastcall SetLoginPrompt(bool Value);
	virtual void __fastcall SetParams(Classes::TStrings* Value);
	virtual bool __fastcall GetConnected(void);
	virtual AnsiString __fastcall GetDatabaseName();
	virtual bool __fastcall GetLoginPrompt(void);
	virtual Classes::TStrings* __fastcall GetParams(void);
	
public:
	__fastcall virtual TfrxDBXDatabase(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxDBXDatabase(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	__property Sqlexpr::TSQLConnection* Database = {read=FDatabase};
	
__published:
	__property AnsiString ConnectionName = {read=GetDatabaseName, write=SetDatabaseName};
	__property AnsiString DriverName = {read=GetDriverName, write=SetDriverName};
	__property AnsiString GetDriverFunc = {read=GetGetDriverFunc, write=SetGetDriverFunc};
	__property AnsiString LibraryName = {read=GetLibraryName, write=SetLibraryName};
	__property LoginPrompt  = {default=1};
	__property Params ;
	__property AnsiString VendorLib = {read=GetVendorLib, write=SetVendorLib};
	__property Connected  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxDBXDatabase(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxCustomDatabase(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDBXTable;
class PASCALIMPLEMENTATION TfrxDBXTable : public Frxcustomdb::TfrxCustomTable 
{
	typedef Frxcustomdb::TfrxCustomTable inherited;
	
private:
	TfrxDBXDatabase* FDatabase;
	Sqlexpr::TSQLTable* FTable;
	void __fastcall SetDatabase(const TfrxDBXDatabase* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetMasterFields(const AnsiString Value);
	virtual void __fastcall SetIndexName(const AnsiString Value);
	virtual void __fastcall SetIndexFieldNames(const AnsiString Value);
	virtual void __fastcall SetTableName(const AnsiString Value);
	virtual AnsiString __fastcall GetIndexName();
	virtual AnsiString __fastcall GetIndexFieldNames();
	virtual AnsiString __fastcall GetTableName();
	
public:
	__fastcall virtual TfrxDBXTable(Classes::TComponent* AOwner);
	__fastcall virtual TfrxDBXTable(Classes::TComponent* AOwner, Word Flags);
	__fastcall virtual ~TfrxDBXTable(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall BeforeStartReport(void);
	__property Sqlexpr::TSQLTable* Table = {read=FTable};
	
__published:
	__property TfrxDBXDatabase* Database = {read=FDatabase, write=SetDatabase};
};


class DELPHICLASS TfrxDBXQuery;
class PASCALIMPLEMENTATION TfrxDBXQuery : public Frxcustomdb::TfrxCustomQuery 
{
	typedef Frxcustomdb::TfrxCustomQuery inherited;
	
private:
	TfrxDBXDatabase* FDatabase;
	Sqlexpr::TSQLQuery* FQuery;
	Classes::TStrings* FStrings;
	bool FLock;
	void __fastcall SetDatabase(const TfrxDBXDatabase* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetSQL(Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetSQL(void);
	virtual void __fastcall OnChangeSQL(System::TObject* Sender);
	
public:
	__fastcall virtual TfrxDBXQuery(Classes::TComponent* AOwner);
	__fastcall virtual TfrxDBXQuery(Classes::TComponent* AOwner, Word Flags);
	__fastcall virtual ~TfrxDBXQuery(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall BeforeStartReport(void);
	virtual void __fastcall UpdateParams(void);
	virtual Fqbclass::TfqbEngine* __fastcall QBEngine(void);
	__property Sqlexpr::TSQLQuery* Query = {read=FQuery};
	
__published:
	__property TfrxDBXDatabase* Database = {read=FDatabase, write=SetDatabase};
};


class DELPHICLASS TfrxEngineDBX;
class PASCALIMPLEMENTATION TfrxEngineDBX : public Fqbclass::TfqbEngine 
{
	typedef Fqbclass::TfqbEngine inherited;
	
private:
	Sqlexpr::TSQLQuery* FQuery;
	TfrxDBXDataset* FDBXDataset;
	
public:
	__fastcall virtual TfrxEngineDBX(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxEngineDBX(void);
	virtual void __fastcall ReadTableList(Classes::TStrings* ATableList);
	virtual void __fastcall ReadFieldList(const AnsiString ATableName, Fqbclass::TfqbFieldList* &AFieldList);
	virtual Db::TDataSet* __fastcall ResultDataSet(void);
	virtual void __fastcall SetSQL(const AnsiString Value);
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxDBXComponents* DBXComponents;

}	/* namespace Frxdbxcomponents */
using namespace Frxdbxcomponents;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxDBXComponents
