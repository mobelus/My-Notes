// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxCustomDB.pas' rev: 6.00

#ifndef frxCustomDBHPP
#define frxCustomDBHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <fqbClass.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <frxDBSet.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxcustomdb
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxCustomDataset;
class PASCALIMPLEMENTATION TfrxCustomDataset : public Frxdbset::TfrxDBDataset 
{
	typedef Frxdbset::TfrxDBDataset inherited;
	
private:
	bool FDBConnected;
	Db::TDataSource* FDataSource;
	Frxdbset::TfrxDBDataset* FMaster;
	AnsiString FMasterFields;
	void __fastcall SetActive(bool Value);
	void __fastcall SetFilter(const AnsiString Value);
	void __fastcall SetFiltered(bool Value);
	bool __fastcall GetActive(void);
	Db::TFields* __fastcall GetFields(void);
	AnsiString __fastcall GetFilter();
	bool __fastcall GetFiltered(void);
	void __fastcall InternalSetMaster(const Frxdbset::TfrxDBDataset* Value);
	void __fastcall InternalSetMasterFields(const AnsiString Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall SetParent(Frxclass::TfrxComponent* AParent);
	virtual void __fastcall SetUserName(const AnsiString Value);
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetMasterFields(const AnsiString Value);
	__property DataSet ;
	
public:
	__fastcall virtual TfrxCustomDataset(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxCustomDataset(void);
	virtual void __fastcall OnPaste(void);
	__property bool DBConnected = {read=FDBConnected, write=FDBConnected, nodefault};
	__property Db::TFields* Fields = {read=GetFields};
	__property AnsiString MasterFields = {read=FMasterFields, write=InternalSetMasterFields};
	__property bool Active = {read=GetActive, write=SetActive, default=0};
	
__published:
	__property AnsiString Filter = {read=GetFilter, write=SetFilter};
	__property bool Filtered = {read=GetFiltered, write=SetFiltered, default=0};
	__property Frxdbset::TfrxDBDataset* Master = {read=FMaster, write=InternalSetMaster};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxCustomDataset(Classes::TComponent* AOwner, Word Flags) : Frxdbset::TfrxDBDataset(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCustomTable;
class PASCALIMPLEMENTATION TfrxCustomTable : public TfrxCustomDataset 
{
	typedef TfrxCustomDataset inherited;
	
protected:
	virtual AnsiString __fastcall GetIndexFieldNames();
	virtual AnsiString __fastcall GetIndexName();
	virtual AnsiString __fastcall GetTableName();
	virtual void __fastcall SetIndexFieldNames(const AnsiString Value);
	virtual void __fastcall SetIndexName(const AnsiString Value);
	virtual void __fastcall SetTableName(const AnsiString Value);
	__property DataSet ;
	
__published:
	__property MasterFields ;
	__property AnsiString TableName = {read=GetTableName, write=SetTableName};
	__property AnsiString IndexName = {read=GetIndexName, write=SetIndexName};
	__property AnsiString IndexFieldNames = {read=GetIndexFieldNames, write=SetIndexFieldNames};
public:
	#pragma option push -w-inl
	/* TfrxCustomDataset.Create */ inline __fastcall virtual TfrxCustomTable(Classes::TComponent* AOwner) : TfrxCustomDataset(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomDataset.Destroy */ inline __fastcall virtual ~TfrxCustomTable(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxCustomTable(Classes::TComponent* AOwner, Word Flags) : TfrxCustomDataset(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxParamItem;
class PASCALIMPLEMENTATION TfrxParamItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	Db::TFieldType FDataType;
	AnsiString FExpression;
	AnsiString FName;
	Variant FValue;
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__property Variant Value = {read=FValue, write=FValue};
	
__published:
	__property AnsiString Name = {read=FName, write=FName};
	__property Db::TFieldType DataType = {read=FDataType, write=FDataType, nodefault};
	__property AnsiString Expression = {read=FExpression, write=FExpression};
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxParamItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxParamItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxParams;
class PASCALIMPLEMENTATION TfrxParams : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxParamItem* operator[](int Index) { return Items[Index]; }
	
private:
	bool FIgnoreDuplicates;
	TfrxParamItem* __fastcall GetParam(int Index);
	
public:
	__fastcall TfrxParams(void);
	HIDESBASE TfrxParamItem* __fastcall Add(void);
	TfrxParamItem* __fastcall Find(const AnsiString Name);
	int __fastcall IndexOf(const AnsiString Name);
	void __fastcall UpdateParams(const AnsiString SQL);
	__property TfrxParamItem* Items[int Index] = {read=GetParam/*, default*/};
	__property bool IgnoreDuplicates = {read=FIgnoreDuplicates, write=FIgnoreDuplicates, nodefault};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxParams(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxCustomQuery;
class PASCALIMPLEMENTATION TfrxCustomQuery : public TfrxCustomDataset 
{
	typedef TfrxCustomDataset inherited;
	
private:
	TfrxParams* FParams;
	Db::TDataSetNotifyEvent FSaveOnBeforeOpen;
	Classes::TNotifyEvent FSaveOnChange;
	AnsiString FSQLSchema;
	void __fastcall ReadData(Classes::TReader* Reader);
	void __fastcall SetParams(TfrxParams* Value);
	void __fastcall WriteData(Classes::TWriter* Writer);
	bool __fastcall GetIgnoreDupParams(void);
	void __fastcall SetIgnoreDupParams(const bool Value);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual void __fastcall OnBeforeOpen(Db::TDataSet* DataSet);
	virtual void __fastcall OnChangeSQL(System::TObject* Sender);
	virtual void __fastcall SetSQL(Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetSQL(void);
	
public:
	__fastcall virtual TfrxCustomQuery(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxCustomQuery(void);
	virtual void __fastcall UpdateParams(void);
	TfrxParamItem* __fastcall ParamByName(const AnsiString Value);
	virtual Fqbclass::TfqbEngine* __fastcall QBEngine(void);
	
__published:
	__property bool IgnoreDupParams = {read=GetIgnoreDupParams, write=SetIgnoreDupParams, nodefault};
	__property TfrxParams* Params = {read=FParams, write=SetParams};
	__property Classes::TStrings* SQL = {read=GetSQL, write=SetSQL};
	__property AnsiString SQLSchema = {read=FSQLSchema, write=FSQLSchema};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxCustomQuery(Classes::TComponent* AOwner, Word Flags) : TfrxCustomDataset(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxDBLookupComboBox;
class PASCALIMPLEMENTATION TfrxDBLookupComboBox : public Frxclass::TfrxDialogControl 
{
	typedef Frxclass::TfrxDialogControl inherited;
	
private:
	Frxdbset::TfrxDBDataset* FDataSet;
	AnsiString FDataSetName;
	Db::TDataSource* FDataSource;
	Dbctrls::TDBLookupComboBox* FDBLookupComboBox;
	bool FAutoOpenDataSet;
	AnsiString __fastcall GetDataSetName();
	AnsiString __fastcall GetKeyField();
	Variant __fastcall GetKeyValue();
	AnsiString __fastcall GetListField();
	AnsiString __fastcall GetText();
	void __fastcall SetDataSet(const Frxdbset::TfrxDBDataset* Value);
	void __fastcall SetDataSetName(const AnsiString Value);
	void __fastcall SetKeyField(AnsiString Value);
	void __fastcall SetKeyValue(const Variant &Value);
	void __fastcall SetListField(AnsiString Value);
	void __fastcall UpdateDataSet(void);
	void __fastcall OnOpenDS(System::TObject* Sender);
	int __fastcall GetDropDownWidth(void);
	void __fastcall SetDropDownWidth(const int Value);
	int __fastcall GetDropDownRows(void);
	void __fastcall SetDropDownRows(const int Value);
	
public:
	__fastcall virtual TfrxDBLookupComboBox(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxDBLookupComboBox(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall BeforeStartReport(void);
	__property Dbctrls::TDBLookupComboBox* DBLookupComboBox = {read=FDBLookupComboBox};
	__property Variant KeyValue = {read=GetKeyValue, write=SetKeyValue};
	__property AnsiString Text = {read=GetText};
	
__published:
	__property bool AutoOpenDataSet = {read=FAutoOpenDataSet, write=FAutoOpenDataSet, default=0};
	__property Frxdbset::TfrxDBDataset* DataSet = {read=FDataSet, write=SetDataSet};
	__property AnsiString DataSetName = {read=GetDataSetName, write=SetDataSetName};
	__property AnsiString ListField = {read=GetListField, write=SetListField};
	__property AnsiString KeyField = {read=GetKeyField, write=SetKeyField};
	__property int DropDownWidth = {read=GetDropDownWidth, write=SetDropDownWidth, nodefault};
	__property int DropDownRows = {read=GetDropDownRows, write=SetDropDownRows, nodefault};
	__property OnClick ;
	__property OnDblClick ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxDBLookupComboBox(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxDialogControl(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall frxParamsToTParams(TfrxCustomQuery* Query, Db::TParams* Params);

}	/* namespace Frxcustomdb */
using namespace Frxcustomdb;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxCustomDB
