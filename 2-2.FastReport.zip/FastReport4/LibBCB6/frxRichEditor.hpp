// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxRichEditor.pas' rev: 6.00

#ifndef frxRichEditorHPP
#define frxRichEditorHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxUnicodeCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ToolWin.hpp>	// Pascal unit
#include <frxDock.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <frxRichEdit.hpp>	// Pascal unit
#include <frxCtrls.hpp>	// Pascal unit
#include <frxCustomEditors.hpp>	// Pascal unit
#include <frxRich.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxricheditor
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxRichEditor;
class PASCALIMPLEMENTATION TfrxRichEditor : public Frxcustomeditors::TfrxViewEditor 
{
	typedef Frxcustomeditors::TfrxViewEditor inherited;
	
public:
	virtual bool __fastcall Edit(void);
	virtual bool __fastcall HasEditor(void);
	virtual void __fastcall GetMenuItems(void);
	virtual bool __fastcall Execute(int Tag, bool Checked);
public:
	#pragma option push -w-inl
	/* TfrxComponentEditor.Create */ inline __fastcall TfrxRichEditor(Frxclass::TfrxComponent* Component, Frxclass::TfrxCustomDesigner* Designer, Menus::TMenu* Menu) : Frxcustomeditors::TfrxViewEditor(Component, Designer, Menu) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxRichEditor(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxRichEditorForm;
class PASCALIMPLEMENTATION TfrxRichEditorForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Dialogs::TOpenDialog* OpenDialog;
	Dialogs::TSaveDialog* SaveDialog;
	Comctrls::TToolBar* SpeedBar;
	Extctrls::TPanel* Ruler;
	Dialogs::TFontDialog* FontDialog1;
	Stdctrls::TLabel* FirstInd;
	Stdctrls::TLabel* LeftInd;
	Extctrls::TBevel* RulerLine;
	Stdctrls::TLabel* RightInd;
	Comctrls::TToolButton* BoldB;
	Comctrls::TToolButton* ItalicB;
	Comctrls::TToolButton* LeftAlignB;
	Comctrls::TToolButton* CenterAlignB;
	Comctrls::TToolButton* RightAlignB;
	Comctrls::TToolButton* UnderlineB;
	Comctrls::TToolButton* BulletsB;
	Comctrls::TToolButton* TTB;
	Comctrls::TToolButton* CancelB;
	Comctrls::TToolButton* OkB;
	Comctrls::TToolButton* ExprB;
	Frxctrls::TfrxFontComboBox* FontNameCB;
	Frxctrls::TfrxComboBox* FontSizeCB;
	Comctrls::TToolButton* OpenB;
	Comctrls::TToolButton* SaveB;
	Comctrls::TToolButton* UndoB;
	Comctrls::TToolButton* Sep1;
	Comctrls::TToolButton* Sep2;
	Frxdock::TfrxTBPanel* Sep3;
	Comctrls::TToolButton* Sep4;
	Comctrls::TToolButton* Sep5;
	Comctrls::TToolButton* BlockAlignB;
	void __fastcall SelectionChange(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FileOpen(System::TObject* Sender);
	void __fastcall FileSaveAs(System::TObject* Sender);
	void __fastcall EditUndo(System::TObject* Sender);
	void __fastcall SelectFont(System::TObject* Sender);
	void __fastcall RulerResize(System::TObject* Sender);
	void __fastcall FormResize(System::TObject* Sender);
	void __fastcall FormPaint(System::TObject* Sender);
	void __fastcall BoldBClick(System::TObject* Sender);
	void __fastcall AlignButtonClick(System::TObject* Sender);
	void __fastcall FontNameCBChange(System::TObject* Sender);
	void __fastcall BulletsBClick(System::TObject* Sender);
	void __fastcall RulerItemMouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	void __fastcall RulerItemMouseMove(System::TObject* Sender, Classes::TShiftState Shift, int X, int Y);
	void __fastcall FirstIndMouseUp(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	void __fastcall LeftIndMouseUp(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	void __fastcall RightIndMouseUp(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	void __fastcall CancelBClick(System::TObject* Sender);
	void __fastcall OkBClick(System::TObject* Sender);
	void __fastcall ExprBClick(System::TObject* Sender);
	void __fastcall FontSizeCBChange(System::TObject* Sender);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormHide(System::TObject* Sender);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	
private:
	bool FDragging;
	int FDragOfs;
	Frxrich::TfrxRichView* FRichView;
	bool FUpdating;
	Frxunicodectrls::TRxUnicodeRichEdit* RichEdit1;
	Frxrichedit::TRxTextAttributes* __fastcall CurrText(void);
	void __fastcall SetupRuler(void);
	void __fastcall SetEditRect(void);
	
public:
	__property Frxrich::TfrxRichView* RichView = {read=FRichView, write=FRichView};
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxRichEditorForm(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxRichEditorForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxRichEditorForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxRichEditorForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxricheditor */
using namespace Frxricheditor;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxRichEditor
