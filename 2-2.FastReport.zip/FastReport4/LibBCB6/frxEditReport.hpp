// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxEditReport.pas' rev: 6.00

#ifndef frxEditReportHPP
#define frxEditReportHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <frxCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxeditreport
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxReportEditorForm;
class PASCALIMPLEMENTATION TfrxReportEditorForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OkB;
	Stdctrls::TButton* CancelB;
	Comctrls::TPageControl* PageControl;
	Comctrls::TTabSheet* GeneralTS;
	Comctrls::TTabSheet* DescriptionTS;
	Stdctrls::TGroupBox* ReportSettingsL;
	Stdctrls::TListBox* PrintersLB;
	Stdctrls::TLabel* CopiesL;
	Stdctrls::TEdit* CopiesE;
	Stdctrls::TCheckBox* CollateCB;
	Stdctrls::TGroupBox* GeneralL;
	Stdctrls::TLabel* PasswordL;
	Stdctrls::TCheckBox* DoublePassCB;
	Stdctrls::TCheckBox* PrintIfEmptyCB;
	Stdctrls::TEdit* PasswordE;
	Stdctrls::TGroupBox* DescriptionL;
	Extctrls::TBevel* Bevel3;
	Stdctrls::TLabel* NameL;
	Extctrls::TImage* PictureImg;
	Stdctrls::TLabel* Description1L;
	Stdctrls::TLabel* PictureL;
	Stdctrls::TLabel* AuthorL;
	Stdctrls::TEdit* NameE;
	Stdctrls::TMemo* DescriptionE;
	Stdctrls::TButton* PictureB;
	Stdctrls::TEdit* AuthorE;
	Stdctrls::TGroupBox* VersionL;
	Stdctrls::TLabel* MajorL;
	Stdctrls::TLabel* MinorL;
	Stdctrls::TLabel* ReleaseL;
	Stdctrls::TLabel* BuildL;
	Stdctrls::TLabel* CreatedL;
	Stdctrls::TLabel* Created1L;
	Stdctrls::TLabel* ModifiedL;
	Stdctrls::TLabel* Modified1L;
	Stdctrls::TEdit* MajorE;
	Stdctrls::TEdit* MinorE;
	Stdctrls::TEdit* ReleaseE;
	Stdctrls::TEdit* BuildE;
	Comctrls::TTabSheet* InheritTS;
	Stdctrls::TGroupBox* InheritGB;
	Stdctrls::TLabel* InheritStateL;
	Stdctrls::TRadioButton* DetachRB;
	Stdctrls::TLabel* SelectL;
	Stdctrls::TRadioButton* InheritRB;
	Stdctrls::TRadioButton* DontChangeRB;
	Comctrls::TListView* InheritLV;
	Stdctrls::TLabel* PathLB;
	Stdctrls::TEdit* PathE;
	Stdctrls::TButton* BrowseB;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall PictureBClick(System::TObject* Sender);
	void __fastcall PrintersLBDrawItem(Controls::TWinControl* Control, int Index, const Types::TRect &ARect, Windows::TOwnerDrawState State);
	void __fastcall FormShow(System::TObject* Sender);
	void __fastcall FormHide(System::TObject* Sender);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall FormDestroy(System::TObject* Sender);
	void __fastcall BrowseBClick(System::TObject* Sender);
	void __fastcall FillTemplatelist(void);
	void __fastcall PathEKeyPress(System::TObject* Sender, char &Key);
	void __fastcall PageControlChange(System::TObject* Sender);
	
private:
	Classes::TStringList* FTemplates;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxReportEditorForm(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxReportEditorForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxReportEditorForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxReportEditorForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxeditreport */
using namespace Frxeditreport;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxEditReport
