// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxPictureCache.pas' rev: 6.00

#ifndef frxPictureCacheHPP
#define frxPictureCacheHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxXML.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxpicturecache
{
//-- type declarations -------------------------------------------------------
#pragma pack(push, 1)
struct TfrxCacheItem
{
	int Segment;
	int Offset;
} ;
#pragma pack(pop)

typedef TfrxCacheItem *PfrxCacheItem;

class DELPHICLASS TfrxCacheList;
class PASCALIMPLEMENTATION TfrxCacheList : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	PfrxCacheItem operator[](int Index) { return Items[Index]; }
	
private:
	PfrxCacheItem __fastcall Get(int Index);
	
protected:
	Classes::TList* FItems;
	void __fastcall Clear(void);
	
public:
	__fastcall TfrxCacheList(void);
	__fastcall virtual ~TfrxCacheList(void);
	PfrxCacheItem __fastcall Add(void);
	int __fastcall Count(void);
	__property PfrxCacheItem Items[int Index] = {read=Get/*, default*/};
};


class DELPHICLASS TfrxFileStream;
class PASCALIMPLEMENTATION TfrxFileStream : public Classes::TFileStream 
{
	typedef Classes::TFileStream inherited;
	
private:
	unsigned FSz;
	
public:
	virtual int __fastcall Seek(int Offset, Word Origin)/* overload */;
	virtual __int64 __fastcall Seek(const __int64 Offset, Classes::TSeekOrigin Origin)/* overload */;
public:
	#pragma option push -w-inl
	/* TFileStream.Create */ inline __fastcall TfrxFileStream(const AnsiString FileName, Word Mode)/* overload */ : Classes::TFileStream(FileName, Mode) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TFileStream.Destroy */ inline __fastcall virtual ~TfrxFileStream(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxMemoryStream;
class PASCALIMPLEMENTATION TfrxMemoryStream : public Classes::TMemoryStream 
{
	typedef Classes::TMemoryStream inherited;
	
private:
	unsigned FSz;
	
public:
	virtual int __fastcall Seek(int Offset, Word Origin)/* overload */;
	virtual __int64 __fastcall Seek(const __int64 Offset, Classes::TSeekOrigin Origin)/* overload */;
public:
	#pragma option push -w-inl
	/* TMemoryStream.Destroy */ inline __fastcall virtual ~TfrxMemoryStream(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxMemoryStream(void) : Classes::TMemoryStream() { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPictureCache;
class PASCALIMPLEMENTATION TfrxPictureCache : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	TfrxCacheList* FItems;
	Classes::TList* FCacheStreamList;
	Classes::TStringList* FTempFile;
	AnsiString FTempDir;
	bool FUseFileCache;
	void __fastcall Add(void);
	void __fastcall SetTempDir(const AnsiString Value);
	void __fastcall SetUseFileCache(const bool Value);
	
public:
	__fastcall TfrxPictureCache(void);
	__fastcall virtual ~TfrxPictureCache(void);
	void __fastcall Clear(void);
	void __fastcall AddPicture(Frxclass::TfrxPictureView* Picture);
	void __fastcall GetPicture(Frxclass::TfrxPictureView* Picture);
	void __fastcall SaveToXML(Frxxml::TfrxXMLItem* Item);
	void __fastcall LoadFromXML(Frxxml::TfrxXMLItem* Item);
	void __fastcall AddSegment(void);
	__property bool UseFileCache = {read=FUseFileCache, write=SetUseFileCache, nodefault};
	__property AnsiString TempDir = {read=FTempDir, write=SetTempDir};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxpicturecache */
using namespace Frxpicturecache;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxPictureCache
