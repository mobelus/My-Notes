// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxUnicodeCtrls.pas' rev: 6.00

#ifndef frxUnicodeCtrlsHPP
#define frxUnicodeCtrlsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxRichEdit.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxunicodectrls
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TUnicodeEdit;
class PASCALIMPLEMENTATION TUnicodeEdit : public Stdctrls::TEdit 
{
	typedef Stdctrls::TEdit inherited;
	
private:
	HIDESBASE void __fastcall SetSelText(const WideString Value);
	HIDESBASE WideString __fastcall GetText();
	HIDESBASE void __fastcall SetText(const WideString Value);
	
protected:
	virtual void __fastcall CreateWindowHandle(const Controls::TCreateParams &Params);
	HIDESBASE WideString __fastcall GetSelText();
	
public:
	__property WideString SelText = {read=GetSelText, write=SetSelText};
	__property WideString Text = {read=GetText, write=SetText};
public:
	#pragma option push -w-inl
	/* TCustomEdit.Create */ inline __fastcall virtual TUnicodeEdit(Classes::TComponent* AOwner) : Stdctrls::TEdit(AOwner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TUnicodeEdit(HWND ParentWindow) : Stdctrls::TEdit(ParentWindow) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TWinControl.Destroy */ inline __fastcall virtual ~TUnicodeEdit(void) { }
	#pragma option pop
	
};


class DELPHICLASS TUnicodeMemo;
class PASCALIMPLEMENTATION TUnicodeMemo : public Stdctrls::TMemo 
{
	typedef Stdctrls::TMemo inherited;
	
private:
	HIDESBASE void __fastcall SetSelText(const WideString Value);
	HIDESBASE WideString __fastcall GetText();
	HIDESBASE void __fastcall SetText(const WideString Value);
	
protected:
	virtual void __fastcall CreateWindowHandle(const Controls::TCreateParams &Params);
	HIDESBASE WideString __fastcall GetSelText();
	
public:
	__property WideString SelText = {read=GetSelText, write=SetSelText};
	__property WideString Text = {read=GetText, write=SetText};
public:
	#pragma option push -w-inl
	/* TCustomMemo.Create */ inline __fastcall virtual TUnicodeMemo(Classes::TComponent* AOwner) : Stdctrls::TMemo(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomMemo.Destroy */ inline __fastcall virtual ~TUnicodeMemo(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TUnicodeMemo(HWND ParentWindow) : Stdctrls::TMemo(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TRxUnicodeRichEdit;
class PASCALIMPLEMENTATION TRxUnicodeRichEdit : public Frxrichedit::TRxRichEdit 
{
	typedef Frxrichedit::TRxRichEdit inherited;
	
protected:
	virtual void __fastcall CreateWindowHandle(const Controls::TCreateParams &Params);
public:
	#pragma option push -w-inl
	/* TRxCustomRichEdit.Create */ inline __fastcall virtual TRxUnicodeRichEdit(Classes::TComponent* AOwner) : Frxrichedit::TRxRichEdit(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TRxCustomRichEdit.Destroy */ inline __fastcall virtual ~TRxUnicodeRichEdit(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TRxUnicodeRichEdit(HWND ParentWindow) : Frxrichedit::TRxRichEdit(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxunicodectrls */
using namespace Frxunicodectrls;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxUnicodeCtrls
