// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxServerUtils.pas' rev: 6.00

#ifndef frxServerUtilsHPP
#define frxServerUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxUtils.hpp>	// Pascal unit
#include <ActiveX.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxserverutils
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TfrxServerFormat { sfHTM, sfXML, sfXLS, sfRTF, sfCSV, sfTXT, sfPDF, sfJPG, sfBMP, sfTIFF, sfGIF, sfFRP, sfODS, sfODT };
#pragma option pop

typedef Set<TfrxServerFormat, sfHTM, sfODT>  TfrxServerOutputFormats;

#pragma option push -b-
enum TfrxHTTPQueryType { qtGet, qtPost, qtHead };
#pragma option pop

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString __fastcall StrToHex(const AnsiString s);
extern PACKAGE AnsiString __fastcall HexToStr(const AnsiString s);
extern PACKAGE AnsiString __fastcall Byte2Hex(const Byte b);
extern PACKAGE AnsiString __fastcall GetHTTPErrorText(const int ErrorCode);
extern PACKAGE AnsiString __fastcall GetUniqueFileName(const AnsiString Path, const AnsiString Prefix);
extern PACKAGE AnsiString __fastcall Str2HTML(const AnsiString Str);
extern PACKAGE AnsiString __fastcall HTML2Str(const AnsiString Line);
extern PACKAGE AnsiString __fastcall UnQuoteStr(const AnsiString s);
extern PACKAGE AnsiString __fastcall GetEnvVar(const AnsiString VarName);
extern PACKAGE AnsiString __fastcall MakeSessionId();
extern PACKAGE AnsiString __fastcall frxGetAbsPath(const AnsiString Path);
extern PACKAGE AnsiString __fastcall frxGetAbsPathDir(const AnsiString Path, const AnsiString Dir);
extern PACKAGE AnsiString __fastcall frxGetRelPath(const AnsiString Path);
extern PACKAGE AnsiString __fastcall frxGetRelPathDir(const AnsiString Path, const AnsiString Dir);
extern PACKAGE void __fastcall frxTouchDir(const AnsiString Path);

}	/* namespace Frxserverutils */
using namespace Frxserverutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxServerUtils
