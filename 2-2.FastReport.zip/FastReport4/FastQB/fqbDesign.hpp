// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fqbDesign.pas' rev: 6.00

#ifndef fqbDesignHPP
#define fqbDesignHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <fqbClass.hpp>	// Pascal unit
#include <fqbSynmemo.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <DBGrids.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ToolWin.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fqbdesign
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfqbDesigner;
class PASCALIMPLEMENTATION TfqbDesigner : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Db::TDataSource* DataSource1;
	Dbgrids::TDBGrid* DBGrid1;
	Fqbclass::TfqbGrid* fqbGrid1;
	Fqbsynmemo::TfqbSyntaxMemo* fqbSyntaxMemo1;
	Fqbclass::TfqbTableArea* fqbTableArea1;
	Fqbclass::TfqbTableListBox* fqbTableListBox1;
	Controls::TImageList* ImageList2;
	Dialogs::TOpenDialog* OpenDialog1;
	Comctrls::TPageControl* PageControl1;
	Extctrls::TPanel* Panel1;
	Dialogs::TSaveDialog* SaveDialog1;
	Extctrls::TSplitter* Splitter1;
	Extctrls::TSplitter* Splitter2;
	Comctrls::TTabSheet* TabSheet1;
	Comctrls::TTabSheet* TabSheet2;
	Comctrls::TTabSheet* TabSheet3;
	Comctrls::TToolBar* ToolBar1;
	Comctrls::TToolButton* ToolButton10;
	Comctrls::TToolButton* ToolButton3;
	Comctrls::TToolButton* ToolButton4;
	Comctrls::TToolButton* ToolButton5;
	Comctrls::TToolButton* ToolButton6;
	Comctrls::TToolButton* ToolButton7;
	Comctrls::TToolButton* ToolButton8;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall TabSheet2Show(System::TObject* Sender);
	void __fastcall TabSheet3Hide(System::TObject* Sender);
	void __fastcall TabSheet3Show(System::TObject* Sender);
	void __fastcall ToolButton10Click(System::TObject* Sender);
	void __fastcall ToolButton3Click(System::TObject* Sender);
	void __fastcall ToolButton4Click(System::TObject* Sender);
	void __fastcall ToolButton6Click(System::TObject* Sender);
	void __fastcall ToolButton7Click(System::TObject* Sender);
	void __fastcall FormDestroy(System::TObject* Sender);
	
protected:
	void __fastcall LoadPos(void);
	void __fastcall SavePos(void);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfqbDesigner(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfqbDesigner(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfqbDesigner(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfqbDesigner(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfqbDesigner* fqbDesigner;

}	/* namespace Fqbdesign */
using namespace Fqbdesign;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fqbDesign
