// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fqbUtils.pas' rev: 6.00

#ifndef fqbUtilsHPP
#define fqbUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <fqbZLib.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fqbutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE unsigned __fastcall fqbStringCRC32(const AnsiString Str);
extern PACKAGE AnsiString __fastcall fqbGetUniqueFileName(const AnsiString Prefix);
extern PACKAGE AnsiString __fastcall fqbTrim(const AnsiString Input, const Sysutils::TSysCharSet &EArray);
extern PACKAGE AnsiString __fastcall fqbParse(AnsiString Char, AnsiString S, int Count, bool Last = false);
extern PACKAGE AnsiString __fastcall fqbBase64Decode(const AnsiString S);
extern PACKAGE AnsiString __fastcall fqbBase64Encode(const AnsiString S);
extern PACKAGE AnsiString __fastcall fqbCompress(const AnsiString S);
extern PACKAGE AnsiString __fastcall fqbDeCompress(const AnsiString S);
extern PACKAGE void __fastcall fqbDeflateStream(Classes::TStream* Source, Classes::TStream* Dest, Fqbzlib::TZCompressionLevel Compression = (Fqbzlib::TZCompressionLevel)(0x2));
extern PACKAGE void __fastcall fqbInflateStream(Classes::TStream* Source, Classes::TStream* Dest);

}	/* namespace Fqbutils */
using namespace Fqbutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fqbUtils
