// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fqbRes.pas' rev: 6.00

#ifndef fqbResHPP
#define fqbResHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fqbres
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfqbResources;
class PASCALIMPLEMENTATION TfqbResources : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TStringList* FNames;
	Classes::TStringList* FValues;
	
public:
	__fastcall TfqbResources(void);
	__fastcall virtual ~TfqbResources(void);
	AnsiString __fastcall Get(const AnsiString StrName);
	void __fastcall Add(const AnsiString Ref, const AnsiString Str);
	void __fastcall AddStrings(const AnsiString Str);
	void __fastcall Clear(void);
	void __fastcall LoadFromFile(const AnsiString FileName);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfqbResources* __fastcall fqbResources(void);
extern PACKAGE AnsiString __fastcall fqbGet(int ID);

}	/* namespace Fqbres */
using namespace Fqbres;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fqbRes
