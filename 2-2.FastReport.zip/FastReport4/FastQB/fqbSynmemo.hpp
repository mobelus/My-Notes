// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fqbSynmemo.pas' rev: 6.00

#ifndef fqbSynmemoHPP
#define fqbSynmemoHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SysUtils.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fqbsynmemo
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TSyntaxType { stPascal, stCpp, stSQL, stText };
#pragma option pop

#pragma option push -b-
enum TCharAttr { caNone, caText, caBlock, caComment, caKeyword, caString };
#pragma option pop

typedef Set<TCharAttr, caNone, caString>  TCharAttributes;

typedef DynamicArray<int >  fqbSynmemo__2;

class DELPHICLASS TfqbSyntaxMemo;
class PASCALIMPLEMENTATION TfqbSyntaxMemo : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	bool FAllowLinesChange;
	int FCharHeight;
	int FCharWidth;
	bool FDoubleClicked;
	bool FDown;
	int FGutterWidth;
	int FFooterHeight;
	bool FIsMonoType;
	AnsiString FKeywords;
	int FMaxLength;
	AnsiString FMessage;
	bool FModified;
	bool FMoved;
	#pragma pack(push, 1)
	Types::TPoint FOffset;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Types::TPoint FPos;
	#pragma pack(pop)
	
	bool FReadOnly;
	#pragma pack(push, 1)
	Types::TPoint FSelEnd;
	#pragma pack(pop)
	
	#pragma pack(push, 1)
	Types::TPoint FSelStart;
	#pragma pack(pop)
	
	Classes::TStrings* FSynStrings;
	TSyntaxType FSyntaxType;
	#pragma pack(push, 1)
	Types::TPoint FTempPos;
	#pragma pack(pop)
	
	Classes::TStringList* FText;
	Graphics::TFont* FKeywordAttr;
	Graphics::TFont* FStringAttr;
	Graphics::TFont* FTextAttr;
	Graphics::TFont* FCommentAttr;
	Graphics::TColor FBlockColor;
	Graphics::TColor FBlockFontColor;
	Classes::TStringList* FUndo;
	bool FUpdating;
	bool FUpdatingSyntax;
	Stdctrls::TScrollBar* FVScroll;
	#pragma pack(push, 1)
	Types::TPoint FWindowSize;
	#pragma pack(pop)
	
	Menus::TPopupMenu* FPopupMenu;
	int KWheel;
	AnsiString LastSearch;
	bool FShowGutter;
	bool FShowFooter;
	DynamicArray<int >  Bookmarks;
	int FActiveLine;
	HIDESBASE Classes::TStrings* __fastcall GetText(void);
	HIDESBASE void __fastcall SetText(Classes::TStrings* Value);
	void __fastcall SetSyntaxType(TSyntaxType Value);
	void __fastcall SetShowGutter(bool Value);
	void __fastcall SetShowFooter(bool Value);
	bool __fastcall FMemoFind(AnsiString Text, Types::TPoint &Position);
	TCharAttributes __fastcall GetCharAttr(const Types::TPoint &Pos);
	int __fastcall GetLineBegin(int Index);
	int __fastcall GetPlainTextPos(const Types::TPoint &Pos);
	Types::TPoint __fastcall GetPosPlainText(int Pos);
	AnsiString __fastcall GetSelText();
	AnsiString __fastcall LineAt(int Index);
	int __fastcall LineLength(int Index);
	AnsiString __fastcall Pad(int n);
	void __fastcall AddSel(void);
	void __fastcall AddUndo(void);
	void __fastcall ClearSel(void);
	void __fastcall CreateSynArray(void);
	void __fastcall DoChange(void);
	void __fastcall EnterIndent(void);
	void __fastcall SetSelText(AnsiString Value);
	void __fastcall ShiftSelected(bool ShiftRight);
	void __fastcall ShowCaretPos(void);
	void __fastcall TabIndent(void);
	void __fastcall UnIndent(void);
	void __fastcall UpdateScrollBar(void);
	void __fastcall UpdateSyntax(void);
	void __fastcall DoLeft(void);
	void __fastcall DoRight(void);
	void __fastcall DoUp(void);
	void __fastcall DoDown(void);
	void __fastcall DoHome(bool Ctrl);
	void __fastcall DoEnd(bool Ctrl);
	void __fastcall DoPgUp(void);
	void __fastcall DoPgDn(void);
	void __fastcall DoChar(char Ch);
	void __fastcall DoReturn(void);
	void __fastcall DoDel(void);
	void __fastcall DoBackspace(void);
	void __fastcall DoCtrlI(void);
	void __fastcall DoCtrlU(void);
	void __fastcall DoCtrlR(void);
	void __fastcall DoCtrlL(void);
	void __fastcall ScrollClick(System::TObject* Sender);
	void __fastcall ScrollEnter(System::TObject* Sender);
	void __fastcall LinesChange(System::TObject* Sender);
	void __fastcall ShowPos(void);
	void __fastcall BookmarkDraw(int Y, int line);
	void __fastcall ActiveLineDraw(int Y, int line);
	void __fastcall CorrectBookmark(int Line, int delta);
	void __fastcall SetKeywordAttr(Graphics::TFont* Value);
	void __fastcall SetStringAttr(Graphics::TFont* Value);
	void __fastcall SetTextAttr(Graphics::TFont* Value);
	void __fastcall SetCommentAttr(Graphics::TFont* Value);
	
protected:
	MESSAGE void __fastcall WMGetDlgCode(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Msg);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Msg);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	virtual void __fastcall SetParent(Controls::TWinControl* Value);
	virtual Types::TRect __fastcall GetClientRect();
	DYNAMIC void __fastcall DblClick(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	void __fastcall CopyPopup(System::TObject* Sender);
	void __fastcall PastePopup(System::TObject* Sender);
	void __fastcall CutPopup(System::TObject* Sender);
	void __fastcall MouseWheelUp(System::TObject* Sender, Classes::TShiftState Shift, const Types::TPoint &MousePos, bool &Handled);
	void __fastcall MouseWheelDown(System::TObject* Sender, Classes::TShiftState Shift, const Types::TPoint &MousePos, bool &Handled);
	void __fastcall DOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState State, bool &Accept);
	void __fastcall DDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	
public:
	__fastcall virtual TfqbSyntaxMemo(Classes::TComponent* AOwner);
	__fastcall virtual ~TfqbSyntaxMemo(void);
	virtual void __fastcall SetBounds(int ALeft, int ATop, int AWidth, int AHeight);
	virtual void __fastcall Paint(void);
	void __fastcall CopyToClipboard(void);
	void __fastcall CutToClipboard(void);
	void __fastcall PasteFromClipboard(void);
	void __fastcall SetPos(int x, int y);
	void __fastcall ShowMessage(AnsiString s);
	void __fastcall Undo(void);
	void __fastcall UpdateView(void);
	Types::TPoint __fastcall GetPos();
	bool __fastcall Find(AnsiString Text);
	__property bool Modified = {read=FModified, write=FModified, nodefault};
	__property AnsiString SelText = {read=GetSelText, write=SetSelText};
	int __fastcall IsBookmark(int Line);
	void __fastcall AddBookmark(int Line, int Number);
	void __fastcall DeleteBookmark(int Number);
	void __fastcall GotoBookmark(int Number);
	void __fastcall SetActiveLine(int Line);
	int __fastcall GetActiveLine(void);
	
__published:
	__property Align  = {default=0};
	__property Anchors  = {default=3};
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind  = {default=0};
	__property ParentBiDiMode  = {default=1};
	__property Color  = {default=-2147483643};
	__property DragCursor  = {default=-12};
	__property DragMode  = {default=0};
	__property Enabled  = {default=1};
	__property Font ;
	__property ParentColor  = {default=1};
	__property ParentCtl3D  = {default=1};
	__property ParentFont  = {default=1};
	__property ParentShowHint  = {default=1};
	__property PopupMenu ;
	__property ShowHint ;
	__property TabOrder  = {default=-1};
	__property TabStop  = {default=0};
	__property Width ;
	__property Height ;
	__property Visible  = {default=1};
	__property Graphics::TColor BlockColor = {read=FBlockColor, write=FBlockColor, nodefault};
	__property Graphics::TColor BlockFontColor = {read=FBlockFontColor, write=FBlockFontColor, nodefault};
	__property Graphics::TFont* CommentAttr = {read=FCommentAttr, write=SetCommentAttr};
	__property Graphics::TFont* KeywordAttr = {read=FKeywordAttr, write=SetKeywordAttr};
	__property Graphics::TFont* StringAttr = {read=FStringAttr, write=SetStringAttr};
	__property Graphics::TFont* TextAttr = {read=FTextAttr, write=SetTextAttr};
	__property Classes::TStrings* Lines = {read=GetText, write=SetText};
	__property bool ReadOnly = {read=FReadOnly, write=FReadOnly, nodefault};
	__property TSyntaxType SyntaxType = {read=FSyntaxType, write=SetSyntaxType, nodefault};
	__property bool ShowFooter = {read=FShowFooter, write=SetShowFooter, nodefault};
	__property bool ShowGutter = {read=FShowGutter, write=SetShowGutter, nodefault};
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfqbSyntaxMemo(HWND ParentWindow) : Controls::TCustomControl(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TfqbSynMemoSearch;
class PASCALIMPLEMENTATION TfqbSynMemoSearch : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* Search;
	Stdctrls::TButton* Button1;
	Stdctrls::TLabel* Label1;
	Stdctrls::TEdit* Edit1;
	void __fastcall FormKeyPress(System::TObject* Sender, char &Key);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfqbSynMemoSearch(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfqbSynMemoSearch(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfqbSynMemoSearch(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfqbSynMemoSearch(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfqbSynMemoSearch* fqbSynMemoSearch;
extern PACKAGE void __fastcall Register(void);

}	/* namespace Fqbsynmemo */
using namespace Fqbsynmemo;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fqbSynmemo
