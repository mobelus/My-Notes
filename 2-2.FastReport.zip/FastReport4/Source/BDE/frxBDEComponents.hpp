// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxBDEComponents.pas' rev: 6.00

#ifndef frxBDEComponentsHPP
#define frxBDEComponentsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxDBSet.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <DBTables.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <frxCustomDB.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxbdecomponents
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxBDEComponents;
class PASCALIMPLEMENTATION TfrxBDEComponents : public Frxclass::TfrxDBComponents 
{
	typedef Frxclass::TfrxDBComponents inherited;
	
private:
	AnsiString FDefaultDatabase;
	AnsiString FDefaultSession;
	TfrxBDEComponents* FOldComponents;
	
public:
	__fastcall virtual TfrxBDEComponents(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxBDEComponents(void);
	virtual AnsiString __fastcall GetDescription();
	
__published:
	__property AnsiString DefaultDatabase = {read=FDefaultDatabase, write=FDefaultDatabase};
	__property AnsiString DefaultSession = {read=FDefaultSession, write=FDefaultSession};
};


class DELPHICLASS TfrxBDEDatabase;
class PASCALIMPLEMENTATION TfrxBDEDatabase : public Frxclass::TfrxCustomDatabase 
{
	typedef Frxclass::TfrxCustomDatabase inherited;
	
private:
	Dbtables::TDatabase* FDatabase;
	void __fastcall SetAliasName(const AnsiString Value);
	void __fastcall SetDriverName(const AnsiString Value);
	AnsiString __fastcall GetAliasName();
	AnsiString __fastcall GetDriverName();
	
protected:
	virtual bool __fastcall GetConnected(void);
	virtual AnsiString __fastcall GetDatabaseName();
	virtual bool __fastcall GetLoginPrompt(void);
	virtual Classes::TStrings* __fastcall GetParams(void);
	virtual void __fastcall SetConnected(bool Value);
	virtual void __fastcall SetDatabaseName(const AnsiString Value);
	virtual void __fastcall SetLoginPrompt(bool Value);
	virtual void __fastcall SetParams(Classes::TStrings* Value);
	
public:
	__fastcall virtual TfrxBDEDatabase(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	__property Dbtables::TDatabase* Database = {read=FDatabase};
	
__published:
	__property AnsiString AliasName = {read=GetAliasName, write=SetAliasName};
	__property DatabaseName ;
	__property AnsiString DriverName = {read=GetDriverName, write=SetDriverName};
	__property LoginPrompt  = {default=1};
	__property Params ;
	__property Connected  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxDialogComponent.Destroy */ inline __fastcall virtual ~TfrxBDEDatabase(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxBDEDatabase(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxCustomDatabase(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxBDETable;
class PASCALIMPLEMENTATION TfrxBDETable : public Frxcustomdb::TfrxCustomTable 
{
	typedef Frxcustomdb::TfrxCustomTable inherited;
	
private:
	Dbtables::TTable* FTable;
	void __fastcall SetDatabaseName(const AnsiString Value);
	AnsiString __fastcall GetDatabaseName();
	void __fastcall SetSessionName(const AnsiString Value);
	AnsiString __fastcall GetSessionName();
	
protected:
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetMasterFields(const AnsiString Value);
	virtual void __fastcall SetIndexName(const AnsiString Value);
	virtual void __fastcall SetIndexFieldNames(const AnsiString Value);
	virtual void __fastcall SetTableName(const AnsiString Value);
	virtual AnsiString __fastcall GetIndexName();
	virtual AnsiString __fastcall GetIndexFieldNames();
	virtual AnsiString __fastcall GetTableName();
	
public:
	__fastcall virtual TfrxBDETable(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	__property Dbtables::TTable* Table = {read=FTable};
	
__published:
	__property AnsiString DatabaseName = {read=GetDatabaseName, write=SetDatabaseName};
	__property AnsiString SessionName = {read=GetSessionName, write=SetSessionName};
public:
	#pragma option push -w-inl
	/* TfrxCustomDataset.Destroy */ inline __fastcall virtual ~TfrxBDETable(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxBDETable(Classes::TComponent* AOwner, Word Flags) : Frxcustomdb::TfrxCustomTable(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxBDEQuery;
class PASCALIMPLEMENTATION TfrxBDEQuery : public Frxcustomdb::TfrxCustomQuery 
{
	typedef Frxcustomdb::TfrxCustomQuery inherited;
	
private:
	Dbtables::TQuery* FQuery;
	void __fastcall SetDatabaseName(const AnsiString Value);
	AnsiString __fastcall GetDatabaseName();
	void __fastcall SetSessionName(const AnsiString Value);
	AnsiString __fastcall GetSessionName();
	
protected:
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetSQL(Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetSQL(void);
	
public:
	__fastcall virtual TfrxBDEQuery(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall UpdateParams(void);
	__property Dbtables::TQuery* Query = {read=FQuery};
	
__published:
	__property AnsiString DatabaseName = {read=GetDatabaseName, write=SetDatabaseName};
	__property AnsiString SessionName = {read=GetSessionName, write=SetSessionName};
public:
	#pragma option push -w-inl
	/* TfrxCustomQuery.Destroy */ inline __fastcall virtual ~TfrxBDEQuery(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxBDEQuery(Classes::TComponent* AOwner, Word Flags) : Frxcustomdb::TfrxCustomQuery(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxBDEComponents* BDEComponents;

}	/* namespace Frxbdecomponents */
using namespace Frxbdecomponents;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxBDEComponents
