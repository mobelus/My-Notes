// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxADOComponents.pas' rev: 6.00

#ifndef frxADOComponentsHPP
#define frxADOComponentsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxDBSet.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <ADOInt.hpp>	// Pascal unit
#include <ADODB.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <frxCustomDB.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxadocomponents
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxADOComponents;
class PASCALIMPLEMENTATION TfrxADOComponents : public Frxclass::TfrxDBComponents 
{
	typedef Frxclass::TfrxDBComponents inherited;
	
private:
	Adodb::TADOConnection* FDefaultDatabase;
	TfrxADOComponents* FOldComponents;
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TfrxADOComponents(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxADOComponents(void);
	virtual AnsiString __fastcall GetDescription();
	
__published:
	__property Adodb::TADOConnection* DefaultDatabase = {read=FDefaultDatabase, write=FDefaultDatabase};
};


class DELPHICLASS TfrxADODatabase;
class PASCALIMPLEMENTATION TfrxADODatabase : public Frxclass::TfrxCustomDatabase 
{
	typedef Frxclass::TfrxCustomDatabase inherited;
	
private:
	Adodb::TADOConnection* FDatabase;
	
protected:
	virtual void __fastcall SetConnected(bool Value);
	virtual void __fastcall SetDatabaseName(const AnsiString Value);
	virtual void __fastcall SetLoginPrompt(bool Value);
	virtual bool __fastcall GetConnected(void);
	virtual AnsiString __fastcall GetDatabaseName();
	virtual bool __fastcall GetLoginPrompt(void);
	
public:
	__fastcall virtual TfrxADODatabase(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall SetLogin(const AnsiString Login, const AnsiString Password);
	__property Adodb::TADOConnection* Database = {read=FDatabase};
	
__published:
	__property DatabaseName ;
	__property LoginPrompt  = {default=1};
	__property Connected  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxDialogComponent.Destroy */ inline __fastcall virtual ~TfrxADODatabase(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxADODatabase(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxCustomDatabase(AOwner, Flags) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxADOTable;
class PASCALIMPLEMENTATION TfrxADOTable : public Frxcustomdb::TfrxCustomTable 
{
	typedef Frxcustomdb::TfrxCustomTable inherited;
	
private:
	TfrxADODatabase* FDatabase;
	Adodb::TADOTable* FTable;
	void __fastcall SetDatabase(TfrxADODatabase* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetMasterFields(const AnsiString Value);
	virtual void __fastcall SetIndexFieldNames(const AnsiString Value);
	virtual void __fastcall SetIndexName(const AnsiString Value);
	virtual void __fastcall SetTableName(const AnsiString Value);
	virtual AnsiString __fastcall GetIndexFieldNames();
	virtual AnsiString __fastcall GetIndexName();
	virtual AnsiString __fastcall GetTableName();
	
public:
	__fastcall virtual TfrxADOTable(Classes::TComponent* AOwner);
	__fastcall virtual TfrxADOTable(Classes::TComponent* AOwner, Word Flags);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall BeforeStartReport(void);
	__property Adodb::TADOTable* Table = {read=FTable};
	
__published:
	__property TfrxADODatabase* Database = {read=FDatabase, write=SetDatabase};
public:
	#pragma option push -w-inl
	/* TfrxCustomDataset.Destroy */ inline __fastcall virtual ~TfrxADOTable(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxADOQuery;
class PASCALIMPLEMENTATION TfrxADOQuery : public Frxcustomdb::TfrxCustomQuery 
{
	typedef Frxcustomdb::TfrxCustomQuery inherited;
	
private:
	TfrxADODatabase* FDatabase;
	Adodb::TADOQuery* FQuery;
	Classes::TStrings* FStrings;
	bool FLock;
	void __fastcall SetDatabase(TfrxADODatabase* Value);
	int __fastcall GetCommandTimeout(void);
	void __fastcall SetCommandTimeout(const int Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall OnChangeSQL(System::TObject* Sender);
	virtual void __fastcall SetMaster(const Db::TDataSource* Value);
	virtual void __fastcall SetSQL(Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetSQL(void);
	
public:
	__fastcall virtual TfrxADOQuery(Classes::TComponent* AOwner);
	__fastcall virtual TfrxADOQuery(Classes::TComponent* AOwner, Word Flags);
	__fastcall virtual ~TfrxADOQuery(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall BeforeStartReport(void);
	virtual void __fastcall UpdateParams(void);
	__property Adodb::TADOQuery* Query = {read=FQuery};
	
__published:
	__property int CommandTimeout = {read=GetCommandTimeout, write=SetCommandTimeout, nodefault};
	__property TfrxADODatabase* Database = {read=FDatabase, write=SetDatabase};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TfrxADOComponents* ADOComponents;
extern PACKAGE void __fastcall frxParamsToTParameters(Frxcustomdb::TfrxCustomQuery* Query, Adodb::TParameters* Params);
extern PACKAGE void __fastcall frxADOGetTableNames(Adodb::TADOConnection* conADO, Classes::TStrings* List, bool SystemTables);

}	/* namespace Frxadocomponents */
using namespace Frxadocomponents;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxADOComponents
