// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxBarcode.pas' rev: 6.00

#ifndef frxBarcodeHPP
#define frxBarcodeHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <frxBarcod.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxbarcode
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxBarCodeObject;
class PASCALIMPLEMENTATION TfrxBarCodeObject : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfrxBarCodeObject(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxBarCodeObject(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxBarCodeView;
class PASCALIMPLEMENTATION TfrxBarCodeView : public Frxclass::TfrxView 
{
	typedef Frxclass::TfrxView inherited;
	
private:
	Frxbarcod::TfrxBarcode* FBarCode;
	Frxbarcod::TfrxBarcodeType FBarType;
	bool FCalcCheckSum;
	AnsiString FExpression;
	Frxclass::TfrxHAlign FHAlign;
	int FRotation;
	bool FShowText;
	AnsiString FText;
	Extended FWideBarRatio;
	Extended FZoom;
	
public:
	__fastcall virtual TfrxBarCodeView(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxBarCodeView(void);
	virtual void __fastcall Draw(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	virtual void __fastcall GetData(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual Frxclass::TfrxRect __fastcall GetRealBounds();
	__property Frxbarcod::TfrxBarcode* BarCode = {read=FBarCode};
	
__published:
	__property Frxbarcod::TfrxBarcodeType BarType = {read=FBarType, write=FBarType, nodefault};
	__property BrushStyle  = {default=0};
	__property bool CalcCheckSum = {read=FCalcCheckSum, write=FCalcCheckSum, default=0};
	__property Color  = {default=536870911};
	__property Cursor  = {default=0};
	__property DataField ;
	__property DataSet ;
	__property DataSetName ;
	__property AnsiString Expression = {read=FExpression, write=FExpression};
	__property Frame ;
	__property Frxclass::TfrxHAlign HAlign = {read=FHAlign, write=FHAlign, default=0};
	__property int Rotation = {read=FRotation, write=FRotation, nodefault};
	__property bool ShowText = {read=FShowText, write=FShowText, default=1};
	__property TagStr ;
	__property AnsiString Text = {read=FText, write=FText};
	__property URL ;
	__property Extended WideBarRatio = {read=FWideBarRatio, write=FWideBarRatio};
	__property Extended Zoom = {read=FZoom, write=FZoom};
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxBarCodeView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxView(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxbarcode */
using namespace Frxbarcode;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxBarcode
