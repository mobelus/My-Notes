// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxChart.pas' rev: 6.00

#ifndef frxChartHPP
#define frxChartHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <TeCanvas.hpp>	// Pascal unit
#include <Series.hpp>	// Pascal unit
#include <Chart.hpp>	// Pascal unit
#include <TeEngine.hpp>	// Pascal unit
#include <TeeProcs.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxchart
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxChartObject;
class PASCALIMPLEMENTATION TfrxChartObject : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
public:
	#pragma option push -w-inl
	/* TComponent.Create */ inline __fastcall virtual TfrxChartObject(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TComponent.Destroy */ inline __fastcall virtual ~TfrxChartObject(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TfrxSeriesDataType { dtDBData, dtBandData, dtFixedData };
#pragma option pop

#pragma option push -b-
enum TfrxSeriesSortOrder { soNone, soAscending, soDescending };
#pragma option pop

#pragma option push -b-
enum TfrxSeriesXType { xtText, xtNumber, xtDate };
#pragma option pop

typedef TMetaClass*TSeriesClass;

#pragma option push -b-
enum TfrxChartSeries { csLine, csArea, csPoint, csBar, csHorizBar, csPie, csGantt, csFastLine, csArrow, csBubble, csChartShape, csHorizArea, csHorizLine, csPolar, csRadar, csPolarBar, csGauge, csSmith, csPyramid, csDonut, csBezier, csCandle, csVolume, csPointFigure, csHistogram, csHorizHistogram, csErrorBar, csError, csHighLow, csFunnel, csBox, csHorizBox, csSurface, csContour, csWaterFall, csColorGrid, csVector3D, csTower, csTriSurface, csPoint3D, csBubble3D, csMyPoint, csBarJoin, csBar3D };
#pragma option pop

class DELPHICLASS TfrxSeriesItem;
class PASCALIMPLEMENTATION TfrxSeriesItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	Frxclass::TfrxDataBand* FDataBand;
	Frxclass::TfrxDataSet* FDataSet;
	AnsiString FDataSetName;
	TfrxSeriesDataType FDataType;
	TfrxSeriesSortOrder FSortOrder;
	int FTopN;
	AnsiString FTopNCaption;
	AnsiString FSource1;
	AnsiString FSource2;
	AnsiString FSource3;
	AnsiString FSource4;
	AnsiString FSource5;
	AnsiString FSource6;
	TfrxSeriesXType FXType;
	AnsiString FValues1;
	AnsiString FValues2;
	AnsiString FValues3;
	AnsiString FValues4;
	AnsiString FValues5;
	AnsiString FValues6;
	void __fastcall FillSeries(Teengine::TChartSeries* Series);
	void __fastcall SetDataSet(const Frxclass::TfrxDataSet* Value);
	void __fastcall SetDataSetName(const AnsiString Value);
	AnsiString __fastcall GetDataSetName();
	
__published:
	__property TfrxSeriesDataType DataType = {read=FDataType, write=FDataType, nodefault};
	__property Frxclass::TfrxDataBand* DataBand = {read=FDataBand, write=FDataBand};
	__property Frxclass::TfrxDataSet* DataSet = {read=FDataSet, write=SetDataSet};
	__property AnsiString DataSetName = {read=GetDataSetName, write=SetDataSetName};
	__property TfrxSeriesSortOrder SortOrder = {read=FSortOrder, write=FSortOrder, nodefault};
	__property int TopN = {read=FTopN, write=FTopN, nodefault};
	__property AnsiString TopNCaption = {read=FTopNCaption, write=FTopNCaption};
	__property TfrxSeriesXType XType = {read=FXType, write=FXType, nodefault};
	__property AnsiString Source1 = {read=FSource1, write=FSource1};
	__property AnsiString Source2 = {read=FSource2, write=FSource2};
	__property AnsiString Source3 = {read=FSource3, write=FSource3};
	__property AnsiString Source4 = {read=FSource4, write=FSource4};
	__property AnsiString Source5 = {read=FSource5, write=FSource5};
	__property AnsiString Source6 = {read=FSource6, write=FSource6};
	__property AnsiString Values1 = {read=FValues1, write=FValues1};
	__property AnsiString Values2 = {read=FValues2, write=FValues2};
	__property AnsiString Values3 = {read=FValues3, write=FValues3};
	__property AnsiString Values4 = {read=FValues4, write=FValues4};
	__property AnsiString Values5 = {read=FValues5, write=FValues5};
	__property AnsiString Values6 = {read=FValues6, write=FValues6};
	__property AnsiString XSource = {read=FSource1, write=FSource1};
	__property AnsiString YSource = {read=FSource2, write=FSource2};
	__property AnsiString XValues = {read=FValues1, write=FValues1};
	__property AnsiString YValues = {read=FValues2, write=FValues2};
public:
	#pragma option push -w-inl
	/* TCollectionItem.Create */ inline __fastcall virtual TfrxSeriesItem(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TfrxSeriesItem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxSeriesData;
class PASCALIMPLEMENTATION TfrxSeriesData : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
public:
	TfrxSeriesItem* operator[](int Index) { return Items[Index]; }
	
private:
	Frxclass::TfrxReport* FReport;
	TfrxSeriesItem* __fastcall GetSeries(int Index);
	
public:
	__fastcall TfrxSeriesData(Frxclass::TfrxReport* Report);
	HIDESBASE TfrxSeriesItem* __fastcall Add(void);
	__property TfrxSeriesItem* Items[int Index] = {read=GetSeries/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TfrxSeriesData(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxChartView;
class PASCALIMPLEMENTATION TfrxChartView : public Frxclass::TfrxView 
{
	typedef Frxclass::TfrxView inherited;
	
private:
	Chart::TChart* FChart;
	TfrxSeriesData* FSeriesData;
	void __fastcall CreateChart(void);
	void __fastcall FillChart(void);
	void __fastcall ReadData(Classes::TStream* Stream);
	void __fastcall ReadData1(Classes::TReader* Reader);
	void __fastcall ReadData2(Classes::TReader* Reader);
	void __fastcall WriteData(Classes::TStream* Stream);
	void __fastcall WriteData1(Classes::TWriter* Writer);
	void __fastcall WriteData2(Classes::TWriter* Writer);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TfrxChartView(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxChartView(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual void __fastcall Draw(Graphics::TCanvas* Canvas, Extended ScaleX, Extended ScaleY, Extended OffsetX, Extended OffsetY);
	virtual void __fastcall AfterPrint(void);
	virtual void __fastcall GetData(void);
	virtual void __fastcall BeforeStartReport(void);
	virtual void __fastcall OnNotify(System::TObject* Sender);
	void __fastcall ClearSeries(void);
	void __fastcall AddSeries(TfrxChartSeries Series);
	__property Chart::TChart* Chart = {read=FChart};
	__property TfrxSeriesData* SeriesData = {read=FSeriesData};
	
__published:
	__property BrushStyle  = {default=0};
	__property Color  = {default=536870911};
	__property Cursor  = {default=0};
	__property Frame ;
	__property TagStr ;
	__property URL ;
public:
	#pragma option push -w-inl
	/* TfrxComponent.DesignCreate */ inline __fastcall virtual TfrxChartView(Classes::TComponent* AOwner, Word Flags) : Frxclass::TfrxView(AOwner, Flags) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxchart */
using namespace Frxchart;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxChart
