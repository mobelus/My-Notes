// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxExportImage.pas' rev: 6.00

#ifndef frxExportImageHPP
#define frxExportImageHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <jpeg.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxexportimage
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxCustomImageExport;
class PASCALIMPLEMENTATION TfrxCustomImageExport : public Frxclass::TfrxCustomExportFilter 
{
	typedef Frxclass::TfrxCustomExportFilter inherited;
	
private:
	Graphics::TBitmap* FBitmap;
	bool FCrop;
	int FCurrentPage;
	int FJPEGQuality;
	int FMaxX;
	int FMaxY;
	int FMinX;
	int FMinY;
	bool FMonochrome;
	int FResolution;
	int FCurrentRes;
	bool FSeparate;
	int FYOffset;
	AnsiString FFileSuffix;
	bool FFirstPage;
	bool FExportNotPrintable;
	bool __fastcall SizeOverflow(const Extended Val);
	
protected:
	Extended FDiv;
	virtual void __fastcall Save(void);
	void __fastcall FinishExport(void);
	
public:
	__fastcall virtual TfrxCustomImageExport(Classes::TComponent* AOwner);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	virtual bool __fastcall Start(void);
	virtual void __fastcall Finish(void);
	virtual void __fastcall FinishPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall StartPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall ExportObject(Frxclass::TfrxComponent* Obj);
	__property int JPEGQuality = {read=FJPEGQuality, write=FJPEGQuality, default=90};
	__property bool CropImages = {read=FCrop, write=FCrop, default=0};
	__property bool Monochrome = {read=FMonochrome, write=FMonochrome, default=0};
	__property int Resolution = {read=FResolution, write=FResolution, nodefault};
	__property bool SeparateFiles = {read=FSeparate, write=FSeparate, nodefault};
	__property bool ExportNotPrintable = {read=FExportNotPrintable, write=FExportNotPrintable, nodefault};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxCustomImageExport(void) : Frxclass::TfrxCustomExportFilter() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxCustomImageExport(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxBMPExport;
class PASCALIMPLEMENTATION TfrxBMPExport : public TfrxCustomImageExport 
{
	typedef TfrxCustomImageExport inherited;
	
protected:
	virtual void __fastcall Save(void);
	
public:
	__fastcall virtual TfrxBMPExport(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	
__published:
	__property CropImages  = {default=0};
	__property Monochrome  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxBMPExport(void) : TfrxCustomImageExport() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxBMPExport(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxTIFFExport;
class PASCALIMPLEMENTATION TfrxTIFFExport : public TfrxCustomImageExport 
{
	typedef TfrxCustomImageExport inherited;
	
private:
	void __fastcall SaveTiffToStream(const Classes::TStream* Stream, const Graphics::TBitmap* Bitmap);
	
protected:
	virtual void __fastcall Save(void);
	
public:
	__fastcall virtual TfrxTIFFExport(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	
__published:
	__property CropImages  = {default=0};
	__property Monochrome  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxTIFFExport(void) : TfrxCustomImageExport() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxTIFFExport(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxJPEGExport;
class PASCALIMPLEMENTATION TfrxJPEGExport : public TfrxCustomImageExport 
{
	typedef TfrxCustomImageExport inherited;
	
protected:
	virtual void __fastcall Save(void);
	
public:
	__fastcall virtual TfrxJPEGExport(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	
__published:
	__property JPEGQuality  = {default=90};
	__property CropImages  = {default=0};
	__property Monochrome  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxJPEGExport(void) : TfrxCustomImageExport() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxJPEGExport(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxGIFExport;
class PASCALIMPLEMENTATION TfrxGIFExport : public TfrxCustomImageExport 
{
	typedef TfrxCustomImageExport inherited;
	
protected:
	virtual void __fastcall Save(void);
	
public:
	__fastcall virtual TfrxGIFExport(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	
__published:
	__property CropImages  = {default=0};
	__property Monochrome  = {default=0};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxGIFExport(void) : TfrxCustomImageExport() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxGIFExport(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxIMGExportDialog;
class PASCALIMPLEMENTATION TfrxIMGExportDialog : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OK;
	Stdctrls::TButton* Cancel;
	Stdctrls::TGroupBox* GroupPageRange;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TCheckBox* CropPage;
	Stdctrls::TLabel* Label2;
	Stdctrls::TEdit* Quality;
	Stdctrls::TCheckBox* Mono;
	Dialogs::TSaveDialog* SaveDialog1;
	Stdctrls::TLabel* DescrL;
	Stdctrls::TRadioButton* AllRB;
	Stdctrls::TRadioButton* CurPageRB;
	Stdctrls::TRadioButton* PageNumbersRB;
	Stdctrls::TEdit* PageNumbersE;
	Stdctrls::TLabel* Label1;
	Stdctrls::TEdit* Resolution;
	Stdctrls::TCheckBox* SeparateCB;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall PageNumbersEChange(System::TObject* Sender);
	void __fastcall PageNumbersEKeyPress(System::TObject* Sender, char &Key);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	
private:
	TfrxCustomImageExport* FFilter;
	void __fastcall SetFilter(const TfrxCustomImageExport* Value);
	
public:
	__property TfrxCustomImageExport* Filter = {read=FFilter, write=SetFilter};
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxIMGExportDialog(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxIMGExportDialog(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxIMGExportDialog(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxIMGExportDialog(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall GIFSaveToFile(const AnsiString FileName, const Graphics::TBitmap* Bitmap);
extern PACKAGE void __fastcall GIFSaveToStream(const Classes::TStream* Stream, const Graphics::TBitmap* Bitmap);

}	/* namespace Frxexportimage */
using namespace Frxexportimage;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxExportImage
