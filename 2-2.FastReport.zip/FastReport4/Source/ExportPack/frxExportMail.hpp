// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxExportMail.pas' rev: 6.00

#ifndef frxExportMailHPP
#define frxExportMailHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxSMTP.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <IniFiles.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxexportmail
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxMailExportDialog;
class PASCALIMPLEMENTATION TfrxMailExportDialog : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OkB;
	Stdctrls::TButton* CancelB;
	Comctrls::TPageControl* PageControl1;
	Comctrls::TTabSheet* ExportSheet;
	Stdctrls::TGroupBox* MessageGroup;
	Stdctrls::TLabel* AddressLB;
	Stdctrls::TLabel* SubjectLB;
	Stdctrls::TLabel* MessageLB;
	Stdctrls::TMemo* MessageM;
	Stdctrls::TGroupBox* AttachGroup;
	Stdctrls::TComboBox* ExportsCombo;
	Stdctrls::TLabel* FormatLB;
	Stdctrls::TCheckBox* SettingCB;
	Comctrls::TTabSheet* AccountSheet;
	Stdctrls::TGroupBox* MailGroup;
	Stdctrls::TCheckBox* RememberCB;
	Stdctrls::TGroupBox* AccountGroup;
	Stdctrls::TEdit* FromNameE;
	Stdctrls::TLabel* FromNameLB;
	Stdctrls::TEdit* FromAddrE;
	Stdctrls::TLabel* FromAddrLB;
	Stdctrls::TLabel* OrgLB;
	Stdctrls::TEdit* OrgE;
	Stdctrls::TLabel* SignatureLB;
	Stdctrls::TMemo* SignatureM;
	Stdctrls::TLabel* HostLB;
	Stdctrls::TEdit* HostE;
	Stdctrls::TEdit* PortE;
	Stdctrls::TLabel* PortLB;
	Stdctrls::TLabel* LoginLB;
	Stdctrls::TEdit* LoginE;
	Stdctrls::TEdit* PasswordE;
	Stdctrls::TLabel* PasswordLB;
	Stdctrls::TButton* SignBuildBtn;
	Stdctrls::TComboBox* AddressE;
	Stdctrls::TComboBox* SubjectE;
	Stdctrls::TLabel* ReqLB;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall SignBuildBtnClick(System::TObject* Sender);
	void __fastcall OkBClick(System::TObject* Sender);
	void __fastcall PortEKeyPress(System::TObject* Sender, char &Key);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxMailExportDialog(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxMailExportDialog(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxMailExportDialog(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxMailExportDialog(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxMailExport;
class PASCALIMPLEMENTATION TfrxMailExport : public Frxclass::TfrxCustomExportFilter 
{
	typedef Frxclass::TfrxCustomExportFilter inherited;
	
private:
	Frxclass::TfrxCustomExportFilter* FExportFilter;
	AnsiString FAddress;
	AnsiString FSubject;
	Classes::TStrings* FMessage;
	bool FShowExportDialog;
	bool FOldSlaveStatus;
	AnsiString FFromName;
	AnsiString FFromMail;
	AnsiString FFromCompany;
	Classes::TStrings* FSignature;
	AnsiString FSmtpHost;
	int FSmtpPort;
	AnsiString FLogin;
	AnsiString FPassword;
	bool FUseIniFile;
	AnsiString FLogFile;
	void __fastcall SetMessage(const Classes::TStrings* Value);
	void __fastcall SetSignature(const Classes::TStrings* Value);
	
protected:
	__property DefaultPath ;
	__property Stream ;
	__property CurPage ;
	__property PageNumbers ;
	__property FileName ;
	__property UseFileCache ;
	__property ExportNotPrintable  = {default=0};
	
public:
	__fastcall virtual TfrxMailExport(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxMailExport(void);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	virtual bool __fastcall Start(void);
	AnsiString __fastcall Mail(const AnsiString Server, const int Port, const AnsiString UserField, const AnsiString PasswordField, const AnsiString FromField, const AnsiString ToField, const AnsiString SubjectField, const AnsiString TextField, const AnsiString FileName, const AnsiString AttachName);
	virtual void __fastcall ExportObject(Frxclass::TfrxComponent* Obj);
	__property Frxclass::TfrxCustomExportFilter* ExportFilter = {read=FExportFilter, write=FExportFilter};
	
__published:
	__property AnsiString Address = {read=FAddress, write=FAddress};
	__property AnsiString Subject = {read=FSubject, write=FSubject};
	__property Classes::TStrings* Lines = {read=FMessage, write=SetMessage};
	__property bool ShowExportDialog = {read=FShowExportDialog, write=FShowExportDialog, nodefault};
	__property AnsiString FromMail = {read=FFromMail, write=FFromMail};
	__property AnsiString FromName = {read=FFromName, write=FFromName};
	__property AnsiString FromCompany = {read=FFromCompany, write=FFromCompany};
	__property Classes::TStrings* Signature = {read=FSignature, write=SetSignature};
	__property AnsiString SmtpHost = {read=FSmtpHost, write=FSmtpHost};
	__property int SmtpPort = {read=FSmtpPort, write=FSmtpPort, nodefault};
	__property AnsiString Login = {read=FLogin, write=FLogin};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property bool UseIniFile = {read=FUseIniFile, write=FUseIniFile, nodefault};
	__property AnsiString LogFile = {read=FLogFile, write=FLogFile};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxMailExport(void) : Frxclass::TfrxCustomExportFilter() { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxexportmail */
using namespace Frxexportmail;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxExportMail
