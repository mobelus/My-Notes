// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxExportTXT.pas' rev: 6.00

#ifndef frxExportTXTHPP
#define frxExportTXTHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <frxProgress.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxexporttxt
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxTXTExportDialog;
class DELPHICLASS TfrxTXTExport;
typedef DynamicArray<char >  frxExportTXT__4;

struct TfrxTXTStyle;
typedef TfrxTXTStyle *PfrxTXTStyle;

#pragma pack(push, 1)
struct TfrxTXTPrinterCommand
{
	AnsiString Name;
	AnsiString SwitchOn;
	AnsiString SwitchOff;
	bool Trigger;
} ;
#pragma pack(pop)

typedef TfrxTXTPrinterCommand frxExportTXT__2[32];

#pragma pack(push, 1)
struct TfrxTXTPrinterType
{
	AnsiString name;
	int CommCount;
	TfrxTXTPrinterCommand Commands[32];
} ;
#pragma pack(pop)

typedef TfrxTXTPrinterType frxExportTXT__5[16];

class PASCALIMPLEMENTATION TfrxTXTExport : public Frxclass::TfrxCustomExportFilter 
{
	typedef Frxclass::TfrxCustomExportFilter inherited;
	
private:
	int CurrentPage;
	bool FirstPage;
	int CurY;
	Classes::TList* RX;
	Classes::TList* RY;
	Classes::TList* ObjectPos;
	Classes::TList* PageObj;
	Classes::TList* StyleList;
	Extended CY;
	Extended LastY;
	TfrxTXTExportDialog* frExportSet;
	Classes::TStringList* pgBreakList;
	bool expBorders;
	bool expBordersGraph;
	bool expPrintAfter;
	bool expUseSavedProps;
	bool expPrinterDialog;
	bool expPageBreaks;
	bool expOEM;
	bool expEmptyLines;
	bool expLeadSpaces;
	AnsiString expCustomFrameSet;
	Extended expScaleX;
	Extended expScaleY;
	Extended MaxWidth;
	DynamicArray<char >  Scr;
	int ScrWidth;
	int ScrHeight;
	AnsiString PrinterInitString;
	Classes::TFileStream* Stream;
	void __fastcall WriteExpLn(const AnsiString str);
	void __fastcall WriteExp(const AnsiString str);
	void __fastcall ObjCellAdd(Classes::TList* Vector, Extended Value);
	void __fastcall ObjPosAdd(Classes::TList* Vector, int x, int y, int dx, int dy, int obj);
	bool __fastcall CompareStyles(PfrxTXTStyle Style1, PfrxTXTStyle Style2);
	int __fastcall FindStyle(PfrxTXTStyle Style);
	void __fastcall MakeStyleList(void);
	void __fastcall ClearLastPage(void);
	void __fastcall OrderObjectByCells(void);
	void __fastcall ExportPage(void);
	AnsiString __fastcall ChangeReturns(const AnsiString Str);
	AnsiString __fastcall TruncReturns(const AnsiString Str);
	void __fastcall AfterExport(const AnsiString FileName);
	void __fastcall PrepareExportPage(void);
	void __fastcall DrawMemo(int x, int y, int dx, int dy, AnsiString text, int st);
	void __fastcall FlushScr(void);
	void __fastcall CreateScr(int dx, int dy);
	void __fastcall FreeScr(void);
	void __fastcall ScrType(int x, int y, char c);
	char __fastcall ScrGet(int x, int y);
	void __fastcall ScrString(int x, int y, const AnsiString s);
	void __fastcall FormFeed(void);
	AnsiString __fastcall MakeInitString();
	
public:
	int PrintersCount;
	TfrxTXTPrinterType PrinterTypes[16];
	int SelectedPrinterType;
	int PageWidth;
	int PageHeight;
	bool IsPreview;
	int Copys;
	__fastcall virtual TfrxTXTExport(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxTXTExport(void);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	virtual bool __fastcall Start(void);
	virtual void __fastcall Finish(void);
	virtual void __fastcall FinishPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall StartPage(Frxclass::TfrxReportPage* Page, int Index);
	virtual void __fastcall ExportObject(Frxclass::TfrxComponent* Obj);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	int __fastcall RegisterPrinterType(const AnsiString Name);
	void __fastcall RegisterPrinterCommand(int PrinterIndex, const AnsiString Name, const AnsiString switch_on, const AnsiString switch_off);
	void __fastcall LoadPrinterInit(const AnsiString FName);
	void __fastcall SavePrinterInit(const AnsiString FName);
	void __fastcall SpoolFile(const AnsiString FileName);
	
__published:
	__property Extended ScaleWidth = {read=expScaleX, write=expScaleX};
	__property Extended ScaleHeight = {read=expScaleY, write=expScaleY};
	__property bool Borders = {read=expBorders, write=expBorders, nodefault};
	__property bool Pseudogrpahic = {read=expBordersGraph, write=expBordersGraph, nodefault};
	__property bool PageBreaks = {read=expPageBreaks, write=expPageBreaks, nodefault};
	__property bool OEMCodepage = {read=expOEM, write=expOEM, nodefault};
	__property bool EmptyLines = {read=expEmptyLines, write=expEmptyLines, nodefault};
	__property bool LeadSpaces = {read=expLeadSpaces, write=expLeadSpaces, nodefault};
	__property bool PrintAfter = {read=expPrintAfter, write=expPrintAfter, nodefault};
	__property bool PrinterDialog = {read=expPrinterDialog, write=expPrinterDialog, nodefault};
	__property bool UseSavedProps = {read=expUseSavedProps, write=expUseSavedProps, nodefault};
	__property AnsiString InitString = {read=PrinterInitString, write=PrinterInitString};
	__property AnsiString CustomFrameSet = {read=expCustomFrameSet, write=expCustomFrameSet};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxTXTExport(void) : Frxclass::TfrxCustomExportFilter() { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TfrxTXTExportDialog : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OK;
	Stdctrls::TButton* Cancel;
	Extctrls::TPanel* Panel1;
	Stdctrls::TGroupBox* GroupCellProp;
	Stdctrls::TGroupBox* GroupPageRange;
	Stdctrls::TLabel* Pages;
	Stdctrls::TLabel* Descr;
	Stdctrls::TEdit* E_Range;
	Stdctrls::TGroupBox* GroupScaleSettings;
	Stdctrls::TLabel* ScX;
	Stdctrls::TLabel* Label2;
	Stdctrls::TLabel* ScY;
	Stdctrls::TLabel* Label9;
	Stdctrls::TEdit* E_ScaleX;
	Stdctrls::TCheckBox* CB_PageBreaks;
	Stdctrls::TGroupBox* GroupFramesSettings;
	Stdctrls::TRadioButton* RB_NoneFrames;
	Stdctrls::TRadioButton* RB_Simple;
	Stdctrls::TRadioButton* RB_Graph;
	Stdctrls::TCheckBox* CB_OEM;
	Stdctrls::TCheckBox* CB_EmptyLines;
	Stdctrls::TCheckBox* CB_LeadSpaces;
	Stdctrls::TCheckBox* CB_PrintAfter;
	Extctrls::TPanel* Panel2;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TLabel* Label1;
	Stdctrls::TLabel* Label3;
	Stdctrls::TLabel* PgHeight;
	Stdctrls::TLabel* PgWidth;
	Stdctrls::TMemo* Preview;
	Stdctrls::TEdit* EPage;
	Comctrls::TUpDown* PageUpDown;
	Stdctrls::TLabel* LBPage;
	Buttons::TSpeedButton* ToolButton1;
	Buttons::TSpeedButton* ToolButton2;
	Buttons::TSpeedButton* BtnPreview;
	Dialogs::TSaveDialog* SaveDialog1;
	Comctrls::TUpDown* UpDown1;
	Comctrls::TUpDown* UpDown2;
	Stdctrls::TEdit* E_ScaleY;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall CB_OEMClick(System::TObject* Sender);
	void __fastcall RefreshClick(System::TObject* Sender);
	void __fastcall FormClose(System::TObject* Sender, Forms::TCloseAction &Action);
	void __fastcall FormActivate(System::TObject* Sender);
	void __fastcall E_ScaleXChange(System::TObject* Sender);
	void __fastcall BtnPreviewClick(System::TObject* Sender);
	void __fastcall ToolButton1Click(System::TObject* Sender);
	void __fastcall ToolButton2Click(System::TObject* Sender);
	void __fastcall UpDown1Changing(System::TObject* Sender, bool &AllowChange);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	
private:
	TfrxTXTExport* TxtExp;
	bool Flag;
	bool created;
	bool MakeInit;
	bool running;
	int printer;
	
public:
	int PagesCount;
	TfrxTXTExport* Exporter;
	bool PreviewActive;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxTXTExportDialog(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxTXTExportDialog(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxTXTExportDialog(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxTXTExportDialog(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


#pragma pack(push, 1)
struct TfrxTXTStyle
{
	Graphics::TFont* Font;
	Frxclass::TfrxVAlign VAlignment;
	Frxclass::TfrxHAlign HAlignment;
	Frxclass::TfrxFrameTypes FrameTyp;
	float FrameWidth;
	Graphics::TColor FrameColor;
	Frxclass::TfrxFrameStyle FrameStyle;
	Graphics::TColor FillColor;
	bool IsText;
} ;
#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxexporttxt */
using namespace Frxexporttxt;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxExportTXT
