// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxExportMatrix.pas' rev: 6.00

#ifndef frxExportMatrixHPP
#define frxExportMatrixHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <frxUnicodeUtils.hpp>	// Pascal unit
#include <frxUtils.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <frxProgress.hpp>	// Pascal unit
#include <frxPreviewPages.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxexportmatrix
{
//-- type declarations -------------------------------------------------------
typedef DynamicArray<int >  frxExportMatrix__2;

class DELPHICLASS TfrxIEMatrix;
class DELPHICLASS TfrxIEMStyle;
class DELPHICLASS TfrxIEMObject;
class PASCALIMPLEMENTATION TfrxIEMatrix : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TList* FIEMObjectList;
	Classes::TList* FIEMStyleList;
	Classes::TList* FXPos;
	Classes::TList* FYPos;
	Classes::TList* FPages;
	int FWidth;
	int FHeight;
	Extended FMaxWidth;
	Extended FMaxHeight;
	Extended FMinLeft;
	Extended FMinTop;
	DynamicArray<int >  FMatrix;
	Extended FDeltaY;
	bool FShowProgress;
	Extended FMaxCellHeight;
	Extended FMaxCellWidth;
	Extended FInaccuracy;
	Frxprogress::TfrxProgress* FProgress;
	bool FRotatedImage;
	bool FPlainRich;
	bool FRichText;
	bool FCropFillArea;
	bool FFillArea;
	bool FOptFrames;
	Extended FLeft;
	Extended FTop;
	bool FDeleteHTMLTags;
	bool FBackImage;
	bool FBackground;
	Frxclass::TfrxReport* FReport;
	bool FPrintable;
	bool FImages;
	bool FWrap;
	bool FEmptyLines;
	Frxclass::TfrxBand* FHeader;
	Frxclass::TfrxBand* FFooter;
	bool FBrushAsBitmap;
	int __fastcall AddStyleInternal(TfrxIEMStyle* Style);
	int __fastcall AddStyle(Frxclass::TfrxView* Obj);
	int __fastcall AddInternalObject(TfrxIEMObject* Obj, int x, int y, int dx, int dy);
	bool __fastcall IsMemo(Frxclass::TfrxView* Obj);
	bool __fastcall IsLine(Frxclass::TfrxView* Obj);
	bool __fastcall IsRect(Frxclass::TfrxView* Obj);
	bool __fastcall QuickFind(Classes::TList* aList, Extended aPosition, int &Index);
	void __fastcall SetCell(int x, int y, int Value);
	void __fastcall FillArea(int x, int y, int dx, int dy, int Value);
	void __fastcall ReplaceArea(int ObjIndex, int x, int y, int dx, int dy, int Value);
	void __fastcall FindRectArea(int x, int y, int &dx, int &dy);
	void __fastcall CutObject(int ObjIndex, int x, int y, int dx, int dy);
	void __fastcall CloneFrames(int Obj1, int Obj2);
	void __fastcall AddPos(Classes::TList* List, Extended Value);
	void __fastcall OrderPosArray(Classes::TList* List, bool Vert);
	void __fastcall OrderByCells(void);
	void __fastcall Render(void);
	void __fastcall Analyse(void);
	void __fastcall OptimizeFrames(void);
	
public:
	__fastcall TfrxIEMatrix(const bool UseFileCache, const AnsiString TempDir);
	__fastcall virtual ~TfrxIEMatrix(void);
	int __fastcall GetFontCharset(Graphics::TFont* Font);
	int __fastcall GetCell(int x, int y);
	TfrxIEMObject* __fastcall GetObjectById(int ObjIndex);
	TfrxIEMStyle* __fastcall GetStyleById(int StyleIndex);
	Extended __fastcall GetXPosById(int PosIndex);
	Extended __fastcall GetYPosById(int PosIndex);
	TfrxIEMObject* __fastcall GetObject(int x, int y);
	TfrxIEMStyle* __fastcall GetStyle(int x, int y);
	Extended __fastcall GetCellXPos(int x);
	Extended __fastcall GetCellYPos(int y);
	void __fastcall DeleteMatrixLine(int y);
	int __fastcall GetStylesCount(void);
	int __fastcall GetPagesCount(void);
	int __fastcall GetObjectsCount(void);
	void __fastcall Clear(void);
	void __fastcall AddObject(Frxclass::TfrxView* Obj);
	void __fastcall AddDialogObject(Frxclass::TfrxReportComponent* Obj);
	void __fastcall AddPage(Printers::TPrinterOrientation Orientation, Extended Width, Extended Height, Extended LeftMargin, Extended TopMargin, Extended RightMargin, Extended BottomMargin);
	void __fastcall Prepare(void);
	void __fastcall GetObjectPos(int ObjIndex, int &x, int &y, int &dx, int &dy);
	Extended __fastcall GetPageBreak(int Page);
	Extended __fastcall GetPageWidth(int Page);
	Extended __fastcall GetPageHeight(int Page);
	Extended __fastcall GetPageLMargin(int Page);
	Extended __fastcall GetPageTMargin(int Page);
	Extended __fastcall GetPageRMargin(int Page);
	Extended __fastcall GetPageBMargin(int Page);
	Printers::TPrinterOrientation __fastcall GetPageOrientation(int Page);
	void __fastcall SetPageHeader(Frxclass::TfrxBand* Band);
	void __fastcall SetPageFooter(Frxclass::TfrxBand* Band);
	__property int Width = {read=FWidth, nodefault};
	__property int Height = {read=FHeight, nodefault};
	__property Extended MaxWidth = {read=FMaxWidth};
	__property Extended MaxHeight = {read=FMaxHeight};
	__property Extended MinLeft = {read=FMinLeft};
	__property Extended MinTop = {read=FMinTop};
	__property bool ShowProgress = {read=FShowProgress, write=FShowProgress, nodefault};
	__property Extended MaxCellHeight = {read=FMaxCellHeight, write=FMaxCellHeight};
	__property Extended MaxCellWidth = {read=FMaxCellWidth, write=FMaxCellWidth};
	__property int PagesCount = {read=GetPagesCount, nodefault};
	__property int StylesCount = {read=GetStylesCount, nodefault};
	__property int ObjectsCount = {read=GetObjectsCount, nodefault};
	__property Extended Inaccuracy = {read=FInaccuracy, write=FInaccuracy};
	__property bool RotatedAsImage = {read=FRotatedImage, write=FRotatedImage, nodefault};
	__property bool RichText = {read=FRichText, write=FRichText, nodefault};
	__property bool PlainRich = {read=FPlainRich, write=FPlainRich, nodefault};
	__property bool AreaFill = {read=FFillArea, write=FFillArea, nodefault};
	__property bool CropAreaFill = {read=FCropFillArea, write=FCropFillArea, nodefault};
	__property bool FramesOptimization = {read=FOptFrames, write=FOptFrames, nodefault};
	__property bool DeleteHTMLTags = {read=FDeleteHTMLTags, write=FDeleteHTMLTags, nodefault};
	__property Extended Left = {read=FLeft};
	__property Extended Top = {read=FTop};
	__property bool BackgroundImage = {read=FBackImage, write=FBackImage, nodefault};
	__property bool Background = {read=FBackground, write=FBackground, nodefault};
	__property Frxclass::TfrxReport* Report = {read=FReport, write=FReport};
	__property bool Printable = {read=FPrintable, write=FPrintable, nodefault};
	__property bool Images = {read=FImages, write=FImages, nodefault};
	__property bool WrapText = {read=FWrap, write=FWrap, nodefault};
	__property bool EmptyLines = {read=FEmptyLines, write=FEmptyLines, nodefault};
	__property bool BrushAsBitmap = {read=FBrushAsBitmap, write=FBrushAsBitmap, nodefault};
};


class PASCALIMPLEMENTATION TfrxIEMObject : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Frxunicodeutils::TWideStrings* FMemo;
	AnsiString FURL;
	int FStyleIndex;
	TfrxIEMStyle* FStyle;
	bool FIsText;
	bool FIsRichText;
	bool FIsDialogObject;
	Extended FLeft;
	Extended FTop;
	Extended FWidth;
	Extended FHeight;
	Graphics::TBitmap* FImage;
	TfrxIEMObject* FParent;
	int FCounter;
	System::TObject* FLink;
	bool FRTL;
	AnsiString FAnchor;
	bool FCached;
	bool FFooter;
	bool FHeader;
	AnsiString FName;
	bool FHTMLTags;
	void __fastcall SetMemo(const Frxunicodeutils::TWideStrings* Value);
	Graphics::TBitmap* __fastcall GetImage(void);
	void __fastcall SetImage(const Graphics::TBitmap* Value);
	
public:
	__fastcall TfrxIEMObject(void);
	__fastcall virtual ~TfrxIEMObject(void);
	__property Frxunicodeutils::TWideStrings* Memo = {read=FMemo, write=SetMemo};
	__property AnsiString URL = {read=FURL, write=FURL};
	__property int StyleIndex = {read=FStyleIndex, write=FStyleIndex, nodefault};
	__property bool IsText = {read=FIsText, write=FIsText, nodefault};
	__property bool IsRichText = {read=FIsRichText, write=FIsRichText, nodefault};
	__property bool IsDialogObject = {read=FIsDialogObject, write=FIsDialogObject, nodefault};
	__property Extended Left = {read=FLeft, write=FLeft};
	__property Extended Top = {read=FTop, write=FTop};
	__property Extended Width = {read=FWidth, write=FWidth};
	__property Extended Height = {read=FHeight, write=FHeight};
	__property Graphics::TBitmap* Image = {read=GetImage, write=SetImage};
	__property TfrxIEMObject* Parent = {read=FParent, write=FParent};
	__property TfrxIEMStyle* Style = {read=FStyle, write=FStyle};
	__property int Counter = {read=FCounter, write=FCounter, nodefault};
	__property System::TObject* Link = {read=FLink, write=FLink};
	__property bool RTL = {read=FRTL, write=FRTL, nodefault};
	__property AnsiString Anchor = {read=FAnchor, write=FAnchor};
	__property bool Cached = {read=FCached, write=FCached, nodefault};
	__property bool Footer = {read=FFooter, write=FFooter, nodefault};
	__property bool Header = {read=FHeader, write=FHeader, nodefault};
	__property AnsiString Name = {read=FName, write=FName};
	__property bool HTMLTags = {read=FHTMLTags, write=FHTMLTags, nodefault};
};


class DELPHICLASS TfrxIEMObjectList;
class PASCALIMPLEMENTATION TfrxIEMObjectList : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TfrxIEMObject* Obj;
	int x;
	int y;
	int dx;
	int dy;
	bool Exist;
	__fastcall TfrxIEMObjectList(void);
	__fastcall virtual ~TfrxIEMObjectList(void);
};


class DELPHICLASS TfrxIEMPos;
class PASCALIMPLEMENTATION TfrxIEMPos : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	Extended Value;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxIEMPos(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxIEMPos(void) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxIEMPage;
class PASCALIMPLEMENTATION TfrxIEMPage : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	Extended Value;
	Printers::TPrinterOrientation Orientation;
	Extended Width;
	Extended Height;
	Extended LeftMargin;
	Extended TopMargin;
	Extended BottomMargin;
	Extended RightMargin;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TfrxIEMPage(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TfrxIEMPage(void) { }
	#pragma option pop
	
};


class PASCALIMPLEMENTATION TfrxIEMStyle : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	Graphics::TFont* Font;
	Extended LineSpacing;
	Frxclass::TfrxVAlign VAlign;
	Frxclass::TfrxHAlign HAlign;
	Frxclass::TfrxFrameTypes FrameTyp;
	float FrameWidth;
	Graphics::TColor FrameColor;
	Frxclass::TfrxFrameStyle FrameStyle;
	Graphics::TColor Color;
	int Rotation;
	Graphics::TBrushStyle BrushStyle;
	Extended ParagraphGap;
	Extended GapX;
	Extended GapY;
	Extended CharSpacing;
	bool WordBreak;
	int Charset;
	Frxclass::TfrxFormat* FDisplayFormat;
	__fastcall TfrxIEMStyle(void);
	__fastcall virtual ~TfrxIEMStyle(void);
	void __fastcall Assign(TfrxIEMStyle* Style);
	void __fastcall SetDisplayFormat(const Frxclass::TfrxFormat* Value);
	__property Frxclass::TfrxFormat* DisplayFormat = {read=FDisplayFormat, write=SetDisplayFormat};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxexportmatrix */
using namespace Frxexportmatrix;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxExportMatrix
