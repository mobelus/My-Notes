// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxNetUtils.pas' rev: 6.00

#ifndef frxNetUtilsHPP
#define frxNetUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Registry.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxnetutils
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString __fastcall GMTDateTimeToRFCDateTime(const System::TDateTime D);
extern PACKAGE AnsiString __fastcall DateTimeToRFCDateTime(const System::TDateTime D);
extern PACKAGE AnsiString __fastcall PadLeft(const AnsiString S, const char PadChar, const int Len);
extern PACKAGE AnsiString __fastcall PadRight(const AnsiString S, const char PadChar, const int Len);
extern PACKAGE AnsiString __fastcall Base64Encode(const AnsiString S);
extern PACKAGE AnsiString __fastcall Base64Decode(const AnsiString S);
extern PACKAGE AnsiString __fastcall GetFileMIMEType(const AnsiString FileName);
extern PACKAGE AnsiString __fastcall GetSocketErrorText(const int ErrorCode);
extern PACKAGE void __fastcall PMessages(void);
extern PACKAGE AnsiString __fastcall ParseHeaderField(const AnsiString Field, const AnsiString Header);

}	/* namespace Frxnetutils */
using namespace Frxnetutils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxNetUtils
