// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxSMTP.pas' rev: 6.00

#ifndef frxSMTPHPP
#define frxSMTPHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxProgress.hpp>	// Pascal unit
#include <frxNetUtils.hpp>	// Pascal unit
#include <ScktComp.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxsmtp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxSMTPClient;
class DELPHICLASS TfrxSMTPClientThread;
class PASCALIMPLEMENTATION TfrxSMTPClientThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
protected:
	TfrxSMTPClient* FClient;
	void __fastcall DoOpen(void);
	virtual void __fastcall Execute(void);
	
public:
	Scktcomp::TClientSocket* FSocket;
	__fastcall TfrxSMTPClientThread(TfrxSMTPClient* Client);
	__fastcall virtual ~TfrxSMTPClientThread(void);
};


class PASCALIMPLEMENTATION TfrxSMTPClient : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	bool FActive;
	bool FBreaked;
	Classes::TStrings* FErrors;
	AnsiString FHost;
	int FPort;
	TfrxSMTPClientThread* FThread;
	int FTimeOut;
	AnsiString FPassword;
	AnsiString FMailTo;
	AnsiString FUser;
	AnsiString FMailFile;
	AnsiString FMailFrom;
	AnsiString FMailSubject;
	AnsiString FMailText;
	AnsiString FAnswer;
	bool FAccepted;
	AnsiString FAuth;
	int FCode;
	bool FSending;
	AnsiString FAttachName;
	Frxprogress::TfrxProgress* FProgress;
	bool FShowProgress;
	AnsiString FLogFile;
	Classes::TStringList* FLog;
	Classes::TStringList* FAnswerList;
	bool F200Flag;
	bool F210Flag;
	bool F215Flag;
	AnsiString FUserName;
	void __fastcall DoConnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoDisconnect(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall DoError(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket, Scktcomp::TErrorEvent ErrorEvent, int &ErrorCode);
	void __fastcall DoRead(System::TObject* Sender, Scktcomp::TCustomWinSocket* Socket);
	void __fastcall SetActive(const bool Value);
	void __fastcall AddLogIn(const AnsiString s);
	void __fastcall AddLogOut(const AnsiString s);
	AnsiString __fastcall DomainByEmail(const AnsiString addr);
	
public:
	__fastcall virtual TfrxSMTPClient(Classes::TComponent* AOwner);
	__fastcall virtual ~TfrxSMTPClient(void);
	void __fastcall Connect(void);
	void __fastcall Disconnect(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	__property bool Breaked = {read=FBreaked, nodefault};
	__property Classes::TStrings* Errors = {read=FErrors, write=FErrors};
	__property AnsiString LogFile = {read=FLogFile, write=FLogFile};
	
__published:
	__property bool Active = {read=FActive, write=SetActive, nodefault};
	__property AnsiString Host = {read=FHost, write=FHost};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, nodefault};
	__property AnsiString UserName = {read=FUserName, write=FUserName};
	__property AnsiString User = {read=FUser, write=FUser};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property AnsiString MailFrom = {read=FMailFrom, write=FMailFrom};
	__property AnsiString MailTo = {read=FMailTo, write=FMailTo};
	__property AnsiString MailSubject = {read=FMailSubject, write=FMailSubject};
	__property AnsiString MailText = {read=FMailText, write=FMailText};
	__property AnsiString MailFile = {read=FMailFile, write=FMailFile};
	__property AnsiString AttachName = {read=FAttachName, write=FAttachName};
	__property bool ShowProgress = {read=FShowProgress, write=FShowProgress, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxsmtp */
using namespace Frxsmtp;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxSMTP
