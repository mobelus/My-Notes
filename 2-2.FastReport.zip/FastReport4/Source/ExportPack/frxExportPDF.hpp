// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'frxExportPDF.pas' rev: 6.00

#ifndef frxExportPDFHPP
#define frxExportPDFHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <frxPDFFile.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <ShellAPI.hpp>	// Pascal unit
#include <jpeg.hpp>	// Pascal unit
#include <frxClass.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <ComObj.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxexportpdf
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfrxPDFExportDialog;
class PASCALIMPLEMENTATION TfrxPDFExportDialog : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TButton* OkB;
	Stdctrls::TButton* CancelB;
	Stdctrls::TGroupBox* GroupPageRange;
	Stdctrls::TLabel* DescrL;
	Stdctrls::TRadioButton* AllRB;
	Stdctrls::TRadioButton* CurPageRB;
	Stdctrls::TRadioButton* PageNumbersRB;
	Stdctrls::TEdit* PageNumbersE;
	Stdctrls::TGroupBox* GroupQuality;
	Stdctrls::TCheckBox* CompressedCB;
	Stdctrls::TCheckBox* OpenCB;
	Dialogs::TSaveDialog* SaveDialog1;
	Stdctrls::TCheckBox* EmbeddedCB;
	Stdctrls::TCheckBox* PrintOptCB;
	Stdctrls::TCheckBox* OutlineCB;
	Stdctrls::TCheckBox* BackgrCB;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall PageNumbersEChange(System::TObject* Sender);
	void __fastcall PageNumbersEKeyPress(System::TObject* Sender, char &Key);
	void __fastcall FormKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TfrxPDFExportDialog(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TfrxPDFExportDialog(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TfrxPDFExportDialog(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TfrxPDFExportDialog(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TfrxPDFExport;
class PASCALIMPLEMENTATION TfrxPDFExport : public Frxclass::TfrxCustomExportFilter 
{
	typedef Frxclass::TfrxCustomExportFilter inherited;
	
private:
	bool FCompressed;
	bool FEmbedded;
	bool FOpenAfterExport;
	Frxpdffile::TfrxPDFFile* FPDF;
	Frxpdffile::TfrxPDFPage* FPDFpage;
	bool FPrintOpt;
	bool FOutline;
	WideString FSubject;
	WideString FAuthor;
	bool FBackground;
	WideString FCreator;
	bool FTags;
	
public:
	__fastcall virtual TfrxPDFExport(Classes::TComponent* AOwner);
	/* virtual class method */ virtual AnsiString __fastcall GetDescription(TMetaClass* vmt);
	virtual Controls::TModalResult __fastcall ShowModal(void);
	virtual bool __fastcall Start(void);
	virtual void __fastcall ExportObject(Frxclass::TfrxComponent* Obj);
	virtual void __fastcall Finish(void);
	virtual void __fastcall StartPage(Frxclass::TfrxReportPage* Page, int Index);
	
__published:
	__property bool Compressed = {read=FCompressed, write=FCompressed, default=1};
	__property bool EmbeddedFonts = {read=FEmbedded, write=FEmbedded, default=0};
	__property bool OpenAfterExport = {read=FOpenAfterExport, write=FOpenAfterExport, default=0};
	__property bool PrintOptimized = {read=FPrintOpt, write=FPrintOpt, nodefault};
	__property bool Outline = {read=FOutline, write=FOutline, nodefault};
	__property WideString Author = {read=FAuthor, write=FAuthor};
	__property WideString Subject = {read=FSubject, write=FSubject};
	__property bool Background = {read=FBackground, write=FBackground, nodefault};
	__property WideString Creator = {read=FCreator, write=FCreator};
	__property bool HTMLTags = {read=FTags, write=FTags, nodefault};
public:
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.CreateNoRegister */ inline __fastcall TfrxPDFExport(void) : Frxclass::TfrxCustomExportFilter() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TfrxCustomExportFilter.Destroy */ inline __fastcall virtual ~TfrxPDFExport(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxexportpdf */
using namespace Frxexportpdf;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// frxExportPDF
