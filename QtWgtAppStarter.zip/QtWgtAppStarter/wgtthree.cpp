#include "wgtthree.h"
#include "ui_wgtthree.h"

WgtThree::WgtThree(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WgtThree)
{
    ui->setupUi(this);
}

WgtThree::~WgtThree()
{
    delete ui;
}
