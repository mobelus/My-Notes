#ifndef LOCALQUESTIONDIALOG_H
#define LOCALQUESTIONDIALOG_H

#include <QDialog>

namespace Ui {
class LocalQuestionDialog;
}
/*
class LocalQuestionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LocalQuestionDialog(QWidget *parent = 0);
    ~LocalQuestionDialog();

private:
    Ui::LocalQuestionDialog *ui;
};
*/

#include <QWidget>
#include <QMessageBox>
#include <QDialog>
#include <QPushButton>

class LocalQuestionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LocalQuestionDialog(QWidget *parent = nullptr);
    ~LocalQuestionDialog();

    explicit LocalQuestionDialog(const QString &questionText, const QString &acceptButtonText, QWidget *parent);

    explicit LocalQuestionDialog(const QString &questionText, const QString &acceptButtonText,
                                 const QString &rejectButtonText, QWidget *parent);

    void setText(QString s);

    /*bool wasAcceptButtonClicked() { return (clickedButton() == mAcceptButton); }
    bool wasCancelButtonClicked() { return (clickedButton() == mCancelButton); }*/

    void centerQuestionDialog(QRect parentRect, QSize dlgSize);

private:
    QPushButton *mAcceptButton = nullptr;
    QPushButton *mCancelButton = nullptr;

    const QString mQuestiondialogCss = ":/gui/themes/dark/questiondialog.css";
};

#endif // LOCALQUESTIONDIALOG_H
