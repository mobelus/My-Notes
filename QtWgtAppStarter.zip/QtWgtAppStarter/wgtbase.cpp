#include "wgtbase.h"
//#include "ui_wgtone.h"

WgtBase::WgtBase(QWidget *parent) : QWidget(parent) //, ui(new Ui::WgtOne)
{
    // ui->setupUi(this);
}
WgtBase::~WgtBase()
{
    // delete ui;
}
