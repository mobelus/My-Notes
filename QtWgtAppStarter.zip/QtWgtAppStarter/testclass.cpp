#include "testclass.h"

TestClass::TestClass(QObject *parent) : QObject(parent)
{

}
