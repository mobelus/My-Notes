#include "externalapprunner.h"
//#include <appconfig.h>
//#include <core/cryptography/signedbinary.h>

#include <QLoggingCategory>
#include <QDir>

namespace {
Q_LOGGING_CATEGORY(LOG, "ExternalAppRunner")
}

ExternalAppRunner::ExternalAppRunner(QObject *parent) :
    QObject(parent)
{
}

ExternalAppRunner::~ExternalAppRunner()
{
    stop();
}

bool ExternalAppRunner::start(QString s)
{
    /*
    //if (fi.fileName().endsWith(mSyncExtension)) {
        mProcess.start(s, QStringList());
        if (mProcess.waitForStarted(-1)) {
            qCInfo(LOG) << "external program " << s << " has been synchronously started from USB storage";
        }
        if (mProcess.waitForFinished(-1)) {
            return true;
        }
    //}
    */

    //else if (fi.fileName().endsWith(mAsyncExtension)) {
        mProcess.start(s, QStringList());
        if (mProcess.waitForStarted(-1)) {
            qCInfo(LOG) << "external program" << s << "has been asynchronously started from USB storage";
        }
    //    return false;
    //}


    return false;
}

void ExternalAppRunner::stop()
{
    if (mProcess.state() != QProcess::NotRunning) {
        mProcess.terminate();
        if (!mProcess.waitForFinished(1000)) {
            mProcess.kill();
        }
    }
}

void ExternalAppRunner::setSyncExtension(const QString &ext)
{
    mSyncExtension = ext;
}

QString ExternalAppRunner::syncExtension() const
{
    return mSyncExtension;
}

void ExternalAppRunner::setAsyncExtension(const QString &ext)
{
    mAsyncExtension = ext;
}

QString ExternalAppRunner::asyncExtension() const
{
    return mAsyncExtension;
}
