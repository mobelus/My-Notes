#ifndef TOGLEBTN_H
#define TOGLEBTN_H

#include <QFrame>
#include <QLabel>
#include <QPushButton>

namespace Ui {
class TogleBtn;
}

class TogleBtn : public QFrame
{
    Q_OBJECT
public:
    explicit TogleBtn(QWidget *parent = nullptr);
    ~TogleBtn();

    QLabel *     label() { return mLab; }
    virtual void f(bool) = 0;

private:
    Ui::TogleBtn *ui;
    QLabel *      mLab;
};

#endif // TOGLEBTN_H
