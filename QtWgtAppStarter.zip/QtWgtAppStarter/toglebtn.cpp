#include "toglebtn.h"
#include "ui_toglebtn.h"

TogleBtn::TogleBtn(QWidget *parent) : QFrame(parent), ui(new Ui::TogleBtn)
{
    ui->setupUi(this);

    connect(ui->pbOn, &QPushButton::clicked, this, [=]() { f(true); });   //&B::f);
    connect(ui->pbOff, &QPushButton::clicked, this, [=]() { f(false); }); //&B::f);
}

TogleBtn::~TogleBtn()
{
    delete ui;
}
