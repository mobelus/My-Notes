#include "labelframe.h"
#include "ui_labelframe.h"

LabelFrame::LabelFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::LabelFrame)
{
    ui->setupUi(this);
}

LabelFrame::~LabelFrame()
{
    delete ui;
}
