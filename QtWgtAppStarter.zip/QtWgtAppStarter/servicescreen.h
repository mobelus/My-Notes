#ifndef SERVICESCREEN_H
#define SERVICESCREEN_H

#include <QWidget>

namespace Ui {
class ServiceScreen;
}

class ServiceScreen : public QWidget
{
    Q_OBJECT

public:
    explicit ServiceScreen(QWidget *parent = 0);
    ~ServiceScreen();

private:
    Ui::ServiceScreen *ui;
};

#endif // SERVICESCREEN_H
