#ifndef WGTTWO_H
#define WGTTWO_H

#include <QWidget>

namespace Ui {
class WgtTwo;
}

class WgtTwo : public QWidget
{
    Q_OBJECT

public:
    explicit WgtTwo(QWidget *parent = 0);
    ~WgtTwo();

private:
    Ui::WgtTwo *ui;
};

#endif // WGTTWO_H
