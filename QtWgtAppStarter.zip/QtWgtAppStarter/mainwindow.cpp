#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QProcess>
#include <QDir>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QTextStream>
#include <QFileDialog>
#include <QDesktopServices>
#include "qfilefolderdialog.h"
#include <QToolButton>

#include "mymegabutton.h"
#include "mysuperbutton.h"

bool getT(int &t)
{
    ++t;
    return true;
}
bool getF(int &f)
{
    ++f;
    return false;
}

void plus(int &n)
{
    ++n;
}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    mTimeTimer = new QTimer(this);
    mTimeTimer->setSingleShot(true);
    mTimeTimer->setInterval(5000);

    QString currentVersionString = "AAA", newVersionString = "BBB", fileName = "FILE", typeFullText = "MCU";
    bool    isBadVersion = false;
    {
        QString msg = tr("Update successfully finished for: %1. Has been updated from v %2 ")
                              .append(isBadVersion ? tr(" from file: %4") : tr(" to v %3 from file: %4"));
        msg = msg.arg(typeFullText).arg(currentVersionString).arg(newVersionString).arg(fileName);
    }

    isBadVersion = true;
    {
        QString msg = tr("Update successfully finished for: %1. Has been updated from v %2 ")
                              .append(isBadVersion ? tr(" from file: %3") : tr(" to v %3 from file: %4"));
        msg = msg.arg(typeFullText).arg(currentVersionString).arg(newVersionString).arg(fileName);
    }

    mTimerProgress = new QTimer(this);
    // mTimerProgress->setSingleShot(true);
    mTimerProgress->setInterval(1000);
    connect(mTimerProgress, &QTimer::timeout, this, &MainWindow::processThing);
    // timer->start(1000);
    ui->progressBar->setValue(0);

    bool a = true;
    bool b = true;
    bool c = true;
    bool d = true;
    bool r = true;

    int one = 1;
    r       = r & getT(one);
    r       = r & getF(one);
    r       = r & getT(one);
    r       = r & getF(one);

    ui->editLineToExecute->setText(
            "/home/pobrosov/dev-work/work/PRINTSCREENS_FROM_DEVICE/fb_grab_grab_bravo_framebuffer.sh");
    ui->editArguments->setPlainText(" root@192.168.10.3");

    timer = new QTimer(this);
    timer->setInterval(1000);
    connect(timer, &QTimer::timeout, this, &MainWindow::processOneThing);
    // QTimer::singleShot(1000, this, &Foo::updateCaption);

    loadAppsList();

    // QToolButton *tb = new QToolButton(ui->tab_3);
    QToolButton *tb = new QToolButton(this);
    tb->setObjectName("MyQToolButtonObjectName");
    tb->setText("+");
    tb->setFixedSize(100, 100);

    MyMegaButton *tb1 = new MyMegaButton(this);
    // tb1->setObjectName("MyMegaButtonObjectName");
    tb1->setText("*****");
    tb1->setGeometry(150, 0, 100, 100);

    QString s;
    s.append("#MyQToolButtonObjectName { background-color: red; color: blue; }");
    s.append("\n");
    s.append("MyMegaButton { background-color: green; color: white; }");

    this->setStyleSheet(s);

    ui->progressBar_2->setStyleSheet("abc.css");

    double aa = 0;
    int    status;
    bool   isTop;

    connect(ui->pushButton_13, &QPushButton::clicked, this, [=]() { ui->pushButton_13->setObjectName("123"); });

    connect(ui->pushButton_13, &QPushButton::objectNameChanged, this, [aa, status, isTop](QString s) {
        s = s + QString::number(status);
        // aa++; // readonly !
    });

    // ui->label_12->

    /*        QString text = innerText;
            // Works fine for single line text only
            if (elideMode != Qt::ElideNone && !text.contains("\n")) {
                text = elidedText(text, width() - hIndent);
            }
            label->setText(text);
            QFont font = label->font();

            //font.setPixelSize(mSize);
            FontMetrics fMetr(font);
            QRect       rect = fMetr.boundingRect(text);
            label->resize(rect.width(), rect.height());

            updateHorizontalPosition();
            updateVerticalPosition();
            updateGeometry();
            */
}

void MainWindow::on_pbExecute_clicked()
{
    // ui->progressBar->setValue();

    ///*
    QString     list = ui->editArguments->toPlainText();
    QStringList cmds = list.split('\n');

    startApp(ui->editLineToExecute->text(), cmds);
    ///*/
}

MainWindow::~MainWindow()
{
    on_pbSave_clicked();

    delete ui;
}

void MainWindow::loadAppsList()
{
    mFileWithListOfApps = "../QtWgtAppStarter/apps.txt";

    QFile file(mFileWithListOfApps);
    if (!file.exists())
        file.open(QIODevice::ReadWrite);
    file.close();

    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::information(0, "error", file.errorString());
    }

    QTextStream in(&file);

    while (!in.atEnd()) {
        QString line = in.readLine();
        mAppsPaths.append(line);
    }

    file.close();

    ui->tableWidget->setColumnWidth(AppPath, 630);

    for (int i = 0, ilen = mAppsPaths.size(); i < ilen; i++)
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());

    ui->tableWidget->currentItem();

    // QPushButton* btn_edit = new QPushButton();
    // ui->tableWidget->setItem(0,0,btn_edit);

    for (int irow = 0; irow < ui->tableWidget->rowCount(); irow++) {
        for (int jcol = 0; jcol < ui->tableWidget->columnCount(); jcol++) {
            switch (jcol) {
            case AppPath: {
                QTableWidgetItem *pCell = ui->tableWidget->item(irow, jcol);
                if (!pCell) {
                    pCell = new QTableWidgetItem;
                    ui->tableWidget->setItem(irow, jcol, pCell);
                }
                pCell->setText(mAppsPaths[irow]);
            } break;

            case LaunchButton: {
                QPushButton *btn_edit = new QPushButton();
                connect(btn_edit, &QPushButton::clicked, this, &MainWindow::onStartSelectedApp);
                btn_edit->setText("Launch");
                ui->tableWidget->setCellWidget(irow, jcol, btn_edit);
            } break;
            }
            // QTableWidgetItem*item = new QTableWidgetItem(vec[i]);
            // item->setFlags(item->flags() ^ Qt::ItemIsEditable);
            // ui->tableWidget->setItem(i, j, item);
        }
    }

    /*
    if(j == 0)
    {
        QWidget* pWidget = new QWidget();
        QPushButton* btn_edit = new QPushButton();
        btn_edit->setText("Launch");
        QHBoxLayout* pLayout = new QHBoxLayout(pWidget);
        pLayout->addWidget(btn_edit);
        pLayout->setAlignment(Qt::AlignCenter);
        pLayout->setContentsMargins(0, 0, 0, 0);
        pWidget->setLayout(pLayout);
        ui->tableWidget->setCellWidget(0, LaunchButton, pWidget);
        //continue;

    }
    //QTableWidgetItem*item = new QTableWidgetItem("Launch");
    //item->setFlags(item->flags() ^ Qt::ItemIsEditable);
    //ui->tableWidget->setItem(0, LaunchButton, item);
    */

    /*
    QWidget* pWidget = new QWidget();
    QPushButton* btn_edit = new QPushButton();
    btn_edit->setText("Edit");
    QHBoxLayout* pLayout = new QHBoxLayout(pWidget);
    pLayout->addWidget(btn_edit);
    pLayout->setAlignment(Qt::AlignCenter);
    pLayout->setContentsMargins(0, 0, 0, 0);
    pWidget->setLayout(pLayout);
    ui->tableWidget->setCellWidget(0, 0, pWidget);
    */
}

void MainWindow::onStartSelectedApp()
{
    for (int irow = 0, rowlen = ui->tableWidget->rowCount(); irow < rowlen; irow++) {
        QPushButton *snd = (QPushButton *)sender();
        QPushButton *pb  = (QPushButton *)ui->tableWidget->cellWidget(irow, LaunchButton);
        if (pb == snd) {

            QTableWidgetItem *pCell = ui->tableWidget->item(irow, AppPath);
            QString           path  = pCell->text();

            // startApp(path);
            QDesktopServices::openUrl(QUrl::fromLocalFile(path));

            break;
        }
    }
}

#include "externalapprunner.h"

void MainWindow::startApp(QString fullPath, QStringList params)
{
    // system(fullPath.toStdString().c_str());

    bool anyExtentionFound = false;

    //*
    {
        QString extension = fullPath.right(QString(".txt").size());
        if (extension == ".txt") {
            anyExtentionFound = true;
            QProcess::startDetached("gedit", QStringList() << fullPath);
        }
    }
    //*/

    {
        QString extension = fullPath.right(QString(".sh").size());
        if (extension == ".sh") {
            anyExtentionFound = true;
            // QProcess *process = new QProcess(this);
            // QString   program = fullPath;

            QString param;
            for (auto p : params) {
                param.append(" ");
                param.append(p);
            }

            // process->start(program, QStringList() << folder);

            // process->start(program, QStringList() << params);

            /// QString cmd = ("/bin/sh ") + fullPath + param;
            // if (QProcess::execute(cmd) < 0)
            //    qDebug() << "Failed to run";
            // process.waitForFinished();
            QProcess *process = new QProcess(this);
            ////////process->setWorkingDirectory(QDir::::MaindMainDirectory);
            if (params.empty())
                process->start(fullPath);
            else
                process->start(fullPath, params);

            // if (process->execute(cmd) < 0)
            //    qDebug() << "Failed to run";

            process->waitForFinished();
            QString output(process->readAllStandardOutput());
            int     z = 0;
        }
    }

    int a = 0;

    if (!anyExtentionFound) {
        // ExternalAppRunner extAppRunner;
        // extAppRunner.start(fullPath);

        if (params.isEmpty()) {
            QDesktopServices::openUrl(QUrl::fromLocalFile(fullPath));
        } else {
            QProcess *process = new QProcess(this);
            QString   program = fullPath;
            // QString   param  = params;
            // process->start(program, QStringList() << folder);
            process->start(program, QStringList() << params);

            // QProcess::start(fullPath, params);
        }

        /*QProcess::startDetached(
                fullPath + " "
                + params); // QDesktopServices::openUrl(QUrl::fromLocalFile(fullPath + " " + params));
                */
    }

    // /home/pobrosov/dev-work/work/PRINTSCREENS_FROM_DEVICE/fb_grab_grab_bravo_framebuffer.sh
    // QProcess process;
    // process.start("gedit", QStringList() << fullPath);

    // QProcess::startDetached("gedit", QStringList() << fullPath);
    // QProcess::startDetached("gedit", QStringList() << fullPath);

    //  QString program = fullPath;
    // QStringList arguments;
    // QProcess *myProcess = new QProcess(this);
    // myProcess->start(program,(QStringList) arguments<<fullPath);

    // QProcess::execute(fullPath);

    // QProcess::startDetached(fullPath);

    // QProcess *myProcess = new QProcess(this);
    // myProcess->start(fullPath);

    // QProcess *process = new QPQLayoutItem *item = ui->horizontalLayout_4->takeAt(0)rocess(this);
    // QString file =  fullPath; //+ "/file.exe";
    // process->start(file);

    // QDesktopServices::openUrl(QUrl::fromUserInput(fullPath));
    //*/
}

void MainWindow::on_pbAdd_clicked()
{
    QString filePath;

    // filePath = QFileDialog::getOpenFileName(this,tr("Select file"),"/",tr("(*.*)"));
    // filePath = QFileDialog::getOpenFileName(this,tr("Select file"),"/",tr("(*.*)"));

    QFileFolderDialog dlgFileFolder;

    QString   lastFilePath(QString("/"));
    QFileInfo objectInfo(lastFilePath);
    lastFilePath = (objectInfo.exists()) ? lastFilePath : "";
    dlgFileFolder.setChosenFilePath(lastFilePath);
    int res = dlgFileFolder.exec();

    if (res == QDialog::Accepted) {
        // QString filePath = dlgFileFolder.getChosenFilePath();
        filePath = dlgFileFolder.getChosenFilePath();
        // emit chooseFileOrDirResult(lastFilePath);
    }

    if (!filePath.isEmpty()) {
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        mAppsPaths.append(filePath);
    }

    int irow = ui->tableWidget->rowCount() - 1;

    for (int jcol = 0; (irow >= 0) && jcol < ui->tableWidget->columnCount(); jcol++) {
        switch (jcol) {
        case AppPath: {
            /*QTableWidgetItem *pCell = ui->tableWidget->item(irow, jcol);
            if(!pCell)
            {
                pCell = new QTableWidgetItem;
                ui->tableWidget->setItem(irow, jcol, pCell);
            }
            pCell->setText(mAppsPaths.last());
            */
            auto model = ui->tableWidget->model();
            model->setData(model->index(irow, jcol), mAppsPaths.last());
        } break;

        case LaunchButton: {
            QPushButton *btn_edit = new QPushButton();
            connect(btn_edit, &QPushButton::clicked, this, &MainWindow::onStartSelectedApp);
            btn_edit->setText("Launch");
            ui->tableWidget->setCellWidget(irow, jcol, btn_edit);

            /*
            QWidget* pWidget = new QWidget();
            QPushButton* btn_edit = new QPushButton();

            connect(btn_edit, &QPushButton::clicked, this, &MainWindow::onStartApp);

            btn_edit->setText("Launch");
            QHBoxLayout* pLayout = new QHBoxLayout(pWidget);
            pLayout->addWidget(btn_edit);
            pLayout->setAlignment(Qt::AlignCenter);
            pLayout->setContentsMargins(0, 0, 0, 0);
            pWidget->setLayout(pLayout);
            ui->tableWidget->setCellWidget(irow, jcol, pWidget);
            */
        } break;
        }
    }
}

void MainWindow::on_pbDelete_clicked()
{
    auto items = ui->tableWidget->selectedItems();
    if (items.size() > 0) {
        int rowPos = ui->tableWidget->row(items.first());
        ui->tableWidget->removeRow(rowPos);
    }
}

void MainWindow::on_pbLaunch_clicked()
{
    // open folder on linux:
    // QDesktopServices::openUrl( QUrl::fromLocalFile( "/home/pobrosov/Рабочий стол" ) );

    // QDesktopServices::openUrl( QUrl::fromLocalFile( "/home/pobrosov/Рабочий стол/2020-12-17-pages.html" ) );

    //*
    for (int irow = 0; irow < ui->tableWidget->rowCount(); irow++) {
        QTableWidgetItem *pCell = ui->tableWidget->item(irow, AppPath);
        QString           path  = pCell->text();

        startApp(path);
        // QDesktopServices::openUrl( QUrl::fromLocalFile( path ) );
    }
    //*/
}

void MainWindow::on_pbSave_clicked()
{
    QFile file(mFileWithListOfApps);
    if (!file.exists())
        file.open(QIODevice::ReadWrite);
    file.close();

    {
        QFile f(mFileWithListOfApps);
        f.open(QFile::WriteOnly | QFile::Truncate);
        f.close();
    }

    if (!file.open(QIODevice::ReadWrite)) {
        QMessageBox::information(0, "error", file.errorString());
    }

    QTextStream out(&file);

    // while(!in.atEnd()) {
    //    QString line = in.readLine();
    //    mAppsPaths.append(line);
    //}
    for (auto path : mAppsPaths)
        out << path << endl;

    file.close();
}

void MainWindow::on_pbAdd1_clicked()
{
    if (!timer->isActive())
        timer->start();
    add1 = true;
}

void MainWindow::on_pbAdd2_clicked()
{
    if (!timer->isActive())
        timer->start();
    add2 = true;
}

void MainWindow::processOneThing()
{
    timer->stop();
    if (add1 && add2) {
        QMessageBox m;
        m.exec();
    } else {
        if (add1) {
            // updtae
        }

        if (add2) {
            // update
        }
    }

    add1 = false;
    add2 = false;
}

void MainWindow::processThing()
{
    mSeconds++;
    int percents = mSeconds * (100 / mMaxSecs);
    ui->progressBar->setValue(percents);
    if (ui->progressBar->value() == 100)
        on_pbFinish_clicked();
}

void MainWindow::on_pbStart_2_clicked()
{
    on_pbStop_clicked();
    mTimerProgress->start();
}

void MainWindow::on_pbStop_clicked()
{
    mSeconds = 0;
    mTimerProgress->stop();
    ui->progressBar->setValue(0);
}

void MainWindow::on_pbFinish_clicked()
{
    mTimerProgress->stop();
    mSeconds = 0;
    ui->progressBar->setValue(100);
}

/*
void MainWindow::on_pushButton_clicked()
{
    // void MainWindow::clickTest()
    //{
    HWnd hwndgamewindow = ::findwindow(null, l "window name");
    gameWindow          = QWidget::find((WId)hwndGameWindow);
    qDebug() << (QString)(gameWindow->windowTitle());
    QPoint *     pos = new QPoint(112, 83);
    QMouseEvent *clickEvent =
            new QMouseEvent(QEvent::MouseButtonPress, *pos, Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    QApplication::sendEvent(gameWindow, clickEvent);

    //}
}
*/

void MainWindow::on_pbChoose_clicked()
{
    QString filePath;

    // filePath = QFileDialog::getOpenFileName(this,tr("Select file"),"/",tr("(*.*)"));
    // filePath = QFileDialog::getOpenFileName(this,tr("Select file"),"/",tr("(*.*)"));

    QFileFolderDialog dlgFileFolder;

    QString   lastFilePath(QString("/"));
    QFileInfo objectInfo(lastFilePath);
    lastFilePath = (objectInfo.exists()) ? lastFilePath : "";
    dlgFileFolder.setChosenFilePath(lastFilePath);
    int res = dlgFileFolder.exec();

    if (res == QDialog::Accepted) {
        // QString filePath = dlgFileFolder.getChosenFilePath();
        filePath = dlgFileFolder.getChosenFilePath();
        // emit chooseFileOrDirResult(lastFilePath);
    }

    ui->editImagesPath->setText(filePath);
}

void MainWindow::on_pbInvert_clicked()
{
    QString png        = ".png";
    QString imagesPath = ui->editImagesPath->text();
    /// QString imageNamePart = ui->editFileNameToInvert->text();
    // assume the directory exists and contains some files and you want all jpg and JPG files
    QDir        directory(imagesPath);
    QStringList images = directory.entryList(QStringList() << "*" + png << "*.PNG", QDir::Files);
    // foreach (QString filename, images)
    {
        QString filename = ui->editFileNameToInvert->text();

        QString fullPath     = imagesPath + "/" + filename;
        QString fullPathCopy = filename.left(filename.indexOf(png));
        fullPathCopy         = fullPathCopy /*+ imageNamePart*/ + png;
        fullPathCopy         = imagesPath + "/" + fullPathCopy;
        QFile::copy(fullPath, fullPathCopy);

        QImage img(fullPathCopy);
        img.invertPixels(QImage::InvertRgb);

        QColor clrSearch("#e5441e");
        QColor clrReplace("#d5d5d5");

        // "pixmap" is your QPixmap // "color" is your QColor
        // Convert the pixmap to QImage
        // QImage tmp = pixmap.toImage();
        QImage tmp = img;

        for (int y = 0; y < tmp.height(); y++) // Loop all the pixels
        {
            for (int x = 0; x < tmp.width(); x++) {
                // Read the alpha value each pixel, keeping the RGB values of your color
                // color.setAlpha(tmp.pixelColor(x,y).alpha());
                QColor cur = tmp.pixelColor(x, y);
                if (cur == clrSearch) {
                    // Apply the pixel color
                    tmp.setPixelColor(x, y, clrReplace);
                }
            }
        }
        // Get the coloured pixmap
        // QPixpixmap = QPixmap::fromImage(tmp);

        tmp.save(fullPathCopy);
    }
}

#include <QFile>
#include <QDir>

void MainWindow::on_pbInvertAllInFolder_clicked()
{
    QString png           = ".png";
    QString imagesPath    = ui->editImagesPath->text();
    QString imageNamePart = ui->editAddNamePart->text();
    // assume the directory exists and contains some files and you want all jpg and JPG files
    QDir        directory(imagesPath);
    QStringList images = directory.entryList(QStringList() << "*" + png << "*.PNG", QDir::Files);
    foreach (QString filename, images) {
        QString fullPath     = imagesPath + "/" + filename;
        QString fullPathCopy = filename.left(filename.indexOf(png));
        fullPathCopy         = fullPathCopy + imageNamePart + png;
        fullPathCopy         = imagesPath + "/" + fullPathCopy;
        QFile::copy(fullPath, fullPathCopy);

        QImage img(fullPathCopy);
        img.invertPixels(QImage::InvertRgb);

        QColor clrSearch("#e5441e");
        QColor clrReplace("#d5d5d5");

        // "pixmap" is your QPixmap // "color" is your QColor
        // Convert the pixmap to QImage
        // QImage tmp = pixmap.toImage();
        QImage tmp = img;

        for (int y = 0; y < tmp.height(); y++) // Loop all the pixels
        {
            for (int x = 0; x < tmp.width(); x++) {
                // Read the alpha value each pixel, keeping the RGB values of your color
                // color.setAlpha(tmp.pixelColor(x,y).alpha());
                QColor cur = tmp.pixelColor(x, y);
                if (cur == clrSearch) {
                    // Apply the pixel color
                    tmp.setPixelColor(x, y, clrReplace);
                }
            }
        }
        // Get the coloured pixmap
        // QPixpixmap = QPixmap::fromImage(tmp);

        tmp.save(fullPathCopy);
    }
}

void MainWindow::on_pushButton_clicked()
{
    mTimeTimer->start();
}

void MainWindow::on_pushButton_2_clicked()
{
    if (mTimeTimer->isActive()) {
        qDebug() << "ACTIVE!";
    } else {
        qDebug() << "NOT ACTIVE!";
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    QString msgBox = ".QMessageBox{background:rgba(250,30,10,255);color:#fff} "
                     "QLabel{background:transparent;color:#fff} "
                     ".QPushButton{color:#161616;background-color:#6c9636;}";

    QMessageBox dlg(this);
    dlg.setObjectName("saveSystemConfiguration");
    dlg.setText("After update you should restart the device.\n Restart now?");
    dlg.setWindowTitle("Exit Service Screen");
    QPushButton *acceptButton = dlg.addButton(tr("Restart"), QMessageBox::ActionRole);
    /*acceptButton->setStyleSheet(".QPushButton{color:#161616;background-color:#6c9636;}");*/
    acceptButton->setObjectName("acceptButtonQuestionDialog");
    acceptButton->setStyleSheet("#acceptButtonQuestionDialog{color:#161616;background-color:#6c9636;}");
    QPushButton *cancelButton = dlg.addButton(tr("Cancel"), QMessageBox::ActionRole);
    /*cancelButton->setStyleSheet(".QPushButton{color:#161616;background-color:#5b6266;}");*/
    cancelButton->setObjectName("cancelButtonQuestionDialog");
    // reloadStyleRecursive(this);

    dlg.setStyleSheet(msgBox);

    /*
dlg.setStyleSheet("QLabel{min-width:500px; min-height:500px; font-size: 13px;} "
              "#qt_msgbox_label{background-color:\"red\"} "
              "#qt_msgbox_informativelabel{background-color:\"green\"}  QPushButton "
              "#acceptButtonQuestionDialog { color: #161616; background-color: #6c9636; }"
              "QPushButton { color: #161616; background-color: #6c9636; }"
              "");
*/

    dlg.exec();
}

void MainWindow::on_pushButton_4_clicked()
{
    int a = 0;

    // IClass *mIC = new Class(getClass());

    int z = 0;
}

#include "frameone.h"
#include "frametwo.h"

void MainWindow::initSomthing() {}

void MainWindow::on_pushButton_5_clicked()
{
    // ui->frame = new FrameOne(this);
    QLayoutItem *item = ui->horizontalLayout_4->takeAt(0);
    if (item != nullptr) {
        delete item->widget();
        delete item;
        // delete ui->horizontalLayout_4;
    }

    // ui->horizontalLayout_4->addWidget(new FrameOne(this));
    /// setNewFrame<FrameOne>();
}

void MainWindow::on_pushButton_6_clicked()
{
    // ui->frame = new FrameTwo(this);
    QLayoutItem *item = ui->horizontalLayout_4->takeAt(0);
    if (item != nullptr) {
        delete item->widget();
        delete item;
        // delete ui->horizontalLayout_4;
    }

    // ui->horizontalLayout_4->addWidget(new FrameTwo(this));
    /// setNewFrame<FrameTwo>();
}

void MainWindow::on_pushButton_7_clicked() {}

void MainWindow::on_pushButton_8_clicked() {}

//#include "wgtbase.h"
#include "wgtone.h"
#include "wgttwo.h"
#include "wgtthree.h"

void MainWindow::on_pbAddTab_clicked()
{
    int cnt = ui->tabWidgetSubWgt->count();
    /// ui->tabWidgetSubWgt->addTab(new WgtBase(ui->tabWidgetSubWgt), "Tab " + QString::number(cnt));
    ui->tabWidgetSubWgt->addTab(new WgtBase(ui->tabWidgetSubWgt), "Tab " + QString::number(cnt));
}

void MainWindow::on_pbDelTab_clicked()
{
    ui->tabWidgetSubWgt->removeTab(0);
}

void MainWindow::on_pbAddTab1_clicked()
{
    auto wgt = new WgtOne(new TestClass(ui->tabWidgetSubWgt), ui->tabWidgetSubWgt);
    ui->tabWidgetSubWgt->addTab(wgt, wgt->objectName());
}

void MainWindow::on_pbAddTab2_clicked()
{
    auto wgt = new WgtTwo(ui->tabWidgetSubWgt);
    ui->tabWidgetSubWgt->addTab(wgt, wgt->objectName());
}

void MainWindow::on_pbAddTab3_clicked()
{
    auto wgt = new WgtThree(ui->tabWidgetSubWgt);
    ui->tabWidgetSubWgt->addTab(wgt, wgt->objectName());
}

void MainWindow::on_pbAddAllTabs_clicked()
{
    ui->tabWidgetSubWgt->addTab(new WgtOne(new TestClass(ui->tabWidgetSubWgt), ui->tabWidgetSubWgt), "BACKREFL");
    ui->tabWidgetSubWgt->addTab(new WgtTwo(ui->tabWidgetSubWgt), "DEMOMODE");
    ui->tabWidgetSubWgt->addTab(new WgtThree(ui->tabWidgetSubWgt), "FIRMWARE");
}

void MainWindow::on_pushButton_9_clicked()
{
    int type = ui->editBlockType->text().toInt();

    /*ui->gridSuper->addWidget(new QLabel("TEXT", ui->gridSuper), 0, 0);
    ui->gridSuper->addWidget(new QToolButton("TEXT", ui->gridSuper), 0, 1);*/

    QLabel *Title = new QLabel(this);
    // Title->setAlignment(Qt::AlignCenter);
    Title->setText("ABCDEF");

    /// QPushButton *Btn = new QPushButton("123456", this);

    /// AA *BtnA = new AA("123456", this);
    /// AA *B = new AA("123", 123);    //AA("123456", this);
    AA *BtnA = new AA("123", this); // AA("123456", this);

    // Title->setFixedWidth (800);

    // Creating the scroll area
    /*
    QScrollArea *scroll = new QScrollArea(this);
    scroll->setVerticalScrollBarPolicy (Qt::ScrollBarAlwaysOn);
    scroll->setHorizontalScrollBarPolicy (Qt::ScrollBarAlwaysOn);

    QWidget *viewport  = new QWidget(this);
    scroll->setWidget (viewport);
    scroll->setWidgetResizable (true);
    */
    // Adding layout

    // ui->gridSuper->addWidget (scroll);
    // Additem::setLayout (ui->gridSuper);

    ui->gridSuper->addWidget(Title, 0, 0);
    // ui->gridSuper->addWidget(Btn, 0, 1);
    ui->gridSuper->addWidget(BtnA, 0, 1);
}

void MainWindow::on_pushButton_11_clicked()
{
    BB *    BtnA  = new BB(this); // AA("123456", this);
    QLabel *Title = new QLabel(this);
    Title->setText("ABCDEF");

    ui->gridSuper->addWidget(Title, 0, 0);
    ui->gridSuper->addWidget(BtnA, 0, 1);
}

enum Warrior_ID { Infantryman_ID = 0, Archer_ID };

class Warrior
{
public:
    QLabel *         leftLabel();
    virtual QWidget *rightWidget() = 0;
    virtual ~Warrior() {}
    static Warrior *createWarrior(Warrior_ID id);
};

class Infantryman : public Warrior
{
public:
    void info()
    {
        // cout << "Infantryman" << endl;
    }
};

class Archer : public Warrior
{
public:
    void info()
    {
        // cout << "Archer" << endl;
    }
};
/*
class SuperClass : public QFrame
{
public:
    QLabel *         leftLabel();
    virtual QWidget *rightWidget() = 0;
    virtual ~Warrior() {}
    static Warrior *createWarrior(Warrior_ID id);
};

class Infantryman : public Warrior
{
public:
    void info()
    {
        // cout << "Infantryman" << endl;
    }
};

class Archer : public Warrior
{
public:
    void info()
    {
        // cout << "Archer" << endl;
    }
};
*/
// Реализация параметризированного фабричного метода
Warrior *Warrior::createWarrior(Warrior_ID id)
{
    Warrior *p;
    switch (id) {
    case Infantryman_ID:
        // p = new Infantryman();
        break;
    case Archer_ID:
        // p = new Archer();
        break;
        // default:
        // assert(false);
    }
    return p;
};

void MainWindow::on_pushButton_12_clicked()
{
    Warrior *v1 = Warrior::createWarrior(Infantryman_ID);
    /// Warrior* v2= Warrior::createWarrior( Archer_ID);

    // Infantryman *iman = Warrior::createWarrior(Infantryman_ID);
    // Archer *     aman = Warrior::createWarrior(Archer_ID);
}

void MainWindow::on_pushButton_14_clicked()
{

    int k = 1;
    for (int i = 0, ilen = 2; i < ilen; i++) {     // 0 1
        for (int j = 0, jlen = 3; j < jlen; j++) { // 0 1 2
            if (((i + 1) + (j + 1)) == (5)) {
                QLabel *lab = new QLabel("");
                ui->gridLayout_2->addWidget(lab, i, j);
            } else {
                QString position = QString::number(k++);
                // QString      position = QString("%1,%2").arg(i).arg(j);
                QPushButton *button = new QPushButton(position);
                ui->gridLayout_2->addWidget(button, i, j);
            }

            // connect(button, SIGNAL(clicked()), signalMapper, SLOT(map()));
            // signalMapper->setMapping(button, position);
        }
    }
}
