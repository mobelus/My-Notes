#ifndef DATETIMEFRAME_H
#define DATETIMEFRAME_H

#include <QFrame>

namespace Ui {
class DateTimeFrame;
}

class DateTimeFrame : public QFrame
{
    Q_OBJECT

public:
    explicit DateTimeFrame(QWidget *parent = 0);
    ~DateTimeFrame();

private:
    Ui::DateTimeFrame *ui;
};

#endif // DATETIMEFRAME_H
