#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QElapsedTimer>
#include <QMessageBox>
#include <QLayoutItem>
#include <QHBoxLayout>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

#include "iclass.h"

class Class : public IClass
{
    Q_OBJECT
public:
    explicit Class(QObject *parent = nullptr)
        :                // FirmwareVersions::FirmwareVersions(QObject *parent) :
          IClass(parent) // IFirmwareVersionsReporter(parent)
    {
    }

    int AddThree(int _a) override
    {
        ma = _a;
        return ma;
    }

private:
    int ma = 0;
};

/*A()
{
    // connect(pbTogleBtn, &QToolButton::clicked, this, &A::f);
    connect(this, &QPushButton::clicked, this, &A::f);
}*/

#include <QLabel>
#include <QPushButton>
#include <QToolButton>

// class A : public QWidget
class A : public QPushButton
{
    Q_OBJECT
public:
    virtual void f() = 0;

    // A(const QString & text, QWidget * parent = nullptr)
    explicit A(const QString &text, QWidget *parent) : QPushButton(text, parent)
    {
        connect(this, &QPushButton::clicked, this, &A::f);
    }
    // virtual ~A();

    QLabel *label() { return lab; }

private:
    // QPushButton *pbTogleBtn = nullptr;
    QLabel *lab;
};

class AA : public A // QWidget, A
{
    Q_OBJECT
public:
    explicit AA(const QString &text, QWidget *parent) : A(text, parent) {}
    //~AA();

    void f() override
    {
        int a = 0;
        a++;
    }
};
//*/

/*
class B : public QWidget
{
    Q_OBJECT
public:
    virtual void f() = 0;

    // A(const QString & text, QWidget * parent = nullptr)
    explicit B(QWidget *parent) : QWidget(parent)
    {


        connect(pbOn, &QPushButton::clicked, this, &B::f);
        connect(pbOff, &QPushButton::clicked, this, &B::f);
    }
    // virtual ~A();

    QLabel *label() { return lab; }

private:
    QPushButton *pbOn  = nullptr;
    QPushButton *pbOff = nullptr;
    QLabel *     lab;
};
*/

#include "toglebtn.h"

/// class BB : public B // QWidget, A
class BB : public TogleBtn
{
    Q_OBJECT
public:
    explicit BB(QWidget *parent) : TogleBtn(parent) {}
    //~AA();

    void f(bool val) override
    {
        bool b = val;
        b++;
    }
};

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    Class * mC;
    IClass *getClass() { return mC; }

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void loadAppsList();

    void startApp(QString fullPath, QStringList params = QStringList());
    void processOneThing();

private slots:
    void on_pbAdd_clicked();
    void on_pbDelete_clicked();
    void on_pbLaunch_clicked();
    void on_pbSave_clicked();

    void onStartSelectedApp();

    void on_pbAdd1_clicked();
    void on_pbAdd2_clicked();

    void on_pbExecute_clicked();

    void on_pbStart_2_clicked();

    void on_pbStop_clicked();

    void on_pbFinish_clicked();

    void on_pbChoose_clicked();

    void on_pbInvert_clicked();

    void on_pbInvertAllInFolder_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pbAddTab_clicked();

    void on_pbDelTab_clicked();

    void on_pbAddTab1_clicked();

    void on_pbAddTab2_clicked();

    void on_pbAddTab3_clicked();

    void on_pbAddAllTabs_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_14_clicked();

private:
    void            processThing();
    double          mSeconds = 0;
    const double    mMaxSecs = 20;
    QTimer *        mTimerProgress;
    Ui::MainWindow *ui;

    QTimer *mTimeTimer;

    QString     mFileWithListOfApps;
    QStringList mAppsPaths;

    enum { AppPath, LaunchButton };

    // QTimer *mTimerProgress;

    QTimer *timer;
    bool    add1;
    bool    add2;

    void initSomthing();

    // virtual void setNewFrame() = 0;

    template <class T>
    void setNewFrame()
    {
        QLayoutItem *item = ui->horizontalLayout_4->takeAt(0);
        if (item != nullptr) {
            delete item->widget();
            delete item;
            // delete ui->horizontalLayout_4;
        }

        ui->horizontalLayout_4->addWidget(new T(this));
    }
};
#endif // MAINWINDOW_H
