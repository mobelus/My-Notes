#ifndef ICLASS_H
#define ICLASS_H

#include <QObject>

class IClass : public QObject
{
    Q_OBJECT
public:
    explicit IClass(QObject *parent = nullptr);

public:
    virtual int AddThree(int) = 0;
};

/*
class IClass : public QObject
{
    Q_OBJECT
public:
    explicit IClass(QObject *parent = nullptr);
};
*/
#endif // ICLASS_H
