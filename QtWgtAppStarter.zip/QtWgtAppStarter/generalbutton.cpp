#include "generalbutton.h"

// class implementation (MyButton.cpp)
GeneralButton::GeneralButton(QWidget *parent) : QPushButton(parent)
{
    int b = 0;
}

GeneralButton::~GeneralButton()
{
    int a = 0;
}
