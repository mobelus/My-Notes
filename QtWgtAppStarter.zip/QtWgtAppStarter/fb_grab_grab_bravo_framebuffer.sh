#/bin/bash

set -e

FB_DEV=/dev/fb2

function help() {
    echo "Usage example: ./$(basename $0) root@ixora"
    echo "Input ssh address of ursus device on your workstation"
    exit 0
}

function error() {
    rm -f ${FILE}-0.png 2>/dev/null || true
    rm -f ${FILE}-0.png 2>/dev/null || true
    exit 1
}

declare ursusSshAddress

while [ $# -gt 0 ]; do
  case $1 in
    -h|--help)
        help
      ;;

    *)
        ursusSshAddress=$1
        shift
      ;;
  esac
done

[[ -z "${ursusSshAddress}" ]] && help


if ! [ -x "$(command -v convert)" ]; then
    echo "ImageMagick is not installed, trying to execute 'sudo apt-get install imagemagick'"
    sudo apt-get install imagemagick
    if ! [ -x "$(command -v convert)" ]; then
        echo "For some unknown reason installation of imagemagick failed."
        exit 1
    fi
    echo "ImageMagick installed, try to restart this script."
    exit 0
fi


FILE=ursus_screenshot-`date +%Y.%m.%d-%H.%M.%S`
ssh ${ursusSshAddress} cat ${FB_DEV} 0>/dev/null | convert -depth 8 -size 1280x800+0 BGRA:- ${FILE}.png || error ${FILE}
echo "Success! Files ${FILE}-0.png and ${FILE}-1.png created."
