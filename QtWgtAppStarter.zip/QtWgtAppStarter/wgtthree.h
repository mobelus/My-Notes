#ifndef WGTTHREE_H
#define WGTTHREE_H

#include <QWidget>

namespace Ui {
class WgtThree;
}

class WgtThree : public QWidget
{
    Q_OBJECT

public:
    explicit WgtThree(QWidget *parent = 0);
    ~WgtThree();

private:
    Ui::WgtThree *ui;
};

#endif // WGTTHREE_H
