#include "wgttwo.h"
#include "ui_wgttwo.h"

WgtTwo::WgtTwo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WgtTwo)
{
    ui->setupUi(this);
}

WgtTwo::~WgtTwo()
{
    delete ui;
}
