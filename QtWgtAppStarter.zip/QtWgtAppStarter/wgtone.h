#ifndef WGTONE_H
#define WGTONE_H

#include <QWidget>
#include "wgtbase.h"
#include "testclass.h"

namespace Ui {
class WgtOne;
}

// class WgtOne : public QWidget
class WgtOne : public WgtBase
{
    Q_OBJECT

public:
    // explicit WgtOne(QWidget *parent = 0);
    explicit WgtOne(TestClass *test, QWidget *parent = 0);
    ~WgtOne();

    void init(int b);

private:
    Ui::WgtOne *ui;
    TestClass * mTest;
};

#endif // WGTONE_H
