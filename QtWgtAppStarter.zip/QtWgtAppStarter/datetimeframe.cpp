#include "datetimeframe.h"
#include "ui_datetimeframe.h"

DateTimeFrame::DateTimeFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::DateTimeFrame)
{
    ui->setupUi(this);
}

DateTimeFrame::~DateTimeFrame()
{
    delete ui;
}
