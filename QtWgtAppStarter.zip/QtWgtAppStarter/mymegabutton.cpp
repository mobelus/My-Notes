#include "mymegabutton.h"

// class implementation (MyButton.cpp)
MyMegaButton::MyMegaButton(QWidget *parent) : GeneralButton(parent)
{
    int b = 0;
}

MyMegaButton::~MyMegaButton()
{
    int a = 0;
}
