#include "mainwindow.h"

#include <QApplication>

template <typename Characters>
std::vector<Characters> split_(const Characters &str, const Characters &delim)
{
    std::vector<Characters> res;
    auto                    str_end = str.cend();
    for (auto i = str.cbegin(), j = delim.cbegin(), word_end = str.cbegin(); i != str.cend(); ++i) {
        auto ii = *i;
        auto jj = *j;
        if (ii == jj) {
            word_end  = i;
            auto word = Characters(str.cbegin(), word_end);
            int  a    = 0;
        } else if ((ii != jj) /*&& (str.cbegin())*/) {
            // auto word = Characters(str.cbegin(), word_end);
            // res.push_back(word);
        }
        // word_end  = i;
    }
    return res;
}

int main(int argc, char *argv[])
{
    {
        std::string              s = "aaa:bb::c:::dd";
        std::string              d = ":";
        std::vector<std::string> r = split_(s, d);
        int                      a = 0;
    }

    {
        int  a = 0;
        int  b = 0;
        auto f = [a, &b](int m, int &n) {
            int z = 0;
            z++;

            // a++; // замкнута read-only variable
            z = z + a; // ok

            b++;

            z = z + m;
            n = z;
        };
    }

    {
        /*
        pNums = make_unique<vector<int>>(nums);
        //...
        auto a = [ptr = move(pNums)]() {
            // use ptr
        };
        */
    }

    {
        // CONST INT POINTER
        int        a   = 1;
        int        aa  = 11;
        const int *cip = &a;
        //*cip           = aa; // compile err // assignment of read-only location ‘cip’
        cip = &aa;

        int        b   = 2;
        int        bb  = 22;
        int const *icp = &b;
        //*icp           = bb; // compile err // assignment of read-only location ‘icp’
        icp = &bb;

        int        c   = 3;
        int        cc  = 33;
        int *const ipc = &c;
        *ipc           = cc;
        // ipc            = &cc; // compile err // assignment of read-only variable ‘ipc’
    }

    QApplication a(argc, argv);

    QStringList listProxy;
    listProxy.append("Z");
    listProxy.append("X");
    listProxy.append("Y");
    QString funcProxy = "a1-'%1'-b2-'%2'-c3-'%3'"; // aZbXcY
    for (int i = 0; i < listProxy.size(); ++i)
        funcProxy.replace(QString("%%1").arg(i + 1), listProxy.at(i));

    MainWindow w;
    w.show();
    return a.exec();
}
