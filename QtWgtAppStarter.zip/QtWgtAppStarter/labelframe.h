#ifndef LABELFRAME_H
#define LABELFRAME_H

#include <QFrame>

namespace Ui {
class LabelFrame;
}

class LabelFrame : public QFrame
{
    Q_OBJECT

public:
    explicit LabelFrame(QWidget *parent = 0);
    ~LabelFrame();

private:
    Ui::LabelFrame *ui;
};

#endif // LABELFRAME_H
