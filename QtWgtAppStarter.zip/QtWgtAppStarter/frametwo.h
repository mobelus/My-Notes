#ifndef FRAMETWO_H
#define FRAMETWO_H

#include <QFrame>

namespace Ui {
class FrameTwo;
}

class FrameTwo : public QFrame
{
    Q_OBJECT

public:
    explicit FrameTwo(QWidget *parent = 0);
    ~FrameTwo();

private:
    Ui::FrameTwo *ui;
};

#endif // FRAMETWO_H
