#ifndef CHECKBOXBTN_H
#define CHECKBOXBTN_H

#include <QFrame>

namespace Ui {
class CheckBoxBtn;
}

class CheckBoxBtn : public QFrame
{
    Q_OBJECT

public:
    explicit CheckBoxBtn(QWidget *parent = 0);
    ~CheckBoxBtn();

private:
    Ui::CheckBoxBtn *ui;
};

#endif // CHECKBOXBTN_H
