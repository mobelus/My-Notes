#include "iclass.h"

IClass::IClass(QObject *parent) : QObject(parent) {}
