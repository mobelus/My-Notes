#ifndef FRAMEONE_H
#define FRAMEONE_H

#include <QFrame>

namespace Ui {
class FrameOne;
}

class FrameOne : public QFrame
{
    Q_OBJECT

public:
    explicit FrameOne(QWidget *parent = 0);
    ~FrameOne();

    void init();

private:
    Ui::FrameOne *ui;
};

#endif // FRAMEONE_H
