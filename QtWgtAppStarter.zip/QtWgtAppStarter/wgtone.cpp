#include "wgtone.h"
#include "ui_wgtone.h"

/*WgtOne::WgtOne(QWidget *parent) : WgtBase(parent), ui(new Ui::WgtOne)
{
    ui->setupUi(this);
}
*/
WgtOne::WgtOne(TestClass *test, QWidget *parent) : WgtBase(parent), ui(new Ui::WgtOne), mTest(test)
{
    ui->setupUi(this);
}

WgtOne::~WgtOne()
{
    delete ui;
}

void WgtOne::init(int b)
{
    auto a = b;
}
