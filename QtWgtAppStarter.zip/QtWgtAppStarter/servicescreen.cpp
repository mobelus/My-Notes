#include "servicescreen.h"
#include "ui_servicescreen.h"

ServiceScreen::ServiceScreen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ServiceScreen)
{
    ui->setupUi(this);
}

ServiceScreen::~ServiceScreen()
{
    delete ui;
}
