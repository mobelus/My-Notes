#include "checkboxbtn.h"
#include "ui_checkboxbtn.h"

CheckBoxBtn::CheckBoxBtn(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::CheckBoxBtn)
{
    ui->setupUi(this);
}

CheckBoxBtn::~CheckBoxBtn()
{
    delete ui;
}
