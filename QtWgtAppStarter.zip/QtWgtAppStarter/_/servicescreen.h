#ifndef GUI_SCREENS_SERVICESCREEN_H
#define GUI_SCREENS_SERVICESCREEN_H

#include <QObject>
#include <QWidget>
#include <QFrame>
#include <QDebug>
#include <QTimer>
#include <QStyle>
#include <QMessageBox>
#include <QScrollBar>
#include <QFileInfo>
#include <QDialog>
#include <QLoggingCategory>
#include <QLayoutItem>
#include <QTabWidget>
#include <QLayoutItem>
#include <QHBoxLayout>
#include <QSqlQueryModel>

///#include <appconfig.h>
// ok
#include "servicescreenexternalparameters.h"
#include "appkerneldevtreeupdater.h"
#include "datetimepicker/datetimepicker.h"
#include "setsystemdatetime.h"

/// INTERFACE
///#include "settingsfile.h"
///#include "../src/isettingsfile.h"
///#include "profiles/profilestorage.h" /// INTERFACE /// mProfileStorage->fileVersion()
///#include "profiles/iprofilestorage.h" /// INTERFACE /// mProfileStorage->fileVersion()
///#include "proxyobjects/bravodeviceproxy.h"
///#include <systemevent/systemeventlog.h> /// MOVE TO CORE

#include <facade/interfaces/ibravodevicefront.h>
#include <facade/interfaces/isystemeventlogmodel.h>
#include <facade/interfaces/isettingsfile.h>
#include <facade/interfaces/iprofilestorage.h>

#include <facade/interfaces/iupdater.h>
#include <facade/interfaces/iwirelesspedalpairing.h>
#include <facade/interfaces/imixervolume.h>
#include <facade/interfaces/ifirmwareversionsprovider.h>

///#include <appbravo/carrierboard.h>      /// MOVE TO CORE  /// CarrierBoard::carrierBoardVersion() + bravotransitionstartup
#include <core/boards/carrierboard/carrierboard.h>
#include <core/storage/usbstorage.h>
#include <core/application/app/demomode/demomodeswitcher.h>
#include <core/application/app/fileversion/jsonserializer.h>
#include <core/application/app/fileversion/checksumversion.h>
#include <core/calibration/calibrationreader.h>

class UiObjects;

class IUpdaterControllerFacade;
class IUpdaterFacade;
class IWirelessPedalPairing;
class IMixerVolume;
class IProfileStorage;
class ISettingsFile;
class IStorage;
class IFirmwareVersionsProvider;
class IBravoDeviceFront;
class DemoModeSwitcher;

namespace IPGP {
class Connection;
}

namespace Ui {
class ServiceScreen;
}

namespace TreatmentLog {
class Storage;
}

class UpdatePanel;
class CalibrationFileProvider;
class ProceduresProfilesIniFileProvider;
class FactoryProceduresFileProvider;
class ProfileStorage;

class SoftwareUpdateBlock : public QFrame
{
public:
    SoftwareUpdateBlock(QWidget *parent = nullptr) :
        QFrame(parent)
    {
    }
};

// class FirmwareUpdate { }
//
// class ServiceScreen  { }
// Top: BackBtn Title RightRecdtangle Middle: Tabwidget
// methods: addPage(QWidget), moveTabLeft, moveTabRight, setTabPos(int index)
// class BravoServiceScreen  { }
// addPage(new PageWgt);

class ServiceScreen : public QWidget
{
    Q_OBJECT
public:
    explicit ServiceScreen(
            ServiceScreenExternalParameters externalParameters,
            IBravoDeviceFront *             bravoDeviceFront,
            IUpdaterControllerFacade *      updateFacade,
            IFirmwareVersionsProvider *     firmVersions,
            IProfileStorage *               profileStorage,
            ISettingsFile *                 settingsFile,
            DemoModeSwitcher *              demoModeSwitcher,
            IWirelessPedalPairing *         wirelessPedalPairing,
            TreatmentLog::Storage *         treatmentLogStorage,
            IMixerVolume *                  volume,
            ISystemEventLogModel *          fullEventLogModel,
            QString                         fullEventLogQuery,
            QList<int>                      fullEventLogColumns,
            QWidget *                       parent = nullptr);
    ~ServiceScreen();

    void onPbDemoModeClicked(bool enable);
    bool isDemoMode() const;

signals:
    void backRequired();

    void saveToSystemEventLog(QString logName, QString eventType, const QString &eventTimeStamp, const QString &eventKeyIdDb, const QVariant &eventValue);

private:
    Ui::ServiceScreen *             ui;
    ServiceScreenExternalParameters mExternalParameters;

    IUpdaterControllerFacade *     mUpdaterFacade         = nullptr;
    IFirmwareVersionsProvider *    mFirmVersions          = nullptr;
    CalibrationFileProvider *      mCalibrationFile       = nullptr;
    IBravoDeviceFront *            mBravoDeviceFront      = nullptr;
    FactoryProceduresFileProvider *mFactoryProceduresFile = nullptr;
    IProfileStorage *              mProfileStorage        = nullptr;
    ISettingsFile *                mSettingsFile          = nullptr;
    IStorage *                     mUsbStick              = nullptr;
    AppKernelDevTreeUpdater *      mAppUpdater            = nullptr;
    IWirelessPedalPairing *        mWirelessPedalPairing  = nullptr;
    IMixerVolume *                 mVolume                = nullptr;
    TreatmentLog::Storage *        mTreatmentLogStorage   = nullptr;
    ISystemEventLogModel *         mSystemEventLogModel   = nullptr;

    bool    mRebootRequired      = false;
    QTimer *mDateTimeUpdateTimer = nullptr;

    DemoModeSwitcher *mDemoModeSwitcher = nullptr;

    void initUpdatePanel(UpdatePanel *pnl, const QString &typeText, const QString &typeFullText, IUpdaterFacade *updater);
    void createWatcher(const QString &filePattern, IUpdaterFacade *updater);

    void initAppKernelImageDeviceTreeUpdater();

    QString getChecksumVersionFromJsonDescriptionFile(QString descriptionFilePath) const; //
    QString getKernelImageVersion(QString descriptionFilePath = "") const;
    QString getDeviceTreeVersion(QString descriptionFilePath = "") const;
    QString getCarrierBoardVersion() const;
    QString getRfidTransceiverVersion() const;
    void    prepareRfidTransceiverVersion(QString &rfidTransceiverVersion);

    void startUpdate(IUpdaterFacade *updater);
    void updateError(const Error &error);
    void updateFinished();

    void addFirmwareLogLine(const QString &msg);
    void addSoftwareLogLine(const QString &msg);
    void addSoftwareOrFirmwareLogLine(const QString &msg, UpdatePanel *pnl);

    void updateVersions();
    void backButtonClicked();
    void setBackReflectionEnabled(bool value);
    void setPdFeedbackPolling(bool enabled);
    void onPbSysConfSetDateTimeClicked();
    void updateCurrentDateTimeWidget();

    void actualizeDemoModeCaptions();

    void showUsbStickStatusInSoftwareLogLine(bool isUsbPresent);

    void onCoefficientToReduceVolumeChanged(int value);

    void readEmissionMinutes();
    void setEmissionMinutes();
    void loadSerialNumber();

    void initSliderForCoefficientToReduceVolume();
    void hideSliderForCoefficientToReduceVolume();

    void setDemoModeTopBar();
    void initServiceScreenTopBar();

    void logDemoMode(bool isDemoMode);
    void logDateTimeChangeAction(const QDateTime &oldDateTime, const QDateTime &newDateTime);

    QWidget *makeScrollCorner();
};

class CalibrationFileProvider : public QObject
{
    Q_OBJECT
public:
    CalibrationFileProvider(const QString &fileName, const QString &usbStickDirectory, const QString &calibrationFilePath, bool encrypedtFiles, QObject *parent = nullptr);

    QString currentChecksum() const { return mCurrentChecksum; }
    QString newChecksum() const { return mNewChecksum; }

    QString fileNameIfExists() const;

    void updatePanelLabelWithValueFromCurrentFile();

signals:
    void logMessageReady(const QString &message);

private:
    QString mFileName;
    QString mCurrentChecksum;
    QString mNewChecksum;

    QString mUsbStickDirectory;
    QString mCalibrationFilePath;
    bool    mEncrypedtFiles;
};

class FactoryProceduresFileProvider : public QObject
{
    Q_OBJECT
public:
    FactoryProceduresFileProvider(const QString &fileName, const QString &usbStickDirectory, QObject *parent = nullptr);

    QString fileNameIfExists() const;

signals:
    void logMessageReady(const QString &message);

private:
    QString mFileName;
    QString mCurrentVersion;
};

#endif // GUI_SCREENS_SERVICESCREEN_H
