#include "servicescreen.h"
#include "ui_servicescreen.h"

namespace {
Q_LOGGING_CATEGORY(LOG, "ServiceScreen")
}

auto DEMO_MODE_OFF_MAIN_TITLE = QObject::tr("SERVICE MODE");
auto DEMO_MODE_ON_MAIN_TITLE  = QObject::tr("SERVICE MODE - DEMO");
auto DEMO_MODE_OFF_BTN_TITLE  = QObject::tr("DEMO MODE DISABLED");
auto DEMO_MODE_ON_BTN_TITLE   = QObject::tr("DEMO MODE ENABLED");

static constexpr char const *VERSION_3_ZEROS = "0.0.0";
static constexpr char const *VERSION_4_ZEROS = "0.0.0.0";

static constexpr int DATE_TIME_UPDATE_INTERVAL_MS = 30000;

inline void reloadStyle(QWidget *widget)
{
    widget->style()->unpolish(widget);
    widget->style()->polish(widget);
}

inline void reloadStyleRecursive(QWidget *root)
{
    reloadStyle(root);
    for (auto widget : root->findChildren<QWidget *>()) {
        reloadStyle(widget);
    }
}

inline QString getFileNameFromJson(QString descriptionFilePath)
{
    QString res;
    try {
        auto fileFullInfo = std::make_shared<App::ChecksumVersion>();
        App::JsonSerializer::parseFromFile(descriptionFilePath, *fileFullInfo);
        res            = fileFullInfo->filePath();
        auto pathParts = res.split(QChar(47));
        res            = pathParts.last();
    }
    catch (const std::exception &exn) {
        res = QString("Error while reading path for %1").arg(exn.what());
        qCWarning(LOG) << res;
    }
    return res;
}

void ServiceScreen::initServiceScreenTopBar()
{
    /// ui->topBar->setTitle(tr("Service"));
    /// auto backButton = ui->topBar->addBackButton();
    /// connect(backButton, &QAbstractButton::clicked, this, &ServiceScreen::backButtonClicked);

    ui->titleAssistantLabel->clear();

    const QString serviceScreenTopBar = "QLabel#titleAssistantLabel, QLabel#titleAssistantInvisibleLabel, QLabel#lbDemo { "
                                        "font-size: 35px; "
                                        "font-family: Open Sans; "
                                        "font-weight: bold; "
                                        "text-transform: uppercase; "
                                        "margin-top: 8px; "
                                        "}";
    ui->titleAssistantLabel->setText(tr("SERVICE"));
    ui->topBar->setStyleSheet(serviceScreenTopBar);

    ui->frIndicators->setStyleSheet("QFrame { border: none; }");

    connect(ui->backButton, &QPushButton::clicked, this, &ServiceScreen::backButtonClicked);
}

ServiceScreen::ServiceScreen(
        ServiceScreenExternalParameters externalParameters,
        IBravoDeviceFront *             bravoDeviceFront,
        IUpdaterControllerFacade *      updateFacade,
        IFirmwareVersionsProvider *     firmVersions,
        IProfileStorage *               profileStorage,
        ISettingsFile *                 settingsFile,
        DemoModeSwitcher *              demoModeSwitcher,
        IWirelessPedalPairing *         wirelessPedalPairing,
        TreatmentLog::Storage *         treatmentLogStorage,
        IMixerVolume *                  volume,
        ISystemEventLogModel *          fullEventLogModel,
        QString                         fullEventLogQuery,
        QList<int>                      fullEventLogColumns,
        QWidget *                       parent) :
    QWidget(parent),
    ui(new Ui::ServiceScreen),
    mExternalParameters(externalParameters),
    mUpdaterFacade(updateFacade),
    mFirmVersions(firmVersions),
    mBravoDeviceFront(bravoDeviceFront),
    mProfileStorage(profileStorage),
    mSettingsFile(settingsFile),
    mWirelessPedalPairing(wirelessPedalPairing),
    mVolume(volume),
    mTreatmentLogStorage(treatmentLogStorage),
    mSystemEventLogModel(fullEventLogModel),
    mDateTimeUpdateTimer(new QTimer(this)),
    mDemoModeSwitcher(demoModeSwitcher)
{
    ui->setupUi(this);

    ///mSystemEventLogModel->setModelQuery(fullEventLogQuery);

    mCalibrationFile       = (new CalibrationFileProvider(mExternalParameters.cALIBRATION_FILE_UNECNRYPTED_NAME(), mExternalParameters.uSB_STICK_DIRECTORY(), mExternalParameters.cALIBRATION_FILE_PATH(), mExternalParameters.encryptedFiles(), this));
    mFactoryProceduresFile = (new FactoryProceduresFileProvider(mExternalParameters.pROFILES_FILE_NAME(), mExternalParameters.uSB_STICK_DIRECTORY(), this));
    mUsbStick              = (new UsbStorage(mExternalParameters.uSB_STICK_DEVICE(), mExternalParameters.uSB_STICK_DIRECTORY(), this));

    connect(mUsbStick, &IStorage::presenceChanged, ui->systemEventLogWidget, &SSystemEventLogWidget::onPbDownloadEnabled);
    connect(mUsbStick, &IStorage::presenceChanged, ui->systemEventLogWidget, &SSystemEventLogWidget::onPbDownloadEnabled);
    ui->systemEventLogWidget->initTableExternalParameters(mSystemEventLogModel, fullEventLogColumns, mExternalParameters.connectionName(), mExternalParameters.tableName(), mExternalParameters.uSB_STICK_DIRECTORY());
    ui->systemEventLogWidget->setTreatmentLogStorage(treatmentLogStorage);
    ui->systemEventLogWidget->onPbDownloadEnabled(mUsbStick->isPresent());

    initServiceScreenTopBar();

    connect(firmVersions, &IFirmwareVersionsProvider::changed, this, &ServiceScreen::updateVersions);
    connect(mCalibrationFile, &CalibrationFileProvider::logMessageReady, this, &ServiceScreen::addSoftwareLogLine);

    updateCurrentDateTimeWidget();
    connect(mDateTimeUpdateTimer, &QTimer::timeout, this, &ServiceScreen::updateCurrentDateTimeWidget);
    mDateTimeUpdateTimer->start(DATE_TIME_UPDATE_INTERVAL_MS);

    connect(mUsbStick, &IStorage::presenceChanged, this, &ServiceScreen::showUsbStickStatusInSoftwareLogLine);

    showUsbStickStatusInSoftwareLogLine(mUsbStick->isPresent());

    // Firmware panel ...........................

    initUpdatePanel(ui->laserMcuUpdatePanel, tr("MCU"), tr("LASER_BOARD ------ MCU"), mUpdaterFacade->laserBoardMcuUpdater());
    initUpdatePanel(ui->laserFpgaUpdatePanel, tr("FPGA"), tr("LASER_BOARD ------ FPGA"), mUpdaterFacade->laserBoardFpgaUpdater());
    initUpdatePanel(ui->laserBootloaderUpdatePanel, tr("BOOTLOADER"), tr("LASER_BOARD ------ BOOTLOADER"), mUpdaterFacade->laserBoardBootloaderUpdater());

    initUpdatePanel(ui->safetyMcuUpdatePanel, tr("MCU"), tr("SAFETY_BOARD ----- MCU"), mUpdaterFacade->safetyBoardMcuUpdater());
    initUpdatePanel(ui->safetyFpgaUpdatePanel, tr("FPGA"), tr("SAFETY_BOARD ----- FPGA"), mUpdaterFacade->safetyBoardFpgaUpdater());
    initUpdatePanel(ui->safetyBootloaderUpdatePanel, tr("BOOTLOADER"), tr("SAFETY_BOARD ----- BOOTLOADER"), mUpdaterFacade->safetyBoardBootloaderUpdater());

    initUpdatePanel(ui->opticalMcuUpdatePanel, tr("MCU"), tr("OPTICAL_BOARD ---- MCU"), mUpdaterFacade->opticalBoardMcuUpdater());
    initUpdatePanel(ui->opticalFpgaUpdatePanel, tr("FPGA"), tr("OPTICAL_BOARD ---- FPGA"), mUpdaterFacade->opticalBoardFpgaUpdater());
    initUpdatePanel(ui->opticalBootloaderUpdatePanel, tr("BOOTLOADER"), tr("OPTICAL_BOARD ---- BOOTLOADER"), mUpdaterFacade->opticalBoardBootloaderUpdater());

    initUpdatePanel(ui->distributionMcuUpdatePanel, tr("MCU"), tr("DISTRIBUTION_BOARD MCU"), mUpdaterFacade->ig597BoardMcuUpdater());
    initUpdatePanel(ui->distributionFpgaUpdatePanel, tr("FPGA"), tr("DISTRIBUTION_BOARD FPGA"), mUpdaterFacade->ig597BoardFpgaUpdater());
    initUpdatePanel(ui->distributionBootloaderUpdatePanel, tr("BOOTLOADER"), tr("DISTRIBUTION_BOARD BOOTLOADER"), mUpdaterFacade->ig597BoardBootloaderUpdater());

    createWatcher("br_ipgp881_mcu_*.bin", mUpdaterFacade->safetyBoardMcuUpdater());
    createWatcher("br_ipgp881_fpga_*.rbf", mUpdaterFacade->safetyBoardFpgaUpdater());
    createWatcher("br_ipgp881_bootloader_*.bin", mUpdaterFacade->safetyBoardBootloaderUpdater());

    if (mBravoDeviceFront->isIpgp964Board()) {
        createWatcher("br_ipgp964_mcu_*.bin", mUpdaterFacade->opticalBoardMcuUpdater());
        createWatcher("br_ipgp964_fpga_*.rbf", mUpdaterFacade->opticalBoardFpgaUpdater());
    }
    else {
        createWatcher("br_ipgp736_mcu_*.bin", mUpdaterFacade->opticalBoardMcuUpdater());
        createWatcher("br_ipgp736_fpga_*.rbf", mUpdaterFacade->opticalBoardFpgaUpdater());
    }
    createWatcher("br_ipgp736_bootloader_*.bin", mUpdaterFacade->opticalBoardBootloaderUpdater());

    createWatcher("br_ig545_mcu_*.bin", mUpdaterFacade->laserBoardMcuUpdater());
    createWatcher("br_ig545_fpga_*.rbf", mUpdaterFacade->laserBoardFpgaUpdater());
    createWatcher("br_ig545_bootloader_*.bin", mUpdaterFacade->laserBoardBootloaderUpdater());

    createWatcher("br_ig597_mcu_*.bin", mUpdaterFacade->ig597BoardMcuUpdater());
    createWatcher("br_ig597_fpga_*.rbf", mUpdaterFacade->ig597BoardFpgaUpdater());
    createWatcher("br_ig597_bootloader_*.bin", mUpdaterFacade->ig597BoardBootloaderUpdater());

    // Software panel ...........................
    initAppKernelImageDeviceTreeUpdater();

    initUpdatePanel(ui->calibrationUpdatePanel, "", tr("CALIBRATION"), mUpdaterFacade->calibrationUpdater());
    initUpdatePanel(ui->proceduresUpdatePanel, "", tr("FACTORY PROCEDURES"), mUpdaterFacade->factoryProceduresUpdater());

    createWatcher("bravo", mUpdaterFacade->applicationUpdater());

    QString kernelImageFileName = getFileNameFromJson(mExternalParameters.kERNEL_IMAGE_DESCRIPTION_FILE_PATH());
    createWatcher(kernelImageFileName, mUpdaterFacade->kernelImageUpdater());

    QString deviceTreeFileName = getFileNameFromJson(mExternalParameters.dEVICE_TREE_DESCRIPTION_FILE_PATH());
    createWatcher(deviceTreeFileName, mUpdaterFacade->deviceTreeUpdater());

    // Search for (!) Unencrypted Calibration file on Usb, then Encrypt it, then replace with the one on Device
    createWatcher(mExternalParameters.cALIBRATION_FILE_UNECNRYPTED_NAME(), mUpdaterFacade->calibrationUpdater());
    createWatcher(mExternalParameters.pROFILES_FILE_NAME(), mUpdaterFacade->factoryProceduresUpdater());

    // BackReflection Panel ......................
    ui->backReflectionCheckBox->setChecked(mBravoDeviceFront->isBackReflectionEnabled());
    //ui->backReflectionCheckBox->setChecked(mSettingsFile->backReflectionEnabled());
    connect(ui->backReflectionCheckBox, &QCheckBox::clicked, this, &ServiceScreen::setBackReflectionEnabled);

    ui->enablePollingPdCheckBox->setChecked(mBravoDeviceFront->isPdFeedbackPollingEnabled());
    connect(ui->enablePollingPdCheckBox, &QCheckBox::clicked, this, &ServiceScreen::setPdFeedbackPolling);

    connect(ui->pbSysConfSetDateTime, &QPushButton::clicked, this, &ServiceScreen::onPbSysConfSetDateTimeClicked);

#ifdef DEMO_MODE
    // If that option is enabled over СМАКЕ, then the turn DemoMode ON by Force*
    mDemoModeSwitcher->setDemoMode(true); // set TRUE by Force*
    // do NOT let user turn OFF Demo mode if it's enabled in CMAKE
    ui->pbDemoModeOn->setEnabled(false);
    ui->pbDemoModeOff->setEnabled(false);
#else
    connect(ui->pbDemoModeOn, &QToolButton::clicked, this, [this] { this->onPbDemoModeClicked(true); });
    connect(ui->pbDemoModeOff, &QToolButton::clicked, this, [this] { this->onPbDemoModeClicked(false); });
#endif
    actualizeDemoModeCaptions();

    ui->proceduresUpdateBlock->hide();
    ui->calibrationUpdateBlock->hide();
    ui->enablePollingPdLabel->hide();
    ui->enablePollingPdCheckBox->hide();
    ui->frameLogoScreenConfiguration->hide();

    updateVersions();

    loadSerialNumber();
    readEmissionMinutes();
    connect(ui->setEmissionMinutes, &QPushButton::clicked, this, &ServiceScreen::setEmissionMinutes);

    ui->tabWidgetServiceScreen->setCornerWidget(makeScrollCorner());

    initSliderForCoefficientToReduceVolume();
    hideSliderForCoefficientToReduceVolume();
}

void ServiceScreen::initSliderForCoefficientToReduceVolume()
{
    int vol = mSettingsFile->coefficientToReduceVolume();
    ui->slCoefficientToReduceVolume->setValue(vol);
    onCoefficientToReduceVolumeChanged(vol);
    connect(ui->slCoefficientToReduceVolume, &QSlider::valueChanged, this, &ServiceScreen::onCoefficientToReduceVolumeChanged);
}

void ServiceScreen::hideSliderForCoefficientToReduceVolume()
{
    ui->frameCoefficientToReduceVolumeValue->hide();
}

ServiceScreen::~ServiceScreen()
{
    delete mCalibrationFile;
    delete mFactoryProceduresFile;

    delete ui;
}

void ServiceScreen::onCoefficientToReduceVolumeChanged(int value)
{
    mSettingsFile->setCoefficientToReduceVolume(value);
    mVolume->setCoefficientToReduceVolume((-1) * value);
    ui->lbCoefficientToReduceVolumeValue->setText(QString::number(value));
}

void ServiceScreen::initAppKernelImageDeviceTreeUpdater()
{
    ui->applicationUpdatePanel->setTypeText("");
    ui->applicationUpdatePanel->setTypeFullText(tr("APPLICATION"));
    ui->kernelUpdatePanel->setTypeText("");
    ui->kernelUpdatePanel->setTypeFullText(tr("KERNEL IMAGE"));
    ui->kernelUpdatePanel->setIconOnButton("theme:icons/service/update_button_extra-active.png", "theme:icons/service/update_button-disabled.png");
    ui->deviceTreeUpdatePanel->setTypeText("");
    ui->deviceTreeUpdatePanel->setTypeFullText(tr("DEVICE TREE"));
    ui->deviceTreeUpdatePanel->setIconOnButton("theme:icons/service/update_button_extra-active.png", "theme:icons/service/update_button-disabled.png");

    mAppUpdater = new AppKernelDevTreeUpdater(ui->applicationUpdatePanel, ui->kernelUpdatePanel, ui->deviceTreeUpdatePanel, mUpdaterFacade, this);

    connect(mAppUpdater, &AppKernelDevTreeUpdater::startUpdateApp, this, [this]() { startUpdate(mUpdaterFacade->applicationUpdater()); });
    connect(mAppUpdater, &AppKernelDevTreeUpdater::startUpdateKernelImage, this, [this]() { startUpdate(mUpdaterFacade->kernelImageUpdater()); });
    connect(mAppUpdater, &AppKernelDevTreeUpdater::startUpdateDeviceTree, this, [this]() { startUpdate(mUpdaterFacade->deviceTreeUpdater()); });

    connect(mAppUpdater, &AppKernelDevTreeUpdater::addSoftwareLogLine, this, &ServiceScreen::addSoftwareLogLine);
    connect(mAppUpdater, &AppKernelDevTreeUpdater::updateErrorOccured, this, &ServiceScreen::updateError);
    connect(mAppUpdater, &AppKernelDevTreeUpdater::updateFinished, this, &ServiceScreen::updateFinished);
}

QString ServiceScreen::getChecksumVersionFromJsonDescriptionFile(QString descriptionFilePath) const
{
    QString res;
    try {
        auto version = std::make_shared<App::ChecksumVersion>();
        App::JsonSerializer::parseFromFile(descriptionFilePath, *version);
        res = version->value();
    }
    catch (const std::exception &exn) {
        res = QString("Error while reading version %1").arg(exn.what());
        qCWarning(LOG) << res;
    }
    return res;
}

QString ServiceScreen::getKernelImageVersion(QString descriptionFilePath) const
{
    if (descriptionFilePath.isEmpty())
        descriptionFilePath = mExternalParameters.kERNEL_IMAGE_DESCRIPTION_FILE_PATH();

    return getChecksumVersionFromJsonDescriptionFile(descriptionFilePath);
}

QString ServiceScreen::getDeviceTreeVersion(QString descriptionFilePath) const
{
    if (descriptionFilePath.isEmpty())
        descriptionFilePath = mExternalParameters.dEVICE_TREE_DESCRIPTION_FILE_PATH();

    return getChecksumVersionFromJsonDescriptionFile(descriptionFilePath);
}

void ServiceScreen::showUsbStickStatusInSoftwareLogLine(bool isUsbPresent)
{
    static bool present    = false;
    QString     presentStr = QString("USB stick drive: %1").arg(isUsbPresent ? "PRESENT" : "NOT present");
    addSoftwareLogLine(presentStr);
    addFirmwareLogLine(presentStr);

    if (present == true && isUsbPresent == false) {
        presentStr = ("_________________________________________________________");
        addSoftwareLogLine(presentStr);
        addFirmwareLogLine(presentStr);
    }

    present = isUsbPresent;
}

void ServiceScreen::readEmissionMinutes()
{
    ui->emissionMinutes->setText(QString("%1").arg(mBravoDeviceFront->laserBackEmissionTime()));
}

QString ServiceScreen::getRfidTransceiverVersion() const
{
    return mBravoDeviceFront->getRfidTransceiverVersion();
}

void ServiceScreen::setEmissionMinutes()
{
    mBravoDeviceFront->setLaserBackEmissionTime(0);
    qDebug() << QString("Reset back emission time: %1 --> %2").arg(ui->emissionMinutes->text()).arg(0);

    readEmissionMinutes();
}

void ServiceScreen::loadSerialNumber()
{
    ui->serialNumber->setText(mBravoDeviceFront->laserSerialNumber());
}

QWidget *ServiceScreen::makeScrollCorner()
{
    QWidget *    corner = new QWidget(this);
    QHBoxLayout *layout = new QHBoxLayout(corner);
    layout->setContentsMargins(2, 0, 2, 0);
    layout->setSpacing(2);

    QPushButton *leftButton = new QPushButton("<", corner);
    leftButton->setObjectName("ScrollLeft");

    QPushButton *rightButton = new QPushButton(">", corner);
    rightButton->setObjectName("ScrollRight");

    layout->addWidget(leftButton, Qt::AlignVCenter | Qt::AlignRight);
    layout->addWidget(rightButton, Qt::AlignVCenter | Qt::AlignRight);

    connect(leftButton, &QPushButton::clicked, this, [this]() {
        ui->tabWidgetServiceScreen->setCurrentIndex(ui->tabWidgetServiceScreen->currentIndex() - 1);
    });

    connect(rightButton, &QPushButton::clicked, this, [this]() {
        ui->tabWidgetServiceScreen->setCurrentIndex(ui->tabWidgetServiceScreen->currentIndex() + 1);
    });

    return corner;
}

void ServiceScreen::setDemoModeTopBar()
{
    const QString demoSuffix = tr(" - DEMO");
    bool          isDemo     = mDemoModeSwitcher->isDemoMode();
    if (!isDemo && ui->titleAssistantLabel->text().contains(demoSuffix)) {
        ui->titleAssistantLabel->setText(ui->titleAssistantLabel->text().left(ui->titleAssistantLabel->text().indexOf(demoSuffix)));
    }
    else if (isDemo && !ui->titleAssistantLabel->text().contains(demoSuffix)) {
        ui->titleAssistantLabel->setText(ui->titleAssistantLabel->text() + demoSuffix);
    }
}

void ServiceScreen::actualizeDemoModeCaptions()
{
    /// ui->topBar->setDemoMode(mDemoModeSwitcher->isDemoMode()); // TO DO //
    /// ui->lbDemo->setText(mDemoModeSwitcher->isDemoMode() ? tr(" - DEMO") : "");
    setDemoModeTopBar();

    ui->pbDemoModeOn->setDown(mDemoModeSwitcher->isDemoMode());
    ui->pbDemoModeOff->setDown(!mDemoModeSwitcher->isDemoMode());
}

bool ServiceScreen::isDemoMode() const
{
    return mDemoModeSwitcher->isDemoMode();
}

void ServiceScreen::onPbDemoModeClicked(bool enable)
{
#ifndef DEMO_MODE
    if (mDemoModeSwitcher->isDemoMode() == enable) {
        actualizeDemoModeCaptions();
        reloadStyleRecursive(this);
        return;
    }

    /// QuestionDialog dlg(question, tr("Yes"), tr("No"), this);
    ///dlg.setQuestionFontSize(30);
    ///dlg.setGapOverQuestionHeight(45);

    QString     question = tr("System configuration will be saved\npermanently. Are you sure you want to\nchange system configuration?");
    QMessageBox dlg(this);
    auto        acceptButton = AppKernelDevTreeUpdater::prepareQuestionDialog(dlg, question, tr("Yes"), tr("No"), this);

    dlg.exec();

    ///if (QDialog::Accepted == dlg.exec()) {
    if (dlg.clickedButton() == acceptButton) {
        // Device
        mDemoModeSwitcher->setDemoMode(!(mDemoModeSwitcher->isDemoMode()));
        // Label
        actualizeDemoModeCaptions();
        reloadStyleRecursive(this);
        // Settings
        mSettingsFile->setDemoMode(mDemoModeSwitcher->isDemoMode());
        // Service Logs
        logDemoMode(mDemoModeSwitcher->isDemoMode());
    }
#endif
}

void ServiceScreen::initUpdatePanel(UpdatePanel *pnl, const QString &typeText, const QString &typeFullText, IUpdaterFacade *updater)
{
    pnl->setTypeText(typeText);
    pnl->setTypeFullText(typeFullText);

    connect(pnl, &UpdatePanel::updateRequested, this, [updater, pnl, this]() {
        addSoftwareOrFirmwareLogLine(QString("* Update requested for: %1 file").arg(pnl->typeFullText()), pnl);
        startUpdate(updater);
    });

    connect(updater, &IUpdaterFacade::fileNameChanged, this, [pnl, updater, this]() {
        QString fileName      = updater->fileName();
        bool    isFilePresent = !fileName.isEmpty();
        pnl->setButtonEnabled(isFilePresent);
        if (mUsbStick->isPresent() && isFilePresent) {
            QString pText = pnl->typeFullText();
            addSoftwareOrFirmwareLogLine(QString("%1 File found on USB drive").arg(pnl->typeFullText()), pnl);
        }
    });

    connect(updater, &IUpdaterFacade::progressChanged,
            pnl, &UpdatePanel::setProgress);

    connect(updater, &IUpdaterFacade::finished, this, [pnl, updater, this]() {
        pnl->setProgress(-1);
        QString pText = pnl->typeText();

        QString currentVersionString = pnl->versionText();
        currentVersionString.replace('\n', ' ');

        mFirmVersions->refresh();
        updateVersions();

        // If versions are equal (old==new) or they are all zeros, then we print from what file we did the update
        // If versions are Not equal (old!=new), then we print old and new versions and from what file we did the update
        QString newVersionString = pnl->versionText();
        bool    isBadVersion     = ((newVersionString == VERSION_3_ZEROS) || (newVersionString == VERSION_4_ZEROS) || (currentVersionString == newVersionString));

        QString msg = tr("Update successfully finished for: %1. Has been updated from v %2 ");
        if (isBadVersion) {
            msg += tr(" from file: %3");
            msg = msg.arg(pnl->typeFullText()).arg(currentVersionString).arg(updater->fileName());
        }
        else {
            msg += tr(" to v %3 from file: %4");
            msg = msg.arg(pnl->typeFullText()).arg(currentVersionString).arg(newVersionString).arg(updater->fileName());
        }

        addSoftwareOrFirmwareLogLine(msg, pnl);
        qCDebug(LOG).noquote() << msg;
    });

    connect(updater, &IUpdaterFacade::errorOccurred,
            this, &ServiceScreen::updateError);

    if (pnl->parentWidget() == ui->firmwareUpdateTab) {
        connect(updater, &IUpdaterFacade::logMessageReady,
                this, &ServiceScreen::addFirmwareLogLine);
    }
    else {
        connect(updater, &IUpdaterFacade::logMessageReady,
                this, &ServiceScreen::addSoftwareLogLine);
    }

    connect(updater, &IUpdaterFacade::finished,
            this, &ServiceScreen::updateFinished);
}

void ServiceScreen::createWatcher(const QString &filePattern, IUpdaterFacade *updater)
{
    QString               patternToWatchFor = QString("%1/%2").arg(mExternalParameters.uSB_STICK_DIRECTORY()).arg(filePattern);
    Updater::FileWatcher *watcher           = new Updater::FileWatcher(patternToWatchFor, this);
    connect(watcher, &Updater::FileWatcher::changed, [updater](const QString &file) {
        updater->setFileName(file);
    });
    watcher->start();
}

void ServiceScreen::prepareRfidTransceiverVersion(QString &rfidTransceiverVersion)
{
    // Prepare the vewrsion to make Word Wrap use on it:
    if (rfidTransceiverVersion.isEmpty()) {
        rfidTransceiverVersion = "---";
    }
    else {
        int rfidVerLen = rfidTransceiverVersion.length();
        if (rfidVerLen > 16) {
            auto parts                    = rfidTransceiverVersion.split("-");
            bool isNotEmptyAndHasSplitted = false;
            if (!parts.empty()) {
                isNotEmptyAndHasSplitted = (rfidTransceiverVersion != parts.first());
            }

            if (isNotEmptyAndHasSplitted) {
                QString res;
                for (int i = 0, ilen = parts.size(); i < ilen; ++i) {
                    res.append(parts[i]);
                    if (i != ilen - 1)
                        res.append("\n");
                }
                rfidTransceiverVersion = res;
            }
            else {
                // If no "-" found and it's too long
                // At least split it in half
                int halfMaxLen = (rfidVerLen / 2);
                if (rfidTransceiverVersion.length() > halfMaxLen) {
                    int halfName = (rfidTransceiverVersion.length() / 2) + 1;
                    rfidTransceiverVersion.insert(halfName, "\n");
                }
            }
        }
    }
}

QString ServiceScreen::getCarrierBoardVersion() const
{
    uint8_t version = CarrierBoard::carrierBoardVersion();
    return QString::number(version);
}

void ServiceScreen::updateVersions()
{
    QString ver = mWirelessPedalPairing->getVersion();
    ui->wirelessVersion->setText(ver);

    ui->carrierBoardVersion->setText(getCarrierBoardVersion());

    QString rfidTransceiverVersion = getRfidTransceiverVersion();
    prepareRfidTransceiverVersion(rfidTransceiverVersion);
    ui->rfidUpdatePanel->setVersionText(rfidTransceiverVersion); // "01.0B.02.05-\n20.18.08.06-\nBL12.12.13.00");

    ui->laserMcuUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Laser"].mcuVersion.toFullString());
    ui->laserFpgaUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Laser"].fpgaVersion.toFullString());

    QString verMajMinBuild              = mFirmVersions->boardVersions()["Laser"].bootloaderVersion.toString();
    QString laserBoardBootloaderVersion = "0." + verMajMinBuild;
    ui->laserBootloaderUpdatePanel->setVersionText(laserBoardBootloaderVersion);

    ui->safetyMcuUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Safety"].mcuVersion.toString());
    ui->safetyFpgaUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Safety"].fpgaVersion.toString());
    ui->safetyBootloaderUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Safety"].bootloaderVersion.toString());

    ui->opticalMcuUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Optical"].mcuVersion.toString());
    ui->opticalFpgaUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Optical"].fpgaVersion.toString());
    ui->opticalBootloaderUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Optical"].bootloaderVersion.toString());

    ui->distributionMcuUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Distribution"].mcuVersion.toString());
    ui->distributionFpgaUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Distribution"].fpgaVersion.toString());
    ui->distributionBootloaderUpdatePanel->setVersionText(mFirmVersions->boardVersions()["Distribution"].bootloaderVersion.toString());

    ui->applicationUpdatePanel->setVersionText(QString("%1.%2 build %3\nhashes: %4:%5   ")
                                                       .arg(mExternalParameters.aPP_VERSION_MAJOR())
                                                       .arg(mExternalParameters.aPP_VERSION_MINOR())
                                                       .arg(mExternalParameters.aPP_VERSION_BUILD())
                                                       .arg(GIT_COMMIT_HASH)
                                                       .arg(GIT_COMMIT_HASH_CORE));

    ui->kernelUpdatePanel->setVersionText(getKernelImageVersion());
    ui->deviceTreeUpdatePanel->setVersionText(getDeviceTreeVersion());

    QString profilesAndFactoryPresetsFileVersion = mProfileStorage->fileVersion();
    ui->proceduresUpdatePanel->setVersionText(profilesAndFactoryPresetsFileVersion.isEmpty() ? "0.0" : profilesAndFactoryPresetsFileVersion);

    ui->calibrationUpdatePanel->setVersionText(QString(tr("curr checksum: %1\nnew checksum: %2"))
                                                       .arg(mCalibrationFile->currentChecksum().isEmpty() ? "" : mCalibrationFile->currentChecksum().left(7) + "...")
                                                       .arg(mCalibrationFile->newChecksum().isEmpty() ? "" : mCalibrationFile->newChecksum().left(7) + "..."));
}

void ServiceScreen::backButtonClicked()
{
    if (!mRebootRequired) {
        emit backRequired();
        return;
    }

    /// QuestionDialog dlg(tr("After update you should restart the device.\n Restart now?"),
    ///                   tr("Restart"), tr("Cancel"),
    ///                   this);

    QMessageBox dlg(this);
    auto        acceptButton = AppKernelDevTreeUpdater::prepareQuestionDialog(dlg, tr("After update you should restart the device.\n Restart now?"),
                                                                       tr("Restart"), tr("Cancel"),
                                                                       this);
    dlg.exec();

    ///if (QDialog::Accepted == dlg.exec()) {
    if (dlg.clickedButton() == acceptButton) {
#ifndef Q_PROCESSOR_X86
        std::system("reboot");
#else
        QCoreApplication::quit();
#endif
    }
}

void ServiceScreen::setBackReflectionEnabled(bool value)
{
    mBravoDeviceFront->setBackReflectionEnabled(value);
    ui->backReflectionCheckBox->setChecked(mBravoDeviceFront->isBackReflectionEnabled());

    //mSettingsFile->setBackReflectionEnabled(value);
}

void ServiceScreen::setPdFeedbackPolling(bool enabled)
{
    mBravoDeviceFront->setPdFeedbackPollingEnabled(enabled);
    ui->enablePollingPdCheckBox->setChecked(mBravoDeviceFront->isPdFeedbackPollingEnabled());
}

void ServiceScreen::onPbSysConfSetDateTimeClicked()
{
    DateTimePicker dlg(this);
    if (DateTimePicker::Accepted == dlg.exec()) {
        auto newDateTime = dlg.selectedDateTime();
        auto oldDateTime = QDateTime::currentDateTime();
        setSystemDateTime(newDateTime);
        updateCurrentDateTimeWidget();
        logDateTimeChangeAction(oldDateTime, newDateTime);
    }
}

void ServiceScreen::updateCurrentDateTimeWidget()
{
    auto dt = QDateTime::currentDateTime();
    ui->lbSysConfDateValue->setText(dt.date().toString("yyyy-MM-dd"));
    ui->lbSysConfTimeValue->setText(dt.time().toString("HH:mm AP"));
}

void ServiceScreen::logDemoMode(bool isDemoMode)
{
    emit saveToSystemEventLog("Service Mode", isDemoMode ? "Demo Mode Enabled" : "Demo Mode Disabled", QDateTime::currentDateTime().toString(), mExternalParameters.systemInformationVariableValueKey(), QVariant(isDemoMode).toString());

    /*
    auto event = SystemEventLog::log(SERVICE_LOG).createEvent(isDemoMode ? "Demo Mode Enabled" : "Demo Mode Disabled");
    event->systemInformation().put(mExternalParameters.systemInformationVariableValueKey(), QVariant(isDemoMode).toString());
    event->saveToLog();
    */
}

void ServiceScreen::logDateTimeChangeAction(const QDateTime &oldDateTime, const QDateTime &newDateTime)
{
    emit saveToSystemEventLog("Service Mode", "System Date Set", oldDateTime.toString(), mExternalParameters.systemInformationVariableValueKey(), newDateTime);

    /*
    auto event = SystemEventLog::log(SERVICE_LOG).createEvent("System Date Set", oldDateTime);
    event->systemInformation().put(mExternalParameters.systemInformationVariableValueKey(), newDateTime);
    event->saveToLog();
    */
}

void ServiceScreen::startUpdate(IUpdaterFacade *updater)
{
    if (!updater) {
        return;
    }

    mRebootRequired = true;
    this->setEnabled(false);

    for (auto watcher : findChildren<Updater::FileWatcher *>()) {
        watcher->stop();
    }

    updater->start();
}

void ServiceScreen::updateError(const Error &error)
{
    //WarningDialog dlg(error.what(), this);

    //QMessageBox dlg("Update Error", error.what(), this);
    ///QMessageBox dlg("Update Error", error.what(), nullptr, 0, 0, 0, this);
    QMessageBox dlg(this);
    dlg.setText(error.what());
    dlg.setWindowTitle("Update Error");
    dlg.exec();
}

void ServiceScreen::updateFinished()
{
    this->setEnabled(true);
    for (auto watcher : findChildren<Updater::FileWatcher *>()) {
        watcher->start();
    }
}

void ServiceScreen::addFirmwareLogLine(const QString &msg)
{
    ui->firmwareLogBox->insertPlainText(msg + "\n");
    QScrollBar *scroll = ui->firmwareLogBox->verticalScrollBar();
    scroll->setValue(scroll->maximum());
}

void ServiceScreen::addSoftwareLogLine(const QString &msg)
{
    ui->softwareLogBox->insertPlainText(msg + "\n");
    QScrollBar *scroll = ui->softwareLogBox->verticalScrollBar();
    scroll->setValue(scroll->maximum());
}

void ServiceScreen::addSoftwareOrFirmwareLogLine(const QString &msg, UpdatePanel *pnl)
{
    bool isMsgForSoftwareTab = false;
    isMsgForSoftwareTab      = (pnl == ui->applicationUpdatePanel) || (pnl == ui->kernelUpdatePanel) || (pnl == ui->deviceTreeUpdatePanel) || (pnl == ui->proceduresUpdatePanel) || (pnl == ui->calibrationUpdatePanel);
    if (isMsgForSoftwareTab) {
        addSoftwareLogLine(msg);
    }
    else {
        addFirmwareLogLine(msg);
    }
}

//
// CalibrationFileProvider
//

CalibrationFileProvider::CalibrationFileProvider(const QString &fileName, const QString &usbStickDirectory, const QString &calibrationFilePath, bool encrypedtFiles, QObject *parent) :
    QObject(parent),
    mFileName(QString("%1/%2").arg(usbStickDirectory).arg(fileName)),
    mUsbStickDirectory(usbStickDirectory),
    mCalibrationFilePath(calibrationFilePath),
    mEncrypedtFiles(encrypedtFiles)
{
    updatePanelLabelWithValueFromCurrentFile();
}
QString CalibrationFileProvider::fileNameIfExists() const
{
    QFileInfo fi(mFileName);
    if (!fi.exists()) {
        return QString();
    }
    return fi.fileName();
}

void CalibrationFileProvider::updatePanelLabelWithValueFromCurrentFile()
{
    QString currentFileName = QString("%1").arg(mCalibrationFilePath);

    try {
        CalibrationReader reader(currentFileName, mEncrypedtFiles);
        CalibrationData   data = reader.read().tryResult();
        mCurrentChecksum       = data.checksum;
    }
    catch (const Error &err) {
        emit logMessageReady(tr("Can't read checksum of current calibration file: %1").arg(currentFileName));
        return;
    }

    try {
        if (mFileName.isEmpty()) {
            return;
        }
        CalibrationReader reader(mFileName, mEncrypedtFiles);
        CalibrationData   data = reader.read().tryResult();

        mNewChecksum = data.checksum;
    }
    catch (const Error &err) {
        qCWarning(LOG) << QString("Can't read calibration file on USB drive: %1").arg(err.what());
        emit logMessageReady(tr("Can't read checksum of new calibration file %1").arg(mFileName));
        return;
    }
}

//
// FactoryProceduresFileProvider
//

FactoryProceduresFileProvider::FactoryProceduresFileProvider(const QString &fileName, const QString &usbStickDirectory, QObject *parent) :
    QObject(parent),
    mFileName(QString("%1/%2").arg(usbStickDirectory).arg(fileName))
{
}
QString FactoryProceduresFileProvider::fileNameIfExists() const
{
    QFileInfo fi(mFileName);
    if (!fi.exists()) {
        return QString();
    }
    return fi.fileName();
}
