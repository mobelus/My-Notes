#include "wdtreatpedal.h"
#include "ui_wdtreatpedal.h"
#include "wdpickerwheel.h"
#include "wdunitlabel.h"

#include "modewidgets/modeselectionpopup/modeselectionpopup.h"
#include "../interfaces/standbystatemodewidgetbuilder.h"
#include "../interfaces/readystatemodewidgetbuilder.h"
#include "../interfaces/emissionstatemodewidgetbuilder.h"
#include "../utils/icon.h"

#include "treatmentmodes/operationpresetlist.h"
#include "treatmentmodes/modecreator.h"
#include "popups/selectpulsemodepopup.h"

#include <QTimer>

constexpr int PEDAL_IMAGE_MARGIN     = 19;
constexpr int PEDAL_LABEL_MARGIN     = 9;
constexpr int PEDAL_OUTSIDE_MARGIN   = 19;
constexpr int PEDAL_INSIDE_MARGIN    = 27;
constexpr int ICON_BLINK_INTERVAL_MS = 1000;

WdTreatPedal::WdTreatPedal(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WdTreatPedal),
    mHeaderIcons {
        { Icon::byName("pedalleft46x46"), Icon::byName("pedalleftnegative") },
        { Icon::byName("pedalright46x46"), Icon::byName("pedalrightnegative") },
    }
{
    ui->setupUi(this);

    mEmissionShutter = new QWidget(this);
    mEmissionShutter->hide();
    mEmissionShutter->setObjectName("emissionShutter");
    mEmissionShutter->setGeometry(0, 0, width(), height());
    mShutterIcon = new QLabel(mEmissionShutter);
    mShutterIcon->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    mShutterIcon->setPixmap(Icon::byName("emission"));
    QHBoxLayout *ltGrid = new QHBoxLayout(mEmissionShutter);
    ltGrid->addWidget(mShutterIcon);

    mIconBlinkTimer = new QTimer(this);
    mIconBlinkTimer->setInterval(ICON_BLINK_INTERVAL_MS);
    connect(mIconBlinkTimer, &QTimer::timeout, this, [=]() { mShutterIcon->setVisible(!mShutterIcon->isVisible()); });

    ui->lbSide->setFontPixelSize(Style::fs29);
    ui->lbSide->setStyleId(Style::greyText);
    ui->lbSide->setVerticalIndent(3);
    ui->lbSide->setHorizontalIndent(0);
    ui->lbSide->setVerticalAlignment(AdjustableLabel::CenterCapHeight);

    ui->lbName->setFontPixelSize(Style::fs36);
    ui->lbName->setVerticalIndent(3);
    ui->lbName->setHorizontalAlignment(AdjustableLabel::AlignHCenter);

    ui->lbWarningIcon->setText("");

    connect(this, &WdTreatPedal::changeModeClicked, this, &WdTreatPedal::showModeSelectionPopup);
}

void WdTreatPedal::setName(const QString &name)
{
    ui->lbName->setText(name);

    onRescaledHeaderItems(false);
}

void WdTreatPedal::onRescaledHeaderItems(bool isWarningOn)
{
    // IF TEMPERATURE OUT OF LIMIT
    if (isWarningOn)
        Icon::setForLabel(ui->lbWarningIcon, "error40x40");

    int lbAsSpacerLen          = ui->treatPedalCaption->width();
    int areaWithIconAndNameLen = ui->presetIconName->width() - 10;

    ui->lbName->setElideMode(Qt::TextElideMode::ElideNone);
    int warningIconWidth = isWarningOn ? (ui->lbWarningIcon->width() * 2) : ui->lbWarningIcon->width();
    //int warningIconWidth = isWarningOn ? ui->lbWarningIcon->width() : 0;
    //int          warningIconWidth = isWarningOn ? ui->lbWarningIcon->width() - ui->presetIconNameLayout->spacing() : 0;
    auto         name = ui->lbName->text();
    QFontMetrics fontMetrics(ui->lbName->font());
    int          textWidth  = fontMetrics.width(name);
    int          normalLen  = areaWithIconAndNameLen;
    int          maximalLen = areaWithIconAndNameLen + lbAsSpacerLen;
    ui->lbName->setElideMode(Qt::TextElideMode::ElideRight);

    // ^ = warning on, x - warning off, |^ or x| <-left-middle-part | right-spacer-label-part |
    //     |^|abcde |       |
    //     |x|abcde |       |
    //     | normal |
    //     |     maximal    |

    int spacerWidth = 0;
    if (textWidth <= normalLen) {
        //     |^|abcde |       |
        //     |x|abcde |       |
        if (ui->treatPedalCaption->layoutDirection() == Qt::LeftToRight) {
            spacerWidth = lbAsSpacerLen + warningIconWidth;
        }
        else {
            if (isWarningOn)
                spacerWidth = lbAsSpacerLen - warningIconWidth;
            else
                spacerWidth = lbAsSpacerLen - warningIconWidth;
        }

        /*if (ui->treatPedalCaption->layoutDirection() == Qt::LeftToRight) {
            spacerWidth = lbAsSpacerLen + warningIconWidth;
        }
        else {
            spacerWidth = lbAsSpacerLen - warningIconWidth;
        }*/
    }
    else // if(textWidth > normalLen)
    {
        if (textWidth <= maximalLen) {
            // |^|abcdef|ghi    |
            // |x|abcdef|ghi    |
            spacerWidth = lbAsSpacerLen - warningIconWidth;
        }
        else //if (textWidth > maximalLen)
        {
            // |^|abcdef|ghij...|
            // |x|abcdef|ghij...|
            spacerWidth = 0;
        }
    }
    //QSize sz(spacerWidth, ui->treatPedalCaption->height()); //ui->labelAsSpacer->minimumSize().height());
    //ui->labelAsSpacer->setMinimumSize(sz);
    //ui->labelAsSpacer->setMaximumSize(sz);

    ui->labelAsSpacer->setMinimumWidth(spacerWidth);
    ui->labelAsSpacer->setMaximumWidth(spacerWidth);
    ui->labelAsSpacer->setFixedWidth(spacerWidth);
}

WdTreatPedal::~WdTreatPedal()
{
    delete ui;
}

void WdTreatPedal::changeEvent(QEvent *event)
{
    if (event->type() == QEvent::LanguageChange) {
        ui->retranslateUi(this);
    }
}

void WdTreatPedal::setSide(Side side)
{
    mSide = side;
    setSidePixmap(mHeaderIcons[(int)mSide].normal);

    while (ui->layoutHeader->count()) {
        ui->layoutHeader->takeAt(0);
    }

    QMargins headerMargins        = ui->layoutHeader->contentsMargins();
    QMargins contentWidgetMargins = ui->layoutContent->contentsMargins();
    switch (mSide) {
        case Side::LEFT: {
            ui->lbSide->setText(tr("Left"));
            ui->lbSide->setHorizontalAlignment(WdLabel::AlignLeft);

            headerMargins.setLeft(PEDAL_IMAGE_MARGIN);
            headerMargins.setRight(PEDAL_LABEL_MARGIN);
            // []Left   Left Pedal   LABEL
            ui->layoutHeader->addWidget(ui->treatPedalCaption);
            ui->layoutHeader->addWidget(ui->presetIconName);
            ui->layoutHeader->addWidget(ui->labelAsSpacer);

            ui->treatPedalCaption->setLayoutDirection(Qt::LeftToRight);

            contentWidgetMargins.setLeft(PEDAL_OUTSIDE_MARGIN);
            contentWidgetMargins.setRight(PEDAL_INSIDE_MARGIN);

            break;
        }
        case Side::RIGHT: {
            ui->lbSide->setText(tr("Right"));
            ui->lbSide->setHorizontalAlignment(WdLabel::AlignRight);

            headerMargins.setRight(PEDAL_IMAGE_MARGIN);
            headerMargins.setLeft(PEDAL_LABEL_MARGIN);
            // LABEL   Left Pedal   []Right
            ui->layoutHeader->addWidget(ui->labelAsSpacer);
            ui->layoutHeader->addWidget(ui->presetIconName);
            ui->layoutHeader->addWidget(ui->treatPedalCaption);

            ui->treatPedalCaption->setLayoutDirection(Qt::RightToLeft);

            contentWidgetMargins.setLeft(PEDAL_INSIDE_MARGIN);
            contentWidgetMargins.setRight(PEDAL_OUTSIDE_MARGIN);
            break;
        }
    }

    ui->layoutHeader->setContentsMargins(headerMargins);
    ui->layoutContent->setContentsMargins(contentWidgetMargins);

    handleHeader(mCurrentState, mSide);
    handleShutter(mCurrentState, mSide);
    Style::applyStyleProperty(this);
}

void WdTreatPedal::setCurrentState(IStateControllerFacade::State state)
{
    mCurrentState = state;
    if (!mMode) {
        return;
    }
    updateModeWidget();
    handleHeader(mCurrentState, mSide);
    handleShutter(mCurrentState, mSide);
}

void WdTreatPedal::setRegimeValues(Session::Mode sessionMode, const QString &name, const RegimeValues &values)
{
    mSessionMode = sessionMode;
    IMode *mode  = ModeCreator::create(values);
    mMode        = mode;
    connect(mMode, &IMode::changed, this, &WdTreatPedal::valueChoosen);
    connect(mMode, &IMode::changed, this, &WdTreatPedal::onModeChanged);
    mMode->setModeName(name);
}

void WdTreatPedal::onModeChanged()
{
    onRescaledHeaderItems();
}

void WdTreatPedal::updateModeWidget()
{
    connect(mMode, &IMode::switchModeRequired, this, &WdTreatPedal::onModeSwitched, Qt::UniqueConnection);

    IModeWidgetBuilder *builder = nullptr;
    switch (mCurrentState) {
        case IStateControllerFacade::State::FIBER_ABSENT:
        case IStateControllerFacade::State::ERROR:
        case IStateControllerFacade::State::STANDBY: {
            builder = new StandbyStateModeWidgetBuilder(mSide, [=]() { emit changeModeClicked(); });
            break;
        }
        case IStateControllerFacade::State::SWITCHING_TO_READY:
        case IStateControllerFacade::State::READY: {
            builder = new ReadyStateModeWidgetBuilder();
            break;
        }
        case IStateControllerFacade::State::RIGHT_PEDAL_EMISSION:
        case IStateControllerFacade::State::LEFT_PEDAL_EMISSION: {
            builder = new EmissionStateModeWidgetBuilder();
            break;
        }
        default: {
            break;
        }
    }
    if (builder) {
        builder->visit(*mMode);
    }

    if (mModeWidget) {
        mModeWidget->hide();
        delete mModeWidget;
    }
    mModeWidget = builder->getProduct();
    if (mModeWidget) {
        ui->contentWidget->layout()->addWidget(mModeWidget);
    }
    setName(mMode->modeName());
    delete builder;
}

void WdTreatPedal::handleShutter(IStateControllerFacade::State state, Side side)
{
    bool isShutterVisible = ((state == IStateControllerFacade::State::LEFT_PEDAL_EMISSION && side == Side::RIGHT)
                             || (state == IStateControllerFacade::State::RIGHT_PEDAL_EMISSION && side == Side::LEFT));

    if (isShutterVisible) {
        mEmissionShutter->show();
        mShutterIcon->show();
        mIconBlinkTimer->start();
    }
    else {
        mIconBlinkTimer->stop();
        mEmissionShutter->hide();
    }
}

void WdTreatPedal::onModeSwitched(IMode::Id newMode)
{
    IMode *mode = ModeCreator::create(newMode);
    mMode       = mode;
    connect(mMode, &IMode::changed, this, &WdTreatPedal::valueChoosen);
    updateModeWidget();
}

void WdTreatPedal::showModeSelectionPopup()
{

    bool needPopupForManual = false;

    QList<IMode::Id> modes;
    switch (mSessionMode) {
        case Session::Mode::Stone: {
            modes = { mSide == Side::LEFT ? IMode::Id::Dusting : IMode::Id::Fragmentation, IMode::Id::StepRetropulsion, IMode::Id::Square };
            break;
        }
        case Session::Mode::SoftTissue: {
            modes = { mSide == Side::LEFT ? IMode::Id::StepVaporization : IMode::Id::StepEnucleation, IMode::Id::StepRetropulsion, IMode::Id::Square };
            break;
        }
        case Session::Mode::Bph: {
            modes = { mSide == Side::LEFT ? IMode::Id::StepVaporization : IMode::Id::StepEnucleation, IMode::Id::Square };
            break;
        }
        case Session::Mode::Manual: {
            needPopupForManual = true;
            break;
        }
        default: {
            modes = { IMode::Id::Square, IMode::Id::StepRetropulsion, IMode::Id::CW };
            break;
        }
    }

    IMode::Id currentMode = mMode->id();
    if (needPopupForManual) {
        SelectPulseModePopup *popup = new SelectPulseModePopup(mSide == WdTreatPedal::Side::LEFT ? Pedal::Left : Pedal::Right, currentMode, topLevelWidget());
        connect(popup, &SelectPulseModePopup::modeSelected, [=]() {
            onModeSwitched(popup->currentMode());
        });
        popup->show();
    }
    else {
        QString             title     = mSide == WdTreatPedal::Side::LEFT ? tr("Left: Select Mode") : tr("Right: Select Mode");
        QString             popupIcon = mSide == WdTreatPedal::Side::LEFT ? "pedalleft46x46" : "pedalright46x46";
        ModeSelectionPopup *popup     = new ModeSelectionPopup(modes, currentMode, topLevelWidget());
        popup->setHeaderText(title);
        popup->setHeaderIcon(Icon::byName(popupIcon));
        connect(popup, &ModeSelectionPopup::modeSelected, [=]() {
            onModeSwitched(popup->mode());
        });
        popup->show();
    }
}

// void WdTreatPedal::setName(const QString &name)

void WdTreatPedal::setSidePixmap(const QPixmap &icon)
{
    ui->lbPedalImage->setPixmap(icon);
}

void WdTreatPedal::handleHeader(IStateControllerFacade::State state, Side side)
{
    bool isEmissionActive = ((state == IStateControllerFacade::State::LEFT_PEDAL_EMISSION && side == Side::LEFT)
                             || (state == IStateControllerFacade::State::RIGHT_PEDAL_EMISSION && side == Side::RIGHT));

    setSidePixmap(isEmissionActive ? mHeaderIcons[(int)side].negative : mHeaderIcons[(int)side].normal);
    ui->lbName->setStyleId(isEmissionActive ? Style::blackText : Style::defaultStyle);
    ui->lbSide->setStyleId(isEmissionActive ? Style::blackText : Style::lightGreyText);
    Style::applyStyleProperty(ui->wdHeader);
}
