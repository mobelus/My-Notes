#ifndef WDTREATPEDAL_H
#define WDTREATPEDAL_H

#include <QWidget>
#include <facade/interfaces/istatecontrollerfacade.h>
#include <facade/interfaces/imode.h>
#include <session.h>

class QLabel;
class QTimer;
class RegimeValues;

namespace Ui {
class WdTreatPedal;
}

class WdTreatPedal : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(Side side READ side WRITE setSide)
    Q_PROPERTY(IStateControllerFacade::State state READ currentState)

public:
    explicit WdTreatPedal(QWidget *parent = 0);
    ~WdTreatPedal();

    enum class Side {
        LEFT,
        RIGHT
    };
    Q_ENUM(Side)

    Side side() const { return mSide; }
    void setSide(Side side);

    const IMode *mode() const { return mMode; }

    IStateControllerFacade::State currentState() const { return mCurrentState; }

    void setCurrentState(IStateControllerFacade::State state);

    void setRegimeValues(Session::Mode sessionMode, const QString &name, const RegimeValues &values);

signals:
    void changeModeClicked();
    void valueChoosen();

private:
    void setName(const QString &name);
    void setSidePixmap(const QPixmap &icon);
    void handleHeader(IStateControllerFacade::State state, WdTreatPedal::Side side);
    void updateModeWidget();
    void handleShutter(IStateControllerFacade::State state, WdTreatPedal::Side side);
    void onModeSwitched(IMode::Id newMode);
    void showModeSelectionPopup();

    void onModeChanged();
    void onRescaledHeaderItems(bool isWarningOn = true);

private:
    struct HeaderIcons
    {
        QPixmap normal;
        QPixmap negative;
    };

    Ui::WdTreatPedal *ui;
    Side              mSide       = Side::LEFT;
    IMode *           mMode       = nullptr;
    QWidget *         mModeWidget = nullptr;

    QWidget *mEmissionShutter;
    QLabel * mShutterIcon;
    QTimer * mIconBlinkTimer;

    Session::Mode                 mSessionMode  = Session::Mode::Manual;
    IStateControllerFacade::State mCurrentState = IStateControllerFacade::State::STANDBY;
    const QVector<HeaderIcons>    mHeaderIcons;

protected:
    void changeEvent(QEvent *event) override;
};

#endif // WDTREATPEDAL_H
