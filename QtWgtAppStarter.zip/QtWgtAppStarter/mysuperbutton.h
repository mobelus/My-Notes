#ifndef MySuperButton_H
#define MySuperButton_H
#include "generalbutton.h"
#include <QPushButton>

// class MySuperButton : public QPushButton
class MySuperButton : public GeneralButton
{
    Q_OBJECT // don't forget this macro, or your signals/slots won't work
            public : MySuperButton(QWidget *parent = nullptr);
    virtual ~MySuperButton();
};

#endif // MySuperButton_H
