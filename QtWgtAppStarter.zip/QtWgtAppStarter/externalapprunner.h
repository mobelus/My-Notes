#ifndef EXTERNALAPPRUNNER_H
#define EXTERNALAPPRUNNER_H

#include <QObject>
#include <QProcess>

class ExternalAppRunner : public QObject
{
    Q_OBJECT
public:
    explicit ExternalAppRunner(QObject *parent = nullptr);
    ~ExternalAppRunner();

    bool start(QString s);
    void stop();

    void    setSyncExtension(const QString &ext);
    QString syncExtension() const;

    void    setAsyncExtension(const QString &ext);
    QString asyncExtension() const;

private:
    QProcess mProcess;
    QString  mSyncExtension  = "pps";
    QString  mAsyncExtension = "ppa";
};

#endif // EXTERNALAPPRUNNER_H

// AlarmWithError(Device_GeneralError<1001>: 6.1 2.3, Can't set emission to ON)" "Resolvable(0)"
