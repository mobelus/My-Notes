#include "frametwo.h"
#include "ui_frametwo.h"

FrameTwo::FrameTwo(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::FrameTwo)
{
    ui->setupUi(this);
}

FrameTwo::~FrameTwo()
{
    delete ui;
}
