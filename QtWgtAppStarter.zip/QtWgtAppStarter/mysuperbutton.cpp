#include "mysuperbutton.h"

// class implementation (MyButton.cpp)
MySuperButton::MySuperButton(QWidget *parent) : GeneralButton(parent)
{
    int b = 0;
}

MySuperButton::~MySuperButton()
{
    int a = 0;
}
