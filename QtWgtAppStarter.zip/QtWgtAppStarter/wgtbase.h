#ifndef WGTBASE_H
#define WGTBASE_H

#include <QWidget>
class WgtBase : public QWidget
{
    Q_OBJECT
public:
    explicit WgtBase(QWidget *parent = 0);
    ~WgtBase();
};

#endif // WGTBASE_H
