#ifndef GENERALBUTTON_H
#define GENERALBUTTON_H
#include <QPushButton>

class GeneralButton : public QPushButton
{
    Q_OBJECT // don't forget this macro, or your signals/slots won't work
            public : GeneralButton(QWidget *parent = nullptr);
    virtual ~GeneralButton();
};

#endif // GENERALBUTTON_H
