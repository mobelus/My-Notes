#include "localquestiondialog.h"
#include "ui_localquestiondialog.h"
/*
LocalQuestionDialog::LocalQuestionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LocalQuestionDialog)
{
    ui->setupUi(this);
}

LocalQuestionDialog::~LocalQuestionDialog()
{
    delete ui;
}
*/

LocalQuestionDialog::LocalQuestionDialog(QWidget *parent) : QDialog(parent)
{
    this->setObjectName(this->metaObject()->className());
}

void LocalQuestionDialog::centerQuestionDialog(QRect parentRect, QSize dlgSize)
{
    this->setStyleSheet("{ background-color: #243038; } .QMessageBox > QLabel { background-color: #243038; min-width:"
                        + QString::number(dlgSize.width()) + "px; min-height:" + QString::number(dlgSize.height())
                        + "px; }");

    QSize mSize = this->sizeHint();
    this->move(QPoint(parentRect.width() / 2 - mSize.width() / 2, parentRect.height() / 2 - mSize.height() / 2));
}

LocalQuestionDialog::LocalQuestionDialog(const QString &questionText, const QString &acceptButtonText, QWidget *parent)
    : LocalQuestionDialog(parent)
{
    this->setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowTitleHint);
    this->setText(questionText); ///"After update you should restart the device.\n Restart now?");
    /// this->setWindowTitle("Exit Service Screen");
    this->setStyleSheet(mQuestiondialogCss);

    /*mAcceptButton = this->addButton(QObject::tr(acceptButtonText.toLatin1()), QMessageBox::ActionRole);
    mAcceptButton->setObjectName("acceptButtonQuestionDialog");
    mAcceptButton->setStyleSheet(mQuestiondialogCss);*/

    adjustSize();
}

LocalQuestionDialog::LocalQuestionDialog(const QString &questionText, const QString &acceptButtonText,
                                         const QString &rejectButtonText, QWidget *parent)
    : LocalQuestionDialog(questionText, acceptButtonText, parent)
{
    /*mCancelButton = this->addButton(QObject::tr(rejectButtonText.toLatin1()), QMessageBox::ActionRole);
    mCancelButton->setObjectName("cancelButtonQuestionDialog");
    mCancelButton->setStyleSheet(mQuestiondialogCss);*/

    adjustSize();
}

void LocalQuestionDialog::setText(QString s)
{
    /*ui->questionLabel->setText(s);*/
}

LocalQuestionDialog::~LocalQuestionDialog()
{
    if (mAcceptButton != nullptr)
        delete mAcceptButton;

    if (mCancelButton != nullptr)
        delete mCancelButton;
}
