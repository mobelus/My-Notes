#include "frameone.h"
#include "ui_frameone.h"

FrameOne::FrameOne(QWidget *parent) : QFrame(parent), ui(new Ui::FrameOne)
{
    ui->setupUi(this);
}

FrameOne::~FrameOne()
{
    delete ui;
}

void FrameOne::init()
{
    auto a = 0;
}
