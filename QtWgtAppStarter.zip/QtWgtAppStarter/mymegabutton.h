#ifndef MyMegaButton_H
#define MyMegaButton_H
#include "generalbutton.h"
#include <QPushButton>

// class MyMegaButton : public QPushButton
class MyMegaButton : public GeneralButton
{
    Q_OBJECT // don't forget this macro, or your signals/slots won't work
            public : MyMegaButton(QWidget *parent = nullptr);
    virtual ~MyMegaButton();
};

#endif // MyMegaButton_H
