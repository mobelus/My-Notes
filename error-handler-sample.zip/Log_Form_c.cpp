//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Log_Form_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sMemo"
#pragma link "sPanel"
#pragma link "sSkinProvider"
#pragma link "sSpeedButton"
#pragma resource "*.dfm"
TLog_Form *Log_Form;
//---------------------------------------------------------------------------
__fastcall TLog_Form::TLog_Form(TComponent* Owner)
        : TForm(Owner), Error_Count(0)
{
}
//---------------------------------------------------------------------------
void __fastcall TLog_Form::sSpeedButton1Click(TObject *Sender)
{
   this->Close();
}
//---------------------------------------------------------------------------
void TLog_Form::Add(AnsiString line, bool Error)
{
   AnsiString st, e_st(" ");

   if(Error){
      Error_Count++;
      e_st = " ������: ";
   }

   TDateTime dt = Now();
   unsigned short h, m, s, ms;
   dt.DecodeTime(&h, &m, &s, &ms);
   st = st.sprintf("%s.%3d%s%s", dt.DateTimeString(), ms, e_st.c_str(), line.c_str());

   sMemo1->Lines->Add(st);

   Application->ProcessMessages();
}
//---------------------------------------------------------------------------
void TLog_Form::Clear()
{
   Error_Count = 0;
   sMemo1->Lines->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TLog_Form::Button1Click(TObject *Sender)
{
    if (SaveDialog1->Execute()) sMemo1->Lines->SaveToFile(SaveDialog1->FileName + ".txt");
}
//---------------------------------------------------------------------------

