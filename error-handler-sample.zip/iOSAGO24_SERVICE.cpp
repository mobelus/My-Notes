// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://apo.rgs.ru/Send_OSAGO_Service_Prod/Send_OSAGO_Service.dll/wsdl/ISend_OSAGO_Service
// Version  : 1.0
// (11.09.2015 16:08:59 - $Revision:   1.0.1.0.1.82  $)
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#if !defined(ISend_OSAGO24_ServiceH)
#include "iOSAGO24_SERVICE.h"
#endif



namespace NS_ISend_OSAGO24_Service {

_di_ISend_OSAGO24_Service GetISend_OSAGO24_Service(bool useWSDL, AnsiString addr)
{
  static const char* defWSDL= "http://apo.rgs.ru/Send_OSAGO_Service_Prod/Send_OSAGO_Service.dll/wsdl/ISend_OSAGO_Service";
  static const char* defURL = "http://apo.rgs.ru/Send_OSAGO_Service_Prod/Send_OSAGO_Service.dll/soap/ISend_OSAGO_Service";
  static const char* defSvc = "ISend_OSAGO_Serviceservice";
  static const char* defPrt = "ISend_OSAGO_ServicePort";
  if (addr=="")
    addr = useWSDL ? defWSDL : defURL;
  THTTPRIO* rio = new THTTPRIO(0);
  if (useWSDL) {
    rio->WSDLLocation = addr;
    rio->Service = defSvc;
    rio->Port = defPrt;
  } else {
    rio->URL = addr;
  }
  _di_ISend_OSAGO24_Service service;
  rio->QueryInterface(service);
  if (!service && !rio)
    delete rio;
  return service;
}


// ************************************************************************ //
// This routine registers the interfaces and types used by invoke the SOAP
// Service.
// ************************************************************************ //

//#pragma startup RegTypes 32

};     // NS_ISend_OSAGO_Service

