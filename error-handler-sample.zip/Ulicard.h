//---------------------------------------------------------------------------


#ifndef UlicardH
#define UlicardH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sCustomComboEdit.hpp"
#include "sEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "MainWinFC.h"
//---------------------------------------------------------------------------
class TLicard : public TFrame
{
__published:	// IDE-managed Components
  TGroupBox *GroupBox1;
  TsDateEdit *licard_date;
  TsEdit *EInsPhone3Code;
  TsEdit *EInsPhone3;
  TsEdit *licard_num;
  TButton *Button1;
  void __fastcall EInsPhone3CodeChange(TObject *Sender);
  void __fastcall EInsPhone3Change(TObject *Sender);
  void __fastcall EInsPhone3CodeKeyPress(TObject *Sender, char &Key);
  void __fastcall licard_numChange(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
   Set <char, '0', '9'> s1;
public:		// User declarations
  TFrame *print_frame;
  mops_api_027 *m_api;
  int res;
  __fastcall TLicard(TComponent* Owner);
  void LoadFrame(long id_calc);
  void SaveFrame(long id_calc);
  void CheckError();
};
//---------------------------------------------------------------------------
extern PACKAGE TLicard *Licard;
//---------------------------------------------------------------------------
#endif
