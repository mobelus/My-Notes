//--------------------------------------------------------------------


#pragma hdrstop

#include "Transdekra_funcs.h"
#include "cxImage.hpp"
#include "DateUtils.hpp"
#include <math.h>

//---------------------------------------------------------------------------

Transdekra::Transdekra(mops_api_014 *module_api)
{
        m_api=module_api;
        td_stoimosti_api=NULL;
        view_pic_form=NULL;
        GetTDApi();
}

AnsiString Transdekra::Get_Picture_By_TD_ID(AnsiString td_id,TStream *out)
{
        int res;
        AnsiString st;

        TSearchRec sr;
        AnsiString Path;

        Path=ExtractFilePath(Application->ExeName)+"\\System\\Transdekra_Pics\\";

        st="";
        if (FindFirst(Path+td_id+".*", faAnyFile, sr) == 0)
        {
          TFileStream *fs=new TFileStream(Path+sr.Name,fmOpenRead|fmShareDenyNone);
          fs->Position=0;
          out->CopyFrom(fs,fs->Size);
          out->Position=0;
          delete fs;
          st=sr.Name;
          FindClose(sr);
        }
        return st;
}

void Transdekra::Create_view_pic_form(TComponent *owner)
{
        bool need_create=false;
        if(!view_pic_form)
        {
                view_pic_form=new TForm(owner);
                need_create=true;
        }
        try{
                view_pic_form->Caption="";
        }catch(...)
        {
                view_pic_form=new TForm(owner);
                need_create=true;
        }

        if(need_create)
        {
                view_pic_form->Caption="";
                view_pic_form->BorderStyle=bsDialog;
                view_pic_form->BorderIcons.Empty();

                view_pic_form->AutoSize=true;
                view_pic_form->FormStyle=fsStayOnTop;

                view_pic_form->OnClose=view_pic_FormClose;
                view_pic_form->OnDestroy=view_pic_FormDestroy;
        }
}

void __fastcall Transdekra::view_pic_FormDestroy(TObject *Sender)
{
        view_pic_form=NULL;
}

void __fastcall Transdekra::view_pic_FormClose(TObject *Sender, TCloseAction &Action)
{
        Action=NULL;
        try{
        if(view_pic_form)
        delete view_pic_form;
        }catch(...){}
        view_pic_form=NULL;
}

AnsiString Transdekra::NolTORSA_ID(AnsiString RSA_ID)
{
        while(RSA_ID.Length()<9)RSA_ID="0"+RSA_ID;
        return RSA_ID;
}

unsigned long Transdekra::getCRC (char *pchBuf, int nBufLen)
{ 
int i;
int nIndex; 
char ch; 
unsigned long res; 
unsigned long table [] = {
0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA,
0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988,
0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,

0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE,
0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC,
0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,

0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172,
0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940,
0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,

0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116,
0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924,
0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,

0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A,
0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818,
0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,

0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E,
0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C,
0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,

0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2,
0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0,
0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,

0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086,
0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4,
0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,

0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A,
0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8,
0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,

0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE,
0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC,
0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,

0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252,
0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60,
0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,

0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236,
0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04,
0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,

0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A,
0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38,
0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,

0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E,
0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C,
0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,

0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2,
0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0,
0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,

0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6,
0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94,
0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
}; 
 
res = 0xFFFFFFFF; 
for (i=0;i<nBufLen+4;i++) 
{ 
nIndex = (res >> 24) & 0xFF; 
if (i<nBufLen)
ch = pchBuf[i]; 
else
ch = 0x0; 
res = (res << 8) | ch; 
res ^= table[nIndex]; 
      } 
 
      return res; 
}

bool Transdekra::ShowPictures(AnsiString RSA_ID,AnsiString GodVipuska,TComponent *owner)
{
        HidePicture();
        if(!td_stoimosti_api)
                return false;
        try
        {
        AnsiString st,sql;
        int res;
        TADOQuery *q;
        bool ret=false;

        sql="select distinct td_id from td_531 where 1=1 ";
        if(RSA_ID.Pos("TD_")==1)
        {
                RSA_ID=RSA_ID.SubString(4,RSA_ID.Length()-3);
                sql=sql+" and td_id='"+RSA_ID+"'";
        }
        else
        {
                RSA_ID=NolTORSA_ID(RSA_ID);
                sql=sql+" and rsa_id='"+RSA_ID+"'";
                if(GodVipuska!="")
                {
                        sql=sql+" and ("+GodVipuska+" >= Year(Cdate(car_prod_start)) and "+GodVipuska+" <= iif(car_prod_end is NULL or car_prod_end='',Year(DATE()),Year(Cdate(car_prod_end))) "+")";
                }
        }
                                         
        q=td_stoimosti_api->dbGetCursor(res,sql);

        if(q->RecordCount>0)
        {
                Create_view_pic_form(owner);

                TList *pl=new TList();
                TStringList *t_ids=new TStringList();
                TList *crcl=new TList();

                bool hint_flag=true;

                while(!q->Eof)
                {
                TSearchRec sr;
                AnsiString Path,td_id;
                td_id=q->FieldByName("td_id")->AsString;

                Path=ExtractFilePath(Application->ExeName)+"\\System\\Transdekra_Pics\\";

                st="";

                if (FindFirst(Path+td_id+".*", faAnyFile, sr) == 0)
                {
                        unsigned long *crc=new unsigned long;
                        TFileStream* fs=new TFileStream(Path+sr.Name,fmOpenRead);
                        fs->Position=0;
                        long size;
                        size=fs->Size;
                        char *buff=new char[size];
                        fs->Read(buff,size);
                        *crc=getCRC(buff,size);
                        delete []buff;
                        delete fs;

                        int j=0;
                        while(j<crcl->Count&&*((unsigned long*)(crcl->Items[j]))!=*crc)j++;

                        if(j==crcl->Count||crcl->Count==0)
                        {
                                crcl->Add(crc);
                                TcxImage *im=new TcxImage(view_pic_form);
                                im->Parent=view_pic_form;
                                im->Name="TR_Picture_"+IntToStr(pl->Count);
                                pl->Add(im);
                                t_ids->Add(q->FieldByName("td_id")->AsString);
                                im->Picture->LoadFromFile(Path+sr.Name);
                        }
                        else
                        {
                                hint_flag=false;
                        }
                               // im->Picture
                                FindClose(sr);

                }
                q->Next();
                }

                if(pl->Count==0)
                {
                        HidePicture();
                        return false;
                }

                int n_col;
                n_col=m_api->Round(sqrt(pl->Count)/100.)*100;
                int w,h,row=0,col=0;
                w=((TcxImage *)pl->Items[0])->Picture->Width+3;
                h=((TcxImage *)pl->Items[0])->Picture->Height+3;
                for(int i=0;i<pl->Count;i++)
                {
                        TcxImage *im;
                        im=(TcxImage *)pl->Items[i];
                        col=i%n_col;
                        row=i/n_col;
                        im->Left=w*col;
                        im->Top=h*row;
                        im->Height=h;
                        im->Width=w;
                        //im->Enabled=false;
                        im->Properties->PopupMenuLayout->MenuItems.Clear();

                        if(hint_flag)
                        {
                        // ��� ��� hint ���������� �����
                        TADOQuery *qq;
                        qq=td_stoimosti_api->dbGetCursor(res,"select * from td_531 where td_id='"+t_ids->Strings[i]+"'");
                        st=
                                "������ - "+qq->FieldByName("car_case_type")->AsString+" \n\r"+
                                "����������� - "+qq->FieldByName("car_modif")->AsString+" \n\r"+
                                "���-�� ������ - "+qq->FieldByName("car_doors")->AsString+" \n\r"+
                                "��������� - "+qq->FieldByName("car_engine")->AsString+" \n\r"+
                                "�������� - "+qq->FieldByName("car_engpwr")->AsString+" \n\r"+
                                "��� - "+qq->FieldByName("car_kpp")->AsString+" \n\r"+
                                "������� - "+qq->FieldByName("car_fuel")->AsString+" \n\r"+
                                "���� ������� - � "+qq->FieldByName("car_prod_start")->AsString+
                                        " �� "+(qq->FieldByName("car_prod_end")->AsString==""?
                                                        (AnsiString)"��������� �����":(AnsiString)qq->FieldByName("car_prod_end")->AsString)+" \n\r"+
                                "";
                        st=st+"\n\r\n\r\�����:\n\r";


                        TStringList * sl2=new TStringList();
                        TSysCharSet sep,w_sp;
                        sep<<';'<<',';
                        ExtractStrings(sep,w_sp,qq->FieldByName("car_options")->AsString.c_str(),sl2);

                        for(int i=0;i<sl2->Count;i++)
                        {
                                st=st+td_stoimosti_api->dbGetStringFromQuery(res,"select opt_name from td_532 where opt_id='"+sl2->Strings[i]+"'")+";   ";
                        }

                        delete sl2;

                        im->ShowHint=true;
                        im->Hint=st;
                        td_stoimosti_api->dbCloseCursor(res,qq);
                        }
                }

                delete pl;
                delete t_ids;
                delete crcl;

                view_pic_form->Show();
                Application->ProcessMessages();
                view_pic_form->Top=0;
                view_pic_form->Left=Screen->Width-view_pic_form->Width;
                Application->ProcessMessages();

                ret=true;
        }

        td_stoimosti_api->dbCloseCursor(res,q);

        return ret;
        }catch(...)
        {
                HidePicture();
                return false;
        }
}

bool Transdekra::ShowPicture(AnsiString td_id,TComponent *owner)
{
        return ShowPictures("TD_"+td_id,"",owner);
}

void Transdekra::HidePicture()
{
        if(view_pic_form)
                view_pic_FormClose(NULL,NULL);
}

void Transdekra::GenerateIni(TIniFile *inif,AnsiString f_name)
{
        inif->WriteString(f_name,"ColNameHeader","True");
        inif->WriteString(f_name,"Format","TabDelimited");

        TStringList * sl=new TStringList();
        sl->LoadFromFile(Load_path+"\\"+f_name);

        TStringList * sl2=new TStringList();

        TSysCharSet sep,w_sp;
        sep<<'\t';
        ExtractStrings(sep,w_sp,sl->Strings[0].c_str(),sl2);
        sl2->Count;

        AnsiString st;
        for(int i=0;i<sl2->Count;i++)
        {
                inif->WriteString(f_name,st.sprintf("Col%i",i+1),sl2->Strings[i]+" Char Width 255");
        }

        delete sl2;
        delete sl;
}

void Transdekra::LoadDataFromSKK(AnsiString Path,TDateTime From_Date)
{
        AnsiString st;
        Load_path=Path;
        int res;
        m_api->glDic_Create_Empty_DB(res,"����������, ���������","TRANSDEKRA");

        GetTDApi();
        if(!td_stoimosti_api)
                return;

        // ������ ���������

        // ��� ���������� � ini ������, ����� �� �����
        AnsiString  schema_ini;
        schema_ini=Path+"\\schema.ini";
        TIniFile *inf=new TIniFile(schema_ini);
        GenerateIni(inf,"531.txt");
        GenerateIni(inf,"532.txt");
        GenerateIni(inf,"533.txt");
        delete inf;

        mops_api_014* t_api=new mops_api_014();
        t_api->BuildConnectionString(res,"Text_Files","","","",Path);
        t_api->dbConnect(res);
        TADOQuery *q,*q2;

        q=t_api->dbGetCursor(res,"select * from [531.txt]");
        // ������� ��������� ��� 531
        td_stoimosti_api->dbExecuteQuery(res,"drop table td_531");
        td_stoimosti_api->dbExecuteQuery(res,"create table td_531 (mops_tmp_field_326457715 integer)");
        for(int i=0;i<q->FieldCount;i++)
                td_stoimosti_api->dbExecuteQuery(res,"alter table td_531 add column ["+q->Fields->Fields[i]->DisplayName+"] varchar(255)");
        td_stoimosti_api->dbExecuteQuery(res,"alter table td_531 drop column mops_tmp_field_326457715");
        // ��������� �������
        q2=td_stoimosti_api->dbGetCursor(res,"select * from td_531",0);
        while(!q->Eof)
        {
                q2->Insert();
                for(int i=0;i<q->Fields->Count;i++)
                        q2->Fields->Fields[i]->AsString=q->Fields->Fields[i]->AsString;
                q->Next();
        }
        q2->UpdateBatch();
        t_api->dbCloseCursor(res,q);
        td_stoimosti_api->dbCloseCursor(res,q2);

        q=t_api->dbGetCursor(res,"select * from [532.txt]");
        // ������� ��������� ��� 532
        td_stoimosti_api->dbExecuteQuery(res,"drop table td_532");
        td_stoimosti_api->dbExecuteQuery(res,"create table td_532 (mops_tmp_field_326457715 integer)");
        for(int i=0;i<q->FieldCount;i++)
                td_stoimosti_api->dbExecuteQuery(res,"alter table td_532 add column ["+q->Fields->Fields[i]->DisplayName+"] varchar(255)");
        td_stoimosti_api->dbExecuteQuery(res,"alter table td_532 drop column mops_tmp_field_326457715");
        // ��������� �������
        q2=td_stoimosti_api->dbGetCursor(res,"select * from td_532",0);
        while(!q->Eof)
        {
                q2->Insert();
                for(int i=0;i<q->Fields->Count;i++)
                        q2->Fields->Fields[i]->AsString=q->Fields->Fields[i]->AsString;
                q->Next();
        }
        q2->UpdateBatch();
        t_api->dbCloseCursor(res,q);
        td_stoimosti_api->dbCloseCursor(res,q2);

        q=t_api->dbGetCursor(res,"select * from [533.txt]");
        // ������� ��������� ��� 533

        if(m_api->vrGetVariable(res,"_mops_global_run_parameter_is_debug_")!="1")
        {
        // ����� ������������� ������ �� ��� �������, � �� exception� ���������
        td_stoimosti_api->dbExecuteQuery(res,"create table td_533 (mops_tmp_field_326457715 integer)");
        td_stoimosti_api->dbExecuteQuery(res,"alter table td_533 add column [id] integer");
        td_stoimosti_api->dbExecuteQuery(res,"alter table td_533 add column [date_s] datetime");
        td_stoimosti_api->dbExecuteQuery(res,"alter table td_533 add column [date_e] datetime");
        for(int i=0;i<q->FieldCount;i++)
                td_stoimosti_api->dbExecuteQuery(res,"alter table td_533 add column ["+q->Fields->Fields[i]->DisplayName+"] varchar(255)");
        td_stoimosti_api->dbExecuteQuery(res,"alter table td_533 drop column mops_tmp_field_326457715");
        }

        // ��������� �������
        q2=td_stoimosti_api->dbGetCursor(res,"select * from td_533",0);
        while(!q->Eof)
        {
                q2->Filtered=false;
                q2->Filter="ckk_id='"+q->FieldByName("ckk_id")->AsString+"'";
                q2->Filtered=true;

                long id;
                TDateTime ds,dp;

                if(q2->RecordCount<=0)
                {

                        id=td_stoimosti_api->dbGenerateId(res,"td_533");
                        ds=From_Date;
                        dp=0;
                }
                else
                {
                        id=q2->FieldByName("id")->AsInteger;
                        ds=q2->FieldByName("date_s")->AsDateTime;
                        dp=q2->FieldByName("date_e")->AsDateTime;
                        td_stoimosti_api->dbExecuteQuery(res,st.sprintf("delete from td_533 where [id]=%i",id));

//                        q2->Delete();
                }
                q2->Filtered=false;

                q2->Insert();
                q2->FieldByName("id")->AsInteger=id;
                q2->FieldByName("date_s")->AsDateTime=ds;
                q2->FieldByName("date_e")->AsDateTime=dp;

                for(int i=0;i<q->Fields->Count;i++)
                        q2->FieldByName(q->Fields->Fields[i]->DisplayName)->AsString=q->Fields->Fields[i]->AsString;
                q->Next();
        }
        q2->UpdateBatch();
        td_stoimosti_api->dbCloseCursor(res,q2);

        // ��� ��� ���� ������ ������ ������������ ��� �������������
        q2=td_stoimosti_api->dbGetCursor(res,"select id,date_e,ckk_id from td_533 where date_e is NULL or date_e=0",0);
        q->First();
        while(!q2->Eof)
        {
                q->Filtered=false;
                q->Filter="ckk_id='"+q2->FieldByName("ckk_id")->AsString+"'";
                q->Filtered=true;
                if(q->RecordCount<=0)
                {
                        q2->Edit();
                        q2->FieldByName("date_e")->AsDateTime=From_Date-1;
                        q2->Post();
                }
                q2->Next();
        }
        td_stoimosti_api->dbCloseCursor(res,q2);
        t_api->dbCloseCursor(res,q);
        delete t_api;
        DeleteFile(schema_ini);


}

mops_api_014* Transdekra::GetTDApi()
{
        int res;
        if(!td_stoimosti_api)
                td_stoimosti_api=(mops_api_014*)m_api->glDic_Get_API(res,"����������, ���������");
        return td_stoimosti_api;
}


bool Transdekra::GetYearsList(AnsiString RSA_ID,TStrings *out)
{
        int res;
        AnsiString st;
        out->Clear();
        if(!td_stoimosti_api)
                return false;

        RSA_ID=NolTORSA_ID(RSA_ID);

        int minyear=td_stoimosti_api->dbGetIntFromQuery(res,"SELECT min(Year(Cdate(car_prod_start)))  from td_531 where rsa_id='"+RSA_ID+"'");
        if(minyear<=1800)
                return false;

        int maxyear;
        if(td_stoimosti_api->dbGetIntFromQuery(res,"SELECT count(car_prod_end) from td_531 where (car_prod_end=NULL or car_prod_end='') and rsa_id='"+RSA_ID+"'")>0)
        {
                maxyear=YearOf(TDateTime::CurrentDate());
        }
        else
        {
                maxyear=td_stoimosti_api->dbGetIntFromQuery(res,"SELECT max(Year(Cdate(car_prod_end))) from td_531 where rsa_id='"+RSA_ID+"'");
        }

        while(minyear<=maxyear)
        {
                out->Add(st.sprintf("%i",minyear++));
        }
        return true;
}


bool Transdekra::GetPowerDelta(AnsiString RSA_ID,int &power_min,int &power_max)
{
        power_min=0;
        power_max=INT_MAX;
        int res;
        AnsiString st;
        if(!td_stoimosti_api)
                return false;

        RSA_ID=NolTORSA_ID(RSA_ID);

        power_min=td_stoimosti_api->dbGetIntFromQuery(res,"SELECT min(int(car_engpwr)) from td_531 where rsa_id='"+RSA_ID+"'");
        if(power_min<=0)
                return false;
        power_max=td_stoimosti_api->dbGetIntFromQuery(res,"SELECT max(int(car_engpwr)) from td_531 where rsa_id='"+RSA_ID+"'");
        return true;
}

bool Transdekra::GetPriceDelta(AnsiString RSA_ID,AnsiString GodVipuska,AnsiString Region,TDateTime DateRascheta,double &price_min,double &price_max)
{
        price_min=0;
        price_max=INT_MAX;
        int res;
        AnsiString st;
        if(!td_stoimosti_api)
                return false;

        RSA_ID=NolTORSA_ID(RSA_ID);

        AnsiString spr=
"SELECT %s(used_price_reg%s) from td_531 t1 "
"left join td_533 t2 on t2.td_id=t1.td_id "
"where t1.rsa_id='%s' and Year(DateValue(t2.date_prod))=%s and "
"(DateValue('%s') >= t2.date_s and DateValue('%s') <= iif(t2.date_e is null or t2.date_e=0, DATE(), t2.date_e)) ";

        price_min=
        td_stoimosti_api->dbGetFloatFromQuery(res,st.sprintf(spr.c_str(),"min",Region,RSA_ID,GodVipuska,DateRascheta.DateString(),DateRascheta.DateString()));
        if(price_min<=0)
                return false;

        price_max=
        td_stoimosti_api->dbGetFloatFromQuery(res,st.sprintf(spr.c_str(),"max",Region,RSA_ID,GodVipuska,DateRascheta.DateString(),DateRascheta.DateString()));

        return true;
}

bool Transdekra::CheckPrice(AnsiString RSA_ID,AnsiString GodVipuska,AnsiString Region,TDateTime DateRascheta,double price,bool &Result)
{
        double pmi,pma;
        bool ret;
        ret=GetPriceDelta(RSA_ID,GodVipuska,Region,DateRascheta,pmi,pma);

        Result=false;
        int rpocent=10;
        if(ret)
        {
                pmi*=(1.-rpocent/100.);
                pma*=(1.+rpocent/100.);

                Result=(pmi<=price&&price<=pma);
        }

        return ret;
}

#pragma package(smart_init)
