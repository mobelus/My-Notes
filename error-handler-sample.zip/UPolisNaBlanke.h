//---------------------------------------------------------------------------

#ifndef UPolisNaBlankeH
#define UPolisNaBlankeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <QRCtrls.hpp>
#include <QuickRpt.hpp>
#include <jpeg.hpp>
#include "TMops_api.h"
//---------------------------------------------------------------------------
class TRPolisNaBlanke : public TForm
{
__published:	// IDE-managed Components
        TQuickRep *QR;
        TQRBand *QRBand1;
        TQRLabel *QRLabel01;
        TQRLabel *QRLabel02;
        TQRLabel *QRLabel03;
        TQRLabel *QRLabel04;
        TQRLabel *QRLabel05;
        TQRLabel *QRLabel08;
        TQRLabel *QRLabel07;
        TQRLabel *QRLabel06;
        TQRLabel *QRLabel27;
        TQRLabel *QRLabel28;
        TQRLabel *QRLabel09;
        TQRLabel *QRLabel10;
        TQRLabel *QRLabel11;
        TQRLabel *QRLabel12;
        TQRLabel *QRLabel13;
        TQRLabel *QRLabel14;
        TQRLabel *QRLabel15;
        TQRLabel *QRLabel16;
        TQRLabel *QRLabel17;
        TQRLabel *QRLabel18;
        TQRLabel *QRLabel19;
        TQRLabel *QRLabel20;
        TQRLabel *QRLabel21;
        TQRLabel *QRLabel22;
        TQRLabel *QRLabel23;
        TQRLabel *QRLabel26;
        TQRLabel *QRLabel25;
        TQRLabel *QRLabel24;
        TQRLabel *QRLabel29;
        TQRLabel *VIN1;
        TQRLabel *QRLabel31;
        TQRLabel *QRLabel32;
        TQRLabel *QRLabel33;
        TQRLabel *QRLabel34;
        TQRLabel *QRLabel35;
        TQRLabel *QRLabel36;
        TQRLabel *QRLabel37;
        TQRLabel *QRLabel38;
        TQRLabel *QRLabel39;
        TQRLabel *QRLabel40;
        TQRLabel *QRLabel41;
        TQRLabel *QRLabel42;
        TQRLabel *QRLabel43;
        TQRLabel *QRLabel44;
        TQRLabel *QRLabel45;
        TQRLabel *QRLabel46;
        TQRLabel *QRLabel47;
        TQRLabel *QRLabel48;
        TQRLabel *QRLabel49;
        TQRLabel *QRLabel50;
        TQRLabel *QRLabel51;
        TQRLabel *QRLabel52;
        TQRLabel *QRLabel53;
        TQRLabel *QRLabel54;
        TQRLabel *QRLabel55;
        TQRLabel *QRLabel56;
        TQRLabel *QRLabel57;
        TQRLabel *QRLabel58;
        TQRLabel *QRLabel59;
        TQRLabel *QRLabel60;
        TQRLabel *VIN2;
        TQRLabel *VIN3;
        TQRLabel *VIN4;
        TQRLabel *VIN5;
        TQRLabel *VIN6;
        TQRLabel *VIN7;
        TQRLabel *VIN8;
        TQRLabel *VIN9;
        TQRLabel *VIN10;
        TQRLabel *VIN11;
        TQRLabel *VIN12;
        TQRLabel *VIN13;
        TQRLabel *VIN14;
        TQRLabel *VIN15;
        TQRLabel *VIN16;
        TQRLabel *VIN17;
private:	// User declarations
   AnsiString AddSpases(AnsiString st, int num);
   double GetKbm(AnsiString klass, bool inostr_gosvo,  AnsiString inostr_gosvo_t);
public:		// User declarations
   __fastcall TRPolisNaBlanke(TComponent* Owner);
   void Print_Form(long calc_id,bool Preview);
   mops_api_014* m_api;
};
//---------------------------------------------------------------------------
extern PACKAGE TRPolisNaBlanke *RPolisNaBlanke;
//---------------------------------------------------------------------------
#endif
