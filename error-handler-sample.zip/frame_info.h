//---------------------------------------------------------------------------


#ifndef frame_infoH
#define frame_infoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxMemo.hpp"
#include "cxRichEdit.hpp"
#include "cxTextEdit.hpp"
#include "frxClass.hpp"
#include "frxPreview.hpp"
//---------------------------------------------------------------------------
class TInfo : public TFrame
{
__published:	// IDE-managed Components
    TfrxReport *frxReport1;
    TfrxPreview *frxPreview1;
private:	// User declarations
public:		// User declarations
    __fastcall TInfo(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TInfo *Info;
//---------------------------------------------------------------------------
#endif
