//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "UZayav2.h"
#include "tools.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//#pragma link "dxGDIPlusClasses"
#pragma resource "*.dfm"
TRZayav2 *RZayav2;
//---------------------------------------------------------------------------
__fastcall TRZayav2::TRZayav2(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TRZayav2::Print_Form(long calc_id, bool Preview)
{
   int res;
   TADOQuery *qw = m_api->dbGetCursor(res, "select * from OSAGO_R_main where calc_id=" + IntToStr(calc_id));
   if(!qw->IsEmpty()){

      QRLabel88->Caption =(qw->FieldByName("calc_dopusk_bez_ogran")->AsBoolean ? "X" : " ");
      QRLabel89->Caption = (!qw->FieldByName("calc_dopusk_bez_ogran")->AsBoolean ? "X" : " ");

      if(qw->FieldByName("pol_zayav_dop_tolko_sled_voditeli")->AsBoolean){
         TADOQuery *qw_du = m_api->dbGetCursor(res,"select * from osago_r_dop_k_upr where calc_id=" + IntToStr(calc_id) + " order by num_dop_upr");
         for(int i = 0; i < 5; i++){
            TQRLabel *qr_fio, *qr_dr, *qr_sex, *qr_vu, *qr_stag, *qr_avar, *qr_klass;
            AnsiString fio, dr, sex, vu, stag, avar, klass;
            switch(i){
               case 0:
                  qr_fio=QRLabel90;qr_dr=QRLabel96;qr_sex=QRLabel102;qr_vu=QRLabel108;qr_stag=QRLabel114;qr_avar=QRLabel148;qr_klass=QRLabel120;
                  break;
               case 1:
                  qr_fio=QRLabel91;qr_dr=QRLabel97;qr_sex=QRLabel103;qr_vu=QRLabel109;qr_stag=QRLabel115;qr_avar=QRLabel149;qr_klass=QRLabel121;
                  break;
               case 2:
                  qr_fio=QRLabel92;qr_dr=QRLabel98;qr_sex=QRLabel104;qr_vu=QRLabel110;qr_stag=QRLabel116;qr_avar=QRLabel150;qr_klass=QRLabel122;
                  break;
               case 3:
                  qr_fio=QRLabel93;qr_dr=QRLabel99;qr_sex=QRLabel105;qr_vu=QRLabel111;qr_stag=QRLabel117;qr_avar=QRLabel151;qr_klass=QRLabel123;
                  break;
               case 4:
                  qr_fio=QRLabel94;qr_dr=QRLabel100;qr_sex=QRLabel106;qr_vu=QRLabel112;qr_stag=QRLabel118;qr_avar=QRLabel152;qr_klass=QRLabel124;
                  break;
            }
            if(!qw_du->Eof){
               fio=qw_du->FieldByName("f")->AsString + " " +qw_du->FieldByName("i")->AsString + " " + qw_du->FieldByName("o")->AsString;
               fio=(Trim(fio).IsEmpty() ? AnsiString("-------------------------------------------------------------"):fio);
               dr=(qw_du->FieldByName("data_rogd")->AsString.IsEmpty()?AnsiString("----------------------"):qw_du->FieldByName("data_rogd")->AsString);
               sex=(qw_du->FieldByName("sex")->AsString.IsEmpty()?AnsiString("----"):qw_du->FieldByName("sex")->AsString);
               vu=qw_du->FieldByName("prava_s")->AsString + " " +qw_du->FieldByName("prava_n")->AsString;
               vu=(Trim(vu).IsEmpty()?AnsiString("------------------------------"):vu);
               stag=(qw_du->FieldByName("stag")->AsString.IsEmpty()?AnsiString("--------------"):qw_du->FieldByName("stag")->AsString);
                AnsiString a = (StrToIntDef(qw_du->FieldByName("avar")->AsString, 0) == 0 ? AnsiString("���") : qw_du->FieldByName("avar")->AsString);
               avar=(qw_du->FieldByName("avar")->AsString.IsEmpty()?AnsiString("------------"):a);
               klass=(qw_du->FieldByName("kbm")->AsString.IsEmpty()?AnsiString("--------------"):qw_du->FieldByName("kbm")->AsString);
               qw_du->Next();
            }
            else{
               fio=fio.StringOfChar('-',61 );dr=dr.StringOfChar('-',22);sex=sex.StringOfChar('-',4);vu=vu.StringOfChar('-',30);
               stag=stag.StringOfChar('-',12);avar=avar.StringOfChar('-',14); klass=klass.StringOfChar('-',13);
            }
            qr_fio->Caption=fio;qr_dr->Caption=dr;qr_sex->Caption=sex; qr_vu->Caption=vu;qr_stag->Caption=stag;qr_avar->Caption=avar;qr_klass->Caption=klass;
         }
         m_api->dbCloseCursor(res,qw_du);
      }
      else{
         QRLabel90->Caption = "";
         QRLabel91->Caption = "";
         QRLabel92->Caption = "";
         QRLabel93->Caption = "";
      QRLabel94->Caption = "";
      QRLabel96->Caption = "";
      QRLabel97->Caption = "";
      QRLabel98->Caption = "";
      QRLabel99->Caption = "";
      QRLabel100->Caption = "";
      QRLabel102->Caption = "";
      QRLabel103->Caption = "";
      QRLabel104->Caption = "";
      QRLabel105->Caption = "";
      QRLabel106->Caption = "";
      QRLabel108->Caption = "";
      QRLabel109->Caption = "";
      QRLabel110->Caption = "";
      QRLabel111->Caption = "";
      QRLabel112->Caption = "";
      QRLabel114->Caption = "";
      QRLabel115->Caption = "";
      QRLabel116->Caption = "";
      QRLabel117->Caption = "";
      QRLabel118->Caption = "";
      QRLabel120->Caption = "";
      QRLabel121->Caption = "";
      QRLabel122->Caption = "";
      QRLabel123->Caption = "";
      QRLabel124->Caption = "";
      QRLabel148->Caption = "";
      QRLabel149->Caption = "";
      QRLabel150->Caption = "";
      QRLabel151->Caption = "";
      QRLabel152->Caption = "";
      }

      QRLabel14->Caption =qw->FieldByName("pol_zayav_pred_pol_num")->AsString;
      QRLabel13->Caption =qw->FieldByName("pol_zayav_pred_pol_ser")->AsString;
      QRLabel16->Caption = qw->FieldByName("pol_zayav_pred_pol_SK")->AsString;

      QRLabel27->Caption = "� " + qw->FieldByName("pol_zayav_per_isp_1_s")->AsString  + " �� " + qw->FieldByName("pol_zayav_per_isp_1_po")->AsString;
      if(!qw->FieldByName("pol_zayav_per_isp_2_s")->AsString.IsEmpty() && !qw->FieldByName("pol_zayav_per_isp_2_po")->AsString.IsEmpty())
         QRLabel9->Caption = "� " + qw->FieldByName("pol_zayav_per_isp_2_s")->AsString + " �� " + qw->FieldByName("pol_zayav_per_isp_2_po")->AsString;
      else QRLabel9->Caption ="";

      if(!qw->FieldByName("pol_zayav_per_isp_3_s")->AsString.IsEmpty() && !qw->FieldByName("pol_zayav_per_isp_3_po")->AsString.IsEmpty())
         QRLabel10->Caption = "� " + qw->FieldByName("pol_zayav_per_isp_3_s")->AsString + " �� " + qw->FieldByName("pol_zayav_per_isp_3_po")->AsString;
      else QRLabel10->Caption ="";

      QRLabel20->Caption = "";
      QRLabel126->Caption = qw->FieldByName("pol_zayav_pol_ser")->AsString;;
      QRLabel127->Caption = qw->FieldByName("pol_zayav_pol_num")->AsString;
      QRLabel132->Caption = qw->FieldByName("fio_rgs_pred_i")->AsString;

      QRLabel130->Caption =  qw->FieldByName("pol_zayav_strah_f")->AsString + " " + qw->FieldByName("pol_zayav_strah_i")->AsString + " " + qw->FieldByName("pol_zayav_strah_o")->AsString;//qw->FieldByName("pol_zayav_strah_fio")->AsString;
      QRLabel131->Caption = qw->FieldByName("pol_zayav_date_zayav")->AsString;
      QRLabel133->Caption = qw->FieldByName("pol_zayav_date_zayav")->AsString;;

      QRMemo1->Lines->Text = "";
      if(qw->FieldByName("calc_sled_k_mr")->AsBoolean) QRMemo1->Lines->Text += "����������� �� ���� ���������� � ����� ����������� ��\r\n";
      if(qw->FieldByName("calc_inostr_gosvo")->AsBoolean) QRMemo1->Lines->Text += "�� ���������������� � ����������� ����������� (" + qw->FieldByName("calc_in_gosvo_t")->AsString + ")\r\n";
      QRMemo1->Lines->Text += qw->FieldByName("pol_zayav_osob_otmet")->AsString;

      QRLabel134->Caption = qw->FieldByName("calc_bs")->AsString;
      QRLabel135->Caption = qw->FieldByName("calc_kt")->AsString;
      QRLabel136->Caption = qw->FieldByName("calc_kbm2")->AsString;
      QRLabel137->Caption = FormatFloat("#,##0.00", StrToFloat(StrToFloatStr(qw->FieldByName("calc_ko")->AsString)) * StrToFloat(StrToFloatStr(qw->FieldByName("calc_kvs")->AsString)));
      QRLabel138->Caption = qw->FieldByName("calc_ks")->AsString;
      QRLabel139->Caption = qw->FieldByName("calc_kp")->AsString;
      QRLabel140->Caption = qw->FieldByName("calc_km")->AsString;
      QRLabel141->Caption = qw->FieldByName("calc_kn")->AsString;
      QRLabel142->Caption = qw->FieldByName("calc_prem")->AsString;
   }

   m_api->dbCloseCursor(res, qw);

   if(!Preview) QR->Print();
   else         QR->Preview();
}
//---------------------------------------------------------------------------

