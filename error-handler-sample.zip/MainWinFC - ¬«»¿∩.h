//---------------------------------------------------------------------------
#ifndef MainWinFCH
#define MainWinFCH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <DB.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
#include <DB.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include <Buttons.hpp>
#include <oxmldom.hpp>
#include <XMLDoc.hpp>
#include <xmldom.hpp>
#include <XMLIntf.hpp>
#include <msxmldom.hpp>
#include "Tmops_api.h"
#include "tools.h"
#include "Ulicard.h"
#include "BlackListKit.h"

#include "vozvrat.h"

#include "sCurrEdit.hpp"
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include "sComboBox.hpp"
#include "acHeaderControl.hpp"
#include "sEdit.hpp"
#include "sCheckBox.hpp"
#include <Graphics.hpp>
#include "sFrameBar.hpp"
#include "sScrollBox.hpp"
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxDropDownEdit.hpp"
#include "cxEdit.hpp"
#include "cxGraphics.hpp"
#include "cxMaskEdit.hpp"
#include "cxTextEdit.hpp"
#include <ActnList.hpp>
#include <memory>
#include "Project_.h"

#define PR "������ ����������"

//const short ENABLE_FORTUNA =  0; // Do NOT Forget to change it also in UCalc.h
#define ENABLE_FORTUNA          1  // Do NOT Forget to change it also in UCalc.h
#define ENABLE_GRBOX_OWNER_PREV 0


enum DB_PAYMENT_TYPE
{
	DB_PAYMENT_NAL = 1,
	DB_PAYMENT_BEZNAL = 3,
};

enum DB_PAYMENT_DOC_TYPE
{
	DB_PAYDOC_PROURATORY   = 2,
	DB_PAYDOC_OTHER_DOC    = 5,
	DB_PAYDOC_INSUR_ACT    = 9,
	DB_PAYDOC_QUITTANCE_A7 = 10,
	DB_PAYDOC_PAYBACK      = 11,
	DB_PAYDOC_DIGITAL_CHECK= 14,
};

enum DB_SALE_CHANEL
{
	DB_SLCNL_AGENTS_SALES = 120,
	DB_SLCNL_AGENTS_NEW_FORMAT = 122,
	DB_SLCNL_TRANSFER_PARTNER_SALES_TO_OFFICES = 139,
};




class Transdekra;
//---------------------------------------------------------------------------
class TFrame1 : public TFrame
{
__published:	// IDE-managed Components
   TGroupBox *gbInsured;
    TRadioButton *RBInsFiz;
    TCheckBox *ip_strah;
    TRadioButton *RBInsJur;
    TCheckBox *SMSSending;
    TButton *Button2;
    TsEdit *EInsNameYur; // underneath
    TsEdit *EStrachF;
    TsEdit *EStrachI;
    TsEdit *EStrachO;
    TsComboBox *CBStrachSex;
    TPanel *Panel1;
     TsComboBox *EInsDocName;
     TsEdit *EInsDocSeria;
     TsEdit *EInsDocNumber;
     TsEdit *EInsDocVidan;
     TsDateEdit *DEInsBirtday;
     TsEdit *EInsINN;
     TsDateEdit *DEInsDocDate;
     TsComboBox *cbInsGrajdanstvo;
     TsEdit *EInsPhone;
     TsEdit *EInsPhone2;
     TsEdit *EInsIndex;
     TsEdit *EInsGos;
     TsEdit *EInsRegion;
     TsEdit *EInsRaion;
     TsEdit *EInsCity;
     TsEdit *EInsStreet;
     TsEdit *EInsHouse;
     TsEdit *EInsPart;
     TsEdit *EInsKV;
     TPanel *Panel4;
      TButton *KladrButton1;
   TGroupBox *gbContacts;
    TsEdit *EInsPhone3Code;
    TsEdit *EInsPhone3;
    TsCheckBox *chkNoContacts;
    TsEdit *EInsEmail;
   TGroupBox *gbOwner;
    TRadioButton *RBOwnFiz;
    TRadioButton *RBOwnJur;
    TsEdit *EOwnNameYur;
    TButton *Button1;
   TGroupBox *gbPermitted;
    TRadioButton *RBAnyVod;
    TRadioButton *RBBezOgrVod;
    TRadioGroup *RGDUKol;
   TGroupBox *gbDogovor;
    TLabel *Label62;
    TLabel *Label63;
    TsEdit *EPolNum;
    TsEdit *EPRPolNum;
    TLabel *Label69;
    TLabel *Label70;
    TLabel *Label71;
    TLabel *Label72;
    TMemo *MOsOtm;
    TsDateEdit *DEZDate;
    TsComboBox *EPolSer;
    TsComboBox *EPRPolSer;
    TsComboBox *CBPayment;
    TsComboBox *CBPaymentDoc;
    TsComboBox *CBOwnSex;
    TsEdit *EOwnO;
    TsEdit *EOwnI;
    TsEdit *EOwnF;
    TsEdit *FilialName;
    TsEdit *EPPSer;
    TsEdit *EPPNum;
    TsDateEdit *EPPDate;
    TsComboBox *EPRStrah;
   TGroupBox *gbOthers;
    TsComboBox *CBAutodealer;
    TsComboBox *CBBank;
    TsComboBox *CBOtherPartner;
    TCheckBox *CBPartnerAnaliz;
    TsHeaderControl *HCDop;
    TStringGrid *SGDop;
    TButton *B1_1;
    TButton *B2_1;
    TButton *B1_2;
    TButton *B2_2;
    TsEdit *EditDop;
    TsDateEdit *DEDop;
    TsComboBox *CBAvar;
    TsComboBox *CBSex;
    TLabel *labSaleChannel;
    TTreeView *tvSaleChannel;
    //TPanel *Panel1;
    TLabel *Label11;
    TLabel *Label10;
    TLabel *Label12;
    TLabel *Label13;
    TLabel *Label14;
   TGroupBox *gbVehicle;
    TLabel *Label48;
    TLabel *Label49;
    TLabel *Label50;
    TLabel *Label83;
    TLabel *Label84;
    TLabel *Label85;
    TsComboBox *CBCatTS;
    TsEdit *EShassiTS;
    TsEdit *EKuzovTS;
    TsEdit *ETSPassSeria;
    TsEdit *ETSPassNumber;
    TsDateEdit *DETSPassDate;
    TCheckBox *CBArendaTS;
    TCheckBox *ShowPics;
    TsComboBox *ETSDocType;
    TsEdit *editTehOsmortSer;
    TsEdit *editTehOsmortNum;
    TsComboBox *cboxTehOsmortMonth;
    TsComboBox *cboxTehOsmortYear;
    TPanel *Panel2;
    TsComboBox *EOwnDocName;
    TsEdit *EOwnDocSeria;
    TsEdit *EOwnDocNumber;
    TsDateEdit *DEOwnBirtday;
    TsEdit *EOwnINN;
    TsEdit *EOwnPhone;
    TsEdit *EOwnPhone2;
    TsEdit *EOwnPhone3;
    TsEdit *EOwnIndex;
    TsEdit *EOwnGos;
    TsEdit *EOwnRegion;
    TsEdit *EOwnRaion;
    TsEdit *EOwnStreet;
    TsEdit *EOwnCity;
    TsEdit *EOwnHouse;
    TsEdit *EOwnPart;
    TsEdit *EOwnKV;
    TLabel *Label8;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
   TGroupBox *gbOwnerPrev;
    TsEdit *EOwnPrevO;
    TsEdit *EOwnPrevI;
    TsEdit *EOwnPrevF;
    TsComboBox *EOwnPrevDocName;
    TsEdit *EOwnPrevDocSeria;
    TsEdit *EOwnPrevDocNumber;
   TGroupBox *GroupBox1;
    TsDateEdit *DEInsBDate;
    TsDateEdit *DEInsEDate;
   TGroupBox *gbPeriods;
    TsDateEdit *DEBPI1;
    TsDateEdit *DEEPI1;
    TCheckBox *CBTwoPS;
    TsDateEdit *DEBPI2;
    TsDateEdit *DEEPI2;
    TCheckBox *CB3PS;
    TsDateEdit *DEBPI3;
    TsDateEdit *DEEPI3;
    TLabel *Label7;
    TLabel *Label9;
    TCheckBox *chkTO;
    TLabel *labInfo;
   TGroupBox *gbFortuna;
    TsEdit *editPolisNumber;
    TsEdit *editPrevSeria;
    TsEdit *editPrevNumber;
    TsComboBox *cbDogovorType;
    TsDateEdit *datePrevDog;
    TCheckBox *CboxFortuna;
    TsEdit *editGroupSales;
    TsComboBox *cbNStypeblank;
    TsComboBox *cbNSPayment;
    TsComboBox *cbNSpaymentdoc;
    TsEdit *eNSPPSer;
    TsEdit *eNSPPNum;
    TsDateEdit *eNSPPDate;
    TsDateEdit *eNSbeznaldate;
    TLabel *Label15;
    TsEdit *EIndNumberTS;
    TCheckBox *cbtsgosreg;
    TsDateEdit *DatePereoforml;
    TsComboBox *cbOTO;
    TButton *btncheckbso;
    TButton *Button3;
    TButton *Button4;
    TButton *Button5;
   TGroupBox *GroupBox2;
    TsEdit *sEdit1;
    TPanel *Panel3;
    TButton *KladrButton2;
    TsComboBox *ns_ser;
    TLabel *Label16;
    TsEdit *code_autch;
    TsDateEdit *data_autch;
    TsDateEdit *fa_data_autch;
    TsEdit *fa_code_autch;
    TLabel *Label19;
    TLabel *Label20;
    TsMaskEdit *EZnakTS;
    TCheckBox *RUS;
    TCheckBox *ip_sobstv;
    TsFrameBar *sFrameBarMainWinFC;
    TLabel *_LabelToScrollFrameBar;
    TsDateEdit *DEOwnDocDateEnd;
    TsDateEdit *DEOwnDocDate;
    TLabel *Label17;
    TLabel *lbl1;
    TsComboBox *CBNewBlankType;
    TcxComboBox *CXCBNewBlankType;
    TActionList *ActionList1;
    TButton *btn1;
    TsComboBox *CBBlankType;
   void __fastcall RBInsFizClick(TObject *Sender);
   void __fastcall RBOwnJurClick(TObject *Sender);
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall Button2Click(TObject *Sender);
   void __fastcall EInsNameYurChange(TObject *Sender);
   void __fastcall RBAnyVodClick(TObject *Sender);
   void __fastcall RBBezOgrVodClick(TObject *Sender);
   void __fastcall CBTwoPSClick(TObject *Sender);
   void __fastcall B1_1Click(TObject *Sender);
   void __fastcall B1_2Click(TObject *Sender);
   void __fastcall B2_1Click(TObject *Sender);
   void __fastcall B2_2Click(TObject *Sender);
   void __fastcall CB3PSClick(TObject *Sender);
   void __fastcall DEZDateChange(TObject *Sender);
   void __fastcall CBPaymentChange(TObject *Sender);
   void __fastcall KladrButton1Click(TObject *Sender);
   void __fastcall DEInsEDateChange(TObject *Sender);
   void __fastcall ShowPicsClick(TObject *Sender);
   void __fastcall CBPaymentDocChange(TObject *Sender);
   void __fastcall CBPartnerAnalizClick(TObject *Sender);
   void __fastcall SGDopSelectCell(TObject *Sender, int ACol, int ARow, bool &CanSelect);
   void __fastcall EditDopExit(TObject *Sender);
   void __fastcall EditDopKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall DEDopKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall CBAvarKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
   void __fastcall EPolNumChange(TObject *Sender);
   void __fastcall EPolNumKeyPress(TObject *Sender, char &Key);
   void __fastcall EInsPhoneKeyPress(TObject *Sender, char &Key);
   void __fastcall tvSaleChannelChange(TObject *Sender, TTreeNode *Node);
   void __fastcall chkTOClick(TObject *Sender);
   void __fastcall EInsPhone3CodeChange(TObject *Sender);
   void __fastcall DEBPI1Change(TObject *Sender);
   void __fastcall chkNoContactsClick(TObject *Sender);
   void __fastcall EOwnFChange(TObject *Sender);
   void __fastcall EOwnNameYurChange(TObject *Sender);
   void __fastcall EInsINNChange(TObject *Sender);
   void __fastcall EZnakTS2Change(TObject *Sender);
   void __fastcall EIndNumberTSChange(TObject *Sender);
   void __fastcall EShassiTSChange(TObject *Sender);
   void __fastcall EKuzovTSChange(TObject *Sender);
   void __fastcall CboxFortunaClick(TObject *Sender);
   void __fastcall cbDogovorTypeChange(TObject *Sender);
   void __fastcall cbNStypeblankChange(TObject *Sender);
   void __fastcall editPolisNumberChange(TObject *Sender);
   void __fastcall cbNSPaymentChange(TObject *Sender);
   void __fastcall cbNSpaymentdocChange(TObject *Sender);
   void __fastcall eNSPPDateChange(TObject *Sender);
   void __fastcall EMarka2Change(TObject *Sender);
   void __fastcall EModel2Change(TObject *Sender);
   void __fastcall EIndNumberTSKeyPress(TObject *Sender, char &Key);
   void __fastcall EZnakTS2KeyPress(TObject *Sender, char &Key);
   void __fastcall cbtsgosregClick(TObject *Sender);
   void __fastcall cbInsGrajdanstvoChange(TObject *Sender);
   void __fastcall EZnakTS2Exit(TObject *Sender);
   void __fastcall EIndNumberTSExit(TObject *Sender);
   void __fastcall cbOTOChange(TObject *Sender);
   void __fastcall DatePereoformlChange(TObject *Sender);
   void __fastcall btncheckbsoClick(TObject *Sender);
   void __fastcall datePrevDogChange(TObject *Sender);
   void __fastcall ns_serChange(TObject *Sender);
   void __fastcall EOwnDocSeriaKeyPress(TObject *Sender, char &Key);
    void __fastcall EInsEmailChange(TObject *Sender);
    void __fastcall CBBlankTypeChange(TObject *Sender);
        void __fastcall RUSClick(TObject *Sender);
    void __fastcall EShassiTSKeyPress(TObject *Sender, char &Key);
    void __fastcall EInsDocSeriaExit(TObject *Sender);
    void __fastcall EOwnDocSeriaExit(TObject *Sender);
    void __fastcall DEInsBDateChange(TObject *Sender);
    void __fastcall EKuzovTSExit(TObject *Sender);
    void __fastcall editTehOsmortSerExit(TObject *Sender);
    void __fastcall ip_strahClick(TObject *Sender);
    void __fastcall ip_sobstvClick(TObject *Sender);
    void __fastcall EStrachFChange(TObject *Sender);
        void __fastcall SMSSendingClick(TObject *Sender);
        void __fastcall CBStrachSexChange(TObject *Sender);
        void __fastcall ETSDocTypeChange(TObject *Sender);
        void __fastcall DEInsDocDateChange(TObject *Sender);
        void __fastcall DETSPassDateChange(TObject *Sender);
        void __fastcall CBAutodealerClick(TObject *Sender);
        void __fastcall CBBankClick(TObject *Sender);
        void __fastcall CBOtherPartnerClick(TObject *Sender);
        void __fastcall CBOwnSexChange(TObject *Sender);
        void __fastcall EPPDateChange(TObject *Sender);
        void __fastcall EPPSerChange(TObject *Sender);
        void __fastcall EInsDocNameChange(TObject *Sender);
        void __fastcall EOwnDocNameChange(TObject *Sender);
        void __fastcall DEIChange(TObject *Sender);
        void __fastcall EditExitForBlackList(TObject *Sender);
        void __fastcall DEEPI1Change(TObject *Sender);
    void __fastcall EInsNameYurKeyPress(TObject *Sender, char &Key);
    void __fastcall EOwnNameYurKeyPress(TObject *Sender, char &Key);
    void __fastcall EInsDocVidanKeyPress(TObject *Sender, char &Key);
    void __fastcall FrameCanResize(TObject *Sender, int &NewWidth,
          int &NewHeight, bool &Resize);
    void __fastcall FrameResize(TObject *Sender);
    //////////////////////////////////////////////
    void __fastcall DEInsDocDateEndChange(TObject *Sender);
    void __fastcall CBNewBlankTypeChange(TObject *Sender);
    void __fastcall CXCBNewBlankTypePropertiesChange(TObject *Sender);
    void __fastcall btn1Click(TObject *Sender);

private:	// User declarations
   //TADOQuery *q;
   int osob_otmet_memoid;
   TProject *pr, *program;
   Set <char, '0', '9'> s1;
   typedef pair<int, AnsiString> Kanal;
   typedef multimap<int, Kanal> Kanals;
   Kanals mmap;
   TDateTime calc_date;
   int res, ins_mid, owner_mid, increase_srok, old_sale_channel_id;
   bool can;
   int checkbso[4];

private:
   void LoadTypeDoc(TCustomComboBox *cb, bool yur_lico);
   void LoadTree(TTreeView *tree, TTreeNode *node, int parent_id);
   void SetGroupBoxes();
   //void setFrameBarMaxSize(TsFrameBar *innerFrameBar); // ������������� ��� �������� ������ ���������, ������� �� ������� ����� ������, � ������������� ������ ��������� = ������� ����� �������� + ��� ������
   void setFrameBarMaxSize(); // ������������� ��� �������� ������ ���������, ������� �� ������� ����� ������, � ������������� ������ ��������� = ������� ����� �������� + ��� ������
   int DiffYear(const TDateTime& dat);
public:		// User declarations
   TWndMethod EditDopOldWndProc, DEDopOldWndProc, CBSexOldWndProc, CBAvarOldWndProc;
   mops_api_032 *m_api;
   TRichEdit *memo, *hint;
   TFrame *calc_frame;
   TFrame *licard;
   Transdekra *td;
   TVozvratForm *frame_vozvrat;
   int sobstv_country_id,strah_country_id;

   std::auto_ptr<TStringList> ins_addr, owner_addr;
   int Kbm, Period, Srok, StopRecalc;
   bool project_in_print, program_in_print,period2;
   AnsiString id_product, id_product_fisik, id_product_yurik, id_region;
   AnsiString code_federation, region_for_oto;
//�������� ��
/*   typedef pair<AnsiString, TObject*> OTO;
   typedef multimap<int, OTO> OTOs;
   OTOs oto_mmap;
   TADOQuery *q_oto;
   AnsiString operator_to;
   void LoadOTO(TTreeView *tree, TTreeNode *node, int parent_id);
*/
private:
    int ChangeBlankIndex;
    int ChangeNStypeblankIndex;
    int ChangeNsSerIndex;

protected:
    void CheckInBlackList(BlackListCheckType blct);
   
public:
   __fastcall TFrame1(TComponent* Owner);
   void InitForm();
   void EnableControl(TWinControl* cont);
   void ShowPictures();
   void SaveFrame(long calc_id);
   void LoadFrame(long id_calc);
   void SetIncrease(const int& v)
   {
        increase_srok = v; DEZDateChange(DEInsBDate);
   }
   void SetDopPeriod(int mes);
   void setvozvrat();
   void setpereoformlenie();
   void __fastcall Recalc();
   void __fastcall EditDopNewWndProc(Messages::TMessage &Msg);
   void __fastcall DEDopNewWndProc(Messages::TMessage &Msg);
   void __fastcall CBSexNewWndProc(Messages::TMessage &Msg);
   void __fastcall CBAvarNewWndProc(Messages::TMessage &Msg);

   __fastcall ~TFrame1()
   {
//        m_api->dbCloseCursor(res, q_oto);
         MYGLOBAL::openToPereoform = false;
   }
};
//---------------------------------------------------------------------------
extern PACKAGE TFrame1 *Frame1;
//---------------------------------------------------------------------------
#endif
