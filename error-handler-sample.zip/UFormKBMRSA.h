//---------------------------------------------------------------------------

#ifndef UFormKBMRSAH
#define UFormKBMRSAH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "kbm_of_rsa.h"

//---------------------------------------------------------------------------
class TFKBMRSA : public TForm
{
__published:	// IDE-managed Components
        TPageControl *PageControl1;
        TTabSheet *TabSheet1;
        TTabSheet *TabSheet2;
        TRadioGroup *RadioGroup1;
        TPageControl *PageControl2;
        TTabSheet *TabSheet3;
        TTabSheet *TabSheet4;
        TEdit *Edit5;
        TLabel *Label7;
        TLabel *Label8;
        TEdit *Edit6;
        TLabel *Label9;
        TEdit *Edit7;
        TLabel *Label10;
        TEdit *Edit8;
        TEdit *Edit9;
        TLabel *Label11;
        TDateTimePicker *DateTimePicker2;
        TLabel *Label12;
        TGroupBox *GroupBox3;
        TComboBox *ComboBox1;
        TLabel *Label13;
        TEdit *Edit10;
        TLabel *Label14;
        TEdit *Edit11;
        TPanel *Panel1;
        TPanel *Panel2;
        TLabel *Label19;
        TDateTimePicker *DateTimePicker3;
        TButton *Button1;
        TButton *Button2;
        TTabSheet *TabSheet5;
        TEdit *Edit15;
        TLabel *Label18;
        TLabel *Label17;
        TLabel *Label16;
        TEdit *Edit14;
        TEdit *Edit13;
        TEdit *Edit12;
        TLabel *Label15;
        TTabControl *TabControl1;
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *ELastName;
        TEdit *Edit1;
        TEdit *Edit2;
        TDateTimePicker *DateTimePicker1;
        TGroupBox *GroupBox2;
        TLabel *Label5;
        TLabel *Label6;
        TEdit *Edit3;
        TEdit *Edit4;
        void __fastcall Edit5Change(TObject *Sender);
        void __fastcall Edit6Change(TObject *Sender);
        void __fastcall Edit7Change(TObject *Sender);
        void __fastcall Edit8Change(TObject *Sender);
        void __fastcall Edit9Change(TObject *Sender);
        void __fastcall DateTimePicker2Change(TObject *Sender);
        void __fastcall ComboBox1Change(TObject *Sender);
        void __fastcall Edit10Change(TObject *Sender);
        void __fastcall Edit11Change(TObject *Sender);
        void __fastcall Edit12Change(TObject *Sender);
        void __fastcall Edit13Change(TObject *Sender);
        void __fastcall Edit14Change(TObject *Sender);
        void __fastcall Edit15Change(TObject *Sender);
        void __fastcall DateTimePicker3Change(TObject *Sender);
        void __fastcall ELastNameChange(TObject *Sender);
        void __fastcall Edit1Change(TObject *Sender);
        void __fastcall Edit2Change(TObject *Sender);
        void __fastcall DateTimePicker1Change(TObject *Sender);
        void __fastcall Edit3Change(TObject *Sender);
        void __fastcall Edit4Change(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall TabControl1Change(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
    void __fastcall Edit10Exit(TObject *Sender);
private:	// User declarations
       
public:		// User declarations
         CalcKBMReqType c;
         mode_work wm;
        __fastcall TFKBMRSA(TComponent* Owner);
        __fastcall TFKBMRSA(TComponent* Owner, CalcKBMReqType c_,mode_work wm_);

};
//---------------------------------------------------------------------------
extern PACKAGE TFKBMRSA *FKBMRSA;
//---------------------------------------------------------------------------
#endif
