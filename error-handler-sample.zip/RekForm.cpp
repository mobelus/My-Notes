//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "RekForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TReks *Reks;
int res;
//---------------------------------------------------------------------------
__fastcall TReks::TReks(TComponent* Owner, mops_api_027 *m_api)
        : TForm(Owner)
{
        this->m_api = m_api;
}
//---------------------------------------------------------------------------
void __fastcall TReks::FormShow(TObject *Sender)
{

        Poluch->Text = m_api->vrGetVariableCurProduct(res, "_OSAGO_UL_Poluch_Name");
        Address->Text = m_api->vrGetVariableCurProduct(res, "_OSAGO_UL_Poluch_Address");
        Reks->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_Poluch_Reks");
        Podp1_dolzh->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_Podpis1_dolzh");
        Podp2_dolzh->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_Podpis2_dolzh");
        Podp1_fio->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_Podpis1_fio");
        Podp2_fio->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_Podpis2_fio");
        IspFIO->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_IspFIO");
        IspPhone->Text = m_api->vrGetVariableCurProduct(res,"_OSAGO_UL_IspPhone");
}
//---------------------------------------------------------------------------
void __fastcall TReks::Panel1Click(TObject *Sender)
{
        m_api->vrSetVariableCurProduct(res, "_OSAGO_UL_Poluch_Name",Poluch->Text);
        m_api->vrSetVariableCurProduct(res, "_OSAGO_UL_Poluch_Address",Address->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_Poluch_Reks",Reks->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_Podpis1_dolzh",Podp1_dolzh->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_Podpis2_dolzh",Podp2_dolzh->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_Podpis1_fio",Podp1_fio->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_Podpis2_fio",Podp2_fio->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_IspFIO",IspFIO->Text);
        m_api->vrSetVariableCurProduct(res,"_OSAGO_UL_IspPhone",IspPhone->Text);
        Close();
}
//---------------------------------------------------------------------------
void __fastcall TReks::Panel2Click(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------
