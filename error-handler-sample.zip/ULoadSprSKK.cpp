//---------------------------------------------------------------------------
#pragma hdrstop

#include "ULoadSprSKK.h"
#include "XML_Progress_Form_c.h"
#include "BlackListKit.h"
 #pragma package(smart_init)
//---------------------------------------------------------------------------

///////////////////////////////////////////////
// TO ADD A GLOBAL-DICTIONARY
// ��� ���������� ����������� �����������
///////////////////////////////////////////////
//
// _mops_SKK_dicts_
// _mops_global_dicts_
// _mops_global_dicts_tables_
//
/////////////////////////////////////////////////
//
///////////////////////////////////////////////
// TO ADD A LOCAL-DICTIONARY
// ��� ���������� ���������� �����������
///////////////////////////////////////////////
//
// _mops_meta_data_
// _mops_meta_data_tables_
//
/////////////////////////////////////////////////

//---------------------------------------------------------------------------
void ReloadSpr7_9_29(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select t1.id as id,t2.OBJECT_ID as id_entity,t3.VALIDATION_TYPE_ID as id_validation,t4.code as id_ts "
                                ",t1.MIN_VALUE as val_min,t1.MAX_VALUE as val_max,t1.TEXT as ch,t1.start_date as start_date, t1.FINISH_DATE as end_date "
                            " from RGSSCC.REF_DICT_VALIDATION_RSA t1"
                            " join RGSSCC.REF_DICT_OBJECT_RSA t2 on t2.id =t1.OBJECT_ID "
                            " join RGSSCC.REF_DICT_VALID_TYPE_RSA t3 on t3.id =t1.VALIDATION_TYPE_ID "
                            " join RGSSCC.REF_CARRIER_TYPE t4 on t4.SCC_ID =t1.CODE "
                            " where sysdate <= t1.date_to and sysdate >= t1.date_from"
                            );
//REF_DICT_OBJECT_RSA 7_9_27 ���� ���������(����� ��� ����� � �.�.) SCC_ID SCC_STATUS ID DATE_FROM DATE_TO TICK IS_NODE BASE_ID OBJECT_ID OBJECT_NAME
//REF_DICT_VALID_TYPE_RSA 7_9_28  ���� �������� (�������� �������� ��� ����������� ����.�������) SCC_ID SCC_STATUS ID DATE_FROM DATE_TO TICK IS_NODE BASE_ID VALIDATION_TYPE_ID VALIDATION_TYPE_NAME
//REF_CARRIER_TYPE 5_1_1 ���� ��  (� � � �..) SCC_ID SCC_STATUS BASE_ID RF_CODE_TYPE_TS_FK$ SHORT_NAME NOTE FULL_NAME CODE IS_NODE TICK DATE_TO DATE_FROM ID CREATION_TIME USER_ID VEHICLE_OR_TRACTOR VEHICLE_SHORT_CATEGORY RF_CODE_TYPE_TS_FK_ RF_CODE_TYPE_TS_FK
//REF_DICT_VALIDATION_RSA 7_9_29 SCC_ID SCC_STATUS ID DATE_FROM DATE_TO TICK IS_NODE BASE_ID VALIDATION_ID OBJECT_ID VALIDATION_TYPE_ID CODE MIN_VALUE MAX_VALUE TEXT START_DATE FINISH_DATE

//   TADOQuery *qw=pSKK->dbGetCursor(res,"select * from RGSSCC.REF_DICT_OBJECT_RSA" );
/*    TStringList *sl = new TStringList();
    qw->GetFieldNames(sl);
    AnsiString nnn = sl->Text;
    delete sl;
*/

  m_api->dbExecuteQuery(res,"delete from gl_dict_FLK");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_FLK", 0);
  for(qw->First(); !qw->Eof; qw->Next()) {
    q->Insert();

    for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;

    q->Post();
  }
  m_api->dbCloseCursor(res,q);

  pSKK->dbCloseCursor(res,qw);
}



void ReloadSpr5_4_15(mops_api_014* m_api,mops_api_014* pSKK){
 int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"SELECT id,clients_name,db_inn FROM RGSSCC.REF_SPECIALCLIENTS where DATE_TO>SYSDATE AND clients_name IS NOT NULL");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_SPECIALCLIENTS");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_SPECIALCLIENTS", 0);

  TXML_Progress_Form *pr = new TXML_Progress_Form(0);
  int z_count = qw->RecordCount;
  pr->sGauge1->MinValue = 0;
  pr->sGauge1->MaxValue = z_count;
  pr->sGauge1->Progress = 0;
  pr->sLabel1->Caption = "��������";
  pr->Show();


  for(qw->First(); !qw->Eof; qw->Next(), Application->ProcessMessages(), pr->sGauge1->Progress++) {
    q->Insert();
    q->Fields->Fields[0]->Value = qw->Fields->Fields[0]->Value;
    q->Fields->Fields[1]->Value = qw->Fields->Fields[1]->Value;
    q->Fields->Fields[2]->Value = qw->Fields->Fields[2]->Value;
  }
  q->Post();

  pr->Visible    = false;
  delete pr;  pr = 0;

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

void ReLoadSpr7_3_43(mops_api_014* m_api,mops_api_014* pSKKAPI) {
  int res;
  TADOQuery *qw_skk= pSKKAPI->dbGetCursor(res, "select distinct base.BASE_RATE_ID, base.VEHICLE_TYPE,base.PERCENT_VALUE,base.ABSOLUTE_VALUE,base.SORT_ORDER,base.OSAGO_FORMULA_ID,base.CARRIER_TYPE_CODE_FK,base.IS_JURIDICAL,"
                "base.BUS_SEATS_QUANTITY_MIN,base.BUS_SEATS_QUANTITY_MAX,base.TRUCK_ALLOWED_MASS_MIN,base.TRUCK_ALLOWED_MASS_MAX,usage.usage_purpose_id,base.START_DATE,base.END_DATE,base.MAX_ABSOLUTE_VALUE"
               " from RGSSCC.REF_ADOSAGOBASERATE_22 base left join RGSSCC.REF_autodictusagepurpose usage on base.USAGAE_FK_FK = usage.id "
               " where sysdate <= base.date_to and sysdate >= base.date_from" );

  m_api->dbExecuteQuery(res,"delete from OSAGO_R_AutoDictOsagoBaseRate");
  TADOQuery *q_apo = m_api->dbGetCursor( res, "select * from OSAGO_R_AutoDictOsagoBaseRate", 0);
  for(qw_skk->First(); !qw_skk->Eof; qw_skk->Next()) {
    q_apo->Insert();
     for(int j=0; j<qw_skk->Fields->Count;j++) {
       q_apo->Fields->Fields[j]->Value=qw_skk->Fields->Fields[j]->Value;

       if( j==12 //"USAGAE_FK_FK"
            &&  q_apo->Fields->Fields[j]->Value.IsNull() )
         q_apo->Fields->Fields[j]->Value=0;

     }
    q_apo->Post();
  }
  m_api->dbCloseCursor(res,q_apo);
  pSKKAPI->dbCloseCursor(res,qw_skk);
}


void ReLoadSpr7_1_9(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString sSQL = "";
  const char *finsert = "insert into %s values (%d, '%s', %0.2f, %d, %d, %s, %s)";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));

   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("id")->AsInteger,
   qwSource->FieldByName("period_name")->AsString,
   qwSource->FieldByName("coeff_value")->AsFloat,
   qwSource->FieldByName("sort_order")->AsInteger,
   qwSource->FieldByName("is_infraction_present")->AsInteger,
   sdate,
   edate
   );

   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_1_11(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, '%s', %0.2f, %i, %i, %i, %i, %i, %i, %i, %s, %s, %s)";

sSQL = "select "
"age_id, "
"AGE_NAME, "
"coeff_value, "
"sort_order, "
"IS_JURIDICAL, "
"CAST (DRIVING_EXPERIENCE_MIN as int) as DRIVING_EXPERIENCE_MIN, "
"DRIVING_EXPERIENCE_MAX, "
"CAST (AGE_MIN as int) as AGE_MIN, "
"AGE_MAX, "
"IS_UNLIMITED_DRIVERS, "
"NVL(ta.territory_id , 0) As territory_id, "
"start_date, "
"end_date "
"from RGSSCC.REF_AUTODICTOSAGOAGE ta "
"where sysdate >= DATE_FROM "
"AND sysdate <= DATE_TO ";
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));

   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("age_id")->AsString,
   qwSource->FieldByName("AGE_NAME")->AsString,
   qwSource->FieldByName("coeff_value")->AsFloat,
   qwSource->FieldByName("sort_order")->AsInteger,
   qwSource->FieldByName("IS_JURIDICAL")->AsInteger,
   qwSource->FieldByName("DRIVING_EXPERIENCE_MIN")->AsInteger,
   qwSource->FieldByName("DRIVING_EXPERIENCE_MAX")->AsInteger,
   qwSource->FieldByName("AGE_MIN")->AsInteger,
   qwSource->FieldByName("AGE_MAX")->AsInteger,
   qwSource->FieldByName("IS_UNLIMITED_DRIVERS")->AsInteger,
   qwSource->FieldByName("TERRITORY_ID")->AsString,
   sdate,
   edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_1_12(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%d, '%s', %0.2f, %d, %d, %d, %s, %s, %s)";


sSQL = "select "
 "id, "
 "limit_name, "
 "coeff_value, "
 "sort_order, "
 "is_juridical, "
 "is_unlimited_drivers, "
 "NVL(tlimit.territory_id , 0) As territory_id, "
 "start_date, "
 "end_date "
 "from RGSSCC.REF_ADOSAGODRIVERLIMIT tlimit "
 "where sysdate >= DATE_FROM AND sysdate <= DATE_TO ";

  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));

   sSQL.sprintf(finsert,
    apo_tb,
    qwSource->FieldByName("id")->AsInteger,
    qwSource->FieldByName("limit_name")->AsString,
    qwSource->FieldByName("coeff_value")->AsFloat,
    qwSource->FieldByName("sort_order")->AsInteger,
    qwSource->FieldByName("is_juridical")->AsInteger,
    qwSource->FieldByName("is_unlimited_drivers")->AsInteger,
    qwSource->FieldByName("territory_id")->AsString,
    sdate,
    edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_3_41(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%d, '%s', %0.2f, %0.2f, %0.2f, %d, %s, %s)";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));

   sSQL.sprintf(finsert,
    apo_tb,
    qwSource->FieldByName("id")->AsInteger,
    qwSource->FieldByName("power_name")->AsString,
    qwSource->FieldByName("low_power")->AsFloat,
    qwSource->FieldByName("high_power")->AsFloat,
    qwSource->FieldByName("coeff_value")->AsFloat,
    qwSource->FieldByName("sort_order")->AsInteger,
    sdate,
    edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_1_10(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, '%s', %0.2f, %d, %d, %d, %d, %s, %s)";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));

   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("USAGE_ID")->AsString,
   qwSource->FieldByName("USAGE_NAME")->AsString,
   qwSource->FieldByName("COEFF_VALUE")->AsFloat,
   qwSource->FieldByName("SORT_ORDER")->AsInteger,
   qwSource->FieldByName("USAGE_PERIOD_MIN")->AsInteger,
   qwSource->FieldByName("USAGE_PERIOD_MAX")->AsInteger,
   qwSource->FieldByName("IS_JURIDICAL")->AsInteger,
   sdate,
   edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr5_1_1(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%d, '%s', '%s', '%s', %d)";

/*
    sSQL = "select ct.id As vehtype_id, "
	   "ct.full_name As veh_full, "
	   "ct.short_name As veh_sokr, "
	   "nt.NAME_T_TS As veh_group, "
	   "ct.VEHICLE_OR_TRACTOR As is_tractor "
     "from rgsscc_meta." + skk_tb + " ct, "
	    "rgsscc_meta.REF_TYPE_TS_DUU nt "
     "where "
      "ct.RF_CODE_TYPE_TS_FK = nt.id "
      "and ct.date_from <= SYSDATE AND NVL (ct.date_to, SYSDATE) >= SYSDATE";
*/
    sSQL = "select id As vehtype_id, "
	   "full_name As veh_full, "
	   "short_name As veh_sokr, "
	   "VEHICLE_OR_TRACTOR As is_tractor"
       " from rgsscc_meta."+skk_tb + " where date_from <= SYSDATE AND NVL (date_to, SYSDATE) >= SYSDATE";

  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   int stractor = (qwSource->FieldByName("is_tractor")->AsString == "1")?1:0;
   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("vehtype_id")->AsInteger,
   qwSource->FieldByName("veh_full")->AsString,
   qwSource->FieldByName("veh_sokr")->AsString,
   "",
   stractor
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_3_47(mops_api_014* m_api,mops_api_014* pSKKAPI)
{
  int
    iRes = 0,
    forign = 0;
  long parent_id = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "",
   apo_tb = "gl_dict_osagoterritory";
  const char *finsert = "insert into %s values (%s, %ld, '%s', %d, %d, %d, %d)";

 sSQL = "SELECT territory_id AS terr_id, NVL (fk_osg_ter_par_fk, 0) AS parent_id, "
        "territory_name AS terr_name, NVL (vehicle_value, 0) AS veh_val, "
        "NVL (tractor_value, 0) AS tract_val, sort_order, "
        "is_foreign_registration AS is_foreign "
    "FROM rgsscc_meta.ref_atdosagoterritory "
   "WHERE date_from <= SYSDATE AND NVL (date_to, SYSDATE) >= SYSDATE "
   "ORDER BY sort_order";



  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   forign = (qwSource->FieldByName("is_foreign")->AsString == "1")?1:0;
   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("terr_id")->AsString,
   0,
   qwSource->FieldByName("terr_name")->AsString.c_str(),
   qwSource->FieldByName("veh_val")->AsInteger,
   qwSource->FieldByName("tract_val")->AsInteger,
   qwSource->FieldByName("sort_order")->AsInteger,
   forign
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

//------------------------------------------------------------------------------

void ReLoadSpr7_1_14(mops_api_014* m_api,mops_api_014* pSKKAPI)
{
  int iRes = 0;
  TADOQuery* qwSource = NULL;
  AnsiString
   sSQL = "",
   usage_name = "",
   apo_tb = "gl_dict_osagoterritorycoeff",
   sSQLParent = "";

//  m_api->dbExecuteQuery(res,"delete from gl_dict_osagoterritorycoeff");

  const char *finsert = "insert into %s values (%d, %d, %d, %0.2f, %0.2f, %s, %s)";

 sSQL = "SELECT t1.id_scc, "
       "t2.territory_id as terr_id, "
       "t3.territory_id as parent_id, "
       "t1.vehicle_value as veh_val, "
       "t1.tractor_value as tract_val, "
       "t1.start_date, "
       "NVL(t1.end_date,TO_DATE('01.01.3000','DD/MM/YYYY')) as end_date_ "
     "FROM rgsscc.ref_adosagoterritorycoeff t1, "
          "rgsscc.ref_atdosagoterritory t2, "
          "rgsscc.ref_atdosagoterritory t3 "
    "WHERE t1.TERRITORY_ID_7_3_47_FK = t2.ID(+) "
      "AND t1.PARENT_ID_7_3_47_FK = t3.ID(+) "
      "AND t1.date_to = TO_DATE ('01.01.2020', 'DD/MM/YYYY') "
      "AND t2.date_to(+) = TO_DATE ('01.01.2020', 'DD/MM/YYYY') "
      "AND t3.date_to(+) = TO_DATE ('01.01.2020', 'DD/MM/YYYY') ";

  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString sdate(""), edate("");
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date_")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date_")->AsDateTime));

   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("id_scc")->AsInteger,
   qwSource->FieldByName("terr_id")->AsInteger,
   qwSource->FieldByName("parent_id")->AsInteger,
   qwSource->FieldByName("veh_val")->AsFloat,
   qwSource->FieldByName("tract_val")->AsFloat,
   sdate,
   edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_4_12(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource = NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, %d, '%s', %0.2f, %0.2f, %d, %s, %s)";

  sSQL = "select BONUS_MALUS_ID AS malus_id, "
	   "cast (BONUS_MALUS_VALUE as integer) AS malus_val, "  //����, ���� ���������� ����� ���� � Int
	   "description AS descriptio, "
	   "coeff_value AS coeff_val, "
	   "b.sort_order AS sort_order, "
	   "cast (t.TERRITORY_ID as integer) AS terr_id, "       //����, ���� ���������� ����� ���� � Int
	   "b.START_DATE AS start_date, "
	   "b.END_DATE AS end_date "
  "from rgsscc_meta.ref_AUTODICTBONUSMALUS b "
  "left join rgsscc_meta.ref_atdosagoterritory t "
  "on NVL (t.date_to, SYSDATE) >= SYSDATE "
  	 "and b.OSAGO_TERRITORY_ID_7_3_47_FK = t.id "
  "WHERE "
    "b.DATE_TO = TO_DATE ('01.01.2020', 'DD/MM/YYYY') "
  	"AND b.start_date <= SYSDATE "
	"AND	NVL (b.end_date, SYSDATE) >= SYSDATE "
  "ORDER BY b.sort_order";

  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   int terr_id = 0;


   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));
   if(qwSource->FieldByName("terr_id")->IsNull)
    terr_id = 0;
   else
    terr_id = qwSource->FieldByName("terr_id")->AsInteger;
   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("malus_id")->AsString,
   qwSource->FieldByName("malus_val")->AsInteger,
   qwSource->FieldByName("descriptio")->AsString,
   qwSource->FieldByName("coeff_val")->AsFloat,
   qwSource->FieldByName("sort_order")->AsFloat,
   terr_id,
   sdate,
   edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}

void ReLoadSpr7_3_42(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, '%s', %0.2f, %d, '%s', '%s', %d, %s, %s)";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
   AnsiString
    sdate = "",
    edate = "";
   int trans = 0;
   if(qwSource->FieldByName("start_date")->IsNull)
     sdate = "null";
   else
     sdate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("start_date")->AsDateTime));
   if(qwSource->FieldByName("end_date")->IsNull)
     edate = "null";
   else
     edate = m_api->Internal_Convert_Date_To_SQL(iRes, FormatDateTime("dd.mm.yyyy hh:mm:ss", qwSource->FieldByName("end_date")->AsDateTime));
   trans = (qwSource->FieldByName("IS_TRANSIT_TO_REGISTRATION")->AsString == "1")?1:0;
   sSQL.sprintf(finsert,
   apo_tb,
   qwSource->FieldByName("PERIOD_ID")->AsString,
   qwSource->FieldByName("PERIOD_NAME")->AsString,
   qwSource->FieldByName("COEFF_VALUE")->AsFloat,
   qwSource->FieldByName("SORT_ORDER")->AsInteger,
   qwSource->FieldByName("PERIOD_MIN")->AsString,
   qwSource->FieldByName("PERIOD_MAX")->AsString,
   trans,
   sdate,
   edate
   );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}


//------------------------------------------------------------------------------
void ReLoadSpr4_1_9(mops_api_014 *m_api,mops_api_014 *pSKK)
{
/* � ����� ���  ���������� �� ��������   ������� ������� ������� � ����  OSAGO_R_tip_doc ��� ����� � ��� ���������
 int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.IDENTITY_DOCUMENTS");

  m_api->dbExecuteQuery(res,"delete from OSAGO_R_tip_doc");

  for(int i=0; i<qw->RecordCount;i++,qw->Next())
      m_api->dbExecuteQuery(res,"insert into OSAGO_R_tip_doc (id_tip_doc,tip_doc,personal) values("
      +(qw->FieldByName("CODE")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("CODE")->AsString) + ",'"
      +(qw->FieldByName("FULL_NAME")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("FULL_NAME")->AsString) + "',"
      +(qw->FieldByName("PERSONAL")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("PERSONAL")->AsString) + ")"
      );
 pSKK->dbCloseCursor(res,qw);
 */
}

//-------------

void ReLoadSpr5_1_3(mops_api_014* m_api,mops_api_014* pSKKAPI)
{
  int res;
  m_api->dbExecuteQuery(res,"delete from GL_DICT_CARRIER_MODELS");
  TADOQuery *qw=m_api->dbGetCursor(res,"select * from GL_DICT_CARRIER_MODELS",0,1);

  TADOQuery *qw_skk=pSKKAPI->dbGetCursor(res,"select * from APO.CARRIER_MODELS");
  for(int i=0; i<qw_skk->RecordCount;i++,qw_skk->Next())
  {
   qw->Insert();
    for(int j=0; j<qw->Fields->Count;j++)
       qw->Fields->Fields[j]->Value=qw_skk->Fields->Fields[j]->Value;
   qw->Post();
  }
  m_api->dbCloseCursor(res,qw);
  pSKKAPI->dbCloseCursor(res,qw_skk);
}


void ReloadSpr5_1_2(mops_api_014* m_api,mops_api_014* pSKKAPI)
{
  int res;
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_CARRIER_CATEGORIES");
  TADOQuery *qw=m_api->dbGetCursor(res,"select * from OSAGO_R_CARRIER_CATEGORIES",0,1);

  TADOQuery *qw_skk=pSKKAPI->dbGetCursor(res,"select * from APO.CARRIER_CATEGORIES");
  for(int i=0; i<qw_skk->RecordCount;i++,qw_skk->Next())
  {
   qw->Insert();
    for(int j=0; j<qw->Fields->Count;j++)
       qw->Fields->Fields[j]->Value=qw_skk->Fields->Fields[j]->Value;
   qw->Post();
  }
  m_api->dbCloseCursor(res,qw);
  pSKKAPI->dbCloseCursor(res,qw_skk);
}

void ReLoadSpr7_3_33(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
  int res;
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_AutoDictOsagoVehPurpose");
  TADOQuery *qw=m_api->dbGetCursor(res,"select * from OSAGO_R_AutoDictOsagoVehPurpose",0,1);

  TADOQuery *qw_skk=pSKKAPI->dbGetCursor(res,"select * from RGSSCC.REF_autodictusagepurpose where sysdate >= date_from and sysdate <= date_to");
  for(int i=0; i<qw_skk->RecordCount;i++,qw_skk->Next())
  {
   qw->Insert();
   qw->FieldByName("purpose_id")->AsInteger = qw_skk->FieldByName("USAGE_PURPOSE_ID")->AsInteger;
   qw->FieldByName("purpose_na")->AsString = qw_skk->FieldByName("USAGE_PURPOSE_NAME")->AsString;
   qw->FieldByName("sort_order")->AsInteger = qw_skk->FieldByName("SORT_ORDER")->AsInteger;
   qw->FieldByName("rsa_code")->AsInteger = qw_skk->FieldByName("RSA_USAGE_PURPOSE_CODE")->AsInteger;
   qw->FieldByName("start_date")->AsString = qw_skk->FieldByName("start_date")->AsString.c_str();
   qw->FieldByName("end_date")->AsString = qw_skk->FieldByName("end_date")->AsString.c_str();
   qw->Post();
  }
  m_api->dbCloseCursor(res,qw);
  pSKKAPI->dbCloseCursor(res,qw_skk);
}
 /*
{
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, '%s', %d, %s)";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
    sSQL.sprintf(finsert,
    apo_tb,
    qwSource->FieldByName("USAGE_PURPOSE_ID")->AsString.c_str(),
    qwSource->FieldByName("USAGE_PURPOSE_NAME")->AsString.c_str(),
    qwSource->FieldByName("SORT_ORDER")->AsInteger,
    qwSource->FieldByName("RSA_USAGE_PURPOSE_CODE")->AsString.c_str(),
    );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
}    */

void ReLoadSpr7_1_7(mops_api_014*  m_api, mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
/*
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, '%s')";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
    sSQL.sprintf(finsert,
    apo_tb,
    qwSource->FieldByName("PAIMENT_TYPE_ID")->AsString.c_str(),
    qwSource->FieldByName("PAYMENT_TYPE_NAME")->AsString.c_str()
    );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
*/
}

void ReLoadSpr7_4_33(mops_api_014* m_api,mops_api_014* pSKKAPI, AnsiString skk_tb, AnsiString apo_tb)
{
/*
  int iRes = 0;
  TADOQuery* qwSource =NULL;
  AnsiString
   sSQL = "",
   usage_name = "";
  const char *finsert = "insert into %s values (%s, '%s')";

  sSQL.sprintf(fselSKK , skk_tb);
  qwSource = pSKKAPI->dbGetCursor(iRes, sSQL, false);
  sSQL.sprintf(fdelete, apo_tb);
  m_api->dbExecuteQuery(iRes, sSQL);
  for(qwSource->First(); !qwSource->Eof; qwSource->Next())
  {
    sSQL.sprintf(finsert,
    apo_tb,
    qwSource->FieldByName("PAYMENT_DOC_ID")->AsString.c_str(),
    qwSource->FieldByName("PAYMENT_DOC_NAME")->AsString.c_str()
    );
   m_api->dbExecuteQuery(iRes, sSQL);
  }
  pSKKAPI->dbCloseCursor(iRes, qwSource);
*/
}

 void ReloadSpr7_4_9(mops_api_014* m_api,mops_api_014 *pSKK) //���������� ����� �������
{
  int res;
  /* TODO : WARNING: SKK 7.4.9 */
  //TADOQuery *qw_s=pSKK->dbGetCursor(res,"select blank_type_id,blank_type_name from rgsscc_meta.ref_dictblanktype where "
  //                                      " date_FROM<=SYSDATE AND DATE_TO>SYSDATE AND CONTRACT_ClASS_ID IN(2)AND ACTIVE_entry='Y'");
  TADOQuery *qw_s=pSKK->dbGetCursor(res,"select b.blank_type_id,b.blank_type_name from RGSSCC.REF_DICTBLANKTYPE b"
                                        " join RGSSCC.REF_DICTBLANKTYPESERIES bs on BS.TABL_755_FK_=B.SCC_ID"
                                        " where B.CONTRACT_CLASS_ID='2'"
                                        " and B.SCC_STATUS=0"
                                        " and BS.SCC_STATUS=0"
                                        " and BS.START_DATE<=sysdate"
                                        " and BS.END_DATE>=sysdate");

  m_api->dbExecuteQuery(res,"delete from osago_r_blanktypes");
  AnsiString sql="";
  for(int i=0; i<qw_s->RecordCount;i++,qw_s->Next())
  {
   sql="insert into osago_r_blanktypes values("+qw_s->FieldByName("blank_type_id")->AsString+",'"+ m_api->Internal_Prepare_SQL_Text(res,qw_s->FieldByName("blank_type_name")->AsString) +"')";
   m_api->dbExecuteQuery(res,sql);
  }

  pSKK->dbCloseCursor(res,qw_s);

}

void ReloadSpr7_5_2(mops_api_014* m_api,mops_api_014 *pSKK) // �������� ��������
{
         int res;
         TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.insurer");
        m_api->dbExecuteQuery(res,"delete from OSAGO_R_ref_dictinsurer");
        for(int i=0; i<qw->RecordCount; i++,qw->Next())
        {
                m_api->dbExecuteQuery(res," insert into   OSAGO_R_ref_dictinsurer (id,insurer_id,insurer_name,sort_order) values ("
                                                + qw->FieldByName("id")->AsString + ","
                                                + qw->FieldByName("insurer_id")->AsString + ","
                                                + "'"+m_api->Internal_Prepare_SQL_Text(res,qw->FieldByName("insurer_name")->AsString) +"',"
                                                + qw->FieldByName("sort_order")->AsString +

                ")");


        }
         pSKK->dbCloseCursor(res,qw);
}


void ReloadSpr7_5_3(mops_api_014* m_api,mops_api_014 *pSKK) // ����� ��������� �������� � ���������
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.insurer_company");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_ref_insurer_company");
  for(int i=0; i<qw->RecordCount; i++, qw->Next())
     m_api->dbExecuteQuery(res," insert into  OSAGO_R_ref_insurer_company ( id, tabl_4_1_4_FK,TABL_7_5_2_FK) values ("
                                + qw->FieldByName("id")->AsString + ","
                                + qw->FieldByName("tabl_4_1_4_FK")->AsString + ","
                                + qw->FieldByName("TABL_7_5_2_FK")->AsString +
                                ")");
      pSKK->dbCloseCursor(res,qw);
}


//���������_�����
void ReloadSpr7_3_5(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res, "select RISK_OBJECT_TYPE_ID,insurancerule_22_fk as rules_id, "
                    " cast(substr(RISK_OBJECT_NAME,INSTR(RISK_OBJECT_NAME,'-',-1)+1) as integer) as age,"
                    " case when instr(RISK_OBJECT_NAME,'�������')=0 then '�'"
                    " else '�' end \"SEX\","
                    " START_DATE,END_DATE"
                    " from RGSSCC.REF_DICTRISKOBJECTTYPE_22"
                    " where  date_to>sysdate and insurancerule_22_fk in(933,934,935)" );

  m_api->dbExecuteQuery(res,"delete from OSAGO_R_nsrisktypes");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_nsrisktypes", 0);
  for(qw->First(); !qw->Eof; qw->Next()) {
    q->Insert();
    q->FieldByName("RISK_OBJECT_TYPE_ID")->Value = qw->FieldByName("RISK_OBJECT_TYPE_ID")->Value;
    q->FieldByName("rules_id")->Value = qw->FieldByName("rules_id")->Value;
    q->FieldByName("sex")->Value = qw->FieldByName("sex")->Value;
    q->FieldByName("age")->Value = qw->FieldByName("age")->Value;
    q->FieldByName("START_DATE")->Value = qw->FieldByName("START_DATE")->Value;
    q->FieldByName("END_DATE")->Value = qw->FieldByName("END_DATE")->Value;
    q->Post();
  }
  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

//��������� �� old
/*void ReloadSpr5_4_11(mops_api_014* m_api,mops_api_014* pSKK) {
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select t1.oto_pik_id as branch_id,decode(t2.oto_pik_id,t1.oto_pik_id,0,t2.oto_pik_id) as parent_id,"
   "decode(t2.oto_pik_id,t1.oto_pik_id,t1.oto_pik_name,trim(nullif(t1.p_index||' ',' ')||nullif(t1.p_district||', ',', ')||nullif(t1.p_place||', ',', ')||t1.p_street||' '||t1.p_house||' '||t1.p_building)) as branch_name,"
   "decode(t1.oto_type,3,t1.link_to_4_1_4_1_fk,decode(t2.oto_pik_id,t1.oto_pik_id,0,t1.link_to_4_1_4_1_fk)) as region_id,"
   "t1.oto_type,decode(substr(t1.p_place, 1, 1),'�',t1.p_place,('�. ' || t1.p_place)) as city,"
   "trim(nullif(t1.p_index||' ',' ')||nullif(t1.p_district||', ',', ')||nullif(t1.p_place||', ',', ')||t1.p_street||' '||t1.p_house||' '||t1.p_building) as branch_address,"
   "trim(nullif(t1.u_index||' ',' ')||nullif(t1.u_district||', ',', ')||nullif(t1.u_place||', ',', ')||t1.u_street||' '||t1.u_house||' '||t1.u_building) as u_address,"
   "t3.accreditation_number,t3.accreditation_date,t3.contract_number,t3.contract_date,t3.ogrn,t3.okpo,t3.okato,t3.bik_oto as bik,t3.account_number_ as account_number,"
   "t3.kpp,t3.inn,t3.kor_schet,t3.bank,dictblankser1.series_name series_blank_dk,jointoplus.series_blank_toplus,t3.start_date as start_date_cnt,t3.end_date_ as end_date_cnt,t1.start_date,t1.end_date "
   "from rgsscc_meta.ref_oto t1,rgsscc_meta.ref_oto t2,(select * from rgsscc_meta.ref_relationship_oto_contr where date_to>sysdate) t4,"
   "(select * from rgsscc_meta.ref_contract_oto where date_to>sysdate) t3, (select * from rgsscc_meta.ref_subject_rf where date_to>sysdate and active_entry='Y') t5,"
   "(select * from rgsscc_meta.ref_subject_rf where date_to>sysdate and active_entry='Y') t6,rgsscc_meta.ref_oto_branch_bsoseries_2 oto_bso1,"
   "rgsscc_meta.ref_dictblankseries dictblankser1,rgsscc_meta.ref_dictblanktypeseries dictblanktypeseries1,"
   "(select oto2.oto_pik_id,dictblankser2.series_name series_blank_toplus from rgsscc_meta.ref_oto oto2,rgsscc_meta.ref_oto_branch_bsoseries_2 oto_bso2,rgsscc_meta.ref_dictblankseries dictblankser2,rgsscc_meta.ref_dictblanktypeseries dictblanktypeseries2 where	oto2.id=oto_bso2.to_5411_fk(+) and oto_bso2.to_754_fk=dictblankser2.id(+) and oto_bso2.to_754_fk=dictblanktypeseries2.tab_755_fk(+) and dictblanktypeseries2.tabl_755_fk=329 and nvl(oto2.date_to,sysdate)>=sysdate and nvl(oto_bso2.date_to,sysdate)>=sysdate and nvl(dictblankser2.date_to,sysdate)>=sysdate and nvl(dictblanktypeseries2.date_to,sysdate)>=sysdate) jointoplus"
   " where nvl(t1.link_to_5_4_11_fk,t1.id)=t2.id(+) and t1.id=t4.link_to_5_4_11_fk(+) and t4.link_to_5_4_12_fk=t3.id(+) and t1.link_to_4_1_4_1_fk=t5.id(+) and "
   "t1.link_to_4_1_4_2_fk=t6.id(+) and t1.id=oto_bso1.to_5411_fk(+) and oto_bso1.to_754_fk=dictblankser1.id(+) and oto_bso1.to_754_fk=dictblanktypeseries1.tab_755_fk(+) and "
   "t1.oto_pik_id=jointoplus.oto_pik_id(+) and nvl(t1.date_to,sysdate)>=sysdate and nvl(t2.date_to,sysdate)>=sysdate and nvl(oto_bso1.date_to, sysdate)>=sysdate and "
   "nvl(dictblankser1.date_to, sysdate)>=sysdate and nvl(dictblanktypeseries1.date_to, sysdate)>=sysdate and (dictblanktypeseries1.tabl_755_fk=277 or nvl(dictblanktypeseries1.tabl_755_fk,0)=0) order by t1.oto_pik_id"
   );

  m_api->dbExecuteQuery(res,"delete from OSAGO_R_dict_branch");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_dict_branch", 0);

  AnsiString str;
  for(qw->First(); !qw->Eof; qw->Next() ) {
    q->Insert();
    for(int i = 0, fcnt = qw->FieldCount; i < fcnt; ++i) {
      str = qw->Fields->Fields[i]->DisplayName + "; " + qw->Fields->Fields[0]->AsString;
      try {
        q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
      } catch(Exception& ex) {
        ShowMessage(str);
      }
    }
  }
  q->UpdateBatch();

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}
*/

//������ �� �� ��������� �� � �������� � 5_4_17
/*void ReloadSpr5_4_17(mops_api_014* m_api,mops_api_014* pSKK) {
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res, "select distinct IO.TO_5411_FK id_5411, io.TO_414_FK region_id from rgsscc_meta.ref_inspection_operator  io where end_date>sysdate and IO.TO_5411_FK is not null");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_ref_oto_5_4_17");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_ref_oto_5_4_17", 0);

  TXML_Progress_Form *pr = new TXML_Progress_Form(0);
  int z_count = qw->RecordCount;
  pr->sGauge1->MinValue = 0;
  pr->sGauge1->MaxValue = z_count;
  pr->sGauge1->Progress = 0;
  pr->sLabel1->Caption = "��������";
  pr->Show();

  for(qw->First(); !qw->Eof; qw->Next(), Application->ProcessMessages(), pr->sGauge1->Progress++) {
    q->Insert();
    for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
  }
  q->Post();

  pr->Visible    = false;
  delete pr;  pr = 0;

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}
*/

void ReloadSpr5_1_14(mops_api_033* m_api, mops_api_014* pSKK)
{
  int res;

/*
  TADOQuery *qw=pSKK->dbGetCursor(res,	"select *"
										"from  rgsscc.ref_CARRIERMODIFICATION"
										"where scc_status = 0"
								);

  m_api->dbExecuteQuery(res,"delete from gl_dict_5_1_14_modification_ts");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_5_1_14_modification_ts", 0);

  //AnsiString sqlstr;
  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
    for(int i=0; i < qw->Fields->Count; i++)
		q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
  }
  q->Post();

  m_api->dbCloseCursor(res, q);
  pSKK->dbCloseCursor(res, qw);
*/

  //if (NumDict == "5.4.11") //
    m_api->dbCopyTableFromSKK(res, "apo.modification_ts_5_1_14", "", "gl_dict_5_1_14_modification_ts");
}


//��������� ��
void ReloadSpr5_4_11(mops_api_014* m_api,mops_api_014* pSKK) {
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,

  "select distinct o.id, o.OTO_PIK_ID,o.OTO_PIK_NAME, rf.id AS REGION, o.start_date,o.end_date"
  " from RGSSCC.REF_OTO o,RGSSCC.REF_SUBJECT_RF rf "
  " where o.LINK_TO_4_1_4_1_FK=rf.id and o.OTO_TYPE=3 and o.end_date>sysdate and o.date_to>sysdate and o.LINK_TO_5_4_11_FK is null" // and o.end_date>'01.03.2014' ������ o.end_date>sysdate ��� ������������(��������� 1��� ������ ��������� ��� ��������������)
  " order by region"

/*��23.04.2015 ���   ��������� ������� �� �����������
  "select distinct o.id, OTO_PIK_ID,OTO_PIK_NAME, nvl(PRIOR link_to_4_1_4_1_FK,link_to_4_1_4_1_FK) AS REGION, start_date,end_date"
  " from RGSSCC.REF_OTO o"
  " where o.end_date>sysdate and o.date_to>sysdate and o.LINK_TO_5_4_11_FK is null" // and o.end_date>'01.03.2014' ������ o.end_date>sysdate ��� ������������(��������� 1��� ������ ��������� ��� ��������������)
  " start with  link_to_4_1_4_1_FK in  (select distinct TO_414_FK from rgsscc_meta.ref_inspection_operator where end_date>sysdate )"
  " connect by prior O.LINK_TO_5_4_11_FK=O.ID"
  " order by region"
*/
/*    "SELECT oto.OTO_PIK_ID,oto.OTO_PIK_NAME,oto.LINK_TO_4_1_4_1_FK"
  " FROM rgsscc_meta.ref_oto oto"
  " WHERE date_to > SYSDATE"
  " AND date_to > SYSDATE"
  " AND oto.link_to_4_1_4_1_fk IN ("
                     " SELECT DISTINCT io.to_414_fk"
                     " FROM rgsscc_meta.ref_inspection_operator io"
                     " WHERE date_to > SYSDATE"
                     " AND end_date > SYSDATE"
                     " AND io.to_414_fk IS NOT NULL)"
*/
//  "select id,oto_pik_id,oto_pik_name from rgsscc_meta.ref_oto oto where date_to >sysdate and OTO.LINK_TO_5_4_11_FK is null"
);
  m_api->dbExecuteQuery(res,"delete from gl_dict_5_4_11");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_5_4_11", 0);

  TXML_Progress_Form *pr = new TXML_Progress_Form(0);
  int z_count = qw->RecordCount;
  pr->sGauge1->MinValue = 0;
  pr->sGauge1->MaxValue = z_count;
  pr->sGauge1->Progress = 0;
  pr->sLabel1->Caption = "��������";
  pr->Show();

  AnsiString str;
  for(qw->First(); !qw->Eof; qw->Next(), Application->ProcessMessages(), pr->sGauge1->Progress++ ) {
    q->Insert();
    for(int i = 0, fcnt = qw->FieldCount; i < fcnt; ++i) {
      str = qw->Fields->Fields[i]->DisplayName + "; " + qw->Fields->Fields[0]->AsString;
      try {
        q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
      } catch(Exception& ex) {
        ShowMessage(str);
      }
    }
  }
  q->UpdateBatch();

  pr->Visible    = false;
  delete pr;  pr = 0;

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

void ReloadSpr7_4_39(mops_api_014* m_api,mops_api_014* pSKK) {
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select OSAGOTRAILERCOEFF_ID,LINK_FROM_7439_TO_511_FK as CARRIER_TYPE, TRAILER_USED,SUBJECT_TYPE,TRUCK_ALLOWED_MASS_MIN,"
                                       "TRUCK_ALLOWED_MASS_MAX,COEFF_VALUE,START_DATE,END_DATE from rgsscc_meta.ref_OSAGOTRAILERCOEFF");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_TRAILERCOEFF");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_TRAILERCOEFF", 0);

  AnsiString sqlstr("");
  for(qw->First(); !qw->Eof; qw->Next()) {

   q->Insert();
     for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
  }
  q->Post();

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}


//reg_koef ��� �������
void ReloadSpr7_3_81(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  AnsiString qstr = "select o.OSAGOREGCOEFF_ID,terr.code as TERRITORY_CODE,car.code as CARRIER_TYPE,o.BUS_SEATS_QUANTATI_MIN,o.BUS_SEATS_QUANTITY_MAX,o.TRUCK_ALLOWED_MASS_MIN,o.TRUCK_ALLOWED_MASS_MAX,"
                    "o.AGE_MIN,o.AGE_MAX,CKK_7_3_28_3.ID,o.COEFF_VALUE,o.START_DATE,o.END_DATE"
                   " from rgsscc.ref_osagoregcoeff o "
                  " left join rgsscc.ref_territories terr on terr.id=o.to_416_fk "
                  " left join rgsscc.ref_carrier_type car on car.id=o.to_511_fk "
                  " left join RGSSCC.REF_DICTSUBJECTTYPE CKK_7_3_28_3 on CKK_7_3_28_3.id=o.SUBJECT_TYPE_ID_FK "

                 " where o.date_to>sysdate "
                 "          and terr.date_to>sysdate "
                 "           and car.date_to>sysdate "
                 "  and CKK_7_3_28_3.date_to>sysdate ";



  TADOQuery *qw=pSKK->dbGetCursor(res,qstr);
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_REGCOEFF");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_REGCOEFF", 0);

  TXML_Progress_Form *pr = new TXML_Progress_Form(0);
  int z_count = qw->RecordCount;
  pr->sGauge1->MinValue = 0;
  pr->sGauge1->MaxValue = z_count;
  pr->sGauge1->Progress = 0;
  pr->sLabel1->Caption = "��������";
  pr->Show();

  AnsiString sqlstr("");
  int cnt = qw->RecordCount;

  for(qw->First(); !qw->Eof; qw->Next(), Application->ProcessMessages(), pr->sGauge1->Progress++) {
     q->Insert();
     for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
  }
  q->UpdateBatch();

  pr->Visible    = false;
  delete pr;  pr = 0;

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

//OSAGO_R_REGCOEFF   ����� ���� ��� �������
void ReloadSpr7_3_82(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
/*  AnsiString qstr = "select o.OSAGOREGCOEFF_ID,terr.code as TERRITORY_CODE,car.code as CARRIER_TYPE,o.BUS_SEATS_QUANTATI_MIN,o.BUS_SEATS_QUANTITY_MAX,o.TRUCK_ALLOWED_MASS_MIN,o.TRUCK_ALLOWED_MASS_MAX,"
                    "o.AGE_MIN,o.AGE_MAX,o.SUBJECT_TYPE,o.COEFF_VALUE,o.START_DATE,o.END_DATE"
                   " from rgsscc_meta.ref_osagoregcoeff o "
                  " left join rgsscc_meta.ref_territories terr on terr.id=o.to_416_fk "
                  " left join rgsscc_meta.ref_carrier_type car on car.id=o.to_511_fk "
                  " where o.date_to>sysdate ";
  TADOQuery *qw=pSKK->dbGetCursor(res,qstr);
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_REGCOEFF");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_REGCOEFF", 0);

  TXML_Progress_Form *pr = new TXML_Progress_Form(0);
  int z_count = qw->RecordCount;
  pr->sGauge1->MinValue = 0;
  pr->sGauge1->MaxValue = z_count;
  pr->sGauge1->Progress = 0;
  pr->sLabel1->Caption = "��������";
  pr->Show();

  AnsiString sqlstr("");
  int cnt = qw->RecordCount;

  for(qw->First(); !qw->Eof; qw->Next(), Application->ProcessMessages(), pr->sGauge1->Progress++) {
     q->Insert();
     for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
  }
  q->UpdateBatch();

  pr->Visible    = false;
  delete pr;  pr = 0;

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);

  */
}

//��
void ReloadSpr7_6_40(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;


  AnsiString qstr = "select id,lpad(kladr, 13, '0'), case when okato is null then null else lpad(okato, 11, '0') end, kt1,kt2,nam,socr,reg,raion,gorod,punkt,act,start_date, end_date "
   " from rgsscc.ref_osago_kt "
   " where scc_status=0";

  /*"select id,lpad(kladr, 13, '0'),"
     "case when okato is null then null else lpad(okato, 11, '0') end,"
    "kt1,kt2,nam,socr,reg,raion,gorod,punkt,act,date_from as start_date,date_to as end_date from rgsscc.ref_osago_kt "
//    " where date_to>'01.03.2014'"
    " where DATE_TO = TO_DATE('01.01.3000', 'dd.mm.yyyy') "
    " and act=0";
    */

  TADOQuery *qw=pSKK->dbGetCursor(res,qstr);
  m_api->dbExecuteQuery(res,"delete from gl_dict_kt_kladr");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_kt_kladr", 0);

  TXML_Progress_Form *pr = new TXML_Progress_Form(0);
  int z_count = qw->RecordCount;
  pr->sGauge1->MinValue = 0;
  pr->sGauge1->MaxValue = z_count;
  pr->sGauge1->Progress = 0;
  pr->sLabel1->Caption = "��������";
  pr->Show();

  AnsiString sqlstr("");
  for(qw->First(); !qw->Eof; qw->Next(), Application->ProcessMessages(), pr->sGauge1->Progress++) {

/*���������     sqlstr = "insert into gl_dict_kt_kladr (id,kladr,okato,kt1,kt2,nam,socr,reg,raion,gorod,punkt,act) values ("
        + qw->Fields->Fields[0]->AsString +             //id
        ",'" + qw->Fields->Fields[1]->AsString + "','"  //kladr
        + qw->Fields->Fields[2]->AsString + "',"        //okato
        + (qw->Fields->Fields[3]->AsString.IsEmpty()?AnsiString("NULL"):("'"+qw->Fields->Fields[3]->AsString+"'")) + ","         //kt1
        + (qw->Fields->Fields[4]->AsString.IsEmpty()?AnsiString("NULL"):("'"+qw->Fields->Fields[4]->AsString+"'")) + //kt2
        + ",'" + qw->Fields->Fields[5]->AsString + "','" //nam
        + qw->Fields->Fields[6]->AsString + "'," //socr
        + qw->Fields->Fields[7]->AsString + ","   //reg
        + qw->Fields->Fields[8]->AsString + ","   //raion
        + qw->Fields->Fields[9]->AsString + ","   //gorod
        + qw->Fields->Fields[10]->AsString + ","     //punkt
        + qw->Fields->Fields[11]->AsString + ")";  //act
          m_api->dbExecuteQuery(res, sqlstr);
*/   q->Insert();
     for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
  }
  q->Post();



  pr->Visible    = false;
  delete pr;  pr = 0;

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

//������ ���������
/*void ReloadSpr7_7_79(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from RGSSCC.REF_Fortune_AVTO where DATE_TO>SYSDATE");
  m_api->dbExecuteQuery(res,"delete from gl_dict_7_7_79_fortuneavto");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_7_7_79_fortuneavto", 0);
  for(qw->First(); !qw->Eof; qw->Next()) {
    q->Insert();
    q->FieldByName("ID")->AsInteger = qw->FieldByName("ID")->AsInteger;
    q->FieldByName("SCC_ID")->AsInteger = qw->FieldByName("SCC_ID")->AsInteger;
    q->FieldByName("REGION_ID")->AsInteger = qw->FieldByName("REGION_ID")->AsInteger;
    q->FieldByName("REGION")->AsString = qw->FieldByName("REGION")->AsString;
    q->FieldByName("FORTUNE_SUM1")->AsInteger = qw->FieldByName("FORTUNE_SUM1")->AsInteger;
    q->FieldByName("FORTUNE_SUM2")->AsInteger = qw->FieldByName("FORTUNE_SUM2")->AsInteger;
    q->FieldByName("FORTUNE_SUM3")->AsInteger = qw->FieldByName("FORTUNE_SUM3")->AsInteger;
    q->FieldByName("FORTUNE_PRICE1")->AsInteger = qw->FieldByName("FORTUNE_PRICE1")->AsInteger;
    q->FieldByName("FORTUNE_PRICE2")->AsInteger = qw->FieldByName("FORTUNE_PRICE2")->AsInteger;
    q->FieldByName("FORTUNE_PRICE3")->AsInteger = qw->FieldByName("FORTUNE_PRICE3")->AsInteger;
    q->FieldByName("FORTUNE_TARIF1")->AsFloat = qw->FieldByName("FORTUNE_TARIF1")->AsFloat;
    q->FieldByName("FORTUNE_TARIF2")->AsFloat = qw->FieldByName("FORTUNE_TARIF2")->AsFloat;
    q->FieldByName("FORTUNE_TARIF3")->AsFloat = qw->FieldByName("FORTUNE_TARIF3")->AsFloat;
    q->Post();
  }
  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}
*/

//����� ���������
void ReloadSpr7_7_82(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select distinct t.ID,t.ID_SCC,t.LIABILITY,t.PREMIUM,t.START_DATE,t.END_DATE,r.TERRITORY_ID,t.TO_7783_FK,KLADR.CODE as KLADR from RGSSCC.REF_FORT_AUTO_TARIFFS t"
  " LEFT JOIN RGSSCC.REF_ATDOSAGOTERRITORY r ON r.ID=t.TO_7347_FK "
  " LEFT JOIN RGSSCC.REF_TERRITORIES kladr on KLADR.ID = t.TO_416_FK "
  " where t.DATE_TO>SYSDATE");

  m_api->dbExecuteQuery(res,"delete from gl_dict_7_7_82_fortuneavto");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_7_7_82_fortuneavto", 0);
  for(qw->First(); !qw->Eof; qw->Next()) {
    q->Insert();

    for(int i=0; i < qw->Fields->Count; i++) q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;

    q->Post();
  }
  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}


//����������
void ReloadSpr7_4_20(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.autodealer");

  m_api->dbExecuteQuery(res,"delete from gl_dict_autodealer");
  for(int i=0; i<qw->RecordCount; i++,qw->Next())
        m_api->dbExecuteQuery(res,"insert into gl_dict_autodealer (id, auto_dealer_id, auto_dealer_name, sort_order) values ("
        + qw->FieldByName("id")->AsString + ","
        + qw->FieldByName("auto_dealer_id")->AsString + ","
        + "'"+ m_api->Internal_Prepare_SQL_Text(res,qw->FieldByName("auto_dealer_name")->AsString) + "',"
        + qw->FieldByName("sort_order")->AsString + ")");
  pSKK->dbCloseCursor(res,qw);
}

//����� ����������� � ��������
void ReloadSpr7_4_21(mops_api_014* m_api,mops_api_014*pSKK)
{
 int res;
 TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.autodealer_company");
 m_api->dbExecuteQuery(res,"delete from gl_dict_autodealer_company");
 for(int i=0; i<qw->RecordCount; i++,qw->Next())
 m_api->dbExecuteQuery(res," insert into gl_dict_autodealer_company (id,subject_federation_code_fk, auto_dealer_id_fk) values("
   + (qw->FieldByName("id")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("id")->AsString) + ","
   + (qw->FieldByName("subject_federation_code_fk")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("subject_federation_code_fk")->AsString) + ","
   + (qw->FieldByName("auto_dealer_id_fk")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("auto_dealer_id_fk")->AsString )+ ")");
  pSKK->dbCloseCursor(res,qw);
}

//�����
void ReloadSpr7_3_49(mops_api_014* m_api,mops_api_014* pSKK)
{
       int res;
       TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.banki");
        m_api->dbExecuteQuery(res,"delete from OSAGO_R_ref_fid_banki ");
        for(int i=0; i<qw->RecordCount; i++,qw->Next())
            m_api->dbExecuteQuery(res," insert into OSAGO_R_ref_fid_banki (id,code,name,sort_order,ref_code_fk_fk) values ("
            + (qw->FieldByName("id")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("id")->AsString) + ","
             "'" + m_api->Internal_Prepare_SQL_Text(res,qw->FieldByName("code")->AsString) + "',"
             "'" + m_api->Internal_Prepare_SQL_Text(res,qw->FieldByName("name")->AsString) + "',"
            + (qw->FieldByName("sort_order")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("sort_order")->AsString) + ","
            + (qw->FieldByName("ref_code")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("ref_code")->AsString) + ")");
          pSKK->dbCloseCursor(res,qw);
}


//������ ��������
void ReloadSpr7_4_24(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.other_partner");
  m_api->dbExecuteQuery(res,"delete from gl_dict_otherpartner");
  for(int i=0; i<qw->RecordCount;i++,qw->Next())
      m_api->dbExecuteQuery(res,"insert into gl_dict_otherpartner (ID, OTHER_PARTNER_ID, OTHER_PARTNER_NAME, SORT_ORDER) values("
      +(qw->FieldByName("id")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("id")->AsString) + ","
      +(qw->FieldByName("OTHER_PARTNER_ID")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("OTHER_PARTNER_ID")->AsString) + ","
      "'"+m_api->Internal_Prepare_SQL_Text(res,qw->FieldByName("OTHER_PARTNER_NAME")->AsString) + "',"
      +(qw->FieldByName("SORT_ORDER")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("SORT_ORDER")->AsString) + ")");
 pSKK->dbCloseCursor(res,qw);
}

//�������� ������ ��������� � ��������
void ReloadSpr7_4_25(mops_api_014* m_api,mops_api_014* pSKK)
{
 int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.other_partner_company");
  m_api->dbExecuteQuery(res,"delete from gl_dict_otherpartner_company");
  for(int i=0; i<qw->RecordCount;i++,qw->Next())
      m_api->dbExecuteQuery(res,"insert into gl_dict_otherpartner_company (ID, OTHER_PARTNER_ID_FK, SUBJECT_FEDERATION_CODE_FK) values("
      +(qw->FieldByName("id")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("id")->AsString) + ","
      +(qw->FieldByName("OTHER_PARTNER_ID_FK")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("OTHER_PARTNER_ID_FK")->AsString) + ","
      +(qw->FieldByName("SUBJECT_FEDERATION_CODE_FK")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("SUBJECT_FEDERATION_CODE_FK")->AsString) + ")");
 pSKK->dbCloseCursor(res,qw);
}


void ReloadSpr7_4_19(mops_api_014 *m_api,mops_api_014 *pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select * from apo.AUTODICTVEHICLEREGTYPE");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_AUTODICTVEHICLEREGTYPE");
  for(int i=0; i<qw->RecordCount;i++,qw->Next())
      m_api->dbExecuteQuery(res,"insert into OSAGO_R_AUTODICTVEHICLEREGTYPE (ID, VEHICLE_REGISTR_TYPE_ID, VEHICLE_REGISTR_TYPE_NAME,SORT_ORDER) values("
      +(qw->FieldByName("id")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("id")->AsString) + ","
      +(qw->FieldByName("VEHICLE_REGISTR_TYPE_ID")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("VEHICLE_REGISTR_TYPE_ID")->AsString) + ","
      +"'" + m_api->Internal_Prepare_SQL_Text(res,qw->FieldByName("VEHICLE_REGISTR_TYPE_NAME")->AsString) + "',"
      +(qw->FieldByName("SORT_ORDER")->AsString.IsEmpty()?AnsiString("NULL"):qw->FieldByName("SORT_ORDER")->AsString) + ")"
      );
 pSKK->dbCloseCursor(res,qw);
}
//------------------------------------------------------------------------------
//��������� �� �����-��
//------------------------------------------------------------------------------
void ReloadSpr7_9_24(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"SELECT * FROM RGSSCC.REF_PERSON_BO t1 LEFT JOIN RGSSCC.REF_SUBJECT_RF t2 ON t1.TO_414_FK_ = t2.SCC_ID where t1.SCC_STATUS = 0 AND t2.SCC_STATUS = 0");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_7_9_24");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_7_9_24", 0);

  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
    q->FieldByName("PERSON_ID")->Value = qw->FieldByName("PERSON_BO_ID")->Value;
    q->FieldByName("LNR")->Value = qw->FieldByName("LNR")->Value;
    q->FieldByName("EMPLOYEE")->Value = qw->FieldByName("EMPLOYEE")->Value;
    q->FieldByName("START_DATE")->Value = qw->FieldByName("START_DATE")->Value;
    q->FieldByName("END_DATE")->Value = qw->FieldByName("END_DATE")->Value;
    q->FieldByName("SUBJECT_FEDERATION_CODE")->Value = qw->FieldByName("SUBJECT_FEDERATION_CODE")->Value;
    q->Post();
  }

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

void ReloadSpr7_9_25(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"SELECT * FROM RGSSCC.REF_CLIENT_BO t1 "
            "LEFT JOIN RGSSCC.REF_SUBJECT_RF t2 ON t1.TO_414_FK_ = t2.SCC_ID "
            "where T1.SCC_STATUS=0 and T2.SCC_STATUS = 0");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_7_9_25");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_7_9_25", 0);

  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
    q->FieldByName("CLIENT_BA_ID")->Value = qw->FieldByName("CLIENT_BO_ID")->Value;
    q->FieldByName("CLIENT_NAME")->Value = qw->FieldByName("CLIENT_NAME")->Value;
    q->FieldByName("START_DATE")->Value = qw->FieldByName("START_DATE")->Value;
    q->FieldByName("END_DATE")->Value = qw->FieldByName("END_DATE")->Value;
    q->FieldByName("SUBJECT_FEDERATION_CODE")->Value = qw->FieldByName("SUBJECT_FEDERATION_CODE")->Value;
    q->FieldByName("CLIENT_INN")->Value = qw->FieldByName("CLIENT_INN")->Value;
    q->Post();
  }

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}

void ReloadSpr7_9_26(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  TADOQuery *qw=pSKK->dbGetCursor(res,"select bo.PROXY_BO_ID,bo.LNR,cl.CLIENT_BO_ID,  bo.START_DATE,bo.END_DATE,bo.CONTRACT_NUMBER,bo.CONTRACT_DATE "
        " from RGSSCC.REF_PROXY_BO bo "
        " join RGSSCC.REF_CLIENT_BO cl on cl.scc_ID = bo.TO_7_9_25_FK_ "
        " where  bo.scc_status=0 and cl.scc_status=0 ");
  m_api->dbExecuteQuery(res,"delete from OSAGO_R_7_9_26");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_7_9_26", 0);

  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
    q->FieldByName("PROXY_BA_ID")->Value = qw->FieldByName("PROXY_BO_ID")->Value;
    q->FieldByName("LNR")->Value = qw->FieldByName("LNR")->Value;
    q->FieldByName("CLIENT_BA_ID")->Value = qw->FieldByName("CLIENT_BO_ID")->Value;
    q->FieldByName("START_DATE")->Value = qw->FieldByName("START_DATE")->Value;
    q->FieldByName("END_DATE")->Value = qw->FieldByName("END_DATE")->Value;
    q->FieldByName("CONTRACT_NUMBER")->Value = qw->FieldByName("CONTRACT_NUMBER")->Value;
    q->FieldByName("CONTRACT_DATE")->Value = qw->FieldByName("CONTRACT_DATE")->Value;
    q->Post();
  }

  m_api->dbCloseCursor(res,q);
  pSKK->dbCloseCursor(res,qw);
}
//------------------------------------------------------------------------------
void ReloadSpr7_1_62(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  AnsiString qry =
    " SELECT aa.TAXI_ID, aa.TO_414_FK AS SUBJECT_FEDERATION_CODE, "
    "   aa.VIN, aa.BODY_NUMBER, aa.REG_NUMBER, bb.CODE, aa.MODEL_YEAR, "
    "   aa.LICENSE_ISSUED, aa.REASON, aa.NOTE, aa.START_DATE, aa.END_DATE "
    " FROM RGSSCC.REF_TAXI aa "
    "   LEFT JOIN APO.CARRIER_MODELS bb on bb.SCC_ID = aa.TO_513_FK_ ";
    //" WHERE sysdate BETWEEN NVL(aa.START_DATE, sysdate) and NVL(aa.END_DATE, sysdate) ";

  TADOQuery *qw=pSKK->dbGetCursor(res, qry);

  t_BL_DICT_api *bl_api = GetExternalBL_DICT(m_api);
  bl_api->dbExecuteQuery(res,"delete from gl_dict_black_list_ts_7_1_62");
  TADOQuery *q = bl_api->dbGetCursor( res, "select * from gl_dict_black_list_ts_7_1_62", 0);
  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
      //for(int i=0; i < qw->Fields->Count; i++)
        //q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;

    q->Fields->FieldByName("TAXI_ID")->Value = qw->Fields->FieldByName("TAXI_ID")->Value;
    q->Fields->FieldByName("SUBJECT_FEDERATION_CODE")->Value = qw->Fields->FieldByName("SUBJECT_FEDERATION_CODE")->Value;
    q->Fields->FieldByName("VIN")->Value = qw->Fields->FieldByName("VIN")->Value;
    q->Fields->FieldByName("BODY_NUMBER")->Value = qw->Fields->FieldByName("BODY_NUMBER")->Value;
    q->Fields->FieldByName("REG_NUMBER")->Value = qw->Fields->FieldByName("REG_NUMBER")->Value;
    q->Fields->FieldByName("CODE")->Value = qw->Fields->FieldByName("CODE")->Value;
    q->Fields->FieldByName("MODEL_YEAR")->Value = qw->Fields->FieldByName("MODEL_YEAR")->Value;
    q->Fields->FieldByName("LICENSE_ISSUED")->Value = qw->Fields->FieldByName("LICENSE_ISSUED")->Value;
    q->Fields->FieldByName("REASON")->Value = qw->Fields->FieldByName("REASON")->Value;
    q->Fields->FieldByName("NOTE")->Value = qw->Fields->FieldByName("NOTE")->Value;
    q->Fields->FieldByName("START_DATE")->Value = qw->Fields->FieldByName("START_DATE")->Value;
    q->Fields->FieldByName("END_DATE")->Value = qw->Fields->FieldByName("END_DATE")->Value;
    q->Post();
  }
  bl_api->dbCloseCursor(res,q);

  pSKK->dbCloseCursor(res,qw);
}
//------------------------------------------------------------------------------
void ReloadSpr7_1_65(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  AnsiString qry =
    " SELECT STOP_LIST_PERSON_ID, SUBJECT_FEDERATION_CODE, ORG_NAME, "
    "   LASTNAME, FIRSTNAME, SECONDNAME, BIRTHDATE, ITN, PSRN, "
    "   REASON, START_DATE, END_DATE "
    " FROM RGSSCC.REF_STOP_LIST_PERSON ";
    //" WHERE sysdate BETWEEN NVL(START_DATE, sysdate)  and NVL(END_DATE, sysdate) ";

  TADOQuery *qw=pSKK->dbGetCursor(res, qry);

  t_BL_DICT_api *bl_api = GetExternalBL_DICT(m_api);

  bl_api->dbExecuteQuery(res,"delete from gl_dict_black_list_persons_7_1_65");
  TADOQuery *q = bl_api->dbGetCursor( res, "select * from gl_dict_black_list_persons_7_1_65", 0);
  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
      for(int i=0; i < qw->Fields->Count; i++)
        q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
    q->Post();
  }
  bl_api->dbCloseCursor(res,q);

  pSKK->dbCloseCursor(res,qw);
}
//------------------------------------------------------------------------------
void ReloadSpr7_1_61(mops_api_014* m_api,mops_api_014* pSKK)
{
  int res;
  AnsiString qry =
    " SELECT SA.SPECIAL_AGENT_ID, TR.CASCO_TERRITORY_NAME AS TERRITORY_NAME,  "
    "   SA.FIO, SA.LNR, BR.BRANCH_CODE AS SKK, SA.START_DATE, SA.END_DATE "
    " FROM RGSSCC.REF_SPECIAL_AGENT SA "
    "   INNER JOIN RGSSCC.REF_BRANCHES BR ON BR.SCC_ID = SA.BRANCH_CODE "
    "   AND SA.START_DATE BETWEEN NVL(BR.DATE_FROM, SA.START_DATE) and NVL(BR.DATE_TO, SA.END_DATE) "
    "     INNER JOIN RGSSCC.REF_AUTODICTCASCOTERRITORY TR ON TR.SCC_ID = SA.CASCO_TERRITORY_ID "
    "     AND SA.START_DATE BETWEEN NVL(TR.DATE_FROM, SA.START_DATE) and NVL(TR.DATE_TO, SA.END_DATE) "
    "  WHERE SA.SCC_STATUS = 0 ";

  TADOQuery *qw=pSKK->dbGetCursor(res, qry);

  m_api->dbExecuteQuery(res,"delete from gl_dict_special_agent_7_1_61");
  TADOQuery *q = m_api->dbGetCursor( res, "select * from gl_dict_special_agent_7_1_61", 0);
  for(qw->First(); !qw->Eof; qw->Next())
  {
    q->Insert();
      for(int i=0; i < qw->Fields->Count; i++)
        q->Fields->Fields[i]->Value = qw->Fields->Fields[i]->Value;
    q->Post();
  }
  m_api->dbCloseCursor(res,q);

  pSKK->dbCloseCursor(res,qw);
}
//------------------------------------------------------------------------------
 /*
void ReloadSpr7_1_2(mops_api_014 *m_api,mops_api_014 *pSKK)
{
  int res;
  TADOQuery *qw_skk=pSKK->dbGetCursor(res,
                                    "select DCR.CANCEL_REASON_ID,DCR.CANCEL_REASON_NAME, DCR.CONTRACT_STATUS_ID,"
                                    " DCS.CONTRACT_STATUS_NAME, DCC.CONTRACT_CLASS_ID, DCC.CONTRACT_CLASS_NAME "
                                    " from  APO.DICTCANCELREASON dcr "
                                    " join   APO.dictcontractstatus dcs on DCR.CONTRACT_STATUS_ID=DCS.CONTRACT_STATUS_ID "
                                    " join   APO.dictcontractclass dcc on DCR.CONTRACT_CLASS_ID=DCC.CONTRACT_CLASS_ID  "
                                    " where DCR.CONTRACT_STATUS_ID='60' and  DCR.CONTRACT_CLASS_ID in ('2','5','6','8')");

  m_api->dbExecuteQuery(res,"delete from gl_dict_cancel_reason");
  TADOQuery *qw=m_api->dbGetCursor(res,"select * from gl_dict_cancel_reason",0);
  for(int i=0; i<qw_skk->RecordCount;i++,qw_skk->Next())
   {
    qw->Insert();
    for(int j=0; j<qw->Fields->Count;j++)
            qw->Fields->Fields[j]->Value=qw_skk->Fields->Fields[j]->Value;
    qw->Post();
   }
 pSKK->dbCloseCursor(res,qw_skk);
 m_api->dbCloseCursor(res,qw);
}   */




//7.5.5 C���� ����� � ����� ���  ref_dictblanktypeseries select  tab_755_fk_(�� �����)  where tabl_755_fk_(��� ���)
//7.4.9. ���� ���   rgsscc.ref_dictblanktype select id(��� ���)  where to_722_fk=55 use_arm=Y active_entry=Y
//7.5.4. ����� ���  ref_dictblankseries  select series_name where scc_id        date_to  date_from

/*  ���� �������

select CKK_7_4_9.BLANK_TYPE_ID as POLICY_TYPE_ID,
       CKK_7_4_9.BLANK_TYPE_NAME as POLICY_NAME_IN_BLANK,
       CKK_7_5_4.SERIES_NAME BSO_SERIES_IN_BLANK,
       case when CKK_7_4_9.BLANK_TYPE_NAME like '%5033%'
            then 80000
            when CKK_7_4_9.BLANK_TYPE_NAME like '%5034%'
            then 120000
            when CKK_7_4_9.BLANK_TYPE_NAME like '%5035%'
            then 200000
        end as LIABILITY,
       case when CKK_7_4_9.BLANK_TYPE_NAME like '%��������%'
            then 1
            when CKK_7_4_9.BLANK_TYPE_NAME like '%��������%'
            then 2
        end as LAYERS,
       CKK_7_5_5.START_DATE,
       CKK_7_5_5.END_DATE
from RGSSCC.REF_DICTBLANKTYPESERIES CKK_7_5_5,
     RGSSCC.REF_DICTBLANKSERIES CKK_7_5_4,
     RGSSCC.REF_DICTBLANKTYPE CKK_7_4_9
where CKK_7_5_5.SCC_STATUS = 0 and
      CKK_7_4_9.USE_ARM = 'Y' and
      CKK_7_4_9.ACTIVE_ENTRY = 'Y' and
      CKK_7_4_9.TO_722_FK_ = 29914437 and
      CKK_7_5_5.TAB_755_FK_ = CKK_7_5_4.SCC_ID and CKK_7_5_4.SCC_STATUS = 0 and
      CKK_7_5_5.TABL_755_FK_ = CKK_7_4_9.SCC_ID and CKK_7_4_9.SCC_STATUS = 0
order by 2, 3;



       + ����� 4000 1-�� 4000  �� 26    6001/6002??
*/
