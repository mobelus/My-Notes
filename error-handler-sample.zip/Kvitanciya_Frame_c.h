//---------------------------------------------------------------------------


#ifndef Kvitanciya_Frame_cH
#define Kvitanciya_Frame_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sFrameAdapter.hpp"
#include "ToolEdit.hpp"
#include <Mask.hpp>
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
//---------------------------------------------------------------------------
class TKvitanciya_Frame : public TFrame
{
__published:	// IDE-managed Components
   TsFrameAdapter *sFrameAdapter1;
   TLabel *Label4;
   TEdit *Num;
   TLabel *Label5;
   TsDateEdit *KDate;
private:	// User declarations
public:		// User declarations
        __fastcall TKvitanciya_Frame(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKvitanciya_Frame *Kvitanciya_Frame;
//---------------------------------------------------------------------------
#endif
