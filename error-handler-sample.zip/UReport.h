//---------------------------------------------------------------------------

#ifndef UReportH
#define UReportH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sCustomComboEdit.hpp"
#include "sMaskEdit.hpp"
#include "sTooledit.hpp"
#include <Mask.hpp>
#include "Tmops_api.h"
#include "CGAUGES.h"
//---------------------------------------------------------------------------
class TFReport : public TForm{
__published:	// IDE-managed Components
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TEdit *Edit1;
   TsDateEdit *sDateEdit1;
   TsDateEdit *sDateEdit2;
   TButton *Button1;
   TCGauge *CGauge;
   TLabel *Label4;
   TComboBox *ComboBox1;
   TLabel *Label5;
   TComboBox *ComboBox2;
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
private:	// User declarations
   double procent;
public:		// User declarations
  mops_api_014* m_api;
   bool PreViewFlag;
public:		// User declarations
   __fastcall TFReport(TComponent* Owner);
   void SetProcent(const double& val){ procent = val; }
};
//---------------------------------------------------------------------------
extern PACKAGE TFReport *FReport;
//---------------------------------------------------------------------------
#endif
