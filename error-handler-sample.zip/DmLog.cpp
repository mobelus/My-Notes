//---------------------------------------------------------------------------


#pragma hdrstop
#include "DmLog.h"

//---------------------------------------------------------------------------
DmErr::DmErr()
{
   Reset();
}
//---------------------------------------------------------------------------
void DmErr::operator()(const char* ds, const char* n, const char* m, int c)
{
   err = true;
   std::strncpy(description, ds, max - 1);
   std::strncpy(name, n, max - 1);
   std::strncpy(msg, m, max - 1);
   code = c;
}
//---------------------------------------------------------------------------
void DmErr::Reset()
{
   err = code = 0;
   description[0] = '\0';
   name[0] = '\0';
   msg[0] = '\0';
}
//---------------------------------------------------------------------------

/*-----------------------------------DmLog---------------------------------*/
//---------------------------------------------------------------------------
unsigned long DmLog::GetFileSize(const char* name)
{
   unsigned long ret(0);
   char ch;
   std::ifstream fin(name);
   if(!!fin)
      while(fin.get(ch)) ret++;
   return ret;
}
//---------------------------------------------------------------------------
void DmLog::WriteDateTime(const timeb* tmb)
{
   tm* t = localtime(&tmb->time);
   if(!!fout)
      fout << "   "
           << t->tm_year + 1900 << '.' << (t->tm_mon + 1) << '.' << t->tm_mday
           << '@' << t->tm_hour << '-' << t->tm_min << '.' << t->tm_sec
           << '.' << tmb->millitm
           << std::endl;
}
//---------------------------------------------------------------------------
void DmLog::WriteDateTime()
{
   timeb tmb;
   ftime(&tmb);
   WriteDateTime(&tmb);
}
//---------------------------------------------------------------------------
DmLog::DmLog()
   : lock(0), counter(0), idx(0), bf_size(0)
{
   lock = new DmSysCriticalSection;
}
//---------------------------------------------------------------------------
DmLog::DmLog(const char* name)
   : lock(0), counter(0), idx(0), bf_size(0)
{
   lock = new DmSysCriticalSection;
   Open(name);
   for(int i = 0; i < max_lines; i++)
      buff[i][0] = '\0';
}
//---------------------------------------------------------------------------
DmLog::~DmLog()
{
   delete lock;
   if(!!fout){
      fout << ++counter << ". " << "Log closed";
      WriteDateTime();
   }
}
//---------------------------------------------------------------------------
void DmLog::Open(const char* name)
{
   if(GetFileSize(name) < 1024 * 1024)
      fout.open(name, std::ios_base::app);
   else{
      CopyFile((static_cast<std::string>(name) + '_').c_str(), name, false);
      fout.open(name);
   }
   if(fout){
      fout << std::endl << ++counter << ". " << "Log open/created";
      WriteDateTime();
      fout.flush();
   }
}
//---------------------------------------------------------------------------
void DmLog::Write(const char* msg)
{
   lock->Acquire();

   if(!!fout){
      fout << ++counter << ". " << msg;
      WriteDateTime();
      fout.flush();
   }

   lock->Release();
}
//---------------------------------------------------------------------------
void DmLog::ToBuffer(const char* msg)
{
   lock->Acquire();

   if(max_lines == idx)
      idx = 0;
   ftime(bftm + idx);
   std::strncpy(buff[idx++], msg, max_line - 1);
   ++bf_size;

   lock->Release();
}
//---------------------------------------------------------------------------
void DmLog::_FlushBuffer()
{
   if(bf_size){
      if(!!fout){
         fout << ++counter << ". " << "BEGIN OF STACK";
         WriteDateTime();
      }
      for(int i = idx; i < max_lines && !!fout; i++){
         if(std::strlen(buff[i])){
            fout << ++counter << ". " << buff[i] << "   ";
            WriteDateTime(bftm+i);
         }
         buff[i][0] = '\0';
      }
      for(int i = 0; i < idx && !!fout; i++){
         if(std::strlen(buff[i])){
            fout << ++counter << ". " << buff[i];
            WriteDateTime(bftm+i);
         }
         buff[i][0] = '\0';
      }
      if(!!fout){
         fout << ++counter << ". " << "END OF STACK";
         WriteDateTime();
      }
   }
   bf_size = idx = 0;
   if(!!fout)
      fout.flush();
}
//---------------------------------------------------------------------------
void DmLog::FlushBuffer()
{
   lock->Acquire();
      _FlushBuffer();
   lock->Release();
}
//---------------------------------------------------------------------------
void DmLog::Write(const char* object, DmErr& err)
{
   lock->Acquire();

   if(!!fout){
      fout << ++counter << ". ";
      if(strlen(err.description))
         fout << err.description << ", ";
      if(object && strlen(object))
         fout << "OBJECT: " << '\"' << object << '\"' << ", ";
      fout << "NAME: " << '\"' << err.name << '\"' << ", DESCRIPTION: " << '\"' << err.msg << '\"' << ", code: " << '\"' << err.code << '\"';
      WriteDateTime();
      _FlushBuffer();
   }

   lock->Release();
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
