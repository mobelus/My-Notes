//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Calc_Descr_Frame_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sFrameAdapter"
#pragma resource "*.dfm"
TCalc_Descr_Frame *Calc_Descr_Frame;
//---------------------------------------------------------------------------
__fastcall TCalc_Descr_Frame::TCalc_Descr_Frame(TComponent* Owner) : TFrame(Owner)
{
}
//---------------------------------------------------------------------------

