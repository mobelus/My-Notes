//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UPolisNaBlanke.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRPolisNaBlanke *RPolisNaBlanke;
//---------------------------------------------------------------------------
__fastcall TRPolisNaBlanke::TRPolisNaBlanke(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TRPolisNaBlanke::Print_Form(long calc_id, bool Preview)
{
   int res;
   TADOQuery *qw = m_api->dbGetCursor(res,"select * from OSAGO_R_main where calc_id=" + IntToStr(calc_id));
   if(qw->IsEmpty()){
      m_api->dbCloseCursor(res, qw);
      return;
   }

   QRLabel01->Caption = qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime.FormatString("hh");
   QRLabel02->Caption = qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime.FormatString("nn");
   QRLabel01->Caption = AddSpases(QRLabel01->Caption, 3);
   QRLabel02->Caption = AddSpases(QRLabel02->Caption, 3);

   QRLabel03->Caption = AddSpases(qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime.FormatString("dd"),3);
   QRLabel04->Caption = AddSpases(qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime.FormatString("mm"),3);
   QRLabel05->Caption = AddSpases(qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime.FormatString("yy"),3);
   QRLabel06->Caption = AddSpases(qw->FieldByName("pol_zayav_srok_strah_po")->AsDateTime.FormatString("dd"),3);
   QRLabel07->Caption = AddSpases(qw->FieldByName("pol_zayav_srok_strah_po")->AsDateTime.FormatString("mm"),3);
   QRLabel08->Caption = AddSpases(qw->FieldByName("pol_zayav_srok_strah_po")->AsDateTime.FormatString("yy"),3);

   QRLabel09->Caption=AddSpases(qw->FieldByName("pol_zayav_per_isp_1_s")->AsDateTime.FormatString("dd"),3);
   QRLabel10->Caption=AddSpases(qw->FieldByName("pol_zayav_per_isp_1_s")->AsDateTime.FormatString("mm"),3);
   QRLabel11->Caption=AddSpases(qw->FieldByName("pol_zayav_per_isp_1_s")->AsDateTime.FormatString("yy"),3);
   QRLabel12->Caption=AddSpases(qw->FieldByName("pol_zayav_per_isp_1_po")->AsDateTime.FormatString("dd"),3);
   QRLabel13->Caption=AddSpases(qw->FieldByName("pol_zayav_per_isp_1_po")->AsDateTime.FormatString("mm"),3);
   QRLabel14->Caption=AddSpases(qw->FieldByName("pol_zayav_per_isp_1_po")->AsDateTime.FormatString("yy"),3);

   AnsiString str("-----");

   QRLabel15->Caption=(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime.FormatString("dd"),3):str);
   QRLabel16->Caption=(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime.FormatString("mm"),3):str);
   QRLabel17->Caption=(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime.FormatString("yy"),3):str);
   QRLabel18->Caption=(qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime.FormatString("dd"),3):str);
   QRLabel19->Caption=(qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime.FormatString("mm"),3):str);
   QRLabel20->Caption=(qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime.FormatString("yy"),3):str);

   QRLabel21->Caption=(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime.FormatString("dd"),3):str);
   QRLabel22->Caption=(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime.FormatString("mm"),3):str);
   QRLabel23->Caption=(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime.FormatString("yy"),3):str);
   QRLabel24->Caption=(qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime.FormatString("dd"),3):str);
   QRLabel25->Caption=(qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime.FormatString("mm"),3):str);
   QRLabel26->Caption=(qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime!=TDateTime(NULL)?AddSpases(qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime.FormatString("yy"),3):str);

   if( !qw->FieldByName("pol_zayav_strah_fio")->AsString.IsEmpty() && qw->FieldByName("pol_zayav_strah_fio")->AsString.Length()>60 ) QRLabel27->Font->Size = 8; else QRLabel27->Font->Size = 10;
   QRLabel27->Caption = qw->FieldByName("pol_zayav_strah_fio")->AsString;
   if( !qw->FieldByName("pol_zayav_sobstv_fio")->AsString.IsEmpty() && qw->FieldByName("pol_zayav_sobstv_fio")->AsString.Length()>60 ) QRLabel28->Font->Size = 8; else QRLabel28->Font->Size = 10;
   QRLabel28->Caption = qw->FieldByName("pol_zayav_sobstv_fio")->AsString;

   AnsiString markamodel("");
   if(qw->FieldByName("pol_zayav_ts_marka2")->AsString == "=") markamodel = qw->FieldByName("pol_zayav_ts_marka")->AsString;
   else markamodel = qw->FieldByName("pol_zayav_ts_marka2")->AsString;
   if(qw->FieldByName("pol_zayav_ts_model2")->AsString == "=") markamodel += "-"+qw->FieldByName("pol_zayav_ts_model")->AsString;
   else markamodel += "-"+qw->FieldByName("pol_zayav_ts_model2")->AsString;

   QRLabel29->Caption= markamodel;

   if( !qw->FieldByName("pol_zayav_ts_vin")->AsString.IsEmpty() )
     for(int i = 1; i < 18; i++) ((TQRLabel*)FindComponent("VIN" + IntToStr(i)))->Caption = qw->FieldByName("pol_zayav_ts_vin")->AsString.SubString(i, 1);

   if( qw->FieldByName("pol_zayav_ts_gosznak")->AsString.IsEmpty() )
     QRLabel31->Caption= AddSpases("---------",1);
   else QRLabel31->Caption = qw->FieldByName("pol_zayav_ts_gosznak")->AsString;



   QRLabel32->Caption=qw->FieldByName("pol_zayav_ts_doc_type")->AsString;
   QRLabel33->Caption=qw->FieldByName("pol_zayav_ts_PTS_ser")->AsString;
   QRLabel34->Caption=qw->FieldByName("pol_zayav_ts_PTS_num")->AsString;

   if(qw->FieldByName("pol_zayav_dop_tolko_sled_voditeli")->AsBoolean){
      QRLabel35->Caption = "";
      QRLabel36->Caption = "X";
      str = "-----------------------------------------------------------------";
      AnsiString str2("---"), str3("------------------");
      TADOQuery *qw_du = m_api->dbGetCursor(res, "select * from  OSAGO_R_dop_k_upr where calc_id="+ IntToStr(calc_id) + " order by num_dop_upr");
      for(int i = 0; i < 5; i++){
         TQRLabel *qr_num, *qr_dop, *qr_vu;
         AnsiString num, dop, vu;
         switch(i){
            case 0: qr_num = QRLabel37; qr_dop = QRLabel38; qr_vu = QRLabel39; break;
            case 1: qr_num = QRLabel40; qr_dop = QRLabel41; qr_vu = QRLabel42; break;
            case 2: qr_num = QRLabel43; qr_dop = QRLabel44; qr_vu = QRLabel45; break;
            case 3: qr_num = QRLabel46; qr_dop = QRLabel47; qr_vu = QRLabel48; break;
            case 4: qr_num = QRLabel49; qr_dop = QRLabel50; qr_vu = QRLabel51; break;
         }
         if(!qw_du->Eof){
            num = IntToStr(i + 1);
            dop = qw_du->FieldByName("f")->AsString + " " + qw_du->FieldByName("i")->AsString + " " + qw_du->FieldByName("o")->AsString
//              +  " (����� " + (qw_du->FieldByName("kbm")->AsString.IsEmpty() ? str2 : qw_du->FieldByName("kbm")->AsString) + ")"
                  ;
            vu = qw_du->FieldByName("prava_s")->AsString + " " + qw_du->FieldByName("prava_n")->AsString;
            vu = Trim(vu).IsEmpty() ? str3 : vu;
            qw_du->Next();
         }
         else{
            num = "-";
            dop = dop.StringOfChar('-', 65);
            vu  = vu.StringOfChar('-', 18);
         }
         qr_num->Caption = num; qr_dop->Caption = dop; qr_vu->Caption = vu;
      }
      m_api->dbCloseCursor(res, qw_du);
   }
   else{ // ���������� - �������������� �����
      QRLabel35->Caption="X";
      QRLabel36->Caption="";
      QRLabel37->Caption="-";
      QRLabel38->Caption="-----------------------------------------------------------------";
      QRLabel39->Caption="------------------";
      QRLabel40->Caption="-";
      QRLabel41->Caption="-----------------------------------------------------------------";
      QRLabel42->Caption="------------------";
      QRLabel43->Caption="-";
      QRLabel44->Caption="-----------------------------------------------------------------";
      QRLabel45->Caption="------------------";
      QRLabel46->Caption="-";
      QRLabel47->Caption="-----------------------------------------------------------------";
      QRLabel48->Caption="------------------";
      QRLabel49->Caption="-";
      QRLabel50->Caption="-----------------------------------------------------------------";
      QRLabel51->Caption="------------------";
   }

   QRLabel52->Caption = FormatFloat("#,##0.00", qw->FieldByName("calc_prem")->AsFloat );

   QRLabel53->Caption = "";

/*
   if(!qw->FieldByName("pol_zayav_pred_pol_num")->AsString.IsEmpty() && qw->FieldByName("calc_tip_ts")->AsString.Pos("�������") == 0){
      AnsiString kbm = FloatToStr(GetKbm(qw->FieldByName("calc_klass_kbm")->AsString, qw->FieldByName("calc_inostr_gosvo")->AsBoolean, qw->FieldByName("calc_in_gosvo_t")->AsString));
      QRLabel53->Caption = QRLabel53->Caption + "\r\n���= "+ kbm + ". ����������� ������  " + qw->FieldByName("pol_zayav_pred_pol_ser")->AsString+" " + qw->FieldByName("pol_zayav_pred_pol_num")->AsString;
   }
*/
   AnsiString osob_otmet_txt("");
   m_api->dbReadWriteInternalMemo(res, osob_otmet_txt, qw->FieldByName("osob_otmet_memoid")->AsInteger, true, "osago_r_memo");

   QRLabel53->Caption = "                                               " + QRLabel53->Caption + "\r\n" + osob_otmet_txt;
   if( qw->FieldByName("pricep")->AsString == "1" ) QRLabel53->Caption = QRLabel53->Caption + " �� ������������ � ��������.";
   if( !qw->FieldByName("operator_to")->AsString.Trim().IsEmpty() ) QRLabel53->Caption = QRLabel53->Caption + "\r�������� ��: "+qw->FieldByName("operator_to")->AsString+".";

   if( qw->FieldByName("calc_fizyur_lico")->AsString == "���������� ����" ) {
   if( qw->FieldByName("pol_zayav_ts_cel_isp")->AsString != "�����" ) QRLabel53->Caption =  QRLabel53->Caption + "�� � �������� ����� �� ������������.";
   QRLabel53->Caption =  QRLabel53->Caption + "� ��������� �������� ������� ���� ����������.";
   }

   if(!qw->FieldByName("pol_zayav_ts_kuzov")->AsString.IsEmpty())
        QRLabel53->Caption = QRLabel53->Caption + "� ������ " + qw->FieldByName("pol_zayav_ts_kuzov")->AsString +".";
   if(!qw->FieldByName("pol_zayav_ts_shassi")->AsString.IsEmpty())
        QRLabel53->Caption = QRLabel53->Caption + "� ����� (����) " + qw->FieldByName("pol_zayav_ts_shassi")->AsString +".";

   if(qw->FieldByName("status_dogovor")->AsInteger == 4) {//���������������
        AnsiString prichina = "����� ������ "+ qw->FieldByName("pol_zayav_pred_pol_ser")->AsString+"/"
                                              +qw->FieldByName("pol_zayav_pred_pol_num")->AsString + ".";

        QRLabel53->Caption = QRLabel53->Caption + prichina;

        if( !qw->FieldByName("pereoform_summ")->AsString.Trim().IsEmpty() && (qw->FieldByName("pereoform_summ")->AsFloat >0) )
          QRLabel53->Caption = QRLabel53->Caption + " �������: " + FormatFloat("#,##0.00", qw->FieldByName("pereoform_summ")->AsFloat );

    }

   TADOQuery *qw2 = m_api->dbGetCursor(res,"select * from OSAGO_R_main2 where calc_id=" + IntToStr(calc_id));
   if(qw2->IsEmpty()){
      m_api->dbCloseCursor(res, qw2);
   } else {
       //��� �����-������  ���� ���� ��� ������ ���� �������� �����
        AnsiString nomer = qw2->FieldByName("osago_payment_authorization_code")->AsString;
        if(res==0 && !nomer.IsEmpty()) {
           QRLabel53->Caption = QRLabel53->Caption + " ������ ����� ��� ���������� �� ����� �� ������: www.RGS.ru (����� � "+ qw->FieldByName("kvitanciya_num")->AsString +").";
        }

        QRLabel53->Caption = QRLabel53->Caption + "���: " + qw2->FieldByName("checksumm")->AsString + " " + qw->FieldByName("pol_zayav_pol_ser")->AsString + " " + qw->FieldByName("pol_zayav_pol_num")->AsString +".";

        m_api->dbCloseCursor(res, qw2);
   }








//   if(qw->FieldByName("rsa_kbmid")->AsString.Trim()!="")QRLabel53->Caption=    QRLabel53->Caption +"\r\n������������� �������={" + qw->FieldByName("rsa_kbmid")->AsString+"}";
    AnsiString mes = qw->FieldByName("pol_zayav_date_zayav")->AsDateTime.FormatString("mmmm").LowerCase();
    if(mes == "����" || mes=="������") mes = mes + "�";
    else { mes.SetLength(mes.Length()-1); mes = mes + "�"; }

   QRLabel54->Caption = qw->FieldByName("pol_zayav_date_zayav")->AsDateTime.FormatString("dd");
   QRLabel55->Caption = mes;
   QRLabel56->Caption = qw->FieldByName("pol_zayav_date_zayav")->AsDateTime.FormatString("yy");
   QRLabel57->Caption = qw->FieldByName("fio_rgs_pred_i")->AsString;
   QRLabel58->Caption = qw->FieldByName("pol_zayav_date_zayav")->AsDateTime.FormatString("dd");
   QRLabel59->Caption = mes;
   QRLabel60->Caption = qw->FieldByName("pol_zayav_date_zayav")->AsDateTime.FormatString("yy");

   if(qw->FieldByName("status_dogovor")->AsInteger==4 || qw->FieldByName("status_dogovor")->AsInteger==10) { //�������������� ��� ������� �� ���
      QRLabel58->Caption=qw->FieldByName("pereoform_date")->AsDateTime.FormatString("dd");

      mes = qw->FieldByName("pereoform_date")->AsDateTime.FormatString("mmmm").LowerCase();
      if(mes == "����" || mes=="������") mes = mes + "�";
        else { mes.SetLength(mes.Length()-1); mes = mes + "�"; }
      QRLabel59->Caption=mes;
      QRLabel60->Caption=qw->FieldByName("pereoform_date")->AsDateTime.FormatString("yy");
   }


   bool dvoinoi =  !qw->FieldByName("blanktype_id")->IsNull && qw->FieldByName("blanktype_id")->AsInteger == 1;

   m_api->dbCloseCursor(res, qw);
   m_api->QR_Form_Prepare(res, this, "����� �� ������");

   if(!Preview) {
        QR->Print();

       if( dvoinoi ) {
         ShowMessage("�������� ������ ���� ������");
         QR->Print();
       }

   }
   else {
        QR->Preview();

        if( dvoinoi ) {
         ShowMessage("�������� ������ ���� ������");
         QR->Preview();
       }

   }
}
//---------------------------------------------------------------------------
AnsiString TRPolisNaBlanke::AddSpases(AnsiString st, int num)
{
   AnsiString p_st(AnsiString::StringOfChar(' ', num)), res("");
   int l = st.Length();
   for(int i = 0; i < l; i++) res += (AnsiString(st[i + 1]) + p_st);
   return res;
}
//---------------------------------------------------------------------------
double TRPolisNaBlanke::GetKbm(AnsiString klass, bool inostr_gosvo, AnsiString inostr_gosvo_t)
{
   int res;
   AnsiString sql = "select tc.terr_id  from gl_dict_osagoterritorycoeff tc, gl_dict_osagoterritory t "
                    "where tc.parent_id = 0 and tc.terr_id = t.terr_id and is_foreign = 1 "
                    "and DATE() >= tc.start_date and DATE() <= iif(tc.end_date is null, DATE(), tc.end_date) "
                    " and trim(terr_name)='" + inostr_gosvo_t + "'"
                    " order by t.sort_order";
   int terr_id = inostr_gosvo ? m_api->dbGetIntFromQuery(res, sql) : 0;
   sql = "select coeff_val from OSAGO_R_AutoDictBonusMalus where terr_id = " + IntToStr(terr_id) + " and DATE() >= start_date and DATE() <= iif(end_date is null, DATE(), end_date) and trim(descriptio)='" + Trim(klass) + "' ";
   TADOQuery *qw_kbm = m_api->dbGetCursor(res, sql);
   if(qw_kbm->IsEmpty()){
      terr_id = 0;
      sql = "select coeff_val from OSAGO_R_AutoDictBonusMalus where terr_id = 0 and DATE() >= start_date and DATE() <= iif(end_date is null, DATE(), end_date) and trim(descriptio)='" + Trim(klass) + "' ";
      m_api->dbCloseCursor(res, qw_kbm);
      qw_kbm = m_api->dbGetCursor(res, sql);
   }
   double coeff = qw_kbm->FieldByName("coeff_val")->AsFloat;
   m_api->dbCloseCursor(res, qw_kbm);

   return coeff;
}
//---------------------------------------------------------------------------

