//---------------------------------------------------------------------------

#ifndef URastSelectH
#define URastSelectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFRastSelect : public TForm
{
__published:	// IDE-managed Components
        TRadioGroup *RadioGroup1;
        TButton *Button1;
        TButton *Button2;
private:	// User declarations


public:		// User declarations
        __fastcall TFRastSelect(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFRastSelect *FRastSelect;
//---------------------------------------------------------------------------
#endif
