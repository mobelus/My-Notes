//---------------------------------------------------------------------------
#pragma hdrstop
#include "Project_.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
__fastcall TProject::TProject(TWinControl* aParent, mops_api_018* aAPI, AnsiString aTableName, int aTypePr, AnsiString aProductIDList, AnsiString aTerrIDList)
{
   //AnsiString str = aParent->Name;

   Parent = aParent;
   TypePr = aTypePr;

   if(Parent){
      CBProjects = new TsComboBox(aParent);
      CBProjects->Parent = aParent;

      //CBProjects->Color = clYellow;

      CBProjects->BoundLabel->Caption = (aTypePr == 1) ? "������" : "���������";
      CBProjects->BoundLabel->Layout = sclTopLeft;
      CBProjects->BoundLabel->Active = true;
      CBProjects->Width    = 380;
      //CBProjects->Top      = 203;
      CBProjects->Top      = (Parent->Height - CBProjects->Height) - 5;
      CBProjects->Left     = (aTypePr == 1) ? 5 : 393;

      CBProjects->Anchors  = TAnchors() << akLeft << akTop << akRight;
      CBProjects->Style    = csDropDownList;
      CBProjects->OnChange = CBProjectsChange;

      ceKoef = new TsCalcEdit(aParent);
      ceKoef->Parent   = aParent;
      ceKoef->Width    = 60;
      ceKoef->Top      = 20;
      ceKoef->Left     = CBProjects->Left + CBProjects->Width + 10;
      ceKoef->Anchors  = TAnchors() << akTop << akRight;
      ceKoef->Enabled  = false;
      ceKoef->OnChange = ceKoefChange;
   }

   m_api = aAPI;

   TableName = aTableName;
   ProductIDList = aProductIDList;
   TerrIDList = aTerrIDList;
   TypePr = aTypePr;
   min_koef = max_koef = 0;
}
//---------------------------------------------------------------------------
bool __fastcall TProject::CalcKoefsExists()
{
   AnsiString lSQL = "select count(*) "
                              " from " + TableName + " "
                              " where product_id in (" + ProductIDList + ") "
                              " and (Ka_MIN<>1 or Ka_MAX<>1) "
                              " and Start_Date<Date() "
                              " and End_Date>Date() "
                              " and region_id in (" + TerrIDList + ")"
                              " and project_type_id=" + IntToStr(TypePr);

   if(m_api->dbGetIntFromQuery(res, lSQL))  return true;
   else                                     return false;
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetBounds(TRect* aRect, AnsiString aAlign)
{
   /*try{
      if(aRect){
         if(aRect->Top > 0)  gbProjects->Top = aRect->Top;
         if(aRect->Left > 0) gbProjects->Left = aRect->Left;
                if (aRect->Right - aRect->Left > 0)
                        gbProjects->Width = aRect->Right - aRect->Left;
                if (aRect->Bottom - aRect->Top > 0)
                        gbProjects->Height = aRect->Bottom - aRect->Top;
        }
        }
        catch(Exception& e)
        {
                ShowMessage(e.Message);
        }

        if (!aAlign.IsEmpty())
        {
                if (aAlign=="alNone")
                        gbProjects->Align = alNone;
                else if (aAlign=="alTop")
                        gbProjects->Align = alTop;
                else if (aAlign=="alBottom")
                        gbProjects->Align = alBottom;
                else if (aAlign=="alLeft")
                        gbProjects->Align = alLeft;
                else if (aAlign=="alRight")
                        gbProjects->Align = alRight;
        } */
}
TRect  __fastcall TProject::GetBounds()
{
   //return gbProjects->BoundsRect;
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetProductIDList(AnsiString aProductIDList)
{
   ProductIDList = aProductIDList;
   LoadCBProjects();
}
//---------------------------------------------------------------------------
void __fastcall TProject::LoadCBProjects()
{
   CBProjects->Clear();
   min_koef = max_koef = 0;
   ceKoef->Value = 0;
   ceKoef->Enabled = false;
   m_api->Fill_ComboBox_Int(res, CBProjects, "select project_id, project_name "
                                                  "from " + TableName + " "
                                                  "where product_id in (" + ProductIDList + ") "
                                                  "and start_date<Date() "
                                                  "and end_date>Date()"
                                                  "and region_id  in (" + TerrIDList+ ") and project_type_id =" + IntToStr(TypePr));
}
//---------------------------------------------------------------------------
double __fastcall TProject::GetKoef()
{
        if (CBProjects->ItemIndex < 0)
                return 0;
        return ceKoef->Value;
}
//---------------------------------------------------------------------------
void __fastcall TProject::CBProjectsChange(TObject* Sender)
{
        if (CBProjects->ItemIndex < 0)
        return;

        double min = m_api->dbGetFloatFromQuery(res,    " select ka_min  from " + TableName + " "
                                                        " where product_id in (" + ProductIDList + ") "
                                                        " and start_date<Date() "
                                                        " and end_date>Date()"
                                                        " and region_id  in (" + TerrIDList+ ") and project_type_id =" + IntToStr(TypePr)+
                                                        " and project_id=" + IntToStr((int)CBProjects->Items->Objects[CBProjects->ItemIndex]));

        double max = m_api->dbGetFloatFromQuery(res,    " select ka_min  from " + TableName + " "
                                                        " where product_id in (" + ProductIDList + ") "
                                                        " and start_date<Date() "
                                                        " and end_date>Date()"
                                                        " and region_id  in (" + TerrIDList+ ") and project_type_id =" + IntToStr(TypePr) +
                                                        " and project_id=" + IntToStr((int)CBProjects->Items->Objects[CBProjects->ItemIndex]));
        min_koef=min;
        max_koef=max;

        if (min == max)
        {
                ceKoef->Value = min;
                ceKoef->Enabled = false;
        }
        else
        {
                ceKoef->Enabled = true;
        }

        UserFunc();
}
//---------------------------------------------------------------------------
void __fastcall TProject::ceKoefChange(TObject* Sender)
{
   UserFunc();
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetKoefVisible(bool aValue)
{
   ceKoef->Visible = aValue;
}
//---------------------------------------------------------------------------
int __fastcall TProject::GetProjectID()
{
   return (CBProjects->ItemIndex > -1 ? (int)CBProjects->Items->Objects[CBProjects->ItemIndex] : -1);
}
//---------------------------------------------------------------------------
void __fastcall TProject::SetKoef(double value)
{
   if(value < min_koef ||  value > max_koef) return;

   ceKoef->Value = value;
   ceKoefChange(ceKoef);
}
//-----------------------------------------------------------------------------
bool __fastcall TProject::ValidateKoef(AnsiString &error_description)
{
   if(CBProjects->ItemIndex < 0) return false;

   if(ceKoef->Value < min_koef || ceKoef->Value > max_koef){
      error_description = "����������� �� "  + AnsiString(TypePr == 1 ? "������� " : "��������� ") + CBProjects->Text
                        + " ������ ���������� � ��������� �� "
                        + FormatFloat("##0.00", min_koef) + " �� " + FormatFloat("##0.00", max_koef);
      return false;
   }
   else{
      error_description = "";
      return true;
   }
}
//-----------------------------------------------------------------------------

