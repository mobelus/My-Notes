//---------------------------------------------------------------------------

#ifndef Log_Form_cH
#define Log_Form_cH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "sMemo.hpp"
#include "sPanel.hpp"
#include "sSkinProvider.hpp"
#include "sSpeedButton.hpp"
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TLog_Form : public TForm
{
__published:	// IDE-managed Components
        TsSkinProvider *sSkinProvider1;
        TsMemo *sMemo1;
        TsPanel *sPanel1;
        TsSpeedButton *sSpeedButton1;
    TButton *Button1;
    TSaveDialog *SaveDialog1;
        void __fastcall sSpeedButton1Click(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        int Error_Count;
        __fastcall TLog_Form(TComponent* Owner);
        void Add(AnsiString line,bool Error=false);
        void Clear();
};
//---------------------------------------------------------------------------
extern PACKAGE TLog_Form *Log_Form;
//---------------------------------------------------------------------------
#endif
