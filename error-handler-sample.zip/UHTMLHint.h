//---------------------------------------------------------------------------
#ifndef UHTMLHintH
#define UHTMLHintH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <OleCtrls.hpp>
#include <ExtCtrls.hpp>
#include "SHDocVw_OCX.h"
#include <Menus.hpp>
//#include  "shlwapi.h"
//#include <shlobj.h>
using namespace std;
#include <map>
#include <string>
typedef struct
        {
         string htmlcode;
         string formname;
         string html_content_position;
        } html_template;

typedef map <int, html_template> templates;
typedef map <int, string> topics;
//---------------------------------------------------------------------------
class TFHTMLHint : public TForm
{




__published:	// IDE-managed Components
        TCppWebBrowser *WB;
        void __fastcall WBDocumentComplete(TObject *Sender,
          LPDISPATCH pDisp, Variant *URL);
        void __fastcall WBWindowClosing(TObject *Sender,
          VARIANT_BOOL IsChildWindow, VARIANT_BOOL *Cancel);
        void __fastcall WBBeforeNavigate2(TObject *Sender,
          LPDISPATCH pDisp, Variant *URL, Variant *Flags,
          Variant *TargetFrameName, Variant *PostData, Variant *Headers,
          VARIANT_BOOL *Cancel);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations


        templates templ;
        topics topic;
        int templ_id;
        int topic_id;
        MESSAGE void __fastcall MWMActivate(TMessage &Msg);
        


public:		// User declarations
        __fastcall TFHTMLHint(TComponent* Owner);
        void __fastcall ShowHint(int id_templates,int id_topics, const templates &templ_, const topics &topic_,POINT* p=NULL);

         BEGIN_MESSAGE_MAP
                VCL_MESSAGE_HANDLER(WM_MOUSEACTIVATE,TMessage, MWMActivate);
        END_MESSAGE_MAP(TForm);


};
//---------------------------------------------------------------------------
extern PACKAGE TFHTMLHint *FHTMLHint;













//---------------------------------------------------------------------------
#endif
