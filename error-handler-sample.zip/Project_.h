//---------------------------------------------------------------------------
#ifndef Project_H
#define Project_H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include "sCustomComboEdit.hpp"
#include "sGroupBox.hpp"
#include "sLabel.hpp"
#include "sComboBox.hpp"
#include "sCurrEdit.hpp"
#include "Tmops_api.h"
//---------------------------------------------------------------------------
class TProject{
private:
   mops_api_018* m_api;

   AnsiString TableName;
   AnsiString ProductIDList;
   AnsiString TerrIDList;

   TWinControl* Parent;
   TsCalcEdit* ceKoef;

   double min_koef, max_koef;
   int res, TypePr;
private:
   void __fastcall LoadCBProjects();
   void __fastcall ceKoefChange(TObject* Sender);
public:
   TsComboBox* CBProjects;
public:
   __fastcall TProject(TWinControl* aParent, mops_api_018* aAPI, AnsiString aTableName,int aTypePr, AnsiString aProductIDList, AnsiString aTerrIDList);

   bool   __fastcall CalcKoefsExists();
   void   __fastcall CBProjectsChange(TObject* Sender);
   void   __fastcall SetBounds(TRect* aRect, AnsiString aAlign = "");
   TRect  __fastcall GetBounds();
   void   __fastcall SetProductIDList(AnsiString aProductIDList);
   void   __fastcall SetKoefVisible(bool aValue);
   double __fastcall GetKoef();
   int    __fastcall GetProjectID();
   void   __fastcall SetKoef(double value);
   bool   __fastcall ValidateKoef(AnsiString &error_description);
   void   __fastcall (__closure(*UserFunc))();
};
//---------------------------------------------------------------------------
#endif
