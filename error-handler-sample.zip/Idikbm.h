// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://dkbm:8080/KBM/SePeZ_RSA_KBM.dll/wsdl/Idikbm
// Codegen  : [wfDebug,wfVerbose,wfSkipHttpBindings,wfSkipUnusedTypes]
// Version  : 1.0
// (15.10.2012 09:36:20 - $Revision:   1.0.1.0.1.81  $)
// ************************************************************************ //

#ifndef   __Idikbm_h__
#define   __Idikbm_h__

#include <System.hpp>
#include <InvokeRegistry.hpp>
#include <XSBuiltIns.hpp>
#include <SoapHTTPClient.hpp>


namespace NS_Idikbm {


// ************************************************************************ //
// Namespace : urn:dikbm-Idikbm
// soapAction: urn:dikbm-Idikbm#GetKbmTo
// transport : http://schemas.xmlsoap.org/soap/http
// style     : rpc
// binding   : Idikbmbinding
// service   : Idikbmservice
// port      : IdikbmPort
// URL       : http://dkbm:8080/KBM/SePeZ_RSA_KBM.dll/soap/Idikbm
// ************************************************************************ //
__interface INTERFACE_UUID("{7822DE7F-1C7B-C03C-7AB1-2A8FFB522624}") Idikbm : public IInvokable
{
public:
  virtual AnsiString      GetKbmTo(const AnsiString data) = 0; 
};
typedef DelphiInterface<Idikbm> _di_Idikbm;

_di_Idikbm GetIdikbm(bool useWSDL=false, AnsiString addr="");



#endif // __Idikbm_h__

};     // Idikbm

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace NS_Idikbm;
#endif

 