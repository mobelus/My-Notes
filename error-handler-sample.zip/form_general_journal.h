//---------------------------------------------------------------------------

#ifndef form_general_journalH
#define form_general_journalH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cxClasses.hpp"
#include "cxControls.hpp"
#include "cxCustomData.hpp"
#include "cxData.hpp"
#include "cxDataStorage.hpp"
#include "cxDBData.hpp"
#include "cxEdit.hpp"
#include "cxFilter.hpp"
#include "cxGraphics.hpp"
#include "cxGrid.hpp"
#include "cxGridCustomTableView.hpp"
#include "cxGridCustomView.hpp"
#include "cxGridDBTableView.hpp"
#include "cxGridLevel.hpp"
#include "cxGridTableView.hpp"
#include "cxStyles.hpp"
#include <Buttons.hpp>
#include <DB.hpp>
#include <DBClient.hpp>
#include "cxCurrencyEdit.hpp"
#include "cxLabel.hpp"

#include "form_general.h"

//---------------------------------------------------------------------------
class TGeneral;

class TGeneralJournal : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *FA_grbox;
    TSpeedButton *delgeneral;
    TSpeedButton *newgeneral;
    TcxGrid *gridFortuna;
    TcxGridDBTableView *TableView1;
    TcxGridLevel *gridFortunaLevel1;
    TDataSource *DataSource1;
    TClientDataSet  *ClientDataSet1;
    TcxGridDBColumn *TableView1id;
    TcxGridDBColumn *TableView1strah;
    TcxGridDBColumn *TableView1status;
    TcxGridDBColumn *TableView1allprem;
    TSpeedButton *editgeneral;
    TSpeedButton *SpeedButton2;
    void __fastcall newgeneralClick(TObject *Sender);
    void __fastcall editgeneralClick(TObject *Sender);
    void __fastcall delgeneralClick(TObject *Sender);
    void __fastcall SpeedButton2Click(TObject *Sender);
private:	// User declarations
    mops_api_027 *m_api;
    int res;
    TGeneral *general;
    void TGeneralJournal::refresh();
public:		// User declarations
    __fastcall TGeneralJournal(TComponent* Owner, mops_api_027 *api);
    long getmaxid();
};
//---------------------------------------------------------------------------
extern PACKAGE TGeneralJournal *GeneralJournal;
//---------------------------------------------------------------------------
#endif
