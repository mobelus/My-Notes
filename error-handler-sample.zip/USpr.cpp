//---------------------------------------------------------------------------

#include <vcl.h>
#include <vector>
#pragma hdrstop

#include "USpr.h"
#include "Excel.h"
#include "UError.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sGauge"
#pragma resource "*.dfm"
TFSpr *FSpr;
AnsiString table_name[] = {"OSAGO_R_AutoDictOsagoTerritory","OSAGO_R_AutoDictOsagoTerritoryCoeff"};
//---------------------------------------------------------------------------
__fastcall TFSpr::TFSpr(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFSpr::Button1Click(TObject *Sender)
{
  TOpenDialog *od=new TOpenDialog(this);
  if(od->Execute())
  {

         Excel *ex=new Excel();
         ex->ExcelInit(od->FileName);
         TRect r=ex->GetActiverange2();
         AnsiString r_str=ex->GetActiverange();
         //������� ���������� �������� � TList
           CGauge2->MinValue=0;
          CGauge2->MaxValue=(r.bottom-1);
          CGauge2->Progress=0;
          CGauge2->Visible=true;

        /*
        TStringList *lst_col=new TStringList();
                for(int i=r.left;i<=r.bottom;i++) lst_col->Add(ex->GetExcelCell(1,i));
        */


         char dc=DecimalSeparator;
         DecimalSeparator='.';
        TADOQuery *qw_ins;
        int res;
        m_api->dbExecuteQuery(res,"delete from " +table_name[TabControl1->TabIndex]);
         AnsiString error="";
         for(int row=2; row<=r.bottom;row++)
         {
           DecimalSeparator='.';
            qw_ins=m_api->dbGetCursor(res,"select * from " + table_name[TabControl1->TabIndex]+ " where 1=-1",0);
            qw_ins->Insert();
             for(int col=r.left;col<=r.right;col++)// FieldByName(lst_col->Strings[col-1])
                 try{   qw_ins->Fields->Fields[col-1]->Value=ex->GetExcelCell(row,col);}catch(...)
                 {error=error + "������ " + IntToStr(row)+". �� ��������� �������� "+ ex->GetExcelCell(row,col) + " � ���� "+ qw_ins->Fields->Fields[col-1]->DisplayName +"\r\n" ;}
             //qw_ins->UpdateBatch();

                qw_ins->Post();
                m_api->dbCloseCursor(res,qw_ins);
            CGauge2->Progress++;
            Application->ProcessMessages();
         }
         ex->Close();
         delete ex;
         CGauge2->Visible=false;
                  DecimalSeparator=dc;
         TabControl1Change(NULL);
         if(error!="")
         {
          TFError *e=new TFError(this);
          e->Memo->Text=error;
          e->ShowModal();
          delete e;

         }

   }
  delete od;


}
//---------------------------------------------------------------------------
void __fastcall TFSpr::TabControl1Change(TObject *Sender)
{
  int res;
    TADOQuery *qw=m_api->dbGetCursor(res,"select * from " + table_name[TabControl1->TabIndex],0);
    TDataSource *ds=new TDataSource(this);
    ds->DataSet=qw;
    DBGrid1->DataSource=ds;
}
//---------------------------------------------------------------------------
void __fastcall TFSpr::FormShow(TObject *Sender)
{
TabControl1Change(NULL);        
}
//---------------------------------------------------------------------------
void __fastcall TFSpr::Button2Click(TObject *Sender)
{
     int res;   
     TADOQuery *qw_ins=m_api->dbGetCursor(res,"select * from " +table_name[TabControl1->TabIndex]+ " where 1=-1");
     vector <AnsiString> name_field;
     vector <AnsiString>::iterator i_name_field;
     for(int i=0; i<qw_ins->FieldCount;i++)
       if(qw_ins->Fields->Fields[i]->DataType==ftDateTime)
          name_field.push_back(qw_ins->Fields->Fields[i]->DisplayName);

     for(i_name_field=name_field.begin();i_name_field<name_field.end();i_name_field++)
     {

       int count= m_api->dbExecuteQuery(res,"update "+table_name[TabControl1->TabIndex]+" set " + (*i_name_field) + "=NULL  where " + (*i_name_field) + "=0");
       ShowMessage("� ���� " + (*i_name_field)  + " ��������� " + IntToStr(count) + " �������");
     }
     m_api->dbCloseCursor(res,qw_ins);
        
}
//---------------------------------------------------------------------------


