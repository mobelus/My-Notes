//---------------------------------------------------------------------------

#ifndef ns_form_warningH
#define ns_form_warningH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class Tform_ns_del_warning : public TForm
{
__published:	// IDE-managed Components
  TButton *Button1;
  TButton *Button2;
  TLabel *Label1;
  TLabel *Label2;
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall Tform_ns_del_warning(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tform_ns_del_warning *form_ns_del_warning;
//---------------------------------------------------------------------------
#endif
