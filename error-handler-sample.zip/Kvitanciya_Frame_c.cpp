//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Kvitanciya_Frame_c.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "sFrameAdapter"
#pragma link "ToolEdit"
#pragma link "sCustomComboEdit"
#pragma link "sMaskEdit"
#pragma link "sTooledit"
#pragma resource "*.dfm"
TKvitanciya_Frame *Kvitanciya_Frame;
//---------------------------------------------------------------------------
__fastcall TKvitanciya_Frame::TKvitanciya_Frame(TComponent* Owner)
        : TFrame(Owner)
{
}
//---------------------------------------------------------------------------
