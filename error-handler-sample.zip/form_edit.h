//---------------------------------------------------------------------------

#ifndef form_editH
#define form_editH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

//---------------------------------------------------------------------------
class TFormEdit : public TForm
{
__published:	// IDE-managed Components
  TGroupBox *GroupBox1;
  TCheckBox *CheckBox1;
  TCheckBox *CheckBox2;
  TCheckBox *CheckBox3;
  TCheckBox *CheckBox4;
  TCheckBox *CheckBox5;
  TButton *Button1;
  TButton *Button2;
  TCheckBox *CheckBox6;
  TCheckBox *CheckBox7;
  TCheckBox *CheckBox8;
  TCheckBox *CheckBox9;
  TCheckBox *CheckBox10;
  TCheckBox *CheckBox11;
  TCheckBox *CheckBox13;
  TLabel *Label1;
  TLabel *Label2;
    TCheckBox *CheckBox14;
        TCheckBox *CheckBox15;
  void __fastcall CheckBox1Click(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
        void __fastcall CheckBox15Click(TObject *Sender);
        void __fastcall CheckBox8Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  long edittype;
  __fastcall TFormEdit(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormEdit *FormEdit;
//---------------------------------------------------------------------------
#endif
