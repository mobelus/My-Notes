//---------------------------------------------------------------------------
#pragma hdrstop

#include "tools.h"
#include <vcl.h>
#include "ToolEdit.hpp"
#include <DateUtils.hpp>

#define DEBUG 0


AnsiString MYGLOBAL::NADO_OSMOTRET_TS = "������� � ���������� ������� �� ����� ���� �������� ������ ����� ���������� ������� ��.\n����������, ��� ������ �� ���������� �������������� ����� � ���� ��������� ��� � ���� �� ������� ���� ������� ���� � ���� ������ ������������� ��������� �� ����������� �����.";

//��������� ���������� �������� �������� ��� ��� ������ � ����
void MYGLOBAL::FLK_INIT() {

//� ��g id_entity
//    vinSTOPchars.clear();
    mapentity.clear();
    vinSTOPchars.clear();
    bodySTOPchars.clear();
    shassiSTOPchars.clear();

//vin
    AnsiString sql = "select ch from gl_dict_FLK where id_entity=1 and id_validation=1 and (start_date<= DATE() or start_date is null) and (end_date>= DATE() or end_date is null)";
    int res=0;
    TADOQuery *qw=m_api->dbGetCursor(res,sql);
    for(qw->First(); !qw->Eof; qw->Next()) {
       vinSTOPchars.insert( qw->Fields->Fields[0]->AsString[1] );
    }
    m_api->dbCloseCursor(res,qw);
//body
    sql = "select ch from gl_dict_FLK where id_entity=2 and id_validation=1 and (start_date<=DATE() or start_date is null) and (end_date>=DATE() or end_date is null)";
    qw=m_api->dbGetCursor(res,sql);
    for(qw->First(); !qw->Eof; qw->Next()) {
       bodySTOPchars.insert( qw->Fields->Fields[0]->AsString[1] );
    }
    m_api->dbCloseCursor(res,qw);
//shassi
    sql = "select ch from gl_dict_FLK where id_entity=3 and id_validation=1 and (start_date<=DATE() or start_date is null) and (end_date>=DATE() or end_date is null)";
    qw=m_api->dbGetCursor(res,sql);
    for(qw->First(); !qw->Eof; qw->Next()) {
       shassiSTOPchars.insert( qw->Fields->Fields[0]->AsString[1] );
    }
    m_api->dbCloseCursor(res,qw);

    mapentity.insert(std::make_pair( 1, vinSTOPchars) );
    mapentity.insert(std::make_pair( 2, bodySTOPchars) );
    mapentity.insert(std::make_pair( 3, shassiSTOPchars) );

}

bool MYGLOBAL::FLK_CHARCHECK(int entity_id,char ch) {
    if( mapentity.count(entity_id) >0) {
//       map<int, set<char> >::iterator it;
//            it = mapentity.find(entity_id);
//            set<char> fset = it->second;
//            int size = fset.size();
//            int cnt  = fset.count(ch);
       return mapentity.find(entity_id)->second.count(ch) > 0;
       }
    else false;
}

bool MYGLOBAL::FLK_CHECK(int entity_id,float val) {

     AnsiString sql = "select char from gl_dict_FLK where id_entity=1 and id_validation=1 and (start_date<= DATE() or start_date is null) and (end_date>= DATE() or end_date is null)";
    int res=0;
    TADOQuery *qw=m_api->dbGetCursor(res,sql);
    for(qw->First(); !qw->Eof; qw->Next()) {
       vinSTOPchars.insert( qw->Fields->Fields[0]->AsString[1] );
    }
    m_api->dbCloseCursor(res,qw);

}


bool MYGLOBAL::areOnlyNumbers(const AnsiString s)
{
  if(s.IsEmpty()) return false;

  for(int i=1; i<=s.Length(); i++)
  {
    if( !(
           (s[i] >= '0' && s[i] <= '9')
    // ||  (s[i] >= 'a' && s[i] <= 'z')
    // ||  (s[i] >= 'A' && s[i] <= 'Z')
    // ||  (s[i]=='_') || (s[i]=='-') || (s[i]=='.')
         )
     )
    {
      return false;
    }
  }

  return true;
}


bool MYGLOBAL::isCheckSummEmpty(AnsiString& checksumm, long id_calc)
{
   int res;
   AnsiString st;
   TADOQuery *q = m_api->dbGetCursor(res, st.sprintf("select checksumm from OSAGO_R_main2 where calc_id=%i", id_calc));
   checksumm = q->FieldByName("checksumm")->AsString;

   m_api->dbCloseCursor(res, q);
   return (checksumm.IsEmpty() || checksumm == "NULL" || checksumm == "Null");
}


bool MYGLOBAL::calcCheckSumm_(AnsiString& checksumm, long id_calc)
{
   int res = 0;
   AnsiString osago_prem_int = IntToStr( (int) (m_api->dbGetFloatFromQuery(res, "select calc_prem from osago_r_main where calc_id=" +IntToStr(id_calc))));
   AnsiString codemodel = m_api->dbGetStringFromQuery(res,"select pol_zayav_code_model from osago_r_main where calc_id=" +IntToStr(id_calc));
   if(!codemodel.IsEmpty())
   {
     while(codemodel.Length() < 9) //���� ���������� ������� ������ �.�. ��� ���� 9������ ��� �������� � ����� ������ ��������� ����������
       codemodel = "0" + codemodel;
   }

   TADOQuery *q = m_api->dbGetCursor( res, "select * from OSAGO_R_main where calc_id=" + IntToStr(id_calc) );
   AnsiString strDEInsDate = (q->FieldByName("pol_zayav_srok_strah_s")->AsDateTime).FormatString("ddmmyyyy");  //DEInsBDate->Date.FormatString("ddmmyyyy");
   //AnsiString strPolSer = (q->FieldByName("pol_zayav_pol_ser")->AsString);
   //AnsiString strPolNum = (q->FieldByName("pol_zayav_pol_num")->AsString);

   // ��� = ����������(��� ������ ���������� + ���� ������ ����������� (�) � ������� �������� + ��������� ������ �� ��������)
   // �����
   AnsiString str_in = codemodel  + strDEInsDate + osago_prem_int;
   // ������
   //AnsiString str_in = strPolSer + strPolNum + strDEInsDate + osago_prem_int;

   checksumm = m_api->GetCrc16ForPolisSign(res, str_in);


   m_api->dbCloseCursor(res, q);
   return (!checksumm.IsEmpty() && checksumm!="NULL" && checksumm!="Null");

   // ��������, 2-�� ���������, 1 ���.�����
}



//�� 5.4.15 OSAGO_R_SPECIALCLIENTS   id,clients_name,db_inn     �� ���  db_inn  ��� �� ��� ��� ����� ���� ������..
bool MYGLOBAL::inblacklist(AnsiString fio, AnsiString dr) {

    AnsiString sql = "select count(*) from OSAGO_R_SPECIALCLIENTS where clients_name='"+fio+"' and ( db_inn='"+dr + "' or db_inn IS NULL)";
    int res=0;
    int cnt = m_api->dbGetIntFromQuery(res, sql);
    return cnt>0;
}

void MYGLOBAL::show(int indx) {
    switch(indx) {
       case 0: {
            ShowMessage("loadf mainwinfc:recalc " + IntToStr(MYGLOBAL::counter[indx]) );
        } break;
       case 1: {
            ShowMessage("oncreate Tcalc classcalcosago:recalc " + IntToStr(MYGLOBAL::counter[indx]) );
        } break;
    }

    for(int i=0; i<10; i++) MYGLOBAL::counter[i] = 0;
}

bool MYGLOBAL::isnotallowedword(AnsiString str) {
    for(int i=0; i<16;i++)
        if(not_allowed_word[i] == str) return true;

    return false;
}

AnsiString MYGLOBAL::getnotallowedword() {
    AnsiString str = "";
    for(int i=0; i <16;i++)
        str+= not_allowed_word[i] + ",";

    return str;
}


AnsiString utf8tocp1251(const char *str) {
  AnsiString res;
  int result_u, result_c;
  result_u = MultiByteToWideChar(CP_UTF8, 0, str, -1, 0, 0);
  if(!result_u)
    return 0;
  wchar_t *ures = new wchar_t[result_u];
  if(!MultiByteToWideChar(CP_UTF8, 0, str, -1, ures, result_u))
    {
      delete[] ures;
      return 0;
    }
  result_c = WideCharToMultiByte(1251, 0, ures, -1, 0, 0, 0, 0);
  if(!result_c)
    {
      delete[] ures;
      return 0;
    }
  char *cres = new char[result_c];
  if(!WideCharToMultiByte(1251, 0, ures, -1, cres, result_c, 0, 0))
    {
      delete[] ures;
      delete[] cres;
      return 0;
    }
  delete[] ures;
  res = AnsiString(cres);
  delete[] cres;
  return res;
}



bool SaveTextToFile(AnsiString _FileName, AnsiString _dataToWrite)
{
	HANDLE hFile;
	BOOL bErrorFlag = FALSE;
            // name to write  // open for writing  //not share  // default security
	hFile = CreateFile(_FileName.c_str(), GENERIC_WRITE,     0, NULL,
            // create new file only    // normal file         // no attr. template
                        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hFile == INVALID_HANDLE_VALUE)
    {
        //DisplayError(TEXT("CreateFile"));
        //printf(TEXT("Terminal failure: Unable to open file \"%s\" for write.\n"), _FileName);
        return false;
    }

    //_tprintf(TEXT("Writing %d bytes to %s.\n"), dwBytesToWrite, argv[1]);

	DWORD dwBytesToWrite = (DWORD)(_dataToWrite.Length());
	DWORD dwBytesWritten = 0;
                 // open file handle // start of data to write  // number of bytes to write // number of bytes that were written
	bErrorFlag = WriteFile(      hFile, _dataToWrite.c_str(),   dwBytesToWrite,             &dwBytesWritten,  NULL); // no overlapped structure

    if (FALSE == bErrorFlag)
    {
        //DisplayError(TEXT("WriteFile"));
        //printf("Terminal failure: Unable to write to file.\n");
		return false;
    }
    else
    {
        if (dwBytesWritten != dwBytesToWrite)
        {
            // This is an error because a synchronous write that results in
            // success (WriteFile returns TRUE) should write all data as
            // requested. This would not necessarily be the case for
            // asynchronous writes.
            //printf("Error: dwBytesWritten != dwBytesToWrite\n");
			return false;
		}
        else
        {
            //_tprintf(TEXT("Wrote %d bytes to %s successfully.\n"), dwBytesWritten, _FileName);
        }
    }

    CloseHandle(hFile);
	return true;
}


bool AddTextToFile(AnsiString _FileName, AnsiString _dataToWrite)
{
	HANDLE hFile;
	BOOL bErrorFlag = FALSE;
	// name to write  // open for writing  //not share  // default security
	hFile = CreateFile(_FileName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL,
		// create new file only    // normal file         // no attr. template
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		hFile = CreateFile(_FileName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL,
			// create new file only    // normal file         // no attr. template
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			NULL);

		//DisplayError(TEXT("CreateFile"));
		//printf(TEXT("Terminal failure: Unable to open file \"%s\" for write.\n"), _FileName);
	}

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return false;
	}

	//_tprintf(TEXT("Writing %d bytes to %s.\n"), dwBytesToWrite, argv[1]);
    _dataToWrite += "\n";
	DWORD dwBytesToWrite = (DWORD)(_dataToWrite.Length());
	//DWORD dwBytesWritten = 0;
	DWORD dwBytesWritten = SetFilePointer(hFile, 0, NULL, FILE_END); //set pointer position to end file
	// open file handle // start of data to write  // number of bytes to write // number of bytes that were written
	bErrorFlag = WriteFile(hFile, _dataToWrite.c_str(), dwBytesToWrite, &dwBytesWritten, NULL); // no overlapped structure

	if (FALSE == bErrorFlag)
	{
		//DisplayError(TEXT("WriteFile"));
		//printf("Terminal failure: Unable to write to file.\n");
		return false;
	}
	else
	{
		if (dwBytesWritten != dwBytesToWrite)
		{
			// This is an error because a synchronous write that results in
			// success (WriteFile returns TRUE) should write all data as
			// requested. This would not necessarily be the case for
			// asynchronous writes.
			//printf("Error: dwBytesWritten != dwBytesToWrite\n");
			return false;
		}
		else
		{
			//_tprintf(TEXT("Wrote %d bytes to %s successfully.\n"), dwBytesWritten, _FileName);
		}
	}

	CloseHandle(hFile);
	return true;
}


//bool MyLogMsg(AnsiString _FileName, AnsiString _dataToWrite)
bool MyLogMsg(AnsiString _dataToWrite, AnsiString _FileName)
{
  return AddTextToFile(_FileName, _dataToWrite);
}



//��������� ������ � � �=�������������� ��� ���� ����������� ����������
void parsechangexml(AnsiString in_xml,AnsiString changedate, TStringList* newdop) {
    _di_IXMLDocument XMLDoc = NewXMLDocument();
    XMLDoc->Active = true;
    XMLDoc->LoadFromXML(in_xml);
    _di_IXMLNode Root, node, node2,node3;

    Root = XMLDoc->DocumentElement; //log
    node=Root->ChildNodes->FindNode("persons");
/*<persons>
    <person id="0037880aad37f015116317882" type_role="3" act="1">
      <full_name old="" new="������ ����� ��������"></full_name>
      <document_type old="" new=""></document_type>
      <document_series old="" new=""></document_series>
      <document_number old="" new=""></document_number>
    </person>
  </persons>
*/
    node2 = node->ChildNodes->FindNode("person");
    while(node2) {
        node3 = node2->ChildNodes->FindNode("full_name");
        AnsiString oldfio = AnsiString(node3->Attributes["old"]);
        AnsiString newfio = AnsiString(node3->Attributes["new"]);

        bool isnewdop = oldfio.IsEmpty();
        if(isnewdop) {
             newdop->Values[newfio] = changedate;
        }

        node2 = node2->NextSibling();
    }

}

//0.0.0.2 XML
long MYGLOBAL::LoadDataFromARM0002(AnsiString st, bool fromfile)
{
   int res, i_val;
   long id=0;
   TDate oplatadate2; //���� ������(���������) ������ ���� ������������� ����� ���
   bool isProsrochenPerviyPeriod(false); 
   TDate dt1_s=0,dt1_e=0,dt2_s=0,dt2_e=0,dt3_s=0,dt3_e=0;

   if(st.IsEmpty()) st = m_api->Get_Data_From_ARM_Form(res);
   if(st.IsEmpty()) return 0;
   AnsiString dtformat = "yyyy.MM.dd hh:mm:dd";

   _di_IXMLDocument XMLDoc = NewXMLDocument();
   TADOQuery *qw = NULL;
   TADOQuery *qw2= NULL;
   try {
      DWORD start = GetTickCount();

      XMLDoc->Active = true;
      if(fromfile) XMLDoc->LoadFromFile(st);
      else if(DEBUG == 1) {
        XMLDoc->LoadFromFile(st);
      } else {
        XMLDoc->LoadFromXML(st);
        try {
           XMLDoc->SaveToFile(m_api->Excel_tmp_path + "\\LoadDataFromARM0002.xml");
        } catch(Exception& ex) { }
      }

      _di_IXMLNode Root, node, node2,node3,node4;

      Root = XMLDoc->DocumentElement;
      node=Root->ChildNodes->FindNode("policys");
      Root=node;
      node=Root->ChildNodes->FindNode("policy");
      Root=node;

//�������� - ��������� ��������� ���.
      if(is_general) {
        bool notUL=false;
            node2 = node->ChildNodes->FindNode("persons");
            node3 = node2->ChildNodes->FindNode("person");
            bool innandname_sovpal;
            while(node3) {
                 bool isstrahovatel = node3->ChildNodes->FindNode("is_insured")->Text == AnsiString("1");
                 bool isowner = node3->ChildNodes->FindNode("is_owner")->Text == AnsiString("1");
                 bool isdopuch = node3->ChildNodes->FindNode("is_permitted")->Text == AnsiString("1");
                 bool isyur = node3->ChildNodes->FindNode("is_juridical")->Text == AnsiString("1");

                 if( (isstrahovatel || isowner) && !isyur ) {
                        notUL=true;
                        break;
                 }

                 if( isstrahovatel ) {
                       innandname_sovpal = node3->ChildNodes->FindNode("inn")->Text == MYGLOBAL::strah_inn &&
                                   node3->ChildNodes->FindNode("last_name")->Text == MYGLOBAL::strah_name;
                 }

                 node3 = node3->NextSibling();
            }

            node2 = node->ChildNodes->FindNode("autovehicles");
            node3 = node2->ChildNodes->FindNode("autovehicle");
            bool is_transit = AnsiString(node3->ChildNodes->FindNode("transit")->Text) == AnsiString("1");


        if(notUL) {
            ShowMessage("� ���� �������� ������������ ��� ����������� ���-����. � ����� �� ��������� ��������� ����� ��������.");

            delete XMLDoc;
            return 0;
        }

        if(!innandname_sovpal) {
            ShowMessage("��� ������������ �� ������.");

            delete XMLDoc;
            return 0;
        }

        if(is_transit != MYGLOBAL::is_transit) {
            ShowMessage("���� �������� ���������� �� ������������(�� ���� ���������� � ����� �����������.");

            delete XMLDoc;
            return 0;
        }

    }

      id = m_api->dbInsert_Empty_Calc(res);
      m_api->dbExecuteQuery(res, "insert into OSAGO_R_main (calc_id) values (" + IntToStr(id) + ")");

      AnsiString sql = "select calc_id,status_dogovor,calc_dopusk_bez_ogran,pol_filial_name,fio_rgs_pred_i,pol_zayav_osob_otmet,produkt,no_contact,pol_zayav_pol_ser,pol_zayav_pol_num,pol_zayav_date_zayav,pol_zayav_pred_pol_ser,pol_zayav_pred_pol_num"
                             ",pol_zayav_pred_pol_SK,contract_payed_count,date_load_arm,pol_zayav_srok_strah_s,pol_zayav_srok_strah_po,pol_zayav_klass_kbm,pol_zayav_dop_tolko_sled_voditeli"
                              ",rast_date,project_id,sale_channel_id,sale_channel,blanktype_id,Kvitanciya_date,pol_zayav_payment,pol_zayav_payment_doc,seria_pp,Kvitanciya_num,calc_prem,"
                              "branch_name,branch_addr,branch_phone,rsa_kbmid"
                              " from OSAGO_R_main where calc_id=" + IntToStr(id);

      qw = m_api->dbGetCursor(res, sql, 0, 1);
      qw->Edit();

      m_api->dbExecuteQuery(res, "insert into OSAGO_R_main2 (calc_id) values (" + IntToStr(id) + ")");


//��������� 2�� ��������������   ============================================

//-----------------------------------------
//����.�������������� ���� ����
//��������� ����� ������ - ��� ��� ������ ��������������?
//��� ����������� ����������� ��� ����� ����� ���� �������� ����������� �����������. ��� ������� ����� �� ���� ������ �������� ���� ��� ������ 3� ���(���=1.7 � ��� ������ �� ���������), � ����� �������� � ��������� � ���=1.0 (���� ��� 3+ ����)
//� ����� ��� ��� �������� ����� ����� �� ����������� ���� ������ ��������, � ���� �������� ����� �������
//-----------------------------------------
      TStringList* newdop = new TStringList(); //��� ����� ������ ���� ����� ���������� ���� ����
      bool is2pereoformlenie(false);
      node = Root->ChildNodes->FindNode("agreements");
      if(node) {
      node2 = node->ChildNodes->FindNode("agreement");
      if(node2) {

      is2pereoformlenie=true;

      AnsiString perispend1;
      AnsiString oplatadate2_str;

//����������� ���� ���������� ������� �������
      node3 = Root->ChildNodes->FindNode("autovehicles")->ChildNodes->FindNode("autovehicle")->ChildNodes->FindNode("usage_end_date"); //autovehicles->autovehicle->usage_end_date
      TDate period1end(0);
      if(node3) {
         perispend1 = node3->Text;
         period1end = StrToDateFmt(dtformat, perispend1);
      }

//����������� ������ ���� ������
      node3 = Root->ChildNodes->FindNode("paymentdatas")->ChildNodes->FindNode("paymentdata");
      if(node3) {
        node3 = node3->NextSibling();
        if(node3) {
            oplatadate2_str = AnsiString(node3->Attributes["payment_date"]);
            oplatadate2 = StrToDateFmt(dtformat, oplatadate2_str);
        }
      }

//���������� ���� �� ���������
      isProsrochenPerviyPeriod = period1end < oplatadate2;

      qw2 = m_api->dbGetCursor(res, "select * from OSAGO_R_main2 where calc_id=" + IntToStr(id), 0, 1);
      qw2->Edit();
      qw2->FieldByName("is_2pereoformlenie")->AsInteger = is2pereoformlenie;
      qw2->FieldByName("isProsrochenPerviyPeriod")->AsInteger = isProsrochenPerviyPeriod;
      qw2->Post();
      m_api->dbCloseCursor(res, qw2);
      qw2=NULL;

      while(node2) {
          //����� ���� ��������������
           AnsiString agreement_start_date = AnsiString(node2->Attributes["agreement_start_date"]);

          //change_log - <![CDATA[ xml ]]> � ������� ����� ����� �������� �����������(��� ����������..) ���������� ������ ������� - ��� ����������� ��� ������ ����������
//      	<agreements>
//				<agreement agreement_type_id="101" agreement_series="���" agreement_number="0346920825" agreement_start_date="2015.11.07 00:00:00" agreement_end_date="2016.05.04 23:59:59" description="" change_size_premium="" change_log="&lt;![CDATA[]]&gt;"/>
//			</agreements>

          if( node2->HasAttribute("change_log") ) { //�� ����� ��� ���� ��������
            AnsiString str = AnsiString(node2->Attributes["change_log"]);
              if(str.Length() > 20) { //���� ������ ���������� ������ ���� xml�� ��������� ���� <![CDATA[]]>
         // str = utf8tocp1251(str.c_str());
                  str = StringReplace(str,"<![CDATA[","",TReplaceFlags()<<rfReplaceAll);
                  str = StringReplace(str,">]]>",">",TReplaceFlags()<<rfReplaceAll);

                  parsechangexml(str,agreement_start_date,newdop);
              }
          }
          node2 = node2->NextSibling();
      }
      }
      }

//=====================================================

      qw2 = m_api->dbGetCursor(res, "select * from OSAGO_R_main2 where calc_id=" + IntToStr(id), 0, 1);
      qw2->Edit();

//��� �������� �������� ����� ����� ���������� �������������
      qw2->FieldByName("prev_skk")->AsString = Root->ChildNodes->FindNode("branch_code")->Text;

      qw->FieldByName("pol_filial_name")->AsString = m_api->vrGetVariable(res, "OSAGO_filial__rgs_name");
      qw->FieldByName("fio_rgs_pred_i")->AsString=m_api->dbGetStringFromQuery(res, "select name from _mops_polzovateli_ where id="+ m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));

    //  qw->FieldByName("pol_zayav_osob_otmet")->AsString = empty_str; ����� �����?

      if(AnsiString(Root->ChildNodes->FindNode("product_class_id")->Text) == "2" )
          qw->FieldByName("produkt")->AsString = "1"; //������ �����
      else if(AnsiString(Root->ChildNodes->FindNode("product_class_id")->Text) == "1" )
          qw->FieldByName("produkt")->AsString = "2"; //������ �������

 //������������ ����. �� ��� ��������? ���� ������ ������ ��� �������� ���.
      qw->FieldByName("no_contact")->AsString = Root->ChildNodes->FindNode("sms_sending")->Text;

      node = Root->ChildNodes->FindNode("kbm_rsa_id");
      if(node)
          qw->FieldByName("rsa_kbmid")->AsString = AnsiString(node->Text);

      qw->FieldByName("pol_zayav_pol_ser")->AsString = AnsiString(Root->ChildNodes->FindNode("policy_series")->Text).Trim();
      qw->FieldByName("pol_zayav_pol_num")->AsString = AnsiString(Root->ChildNodes->FindNode("policy_number")->Text).Trim();

      qw->FieldByName("pol_zayav_date_zayav")->AsDateTime = StrToDateFmt(dtformat, Root->ChildNodes->FindNode("policy_date")->Text);

      node = Root->ChildNodes->FindNode("quotes_date");
      if(fromfile && node) {   //�� ���� ��������� ���� ��������� �����������
        qw->FieldByName("pol_zayav_date_zayav")->AsDateTime = StrToDateFmt(dtformat, Root->ChildNodes->FindNode("quotes_date")->Text);
      }

      if( Root->ChildNodes->FindNode("prev_contract_series") )
          qw->FieldByName("pol_zayav_pred_pol_ser")->AsString = AnsiString(Root->ChildNodes->FindNode("prev_contract_series")->Text).Trim();
      if( Root->ChildNodes->FindNode("prev_contract_number") )
          qw->FieldByName("pol_zayav_pred_pol_num")->AsString = AnsiString(Root->ChildNodes->FindNode("prev_contract_number")->Text).Trim();

      qw->FieldByName("status_dogovor")->AsString = "1"; //���������������

      node = Root->ChildNodes->FindNode("prev_insurer");
      if( node )
          qw->FieldByName("pol_zayav_pred_pol_SK")->AsString = AnsiString(node->Text).Trim();

      node = Root->ChildNodes->FindNode("contract_payed_count");
      if(node)
          qw->FieldByName("contract_payed_count")->AsInteger = StrToIntDef(AnsiString(node->Text).Trim(),0);

      if(!fromfile) qw->FieldByName("date_load_arm")->AsDateTime=Date();

      AnsiString ps = AnsiString(Root->ChildNodes->FindNode("policy_start_date")->Text);

      qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime =  StrToDateFmt(dtformat, ps);
      AnsiString ppo = AnsiString(Root->ChildNodes->FindNode("policy_end_date")->Text);

      qw->FieldByName("pol_zayav_srok_strah_po")->AsDateTime = StrToDateFmt(dtformat, ppo);

      node = Root->ChildNodes->FindNode("bonus_malus_coeff_id");
      AnsiString kbm="";
      float coeff_val(0.0f);
      if(node && !AnsiString(node->Text).Trim().IsEmpty() ) {
           kbm = m_api->dbGetStringFromQuery(res, "select malus_val from OSAGO_R_autodictbonusmalus where malus_id=" + AnsiString(node->Text).Trim());
           coeff_val = m_api->dbGetFloatFromQuery(res, "select coeff_val from OSAGO_R_autodictbonusmalus where terr_id=0 and malus_val=" + kbm);
      }

      if(kbm.IsEmpty()) {
          node = Root->ChildNodes->FindNode("rsa_bonus_malus_id");
          if(node && !AnsiString(node->Text).Trim().IsEmpty() ) {
                AnsiString rsakbm = m_api->dbGetStringFromQuery(res, "select malus_val from OSAGO_R_autodictbonusmalus where malus_id=" + AnsiString(node->Text).Trim());
                float rsacoeff_val = m_api->dbGetFloatFromQuery(res, "select coeff_val from OSAGO_R_autodictbonusmalus where terr_id=0 and malus_val=" + rsakbm);

                if(rsacoeff_val<coeff_val)
                    coeff_val = rsacoeff_val;
          }
      }

//TODO ������ ��� ����?
      bool limited =  AnsiString(Root->ChildNodes->FindNode("limited_drivers")->Text) == "0";
      qw->FieldByName("calc_dopusk_bez_ogran")->AsBoolean = limited;
      bool doptolkovoditeli = AnsiString(Root->ChildNodes->FindNode("limited_drivers")->Text) == "1";
      qw->FieldByName("pol_zayav_dop_tolko_sled_voditeli")->AsBoolean = doptolkovoditeli;

      node = Root->ChildNodes->FindNode("cancel_date");
      if(node)
        qw->FieldByName("rast_date")->AsString = StrToDateFmt(dtformat, AnsiString(node->Text).c_str());

      node=Root->ChildNodes->FindNode("project_id");
      qw->FieldByName("project_id")->AsInteger=(node!=0?StrToIntDef(AnsiString(node->Text),0):0);

      node = Root->ChildNodes->FindNode("sale_channel_type2008_name");
      if(node && TryStrToInt(node->Text, i_val)){
         qw->FieldByName("sale_channel_id")->AsInteger = i_val;
         qw->FieldByName("sale_channel")->AsString = m_api->dbGetStringFromQuery(res, "select name_kanal from gl_dict_kanal_prodag where id=" + IntToStr(i_val));
      }


/*  option_id	������� �������� �����������	VARCHAR2 (7 Byte)
    ���� ���� ���, ������������� ""��������������"""
*/
    //  node = Root->ChildNodes->FindNode("option_id");
      qw->FieldByName("blanktype_id")->AsInteger = 1;//node ? AnsiString(node->Text).ToIntDef(0) : 0;


      node = Root->ChildNodes->FindNode("paymentdatas")->ChildNodes->FindNode("paymentdata");

      //contract_status_id 20 = �����������, �� �� �������  ����� ��������� �� ����

      if(node) {
//� ��� � ����� 1���� ���� ������ �.�.  ���� ������� ��������� � 2������ (���� ���������  paymentdata)  �� ����� ������ �� ������ ������  + ��������� ������ �� �������
      bool isfirst=true;
      double allsumm=0;

      while(node) {
            if(isfirst) {
              if(fromfile) {

                if( node->Attributes["date_of_check"].IsNull() ) {
                    ShowMessage("��� xml �� � �����(��� �������� date_of_check)");
                    m_api->dbCloseCursor(res, qw2);
                    return 0;
                }

                AnsiString attrdate = node->Attributes["date_of_check"];
                AnsiString attrcode = node->Attributes["payment_authorization_code"];
              //  TryStrToDateTime(attrdate,dt);
                qw2->FieldByName("osago_date_of_check")->AsDateTime = StrToDateFmt(dtformat, attrdate);
                qw2->FieldByName("osago_payment_authorization_code")->AsString = attrcode;
              }
           //   TryStrToDateTime(AnsiString(node->Attributes["payment_date"]),dt);
              qw->FieldByName("Kvitanciya_date")->AsDateTime= StrToDateFmt(dtformat, AnsiString(node->Attributes["payment_date"]));

              qw->FieldByName("pol_zayav_payment")->AsString=(node!=0?m_api->dbGetStringFromQuery(res,"select oplaty_name from OSAGO_R_tip_oplaty where id="+ IntToStr(StrToIntDef( AnsiString(node->Attributes["payment_type_id"]) ,0))):empty_str);
              qw->FieldByName("pol_zayav_payment_doc")->AsString=(node!=0?m_api->dbGetStringFromQuery(res,"select dokument_name from OSAGO_R_tip_platezhnogo_dokumenta where id="+ IntToStr(StrToIntDef( AnsiString(node->Attributes["payment_document_type_id"]) ,0))):empty_str);
        //���������� �� 2: payment_document_number="7003 02207983"
              TStringList *sl=new TStringList();
              sl->Text = StringReplace( AnsiString(node->Attributes["payment_document_number"])," ","\r\n",TReplaceFlags()<<rfReplaceAll);
              if(sl->Count>0) {
                 if( sl->Count==1 ) { //���� ������ �����?
                   qw->FieldByName("Kvitanciya_num")->AsString= sl->Strings[0];  //�����
                 }  else qw->FieldByName("seria_pp")->AsString= sl->Strings[0];   //�����
              }
              if(sl->Count>1) qw->FieldByName("Kvitanciya_num")->AsString= sl->Strings[1];  //�����
              delete sl; sl=NULL;
            } else {
                 oplatadate2 = StrToDateFmt(dtformat, AnsiString(node->Attributes["payment_date"]));
            }
            AnsiString strprem = AnsiString(node->Attributes["payment_sum_rur"]);
            strprem = StringReplace(  StringReplace( strprem , ".", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll), ",", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll);

            //���� �������� �� ������ ��� �� ����������� ����� �� ������ ������ ������ � �������� � 1) ���� ��������� 2)��� ���� ���������� 3) �������� ��� ���������
            //�.�. � ������ ������������ ������ ��� ���� �����������(��������������? � ����� �������? ���������?)
            //������ ����� ������ ��� 99% �������� �� ���������, � ���� � osago_r_main2 ���������� ���� �� ������������ is_2pereoformlenie isProsrochenPerviyPeriod
            //TODO ����� ���� ��� ���.��������.��� �������� ���� �������� � �������� �� ����������� � �� ����� �������������� ��� ������...

            //if(isfirst && is2pereoformlenie && isProsrochenPerviyPeriod) {
                //�� ��������� ������ ������ ��� 2�������������� � ���������� ��������� ������� ��.������ �� ������� 26.02.2016 � ���-�����
            //} else {
                allsumm += StrToFloat(strprem);
            //}
        node = node->NextSibling();
        isfirst=false;
      }
      qw->FieldByName("calc_prem")->AsFloat = StrToFloat(allsumm);//strprem);//allsumm;
      if(fromfile) {  //������ ������ �� xml
        qw2->FieldByName("prem_fromsite")->Value = qw->FieldByName("calc_prem")->Value;
      }
   }//paymentdata!=null


      /*������ ��������� �� �����, ��� �� ����� ������ ��� ��������������� � ������������.
      �������� ��� ���������� ������ � ������������ � ������ ���������*/
      
      node=Root->ChildNodes->FindNode("autovehicles");
      if(node)
      {
        node=node->ChildNodes->FindNode("autovehicle");
        if(node)
        {
                node2=node->ChildNodes->FindNode("riskobjects");
                if(node2)
                {
                        node2=node2->ChildNodes->FindNode("riskobject");
                        if(node2)
                        {
                                double prem=0.0;
                                while(node2)
                                {
                                        AnsiString PremStr=AnsiString(node2->Attributes["premium_rur"]);
                                        PremStr=StringReplace(PremStr,",",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll);
                                        PremStr=StringReplace(PremStr,".",AnsiString(DecimalSeparator),TReplaceFlags()<<rfReplaceAll);
                                        prem+= m_api->Round(StrToFloat(PremStr));
                                        try{node2= node2->NextSibling();} catch(...){node2=NULL;}
                                }
                                qw->FieldByName("calc_prem")->AsFloat = prem;
                                if(fromfile)   //������ ������ �� xml
                                qw2->FieldByName("prem_fromsite")->Value = qw->FieldByName("calc_prem")->Value;
                        }
                }
        }
      }
      qw2->Post();
      m_api->dbCloseCursor(res, qw2);
      qw2=NULL;


//TODO OTO_branch_code
                 AnsiString name("");
                 AnsiString phone = m_api->dbGetStringFromQuery(res, "select mobile_phone from _mops_polzovateli_ where id="+ m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));
                 AnsiString skk = m_api->dbGetStringFromQuery(res, "select skk from _mops_polzovateli_ where id="+ m_api->vrGetVariable(res,"_mops_global_tekushi_polzovatel_id_"));

                 mops_api_014* branch_api = (mops_api_014*)m_api->glDic_Get_API(res,"���������� �������������/������");
                 AnsiString baddr("");
                 if(res==0 && branch_api!=NULL) {
                   baddr = branch_api->dbGetStringFromQuery(res, "select ADDRESS from branches where BRANCH_CODE='"+ skk +"'");
                   name = branch_api->dbGetStringFromQuery(res, "select FULL_NAME from branches where BRANCH_CODE='"+ skk +"'");
                   delete branch_api; branch_api=NULL;
                 }

                 if(phone.Trim() == "8-   -   -") phone="";
                 qw->FieldByName("branch_name")->AsString=name;
                 qw->FieldByName("branch_addr")->AsString=baddr;
                 qw->FieldByName("branch_phone")->AsString=phone;



      qw->Post();
      m_api->dbCloseCursor(res, qw);
      qw=NULL;


                //<contract_payed_count>0</contract_payed_count>
                //<contract_payed_sum>0</contract_payed_sum>

                 //node=Root->ChildNodes->FindNode("contract_payed_count");
                 //qw->FieldByName("ts_count_damage_im")->AsInteger = node!=0 ? StrToIntDef(node->Text,0) : 0;
                 //node=Root->ChildNodes->FindNode("COUNT_DAMAGE_ZD");
                 //qw->FieldByName("ts_count_damage_zd")->AsInteger=(node!=0?StrToIntDef(node->Text,0):0);
                 //node=Root->ChildNodes->FindNode("COUNT_DAMAGE_OPEN");
                 //qw->FieldByName("ts_count_damage_open")->AsInteger=(node!=0?StrToIntDef(node->Text,0):0);
                 //node=Root->ChildNodes->FindNode("contract_payed_sum");
                 //qw->FieldByName("ts_loss")->AsFloat=(node!=0?StrToFloatDef( StrToFloatStr(node->Text),0.0):0.0);
                 //node=Root->ChildNodes->FindNode("DAMAGE_OPEN");
                 //qw->FieldByName("ts_damage_open")->AsFloat=(node!=0?StrToFloatDef( StrToFloatStr(node->Text),0.0):0.0);

/*
                 node=Root->ChildNodes->FindNode("AUTO_DEALER_ID");
                 qw->FieldByName("autodealer_id")->AsInteger=(node!=0?StrToIntDef(AnsiString(node->Text),0):0);

                 node=Root->ChildNodes->FindNode("OTHER_PARTNER_ID");
                 qw->FieldByName("other_partner_id")->AsInteger=(node!=0?StrToIntDef(AnsiString(node->Text),0):0);

                 node=Root->ChildNodes->FindNode("BANK_ID");
                 qw->FieldByName("bank_id")->AsInteger=(node!=0?StrToIntDef(AnsiString(node->Text),0):0);

                 qw->FieldByName("partner_analiz")->AsBoolean=(qw->FieldByName("autodealer_id")->AsInteger+qw->FieldByName("other_partner_id")->AsInteger+qw->FieldByName("bank_id")->AsInteger)>0;
*/

      sql = "select ts_count_damage_im,ts_loss,calc_id,pol_zayav_ts_vin,pol_zayav_ts_marka,pol_zayav_ts_model,pol_zayav_ts_marka2,pol_zayav_ts_model2,pol_zayav_code_marka,pol_zayav_code_model,pol_zayav_ts_type_id,calc_tip_ts,calc_moshnost_ls"
                             ",pol_zayav_ts_tehosmort_month,pol_zayav_ts_tehosmort_year,calc_moshnost_kvt,pol_zayav_ts_god,pol_zayav_ts_shassi,pol_zayav_ts_kuzov,pol_zayav_ts_kategor,pol_zayav_ts_kvo_mest,pol_zayav_ts_max_mass,pol_zayav_ts_doc_type"
                             ",pol_zayav_ts_PTS_ser,pol_zayav_ts_PTS_num,pol_zayav_ts_PTS_date,gosregznak,pol_zayav_ts_gosznak,pol_zayav_ts_cel_isp,pol_zayav_ts_v_arendu,calc_sled_k_mr,calc_inostr_gosvo"
                             ",calc_in_gosvo_t,pricep,pol_zayav_per_isp_1_s,pol_zayav_per_isp_1_po,pol_zayav_per_isp_2_s,pol_zayav_per_isp_2_po,pol_zayav_per_isp_3_s,pol_zayav_per_isp_3_po"
                             ",pol_zayav_srok_strah_s,pol_zayav_srok_strah_po,pol_zayav_per_isp_2_enabled,pol_zayav_per_isp_3_enabled,kladr,calc_grub_narushen,calc_per_isp_ts,deadline,pol_zayav_ts_tehosmort_num,pricep"
                                    " from OSAGO_R_main where calc_id=" + IntToStr(id);

      qw = m_api->dbGetCursor(res, sql, 0, 1);
      qw->Edit();

//������ �� ��������
      node=Root->ChildNodes->FindNode("contract_payed_count");
      qw->FieldByName("ts_count_damage_im")->AsInteger = node!=0 ? StrToIntDef(node->Text,0) : 0;
      node=Root->ChildNodes->FindNode("contract_payed_sum");
      qw->FieldByName("ts_loss")->AsFloat=(node!=0?StrToFloatDef( StrToFloatStr(node->Text),0.0):0.0);
//TC
      node2 = Root->ChildNodes->FindNode("autovehicles")->ChildNodes->FindNode("autovehicle");

      if(!node2) ShowMessage("� ������������ xml ��� ���������� �� ��! ��� <autovehicles> ����.");
      else {
/* ���� ����� vin ���������� � XTA �� �� ��� ����� ������� ��� ����� ���� ������� ���� �������� �� ���(� �� ��� �� ������� ������ �� ��� �����) � ���� ���� ������� �� ������)... */
      AnsiString vin = AnsiString(node2->ChildNodes->FindNode("vin")->Text).Trim();
      vin = StringReplace(vin,"�", "X",TReplaceFlags()<<rfReplaceAll);
      vin = StringReplace(vin,"�", "T",TReplaceFlags()<<rfReplaceAll);
      vin = StringReplace(vin,"�", "A",TReplaceFlags()<<rfReplaceAll);
      vin = StringReplace(vin,"�", "H",TReplaceFlags()<<rfReplaceAll);
      qw->FieldByName("pol_zayav_ts_vin")->AsString       = vin;
//=================
//     qw->FieldByName("is_to")->AsInteger = 1; //sd   809,775 �.�. ��������� �������� ��������� ������ �� ��!

      qw->FieldByName("pol_zayav_ts_marka")->AsString     = node2->ChildNodes->FindNode("vehicle_brand_name")->Text;
      qw->FieldByName("pol_zayav_ts_model")->AsString     = node2->ChildNodes->FindNode("vehicle_model_name")->Text;
      qw->FieldByName("pol_zayav_ts_marka2")->AsString    = qw->FieldByName("pol_zayav_ts_marka")->AsString;
      qw->FieldByName("pol_zayav_ts_model2")->AsString    = qw->FieldByName("pol_zayav_ts_model")->AsString;
      qw->FieldByName("pol_zayav_code_marka")->AsString   = m_api->dbGetStringFromQuery(res,"select code from gl_dict_carrier_models where brand_name='"+qw->FieldByName("pol_zayav_ts_marka")->AsString+"'");
      qw->FieldByName("pol_zayav_code_model")->AsString   = node2->ChildNodes->FindNode("rsa_code")->Text;

      qw->FieldByName("pol_zayav_ts_type_id")->AsString   = node2->ChildNodes->FindNode("vehicle_type_id")->Text;
      qw->FieldByName("calc_tip_ts")->AsString = m_api->dbGetStringFromQuery(res,"select veh_full from OSAGO_R_AutoDictOsagoVehType where vehtype_id="+ qw->FieldByName("pol_zayav_ts_type_id")->AsString );

      node3 = node2->ChildNodes->FindNode("engine_power_hp");
      if(node3 && !node3->Text.IsEmpty())
      qw->FieldByName("calc_moshnost_ls")->AsFloat  = StrToFloat(    StringReplace(  StringReplace( AnsiString(node3->Text) , ".", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll), ",", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll)    );

      node3 = node2->ChildNodes->FindNode("engine_power_kw");
      if(node3 && !node3->Text.IsEmpty())
      qw->FieldByName("calc_moshnost_kvt")->AsFloat = StrToFloat(    StringReplace(  StringReplace( AnsiString(node3->Text) , ".", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll), ",", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll)    );

      if(fromfile) { //����� ������ "2009"
        qw->FieldByName("pol_zayav_ts_god")->AsString = AnsiString(node2->ChildNodes->FindNode("construction_date")->Text);
      } else { //uxml "2009.01.01 23:03:01"
      //  TryStrToDateTime(AnsiString(node2->ChildNodes->FindNode("construction_date")->Text), dt);
        qw->FieldByName("pol_zayav_ts_god")->AsString = YearOf( StrToDateFmt(dtformat, AnsiString(node2->ChildNodes->FindNode("construction_date")->Text) ) );
      }

      qw->FieldByName("pol_zayav_ts_shassi")->AsString    = node2->ChildNodes->FindNode("chassis_number")->Text;
      qw->FieldByName("pol_zayav_ts_kuzov")->AsString     = node2->ChildNodes->FindNode("body_number")->Text;

     // AnsiString catts = m_api->dbGetStringFromQuery(res, "SELECT full_name_ from OSAGO_R_CARRIER_CATEGORIES where code='"+
      //                                             node2->ChildNodes->FindNode("vehicle_type_id")->Text +"'" );
     // qw->FieldByName("pol_zayav_ts_kategor")->AsString   = catts;
      AnsiString kat = m_api->dbGetStringFromQuery(res,"select type from OSAGO_R_AutoDictOsagoVehType where vehtype_id="+ qw->FieldByName("pol_zayav_ts_type_id")->AsString );
      if(!kat.Trim().IsEmpty()) {
          AnsiString tskat =  "��������� \""+ kat + "\"";
          qw->FieldByName("pol_zayav_ts_kategor")->AsString = tskat;
      }

      qw->FieldByName("pol_zayav_ts_kvo_mest")->AsString  = node2->ChildNodes->FindNode("number_of_seats")->Text;

      node3 = node2->ChildNodes->FindNode("allowed_mass");
      if(node3 && !node3->Text.IsEmpty())
        qw->FieldByName("pol_zayav_ts_max_mass")->AsInteger = (int) StrToFloat( StringReplace(  StringReplace( AnsiString(node3->Text) , ".", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll), ",", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll) );

      node3 = node2->ChildNodes->FindNode("vehicle_registration_type_id");

      bool pol_zayav_ts_doc_type=false;
      if(node3) {
          pol_zayav_ts_doc_type=true;
          qw->FieldByName("pol_zayav_ts_doc_type")->AsString  = m_api->dbGetStringFromQuery(res,"select VEHICLE_REGISTR_TYPE_NAME from OSAGO_R_AUTODICTVEHICLEREGTYPE where VEHICLE_REGISTR_TYPE_ID='"+node3->Text+ "'");
      }
      if(!AnsiString(node2->ChildNodes->FindNode("registration_series")->Text).IsEmpty()) {
          qw->FieldByName("pol_zayav_ts_PTS_ser")->AsString   = AnsiString(node2->ChildNodes->FindNode("registration_series")->Text).Trim();
          qw->FieldByName("pol_zayav_ts_PTS_num")->AsString   = AnsiString(node2->ChildNodes->FindNode("registration_number")->Text).Trim();
          if(!pol_zayav_ts_doc_type) qw->FieldByName("pol_zayav_ts_doc_type")->AsString  = "������� ��"; //: "������� �� ������������ �����������";
      } else
      if( node2->ChildNodes->FindNode("reg_certificate_series") != NULL)
      if(!AnsiString(node2->ChildNodes->FindNode("reg_certificate_series")->Text).IsEmpty()) {
          qw->FieldByName("pol_zayav_ts_PTS_ser")->AsString   = AnsiString(node2->ChildNodes->FindNode("reg_certificate_series")->Text).Trim();
          qw->FieldByName("pol_zayav_ts_PTS_num")->AsString   = AnsiString(node2->ChildNodes->FindNode("reg_certificate_number")->Text).Trim();
          if(!pol_zayav_ts_doc_type) qw->FieldByName("pol_zayav_ts_doc_type")->AsString  = "������������� � ����������� ��";// : "������������� � ����������� �� ������������ �����������";
      }

      if(node2->ChildNodes->FindNode("trailer"))
      qw->FieldByName("pricep")->AsString = node2->ChildNodes->FindNode("trailer")->Text;
//��� �������� � ��������
/*
        AnsiString str = AnsiString(node2->ChildNodes->FindNode("registration_issue_date")->Text).Trim();
        int year = StrToInt(str.SubString(1,4));
        int month = StrToInt(str.SubString(6,2));
        int day = StrToInt(str.SubString(9,2));
        TDateTime date(year,month,day);
*/
      qw->FieldByName("pol_zayav_ts_PTS_date")->AsDateTime  = StrToDateFmt(dtformat, AnsiString(node2->ChildNodes->FindNode("registration_issue_date")->Text).Trim() ); 

//      qw->FieldByName("pol_zayav_ts_tehosmort_ser")->AsString =
      if( node2->ChildNodes->FindNode("tto_number") )
          qw->FieldByName("pol_zayav_ts_tehosmort_num")->AsString =  AnsiString(node2->ChildNodes->FindNode("tto_number")->Text).Trim();

      node3 = node2->ChildNodes->FindNode("tto_next_date");
      if(node3 && !node3->Text.IsEmpty()) {
        //  TryStrToDateTime(AnsiString(node3->Text),dt);
         TDateTime dt = StrToDateFmt(dtformat, AnsiString(node3->Text) );
          AnsiString mes[] = {"0","������","�������","����","������","���","����","����","������","��������","�������","������","�������"};
          qw->FieldByName("pol_zayav_ts_tehosmort_month")->AsString = mes[MonthOf(dt)];
          qw->FieldByName("pol_zayav_ts_tehosmort_year")->AsString = YearOf(dt);
      }



      qw->FieldByName("gosregznak")->AsString = node2->ChildNodes->FindNode("is_registration_vehicle")->Text;

      AnsiString regmark = node2->ChildNodes->FindNode("registration_mark")->Text; //��-�� ���� ��� � �����-������ ��������� ��� <registration_mark>�620�� 199</registration_mark>
      qw->FieldByName("pol_zayav_ts_gosznak")->AsString = StringReplace(regmark," ","",TReplaceFlags()<<rfReplaceAll);

      st=AnsiString(node2->ChildNodes->FindNode("usage_purpose")->Text).Trim();
      st=m_api->dbGetStringFromQuery(res,"select purpose_na from OSAGO_R_AutoDictOsagoVehPurpose where purpose_id="+IntToStr(StrToIntDef(st,0)));
      qw->FieldByName("pol_zayav_ts_cel_isp")->AsString   = st;

      qw->FieldByName("pol_zayav_ts_v_arendu")->AsBoolean = AnsiString(node2->ChildNodes->FindNode("rent")->Text) == "1";

      qw->FieldByName("calc_sled_k_mr")->AsBoolean    = AnsiString(node2->ChildNodes->FindNode("transit")->Text) == "1";
      if( node2->ChildNodes->FindNode("foreign_registration") )
          qw->FieldByName("calc_inostr_gosvo")->AsBoolean = AnsiString(node2->ChildNodes->FindNode("foreign_registration")->Text) == "1";

      if(node2->ChildNodes->FindNode("country_registration") !=NULL)
      qw->FieldByName("calc_in_gosvo_t")->AsString= qw->FieldByName("calc_inostr_gosvo")->AsBoolean? AnsiString(node2->ChildNodes->FindNode("country_registration")->Text).Trim():empty_str;

      if(node2->ChildNodes->FindNode("trailer"))
        qw->FieldByName("pricep")->AsString = node2->ChildNodes->FindNode("trailer")->Text;

      node3 = node2->ChildNodes->FindNode("usage_start_date"); //�� �����-������ � xml ����� ���� �����
      if(node3!=NULL && !AnsiString(node3->Text).IsEmpty() ) {
          qw->FieldByName("pol_zayav_per_isp_1_s")->AsDateTime = StrToDateFmt(dtformat, AnsiString(node2->ChildNodes->FindNode("usage_start_date")->Text));
         AnsiString perispend1 = node2->ChildNodes->FindNode("usage_end_date")->Text;
         qw->FieldByName("pol_zayav_per_isp_1_po")->AsDateTime = StrToDateFmt(dtformat, perispend1);
      } else {
          qw->FieldByName("pol_zayav_per_isp_1_s")->AsDateTime = qw->FieldByName("pol_zayav_srok_strah_s")->AsDateTime;
          qw->FieldByName("pol_zayav_per_isp_1_po")->AsDateTime = qw->FieldByName("pol_zayav_srok_strah_po")->AsDateTime;
      }

      node3 = node2->ChildNodes->FindNode("usage_start_date2");
      if(node3!=NULL && !AnsiString(node3->Text).IsEmpty()) {
          qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime = StrToDateFmt(dtformat, AnsiString(node3->Text));
      }

      node3 = node2->ChildNodes->FindNode("usage_end_date2");
      if(node3!=NULL && !AnsiString(node3->Text).IsEmpty()) {
          qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime = StrToDateFmt(dtformat, AnsiString(node3->Text));
      }

      node3 = node2->ChildNodes->FindNode("usage_start_date3");
      if(node3!=NULL && !AnsiString(node3->Text).IsEmpty()) {
          qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime = StrToDateFmt(dtformat, AnsiString(node3->Text));
      }

      node3 = node2->ChildNodes->FindNode("usage_end_date3");
      if(node3!=NULL && !AnsiString(node3->Text).IsEmpty()) {
       //   TryStrToDateTime(AnsiString(node3->Text),dt);
          qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime = StrToDateFmt(dtformat, AnsiString(node3->Text));
      }

      qw->FieldByName("pol_zayav_per_isp_2_enabled")->AsBoolean=int(qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime)>3;
      qw->FieldByName("pol_zayav_per_isp_3_enabled")->AsBoolean=int(qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime)>3;

      //��������� ���������� �������������
      AnsiString terr = AnsiString(node2->ChildNodes->FindNode("territory_kt")->Text).Trim();
      if(terr.Length() == 12 ) //sd 1305707  �� xxx ��������� ������ ����� ���������� ���-��, ���� ����������
            terr = "0" + terr;   //0200000000000	������������     2000000000000	���������

      qw->FieldByName("kladr")->AsString   = terr;

      node3 = node2->ChildNodes->FindNode("infraction_40fz");
      if(node3)
          qw->FieldByName("calc_grub_narushen")->AsBoolean = AnsiString(node3->Text) == "1";

//���������� ������� ������������� ��� ���  calc_per_isp_ts "10 ������� � �����"

      TDateTime dateInc,dateCalc;
      short  out_month =0, out_dday = 0;
      int mcount=0,dcount = 0;

      //1 ������
      if( !qw->FieldByName("pol_zayav_per_isp_1_s")->IsNull && !qw->FieldByName("pol_zayav_per_isp_1_s")->IsNull) {
        AnsiString ddd =  qw->FieldByName("pol_zayav_per_isp_1_s")->AsString;
        dt1_s= qw->FieldByName("pol_zayav_per_isp_1_s")->AsDateTime;
        AnsiString eddd =  qw->FieldByName("pol_zayav_per_isp_1_po")->AsString;
        dt1_e= qw->FieldByName("pol_zayav_per_isp_1_po")->AsDateTime;
        dateCalc = Dateutils::IncDay(dt1_e, 1);
        getDecodDate(dt1_s, dateCalc, out_month, out_dday);
        mcount += out_month;
        dcount += out_dday;
      }
      //2 ������
      if( !qw->FieldByName("pol_zayav_per_isp_2_s")->IsNull && !qw->FieldByName("pol_zayav_per_isp_2_s")->IsNull) {
        dt2_s=qw->FieldByName("pol_zayav_per_isp_2_s")->AsDateTime;
        dt2_e=qw->FieldByName("pol_zayav_per_isp_2_po")->AsDateTime;
        dateCalc = Dateutils::IncDay(dt2_e, dcount+1);
        getDecodDate(dt2_s, dateCalc, out_month, out_dday);
        mcount += out_month;
        dcount += out_dday;
      }
      //3 ������
      if( !qw->FieldByName("pol_zayav_per_isp_3_s")->IsNull && !qw->FieldByName("pol_zayav_per_isp_3_s")->IsNull) {
        dt3_s=qw->FieldByName("pol_zayav_per_isp_3_s")->AsDateTime;
        dt3_e=qw->FieldByName("pol_zayav_per_isp_3_po")->AsDateTime;
        dateCalc = Dateutils::IncDay(dt3_e, dcount+1);
        getDecodDate(dt3_s, dateCalc, out_month, out_dday);
        mcount += out_month;
        dcount += out_dday;
      }

      int m = mcount;
      AnsiString period_isp;

      switch(m) {
        case 3: period_isp= "3 ������"; break;
        case 4: period_isp= "4 ������"; break;
        case 5: period_isp= "5 �������"; break;
        case 6: period_isp= "6 �������"; break;
        case 7: period_isp= "7 �������"; break;
        case 8: period_isp= "8 �������"; break;
        case 9: period_isp= "9 �������"; break;
        case 10:
        case 11:
        case 12: period_isp= "10 ������� � �����"; break;
        default: period_isp=""; break;
      }
      qw->FieldByName("calc_per_isp_ts")->AsString= period_isp;
      qw->FieldByName("deadline")->AsString = period_isp;

      } //if ��� ���� ������!

      qw->Post();
      m_api->dbCloseCursor(res, qw);
      qw=NULL;


 //-----------------------
//������� ---------------
//-----------------------

      sql = "select calc_id,pol_zayav_klass_kbm,calc_klass_kbm,calc_kbm2,pol_zayav_strah_f,pol_zayav_strah_i,pol_zayav_strah_o,pol_zayav_strah_fio,pol_zayav_strah_sex,pol_zayav_strah_date_rojd,pol_zayav_strah_FU,pol_zayav_strah_docum,pol_zayav_strah_doc_ser"
            ",pol_zayav_strah_doc_num,pol_zayav_strah_inn,pol_zayav_strah_telefon,pol_zayav_strah_telefon2,pol_zayav_strah_telefon3,pol_zayav_strah_email,pol_zayav_strah_index,strah_country_id"
            ",pol_zayav_strah_gos_vo,pol_zayav_strah_res_kr_obl,pol_zayav_strah_raion,pol_zayav_strah_nas_punkt,pol_zayav_strah_ulitsa,pol_zayav_strah_dom,pol_zayav_strah_korpus,pol_zayav_strah_kvartira,pol_zayav_strah_mid"
            ",pol_zayav_sobstv_FU,pol_zayav_sobstv_f,pol_zayav_sobstv_i,pol_zayav_sobstv_o,pol_zayav_sobstv_fio,pol_zayav_sobstv_sex,pol_zayav_sobstv_docum,pol_zayav_sobstv_doc_ser,pol_zayav_sobstv_doc_num,pol_zayav_sobstv_date_rojd"
            ",pol_zayav_sobstv_inn,pol_zayav_sobstv_telefon,pol_zayav_sobstv_telefon2,pol_zayav_sobstv_telefon3,pol_zayav_sobstv_index,sobstv_country_id,pol_zayav_sobstv_gos_vo"
            ",pol_zayav_sobstv_res_kr_obl,pol_zayav_sobstv_raion,pol_zayav_sobstv_nas_punkt,pol_zayav_sobstv_ulitsa,pol_zayav_sobstv_dom,pol_zayav_sobstv_korpus,pol_zayav_sobstv_kvartira,pol_zayav_sobstv_mid"
            ",calc_inostr_gosvo,calc_in_gosvo_t,calc_fizyur_lico,sobst_resident,calc_territor_isp_ter,pol_zayav_dopku_kolvo,pol_zayav_strah_doc_vidan,pol_zayav_strah_doc_date"
                       " from OSAGO_R_main where calc_id=" + IntToStr(id);

      qw = m_api->dbGetCursor(res, sql, 0, 1);


      node = Root->ChildNodes->FindNode("persons");
      node2 = node->ChildNodes->FindNode("person");
      int dopnum=0;

      qw->Edit();

      while(node2) {
         dopnum++;
         bool isstrahovatel = node2->ChildNodes->FindNode("is_insured")->Text == AnsiString("1");
         bool isowner = node2->ChildNodes->FindNode("is_owner")->Text == AnsiString("1");
         bool isdopuch = node2->ChildNodes->FindNode("is_permitted")->Text == AnsiString("1");

         bool isyur = node2->ChildNodes->FindNode("is_juridical")->Text == AnsiString("1");

         if( isdopuch ) {

            m_api->dbExecuteQuery(res, "insert into OSAGO_R_dop_k_upr (calc_id, num_dop_upr) values (" + IntToStr(id) + "," + IntToStr(dopnum) + ")");
            TADOQuery* qdu = m_api->dbGetCursor(res, "select * from OSAGO_R_dop_k_upr where calc_id=" + IntToStr(id) + " and num_dop_upr=" + IntToStr(dopnum), 0, 1);
            qdu->Edit();

            AnsiString bstrd= node2->ChildNodes->FindNode("physical_bitrh_date")->Text; // "2015.01.01 23:59:59";
            //TryStrToDateTime(bstrd, dt);
            //if(dt.Val!=0.0) {
              qdu->FieldByName("data_rogd")->AsDateTime = StrToDateFmt(dtformat, bstrd);
              qdu->FieldByName("vozrast")->AsInteger = YearsBetween(Date() + 1, qdu->FieldByName("data_rogd")->AsDateTime);
            //}

            AnsiString strd= node2->ChildNodes->FindNode("driving_start_date")->Text;  // "2015.01.01 23:59:59";
           // TryStrToDateTime( strd , dt);
           // if(dt.Val!=0.0) {
              qdu->FieldByName("data_staj")->AsDateTime = StrToDateFmt(dtformat, strd);
              qdu->FieldByName("stag")->AsInteger  = YearsBetween(Date() + 1, qdu->FieldByName("data_staj")->AsDateTime);
           // }
            qdu->FieldByName("f")->AsString= AnsiString(node2->ChildNodes->FindNode("last_name")->Text);
            qdu->FieldByName("i")->AsString= AnsiString(node2->ChildNodes->FindNode("first_name")->Text);
            if( node2->ChildNodes->FindNode("second_name") )
            qdu->FieldByName("o")->AsString= AnsiString(node2->ChildNodes->FindNode("second_name")->Text);

            qdu->FieldByName("iz_arm")->AsInteger = fromfile?0:1;

//���� ��� ��������������, �������� �� ��������� ����������
            if(is2pereoformlenie && newdop) {
                AnsiString dopfio = qdu->FieldByName("f")->AsString + " " + qdu->FieldByName("i")->AsString + " " + qdu->FieldByName("o")->AsString;
                dopfio = dopfio.Trim(); //���� ���� �������� ������� ������;
                   for(int i=0; i<newdop->Count; i++) {
                      AnsiString names = newdop->Names[i];
                      if( names == dopfio )
                          qdu->FieldByName("add_date")->AsString = newdop->Values[newdop->Names[i]];
                   }
            }



            qdu->FieldByName("prava_s")->AsString    = AnsiString(node2->ChildNodes->FindNode("license_series")->Text).Trim();
            qdu->FieldByName("prava_n")->AsString    = AnsiString(node2->ChildNodes->FindNode("license_number")->Text).Trim();
            qdu->FieldByName("sex")->AsString = AnsiString(node2->ChildNodes->FindNode("physical_sex")->Text) == "1"?"�":"�";


            node3 = node2->ChildNodes->FindNode("bonus_malus_coeff_id");
            if(node3 && !AnsiString(node3->Text).Trim().IsEmpty()) {

                AnsiString dop_kbm("");
                float dop_coef_kbm(0.0f);

                //if(fromfile) { //�����-������   bonus_malus_coeff_id = malus_id  ���� �� ����������� ����������� malus_val
                    dop_kbm =  m_api->dbGetStringFromQuery(res, "select malus_val from OSAGO_R_autodictbonusmalus where malus_id=" + AnsiString(node3->Text).Trim());
                //} else { //��������� �� ���  bonus_malus_coeff_id =  malus_val  ������ ����������� ������..
                //    dop_kbm =  node3->Text;
                //}
                dop_coef_kbm = m_api->dbGetFloatFromQuery(res, "select coeff_val from OSAGO_R_autodictbonusmalus where terr_id=0 and malus_val=" + dop_kbm);

                if(coeff_val==0) {
                    coeff_val = dop_coef_kbm;
                    kbm = dop_kbm;
                } else if(coeff_val < dop_coef_kbm){
                    coeff_val = dop_coef_kbm;
                    kbm = dop_kbm;
                }

                qdu->FieldByName("kbm")->AsString  = dop_kbm;
                qdu->FieldByName("kbm_koeff")->AsFloat = dop_coef_kbm; //GetKbm_koeff(qdu->FieldByName("kbm")->AsString, qw->FieldByName("calc_inostr_gosvo")->AsBoolean,qw->FieldByName("calc_in_gosvo_t")->AsString);
            }

//27.08.2015
//���� �� ������������� �������� UXML
//���� ��� �� ����� ���������� �� �������

            if (node2->ChildNodes->FindNode("loss_new")) qdu->FieldByName("loss_new")->AsInteger=StrToIntDef(AnsiString(node2->ChildNodes->FindNode("loss_new")->Text).Trim(),0);
            if (node2->ChildNodes->FindNode("count_damage_im")) qdu->FieldByName("count_damage_im")->AsInteger=StrToIntDef(AnsiString(node2->ChildNodes->FindNode("count_damage_im")->Text).Trim(),0);
            if (node2->ChildNodes->FindNode("count_damage_zd")) qdu->FieldByName("count_damage_zd")->AsInteger=StrToIntDef(AnsiString(node2->ChildNodes->FindNode("count_damage_zd")->Text).Trim(),0);
            if (node2->ChildNodes->FindNode("count_damage_open")) qdu->FieldByName("count_damage_open")->AsInteger=StrToIntDef(AnsiString(node2->ChildNodes->FindNode("count_damage_open")->Text).Trim(),0);
            if (node2->ChildNodes->FindNode("loss_rur")) qdu->FieldByName("loss_rur")->AsFloat = StrToFloatDef( StrToFloatStr( AnsiString(node2->ChildNodes->FindNode("loss_rur")->Text).Trim() ),0.0);
            if (node2->ChildNodes->FindNode("damage_open_rur")) qdu->FieldByName("damage_open_rur")->AsFloat = StrToFloatDef( StrToFloatStr( AnsiString(node2->ChildNodes->FindNode("damage_open_rur")->Text).Trim() ),0.0);

            qdu->Post();
            m_api->dbCloseCursor(res, qdu);
         }

         if( isstrahovatel ) {
//������������
           if(isyur) {
//�� ������������
             qw->FieldByName("pol_zayav_strah_fio")->AsString =  node2->ChildNodes->FindNode("last_name")->Text;


           } else {
//��� ������������
             qw->FieldByName("pol_zayav_strah_f")->AsString = node2->ChildNodes->FindNode("last_name")->Text;
             qw->FieldByName("pol_zayav_strah_i")->AsString = node2->ChildNodes->FindNode("first_name")->Text;
             if( node2->ChildNodes->FindNode("second_name") )
             qw->FieldByName("pol_zayav_strah_o")->AsString = node2->ChildNodes->FindNode("second_name")->Text;
             qw->FieldByName("pol_zayav_strah_fio")->AsString = qw->FieldByName("pol_zayav_strah_f")->AsString + " " + qw->FieldByName("pol_zayav_strah_i")->AsString + " " + qw->FieldByName("pol_zayav_strah_o")->AsString;
             qw->FieldByName("pol_zayav_strah_sex")->AsString = node2->ChildNodes->FindNode("physical_sex")->Text == AnsiString("1") ? "�":"�";



             if(node2->ChildNodes->FindNode("document_issue_organization")) {
                 qw->FieldByName("pol_zayav_strah_doc_vidan")->AsString = AnsiString(node2->ChildNodes->FindNode("document_issue_organization")->Text);
             }
              if(node2->ChildNodes->FindNode("document_issue_date")) {
                 qw->FieldByName("pol_zayav_strah_doc_date")->AsString = StrToDateFmt(dtformat, node2->ChildNodes->FindNode("document_issue_date")->Text);
             }



             AnsiString bstrd= node2->ChildNodes->FindNode("physical_bitrh_date")->Text; // "2015.01.01 23:59:59";
           //  TryStrToDateTime(bstrd, dt);
           //  if(dt.Val!=0.0) {
               qw->FieldByName("pol_zayav_strah_date_rojd")->AsDateTime = StrToDateFmt(dtformat, bstrd);
            // }
           }
//� ����� ��/���  -������������
           qw->FieldByName("pol_zayav_strah_FU")->AsBoolean = isyur;
           qw->FieldByName("pol_zayav_strah_docum")->AsString = m_api->dbGetStringFromQuery(res,"select tip_doc from OSAGO_R_tip_doc where id_tip_doc="+IntToStr((StrToIntDef(node2->ChildNodes->FindNode("document_type_id")->Text,0))));

           node3 = node2->ChildNodes->FindNode("document_series");
           if(node3) qw->FieldByName("pol_zayav_strah_doc_ser")->AsString    = node3->Text;

           node3 = node2->ChildNodes->FindNode("document_number");
           if(node3) qw->FieldByName("pol_zayav_strah_doc_num")->AsString    = node3->Text;

           node3 = node2->ChildNodes->FindNode("inn");
           if(node3) qw->FieldByName("pol_zayav_strah_inn")->AsString        = node3->Text;

  //��������
             node3 = node2->ChildNodes->FindNode("contacts");
             node4 = node3->ChildNodes->First();
             int ii(0);
             while(node4) {
                if(TryStrToInt(node4->Attributes["contact_type_id"], ii)) {
                  switch(ii) {
                    case 1: qw->FieldByName("pol_zayav_strah_telefon")->AsString = node4->Attributes["contract_data"]; break;
                    case 2: qw->FieldByName("pol_zayav_strah_telefon2")->AsString = node4->Attributes["contract_data"]; break;
                    case 3: //���������
                            qw->FieldByName("pol_zayav_strah_telefon3")->AsString = node4->Attributes["contract_data"];
                            break;
                    case 5: //email
                            qw->FieldByName("pol_zayav_strah_email")->AsString = node4->Attributes["contract_data"]; break;
                  }
                }
                node4 = node4->NextSibling();
             }

           qw->FieldByName("pol_zayav_strah_index")->AsString = node2->ChildNodes->FindNode("zip")->Text;
           qw->FieldByName("strah_country_id")->AsString = node2->ChildNodes->FindNode("country_id")->Text;
           qw->FieldByName("pol_zayav_strah_gos_vo")->AsString = node2->ChildNodes->FindNode("country")->Text;

           qw->FieldByName("pol_zayav_strah_res_kr_obl")->AsString = node2->ChildNodes->FindNode("region")->Text;
           qw->FieldByName("pol_zayav_strah_raion")->AsString = node2->ChildNodes->FindNode("area")->Text;

           node3 = node2->ChildNodes->FindNode("city");
           AnsiString city("");
           if(node3)
               city = node3->Text;
           qw->FieldByName("pol_zayav_strah_nas_punkt")->AsString  = city.IsEmpty() ? AnsiString(node2->ChildNodes->FindNode("place")->Text):city;
           qw->FieldByName("pol_zayav_strah_ulitsa")->AsString =node2->ChildNodes->FindNode("street")->Text;
           qw->FieldByName("pol_zayav_strah_dom")->AsString = node2->ChildNodes->FindNode("house")->Text;
           qw->FieldByName("pol_zayav_strah_korpus")->AsString = node2->ChildNodes->FindNode("building")->Text;
           qw->FieldByName("pol_zayav_strah_kvartira")->AsString = node2->ChildNodes->FindNode("flat")->Text;

        //����� �����
           std::auto_ptr<TStringList> addr(new TStringList());
           addr->Values["������"] = "��";
           addr->Values["��� �����"] = AnsiString(node2->ChildNodes->FindNode("street_id")->Text);
           addr->Values["������ ������"] = qw->FieldByName("pol_zayav_strah_res_kr_obl")->AsString.SubString(0,3);
           addr->Values["�����������"] = qw->FieldByName("pol_zayav_strah_gos_vo")->AsString;
           addr->Values["������"] = qw->FieldByName("pol_zayav_strah_res_kr_obl")->AsString;
           addr->Values["�����"] = qw->FieldByName("pol_zayav_strah_raion")->AsString;

           if(city.IsEmpty()) { if(!qw->FieldByName("pol_zayav_strah_nas_punkt")->AsString.IsEmpty()) addr->Values["�������"] = node2->ChildNodes->FindNode("place")->Text; }
           else addr->Values["�����"] = city;
//                        addr->Values["������"] = node3->ChildNodes->FindNode("zip")->Text;
           addr->Values["�����"] = qw->FieldByName("pol_zayav_strah_ulitsa")->AsString;
           addr->Values["���"] = qw->FieldByName("pol_zayav_strah_dom")->AsString;
           addr->Values["����� �������"] = qw->FieldByName("pol_zayav_strah_korpus")->AsString;
           addr->Values["��������"] = qw->FieldByName("pol_zayav_strah_kvartira")->AsString;
           int id_addr = m_api->dbGenerateId(res, "OSAGO_R_memo");
           m_api->dbReadWriteInternalMemo(res, addr->Text,   id_addr,   false, "OSAGO_R_memo");
           qw->FieldByName("pol_zayav_strah_mid")->AsInteger = id_addr;

           if(isowner) {
//������������ == �����������

//���� ������������ �� ������������ ���������
             qw->FieldByName("pol_zayav_sobstv_FU")->AsBoolean = qw->FieldByName("pol_zayav_strah_FU")->AsBoolean;
             qw->FieldByName("pol_zayav_sobstv_f")->AsString = qw->FieldByName("pol_zayav_strah_f")->AsString;
             qw->FieldByName("pol_zayav_sobstv_i")->AsString = qw->FieldByName("pol_zayav_strah_i")->AsString;
             qw->FieldByName("pol_zayav_sobstv_o")->AsString =  qw->FieldByName("pol_zayav_strah_o")->AsString;
             qw->FieldByName("pol_zayav_sobstv_fio")->AsString = qw->FieldByName("pol_zayav_strah_fio")->AsString;
             qw->FieldByName("pol_zayav_sobstv_sex")->AsString = qw->FieldByName("pol_zayav_strah_sex")->AsString;
             qw->FieldByName("pol_zayav_sobstv_docum")->AsString = qw->FieldByName("pol_zayav_strah_docum")->AsString;
             qw->FieldByName("pol_zayav_sobstv_doc_ser")->AsString = qw->FieldByName("pol_zayav_strah_doc_ser")->AsString;
             qw->FieldByName("pol_zayav_sobstv_doc_num")->AsString = qw->FieldByName("pol_zayav_strah_doc_num")->AsString;
             qw->FieldByName("pol_zayav_sobstv_date_rojd")->AsDateTime = qw->FieldByName("pol_zayav_strah_date_rojd")->AsDateTime;
             qw->FieldByName("pol_zayav_sobstv_inn")->AsString = qw->FieldByName("pol_zayav_strah_inn")->AsString;
             qw->FieldByName("pol_zayav_sobstv_telefon")->AsString = qw->FieldByName("pol_zayav_strah_telefon")->AsString;
             qw->FieldByName("pol_zayav_sobstv_telefon2")->AsString = qw->FieldByName("pol_zayav_strah_telefon2")->AsString;
             qw->FieldByName("pol_zayav_sobstv_telefon3")->AsString = qw->FieldByName("pol_zayav_strah_telefon3")->AsString;

             qw->FieldByName("pol_zayav_sobstv_index")->AsString = qw->FieldByName("pol_zayav_strah_index")->AsString;
             qw->FieldByName("sobstv_country_id")->AsInteger = qw->FieldByName("strah_country_id")->AsInteger;
             qw->FieldByName("pol_zayav_sobstv_gos_vo")->AsString = qw->FieldByName("pol_zayav_strah_gos_vo")->AsString;

             qw->FieldByName("pol_zayav_sobstv_res_kr_obl")->AsString = qw->FieldByName("pol_zayav_strah_res_kr_obl")->AsString;
             qw->FieldByName("pol_zayav_sobstv_raion")->AsString = qw->FieldByName("pol_zayav_strah_raion")->AsString;
             qw->FieldByName("pol_zayav_sobstv_nas_punkt")->AsString  = qw->FieldByName("pol_zayav_strah_nas_punkt")->AsString;
             qw->FieldByName("pol_zayav_sobstv_ulitsa")->AsString =qw->FieldByName("pol_zayav_strah_ulitsa")->AsString;
             qw->FieldByName("pol_zayav_sobstv_dom")->AsString = qw->FieldByName("pol_zayav_strah_dom")->AsString;
             qw->FieldByName("pol_zayav_sobstv_korpus")->AsString = qw->FieldByName("pol_zayav_strah_korpus")->AsString;
             qw->FieldByName("pol_zayav_sobstv_kvartira")->AsString = qw->FieldByName("pol_zayav_strah_kvartira")->AsString;

             qw->FieldByName("calc_territor_isp_ter")->AsString = qw->FieldByName("pol_zayav_strah_res_kr_obl")->AsString;
             qw->FieldByName("pol_zayav_sobstv_FU")->AsBoolean = isyur;
             qw->FieldByName("calc_fizyur_lico")->AsString = isyur? "����������� ����":"���������� ����";

             qw->FieldByName("sobst_resident")->AsInteger = 1;

             node3 = node2->ChildNodes->FindNode("is_resident");
             if(node3 && !node3->Text.IsEmpty())
                 qw->FieldByName("sobst_resident")->AsInteger = StrToInt(node3->Text) == 1 ? 0:1; //��������  �������� ��� null � 0, ����������=1

             qw->FieldByName("sobstv_country_id")->AsString = node2->ChildNodes->FindNode("country_id")->Text;

          //����� ������  ��� � �����.
             int id_addr = m_api->dbGenerateId(res, "OSAGO_R_memo");
             m_api->dbReadWriteInternalMemo(res, addr->Text,   id_addr,   false, "OSAGO_R_memo");
             qw->FieldByName("pol_zayav_sobstv_mid")->AsInteger = id_addr;
           }

           } else if(isowner) {
//�����������
             if(isyur) {
//�� -�����������
                qw->FieldByName("pol_zayav_sobstv_fio")->AsString =  node2->ChildNodes->FindNode("last_name")->Text;

             } else {
//��� -�����������
               qw->FieldByName("pol_zayav_sobstv_f")->AsString = node2->ChildNodes->FindNode("last_name")->Text;
               qw->FieldByName("pol_zayav_sobstv_i")->AsString = node2->ChildNodes->FindNode("first_name")->Text;
               if( node2->ChildNodes->FindNode("second_name") )
               qw->FieldByName("pol_zayav_sobstv_o")->AsString = node2->ChildNodes->FindNode("second_name")->Text;
               qw->FieldByName("pol_zayav_sobstv_fio")->AsString = qw->FieldByName("pol_zayav_sobstv_f")->AsString + " " + qw->FieldByName("pol_zayav_sobstv_i")->AsString + " " + qw->FieldByName("pol_zayav_sobstv_o")->AsString;
               qw->FieldByName("pol_zayav_sobstv_sex")->AsString = node2->ChildNodes->FindNode("physical_sex")->Text == AnsiString("1") ? "�":"�";

               AnsiString bstrd= node2->ChildNodes->FindNode("physical_bitrh_date")->Text; // "2015.01.01 23:59:59";
            //   TryStrToDateTime(bstrd, dt);
            //   if(dt.Val!=0.0) {
                 qw->FieldByName("pol_zayav_sobstv_date_rojd")->AsDateTime = StrToDateFmt(dtformat, bstrd);
            //   }
             }
//� ����� ��/��� �����������
             qw->FieldByName("pol_zayav_sobstv_FU")->AsBoolean = isyur;
             qw->FieldByName("calc_fizyur_lico")->AsString = isyur? "����������� ����":"���������� ����";

             qw->FieldByName("sobst_resident")->AsInteger = 1;
             node3 = node2->ChildNodes->FindNode("is_resident");
             if(node3 && !node3->Text.IsEmpty())
                 qw->FieldByName("sobst_resident")->AsInteger = StrToInt(node3->Text) == 1 ? 0:1; //��������  �������� ��� null � 0, ����������=1

             qw->FieldByName("pol_zayav_sobstv_docum")->AsString = m_api->dbGetStringFromQuery(res,"select tip_doc from OSAGO_R_tip_doc where id_tip_doc="+IntToStr((StrToIntDef(node2->ChildNodes->FindNode("document_type_id")->Text,0))));

             node3 = node2->ChildNodes->FindNode("document_series");
             if(node3)
             qw->FieldByName("pol_zayav_sobstv_doc_ser")->AsString    = node3->Text;

             node3 = node2->ChildNodes->FindNode("document_number");
             if(node3)
             qw->FieldByName("pol_zayav_sobstv_doc_num")->AsString    = node3->Text;

             node3 = node2->ChildNodes->FindNode("inn");
             if(node3)
             qw->FieldByName("pol_zayav_sobstv_inn")->AsString        = node3->Text;

//���������� �� ������������ ��������
             qw->FieldByName("calc_territor_isp_ter")->AsString = node2->ChildNodes->FindNode("region")->Text;

    //��������
             node3 = node2->ChildNodes->FindNode("contacts");
             node4 = node3->ChildNodes->First();
             int ii(0);
             while(node4) {
                if(TryStrToInt(node4->Attributes["contact_type_id"], ii))
                  switch(ii) {
                    case 1: qw->FieldByName("pol_zayav_sobstv_telefon")->AsString = node4->Attributes["contract_data"]; break;
                    case 2: qw->FieldByName("pol_zayav_sobstv_telefon2")->AsString = node4->Attributes["contract_data"]; break;
                    case 3: //���������
                            qw->FieldByName("pol_zayav_sobstv_telefon3")->AsString = node4->Attributes["contract_data"]; break;
                 //   case 5: { //email
                          //qw->FieldByName("pol_zayav_sobstv_email")->AsString = node4->Attributes["contract_data"]; break; }
                   //         }
                  }

                node4 = node4->NextSibling();
             }

             qw->FieldByName("pol_zayav_sobstv_index")->AsString = node2->ChildNodes->FindNode("zip")->Text;
             qw->FieldByName("sobstv_country_id")->AsString = node2->ChildNodes->FindNode("country_id")->Text;
             qw->FieldByName("pol_zayav_sobstv_gos_vo")->AsString = node2->ChildNodes->FindNode("country")->Text;

             qw->FieldByName("pol_zayav_sobstv_res_kr_obl")->AsString = node2->ChildNodes->FindNode("region")->Text;
             qw->FieldByName("pol_zayav_sobstv_raion")->AsString = node2->ChildNodes->FindNode("area")->Text;

             node4 = node3->ChildNodes->FindNode("city");
             AnsiString city("");
             if( node4 )
                city = node4->Text;

             qw->FieldByName("pol_zayav_sobstv_nas_punkt")->AsString  = city.IsEmpty() ? AnsiString(node2->ChildNodes->FindNode("place")->Text):city;
             qw->FieldByName("pol_zayav_sobstv_ulitsa")->AsString =node2->ChildNodes->FindNode("street")->Text;
             qw->FieldByName("pol_zayav_sobstv_dom")->AsString = node2->ChildNodes->FindNode("house")->Text;
             qw->FieldByName("pol_zayav_sobstv_korpus")->AsString = node2->ChildNodes->FindNode("building")->Text;
             qw->FieldByName("pol_zayav_sobstv_kvartira")->AsString = node2->ChildNodes->FindNode("flat")->Text;

        //����� ������
             std::auto_ptr<TStringList> addr(new TStringList());
             addr->Values["������"] = "��";
             addr->Values["��� �����"] = AnsiString(node2->ChildNodes->FindNode("street_id")->Text);
             addr->Values["������ ������"] = qw->FieldByName("pol_zayav_sobstv_res_kr_obl")->AsString.SubString(0,3);
             addr->Values["�����������"] = qw->FieldByName("pol_zayav_sobstv_gos_vo")->AsString;
             addr->Values["������"] = qw->FieldByName("pol_zayav_sobstv_res_kr_obl")->AsString;
             addr->Values["�����"] = qw->FieldByName("pol_zayav_sobstv_raion")->AsString;

             if(city.IsEmpty()) { if(!qw->FieldByName("pol_zayav_sobstv_nas_punkt")->AsString.IsEmpty()) addr->Values["�������"] = node2->ChildNodes->FindNode("place")->Text; }
             else addr->Values["�����"] = city;
//                        addr->Values["������"] = node3->ChildNodes->FindNode("zip")->Text;
             addr->Values["�����"] = qw->FieldByName("pol_zayav_sobstv_ulitsa")->AsString;
             addr->Values["���"] = qw->FieldByName("pol_zayav_sobstv_dom")->AsString;
             addr->Values["����� �������"] = qw->FieldByName("pol_zayav_sobstv_korpus")->AsString;
             addr->Values["��������"] = qw->FieldByName("pol_zayav_sobstv_kvartira")->AsString;
             int id_addr = m_api->dbGenerateId(res, "OSAGO_R_memo");
             m_api->dbReadWriteInternalMemo(res, addr->Text,   id_addr,   false, "OSAGO_R_memo");
             qw->FieldByName("pol_zayav_sobstv_mid")->AsInteger = id_addr;
          }


        node2 = node2->NextSibling();
     }  //while  person

     if(newdop) { delete newdop; newdop=NULL; }

          qw->FieldByName("pol_zayav_dopku_kolvo")->AsInteger =  dopnum;
          qw->FieldByName("pol_zayav_klass_kbm")->AsString = kbm;
          qw->FieldByName("calc_klass_kbm")->AsString = kbm;
          qw->FieldByName("calc_kbm2")->AsString = m_api->Round( coeff_val );
          qw->Post();
          m_api->dbCloseCursor(res, qw);
          qw=NULL;

//=========================================================================
//=========================================================================
//������� �� ������-�����
//=========================================================================
//=========================================================================


          node = Root->NextSibling();
          Root=node;
          if(fromfile && node && AnsiString(node->ChildNodes->FindNode("product_class_id")->Text) == "1") {
                sql = "select calc_id,produkt,ns_paymentdata,ns_payment,ns_paymentdoc,ns_paymentser,ns_paymentnum,ns_allprem,ns_terr_id,ns_payment_id,ns_payment_doc_id,ns_beznalpaymentdata"
                     " from OSAGO_R_main where calc_id=" + IntToStr(id);
                qw = m_api->dbGetCursor(res, sql, 0, 1);
                qw->Edit();
                sql = "select calc_id,fa_date_of_check,fa_payment_authorization_code"
                     " from OSAGO_R_main2 where calc_id=" + IntToStr(id);
                qw2 = m_api->dbGetCursor(res, sql, 0, 1);
                qw2->Edit();

                qw->FieldByName("produkt")->AsString = "0"; //������� + �����

// <paymentdatas>
//    <paymentdata payscheduletype="" payment_date="2015.01.21 18:17:19" payment_sum="1500" payment_sum_rur="1500" payment_document_number="1114534" payment_authorization_code="123456" date_of_check="2015.01.21 18:17:19" payment_type_id="3" payment_document_type_id="14" payment_method="1">
//         <blank blank_series="" blank_number="" blank_type_id="" />
//    </paymentdata>
// </paymentdatas>
              node = Root->ChildNodes->FindNode("paymentdatas")->ChildNodes->FindNode("paymentdata");
     if(node) {
              AnsiString attrdate = node->Attributes["date_of_check"];
              AnsiString attrcode = node->Attributes["payment_authorization_code"];
            //  TryStrToDateTime(attrdate,dt);
              qw2->FieldByName("fa_date_of_check")->AsDateTime =  StrToDateFmt(dtformat, attrdate);
              qw2->FieldByName("fa_payment_authorization_code")->AsString = attrcode;
              qw->FieldByName("ns_payment_id")->AsString = node->Attributes["payment_type_id"];
              qw->FieldByName("ns_payment_doc_id")->AsString  = node->Attributes["payment_document_type_id"];
             // TryStrToDateTime(AnsiString(node->Attributes["payment_date"]),dt);
              qw->FieldByName("ns_paymentdata")->AsDateTime= StrToDateFmt(dtformat, AnsiString(node->Attributes["payment_date"]));
              qw->FieldByName("ns_beznalpaymentdata")->AsDateTime= StrToDateFmt(dtformat, AnsiString(node->Attributes["payment_date"]));
              qw->FieldByName("ns_payment")->AsString=(node!=0?m_api->dbGetStringFromQuery(res,"select oplaty_name from OSAGO_R_tip_oplaty where id="+ IntToStr(StrToIntDef( AnsiString(node->Attributes["payment_type_id"]) ,0))):empty_str);
              qw->FieldByName("ns_paymentdoc")->AsString=(node!=0?m_api->dbGetStringFromQuery(res,"select dokument_name from OSAGO_R_tip_platezhnogo_dokumenta where id="+ IntToStr(StrToIntDef( AnsiString(node->Attributes["payment_document_type_id"]) ,0))):empty_str);
        //���������� �� 2: payment_document_number="7003 02207983"
              TStringList *sl=new TStringList();
              sl->Text = StringReplace( AnsiString(node->Attributes["payment_document_number"])," ","\r\n",TReplaceFlags()<<rfReplaceAll);
              if(sl->Count>0) {
                 if( sl->Count==1 ) { //���� ������ �����?
                   qw->FieldByName("ns_paymentnum")->AsString= sl->Strings[0];  //�����
                 }  else qw->FieldByName("ns_paymentser")->AsString= sl->Strings[0];   //�����
              }
              if(sl->Count>1) qw->FieldByName("ns_paymentnum")->AsString= sl->Strings[1];  //�����
              delete sl; sl=NULL;
//            }
            AnsiString strprem = AnsiString(node->Attributes["payment_sum_rur"]);
            strprem = StringReplace(  StringReplace( strprem , ".", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll), ",", AnsiString(DecimalSeparator), TReplaceFlags() << rfReplaceAll);

            qw->FieldByName("ns_allprem")->AsFloat = StrToFloat(strprem);//allsumm;
      }//paymentdata!=null




//<autovehicles>
//   <autovehicle>
//       <riskobjects>                           RISK_OBJECT_TYPE_ID
//          <riskobject risk_object_type_id="_ROOT10000000000007026999" program_code="" liability="120000" liability_rur="120000" premium="1500" premium_rur="1500" tariff="" franchise_sum="" franchise_id="" franchise_size="" is_conditional_franchise="" />
//       </riskobjects>
     node = Root->ChildNodes->FindNode("autovehicles")->ChildNodes->FindNode("autovehicle")->ChildNodes->FindNode("riskobjects")->ChildNodes->FindNode("riskobject");
     AnsiString liability(""); //�� ������ ����������
     AnsiString premium("");
     if(node) {
          liability = AnsiString(node->Attributes["liability"]);
          premium = AnsiString(node->Attributes["premium"]);
     }



//              <persons>
//                 <person>
//                        <first_name>������</first_name>
//                         <second_name>��������</second_name>
//                        <last_name>���������</last_name>
//                                <physical_bitrh_date>1954.06.04 00:00:00</physical_bitrh_date>
//                     <physical_sex />
//                     <region_id>770000000020000</region_id>


      node = Root->ChildNodes->FindNode("persons");
      node2 = node->ChildNodes->FindNode("person");
      int dopnum=0;

      while(node2) {
         dopnum++;

           AnsiString bdata = AnsiString(node2->ChildNodes->FindNode("physical_bitrh_date")->Text);

//           TryStrToDateTime(bdata, dt);
//           if(dt.Val!=0.0) {
                TDateTime dt = StrToDateFmt(dtformat, bdata);
//TODO ����� ������� ������� ����?
               bdata =  m_api->Internal_Convert_Date_To_SQL(res, DateToStr(dt), false);
//           }
           AnsiString regid = AnsiString(node2->ChildNodes->FindNode("region_id")->Text).SubString(1,2) + "0000000000000";
            regid =  m_api->dbGetStringFromQuery(res,"select top 1 TERRITORY_ID from gl_dict_7_7_82_fortuneavto where KLADR='" + regid +"'");
           qw->FieldByName("ns_terr_id")->AsString = regid;

           AnsiString oth = node2->ChildNodes->FindNode("second_name") !=NULL ? AnsiString(node2->ChildNodes->FindNode("second_name")->Text) : AnsiString("");

           sql = "insert into OSAGO_R_insurfortune (calc_id,famil,name,otch,birthday,sex,selected,strahsum,strahprem,insur_strah) values (" + IntToStr(id) + ",'"
                                                                                                                   + AnsiString(node2->ChildNodes->FindNode("last_name")->Text) + "','"
                                                                                                                   + AnsiString(node2->ChildNodes->FindNode("first_name")->Text) + "','"
                                                                                                                   + oth + "',"
                                                                                                                   +  bdata  + ",'"
                                                                                                                   + (node2->ChildNodes->FindNode("physical_sex")->Text == AnsiString("1") ? "�":"�")
                                                                                                                   + "',1,"+liability+","+premium+",1)";
           m_api->dbExecuteQuery(res, sql);

           node2 = node2->NextSibling();
        }  //while  person

      qw->Post();
      m_api->dbCloseCursor(res, qw);
      qw=NULL;
      qw2->Post();
      m_api->dbCloseCursor(res, qw2);
      qw2=NULL;
      }

   }
   catch( Exception& Ex) {
      m_api->Internal_SetLastError(Ex.Message);
      ShowMessage("������ ��� �������� �� ������� ������: " + Ex.Message);
   }

   if(qw) {
       m_api->dbCloseCursor(res, qw);
       qw=NULL;
   }
   if(qw2) {
       m_api->dbCloseCursor(res, qw2);
       qw2=NULL;
   }
   delete XMLDoc;
   m_api->Module_Refresh_Main_Grid(res);
   return id;
}



bool CheckVin(AnsiString vin)   // http://www.vinfax.ru/about.html   http://carinfo.kiev.ua/vin/chksum
{
   if(vin.Length() != 17) return false;
//   int i_val;
//   if(!TryStrToInt(vin.SubString(14, 4), i_val)) return false;
   for(int i = 1; i < vin.Length(); i++){
      if(!((vin[i] >= '0' && vin[i] <= '9') || (vin[i] >= 'A' && vin[i] <= 'Z'))) return false;
      if(vin[i] == 'I' || vin[i] == 'O' || vin[i] == 'Q')                         return false;
   }


   // �������� ����������� �����
/*   AnsiString b_index="ABCDEFGHJKLMNPRSTUVWXYZ";
   int b_number[]={1,2,3,4,5,6,7,8,1,2,3,4,5,7,9,2,3,4,5,6,7,8,9};
   int v_ves[]={8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2};

   int p,n,s;
   s=0;
   for(int i = 1; i <= 17; i++)
   {
                               n=0;
                               p=b_index.Pos(vin[i]);
                               if(p>0)
                                               n=b_number[p-1];
                               else
                                               n=StrToIntDef(vin[i],0);
                               s+=v_ves[i-1]*n;
   }
   s-=(s/11)*11;

   char cs;
   if(s==10)
                cs='X';
   else
                cs=IntToStr(s)[1];

   if(vin[8]!=cs)
                               return false;
*/

   return true;
}


double RoundInt(double val)
{
   AnsiString ms, rel = ms.sprintf("%.12f", val);
   double tval1;
   int fl(0), i;
   char sim;

   for(i = rel.Length(); i > 0; i--){
      if(i > 2)
         if (rel[i - 2] == '.') break;
      sim = rel[i];
      int t = sim - 48 + fl;
      fl = (t >= 5 ? 1 : 0);
   }
   ms = ms.SubString(1, i);
   tval1 = atof(ms.c_str());
   if(fl) tval1 += 1;
   return tval1;
}
//---------------------------------------------------------------------------
int CheckDate(const AnsiString& date_str)
{
   TDateTime dt;
   return TryStrToDate(date_str, dt);
}
//---------------------------------------------------------------------------
int CheckDateFormat(const AnsiString& date_str)
{
   AnsiString numbersSymbols("0123456789");
   int countNumbers = 0;
   for(int i=1, len = date_str.Length(); i<=len; i++)
     if(numbersSymbols.Pos(date_str[i])) countNumbers++;

   return (countNumbers == 8); // dd.mm.yyyy // should be 8 numbers if less date is invalid
}
//---------------------------------------------------------------------------

int CheckDateLess(AnsiString date, int voz)
{
  TDateTime dt;
   if(TryStrToDate(date,dt))
   {
      TDateTime dt1 = Date();
      int t = double(dt1 - dt) / 365;
      if(t < voz)
            return 0;
      else
          return 1;
   }
   else
   {
    return 0;
   }
}
//---------------------------------------------------------------------------
int CheckDateLessDay(AnsiString date, int voz)
{
   TDateTime dt;

   if(TryStrToDate(date,dt))
   {
      int t = CalculateVozrast(dt);
      if(t < voz) return 0;
      else        return 1;
   }
   else
   {
        return 0;
   }
}
//---------------------------------------------------------------------------
int CalculateVozrast(TDateTime date)
{
   TDateTime ndate = Date();
   int vozr = YearsBetween(ndate, date - 1);
   try{
   if(Dateutils::IncYear(date, vozr) < ndate) vozr++; // ���� ������ ������ ����� ���, ����������� �� 1
   }
   catch(...){}
   return vozr;
}
//---------------------------------------------------------------------------
int CalcYears(const TDateTime& dt1, const TDateTime& dt2)
{
   if(!dt1.Val || !dt2.Val) return 0;

   int y1 = YearOf(dt1),  y2 = YearOf(dt2);
   int m1 = MonthOf(dt1), m2 = MonthOf(dt2);
   int d1 = DayOf(dt1),   d2 = DayOf(dt2);
   int ydif = y2 - y1;
   if(m2 < m1 || (m1 == m2 && d2 < d1)) ydif--;

   return ydif;
}
//---------------------------------------------------------------------------
int CalculateVozrast(TDateTime now, TDateTime date)
{
   return YearsBetween(now + 1, date);
}
//---------------------------------------------------------------------------
int CalculateVozrastMnt(TDateTime now, TDateTime date)
{
   return Dateutils::MonthsBetween(now + 1, date);
}
//---------------------------------------------------------------------------
AnsiString StrToFloatStr(const AnsiString& s)
{
   if(s.IsEmpty()) return null_str;

   char c = DecimalSeparator;

   if(s.AnsiPos(".")){
      if(c != '.') return StringReplace(s, ".", ",", rf);
   }
   else if(s.AnsiPos(",")){
      if(c != ',') return StringReplace(s, ",", ".", rf);
   }

   return s;
}
//---------------------------------------------------------------------------
int CalculateVozrastMnt2(TDateTime now, TDateTime date)
{
        AnsiString dt1, dt2;
        int d1, d2, m1, m2, y1, y2;
        dt1=DateToStr(date);
        dt2=DateToStr(now);
        d1=atoi(dt1.SubString(1, 2).c_str());
        d2=atoi(dt2.SubString(1, 2).c_str());
        m1=atoi(dt1.SubString(4, 2).c_str());
        m2=atoi(dt2.SubString(4, 2).c_str());
        y1=atoi(dt1.SubString(7, 4).c_str());
        y2=atoi(dt2.SubString(7, 4).c_str());

        // ������� ���-�� ������� ����� ������, ��������� �����
        int ret_val = (m2 - m1) + (y2 - y1) * 12;
        if(d2 >= d1) ret_val++;


        return ret_val;
}
//---------------------------------------------------------------------------
int MonthCalculator(int days)
{
   return  Ceil(RoundInt(static_cast<double>(days / 30.4375))) ;
}
//---------------------------------------------------------------------------
void Copy(TWinControl* ParentFrom, TWinControl* ParentTo)
{
  //return;
  
try{
   for(int i = 0, pc1 = ParentFrom->ControlCount; i < pc1; ++i){
      TControl* cnt_from = ParentFrom->Controls[i];
      for(int j = 0, pc2 = ParentTo->ControlCount; j < pc2; ++j){
         TControl* cnt_to = ParentTo->Controls[j];
         if(cnt_to->Tag > 0 && cnt_from->Tag > 0 && cnt_to->Tag == cnt_from->Tag){
            if(cnt_to->InheritsFrom(__classid(TCustomEdit)))
               SetStrProp(cnt_to, "Text", GetStrProp(cnt_from, "Text"));
            else if(cnt_to->InheritsFrom(__classid(TButtonControl)))
               SetOrdProp(cnt_to, "Checked", GetOrdProp(cnt_from, "Checked"));
            else if(cnt_to->InheritsFrom(__classid(TCustomComboBox))){
               dynamic_cast<TCustomComboBox*>(cnt_to)->Items->Assign(dynamic_cast<TCustomComboBox*>(cnt_from)->Items);
               dynamic_cast<TCustomComboBox*>(cnt_to)->ItemIndex = dynamic_cast<TCustomComboBox*>(cnt_from)->ItemIndex;
            }
         }
      }
   }
}catch(...){}
}
//---------------------------------------------------------------------------
bool getDecodDate(TDateTime start, TDateTime end, short &m, short &d)
{
  TDateTime dateInc = start, datePreInc = start;
  m = d = 0;

   while(1){
      dateInc = Inc_Month(dateInc);
      int date = (int)Dateutils::CompareDate(end, dateInc);
      if(date == LessThanValue) break;
      datePreInc = dateInc;
      m++;
   }
   d = Dateutils::DaysBetween(datePreInc, end);

   return true;
}
//----------------------------------------------------------------
TDateTime Inc_Month(TDateTime date)
{
   unsigned short year, month, day, hour, minute, second, msecond;
   Dateutils::DecodeDateTime(date, year, month, day, hour, minute, second, msecond);
   if(month == 12) year++;
   month = (month % 12) + 1;

   TDateTime dt;
   bool f(false);
   int i(0);
   while(!f && i < 33){
      if(TryEncodeDateTime(year, month, day, hour, minute, second, msecond, dt))  f = true;
      else day--;
      i++;
   }
   return dt;
}

AnsiString NormalizeStr(AnsiString StrToNormalize)
{
	const int numSymbols = 17;
 	AnsiString replace_Arr[numSymbols][2] =
 	{
        { "O", "0" },
        { "o", "0" },
        { "�", "0" },
        { "o", "0" },
        { "L", "1" },
        { "l", "1" },
        { "I", "1" },
        { "i", "1" },
        { "�", "3" },
        { "�", "3" },
        { "(", ""  },
        { ")", ""  },
        { ".", "" },
        { "-", "" },
        { "#", "" },
        { "�", "" },
        { " ", "" }
	};

	for (int i = 0; i < numSymbols; ++i) // ������: ���� i<16 - ����� i<17
  		StrToNormalize = StringReplace(StrToNormalize, replace_Arr[i][0], replace_Arr[i][1], TReplaceFlags() << rfReplaceAll); //TReplaceFlags()<< rfReplaceAll << rfIgnoreCase);

	return StrToNormalize;
}

bool IsDigitOnly(AnsiString Str)
{
  bool res = true;
  for(int i = 1; i <= Str.Length(); ++i)
  {
    res = Str[i] >= '0' && Str[i] <= '9';
    if (!res)
      break;
  }
  return res;
}

bool IsAllZero(AnsiString Str)
{
  bool allzero = false;
  if(Str.Length()>0)
  {
    allzero=true;
    for(int i=1; i <= Str.Length(); i++)
    {
      allzero = allzero && Str[i] == '0';

      if(!allzero)
        break;
    }
  }

  return allzero;
}

//----------------------------------------------------------------

void CheckServiceVersion(mops_api_032 *_m_api)
{
  Integer r, r1, r2;

  // _Mops_Variables_
  AnsiString dt =  _m_api->vrGetVariable(r, "_mops_global_StartDateNextVersionRSA_");
  AnsiString nextvers =  _m_api->vrGetVariable(r1, "_mops_global_NextVersionKbmRSA_");
  AnsiString curvers =  _m_api->vrGetVariable(r2, "_mops_global_CurVersionKbmRSA_");

  TDateTime servTime, startTime;
  _m_api->Get_And_Check_Server_DateTime(&servTime);

  startTime = Sysutils::StrToDateTimeDef(dt, NULL);

  MYGLOBAL::KBMServiceVersion = r == 0 && r1 == 0 && r2 == 0 && startTime <= servTime ? nextvers: curvers;
  MYGLOBAL::RSAServiceVersion = r == 0 && r1 == 0 && r2 == 0 && IncHour(startTime, -6) <= servTime ? nextvers: curvers;

  AnsiString sKBM = MYGLOBAL::KBMServiceVersion;
  AnsiString sRSA = MYGLOBAL::RSAServiceVersion;

  if (dt.Length() == 0 || nextvers.Length() == 0 || curvers.Length() == 0 || MYGLOBAL::KBMServiceVersion.IsEmpty() || MYGLOBAL::RSAServiceVersion.IsEmpty() )
  {
    //MYGLOBAL::KBMServiceVersion = "1.6";
    //MYGLOBAL::RSAServiceVersion = "1.6";

	//MYGLOBAL::KBMServiceVersion = "1.7";
	//MYGLOBAL::RSAServiceVersion = "1.7";

	MYGLOBAL::KBMServiceVersion = "1.8";
	MYGLOBAL::RSAServiceVersion = "1.8";

	//return;
  }
}

float GetKBMServiceVersion()
{
  float result;
  char tmpDecimalSeparator;
  tmpDecimalSeparator = DecimalSeparator;
  DecimalSeparator = '.';
  result = StrToFloat( MYGLOBAL::KBMServiceVersion);
  DecimalSeparator = tmpDecimalSeparator;

  return result;
}

float GetRSAServiceVersion()
{
  float result;
  char tmpDecimalSeparator;
  tmpDecimalSeparator = DecimalSeparator;
  DecimalSeparator = '.';
  result = StrToFloat( MYGLOBAL::RSAServiceVersion);
  DecimalSeparator = tmpDecimalSeparator;

  return result;
}

int GetMajorModuleVersion(mops_api_033 *_m_api)
{
  TStringList *sl=new TStringList();
  int res;
  AnsiString curr_modull = _m_api->GetModuleVersion(res, sl);
  int ver = StrToInt(sl->Values["������"][1]);
  return ver;
}

bool CanUseModuleV1(mops_api_033 *_m_api)
{
  int res;
  bool rv;
  AnsiString s = _m_api->vrGetVariable(res, "_mops_global_OSAGO_USE_V1_").UpperCase();
  rv = (s == "��" || s == "");
  
  return rv;
}

#pragma package(smart_init)
