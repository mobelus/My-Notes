//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Tmops_api.h"
#include "form_general.h"
#include "form_general_journal.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxClasses"
#pragma link "cxControls"
#pragma link "cxCustomData"
#pragma link "cxData"
#pragma link "cxDataStorage"
#pragma link "cxDBData"
#pragma link "cxEdit"
#pragma link "cxFilter"
#pragma link "cxGraphics"
#pragma link "cxGrid"
#pragma link "cxGridCustomTableView"
#pragma link "cxGridCustomView"
#pragma link "cxGridDBTableView"
#pragma link "cxGridLevel"
#pragma link "cxGridTableView"
#pragma link "cxStyles"
#pragma link "cxCurrencyEdit"
#pragma link "cxLabel"
#pragma resource "*.dfm"
TGeneralJournal *GeneralJournal;
//---------------------------------------------------------------------------
__fastcall TGeneralJournal::TGeneralJournal(TComponent* Owner, mops_api_027 *api)
    : TForm(Owner)
{
   m_api = api;

   TADOQuery *qf = m_api->dbGetCursor(res,"select * from OSAGO_R_general where deleted=0 order by id");

   for(qf->First();!qf->Eof;qf->Next())
   {
       ClientDataSet1->Insert();
       ClientDataSet1->FieldByName("id")->Value = qf->FieldByName("id")->Value;
       ClientDataSet1->FieldByName("strah")->Value = qf->FieldByName("strah")->Value;
       ClientDataSet1->FieldByName("status")->Value = qf->FieldByName("status")->Value;
       ClientDataSet1->FieldByName("allprem")->Value = qf->FieldByName("allprem")->Value;
       ClientDataSet1->Post();
   }
   
   m_api->dbCloseCursor(res,qf);
}

long TGeneralJournal::getmaxid()
{
   return 1+ m_api->dbGetIntFromQuery(res, "select max(id) from osago_r_general");
}

//---------------------------------------------------------------------------
void __fastcall TGeneralJournal::newgeneralClick(TObject *Sender)
{
  if(general) { delete general; general=NULL; }
  general = new TGeneral(this, m_api, getmaxid(), 0);
  general->Show();
}
//---------------------------------------------------------------------------

void __fastcall TGeneralJournal::editgeneralClick(TObject *Sender)
{
  if( TableView1->DataController->Controller->FocusedRecord &&
     TableView1->DataController->Controller->FocusedRecord->Values[0] != NULL) {
     int general_id = TableView1->DataController->Controller->FocusedRecord->Values[0];

     if(general!=NULL) { delete general; general=NULL; }
     general = new TGeneral(this, m_api, general_id, 1);
     general->LoadForm(general_id);
     general->Show();

  } else {
    ShowMessage("���� ������� �������");
  }
}
//---------------------------------------------------------------------------

void __fastcall TGeneralJournal::delgeneralClick(TObject *Sender)
{
   int selindx = ClientDataSet1->RecNo;
   if( selindx == -1 ) return;

  if( Application->MessageBox( "������ �������?", "��������", MB_YESNO) == IDYES) {
     long general_id = TableView1->DataController->Controller->FocusedRecord->Values[0].intVal;
     m_api->dbExecuteQuery(res, "update OSAGO_R_general set deleted=1 where id=" + IntToStr(general_id));
     ClientDataSet1->Delete();
  }
   refresh();
}
//---------------------------------------------------------------------------


void TGeneralJournal::refresh() {
   ClientDataSet1->DisableControls();
   try {
     ClientDataSet1->EmptyDataSet();
   } __finally {
     ClientDataSet1->EnableControls();
   }

   TADOQuery *qf = m_api->dbGetCursor(res,"select * from OSAGO_R_general where deleted=0");
   for(qf->First();!qf->Eof;qf->Next()) {
       ClientDataSet1->Insert();
       ClientDataSet1->FieldByName("id")->Value = qf->FieldByName("id")->Value;
       ClientDataSet1->FieldByName("strah")->Value = qf->FieldByName("strah")->Value;
       ClientDataSet1->FieldByName("status")->Value = qf->FieldByName("status")->Value;
       ClientDataSet1->FieldByName("allprem")->Value = qf->FieldByName("allprem")->Value;
       ClientDataSet1->Post();
   }
   m_api->dbCloseCursor(res,qf);

}

void __fastcall TGeneralJournal::SpeedButton2Click(TObject *Sender)
{
    refresh();
}
//---------------------------------------------------------------------------


