
#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
#include "DmCriticalSection.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
DmSysCriticalSection::DmSysCriticalSection()
{
#if (_WIN32_WINNT >= 0x0403)

   DWORD res = InitializeCriticalSectionAndSpinCount(&lock, 128);
	if(!res)
      throw Exception(SysErrorMessage(GetLastError()));
#else
	InitializeCriticalSection(&lock);
#endif

}
//---------------------------------------------------------------------------
DmSysCriticalSection::DmSysCriticalSection(DWORD val)
{
#if (_WIN32_WINNT >= 0x0403)
   DWORD res = InitializeCriticalSectionAndSpinCount(&lock, val);
	if(!res)
      throw Exception(SysErrorMessage(GetLastError()));
#else
	InitializeCriticalSection(&lock);
#endif
}
//---------------------------------------------------------------------------
DmSysCriticalSection::~DmSysCriticalSection()
{
   DeleteCriticalSection(&lock);
}
//---------------------------------------------------------------------------
void DmSysCriticalSection::Acquire()
{
   EnterCriticalSection(&lock);
}
//---------------------------------------------------------------------------
bool DmSysCriticalSection::TryAcquire()
{
#if (_WIN32_WINNT >= 0x0400)
   return TryEnterCriticalSection(&lock);
#else
	EnterCriticalSection(&lock);
	return true;
#endif
}
//---------------------------------------------------------------------------
void DmSysCriticalSection::Release()
{
   LeaveCriticalSection(&lock);
}
//---------------------------------------------------------------------------

