//---------------------------------------------------------------------------

#ifndef excelH
#define excelH

//���������, ������������ ��� ��������� �����:
#define xlInsideHorizontal 12
#define xlInsideVertical 11
#define xlDiagonalDown 5
#define xlDiagonalUp 6
#define xlEdgeBottom 9
#define xlEdgeLeft 7
#define xlEdgeRight 10
#define xlEdgeTop 8
//��������� ����� �����
#define xlContinuous 1
#define xlDash -4115
#define xlDashDot 4
#define xlDashDotDot 5
#define xlDot -4118
#define xlDouble -4119
#define xlSlantDashDot 13
#define xlLineStyleNone -4142
//������� �����
#define xlHairline 1
#define xlMedium -4138
#define xlThick 4
#define xlThin 2

#include "DmLog.h"
#include <vcl.h>
//---------------------------------------------------------------------------
class Excel{
private:
   Variant App, Sh;
   DmLog* plog;
   DmErr* perr;
public:
   Excel() : plog(0), perr(0) {}
   Excel(DmErr* pe, DmLog* pl) : perr(pe), plog(pl) {}
   ~Excel() { plog = 0; perr = 0; }
   void ExcelInit(AnsiString File);
   void Free();
   void Visible(bool visible);
   void toExcelCell(int Row, int Column, AnsiString data);
   AnsiString fromExcelCell(int Row,int Column);
   Variant VariantFromExcelCell(int Row, int Column);
   AnsiString GetActiverange();
   int StolbecCharToInt(AnsiString st);
   void Print();

   void SaveBook();
   void SaveBook(AnsiString File_Name);

   void InsertRow(int row_num);

   int CheckBoxes_Count();
   AnsiString Get_CheckBox_name(int index);
   void SetCheckBox(int shape_index, bool checked);

   void SetRowOrientation(int row_num, int Orientation);

   void toExcelCell(int c1, int c2, Variant data);
   void Merge(char* Range);
   void HorAlign(int sRow, int sCol, int val);
   void VertAlign(int sRow, int sCol,int val);
   void SetFont(int sRow, int sCol, TFont *Fnt);
   void SetColor(int sRow, int sCol, int Color);
   void SetColor(char* Range ,int Color);
   void SetFrame(int sRow, int sCol, int gde, int line_style, int weight, int color);
   void SetFrame(char* Range, int gde, int line_style, int weight, int color);
   void SetFrameCellss(int sRow, int sCol, int line_style, int weight, int color);
   void SetOrientation(int sRow, int sCol, int Angle);
   void SetOrientation(char* Range, int Angle);
   void AutoFit(int sRow, int sCol);
   void AutoFit(int sRow);
   AnsiString GetRange(int start_row, int start_col, int end_row, int end_col);
   void Close();
   void SaveAs(AnsiString FileName);
   TRect GetActiverange2();
   void SetCheckBoxVisible();
   Variant __fastcall Excel::GetExcelCell(int c1,int c2);
};
//---------------------------------------------------------------------------
#endif
