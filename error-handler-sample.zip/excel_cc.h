//---------------------------------------------------------------------------

#ifndef excel_ccH
#define excel_ccH

#include <vcl.h>
//---------------------------------------------------------------------------
class Excel{
private:
   Variant App, Sh;
public:
   void ExcelInit(AnsiString File);
   void Free();
   void Visible(bool visible);
   void toExcelCell(int Row,int Column, AnsiString data);
   void toExcelCellV(int Row,int Column, Variant data);
   void Format(int Row, int Column, const char* fmt);
   AnsiString fromExcelCell(int Row,int Column);
   Variant VariantFromExcelCell(int Row,int Column);
   AnsiString GetActiverange();
   int StolbecCharToInt(AnsiString st);
   void Print();

   void SaveBook();
   void SaveBook(AnsiString File_Name);

   void InsertRow(int row_num);

   int CheckBoxes_Count();
   AnsiString Get_CheckBox_name(int index);
   void SetCheckBox(int shape_index, bool checked);

   void SetRowOrientation(int row_num, int Orientation);
   void AutoFit();
   bool CheckCompatibility(int flag);
   bool DeletedRangeCollumns(AnsiString sRang);
};
//---------------------------------------------------------------------------
#endif
