//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "UZayav1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRZayav1 *RZayav1;
//---------------------------------------------------------------------------
__fastcall TRZayav1::TRZayav1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TRZayav1::Print_Form(long calc_id,bool Preview)
{
   int res;
   TADOQuery *qw = m_api->dbGetCursor(res, "select * from OSAGO_R_main where calc_id=" + IntToStr(calc_id));
   if(qw->RecordCount != 1) return;

   QRLabel1->Caption =qw->FieldByName("pol_filial_name")->AsString;
   QRLabel119->Caption =qw->FieldByName("pol_zayav_strah_fio")->AsString;

   if(!qw->FieldByName("pol_zayav_strah_FU")->AsBoolean)
   {
      QRLabel73->Caption =qw->FieldByName("pol_zayav_strah_date_rojd")->AsString;
      QRLabel121->Caption = "";
   }
   else
   {
      QRLabel73->Caption = "";
      QRLabel121->Caption = qw->FieldByName("pol_zayav_strah_inn")->AsString;;
   }

   QRLabel12->Caption = qw->FieldByName("pol_zayav_strah_docum")->AsString;
   QRLabel83->Caption = qw->FieldByName("pol_zayav_strah_doc_ser")->AsString;
   QRLabel84->Caption = qw->FieldByName("pol_zayav_strah_doc_num")->AsString;
   QRLabel74->Caption = qw->FieldByName("pol_zayav_strah_index")->AsString;
   QRLabel75->Caption =qw->FieldByName("pol_zayav_sobstv_gos_vo")->AsString;
    if(!Trim(QRLabel75->Caption).IsEmpty()) QRLabel75->Caption = QRLabel75->Caption + ", ";
   QRLabel75->Caption = QRLabel75->Caption+ qw->FieldByName("pol_zayav_strah_res_kr_obl")->AsString;
   QRLabel76->Caption = qw->FieldByName("pol_zayav_strah_raion")->AsString;
   QRLabel77->Caption = qw->FieldByName("pol_zayav_strah_nas_punkt")->AsString;
   QRLabel78->Caption = qw->FieldByName("pol_zayav_strah_ulitsa")->AsString;
   QRLabel79->Caption = qw->FieldByName("pol_zayav_strah_dom")->AsString;
   QRLabel80->Caption = qw->FieldByName("pol_zayav_strah_korpus")->AsString;
   QRLabel81->Caption = qw->FieldByName("pol_zayav_strah_kvartira")->AsString;

   TStringList *sl=new TStringList();
   if(!qw->FieldByName("pol_zayav_strah_telefon")->AsString.IsEmpty())
    sl->Add("�������� "+qw->FieldByName("pol_zayav_strah_telefon")->AsString);
   if(!qw->FieldByName("pol_zayav_strah_telefon2")->AsString.IsEmpty())
    sl->Add("������� " +qw->FieldByName("pol_zayav_strah_telefon2")->AsString);
   if(!qw->FieldByName("pol_zayav_strah_telefon3")->AsString.IsEmpty())
    sl->Add("��������� " +qw->FieldByName("pol_zayav_strah_telefon3")->AsString);
     QRLabel82->Caption =StringReplace(sl->Text,"\r\n",", ",TReplaceFlags()<<rfReplaceAll).Delete(sl->Text.Length()-1,2);
    delete sl;





   QRLabel120->Caption = qw->FieldByName("pol_zayav_sobstv_fio")->AsString;
   if(!qw->FieldByName("pol_zayav_sobstv_FU")->AsBoolean)
   {
      QRLabel88->Caption = qw->FieldByName("pol_zayav_sobstv_date_rojd")->AsString;
      QRLabel122->Caption="";
   }
   else
   {
      QRLabel88->Caption = "";
      QRLabel122->Caption = qw->FieldByName("pol_zayav_sobstv_inn")->AsString;
   }
   QRLabel31->Caption = qw->FieldByName("pol_zayav_sobstv_docum")->AsString;
   QRLabel86->Caption = qw->FieldByName("pol_zayav_sobstv_doc_ser")->AsString;
   QRLabel87->Caption = qw->FieldByName("pol_zayav_sobstv_doc_num")->AsString;
   QRLabel89->Caption = qw->FieldByName("pol_zayav_sobstv_index")->AsString;
   QRLabel90->Caption = qw->FieldByName("pol_zayav_sobstv_gos_vo")->AsString;
   if(Trim(QRLabel90->Caption ) != "") QRLabel90->Caption = QRLabel90->Caption + ", ";
   QRLabel90->Caption = QRLabel90->Caption + qw->FieldByName("pol_zayav_sobstv_res_kr_obl")->AsString;
   QRLabel91->Caption = qw->FieldByName("pol_zayav_sobstv_raion")->AsString;
   QRLabel92->Caption = qw->FieldByName("pol_zayav_sobstv_nas_punkt")->AsString;
   QRLabel93->Caption = qw->FieldByName("pol_zayav_sobstv_ulitsa")->AsString;
   QRLabel94->Caption = qw->FieldByName("pol_zayav_sobstv_dom")->AsString;
   QRLabel95->Caption = qw->FieldByName("pol_zayav_sobstv_korpus")->AsString;
   QRLabel96->Caption = qw->FieldByName("pol_zayav_sobstv_kvartira")->AsString;


   QRLabel97->Caption = qw->FieldByName("pol_zayav_ts_marka2")->AsString + " " +  qw->FieldByName("pol_zayav_ts_model2")->AsString + ", ��������� " + qw->FieldByName("pol_zayav_ts_kategor")->AsString;
   QRLabel98->Caption = qw->FieldByName("pol_zayav_ts_god")->AsString;

   if(qw->FieldByName("calc_moshnost_ls")->AsFloat!=0.0)
        QRLabel99->Caption = qw->FieldByName("calc_moshnost_ls")->AsString + "/" +qw->FieldByName("calc_moshnost_kvt")->AsString;
   else
        QRLabel99->Caption = "-";

   QRLabel101->Caption =qw->FieldByName("pol_zayav_ts_vin")->AsString;

   if (StrToIntDef(qw->FieldByName("pol_zayav_ts_max_mass")->AsString,0)!=0)
        QRLabel102->Caption = qw->FieldByName("pol_zayav_ts_max_mass")->AsString;
   else
        QRLabel102->Caption = "-";

   if(StrToIntDef(qw->FieldByName("pol_zayav_ts_kvo_mest")->AsString,0)!=0)
        QRLabel104->Caption = qw->FieldByName("pol_zayav_ts_kvo_mest")->AsString;
   else
        QRLabel104->Caption = "-";

   QRLabel103->Caption = qw->FieldByName("pol_zayav_ts_shassi")->AsString;
   QRLabel105->Caption = qw->FieldByName("pol_zayav_ts_kuzov")->AsString;
   QRLabel106->Caption = qw->FieldByName("pol_zayav_ts_PTS_ser")->AsString;
   QRLabel107->Caption = qw->FieldByName("pol_zayav_ts_PTS_num")->AsString;
   QRLabel108->Caption = qw->FieldByName("pol_zayav_ts_PTS_date")->AsString;
   QRLabel109->Caption = qw->FieldByName("pol_zayav_ts_gosznak")->AsString;

   //���������
   QRLabel9->Caption  = qw->FieldByName("pol_zayav_ts_tehosmort_ser")->AsString;
   QRLabel29->Caption = qw->FieldByName("pol_zayav_ts_tehosmort_num")->AsString;
   QRLabel33->Caption = qw->FieldByName("pol_zayav_ts_tehosmort_month")->AsString + " " + qw->FieldByName("pol_zayav_ts_tehosmort_year")->AsString; 

   QRLabel110->Caption = (qw->FieldByName("pol_zayav_ts_v_arendu")->AsBoolean ? "X" : " ");
   QRLabel111->Caption = (!qw->FieldByName("pol_zayav_ts_v_arendu")->AsBoolean ? "X" : " ");

   int pur_id=m_api->dbGetIntFromQuery(res,"select purpose_id from OSAGO_R_AutoDictOsagoVehPurpose "
                                  " where purpose_na='"+qw->FieldByName("pol_zayav_ts_cel_isp")->AsString+"'");
   QRLabel112->Caption = (pur_id== 1 ? "X" : " ");
   QRLabel113->Caption = (pur_id == 2 ? "X" : " ");
   QRLabel116->Caption = (pur_id == 5 ? "X" : " ");
   QRLabel117->Caption = (pur_id == 6 ? "X" : " ");
   QRLabel118->Caption = (pur_id == 9 ? "X" : " ");


     //���� ��� ����������� ���
   if(qw->FieldByName("calc_dopusk_bez_ogran")->AsBoolean)
           QRLabel100->Caption = qw->FieldByName("calc_klass_kbm")->AsString;
   else
     {

         AnsiString sql="SELECT count(*) as cnt FROM OSAGO_R_main INNER JOIN OSAGO_R_dop_k_upr ON "
                        "(OSAGO_R_main.pol_zayav_sobstv_date_rojd = OSAGO_R_dop_k_upr.data_rogd) AND "
                        "(OSAGO_R_main.pol_zayav_sobstv_sex = OSAGO_R_dop_k_upr.sex) AND (OSAGO_R_main.pol_zayav_sobstv_o = OSAGO_R_dop_k_upr.o)"
                        " AND (OSAGO_R_main.pol_zayav_sobstv_i = OSAGO_R_dop_k_upr.i) AND (OSAGO_R_main.pol_zayav_sobstv_f = OSAGO_R_dop_k_upr.f)"
                        " AND (OSAGO_R_main.calc_id ="+IntToStr(calc_id)+" AND  OSAGO_R_dop_k_upr.calc_id="+ IntToStr(calc_id)+")";

        if(m_api->dbGetIntFromQuery(res,sql)==1)
                  QRLabel100->Caption =qw->FieldByName("calc_klass_kbm")->AsString;
          else
                QRLabel100->Caption ="-";

      }


   QRLabel277->Caption = "�� ���� � " + qw->FieldByName("pol_zayav_srok_strah_s")->AsString + " �� " + qw->FieldByName("pol_zayav_srok_strah_po")->AsString;


   if(!qw->FieldByName("calc_dopusk_bez_ogran")->AsBoolean)
      QRLabel125->Caption = "";
   else
        {
         QRLabel125->Caption = "";
      /*  ����� �����-�� ����� ����������:
          sa ����� �� ������, ������� ��� �����, �������� �� sa ������ �� ������� � �� �����������
          ReportForm->QRLabel125->Caption = MoshnayaFunction(f->sa->Text);
     */
        }





    if(!Preview)
       QR->Print();
   else
       QR->Preview();
}












