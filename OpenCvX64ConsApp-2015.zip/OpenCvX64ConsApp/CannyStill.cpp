// CannyStill.cpp

// Sample code was taken from
// https://github.com/MicrocontrollersAndMore/OpenCV_3_Windows_10_Installation_Tutorial

/*
Configuration Properties->VC++ Directories
Include Directories = C:\C_Libraries\opencv - 3 - 1\build\include;
Library Directories = C:\C_Libraries\opencv - 3 - 1\build\x64\vc12\lib;
//*/

/*
To enable debugging :

1) Project->HelloWorld Properties
2) "Configuration Properties -> C/C++ -> General"
3) On the right, change "Debug Information Format" to "Program Database For Edit And Continue (/ZI)"
4) "Configuration Properties -> C/C++ -> Optimization"
5) On the right, change "Optimization" to "Disabled (/Od)"
6) "Configuration Properties -> C/C++ -> Linker"
7) On the left, select "Debugging"
8) On the right, change "Generate Debug Info" to "Yes"
9) Click ok
10) Set your breakpoints
11) Rebuild your application

Also when running your application use Ctrl + F5 to build and run it, this keeps the console window open long enough for you to see your output.
//*/

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

//#include <opencv2/imgproc/imgproc.hpp>
//#include <opencv2/highgui/highgui.hpp>
#include "opencv2/features2d/features2d.hpp"

#include<iostream>
#include<conio.h>           // may have to modify this line if not using Windows

//using namespace cv;
//using namespace std;


static void help()
{
	std::cout << "\nThis program demonstrates circle finding with the Hough transform.\n"
		"Usage:\n"
		"./houghcircles <image_name>, Default is ../data/board.jpg\n" << std::endl;
}

#if 0
int main(int argc, char** argv)
{
	/*
	cv::CommandLineParser parser(argc, argv, "{help h ||}{@image|../data/board.jpg|}");
	
	if (parser.has("help"))
	{
		help();
		return 0;
	}
	*/

}
#endif

bool cvExample_SearchCircles(cv::Mat imgOriginalCopy, cv::Mat &imgFinalResult)
{
	cv::Mat src_gray2;
	cv::cvtColor(imgOriginalCopy, src_gray2, CV_BGR2GRAY);

	cv::namedWindow("imgGray2", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgGray2", src_gray2); cv::waitKey(0);

	GaussianBlur(src_gray2, src_gray2, cv::Size(9, 9), 2, 2);

	cv::namedWindow("imgGaussianBlur", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgGaussianBlur", src_gray2); cv::waitKey(0);

	std::vector<cv::Vec3f> circles;
	/*
	HoughCircles(src_gray2
		, circles
		,CV_HOUGH_GRADIENT
		,4   // accumulator resolution (size of the image / 2)
		,5  // minimum distance between two circles
		,100 // Canny high threshold
		,100 // minimum number of votes
		,0   // min radius
		,100//0 // max radius
		); 
	*/
	//HoughCircles(src_gray2, circles, CV_HOUGH_GRADIENT, 1, src_gray2.rows / 8, 200, 20, 0, 0);
	HoughCircles(src_gray2, circles, CV_HOUGH_GRADIENT,
		2,   // accumulator resolution (size of the image / 2)
		5,  // minimum distance between two circles
		100, // Canny high threshold
		100, // minimum number of votes
		0, 1000); // min and max radius

	std::cout << circles.size() << std::endl;
	std::cout << "end of test" << std::endl;

	std::vector<cv::Vec3f>::const_iterator itc = circles.begin();
	while (itc != circles.end()) {

		cv::circle(src_gray2,
			cv::Point((*itc)[0], (*itc)[1]), // circle centre
			(*itc)[2],       // circle radius
			cv::Scalar(255), // color
			2);              // thickness

		++itc;
	}

	cv::namedWindow("image", CV_WINDOW_AUTOSIZE);
	cv::imshow("image", src_gray2); cv::waitKey(0);

	return circles.size() ? true : false;

/*

	// Use the Hough transform to detect circles in the combined threshold image
	cv::Mat img = imgOriginalCopy;
	if (imgOriginalCopy.empty())
	{
		return false;
	}

	cv::Mat cimg;
	medianBlur(img, imgOriginalCopy, 5);
	cvtColor(imgOriginalCopy, cimg, cv::COLOR_GRAY2BGR);
//	cvtColor(imgOriginalCopy, imgFinalResult, cv::COLOR_GRAY2BGR);
	std::vector<cv::Vec3f> circles;
	HoughCircles(imgOriginalCopy, circles, cv::HOUGH_GRADIENT, 1, 10,
		100, 30, 0, 0 //1, 30 // change the last two parameters
		// (min_radius & max_radius) to detect larger circles
		);

	for (size_t i = 0; i < circles.size(); i++)
	{
		cv::Vec3i c = circles[i];
		circle(imgFinalResult, cv::Point(c[0], c[1]), c[2], cv::Scalar(0, 0, 255), 3, cv::LINE_AA);
		circle(imgFinalResult, cv::Point(c[0], c[1]), 2, cv::Scalar(0, 255, 0), 3, cv::LINE_AA);
	}


	/*
	cv::Mat img = imgOriginalCopy;
	if (img.empty())
	{return false;}

	cv::Mat cimg;
	medianBlur(img, img, 5);
	cvtColor(img, cimg, cv::COLOR_GRAY2BGR);
	std::vector<cv::Vec3f> circles;
	HoughCircles(img, circles, cv::HOUGH_GRADIENT, 1, 10,
		100, 30, 1, 30 // change the last two parameters
		// (min_radius & max_radius) to detect larger circles
		);

	for (size_t i = 0; i < circles.size(); i++)
	{
		cv::Vec3i c = circles[i];
		circle(cimg, cv::Point(c[0], c[1]), c[2], cv::Scalar(0, 0, 255), 3, cv::LINE_AA);
		circle(cimg, cv::Point(c[0], c[1]), 2, cv::Scalar(0, 255, 0), 3, cv::LINE_AA);
	}
	*/

	//imshow("detected circles", cimg); cv::waitKey();

	//imgFinalResult = cimg;
	cv::namedWindow("imgCircles", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgCircles", imgFinalResult); cv::waitKey(0);
}



bool cvExample_ShowSomeFunctions(cv::Mat imgOriginalCopy, cv::Mat &imgFinalResult)
{
	cv::Mat imgGrayscale;       // grayscale of input image
	cv::Mat imgBlurred;         // intermediate blured image
	cv::Mat imgCanny;           // Canny edge image

	if (imgOriginalCopy.empty()) {                                  // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               // may have to modify this line if not using Windows
		return false;                                              // and exit program
	}

	cv::cvtColor(imgOriginalCopy, imgGrayscale, CV_BGR2GRAY);       // convert to grayscale

	cv::GaussianBlur(imgGrayscale,  // input image
		imgBlurred,                 // output image
		cv::Size(5, 5),             // smoothing window width and height in pixels
		1.5);                       // sigma value, determines how much the image will be blurred

	cv::Canny(imgBlurred,           // input image
		//imgCanny,                   // output image
		imgFinalResult,
		100,                        // low threshold
		200);                       // high threshold

	// declare windows
	// CV_WINDOW_AUTOSIZE is the default
	cv::namedWindow("imgOriginalCopy", CV_WINDOW_AUTOSIZE);     // note: you can use CV_WINDOW_NORMAL which allows resizing the window
	cv::imshow("imgOriginalCopy", imgOriginalCopy); cv::waitKey(0); // show window, until user presses a key

	cv::namedWindow("imgGrayscale", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgGrayscale", imgGrayscale); cv::waitKey(0);

	cv::namedWindow("imgBlurred", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgBlurred", imgBlurred); cv::waitKey(0);

	cv::namedWindow("imgCanny", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	//cv::imshow("imgCanny", imgCanny); cv::waitKey(0);
	cv::imshow("imgCanny", imgFinalResult); cv::waitKey(0);
}



#if 0
///////////////////////////////////////////////////////////////////////////////////////////////////
int main() {


	cv::Mat imgOriginal;  // input  image
	cv::Mat imgOriginalCopy;  // input  image
	cv::Mat imgFinal;     // output image

//	imgOriginal = cv::imread("img.jpg");          // open image
//	imgOriginal = cv::imread("..\\..\\pic\\pic.jpg");          // open image
//	imgOriginal = cv::imread("..\\..\\..\\pic\\pic.jpg");          // open image
	imgOriginal = cv::imread("C:\\_WORK_RGS\\MyFiles\\DISSER\\ISTRATOV\\videos\\ConsoleApplicationOpenCV\\pic\\ball.jpg"); //pic.jpg");          // open image


	if (imgOriginal.empty()) {                                  // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               // may have to modify this line if not using Windows
		return(0);                                              // and exit program
	}
	else { imgOriginalCopy = imgOriginal.clone(); }

	cv::namedWindow("image", CV_WINDOW_AUTOSIZE);
	cv::imshow("image", imgOriginal); cv::waitKey(0);

/*
	//cv::Mat img = imgOriginal;

	cv::Ptr<cv::MSER> ms = cv::MSER::create();
	std::vector<std::vector<cv::Point> > regions;
	std::vector<cv::Rect> mser_bbox;
	ms->detectRegions(imgOriginal, regions, mser_bbox);

	for (int i = 0; i < regions.size(); i++)
	{
		rectangle(imgOriginal, mser_bbox[i], CV_RGB(0, 255, 0));
	}

	imshow("mser", imgOriginal);
	cv::waitKey(0);
	return 0;
//*/

/////////////////////////////////////////////////
/*
	cv::Mat src_gray2;
	cv::cvtColor(imgOriginal, src_gray2, cv::COLOR_BGR2GRAY);
	cv::medianBlur(src_gray2, src_gray2, 5);
	std::vector<cv::Vec3f> circles;
	//HoughCircles(src_gray2, circles, CV_HOUGH_GRADIENT, 1, src_gray2.rows / 8, 200, 20, 0, 0);

	HoughCircles(src_gray2, circles, cv::HOUGH_GRADIENT, 1,
		src_gray2.rows / 16, // change this value to detect circles with different distances to each other
		100, 30, 1, 400 // change the last two parameters
		// (min_radius & max_radius) to detect larger circles
		);
//*/

//*
	cv::Mat src_gray2;
	cv::cvtColor(imgOriginal, src_gray2, CV_BGR2GRAY);

	cv::namedWindow("imgGray2", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgGray2", src_gray2); cv::waitKey(0);

	GaussianBlur(src_gray2, src_gray2, cv::Size(9, 9), 2, 2);

	cv::namedWindow("imgGaussianBlur", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgGaussianBlur", src_gray2); cv::waitKey(0);

	std::vector<cv::Vec3f> circles;
//	HoughCircles(src_gray2, circles, CV_HOUGH_GRADIENT, 1, src_gray2.rows / 8, 200, 20, 0, 0);
//*/

	int count_of_err = 0;
	for (int i = 0; i < 1000; i++)
	{
		for (int j = 0; j < 1000; j++)
		{
			try
			{
				//*
				HoughCircles(src_gray2, circles, CV_HOUGH_GRADIENT,
					//HoughCircles(imgOriginal, circles, CV_HOUGH_GRADIENT,
					2,   // accumulator resolution (size of the image / 2)
					5,  // minimum distance between two circles
					100, // Canny high threshold
					100, // minimum number of votes
					i, j); // min and max radius
					//0, 1000); // min and max radius
				//*/
			}
			catch (cv::Exception & e)
			{
				count_of_err++;
				std::cout << circles.size() << std::endl;
				//std::cerr << e.msg << std::endl; // output exception message
			}

		}
		
		if (circles.size() > 0)
		{
			std::cout << circles.size() << std::endl;
		}
	}


	std::cout << circles.size() << std::endl;
	std::cout << "end of test" << std::endl;
//*/

	std::vector<cv::Vec3f>::const_iterator itc = circles.begin();

	while (itc != circles.end()) {

		cv::circle(src_gray2,
			cv::Point((*itc)[0], (*itc)[1]), // circle centre
			(*itc)[2],       // circle radius
			cv::Scalar(255), // color
			2);              // thickness

		++itc;
	}
	cv::namedWindow("image", CV_WINDOW_AUTOSIZE);
	cv::imshow("image", src_gray2);
	cv::waitKey(0);


///////////////////////////////////////////////////






	// Exaple Function we will need:
	//cvExample_ShowSomeFunctions(imgOriginal, imgFinal);

	//imgOriginal = imgOriginalCopy;
	cvExample_SearchCircles(imgOriginal, imgFinal);


	// declare windows
	// CV_WINDOW_AUTOSIZE is the default
	cv::namedWindow("imgOriginal", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgOriginal", imgOriginal); cv::waitKey(0);

	cv::namedWindow("imgFinal", CV_WINDOW_AUTOSIZE);        // or CV_WINDOW_AUTOSIZE for a fixed size window matching the resolution of the image
	cv::imshow("imgFinal", imgFinal); cv::waitKey(0);
	
	cv::waitKey(0);                 // hold windows open until user presses a key
	return(0);
}
#endif


#if 0
using namespace cv;
using namespace std;

int hi = 1, lo = 1;

int main(int argc, char* argv[])
{
	Mat orig = imread("C:\\_WORK_RGS\\MyFiles\\DISSER\\ISTRATOV\\videos\\ConsoleApplicationOpenCV\\pic\\ball.jpg"); //pic.jpg");          // open image

	int key = 0;

	namedWindow("circles", 1);
	createTrackbar("hi", "circles", &hi, 255);
	createTrackbar("lo", "circles", &lo, 255);

	do
	{
		// update display and snooker, so we can play with them
		Mat display = orig.clone();

		Mat snooker;
		cvtColor(orig, snooker, CV_RGB2GRAY);

		vector<Vec3f> circles;

		// also preventing crash with hi, lo threshold here...
		HoughCircles(snooker, circles, CV_HOUGH_GRADIENT, 2, 32.0, hi > 0 ? hi : 1, lo > 0 ? lo : 1);
		for (size_t i = 0; i < circles.size(); i++)
		{
			Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
			int radius = cvRound(circles[i][2]);

			// draw the green circle center
			circle(display, center, 3, Scalar(0, 255, 0), -1, 8, 0);

			// draw the blue circle outline
			circle(display, center, radius, Scalar(255, 0, 0), 3, 8, 0);
		}

		imshow("circles", display);
		imshow("snooker", snooker);
		key = waitKey(33);
	}
	while ((char)key != 27);
	
	return 0;
}

#endif





















#if 1

#include "Blob.h"

#define SHOW_STEPS            // un-comment or comment this line to show steps or not

// global variables ///////////////////////////////////////////////////////////////////////////////
const cv::Scalar SCALAR_BLACK = cv::Scalar(0.0, 0.0, 0.0);
const cv::Scalar SCALAR_WHITE = cv::Scalar(255.0, 255.0, 255.0);
const cv::Scalar SCALAR_YELLOW = cv::Scalar(0.0, 255.0, 255.0);
const cv::Scalar SCALAR_GREEN = cv::Scalar(0.0, 200.0, 0.0);
const cv::Scalar SCALAR_RED = cv::Scalar(0.0, 0.0, 255.0);

// function prototypes ////////////////////////////////////////////////////////////////////////////
void fun_matchCurrentFrameBlobsToExistingBlobs(std::vector<Blob> &existingBlobs, std::vector<Blob> &currentFrameBlobs);
void fun_addBlobToExistingBlobs(Blob &currentFrameBlob, std::vector<Blob> &existingBlobs, int &intIndex);
void fun_addNewBlob(Blob &currentFrameBlob, std::vector<Blob> &existingBlobs);
double fun_distanceBetweenPoints(cv::Point point1, cv::Point point2);
void fun_drawAndShowContours(cv::Size imageSize, std::vector<std::vector<cv::Point> > contours, std::string strImageName);
void fun_drawAndShowContours(cv::Size imageSize, std::vector<Blob> blobs, std::string strImageName);
bool fun_checkIfBlobsCrossedTheLine(std::vector<Blob> &blobs, int &intHorizontalLinePosition, int &carCount);
void fun_drawBlobInfoOnImage(std::vector<Blob> &blobs, cv::Mat &imgFrame2Copy);
void fun_drawCarCountOnImage(int &carCount, cv::Mat &imgFrame2Copy);

///////////////////////////////////////////////////////////////////////////////////////////////////
int main(void) {

	cv::VideoCapture capVideo;

	cv::Mat imgFrame1;
	cv::Mat imgFrame2;

	std::vector<Blob> blobs;

	cv::Point crossingLine[2];

	int carCount = 0;

	capVideo.open("..\\..\\..\\pic\\CarsDrivingUnderBridge.mp4");
	//capVideo.open("C:\\_WORK_RGS\\MyFiles\\DISSER\\ISTRATOV\\videos\\ConsoleApplicationOpenCV\\pic\\CarsDrivingUnderBridge.mp4");

	if (!capVideo.isOpened()) {                                                 // if unable to open video file
		std::cout << "error reading video file" << std::endl << std::endl;      // show error message
		_getch();                   // it may be necessary to change or remove this line if not using Windows
		return(0);                                                              // and exit program
	}

	if (capVideo.get(CV_CAP_PROP_FRAME_COUNT) < 2) {
		std::cout << "error: video file must have at least two frames";
		_getch();                   // it may be necessary to change or remove this line if not using Windows
		return(0);
	}

	capVideo.read(imgFrame1);
	capVideo.read(imgFrame2);

	int intHorizontalLinePosition = (int)std::round((double)imgFrame1.rows * 0.35);

	crossingLine[0].x = 0;
	crossingLine[0].y = intHorizontalLinePosition;

	crossingLine[1].x = imgFrame1.cols - 1;
	crossingLine[1].y = intHorizontalLinePosition;

	char chCheckForEscKey = 0;

	bool blnFirstFrame = true;

	int frameCount = 2;

	while (capVideo.isOpened() && chCheckForEscKey != 27) {

		std::vector<Blob> currentFrameBlobs;

		cv::Mat imgFrame1Copy = imgFrame1.clone();
		cv::Mat imgFrame2Copy = imgFrame2.clone();

		cv::Mat imgDifference;
		cv::Mat imgThresh;

		cv::cvtColor(imgFrame1Copy, imgFrame1Copy, CV_BGR2GRAY);
		cv::cvtColor(imgFrame2Copy, imgFrame2Copy, CV_BGR2GRAY);

		cv::GaussianBlur(imgFrame1Copy, imgFrame1Copy, cv::Size(5, 5), 0);
		cv::GaussianBlur(imgFrame2Copy, imgFrame2Copy, cv::Size(5, 5), 0);

		cv::absdiff(imgFrame1Copy, imgFrame2Copy, imgDifference);

		cv::threshold(imgDifference, imgThresh, 30, 255.0, CV_THRESH_BINARY);

		cv::imshow("imgThresh", imgThresh);

		cv::Mat structuringElement3x3 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
		cv::Mat structuringElement5x5 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5));
		cv::Mat structuringElement7x7 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(7, 7));
		cv::Mat structuringElement15x15 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(15, 15));

		for (unsigned int i = 0; i < 2; i++) {
			cv::dilate(imgThresh, imgThresh, structuringElement5x5);
			cv::dilate(imgThresh, imgThresh, structuringElement5x5);
			cv::erode(imgThresh, imgThresh, structuringElement5x5);
		}

		cv::Mat imgThreshCopy = imgThresh.clone();

		// http://stackoverflow.com/questions/30514037/opencv-with-visual-studio-2013c-findcontours-breakpoint-error
		std::vector<std::vector<cv::Point> > contours;
		//std::vector<cv::Mat> contours;
		
		cv::findContours(imgThreshCopy, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		fun_drawAndShowContours(imgThresh.size(), contours, "imgContours");

		std::vector<std::vector<cv::Point> > convexHulls(contours.size());
		//std::vector<cv::Mat> convexHulls(contours.size());

		for (unsigned int i = 0; i < contours.size(); i++) {
			cv::convexHull(contours[i], convexHulls[i]);
		}

		fun_drawAndShowContours(imgThresh.size(), convexHulls, "imgConvexHulls");

		for (auto &convexHull : convexHulls) {
			Blob possibleBlob(convexHull);

			if (possibleBlob.currentBoundingRect.area() > 400 &&
				possibleBlob.dblCurrentAspectRatio > 0.2 &&
				possibleBlob.dblCurrentAspectRatio < 4.0 &&
				possibleBlob.currentBoundingRect.width > 30 &&
				possibleBlob.currentBoundingRect.height > 30 &&
				possibleBlob.dblCurrentDiagonalSize > 60.0 &&
				(cv::contourArea(possibleBlob.currentContour) / (double)possibleBlob.currentBoundingRect.area()) > 0.50) {
				currentFrameBlobs.push_back(possibleBlob);
			}
		}

		fun_drawAndShowContours(imgThresh.size(), currentFrameBlobs, "imgCurrentFrameBlobs");

		if (blnFirstFrame == true) {
			for (auto &currentFrameBlob : currentFrameBlobs) {
				blobs.push_back(currentFrameBlob);
			}
		}
		else {
			fun_matchCurrentFrameBlobsToExistingBlobs(blobs, currentFrameBlobs);
		}

		fun_drawAndShowContours(imgThresh.size(), blobs, "imgBlobs");

		imgFrame2Copy = imgFrame2.clone();          // get another copy of frame 2 since we changed the previous frame 2 copy in the processing above

		fun_drawBlobInfoOnImage(blobs, imgFrame2Copy);

		bool blnAtLeastOneBlobCrossedTheLine = fun_checkIfBlobsCrossedTheLine(blobs, intHorizontalLinePosition, carCount);

		if (blnAtLeastOneBlobCrossedTheLine == true) {
			cv::line(imgFrame2Copy, crossingLine[0], crossingLine[1], SCALAR_GREEN, 2);
		}
		else {
			cv::line(imgFrame2Copy, crossingLine[0], crossingLine[1], SCALAR_RED, 2);
		}

		fun_drawCarCountOnImage(carCount, imgFrame2Copy);

		cv::imshow("imgFrame2Copy", imgFrame2Copy);

		//cv::waitKey(0);                 // uncomment this line to go frame by frame for debugging

		// now we prepare for the next iteration

		currentFrameBlobs.clear();

		imgFrame1 = imgFrame2.clone();           // move frame 1 up to where frame 2 is

		if ((capVideo.get(CV_CAP_PROP_POS_FRAMES) + 1) < capVideo.get(CV_CAP_PROP_FRAME_COUNT)) {
			capVideo.read(imgFrame2);
		}
		else {
			std::cout << "end of video\n";
			break;
		}

		blnFirstFrame = false;
		frameCount++;
		chCheckForEscKey = cv::waitKey(1);
	}

	if (chCheckForEscKey != 27) {               // if the user did not press esc (i.e. we reached the end of the video)
		cv::waitKey(0);                         // hold the windows open to allow the "end of video" message to show
	}
	// note that if the user did press esc, we don't need to hold the windows open, we can simply let the program end which will close the windows

	return(0);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void fun_matchCurrentFrameBlobsToExistingBlobs(std::vector<Blob> &existingBlobs, std::vector<Blob> &currentFrameBlobs) {

	for (auto &existingBlob : existingBlobs) {

		existingBlob.blnCurrentMatchFoundOrNewBlob = false;

		existingBlob.predictNextPosition();
	}

	for (auto &currentFrameBlob : currentFrameBlobs) {

		int intIndexOfLeastDistance = 0;
		double dblLeastDistance = 100000.0;

		for (unsigned int i = 0; i < existingBlobs.size(); i++) {

			if (existingBlobs[i].blnStillBeingTracked == true) {

				double dblDistance = fun_distanceBetweenPoints(currentFrameBlob.centerPositions.back(), existingBlobs[i].predictedNextPosition);

				if (dblDistance < dblLeastDistance) {
					dblLeastDistance = dblDistance;
					intIndexOfLeastDistance = i;
				}
			}
		}

		if (dblLeastDistance < currentFrameBlob.dblCurrentDiagonalSize * 0.5) {
			fun_addBlobToExistingBlobs(currentFrameBlob, existingBlobs, intIndexOfLeastDistance);
		}
		else {
			fun_addNewBlob(currentFrameBlob, existingBlobs);
		}

	}

	for (auto &existingBlob : existingBlobs) {

		if (existingBlob.blnCurrentMatchFoundOrNewBlob == false) {
			existingBlob.intNumOfConsecutiveFramesWithoutAMatch++;
		}

		if (existingBlob.intNumOfConsecutiveFramesWithoutAMatch >= 5) {
			existingBlob.blnStillBeingTracked = false;
		}

	}

}

///////////////////////////////////////////////////////////////////////////////////////////////////
void fun_addBlobToExistingBlobs(Blob &currentFrameBlob, std::vector<Blob> &existingBlobs, int &intIndex) {

	existingBlobs[intIndex].currentContour = currentFrameBlob.currentContour;
	existingBlobs[intIndex].currentBoundingRect = currentFrameBlob.currentBoundingRect;

	existingBlobs[intIndex].centerPositions.push_back(currentFrameBlob.centerPositions.back());

	existingBlobs[intIndex].dblCurrentDiagonalSize = currentFrameBlob.dblCurrentDiagonalSize;
	existingBlobs[intIndex].dblCurrentAspectRatio = currentFrameBlob.dblCurrentAspectRatio;

	existingBlobs[intIndex].blnStillBeingTracked = true;
	existingBlobs[intIndex].blnCurrentMatchFoundOrNewBlob = true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void fun_addNewBlob(Blob &currentFrameBlob, std::vector<Blob> &existingBlobs) {

	currentFrameBlob.blnCurrentMatchFoundOrNewBlob = true;

	existingBlobs.push_back(currentFrameBlob);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
double fun_distanceBetweenPoints(cv::Point point1, cv::Point point2) {

	int intX = abs(point1.x - point2.x);
	int intY = abs(point1.y - point2.y);

	return(sqrt(pow(intX, 2) + pow(intY, 2)));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//void fun_drawAndShowContours(cv::Size imageSize, std::vector<cv::Mat> contours, std::string strImageName)
void fun_drawAndShowContours(cv::Size imageSize, std::vector<std::vector<cv::Point> > contours, std::string strImageName)
{
	cv::Mat image(imageSize, CV_8UC3, SCALAR_BLACK);

	cv::drawContours(image, contours, -1, SCALAR_WHITE, -1);

	cv::imshow(strImageName, image);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void fun_drawAndShowContours(cv::Size imageSize, std::vector<Blob> blobs, std::string strImageName)
{

	cv::Mat image(imageSize, CV_8UC3, SCALAR_BLACK);

	std::vector<std::vector<cv::Point> > contours;

	for (auto &blob : blobs) {
		if (blob.blnStillBeingTracked == true) {
			contours.push_back(blob.currentContour);
		}
	}

	cv::drawContours(image, contours, -1, SCALAR_WHITE, -1);

	cv::imshow(strImageName, image);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
bool fun_checkIfBlobsCrossedTheLine(std::vector<Blob> &blobs, int &intHorizontalLinePosition, int &carCount) {
	bool blnAtLeastOneBlobCrossedTheLine = false;

	for (auto blob : blobs) {

		if (blob.blnStillBeingTracked == true && blob.centerPositions.size() >= 2) {
			int prevFrameIndex = (int)blob.centerPositions.size() - 2;
			int currFrameIndex = (int)blob.centerPositions.size() - 1;

			if (blob.centerPositions[prevFrameIndex].y > intHorizontalLinePosition && blob.centerPositions[currFrameIndex].y <= intHorizontalLinePosition) {
				carCount++;
				blnAtLeastOneBlobCrossedTheLine = true;
			}
		}

	}

	return blnAtLeastOneBlobCrossedTheLine;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void fun_drawBlobInfoOnImage(std::vector<Blob> &blobs, cv::Mat &imgFrame2Copy) {

	for (unsigned int i = 0; i < blobs.size(); i++) {

		if (blobs[i].blnStillBeingTracked == true) {
			cv::rectangle(imgFrame2Copy, blobs[i].currentBoundingRect, SCALAR_RED, 2);

			int intFontFace = CV_FONT_HERSHEY_SIMPLEX;
			double dblFontScale = blobs[i].dblCurrentDiagonalSize / 60.0;
			int intFontThickness = (int)std::round(dblFontScale * 1.0);

			cv::putText(imgFrame2Copy, std::to_string(i), blobs[i].centerPositions.back(), intFontFace, dblFontScale, SCALAR_GREEN, intFontThickness);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void fun_drawCarCountOnImage(int &carCount, cv::Mat &imgFrame2Copy) {

	int intFontFace = CV_FONT_HERSHEY_SIMPLEX;
	double dblFontScale = (imgFrame2Copy.rows * imgFrame2Copy.cols) / 300000.0;
	int intFontThickness = (int)std::round(dblFontScale * 1.5);

	cv::Size textSize = cv::getTextSize(std::to_string(carCount), intFontFace, dblFontScale, intFontThickness, 0);

	cv::Point ptTextBottomLeftPosition;

	ptTextBottomLeftPosition.x = imgFrame2Copy.cols - 1 - (int)((double)textSize.width * 1.25);
	ptTextBottomLeftPosition.y = (int)((double)textSize.height * 1.25);

	cv::putText(imgFrame2Copy, std::to_string(carCount), ptTextBottomLeftPosition, intFontFace, dblFontScale, SCALAR_GREEN, intFontThickness);

}

#endif








