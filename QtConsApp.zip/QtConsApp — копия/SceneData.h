#ifndef SCENE_DATA_INFO_H
#define SCENE_DATA_INFO_H

#include <string>
#include <cstdint>

#include <QFile>
#include <QTextStream>

#include <QDomElement>
#include <QDomNodeList>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

#include <QPen>


class SceneDataTag
{
public:
	struct SScriptGraphicObjectTag {
		int objectNumber;
		double x, y, m11, m12, m21, m22;
		QString object_name, script_type;
	} m_ScriptGraphicObjectInfo;

	struct SCaptionTag {
		double x, y, connectX, connectY;
		QString text;
	} m_CaptionInfo;

	QRectF  m_boundingRectInfo;

	QString m_scriptObjVar;
	QString m_scriptInit;
};

//class SceneDataStationsTag
//{
//public:
//	QString m_stationName;
//	QVector<SceneDataTag> m_dataOnStation;
//}

#endif // #ifndef SCENE_DATA_INFO_H
