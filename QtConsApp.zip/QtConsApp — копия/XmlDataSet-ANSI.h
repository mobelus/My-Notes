#pragma once

#include "SceneDataSet.h"

class XmlDataSet : public SceneDataSet
{
public:
	XmlDataSet(QString path)
	{
		m_path = path;
	}

	virtual void loadInfo();
	virtual void saveInfo();

	virtual QStringList loadConfig(QString path = "");
	virtual QStringList saveConfig(QString path = "");

	virtual QStringList loadData();
	virtual void loadObjectsForOneStation(QDomElement tag, QVector<SceneDataTag> &objectsOnStation, QStringList &errors);
	virtual void loadScriptObjectParams(QDomElement tag, SceneDataTag &dataForScriptObject, QStringList &errors);
	virtual QStringList saveData();

};


