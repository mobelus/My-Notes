#pragma once

#include <string>
#include <cstdint>

#include <XmlUtils.hpp>

#include <QCryptographicHash>

#include <QFile>
#include <QTextStream>
#include <QTextCodec>

//#include <QXmlStreamWriter>
//#include <QXmlStreamReader>
//#include <QXmlStreamAttribute>


#include <QDomElement>
#include <QDomNodeList>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

#include <QPen>
#include <QDebug>


inline QString colorToString(const QColor &color) //const
{
	return "0x" + QString::number(color.rgba(), 16);
}


static Qt::PenStyle resolvePenStyle(const QString &style)
{
	if (style == "solid" || style.isEmpty()) return Qt::SolidLine;
	else if (style == "nopen") return Qt::NoPen;
	else if (style == "dash") return Qt::DashLine;
	else if (style == "dot") return Qt::DotLine;
	else return Qt::NoPen;
}

static QString penStyleToString(const Qt::PenStyle &style)
{
	switch (style)
	{
	case Qt::SolidLine: return "solid";
	case Qt::DashLine: return "dash";
	case Qt::DotLine: return "dot";
	case Qt::NoPen:
	default:  return "nopen";
	}
}


