#ifndef XML_UTILS_HPP
#define XML_UTILS_HPP

#include <QtXml/QDomElement>
#include <QtCore/QFile>
#include <QtCore/QTextStream>

/**
	@brief Load XML file

	@param doc XML document reference
	@param file Path to file
	@param errors Reference to list of errors
	@return Root tag of XML file
*/
inline QDomElement loadXmlFile(QDomDocument &doc, const QString &filename, QStringList &errors)
{
	QFile file(filename);
	if(!file.open(QIODevice::ReadOnly))
	{
		errors += QStringList("loadXmlFile(): cannot open file '" + filename + "'");
		return QDomElement();
	}

	if(!doc.setContent(&file))
	{
		errors += QStringList("loadXmlFile(): File '" + filename + "' is corrupted!") ;
		return QDomElement();
	}

	return doc.firstChildElement();
}



/**
	@brief Save XML document to file

	@param doc XML document
	@param filename Path to save
	@return List of errors
 */
inline QStringList saveXmlFile(QDomDocument doc, const QString &filename)
{
	QFile f(filename);
	if(!f.open(QIODevice::WriteOnly | QIODevice::Truncate))
		return QStringList("saveXmlFile(): cannot create file '" + filename + "'");

	QTextStream stream(&f);
	QString data = doc.toString(4);
	data.remove("&#xd;");
	stream << data;
	//f.write(doc.toString(4).toLocal8Bit());

	return QStringList();
}

#endif 
