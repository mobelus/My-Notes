#include "JsonDataSet.h"


void JsonDataSet::loadInfo()
{}
void JsonDataSet::saveInfo()
{}

QStringList JsonDataSet::loadConfig(QString path)
{
	if (!path.isEmpty() && !path.isNull())
		m_path = path;


	QStringList errors;

	return errors;
}


QStringList JsonDataSet::saveConfig(QString path)
{
	if (!path.isEmpty() && !path.isNull())
		m_path = path;


	QStringList errors;

	return errors;
}


QStringList JsonDataSet::loadData()
{
	/* test.json * /
	{
		"appDesc": {
			"description": "SomeDescription",
				"message" : "SomeMessage"
		},
		"appName" : {
			"description": "Home",
				"message" : "Welcome",
				"imp" : ["awesome", "best", "good"]
		}
	}
	//*/

	QString val;
	QFile file;
	file.setFileName(m_path);
	file.open(QIODevice::ReadOnly | QIODevice::Text);
	val = file.readAll();
	file.close();
	qDebug() << val;
	QJsonDocument d = QJsonDocument::fromJson(val.toUtf8());
	QJsonObject sett2 = d.object();
	QJsonValue value = sett2.value(QString("appName"));
	qDebug() << value;
	QJsonObject item = value.toObject();
	qDebug() << "QJsonObject of description: " << item;

	/* in case of string value get value and convert into string*/
	qDebug() << "QJsonObject[appName] of description: " << item["description"];
	QJsonValue subobj = item["description"];
	qDebug() << subobj.toString();

	/* in case of array get array and convert into string*/
	qDebug() << "QJsonObject[appName] of value: " << item["imp"];
	QJsonArray test = item["imp"].toArray();
	qDebug() << test[1].toString();

	return QStringList("");
}


QStringList JsonDataSet::saveData()
{
	QStringList errors;

	return errors;
}



