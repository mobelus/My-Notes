

const QString &path

// Load scene form test file
QFile fn(path);
if (!fn.open(QIODevice::ReadOnly)) return;
QString sceneData = fn.readAll();
sceneData.remove("&#xd;");
QDomDocument doc;
if (!doc.setContent(sceneData)) return QStringList("LogicDataset::load(): scene file is corrupted!");

QDomElement tag = doc.firstChildElement();
QDomElement tagData = tag.firstChildElement("data");

// Load scene configuration
QDomElement tagConfig = tag.firstChildElement("config"),
QSharedPointer<SceneConfiguration> config(new SceneConfiguration());
QStringList errors = config->load(tagConfig);
if (!errors.isEmpty()) return errors;


// Get extension for station name
_scene->setConfiguration(config);


int x, y;
QString text;
int connectX, connectY;
int y2, y1, x2, x1;
QString objectVar;
QString objectScript;








	const QString &path

	// Load scene form test file
	QFile fn(path);
	if (!fn.open(QIODevice::ReadOnly)) return;
	QString sceneData = fn.readAll();
	sceneData.remove("&#xd;");
	QDomDocument doc;
	if (!doc.setContent(sceneData)) return QStringList("LogicDataset::load(): scene file is corrupted!");

	QDomElement tag = doc.firstChildElement();

	// Load data
	QDomElement tagData = tag.firstChildElement("data");
	QDomNodeList stationsList = tagData.childNodes();
	for (int i = 0; i < stationsList.size(); ++i)
	{
		QDomElement tagStation = stationsList.at(i).toElement();
		if (tagStation.isNull() || tagStation.tagName() != "station")
			continue;

		_stationName = tagStation.attribute("name");
		if (_stationName.isEmpty())
		{
			errors += "LogicDataset::load(): Empty station name";
			continue;
		}

		// Get extension for station name
		_scene->setConfiguration(config);

		// Load data
		QStringList errs;
		_scene->loadData(tagStation, errs);		// BUG: data for all stations will load in one scene 
		if (!errs.isEmpty()) errors += errs;
	}
	return errors;
}

void ScriptScene::loadData(QDomElement tag, QStringList &errors)
{
	QDomNodeList nodes = tag.childNodes();
	for (int i = 0; i < nodes.size(); i++)
	{
		QDomElement tagProperty = nodes.at(i).toElement();
		if (tagProperty.isNull()) continue;
		if (tagProperty.tagName() != "ScriptGraphicObject")
		{
			errors += "ScriptScene::loadData(): Unsupported tag '" + tagProperty.tagName() + "'";
			continue;
		}

		/* Instance and add script object to scene */
		QString typeName = tagProperty.attribute("script_type"),
			objectName = tagProperty.attribute("object_name");
		if (typeName.simplified().isEmpty() || objectName.simplified().isEmpty())
		{
			errors += "ScriptScene::loadData(): Can not create Graphic representation of object '" + objectName + "' with type '" + typeName + "'. Reason: Empty name or type!";
			continue;
		}
		QString error;
		ScriptObject *object = addScriptObject(objectName, typeName, error);
		if (!object)
		{
			errors += "ScriptScene::loadData(): Can not create Graphic representation of object '" + objectName + "' with type '" + typeName + "'. Reason: " + error;
			continue;
		}

		/* Load objects parameters */
		object->load(tagProperty, errors);
	}

	/* Initialize all instanced script objects */
	QString err;
	for (auto it = _scriptObjects.begin(); it != _scriptObjects.end(); ++it)
	{
		initializeObject(it.value(), err);
		if (!err.isEmpty())
			errors += "ScriptScene::loadData(): Object '" + it.key() + "' error: " + err;
	}
}


void ScriptObject::load(QDomElement tag, QStringList &errors)
{
	if (tag.tagName() != "ScriptGraphicObject")
	{
		errors.append("ScriptObject::load(): wrong tag name <" + tag.tagName() + ">");
		return;
	}

	QDomElement boundTag = tag.firstChildElement("BoundingRect");
	QRectF bound = QRectF(0, 0, 100, 100);
	if (!boundTag.isNull())
	{
		bound = QRectF(boundTag.attribute("x1").toDouble(), boundTag.attribute("y1").toDouble(),
			boundTag.attribute("x2").toDouble(), boundTag.attribute("y2").toDouble());
	}
	_boundRect = bound;
	_boundRect.translate(0, -_boundRect.height() - 2 * _boundRect.y());

	double koefX = 1, koefY = 1;
	/* Set coordinates of object */
	QPointF p(tag.attribute("x").toDouble() * koefX, tag.attribute("y").toDouble() * koefY);
	QPointF pp = _parentScene ? _parentScene->toSceneCoords(p) : p;
	setPos(pp);

	_objectNumber = tag.attribute(OBJECT_NUMBER).toUInt();

	qreal m11 = tag.attribute("m11").toDouble(), m12 = tag.attribute("m12").toDouble(),
		m21 = tag.attribute("m21").toDouble(), m22 = tag.attribute("m22").toDouble();
	QTransform trans(m11, m12, m21, m22, 0, 0);
	setTransform(trans);


	/* Load caption data */
	QDomElement captionTag = tag.firstChildElement("caption");
	if (!captionTag.isNull())
	{
		QFont font = _parentScene ? _parentScene->defaultFont() : QFont("Times New Roman", 14);
		QColor color = _parentScene ? _parentScene->defaultFontColor() : QColor(Qt::black);
		_caption->setFont(font);
		_caption->setPlainText(captionTag.attribute("text"));
		_caption->setDefaultTextColor(color);

		QPointF captionPos(captionTag.attribute("x").toDouble() * koefX, captionTag.attribute("y").toDouble() * koefY);
		QPointF captionMapedPos = _parentScene ? _parentScene->toSceneCoords(captionPos) : captionPos;
		_caption->setPos(captionMapedPos);

		_captionConnect = QPointF(captionTag.attribute("connectX").toDouble(), captionTag.attribute("connectY").toDouble());
		updateCaptionDelta();
	}


	/* Read initialize script code */
	QDomElement scriptTag = tag.firstChildElement("script");
	if (scriptTag.isNull())
	{
		scriptTag = tag.firstChildElement("Script");
		if (scriptTag.isNull()) return;
	}
	QString initScript = scriptTag.text();
	setInitializeScript(initScript);
	setObjectVariable(scriptTag.attribute("objectVar"));
}





//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

QStringList loadScene(const QString &path)
{
	/* Load scene form test file */
	QFile fn(path);
	if (!fn.open(QIODevice::ReadOnly)) return QStringList("LogicDataset::load(): File '" + path + "' not open!");
	QString sceneData = fn.readAll();
	sceneData.remove("&#xd;");
	QDomDocument doc;
	if (!doc.setContent(sceneData)) return QStringList("LogicDataset::load(): scene file is corrupted!");

	QDomElement tag = doc.firstChildElement();
	QDomElement tagConfig = tag.firstChildElement("config"),
		tagData = tag.firstChildElement("data");

	/* Load scene configuration */
	QSharedPointer<SceneConfiguration> config(new SceneConfiguration());
	QStringList errors = config->load(tagConfig);
	if (!errors.isEmpty()) return errors;

	/* Load data */
	QDomNodeList stationsList = tagData.childNodes();
	for (int i = 0; i < stationsList.size(); ++i)
	{
		QDomElement tagStation = stationsList.at(i).toElement();
		if (tagStation.isNull() || tagStation.tagName() != "station")
			continue;

		_stationName = tagStation.attribute("name");
		if (_stationName.isEmpty())
		{
			errors += "LogicDataset::load(): Empty station name";
			continue;
		}

		/* Get extension for station name */
		_scene->setConfiguration(config);

		/* Load data */
		QStringList errs;
		_scene->loadData(tagStation, errs);		// BUG: data for all stations will load in one scene 
		if (!errs.isEmpty()) errors += errs;
	}
	return errors;
}

void ScriptScene::loadData(QDomElement tag, QStringList &errors)
{
	QDomNodeList nodes = tag.childNodes();
	for (int i = 0; i < nodes.size(); i++)
	{
		QDomElement tagProperty = nodes.at(i).toElement();
		if (tagProperty.isNull()) continue;
		if (tagProperty.tagName() != "ScriptGraphicObject")
		{
			errors += "ScriptScene::loadData(): Unsupported tag '" + tagProperty.tagName() + "'";
			continue;
		}

		/* Instance and add script object to scene */
		QString typeName = tagProperty.attribute("script_type"),
			objectName = tagProperty.attribute("object_name");
		if (typeName.simplified().isEmpty() || objectName.simplified().isEmpty())
		{
			errors += "ScriptScene::loadData(): Can not create Graphic representation of object '" + objectName + "' with type '" + typeName + "'. Reason: Empty name or type!";
			continue;
		}
		QString error;
		ScriptObject *object = addScriptObject(objectName, typeName, error);
		if (!object)
		{
			errors += "ScriptScene::loadData(): Can not create Graphic representation of object '" + objectName + "' with type '" + typeName + "'. Reason: " + error;
			continue;
		}

		/* Load objects parameters */
		object->load(tagProperty, errors);
	}

	/* Initialize all instanced script objects */
	QString err;
	for (auto it = _scriptObjects.begin(); it != _scriptObjects.end(); ++it)
	{
		initializeObject(it.value(), err);
		if (!err.isEmpty())
			errors += "ScriptScene::loadData(): Object '" + it.key() + "' error: " + err;
	}
}


void ScriptObject::load(QDomElement tag, QStringList &errors)
{
	if (tag.tagName() != "ScriptGraphicObject")
	{
		errors.append("ScriptObject::load(): wrong tag name <" + tag.tagName() + ">");
		return;
	}

	QDomElement boundTag = tag.firstChildElement("BoundingRect");
	QRectF bound = QRectF(0, 0, 100, 100);
	if (!boundTag.isNull())
	{
		bound = QRectF(boundTag.attribute("x1").toDouble(), boundTag.attribute("y1").toDouble(),
			boundTag.attribute("x2").toDouble(), boundTag.attribute("y2").toDouble());
	}
	_boundRect = bound;
	_boundRect.translate(0, -_boundRect.height() - 2 * _boundRect.y());

	double koefX = 1, koefY = 1;
	/* Set coordinates of object */
	QPointF p(tag.attribute("x").toDouble() * koefX, tag.attribute("y").toDouble() * koefY);
	QPointF pp = _parentScene ? _parentScene->toSceneCoords(p) : p;
	setPos(pp);

	_objectNumber = tag.attribute(OBJECT_NUMBER).toUInt();

	qreal m11 = tag.attribute("m11").toDouble(), m12 = tag.attribute("m12").toDouble(),
		m21 = tag.attribute("m21").toDouble(), m22 = tag.attribute("m22").toDouble();
	QTransform trans(m11, m12, m21, m22, 0, 0);
	setTransform(trans);


	/* Load caption data */
	QDomElement captionTag = tag.firstChildElement("caption");
	if (!captionTag.isNull())
	{
		QFont font = _parentScene ? _parentScene->defaultFont() : QFont("Times New Roman", 14);
		QColor color = _parentScene ? _parentScene->defaultFontColor() : QColor(Qt::black);
		_caption->setFont(font);
		_caption->setPlainText(captionTag.attribute("text"));
		_caption->setDefaultTextColor(color);

		QPointF captionPos(captionTag.attribute("x").toDouble() * koefX, captionTag.attribute("y").toDouble() * koefY);
		QPointF captionMapedPos = _parentScene ? _parentScene->toSceneCoords(captionPos) : captionPos;
		_caption->setPos(captionMapedPos);

		_captionConnect = QPointF(captionTag.attribute("connectX").toDouble(), captionTag.attribute("connectY").toDouble());
		updateCaptionDelta();
	}


	/* Read initialize script code */
	QDomElement scriptTag = tag.firstChildElement("script");
	if (scriptTag.isNull())
	{
		scriptTag = tag.firstChildElement("Script");
		if (scriptTag.isNull()) return;
	}
	QString initScript = scriptTag.text();
	setInitializeScript(initScript);
	setObjectVariable(scriptTag.attribute("objectVar"));
}

