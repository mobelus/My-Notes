#include "XmlDataSet.h"


void XmlDataSet::loadInfo()
{}
void XmlDataSet::saveInfo()
{}

QStringList XmlDataSet::loadConfig(QString path)
{
	if (!path.isEmpty() && !path.isNull())
		m_path = path;


	// Load scene form test file
	QFile fn(m_path);
	if (!fn.open(QIODevice::ReadOnly)) return QStringList("LogicDataset::load(): File '" + m_path + "' not open!");
	QString sceneData = fn.readAll();
	sceneData.remove("&#xd;");
	QDomDocument doc;
	if (!doc.setContent(sceneData)) return QStringList("LogicDataset::load(): scene file is corrupted!");

	// Load scene configuration
	QDomElement tag = doc.firstChildElement();
	QDomElement tagConfig = tag.firstChildElement("config");
	QDomNodeList nodes = tagConfig.childNodes();

	QStringList errors;

	for (int i = 0, ilen = nodes.size(); i < ilen; i++)
	{
		QDomElement currTag = nodes.at(i).toElement();
		if (currTag.isNull()) continue;

		QString tagName = currTag.tagName();

		// Scene parameters
		if (tagName == "scene")
		{
			SceneConfigInfo.m_SceneInfo.moveObjects = currTag.attribute("moveObjects") == "true";

			SceneConfigInfo.m_SceneInfo.fieldOff = currTag.attribute("fieldOff").toInt();
			SceneConfigInfo.m_SceneInfo.fieldWidth = currTag.attribute("fieldWidth").toInt();
			SceneConfigInfo.m_SceneInfo.fieldHeight = currTag.attribute("fieldHeight").toInt();

			// Load span parameters or set default values
			SceneConfigInfo.m_SceneInfo.spanEnable = currTag.attribute("spanEnable") != "false";
			bool res = false;
			SceneConfigInfo.m_SceneInfo.spanStep = currTag.attribute("spanStep").toInt(&res);
			if (!res) SceneConfigInfo.m_SceneInfo.spanStep = 10;
		}
		// Background parameters
		else if (tagName == "background")
		{	// background params
			SceneConfigInfo.m_BackgroundInfo.bkgroundColor = currTag.attribute("color").toUInt(0, 16);
			SceneConfigInfo.m_BackgroundInfo.visible = currTag.attribute("visible") == "true";
			// background pen params
			SceneConfigInfo.m_BackgroundInfo.penColor = currTag.attribute("penColor").toUInt(0, 16);
			SceneConfigInfo.m_BackgroundInfo.penWidth = currTag.attribute("penWidth").toUInt();
			SceneConfigInfo.m_BackgroundInfo.penStyle = currTag.attribute("penStyle");

			//_backgroundPen = loadPen(currTag);
		}
		// Grid parameters
		else if (tagName == "grid")
		{	// grid params
			SceneConfigInfo.m_GridInfo.gridStep = currTag.attribute("step").toUInt();
			SceneConfigInfo.m_GridInfo.visible = (currTag.attribute("visible") == "true");
			// grid pen params
			SceneConfigInfo.m_GridInfo.penColor = currTag.attribute("penColor").toUInt(0, 16);
			SceneConfigInfo.m_GridInfo.penWidth = currTag.attribute("penWidth").toUInt();
			SceneConfigInfo.m_GridInfo.penStyle = currTag.attribute("penStyle");
			//_gridPen = loadPen(currTag);
		}
		// Font parameters
		else if (tagName == "font")
		{
			SceneConfigInfo.m_FontInfo.family = currTag.attribute("family");
			SceneConfigInfo.m_FontInfo.bold = currTag.attribute("bold") == "true";
			SceneConfigInfo.m_FontInfo.italic = currTag.attribute("italic") == "true";
			SceneConfigInfo.m_FontInfo.size = currTag.attribute("size").toUInt();
			SceneConfigInfo.m_FontInfo.color = currTag.attribute("color").toUInt(0, 16);

			// _defaultFont  + _defaultFontColor
		}
		// Load initialize script code
		else if (tagName == "script")
		{
			SceneConfigInfo.m_script = currTag.text();
		}
		// Load colors
		else if (tagName == "colors")
		{
			QDomNodeList colorNodes = currTag.childNodes();
			SceneConfigInfo.m_colors.reserve(colorNodes.size());
			for (int i = 0, ilen = colorNodes.size(); i < ilen; i++)
			{
				QDomElement tagColor = colorNodes.at(i).toElement();
				if (tagColor.isNull()) continue;

				QString colorName = tagColor.attribute("name");
				QColor color = tagColor.attribute("value").toUInt(0, 16);
				SceneConfigInfo.m_colors.push_back(QPair<QString, QColor>(colorName, color));

				//_colors.push_back(QPair<QString, QColor>(tagColor.attribute("name"), color));
			}
		}
		// Load script types
		else if (tagName == "TypeDescription")
		{
			QString typeName = currTag.attribute("name");
			
if (typeName == "CONTROL_CUR") {
int z = 0;}

			if (SceneConfigInfo.m_scriptTypes.find(typeName) != SceneConfigInfo.m_scriptTypes.end())
			{
				errors += "ScriptScene::load(): Type '" + typeName + "' already exists!";
				continue;
			}

			QString scriptCode = currTag.text();
			if (scriptCode.isEmpty())
			{
				errors += "ScriptScene::load(): Type '" + typeName + "' not contained script code!";
				continue;
			}

			SceneConfigInfo.m_scriptTypes.insert(typeName, scriptCode);
			//generateIcon(typeName);
		}

		// Unsupported tag
		else
		{
			errors += "ScriptScene::load(): Unsupported tag name '" + tagName + "'";
			continue;
		}
	}

	return errors;
}


QStringList XmlDataSet::saveConfig(QString path)
{
	if (!path.isEmpty() && !path.isNull())
		m_path = path;


	//QStringList saveScene(const QString &path) const
	QStringList errors;

	QDomDocument doc;
	/* Create root element */
	QDomElement rootTag = doc.createElement("scene");
	doc.appendChild(rootTag);

	/* Save scene configuration */
	QDomElement configTag = doc.createElement("config");
	rootTag.appendChild(configTag);

	//_scene->configuration()->save(doc, configTag);

	/* Scene parameters */
	QDomElement tagScene = doc.createElement("scene");
	configTag.appendChild(tagScene);
	tagScene.setAttribute("moveObjects", SceneConfigInfo.m_SceneInfo.moveObjects ? "true" : "false");
	tagScene.setAttribute("fieldOff", QString::number(SceneConfigInfo.m_SceneInfo.fieldOff));
	tagScene.setAttribute("fieldWidth", QString::number(SceneConfigInfo.m_SceneInfo.fieldWidth));
	tagScene.setAttribute("fieldHeight", QString::number(SceneConfigInfo.m_SceneInfo.fieldHeight));
	tagScene.setAttribute("spanEnable", SceneConfigInfo.m_SceneInfo.spanEnable ? "true" : "false");
	tagScene.setAttribute("spanStep", QString::number(SceneConfigInfo.m_SceneInfo.spanStep));

	/* Background parameters */
	QDomElement tagBack = doc.createElement("background");
	configTag.appendChild(tagBack);
	tagBack.setAttribute("visible", SceneConfigInfo.m_BackgroundInfo.visible ? "true" : "false");
	tagBack.setAttribute("color", colorToString(QColor(SceneConfigInfo.m_BackgroundInfo.bkgroundColor)));

	QPen backgroundPen = QPen(QColor(SceneConfigInfo.m_BackgroundInfo.penColor), SceneConfigInfo.m_BackgroundInfo.penWidth, resolvePenStyle(SceneConfigInfo.m_BackgroundInfo.penStyle));
	savePen(backgroundPen, tagBack);
	//tagBack.setAttribute("penColor", colorToString(_backgroundPen.color()));
	//tagBack.setAttribute("penWidth", QString::number(_backgroundPen.width()));
	//tagBack.setAttribute("penStyle", penStyleToString(_backgroundPen.style()));

	/* Grid parameters */
	QDomElement tagGrid = doc.createElement("grid");
	configTag.appendChild(tagGrid);
	tagGrid.setAttribute("step", QString::number(SceneConfigInfo.m_GridInfo.gridStep));
	tagGrid.setAttribute("visible", SceneConfigInfo.m_GridInfo.visible ? "true" : "false");

	QPen gridPen = QPen(QColor(SceneConfigInfo.m_GridInfo.penColor), SceneConfigInfo.m_GridInfo.penWidth, resolvePenStyle(SceneConfigInfo.m_GridInfo.penStyle));
	savePen(gridPen, tagGrid);
	//tagGrid.setAttribute("penColor", colorToString(options.gridPen.color()));
	//tagGrid.setAttribute("penWidth", QString::number(options.gridPen.width()));
	//tagGrid.setAttribute("penStyle", penStyleToString(options.gridPen.style()));

	/* Font parameters */
	QDomElement tagFont = doc.createElement("font");
	configTag.appendChild(tagFont);

	tagFont.setAttribute("family", SceneConfigInfo.m_FontInfo.family);
	tagFont.setAttribute("size", QString::number(SceneConfigInfo.m_FontInfo.size /*pixelSize()*/  /*- 5*/ )); // !!! WHY -5 !!!
	tagFont.setAttribute("color", colorToString(SceneConfigInfo.m_FontInfo.color));
	tagFont.setAttribute("bold", SceneConfigInfo.m_FontInfo.bold ? "true" : "false");
	tagFont.setAttribute("italic", SceneConfigInfo.m_FontInfo.italic ? "true" : "false");

	/* Initialize script */
	QDomElement tagScript = doc.createElement("script");
	configTag.appendChild(tagScript);
	tagScript.appendChild(doc.createTextNode(SceneConfigInfo.m_script)); // SceneScript

																		 /* Output colors of library */
	QDomElement tagColors = doc.createElement("colors");
	QVector<QPair<QString, QColor> >::const_iterator it = SceneConfigInfo.m_colors.begin();
	while (it != SceneConfigInfo.m_colors.end())
	{
		QDomElement tagC = doc.createElement("color");
		tagC.setAttribute("name", it->first);
		tagC.setAttribute("value", colorToString(it->second));
		//QString cl = it->second.name();
		//cl.replace("#", "0x");
		//tagC.setAttribute("value", cl);
		//tagC.setAttribute("alpha", it->second.alpha());
		tagColors.appendChild(tagC);
		it++;
	}
	configTag.appendChild(tagColors);

	/* Output types */
	auto itType = SceneConfigInfo.m_scriptTypes.begin();
	auto itEnd = SceneConfigInfo.m_scriptTypes.end();

	for (; itType != itEnd; ++itType)
	{

if (itType.key() == "CONTROL_CUR") {
int z = 0;}

		QDomElement tagType = doc.createElement("TypeDescription");
		tagType.setAttribute("name", itType.key());
		QString script = itType.value();
		script.remove("&#xd");

		tagType.appendChild(doc.createTextNode(script));
		configTag.appendChild(tagType);
	}

	//return QStringList("");


	//errors += saveXmlFile(doc, m_path);
	/*
	QDomDocument opt;
	QFile iFile("options.xml");
	iFile.open(QFile::ReadOnly);
	opt.setContent(&iFile);

	QDomElement docElement = opt.documentElement(); // ������� ������
	QDomNode node = docElement.firstChildElement(elementName);

	node.childNodes().item(0).setNodeValue(value);
	*/

	QFile oFile(m_path);
	oFile.open(QFile::ReadWrite);

	QTextStream out(&oFile);
	//out.setCodec(QTextCodec::codecForName("UTF-8"));
	out.setCodec(QTextCodec::codecForName("UTF-16"));
	//out.setCodec(QTextCodec::codecForName("ASCII"));
	//out.setCodec(QTextCodec::codecForName("UNICODE"));
	doc.save(out, 5, QDomNode::EncodingFromTextStream);
	oFile.close();


	return errors;
}



QStringList XmlDataSet::loadData()
{
	QFile fn(m_path);
	if (!fn.open(QIODevice::ReadOnly)) return QStringList("LogicDataset::load(): File '" + m_path + "' not open!");
	QString sceneData = fn.readAll();
	sceneData.remove("&#xd;");
	QDomDocument doc;
	if (!doc.setContent(sceneData)) return QStringList("LogicDataset::load(): scene file is corrupted!");

	// Load scene data
	QDomElement tag = doc.firstChildElement();
	QDomElement	tagData = tag.firstChildElement("data");
	QDomNodeList stationsList = tagData.childNodes();

	QStringList errors;

	for (int i = 0, ilen = stationsList.size(); i < ilen; ++i)
	{
		QDomElement tagStation = stationsList.at(i).toElement();
		if (tagStation.isNull() || tagStation.tagName() != "station")
			continue;

		QString stationName = tagStation.attribute("name");
		if (stationName.isEmpty())
		{
			errors.append("LogicDataset::load(): Empty station name");
			continue;
		}

		/* Load data for One Station*/
		QVector<SceneDataTag> dataForStation;
		QStringList errs;
		//loadData(tagStation, errs);// BUG: data for all stations will load in one scene 

		loadObjectsForOneStation(tagStation, dataForStation, errs);
		if (!errs.isEmpty()) errors += errs;


		SceneDataOnStations.insert(stationName, dataForStation);
	}

	return errors;
}


void XmlDataSet::loadObjectsForOneStation(QDomElement tag, QVector<SceneDataTag> &objectsOnStation, QStringList &errors)
{
	QDomNodeList nodes = tag.childNodes();
	for (int i = 0, ilen = nodes.size(); i < ilen; i++)
	{
		SceneDataTag dataOfOneObj;

		QDomElement tagProperty = nodes.at(i).toElement();
		if (tagProperty.isNull()) continue;
		if (tagProperty.tagName() != "ScriptGraphicObject")
		{
			errors += "ScriptScene::loadData(): Unsupported tag '" + tagProperty.tagName() + "'";
			continue;
		}

		/* Instance and add script object to scene */
		QString typeName = tagProperty.attribute("script_type"),
			objectName = tagProperty.attribute("object_name");
		if (typeName.simplified().isEmpty() || objectName.simplified().isEmpty())
		{
			errors += "ScriptScene::loadData(): Can not create Graphic representation of object '" + objectName + "' with type '" + typeName + "'. Reason: Empty name or type!";
			continue;
		}

		//QString error;
		//ScriptObject *object = addScriptObject(objectName, typeName, error);
		//if (!object)
		//{
		//	errors += "ScriptScene::loadData(): Can not create Graphic representation of object '" + objectName + "' with type '" + typeName + "'. Reason: " + error;
		//	continue;
		//}

		dataOfOneObj.m_ScriptGraphicObjectInfo.script_type = typeName;
		dataOfOneObj.m_ScriptGraphicObjectInfo.object_name = objectName;


		/* Load objects parameters */
		loadScriptObjectParams(tagProperty, dataOfOneObj, errors);

		objectsOnStation.push_back(dataOfOneObj);
	}

	/* Initialize all instanced script objects */
	//QString err;
	//for (auto it = _scriptObjects.begin(); it != _scriptObjects.end(); ++it)
	//{
	//	initializeObject(it.value(), err);
	//	if (!err.isEmpty())
	//		errors += "ScriptScene::loadData(): Object '" + it.key() + "' error: " + err;
	//}
}

void XmlDataSet::loadScriptObjectParams(QDomElement tag, SceneDataTag &dataForScriptObject, QStringList &errors)
{
	//void ScriptObject::load(QDomElement tag, QStringList &errors)
	//{
	if (tag.tagName() != "ScriptGraphicObject")
	{
		errors.append("ScriptObject::load(): wrong tag name <" + tag.tagName() + ">");
		return;
	}

	QDomElement boundTag = tag.firstChildElement("BoundingRect");
	QRectF bound = QRectF(0, 0, 100, 100);
	if (!boundTag.isNull())
	{
		bound = QRectF(boundTag.attribute("x1").toDouble(), boundTag.attribute("y1").toDouble(),
			boundTag.attribute("x2").toDouble(), boundTag.attribute("y2").toDouble());
	}
	dataForScriptObject.m_boundingRectInfo = bound;
	dataForScriptObject.m_boundingRectInfo.translate(0, -dataForScriptObject.m_boundingRectInfo.height() - 2 * dataForScriptObject.m_boundingRectInfo.y());

	/* Read coordinates of object */
	dataForScriptObject.m_ScriptGraphicObjectInfo.x = tag.attribute("x").toDouble();
	dataForScriptObject.m_ScriptGraphicObjectInfo.y = tag.attribute("y").toDouble();

	/* Set coordinates of object */
	//double koefX = 1, koefY = 1;
	//QPointF p(tag.attribute("x").toDouble() * koefX, tag.attribute("y").toDouble() * koefY);
	//QPointF pp = _parentScene ? _parentScene->toSceneCoords(p) : p;
	//setPos(pp);

	dataForScriptObject.m_ScriptGraphicObjectInfo.objectNumber = tag.attribute("objectNumber").toUInt();

	dataForScriptObject.m_ScriptGraphicObjectInfo.m11 = tag.attribute("m11").toDouble();
	dataForScriptObject.m_ScriptGraphicObjectInfo.m12 = tag.attribute("m12").toDouble();
	dataForScriptObject.m_ScriptGraphicObjectInfo.m21 = tag.attribute("m21").toDouble();
	dataForScriptObject.m_ScriptGraphicObjectInfo.m22 = tag.attribute("m22").toDouble();

	//qreal m11 = tag.attribute("m11").toDouble(), m12 = tag.attribute("m12").toDouble(),
	//	m21 = tag.attribute("m21").toDouble(), m22 = tag.attribute("m22").toDouble();
	//QTransform trans(m11, m12, m21, m22, 0, 0);
	//setTransform(trans);


	/* Load caption data */
	QDomElement captionTag = tag.firstChildElement("caption");
	if (!captionTag.isNull())
	{
		//QFont font = _parentScene ? _parentScene->defaultFont() : QFont("Times New Roman", 14);
		//QColor color = _parentScene ? _parentScene->defaultFontColor() : QColor(Qt::black);
		//_caption->setFont(font);

		dataForScriptObject.m_CaptionInfo.text = captionTag.attribute("text");

		//_caption->setPlainText(captionTag.attribute("text"));
		//_caption->setDefaultTextColor(color);

		dataForScriptObject.m_CaptionInfo.x = captionTag.attribute("x").toDouble();
		dataForScriptObject.m_CaptionInfo.y = captionTag.attribute("y").toDouble();

		//QPointF captionPos(captionTag.attribute("x").toDouble() * koefX, captionTag.attribute("y").toDouble() * koefY);
		//QPointF captionMapedPos = _parentScene ? _parentScene->toSceneCoords(captionPos) : captionPos;
		//_caption->setPos(captionMapedPos);

		dataForScriptObject.m_CaptionInfo.connectX = captionTag.attribute("connectX").toDouble();
		dataForScriptObject.m_CaptionInfo.connectY = captionTag.attribute("connectY").toDouble();

		//_captionConnect = QPointF(captionTag.attribute("connectX").toDouble(), captionTag.attribute("connectY").toDouble());
		//updateCaptionDelta();
	}


	/* Read initialize script code */
	QDomElement scriptTag = tag.firstChildElement("script");
	if (scriptTag.isNull())
	{

		scriptTag = tag.firstChildElement("Script");
		if (scriptTag.isNull()) return;
	}

	dataForScriptObject.m_scriptInit = scriptTag.text();
	//setInitializeScript(initScript);
	dataForScriptObject.m_scriptObjVar = scriptTag.attribute("objectVar");
	//setObjectVariable(scriptTag.attribute("objectVar"));
	//}
}


QStringList XmlDataSet::saveData()
{
	QStringList errors;

	return errors;
}




