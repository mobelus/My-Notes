#include "SceneDataSet.h"

#include "XmlDataSet.h"
#include "JsonDataSet.h"

SceneDataSet::DataType SceneDataSet::curData = TYPE_UNKNOWN;

SceneDataSet* SceneDataSet::identifyData(QString path)
{
	//if (extension.indexOf("json") != -1) {
	//	QString str = "aaaaaaa.json";
	//	int j = 0;
	//	while ((j = str.indexOf("<b>", j)) != -1)
	//	{ ++j; }
	//}

	// 1. Simple Extension check
	QString extension = path.right(4);
	if (extension == "json") {
		curData = SceneDataSet::TYPE_JSON;
	}
	else if (extension[0] == ".") {
		extension = path.right(3);
		if (extension == "xml") {
			curData = SceneDataSet::TYPE_XML;
		}
	}
	else {
		curData = SceneDataSet::TYPE_UNKNOWN;
	}

	// 2. Cool Semantic Inner data of the File check
	if (curData == SceneDataSet::TYPE_UNKNOWN)
	{
		QFile inputFile(path);
		if (inputFile.open(QIODevice::ReadOnly))
		{
			float numLines = 0, numJsonBracketsFound = 0, numXmlBracketsFound = 0;
			QTextStream in(&inputFile);

			while (!in.atEnd() && numLines < 100)
			{
				QString line = in.readLine();
				//line.trimmed();
				//line.simplified();

				int n = line.size() - 1;
				for (; n >= 0; --n) // trim-right
				{
					if (line.at(n).isSpace())
						line = line.left(n + 1);
					else
						break;
				}
				for (int i = 0; i < line.size(); i++) // trim-left
				{
					if (line.at(i).isSpace()) {
						line = line.right(line.size() - 1);
						i--;
					}
					else
						break;
				}

				if ((line[0] == '<') && (line[line.size() - 1] == '>'))
					numXmlBracketsFound++;

				numJsonBracketsFound += line.count('{');

				numLines++;
			}
			inputFile.close();

			// if number of all found brackets is more or equal at least
			// 80% of all found lines then we make the decision
			if (numXmlBracketsFound >= numLines * 0.8 || numXmlBracketsFound > numJsonBracketsFound)
				curData = SceneDataSet::TYPE_XML;
			else if (numJsonBracketsFound >= numLines * 0.8 || numJsonBracketsFound > numXmlBracketsFound)
				curData = SceneDataSet::TYPE_JSON;
			else
				curData = SceneDataSet::TYPE_UNKNOWN;
		}
	}


	switch (curData)
	{
	case SceneDataSet::TYPE_XML:
		return new XmlDataSet(path);
		break;
	case SceneDataSet::TYPE_JSON:
		return new JsonDataSet(path);
		break;
	default:
		return 0;
	}
	
}



void SceneDataSet::savePen(const QPen &pen, QDomElement &tag) const
{
	tag.setAttribute("penColor", colorToString(pen.color()));
	tag.setAttribute("penWidth", QString::number(pen.width()));
	tag.setAttribute("penStyle", penStyleToString(pen.style()));
}

QPen SceneDataSet::loadPen(QDomElement tag) const
{
	QPen pen;
	QColor penColor = tag.attribute("penColor").toUInt(0, 16);
	int penWidth = tag.attribute("penWidth").toUInt();
	QString penStyle = tag.attribute("penStyle");

	return QPen(penColor, penWidth, resolvePenStyle(penStyle));
}


//SceneConfigTag SceneConfigInfo;






