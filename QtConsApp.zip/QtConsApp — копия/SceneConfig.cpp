#include "SceneConfig.h"

bool operator==(const SceneConfigTag& left, const SceneConfigTag& right) {
	return (
		left.m_FontInfo == right.m_FontInfo
		&&	left.m_SceneInfo == right.m_SceneInfo
		&&	left.m_BackgroundInfo == right.m_BackgroundInfo
		&&	left.m_GridInfo == right.m_GridInfo

		&&	left.m_script == right.m_script
		&&	left.m_colors == right.m_colors
		&&	left.m_scriptTypes == right.m_scriptTypes

		);
}



QPen SceneConfigTag::loadPen(QDomElement tag) const
{
	QPen pen;
	QColor penColor = tag.attribute("penColor").toUInt(0, 16);
	int penWidth = tag.attribute("penWidth").toUInt();
	QString penStyle = tag.attribute("penStyle");

	return QPen(penColor, penWidth, resolvePenStyle(penStyle));
}


void SceneConfigTag::savePen(const QPen &pen, QDomElement &tag) const
{
	tag.setAttribute("penColor", colorToString(pen.color()));
	tag.setAttribute("penWidth", QString::number(pen.width()));
	tag.setAttribute("penStyle", penStyleToString(pen.style()));
}


