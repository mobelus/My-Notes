#ifndef SCENE_DATA_SET_H
#define SCENE_DATA_SET_H

#include "helpers.h"

#include "SceneConfig.h"
#include "SceneData.h"


class SceneDataSet
{
protected:
	QString m_path;

public:
	SceneDataSet() {}
	virtual ~SceneDataSet() {}


	SceneConfigTag SceneConfigInfo;
	QMap<QString, QVector<SceneDataTag>> SceneDataOnStations;
	//SceneDataTag SceneDataInfo;

	enum DataType
	{
		TYPE_UNKNOWN = 0
		, TYPE_XML
		, TYPE_JSON
		, TYPE_DB
	};

	static DataType curData;

	// Factory method.
	static SceneDataSet* identifyData(QString path); // new !!! don't forget to call delete !!!

	void setPath(QString path) { m_path = path; }
	QString getPath() { return m_path; }

	//void generateIcon(const QString &scriptType);
	QPen loadPen(QDomElement tag) const;
	void savePen(const QPen &pen, QDomElement &tag) const;

	virtual void loadInfo() = 0;
	virtual void saveInfo() = 0;

	virtual QStringList loadConfig(QString path = "") = 0;
	virtual QStringList saveConfig(QString path = "") = 0;

	virtual QStringList loadData() = 0;
	virtual QStringList saveData() = 0;
};


#endif // #ifndef SCENE_DATA_SET_H
