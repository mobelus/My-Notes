#pragma once

#include "SceneDataSet.h"


class JsonDataSet : public SceneDataSet
{
public:
	JsonDataSet(QString path)
	{
		m_path = path;
	}

	virtual void loadInfo();
	virtual void saveInfo();

	virtual QStringList loadConfig(QString path = "");
	virtual QStringList saveConfig(QString path = "");

	virtual QStringList loadData();
	virtual QStringList saveData();

};




