#ifndef SCENE_CONFIG_INFO_H
#define SCENE_CONFIG_INFO_H

#include <string>
#include <cstdint>

#include <QFile>
#include <QTextStream>

#include <QDomElement>
#include <QDomNodeList>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

#include <QPen>

class SceneConfigTag
{
private:
	struct SSceneTag {
		bool moveObjects, spanEnable;
		int fieldWidth, fieldOff, fieldHeight, spanStep;

		bool operator == (const SSceneTag &rhs) const
		{
			return(
				moveObjects == rhs.moveObjects
				&&	spanEnable == rhs.spanEnable
				&&	fieldWidth == rhs.fieldWidth
				&&	fieldOff == rhs.fieldOff
				&&	fieldHeight == rhs.fieldHeight
				&&	spanStep == rhs.spanStep
				);
		}

	} m_SceneInfo;

	struct SFontTag {
		uint32_t size, color;
		bool bold, italic;
		QString family;

		bool operator == (const SFontTag &rhs) const
		{
			return(
				size == rhs.size
				&&	color == rhs.color
				&&	bold == rhs.bold
				&&	italic == rhs.italic
				&&	family == rhs.family
				);
		}

	} m_FontInfo;

	struct SSubstrateObjects
	{
		uint32_t penColor;
		short penWidth;
		bool visible;
		QString penStyle;
	};

	struct SBackgroundTag : SSubstrateObjects {
		uint32_t bkgroundColor;

		bool operator == (const SBackgroundTag &rhs) const
		{
			return(
				penColor == rhs.penColor
				&&	penWidth == rhs.penWidth
				&&	visible == rhs.visible
				&&	penStyle == rhs.penStyle
				&&	bkgroundColor == rhs.bkgroundColor
				);
		}

	} m_BackgroundInfo;

	struct SGridTag : SSubstrateObjects {
		uint32_t gridStep;

		bool operator == (const SGridTag &rhs) const
		{
			return(
				penColor == rhs.penColor
				&&	penWidth == rhs.penWidth
				&&	visible == rhs.visible
				&&	penStyle == rhs.penStyle
				&&	gridStep == rhs.gridStep
				);
		}

	} m_GridInfo;

	QString m_script;
	QVector<QPair<QString, QColor>> m_colors;
	mutable QMap<QString, QString> m_scriptTypes;


public:
	//	SSceneTag sceneInfo() const { return m_SceneInfo; }
	//	void setSceneInfo(const SSceneTag &sceneInfo) { m_SceneInfo = sceneInfo;  }
	SSceneTag & getSceneInfo()		 { return m_SceneInfo; }
	SFontTag & getFontInfo()		 { return m_FontInfo; }
	SGridTag & gridInfo()			 { return m_GridInfo; }
	SBackgroundTag & getBkgrndInfo() { return m_BackgroundInfo; }


	QString getSceneScript() { return m_script; }
	void setSceneScript(QString _script)
	{ m_script = _script; }


	QVector<QPair<QString, QColor>> const & getColors() { return m_colors; } // �������� ����� �������, �� ����� �� ��������
	QMap<QString, QString> const & getScriptTypes() { return m_scriptTypes; } // �������� ����� ������� � ���������, �� �� ��������


	// Functions part:
	QPen loadPen(QDomElement tag) const;
	void savePen(const QPen &pen, QDomElement &tag) const;


	// Helping functions
	static Qt::PenStyle resolvePenStyle(const QString &style)
	{
		if (style == "solid" || style.isEmpty()) return Qt::SolidLine;
		else if (style == "nopen") return Qt::NoPen;
		else if (style == "dash") return Qt::DashLine;
		else if (style == "dot") return Qt::DotLine;
		else return Qt::NoPen;
	}

	static QString penStyleToString(const Qt::PenStyle &style)
	{
		switch (style)
		{
		case Qt::SolidLine: return "solid";
		case Qt::DashLine: return "dash";
		case Qt::DotLine: return "dot";
		case Qt::NoPen:
		default:  return "nopen";
		}
	}

	//
	inline QString colorToString(const QColor &color) const
	{
		return "0x" + QString::number(color.rgba(), 16);
	}


	// friend functions and operators
	friend bool operator==(const SceneConfigTag& left, const SceneConfigTag& right);

//	Incapsulation
//
//	SSceneTag &sceneInfo() { return m_SceneInfo; }
//
//	SSceneTag sceneInfo() const { return m_SceneInfo; }
//	void setSceneInfo(const SSceneTag &sceneInfo) { m_SceneInfo = sceneInfo;  }
//
//private:
//	SSceneTag m_SceneInfo;
//

};


#endif // #ifndef SCENE_CONFIG_INFO_H
