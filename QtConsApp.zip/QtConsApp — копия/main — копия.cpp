#include <iostream>
#include <string>

#include "SceneDataSet.h"

#define MY_TEST false


QString getFileSignatureMd5(QString fileName)
{
	QCryptographicHash hash(QCryptographicHash::Md5);
	QFile file(fileName);
	file.open(QIODevice::ReadOnly);
	hash.addData(file.readAll());
	file.close();
	return hash.result().toHex();
}

QString getFileSignatureSha1(QString fileName)
{
	bool isSigned = false;
	QCryptographicHash hash(QCryptographicHash::Sha1);
	QFile file(fileName);

	if (file.open(QIODevice::ReadOnly)) {
		hash.addData(file.readAll());
		isSigned = true;
	}
	else { // Handle "cannot open file" error
		isSigned = false;
	}

	// Retrieve the SHA1 signature of the file
	return hash.result().toHex();
}

bool testLoadSaveByHash(QString fileLoaded, QString fileSaved)
{
	QString sigLoaded = getFileSignatureMd5(fileLoaded);
	QString sigSaved = getFileSignatureMd5(fileSaved);

	return sigLoaded == sigSaved;
}

bool testEqualityOfConfigs(SceneConfigTag& ScnConf_1, SceneConfigTag& ScnConf_2, QStringList& errors)
{
	if ( !(ScnConf_1.m_SceneInfo == ScnConf_2.m_SceneInfo) )
	{
		errors += "Difference found in section: SceneInfo";
	}
	if ( !(ScnConf_1.m_FontInfo == ScnConf_2.m_FontInfo) )
	{
		errors += "Difference found in section: FontInfo";
	}
	if ( !(ScnConf_1.m_BackgroundInfo == ScnConf_2.m_BackgroundInfo))
	{
		errors += "Difference found in section: BackgroundInfo";
	}
	if ( !(ScnConf_1.m_GridInfo == ScnConf_2.m_GridInfo))
	{
		errors += "Difference found in section: GridInfo";
	}
	if ( !(ScnConf_1.m_script == ScnConf_2.m_script))
	{
		errors += "Difference found in section: SceneScript";
	}
	if ( !(ScnConf_1.m_colors == ScnConf_2.m_colors))
	{
		errors += "Difference found in section: SceneColors";
	}
	if ( !(ScnConf_1.m_scriptTypes == ScnConf_2.m_scriptTypes))
	{
		errors += "Difference found in section: SceneScriptTypes";
	}

	return errors.isEmpty();
}


bool testEqualityByStructs(QString file_1, QString file_2)
{
	SceneDataSet* XmlConf_1 = SceneDataSet::identifyData(file_1);
	XmlConf_1->loadConfig();

	SceneDataSet* XmlConf_2 = SceneDataSet::identifyData(file_2);
	XmlConf_2->loadConfig();

	bool t = false;
	t = (XmlConf_1->SceneConfigInfo == XmlConf_2->SceneConfigInfo);
	
	if (!t)
	{
		QStringList err;
		testEqualityOfConfigs(XmlConf_1->SceneConfigInfo, XmlConf_2->SceneConfigInfo, err);
	}

	delete XmlConf_1;
	delete XmlConf_2;

	return t;
}

bool testLoadSaveByStructs(QString fileLoaded, QString fileSaved)
{
	SceneDataSet* XmlConfLoaded = SceneDataSet::identifyData(fileLoaded);
	XmlConfLoaded->loadConfig();
	XmlConfLoaded->saveConfig(fileSaved);

	SceneDataSet* XmlConfReLoaded = SceneDataSet::identifyData(fileSaved);
	XmlConfReLoaded->loadConfig();

	bool t = false;
	t = (XmlConfLoaded->SceneConfigInfo == XmlConfReLoaded->SceneConfigInfo);
	if (!t)
	{
		QStringList err;
		testEqualityOfConfigs(XmlConfLoaded->SceneConfigInfo, XmlConfReLoaded->SceneConfigInfo, err);
	}

	delete XmlConfLoaded;
	delete XmlConfReLoaded;

	return t;
}




int main(int argc, char *argv[])
{
	//bool t1 = testLoadSaveByHash("1.txt", "2.txt");
		
	//QCoreApplication a(argc, argv);
	//return a.exec();


	/* WORKS FINE !!!
	 SceneDataSet* XmlConf = SceneDataSet::identifyData("stationViewConfig.scn");
	 XmlConf->loadConfig();
	 delete XmlConf;
	 //*/

	/* WORKS FINE !!!
	SceneDataSet* XmlData = SceneDataSet::identifyData("stationViewConfigSave.scn");
	XmlData->saveConfig();
	delete XmlData;
	//*/

	/* WORKS FINE !!!
	SceneDataSet* XmlData = SceneDataSet::identifyData("stationViewData.scn");
	XmlData->loadData();
	delete XmlData;
	//*/

	/* WORKS FINE !!!
	SceneDataSet* XmlDataT = SceneDataSet::identifyData("stationViewDataSave.scn");
	XmlDataT->saveData();
	delete XmlDataT;
	//*/

	QString confLoad = "stationViewConfig.scn";
	QString confSave = "stationViewConfigTest.scn";

	bool test_1 = testLoadSaveByStructs(confLoad, confSave);


	//std::cout << XmlData->type << std::endl;

	SceneDataSet* JsonData = SceneDataSet::identifyData("file-json.json");
	JsonData->loadData();
	delete JsonData;
	//std::cout << JsonData->type << std::endl;
}





